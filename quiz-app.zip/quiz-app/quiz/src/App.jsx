import "./App.css";
import Router from "./routes/Router";

function App() {
  return (
    <div>
      <h1>Hello</h1>
      <Router />
    </div>
  );
}

export default App;
