import React from 'react'
import { Link } from 'react-router-dom'

const Quiz = () => {
  return (
    <div>
        <p>quioz quesssssssssssd</p>
    </div>
  )
}

export default Quiz