// import AuthServices from './auth';
// import CreatorService from './creators';
// import EmpoloyeeServices from './employee';

// export const startIpcServices = async () => {
//   AuthServices();
//   EmpoloyeeServices();
//   CreatorService();
// };
