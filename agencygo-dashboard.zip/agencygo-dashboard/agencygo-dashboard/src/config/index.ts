const API_URL = 
// 'http://116.202.210.102:3000';
'http://localhost:3000';
// 'https://227b-2405-201-200c-c0e6-84c1-c0f0-449d-9633.ngrok-free.app';

// 'http://ec2-18-190-107-196.us-east-2.compute.amazonaws.com:3000';
// 'http://agencygo-server-production-7f8475c1a038de7b.elb.us-east-2.amazonaws.com';

const accountSid = 'AC043ba2179c12c98863bf78d6332c3477';
const authToken = 'da9ef7088769b0b5bd8b688317b08c1a';
// const apiKey='YOUR_API_KEY_SID'
// const apiSecret=YOUR_API_SECRETW
// const addressSid=YOUR_ADDRESS_SID
// const conversationsServiceSid=YOUR_CONVERSATIONS_SERVICE_SID
// const REACT_APP_DEPLOYMENT_KEY=YOUR_REACT_APP_DEPLOYMENT_KEY
// const REACT_APP_REGION=YOUR_REACT_APP_REGION

export { API_URL, accountSid, authToken };
