export type Creator = {
  agencyId: string;
  autoRelink: boolean;
  creatorImage: string | null;
  creatorName: string;
  ofcreds: {
    email: string;
    password: string;
  };
  gender: string;
  id: string;
  _id?: string;
  internalNotes: string;
  isLinkOnlyFans?: boolean;
  status: boolean;
  assignEmployee: {
    _id: string;
  }[];
  proxy: {
    isAgencyProxy: boolean;
    proxyString: string;
  };
  agencyComission: number;
  creatorComission: number;
  tags: string[];
}