const managers = [
  {
    id: 1001,
    name: 'Joan Adams',
    profileImage: '',
  },
  {
    id: 1002,
    name: 'Brad Goldborn',
    profileImage: '',
    notificationCount: 3,
    messageCount: 1,
  },
  {
    id: 1003,
    name: 'Michelle Smith',
    profileImage: '',
  },
  {
    id: 1004,
    name: 'Don Toliver',
    profileImage: '',
  },
];

export default managers;
