// for timer
export const SET_TOTAL_WORK_TIME = 'SET_TOTAL_WORK_TIME';
export const SET_TOTAL_BREAK_TIME = 'SET_TOTAL_BREAK_TIME';
export const IS_CLOCK_OUT = 'IS_CLOCK_OUT';
export const IS_CLOCKED_IN = 'IS_CLOCKED_IN';
export const IS_ON_BREAK = 'IS_ON_BREAK';
export const SET_TIMER_ACTIVE = 'SET_TIMER_ACTIVE';
export const SET_BREAK_TIMER_ACTIVE = 'SET_BREAK_TIMER_ACTIVE';
