import { createContext } from "react";

export const MyInvoiceContext = createContext<any | null>("");
