export const genderList = [
  {
    label: 'Male',
    value: 'male',
  },
  {
    label: 'Female',
    value: 'female',
  },
  {
    label: 'Trans',
    value: 'trans',
  },
  {
    label: 'Other',
    value: 'other',
  },
];
export const assignEmployeeList = [];
