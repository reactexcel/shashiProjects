import { Box, Typography, useTheme } from '@mui/material';
import Overlay from 'renderer/components/Settings/Wallet/Common/Modal';
import { ModalFooter } from 'renderer/components/Settings/Wallet/Common/ModalComponents';
import { deleteTags } from '../utils';

export default function DeleteTagsModal({
  openDeleteTagModal,
  handleCloseDeleteTagModal,
  currentTag,
  setTagsList,
  selectedCreator,
  deleteType,
  deleteSelectedScript,
}: any) {
  const theme = useTheme();
  const agencyID = localStorage.getItem('AgencyId');
  const isDarkTheme = theme.palette.mode === 'dark';
  const tagId = currentTag?._id;

  const deleteTagsHandler = () => {
    if (deleteType == 'tag') {
      deleteTags({ tagId, setTagsList, selectedCreator, agencyID });
    } else {
      deleteSelectedScript(tagId);
    }
    handleCloseDeleteTagModal();
  };
  return (
    <Overlay
      heading={`Delete the ${deleteType}?`}
      open={openDeleteTagModal}
      handleClose={handleCloseDeleteTagModal}
    >
      <Box
        sx={{
          backgroundColor: isDarkTheme ? '#4B4B4B' : '#fff',
          padding: '10px 30px',
        }}
      >
        <Typography>
          This action will permanently remove {currentTag.name} from the
          Creator's scripts. This operation cannot be undone.
        </Typography>
      </Box>
      <ModalFooter
        addHandler={deleteTagsHandler}
        cancelHandler={handleCloseDeleteTagModal}
        addText={'Delete'}
        cancelText={'Cancel'}
        // isLoading={isLoading}
        id="deleteTags"
      />
    </Overlay>
  );
}
