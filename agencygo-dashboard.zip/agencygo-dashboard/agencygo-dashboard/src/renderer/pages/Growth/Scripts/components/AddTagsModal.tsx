import { Box, Stack, Typography, useTheme } from '@mui/material';
import { useEffect } from 'react';
import Overlay from 'renderer/components/Settings/Wallet/Common/Modal';
import { ModalFooter } from 'renderer/components/Settings/Wallet/Common/ModalComponents';
import { createTag, editTags } from '../utils';

interface AddTagsModalProps {
  openAddTagModal: boolean;
  tagModalType: string;
  handleClose: () => void;
  style: any;
  tagName: string;
  setTagName: (e: any) => void;
  currentTag?: any;
  setTagsList: any;
  setTagModalType?: any;
  selectedCreator?: string;
}
const AddTagsModal = ({
  openAddTagModal,
  tagModalType,
  handleClose,
  style,
  tagName,
  setTagName,
  currentTag,
  setTagsList,
  setTagModalType,
  selectedCreator,
}: AddTagsModalProps) => {
  const agencyID = localStorage.getItem('AgencyId');
  const theme = useTheme();
  const isDarkTheme = theme.palette.mode === 'dark';
  const tagId = currentTag._id;
  const oldTagName = currentTag.name;

  useEffect(() => {
    if (Object.keys(currentTag).length > 0) {
      setTagName(oldTagName);
    }
  }, [currentTag]);

  const addTagHandler = () => {
    if (tagModalType == 'add') {
      createTag({
        tagName,
        setTagsList,
        setTagModalType,
        selectedCreator,
        handleClose,
        agencyID,
        setTagName,
      });
    } else {
      editTags({
        tagId,
        tagName,
        setTagsList,
        handleClose,
        setTagName,
        selectedCreator,
        agencyID,
      });
    }
  };

  return (
      <Overlay
        heading={tagModalType === 'add' ? 'Add tag name' : 'Modify tag name'}
        open={openAddTagModal}
        handleClose={handleClose}
      >
        <Box
          sx={{
            backgroundColor: isDarkTheme ? '#4B4B4B' : '#fff',
          }}
        >
          <Stack
            gap="10px"
            sx={{
              marginInline: '30px',
              padding: '20px 0px',
            }}
            // className={styles.inputListWrapper}
          >
            <Typography>Tag Name</Typography>
            <input
              placeholder="Enter tag name"
              value={tagName}
              required
              onChange={(e) => setTagName(e.target.value)}
              style={{
                borderRadius: '3px',
                border: '1px solid #aaa',
                padding: '12px',
                width: '100%',
                marginTop: '2px',
                boxSizing: 'border-box',
                backgroundColor: isDarkTheme ? '#000' : '#EAF1FF',
                color: isDarkTheme ? '#fff' : '#000',
              }}
            />
          </Stack>
        </Box>
        <ModalFooter
          addHandler={addTagHandler}
          cancelHandler={handleClose}
          addText={'Ok'}
          cancelText={'Cancel'}
          // isLoading={isLoading}
          id="AddEditTags"
        />
      </Overlay>
  );
};

export default AddTagsModal;
