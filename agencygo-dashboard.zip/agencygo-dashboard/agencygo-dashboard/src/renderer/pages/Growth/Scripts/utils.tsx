import fetchReq from 'utils/fetch';

export const createTag = ({
  tagName,
  setTagsList,
  setTagModalType,
  handleClose,
  setTagName,
  selectedCreator,
  agencyID,
}: any) => {
  const payload = {
    name: tagName,
    agencyId: agencyID,
    creatorId: selectedCreator,
  };
  const endPoint = `tags/`;
  const options = {
    method: 'POST' as 'POST',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
    body: JSON.stringify(payload),
  };
  fetchReq(endPoint, options)
    .then((response) => {
      response.json();
    })
    .then((_res) => {
      getTags({ setTagsList, selectedCreator, agencyID });
      setTagModalType('');
      handleClose();
      setTagName('');
    })
    .catch((err) => console.log(err));
};

export const getTags = ({ setTagsList, selectedCreator, agencyID}: any) => {
  const endPoint = `tags/agency/${agencyID}/creator/${selectedCreator}`;
  const options = {
    method: 'GET' as 'GET',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      setTagsList(res.data);
      
    })
    .catch((err) => {
      console.log(err);
    });
};

export const deleteTags = ({
  tagId,
  setTagsList,
  selectedCreator,
  agencyID,
}: any) => {
  const endPoint = `tags/deleteTag/tag/${tagId}`;
  const options = {
    method: 'DELETE' as 'DELETE',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      if (res.message == 'Tag deleted Successfully') {
        getTags({ setTagsList, selectedCreator, agencyID });
      }
    })
    .catch((err) => {
      console.log(err);
    });
};

export const editTags = ({
  tagId,
  tagName,
  setTagsList,
  handleClose,
  setTagName,
  selectedCreator,
  agencyID,
}: any) => {
  const endPoint = `tags/updateTag/` + tagId;
  const payload = {
    name: tagName,
  };
  const options = {
    method: 'PUT' as 'PUT',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
    body: JSON.stringify(payload),
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      if (res.message == 'Tag udpated Successfully') {
        getTags({ setTagsList, agencyID, selectedCreator });
        handleClose();
        setTagName('');
      }
    })
    .catch((err) => {
      console.log(err);
      handleClose();
      setTagName('');
    });
};

export const getAllScripts = ({ setAllScriptList, selectedCreator }: any) => {
  const endPoint = `tags/getAllScriptsOfCreator/${selectedCreator}`;
  const options = {
    method: 'GET' as 'GET',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      setAllScriptList(res.data);
    })
    .catch((err) => {
      console.log(err);
    });
};

export const getAllCreator = ({ setAllCreator }: any) => {
  const agencyId = localStorage.getItem('AgencyId');
  const endPoint = `creators/` + agencyId;
  const options = {
    method: 'GET' as 'GET',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      setAllCreator(res.data.creators);
    })
    .catch((err) => {
      console.log(err);
    });
};

export const getTagScript = (setAllScriptList: any, tagId: string) => {
  const endPoint = `tags/getScripts/${tagId}`;
  const options = {
    method: 'GET' as 'GET',
    headers: {
      'content-type': 'application/json',
    },
    withAuth: true,
  };

  fetchReq(endPoint, options)
    .then((response) => response.json())
    .then((res) => {
      setAllScriptList(res.data);
    })
    .catch((err) => {
      console.log(err);
    });
};

// export const addScripts = ({
//   tagName,
//   setTagsList,
//   setTagModalType,
//   handleClose,
//   setTagName,
//   selectedCreator,
//   agencyID,
// }: any) => {
//   const payload = {
//     name:"script2",
//     agencyId:"656f4472a461bb97c821168a",
//     creatorId:"656f4761d765ee2dda21078c",
//     tag:"6574bc0a33b0131a514f7085",
//     text:"hi",
//     notes:"hi",
//     messagePrice:10
//   };
//   const endPoint = `scripts/`;
//   const options = {
//     method: 'POST' as 'POST',
//     headers: {
//       'content-type': 'application/json',
//     },
//     withAuth: true,
//     body: JSON.stringify(payload),
//   };
//   fetchReq(endPoint, options)
//     .then((response) => {
//       response.json();
//     })
//     .then((_res) => {
//       getTags({ setTagsList, selectedCreator, agencyID });
//       setTagModalType('');
//       handleClose();
//       setTagName('');
//     })
//     .catch((err) => console.log(err));
// };
