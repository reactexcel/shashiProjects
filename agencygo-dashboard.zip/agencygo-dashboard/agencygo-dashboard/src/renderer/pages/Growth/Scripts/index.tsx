import * as React from 'react';
import { useState, useEffect, useContext } from 'react';
import SearchInput from 'renderer/components/SearchInput';
import {
  Box,
  Button,
  Stack,
  TableCell,
  TableRow,
  Typography,
  useTheme,
} from '@mui/material';
import { Add } from '@mui/icons-material';
import SearchUsers from 'renderer/components/SearchUsers';
import FilterTable from 'renderer/components/Filter/FilterTable';
import AddTagsModal from './components/AddTagsModal';
import DeleteTagsModal from './components/DeleteTagsModal';
import { getAllScripts, getTags, getAllCreator, getTagScript } from './utils';
import { AuthContext } from 'renderer/contexts/AuthContext';
import { styled } from '@mui/material/styles';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
import MailOutlineIcon from '@mui/icons-material/MailOutline';
import LayersIcon from '@mui/icons-material/Layers';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useLocation } from 'react-router-dom';
import AddScriptsModal from './components/AddScriptsModal';
import fetchReq from 'utils/fetch';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '40%',
  bgcolor: 'background.paper',
  border: '1px solid gray',
  boxShadow: 24,
  p: 2,
  borderRadius: '10px',
};

const headTags = ['Name', 'Text', 'Tags', 'Notes', 'Statistics', 'Operations'];
interface AllScriptProps {
  _id: string;
  messagePrice: number;
  notes: string;
  text: string;
  name: string;
  tags: [
    {
      name: string;
    }
  ];
}
function Scripts() {
  const { userData, userDetail } = useContext(AuthContext);
  const [search, setSearch] = useState('');
  const [tagsList, setTagsList] = useState([]);
  const [allCreator, setAllCreator] = useState([]);
  const [openAddTagModal, setOpenAddTagModal] = useState(false);
  const [openDeleteTagModal, setOpenDeleteTagModal] = useState(false);
  const [tagModalType, setTagModalType] = useState('');
  const [currentTag, setCurrentTag] = useState({});
  const [allScriptList, setAllScriptList] = useState([]);
  const [selectedCreator, setSelectedCreator] = useState('');
  const [selectedScript, setSelectedScript] = useState({});
  const [scriptType, setScriptType] = useState('add');
  const agencyID = localStorage.getItem('AgencyId');
  const [openScriptModal, setOpenScriptModal] = React.useState(false);
  const handleOpenScriptModal = () => setOpenScriptModal(true);
  const [deleteType, setDeleteType] = useState('');
  const location = useLocation();
  const path = location.pathname;

  const isScriptsPage = path.includes('scripts');
  const onSearch = (value: string) => {
    setSearch(value);
  };
  const [tagName, setTagName] = useState('');

  useEffect(() => {
    if (selectedCreator && agencyID) {
      getTags({ setTagsList, selectedCreator, agencyID });
      getAllCurrentScripts();
    }
    getAllCreator({ setAllCreator });
  }, [selectedCreator]);

  useEffect(() => {
    if (Object.keys(userData).length == 0) {
      userDetail();
    }
  }, [userData]);

  const handleOpen = () => {
    setTagModalType('add');
    setCurrentTag({});
    setOpenAddTagModal(true);
  };
  const handleClose = () => {
    setOpenAddTagModal(false);
    setTagModalType('');
  };

  const handleCloseDeleteTagModal = () => {
    setOpenDeleteTagModal(false);
  };

  const getAllCurrentScripts = () => {
    getAllScripts({ setAllScriptList, selectedCreator });
  };

  const BootstrapTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} arrow classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.arrow}`]: {
      color: theme.palette.common.black,
    },
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: theme.palette.common.black,
    },
  }));

  const theme = useTheme();
  const isDarkTheme = theme.palette.mode === 'dark';

  const deleteSelectedScript = (scriptId: string) => {
    let endpoint = `scripts/${scriptId}`;
    let options = {
      method: 'DELETE' as 'DELETE',
      headers: {
        'content-type': 'application/json',
      },
      withAuth: true,
    };
    fetchReq(endpoint, options)
      .then((response) => response.json())
      .then((res) => {
        if (res.message == 'Tag deleted Successfully') {
          setAllScriptList(
            allScriptList.filter((val: any) => val._id != scriptId)
          );
          getAllCurrentScripts();
        }
      })
      .catch((err) => {
        console.log('Error occured: ', err);
      });
  };

  return (
    <>
      <div style={{ position: 'absolute', top: 30, right: 30 }}>
        {isScriptsPage && (
          <AddScriptsModal
            scriptType={scriptType}
            setScriptType={setScriptType}
            selectedScript={selectedScript}
            setSelectedScript={setSelectedScript}
            tagsList={tagsList}
            setTagsList={setTagsList}
            selectedCreator={selectedCreator}
            getAllCurrentScripts={getAllCurrentScripts}
            openScriptModal={openScriptModal}
            setOpenScriptModal={setOpenScriptModal}
            handleOpenScriptModal={handleOpenScriptModal}
          />
        )}
      </div>
      <SearchUsers
        allCreator={allCreator}
        setSelectedCreator={setSelectedCreator}
        selectedCreator={selectedCreator}
      />
      <Box marginLeft="32px" marginRight="16px" marginTop="16px">
        <Stack gap="22px">
          <Stack
            direction="row"
            justifyContent="space-between"
            alignItems={'center'}
          >
            <SearchInput
              value={search}
              onUpdateSearch={onSearch}
              onSearch={() => {}}
            />
            <Stack direction="row" gap="10px">
              <Button
                variant="outlined"
                sx={{
                  borderColor: theme.palette.primary.main,
                  marginLeft: 'auto',
                  height: '32px',
                  textTransform: 'unset',
                }}
              >
                <Typography
                  fontWeight={600}
                  fontSize="14px"
                  color={theme.palette.primary.main}
                  textTransform="unset"
                >
                  Reset
                </Typography>
              </Button>
              <Button
                variant="contained"
                sx={{
                  background: theme.palette.primary.main,
                  marginLeft: 'auto',
                  height: '32px',
                  textTransform: 'unset',
                }}
              >
                <Typography
                  fontWeight={600}
                  fontSize="14px"
                  color="#fff"
                  textTransform="unset"
                >
                  Filter
                </Typography>
              </Button>
            </Stack>
          </Stack>
          <Stack direction="row" gap="16px" alignItems="center">
            <Button
              onClick={handleOpen}
              variant="text"
              sx={{
                borderColor: theme.palette.primary.main,
                height: '32px',
                textTransform: 'unset',
              }}
              startIcon={<Add sx={{ color: theme.palette.primary.main }} />}
            >
              <Typography
                fontWeight={600}
                fontSize="14px"
                fontFamily={'Arimo'}
                color={theme.palette.primary.main}
                textTransform="unset"
              >
                New Tag
              </Typography>
            </Button>
            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
              <Typography
                display={'flex'}
                justifyContent={'center'}
                alignItems={'center'}
                gap={'2px'}
                fontWeight={600}
                fontSize="11px"
                color="#fff"
                fontFamily={'Arimo'}
                textTransform="unset"
                padding="5px 7px"
                borderRadius="16px"
                sx={{
                  background: theme.palette.primary.main,
                  cursor: 'pointer',
                  padding: '5px 10px',
                }}
                onClick={getAllCurrentScripts}
              >
                All Tags
              </Typography>
              {tagsList.map((tag: any) => (
                <BootstrapTooltip
                  sx={{ cursor: 'pointer' }}
                  title={
                    <span>
                      <span
                        onClick={() => {
                          setTagModalType('edit');
                          setOpenAddTagModal(true);
                          setCurrentTag(tag);
                        }}
                      >
                        Edit
                      </span>{' '}
                      |{' '}
                      <span
                        onClick={() => {
                          setOpenDeleteTagModal(!openDeleteTagModal);
                          setCurrentTag(tag);
                          setDeleteType('tag');
                        }}
                      >
                        Delete
                      </span>
                    </span>
                  }
                >
                  <Typography
                    display={'flex'}
                    justifyContent={'center'}
                    alignItems={'center'}
                    gap={'2px'}
                    fontWeight={600}
                    fontSize="11px"
                    color="#fff"
                    fontFamily={'Arimo'}
                    textTransform="unset"
                    padding="5px 7px"
                    borderRadius="16px"
                    sx={{
                      background: theme.palette.primary.main,
                      cursor: 'pointer',
                      padding: '5px 10px',
                    }}
                    onClick={() => getTagScript(setAllScriptList, tag._id)}
                  >
                    {tag.name}
                    {/* <ModeEditOutlineIcon
                    sx={{ fontSize: '11px' }}
                    onClick={() => {
                      setTagModalType('edit');
                      setOpenAddTagModal(true);
                      setCurrentTag(tag);
                    }}
                  />
                  <DeleteIcon
                    sx={{ fontSize: '11px' }}
                    onClick={() => {
                      setOpenDeleteTagModal(!openDeleteTagModal);
                      setCurrentTag(tag);
                    }}
                  /> */}
                  </Typography>
                </BootstrapTooltip>
              ))}
            </div>
          </Stack>

          <FilterTable
            isEmptyContent={!allScriptList.length}
            tableHeaders={headTags}
          >
            <>
              {allScriptList.map((val: AllScriptProps) => {
                return (
                  <TableRow>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                      }}
                      scope="row"
                    >
                      <Stack spacing={1} direction="row" alignItems="center">
                        <Typography
                          variant="h6"
                          fontSize="18px"
                          color={isDarkTheme ? '#fff' : '#000'}
                        >
                          {val.name}
                        </Typography>
                      </Stack>
                    </TableCell>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                        color: '#fff',
                        width: '300px',
                      }}
                      // onClick={}
                    >
                      <Typography color={isDarkTheme ? '#fff' : '#000'}>
                        {val.text}
                      </Typography>
                    </TableCell>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                        color: '#fff',
                      }}
                    >
                      <Typography color={isDarkTheme ? '#fff' : '#000'}>
                        {val?.tags[0]?.name}
                      </Typography>
                    </TableCell>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                        color: '#fff',
                      }}
                    >
                      <Typography color={isDarkTheme ? '#fff' : '#000'}>
                        {val.notes}
                      </Typography>
                    </TableCell>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                      }}
                    >
                      <Box sx={{ display: 'flex', gap: '15px' }}>
                        <span
                          style={{
                            display: 'flex',
                            gap: '5px',
                            alignItems: 'center',
                          }}
                        >
                          <MailOutlineIcon
                            sx={{ color: 'gray', fontSize: '20px' }}
                          />{' '}
                          0
                        </span>
                        <span
                          style={{
                            display: 'flex',
                            gap: '5px',
                            alignItems: 'center',
                          }}
                        >
                          <ShoppingCartIcon
                            sx={{ color: 'gray', fontSize: '20px' }}
                          />{' '}
                          0
                        </span>
                        <span
                          style={{
                            display: 'flex',
                            gap: '5px',
                            alignItems: 'center',
                          }}
                        >
                          <LayersIcon
                            sx={{ color: 'gray', fontSize: '20px' }}
                          />{' '}
                          ${val.messagePrice}
                        </span>
                      </Box>
                    </TableCell>
                    <TableCell
                      sx={{
                        borderColor: theme.palette.primary.contrastText,
                      }}
                    >
                      <Stack spacing={1} direction="row" alignItems="center">
                        <Button
                          style={{
                            cursor: 'pointer',
                            textTransform: 'capitalize',
                          }}
                          onClick={() => {
                            setSelectedScript(val);
                            setScriptType('edit');
                            handleOpenScriptModal();
                          }}
                        >
                          Edit
                        </Button>
                        <Typography style={{ color: 'gray' }}> | </Typography>
                        <span
                          style={{ cursor: 'pointer', color: 'red' }}
                          onClick={() => {
                            setCurrentTag(val);
                            setOpenDeleteTagModal(!openDeleteTagModal);
                            setDeleteType('script');
                          }}
                        >
                          Delete
                        </span>
                      </Stack>
                    </TableCell>
                  </TableRow>
                );
              })}
            </>
          </FilterTable>
        </Stack>
      </Box>
      {tagModalType && (
        <AddTagsModal
          tagModalType={tagModalType}
          openAddTagModal={openAddTagModal}
          handleClose={handleClose}
          style={style}
          tagName={tagName}
          setTagName={setTagName}
          currentTag={currentTag}
          setTagsList={setTagsList}
          setTagModalType={setTagModalType}
          selectedCreator={selectedCreator}
        />
      )}
      <DeleteTagsModal
        setTagsList={setTagsList}
        currentTag={currentTag}
        selectedCreator={selectedCreator}
        openDeleteTagModal={openDeleteTagModal}
        handleCloseDeleteTagModal={handleCloseDeleteTagModal}
        deleteType={deleteType}
        deleteSelectedScript={deleteSelectedScript}
      />
    </>
  );
}

export default Scripts;
