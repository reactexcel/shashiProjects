import * as React from 'react';
import { Add } from '@mui/icons-material';
import {
  Button,
  Box,
  Modal,
  Stack,
  Typography,
  FormControl,
  TextField,
  FormLabel,
  FormGroup,
  Select,
  MenuItem,
  InputAdornment,
  OutlinedInput,
  useTheme,
  Checkbox,
} from '@mui/material';
import theme from 'renderer/styles/muiTheme';
import Overlay from 'renderer/components/Settings/Wallet/Common/Modal';
import { ModalFooter } from 'renderer/components/Settings/Wallet/Common/ModalComponents';
import fetchReq from 'utils/fetch';
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '60%',
  bgcolor: 'background.paper',
  border: '1px solid gray',
  boxShadow: 24,
  p: 2,
  borderRadius: '10px',
};
export default function AddScriptsModal({
  setTagsList,
  selectedCreator,
  getAllCurrentScripts,
  scriptType,
  selectedScript,
  tagsList,
  openScriptModal,
  setOpenScriptModal,
  handleOpenScriptModal,
  setScriptType,
  setSelectedScript,
}: any) {
  const handleClose = () => {
    setOpenScriptModal(false);
    setScriptType('add');
    setSelectedScript({});
    setScriptData({
      name: '',
      text: '',
      notes: '',
      messagePrice: 0,
    });
    setCreatorImages([
      {
        id: 123456,
        image: 'https://placehold.co/600x400',
      },
      {
        id: 789101,
        image: 'https://placehold.co/600x400',
      },
    ]);
    setSelectTag('');
  };
  const agencyID = localStorage.getItem('AgencyId');
  const selectedCreatorId = selectedCreator;
  // const [tagsListData,setTagsListData]=React.useState([])

  const [selectTag, setSelectTag] = React.useState('');
  const [scriptData, setScriptData] = React.useState({
    name: '',
    text: '',
    notes: '',
    messagePrice: 0,
  });
  const [errors, setErrors] = React.useState({
    name: '',
    selectTag: '',
    text: '',
    messagePrice: '',
    notes: '',
  });
  const [creatorImages, setCreatorImages] = React.useState([
    {
      id: 123456,
      image: 'https://placehold.co/600x400',
    },
    {
      id: 789101,
      image: 'https://placehold.co/600x400',
    },
  ]);

  const validateForm = () => {
    const newErrors = {
      name: '',
      selectTag: '',
      text: '',
      messagePrice: '',
      notes: '',
    };
    let isValid = true;
    if (!scriptData.name.trim()) {
      newErrors.name = 'Name is required';
      isValid = false;
    }
    if (!selectTag) {
      newErrors.selectTag = 'Select Tag is required';
      isValid = false;
    }
    // if (!scriptData.text.trim()) {
    //   newErrors.text = 'Text is required';
    //   isValid = false;
    // }
    if (!scriptData.messagePrice) {
      newErrors.messagePrice = 'Message Price is required';
      isValid = false;
    }
    // if (!scriptData.notes.trim()) {
    //   newErrors.notes = 'Notes is required';
    //   isValid = false;
    // }
    setErrors(newErrors);
    return isValid;
  };

  React.useEffect(() => {
    if (selectedScript && scriptType == 'edit') {
      setScriptData((prev) => {
        return {
          ...prev,
          name: selectedScript.name,
          text: selectedScript.text,
          notes: selectedScript.notes,
          messagePrice: selectedScript.messagePrice,
        };
      });
      setSelectTag(selectedScript.tags[0]._id);
    }
  }, [selectedScript]);

  const theme = useTheme();
  const isDarkTheme = theme.palette.mode === 'dark';

  const handleCheckImage = (imageId: string) => {
    const updateCreatorImages = creatorImages.map((val: any) => {
      if (val.id == imageId) {
        return { ...val, paid: val.paid == true ? false : true };
      }
      return val;
    });
    setCreatorImages(updateCreatorImages);
  };

  const addScriptHandler = async () => {
    const previewsId = creatorImages
      .filter((val: any) => !val.paid)
      .map((val) => val.id);
    const mediaId = creatorImages.length && creatorImages.map((val) => val.id);
    const payload = {
      name: scriptData.name,
      agencyId: agencyID,
      creatorId: selectedCreator,
      tag: selectTag,
      text: scriptData.text,
      notes: scriptData.notes,
      messagePrice: Number(scriptData.messagePrice),
      mediaFiles: mediaId,
      previews: previewsId,
    };

    if (scriptType == 'add') {
      const endPoint = `scripts`;
      const options = {
        method: 'POST' as 'POST',
        headers: {
          'content-Type': 'application/json',
        },
        withAuth: true,
        body: JSON.stringify(payload),
      };
      try {
        fetchReq(endPoint, options)
          .then((response) => response.json())
          .then((res) => {
            setScriptData({
              name: '',
              text: '',
              notes: '',
              messagePrice: 0,
            });
            setCreatorImages([
              {
                id: 123456,
                image: 'https://placehold.co/600x400',
              },
              {
                id: 789101,
                image: 'https://placehold.co/600x400',
              },
            ]);
            handleClose();
            getAllCurrentScripts();
          })
          .catch((err) => {
            console.log(err);
          });
      } catch (error) {
        console.error(error);
      }
    } else {
      const scriptId = selectedScript?._id;
      const endPoint = `scripts/${scriptId}`;
      const options = {
        method: 'PUT' as 'PUT',
        headers: {
          'content-Type': 'application/json',
        },
        withAuth: true,
        body: JSON.stringify(payload),
      };
      try {
        fetchReq(endPoint, options)
          .then((response) => response.json())
          .then((res) => {
            setScriptData({
              name: '',
              text: '',
              notes: '',
              messagePrice: 0,
            });
            handleClose();
            getAllCurrentScripts();
            setScriptType('add');
            setSelectedScript({});
          })
          .catch((err) => {
            console.log(err);
          });
      } catch (error) {
        console.error(error);
      }
    }
  };

  return (
    <>
      <Stack direction="row" gap="10px" paddingRight={2}>
        <Button
          variant="outlined"
          sx={{
            borderColor: theme.palette.primary.main,
            marginLeft: 'auto',
            height: '32px',
            textTransform: 'unset',
          }}
        >
          <Typography
            fontWeight={600}
            fontSize="12px"
            color={theme.palette.primary.main}
            textTransform="unset"
          >
            Import from Excel
          </Typography>
        </Button>
        <Button
          onClick={handleOpenScriptModal}
          variant="contained"
          sx={{
            background: theme.palette.primary.main,
            marginLeft: 'auto',
            height: '32px',
            textTransform: 'unset',
          }}
          startIcon={<Add sx={{ color: '#fff' }} />}
          disabled={tagsList.length == 0}
        >
          <Typography
            fontWeight={600}
            fontSize="12px"
            color="#fff"
            textTransform="unset"
          >
            Add Scripts
          </Typography>
        </Button>
      </Stack>

      <Overlay
        heading={scriptType == 'edit' ? 'Edit Script' : 'Add Script'}
        open={openScriptModal}
        handleClose={handleClose}
      >
        <Box
          sx={{
            backgroundColor: isDarkTheme ? '#4B4B4B' : '#fff',
          }}
        >
          <Stack
            gap="10px"
            sx={{
              marginInline: '30px',
              padding: '20px 0px',
            }}
            // className={styles.inputListWrapper}
          >
            <FormControl
              sx={{
                width: '100%',
                display: 'flex',
                flexDirection: 'column',
                gap: '20px',
              }}
            >
              <FormGroup>
                <FormLabel>
                  <span style={{ color: 'red' }}>* </span>Name
                </FormLabel>
                <OutlinedInput
                  // onFocus={() => validateForm()}
                  onBlur={() => validateForm()}
                  size="small"
                  id="outlined-adornment-weight"
                  endAdornment={
                    <InputAdornment position="end">
                      {scriptData?.name?.length}/64
                    </InputAdornment>
                  }
                  // aria-describedby="outlined-weight-helper-text"
                  inputProps={{
                    maxLength: 64,
                    'aria-label': 'weight',
                  }}
                  required
                  value={scriptData.name}
                  onChange={(e: any) =>
                    setScriptData((prev) => {
                      return {
                        ...prev,
                        name: e.target.value,
                      };
                    })
                  }
                />
                {errors.name && (
                  <div style={{ color: 'red', fontSize: 12 }}>
                    {errors.name}
                  </div>
                )}
              </FormGroup>
              <FormGroup>
                <FormLabel>Tags</FormLabel>
                <Select
                  size="small"
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={selectTag}
                  onChange={(event: any) => {
                    setSelectTag(event.target.value);
                  }}
                  // onFocus={() => validateForm()}
                  onBlur={() => validateForm()}
                >
                  <MenuItem value="">None</MenuItem>
                  {tagsList.map((val: any) => (
                    <MenuItem value={val._id}>{val.name}</MenuItem>
                  ))}
                </Select>
                {errors.selectTag && (
                  <div style={{ color: 'red', fontSize: 12 }}>
                    {errors.selectTag}
                  </div>
                )}
              </FormGroup>
              <FormGroup>
                <FormLabel>
                  <span style={{ color: 'red' }}>* </span>Text
                </FormLabel>
                <TextField
                  // onFocus={() => validateForm()}
                  onBlur={() => validateForm()}
                  id="filled-multiline-static"
                  label=""
                  multiline
                  rows={4}
                  defaultValue=""
                  variant="filled"
                  value={scriptData.text}
                  onChange={(e: any) =>
                    setScriptData((prev) => {
                      return {
                        ...prev,
                        text: e.target.value,
                      };
                    })
                  }
                />
                {errors.text && (
                  <div style={{ color: 'red', fontSize: 12 }}>
                    {errors.text}
                  </div>
                )}
              </FormGroup>
              <FormGroup>
                <Box
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}
                >
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <FormLabel>Message price:</FormLabel>
                    <TextField
                      // onFocus={() => validateForm()}
                      onBlur={() => validateForm()}
                      required
                      size="small"
                      id="standard-start-adornment"
                      sx={{ m: 1, width: '20ch' }}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">$</InputAdornment>
                        ),
                      }}
                      value={scriptData.messagePrice}
                      variant="outlined"
                      onChange={(e: any) =>
                        setScriptData((prev) => {
                          return {
                            ...prev,
                            messagePrice: e.target.value,
                          };
                        })
                      }
                    />
                  </Box>
                  <span>0 of 0 selected as PPV</span>
                </Box>
                {errors.messagePrice && (
                  <div style={{ color: 'red', fontSize: 12 }}>
                    {errors.messagePrice}
                  </div>
                )}
              </FormGroup>
              <Box
                sx={{
                  display: 'flex',
                  justifyContent: 'left',
                  gap: '10px',
                }}
              >
                <Button
                  variant="outlined"
                  sx={{
                    height: '100px',
                    display: 'flex',
                    flexDirection: 'column',
                  }}
                >
                  <Typography fontSize="20px">+</Typography>
                  <Typography>Select</Typography>
                </Button>
                <Box
                  sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'left',
                    gap: '10px',
                    position: 'relative',
                  }}
                >
                  {creatorImages.map((val: any) => {
                    return (
                      <>
                        <FormGroup
                          style={{
                            position: 'relative',
                            width: '130px',
                            height: '100px',
                            borderRadius: '3px',
                            overflow: 'hidden',
                          }}
                        >
                          <img
                            src={val.image}
                            width={'130px'}
                            height={'100%'}
                            style={{
                              width: '130px',
                              height: '100px',
                              objectFit: 'cover',
                              borderRadius: '3px',
                            }}
                          />
                          <Checkbox
                            size="small"
                            style={{
                              position: 'absolute',
                              bottom: '0px',
                              right: '0px',
                            }}
                            onChange={() => {
                              handleCheckImage(val.id);
                            }}
                          />
                        </FormGroup>
                      </>
                    );
                  })}
                </Box>
              </Box>
              <FormGroup>
                <FormLabel>Notes</FormLabel>
                <TextField
                  // onFocus={() => validateForm()}
                  onBlur={() => validateForm()}
                  id="filled-multiline-static"
                  label=""
                  multiline
                  rows={4}
                  value={scriptData.notes}
                  defaultValue=""
                  variant="outlined"
                  onChange={(e: any) => {
                    setScriptData((prev) => {
                      return {
                        ...prev,
                        notes: e.target.value,
                      };
                    });
                  }}
                />
                {errors.notes && (
                  <div style={{ color: 'red', fontSize: 12 }}>
                    {errors.notes}
                  </div>
                )}
              </FormGroup>
            </FormControl>
          </Stack>
        </Box>
        <ModalFooter
          addHandler={addScriptHandler}
          cancelHandler={handleClose}
          addText={'Save'}
          cancelText={'Cancel'}
          // isLoading={isLoading}
          id="AddEditTags"
        />
      </Overlay>
    </>
  );
}
