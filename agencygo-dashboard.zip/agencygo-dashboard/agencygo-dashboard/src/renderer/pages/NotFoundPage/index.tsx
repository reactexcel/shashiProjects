import Dashboard from 'renderer/components/Dashboard';

export default function NotFoundPage() {
  return (
    <Dashboard>
      <h1>Not Found</h1>
    </Dashboard>
  );
}
