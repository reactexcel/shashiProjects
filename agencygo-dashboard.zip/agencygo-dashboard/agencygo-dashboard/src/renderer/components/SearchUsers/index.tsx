import { useContext, useEffect, useState } from 'react';
import SearchInput from 'renderer/components/SearchInput';
import UserCardWImage from 'renderer/components/UserCardWImage';
import styles from './styles.module.css';
import { Box, Button, Stack, Typography, useTheme } from '@mui/material';

import ProfilePic from 'renderer/assets/png/profile.jpg';
import { MyInvoiceContext } from 'renderer/pages/Accounting/Invoicing/context/context';
import {
  agencyCreatorSplit,
  randomNumber,
} from 'renderer/pages/Accounting/Invoicing';
import { DataGrid } from '@mui/x-data-grid';

interface Props {
  allUsers: [];
  getUsers: () => {};
  allCreator: any;
  setSelectedCreator: (e: any) => void;
  selectedCreator: string;
}

export default function SearchUsers({
  allUsers,
  getUsers,
  allCreator,
  setSelectedCreator,
  selectedCreator,
}: Props) {
  const [search, setSearch] = useState('');
  const [filteredUsers, setFilteredUsers] = useState<any>([]);
  const { data, setData } = useContext<any>(MyInvoiceContext);

  const theme = useTheme();
  const isDarkTheme = theme.palette.mode === 'dark';

  useEffect(() => {
    setFilteredUsers(allUsers ?? []);
    const length = allUsers?.length;
    if (length > 0) {
      // Automatically set the first user in the list as the default selected user
      setData((prevData: any) => ({
        ...prevData,
        ...(allUsers[length - length] as {}),
        currentModalBalance:
          data?.currentModalBalance ?? randomNumber(25000, 1000),
        agencyPer: data?.agencyPer ?? agencyCreatorSplit(),
      }));
    }
  }, [allUsers]);

  const onSearch = (value: string) => {
    setSearch(value);
    if (value === '') {
      // If the search value is empty, show all users
      setFilteredUsers(allUsers ?? []);
    } else {
      // Filter the users based on the search input
      const usersFromSearch = allUsers.filter((item: any) => {
        return item.firstName.toLowerCase().includes(value.toLowerCase());
      });
      setFilteredUsers(usersFromSearch);
    }
  };

  const handleUserSelection = (userId: string) => {
    setSelectedCreator(userId);
  };
  useEffect(() => {
    if (!selectedCreator && allCreator?.length > 0) {
      handleUserSelection(allCreator[0]._id);
    }
  }, [allCreator]);

  return (
    <aside
      className={styles.aside}
      style={{
        backgroundColor: isDarkTheme ? '#0C0C0C' : '#fff',
        borderColor: isDarkTheme ? '#292929' : '#EAF1FF',
        height: '75vh',
      }}
    >
      <div className={styles.search}>
        <SearchInput
          value={search}
          onUpdateSearch={onSearch}
          onSearch={() => {}}
        >
          <SearchInput.ReloadButton onRefresh={getUsers} />
        </SearchInput>
      </div>
      {filteredUsers.map((item: any, index: any) => (
        <div
          style={{ background: item?._id === data?._id ? '#04A1FF' : '' }}
          key={item?._id}
        >
          <UserCardWImage
            data={item}
            id={item._id}
            name={`${item?.firstName} ${item?.lastName}`}
            notificationCount={item?.notificationCount}
            messageCount={item?.messageCount}
            key={item?._id} // Use a unique key, such as _id
            profileImage={''}
            selected={false}
            autoRelink={false}
            onClick={() => {
              setData({
                ...item,
                currentModalBalance:
                  item?.currentModalBalance ?? randomNumber(25000, 1000),
                agencyPer: item?.agencyPer ?? agencyCreatorSplit(),
              });
              console.log('Selected creator:', item);
            }}
          />
        </div>
      ))}
      <Box sx={{ overflow: 'auto', height: '55vh' }}>
        {allCreator &&
          allCreator.map((c: any) => (
            <UserCardWImage
              key={c._id}
              id={c.id}
              autoRelink={false}
              name={c.creatorName}
              profileImage={ProfilePic}
              notificationCount={0}
              messageCount={0}
              selected={selectedCreator === c._id}
              onClick={() => handleUserSelection(c._id)}
            />
          ))}
      </Box>
    </aside>
  );
}
