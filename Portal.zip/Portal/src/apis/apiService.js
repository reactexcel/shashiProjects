import config from "../config"


const API_URL = `${config.get("API_URL")}/api`;
// console.log(API_URL);
const callApi = async (url, method, token, body = null) => {
  const headers = {

  };

  if (token) {
    const cleanToken = token.replace(/^"|"$/g, ''); // Clean the token
    headers["Authorization"] = `Bearer ${cleanToken}`;
  }

  const options = {
    method,
    headers,
    body: body ? body : null, // Don't stringify the body
  };

  const response = await fetch(url, options);
  const data = await response.json();

  if (!response.ok) {
    console.log(data.message);
  }

  return data;
};

// Dynamic functions for different HTTP methods
export const postRequest = async (endpoint, token, body) => {
  console.log({ token });
  return callApi(`${API_URL}/${endpoint}`, 'PUT', token, body);
};

export const getRequest = async (endpoint, token) => {
  return callApi(`${API_URL}/${endpoint}`, 'GET', token);
};

export const getByIdRequest = async (endpoint, token) => {
  return callApi(`${API_URL}/${endpoint}`, 'GET', token);
};

export const putRequest = async (endpoint, token, body) => {
  return callApi(`${API_URL}/${endpoint}`, 'PUT', token, body);
};

export const deleteRequest = async (endpoint, token) => {
  return callApi(`${API_URL}/${endpoint}`, 'DELETE', token);
};
