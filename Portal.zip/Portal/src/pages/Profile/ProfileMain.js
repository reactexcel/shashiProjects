import React from 'react'
import Profile from '../../pages/dashboard/Tabs/Profile'

const ProfileMain = () => {
  return (
    <div style={{ "width":"100%"}}>
        <Profile />

    </div>
  )
}

export default ProfileMain
