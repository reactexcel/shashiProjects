import React, { useState, useEffect } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import withRouter from "../../components/withRouter";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios"; // Make sure axios is installed and imported
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Alert,
  Form,
  Input,
  Button,
  FormFeedback,
  Label,
  InputGroup,
  Spinner,
} from "reactstrap";

//Import action
import { registerUser, apiError } from "../../redux/actions";

//i18n
import { useTranslation } from "react-i18next";

//Import Images
import logodark from "../../assets/images/Aire Brokers Logo-01.png";
import logolight from "../../assets/images/Aire Brokers Logo-03.png";
import { createSelector } from "reselect";
import config from "../../config";

/**
 * Register component
 * @param {*} props
 */
const Register = (props) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { t } = useTranslation();

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  const selectAccount = createSelector(
    (state) => state.Auth,
    (account) => ({
      user: account.user,
      success: account.success,
      error: account.error,
    })
  );

  const { user, error, success } = useSelector(selectAccount);

  const formik = useFormik({
    initialValues: {
      first_name: "",
      last_name: "",
      email: "",
      phone: "",
      password: "",
      role: ''
    },
    validationSchema: Yup.object({
      first_name: Yup.string().required("First name is required"),
      last_name: Yup.string().required("Last name is required"),
      email: Yup.string()
        .email("Enter a proper email")
        .required("Email is required"),
      phone: Yup.string().required("Phone number is required"),
      password: Yup.string().required("Password is required"),
    }),
    onSubmit: async (values) => {
      setLoading(true);
      setErrorMsg(null);
      const requestUrl = `${config.get("API_URL")}/api/user/register`;
      console.log("Sending registration data to:", requestUrl);
      console.log("Data:", values);

      try {
        const response = await fetch(requestUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(values),
        });

        if (!response.ok) {
          const errorResponse = await response.json(); // Assuming the server sends a JSON response for errors
          dispatch(
            apiError("Network response was not ok: " + errorResponse.error)
          ); // Dispatching error to redux store
          throw new Error(
            "Network response was not ok: " + errorResponse.error
          );
        }

        const data = await response.json();
        console.log("Response:", data);
        if (
          data.message ===
          "User registered successfully, OTP has been sent on email Please verify it."
        ) {
          dispatch(registerUser(data)); // Dispatching success to redux store
          navigate("/verify-email");
        }

        // Assuming the API sends a specific message on successful registration
        if (data.message) {
          sessionStorage.setItem("userInfo", JSON.stringify(data));
          dispatch(registerUser(data)); // Dispatching success to redux store
          navigate("/verify-email"); // Redirect to verification page on successful registration
        } else {
          if (data.error) {
            throw new Error(data.error);
          }
          dispatch(
            apiError("Registration failed: No success message received")
          ); // Dispatching error to redux store
          throw new Error("Registration failed: No success message received");
        }
      } catch (error) {
        console.error("Registration error:", error);
        dispatch(
          apiError(
            error.message || "Registration failed due to an unexpected error."
          )
        ); // Dispatching error to redux store
      } finally {
        console.log("done");
        setLoading(false);
      }
    },
  });

  useEffect(() => {
    if (success) {
      setTimeout(() => navigate("/verify-email"), 3000);
    }
  }, [success, navigate]);

  useEffect(() => {
    dispatch(apiError(""));
  }, [dispatch]);

  document.title = "Register | AiRE Brokers";

  return (
    <React.Fragment>
      <div className="account-pages my-0 pt-sm-1">
        <Container>
          <Row className="justify-content-center">
            <Col md={8} lg={6} xl={5}>
              <div className="text-center mb-4">
                <Link to="/" className="auth-logo mb-2 d-block">
                  <img
                    src={logodark}
                    alt=""
                    height="200"
                    className="logo logo-dark"
                    style={{ width: "46%", heigth: "0%" }}
                  />
                  <img
                    src={logolight}
                    alt=""
                    height="200"
                    className="logo logo-light"
                    style={{ width: "46%", heigth: "10%" }}
                  />
                </Link>

                <h4>{t("Register")}</h4>
                <p className="text-muted mb-4">
                  {t("Get your AiRE Brokers account now")}.
                </p>
              </div>

              <Card>
                <CardBody className="p-4">
                  <Form onSubmit={formik.handleSubmit}>
                    {user && user ? (
                      <Alert color="success">Register User Successfully</Alert>
                    ) : null}

                    {error && error ? (
                      <Alert color="danger">
                        <div>{error}</div>
                      </Alert>
                    ) : null}

                    <FormGroup className="mb-3">
                      <Label for="first_name">{t("First Name")}</Label>
                      <Input
                        id="first_name"
                        name="first_name"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.first_name}
                        invalid={
                          formik.touched.first_name &&
                          !!formik.errors.first_name
                        }
                      />
                      {formik.touched.first_name &&
                        formik.errors.first_name && (
                          <FormFeedback type="invalid">
                            {formik.errors.first_name}
                          </FormFeedback>
                        )}
                    </FormGroup>

                    <FormGroup className="mb-3">
                      <Label for="last_name">{t("Last Name")}</Label>
                      <Input
                        id="last_name"
                        name="last_name"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.last_name}
                        invalid={
                          formik.touched.last_name && !!formik.errors.last_name
                        }
                      />
                      {formik.touched.last_name && formik.errors.last_name && (
                        <FormFeedback type="invalid">
                          {formik.errors.last_name}
                        </FormFeedback>
                      )}
                    </FormGroup>

                    <FormGroup className="mb-3">
                      <Label for="phone">{t("Phone")}</Label>
                      <Input
                        id="phone"
                        name="phone"
                        type="text"
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                        value={formik.values.phone}
                        invalid={formik.touched.phone && !!formik.errors.phone}
                      />
                      {formik.touched.phone && formik.errors.phone && (
                        <FormFeedback type="invalid">
                          {formik.errors.phone}
                        </FormFeedback>
                      )}
                    </FormGroup>

                    <div className="mb-3">
                      <Label className="form-label">{t("Email")}</Label>
                      <InputGroup className="input-group bg-soft-light rounded-3 mb-3">
                        <span className="input-group-text text-muted">
                          <i className="ri-mail-line"></i>
                        </span>
                        <Input
                          type="text"
                          id="email"
                          name="email"
                          className="form-control form-control-lg bg-soft-light border-light"
                          placeholder="Enter Email"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.email}
                          invalid={
                            formik.touched.email && formik.errors.email
                              ? true
                              : false
                          }
                        />
                        {formik.touched.email && formik.errors.email ? (
                          <FormFeedback type="invalid">
                            {formik.errors.email}
                          </FormFeedback>
                        ) : null}
                      </InputGroup>
                    </div>

                    <FormGroup className="mb-4">
                      <Label className="form-label">{t("Password")}</Label>
                      <InputGroup className="mb-3 bg-soft-light input-group-lg rounded-lg">
                        <span className="input-group-text border-light text-muted">
                          <i className="ri-lock-2-line"></i>
                        </span>
                        <Input
                          type="password"
                          id="password"
                          name="password"
                          className="form-control form-control-lg bg-soft-light border-light"
                          placeholder="Enter Password"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.password}
                          invalid={
                            formik.touched.password && formik.errors.password
                              ? true
                              : false
                          }
                        />
                        {formik.touched.password && formik.errors.password ? (
                          <FormFeedback type="invalid">
                            {formik.errors.password}
                          </FormFeedback>
                        ) : null}
                      </InputGroup>
                    </FormGroup>

                    <Button
                      color="new"
                      block
                      className="waves-effect waves-light custom-sign-in-button"
                      type="submit"
                      disabled={loading}
                    >
                      {loading ? (
                        <Spinner size="sm" color="light" />
                      ) : (
                        "Register"
                      )}
                    </Button>

                    <div className="mt-4 text-center">
                      <p className="text-muted mb-0">
                        {t("By registering you agree to the Chatvia")}
                        <Link to="#" className="text-primary">
                          {t("Terms of Use")}
                        </Link>
                      </p>
                    </div>
                  </Form>
                </CardBody>
              </Card>

              <div className="mt-5 text-center">
                <p>
                  {t("Already have an account")} ?{" "}
                  <Link to="login" className="font-weight-medium text-primary">
                    {" "}
                    {t("Signin")}{" "}
                  </Link>
                </p>
                <p>
                  © {new Date().getFullYear()} {t("AiRE Brokers")}.{" "}
                </p>
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  const { user, loading, error } = state.Auth;
  return { user, loading, error };
};

export default withRouter(
  connect(mapStateToProps, { registerUser, apiError })(Register)
);
