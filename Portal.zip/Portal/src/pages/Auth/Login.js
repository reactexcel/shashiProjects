import React, { useCallback, useEffect, useState } from "react";
import {
  Container,
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Alert,
  Form,
  Input,
  Button,
  FormFeedback,
  Label,
  InputGroup,
  Spinner,
} from "reactstrap";
import { connect, useDispatch } from "react-redux";
import { useNavigate, Link, Navigate } from "react-router-dom";
import withRouter from "../../components/withRouter";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";

//i18n
import { useTranslation } from "react-i18next";

//redux store
import { loginUser, apiError, registerUser } from "../../redux/actions";

//Import Images
import logodark from "../../assets/images/Aire Brokers Logo-01.png";
import logolight from "../../assets/images/Aire Brokers Logo-03.png";

import config from "../../config";

/**
 * Login component
 * @param {*} props
 */
const Login = (props) => {
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const { t } = useTranslation();

  const clearError = useCallback(() => {
    setErrorMsg("");
  }, []);

  useEffect(() => {
    clearError();
  }, [clearError]);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email format")
        .required("Please Enter Your Email"),
      password: Yup.string().required("Please Enter Your Password"),
    }),
    onSubmit: async (values) => {
      setLoading(true);
      setErrorMsg(""); // Clear previous errors

      const requestUrl = `${config.get("API_URL")}/api/user/login`;
      try {
        const response = await fetch(requestUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(values),
        });
        if (
          response.status === 401 ||
          response.status === 400 ||
          response.status === 500
        ) {
          const errorText = await response.text();
          setErrorMsg(`Network error: ${errorText || response.statusText}`);
          dispatch(apiError(response.statusText));
        }

        if (!response.ok) {
          const errorText = await response.clone().text();
          setErrorMsg(`Network error: ${errorText || response.statusText}`);
          dispatch(apiError(response.statusText));
          return;
        }

        const data = await response.json();
        if (data.error) {
          console.error("Login error:", data.error);
          setErrorMsg(data.error);
          setLoading(false);
        
        }

        if (data.access_token) {
          console.log("data", data.access_token);
          console.log("access token is set");
          localStorage.setItem("authUser", JSON.stringify(data.access_token));
          dispatch(
            loginUser(values.email, values.password, props.router.navigate)
          );
          navigate("/properties", { replace: true });
        } else {
          setErrorMsg(data.error || "Login failed: No access token provided");
        }
      } catch (error) {
        console.error("Login error:", error);
        setErrorMsg(error.message || "Invalid email or password");
      } finally {
        setLoading(false);
      }
    },
  });

  useEffect(() => {
    const token = localStorage.getItem("authUser");
    if (token) {
      console.log("Token found, navigating to dashboard");
      navigate("/properties");
    } else {
      console.log("No token found, staying on login");
    }
  }, [navigate]);

  useEffect(() => {
    dispatch(apiError(""));
  }, [dispatch]);

  document.title = "Login | AiRE Brokers";

  return (
    <React.Fragment>

      <div className="account-pages my-0 pt-sm-1">
        <Container>
          <Row className="justify-content-center" style={{ "marginTop": "-7%" }}>
            <Col md={8} lg={6} xl={5} >
              <div className="text-center mb-1">
                <Link to="/" className="auth-logo d-block">
                  <img src={logodark} alt="" height="200" className="logo logo-dark"
                    style={{ "width": "46%", "heigth": "0%" }} />
                  <img src={logolight} alt="" height="200" className="logo logo-light"
                    style={{ "width": "46%", "heigth": "10%" }} />
                </Link>

                <h4 style={{ "marginTop": "-5%" }}>{t("Sign in")}</h4>
                <p className="text-muted mb-1">
                  {t("Sign in to continue to AiRE Brokers")}.
                </p>
              </div>

              <Card>
                <CardBody className="p-1">
                  {props.error && <Alert color="danger">{props.error}</Alert>}
                  <div className="p-3">
                    <Form onSubmit={formik.handleSubmit}>
                    {errorMsg && <Alert color="danger">{errorMsg}</Alert>}
                      <div className="mb-3">
                        <Label className="form-label">{t("Email")}</Label>
                        <InputGroup className="mb-3 bg-soft-light rounded-3">
                          <span
                            className="input-group-text text-muted"
                            id="basic-addon3"
                          >
                            <i className="ri-user-2-line"></i>
                          </span>
                          <Input
                            type="text"
                            id="email"
                            name="email"
                            className="form-control form-control-lg border-light bg-soft-light"
                            placeholder="Enter email"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.email}
                            invalid={
                              formik.touched.email && formik.errors.email
                                ? true
                                : false
                            }
                          />
                          {formik.touched.email && formik.errors.email ? (
                            <FormFeedback type="invalid">
                              {formik.errors.email}
                            </FormFeedback>
                          ) : null}
                        </InputGroup>
                      </div>

                      <FormGroup className="mb-4">
                        <div className="float-end">
                          <Link
                            to="/forget-password"
                            className="text-muted font-size-13"
                          >
                            {t("Forgot password")}?
                          </Link>
                        </div>
                        <Label className="form-label">{t("Password")}</Label>
                        <InputGroup className="mb-3 bg-soft-light rounded-3">
                          <span className="input-group-text text-muted">
                            <i className="ri-lock-2-line"></i>
                          </span>
                          <Input
                            type="password"
                            id="password"
                            name="password"
                            className="form-control form-control-lg border-light bg-soft-light"
                            placeholder="Enter Password"
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                            value={formik.values.password}
                            invalid={
                              formik.touched.password && formik.errors.password
                                ? true
                                : false
                            }
                          />
                          {formik.touched.password && formik.errors.password ? (
                            <FormFeedback type="invalid">
                              {formik.errors.password}
                            </FormFeedback>
                          ) : null}
                        </InputGroup>
                      </FormGroup>

                      <div className="form-check mb-4">
                        <Input
                          type="checkbox"
                          className="form-check-input-custom"
                          id="remember-check"
                        />
                        <Label
                          className="form-check-label"
                          htmlFor="remember-check"
                        >
                          {t("Remember me")}
                        </Label>
                      </div>

                      <div className="d-grid">
                        <Button
                          color="new"
                          block
                          className="waves-effect waves-light custom-sign-in-button"
                          type="submit"
                          disabled={loading}
                        >
                          {loading ? (
                            <Spinner size="sm" color="light" />
                          ) : (
                            "Sign In"
                          )}
                        </Button>
                      </div>
                    </Form>
                  </div>
                </CardBody>
              </Card>

              <div className="mt-1 text-center">
                <p>
                  {t("Don't have an account")} ?{" "}
                  <Link
                    to="/register"
                    className="font-weight-medium text-primary"
                  >
                    {" "}
                    {t("Signup now")}{" "}
                  </Link>{" "}
                </p>
                {/*<p>© {new Date().getFullYear()} {t('Chatvia')}. {t('Crafted with')} <i className="mdi mdi-heart text-danger"></i> {t('by Themesbrand')}</p>*/}
              </div>
            </Col>
          </Row>
        </Container>
      </div>
    </React.Fragment>
  );
};

const mapStateToProps = (state) => {
  const { user, loading, error } = state.Auth;
  return { user, loading, error };
};

export default withRouter(
  connect(mapStateToProps, { loginUser, apiError })(Login)
);
