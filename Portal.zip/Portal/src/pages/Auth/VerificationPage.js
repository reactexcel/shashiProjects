import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
    Container, Row, Col, Card, CardBody, FormGroup, Button, Form, Input, Label, Alert, Spinner, InputGroup
} from 'reactstrap';
import logodark from "../../assets/images/Aire Brokers Logo-01.png";
import logolight from "../../assets/images/Aire Brokers Logo-03.png";
import config from '../../config';


const VerificationPage = () => {
    const navigate = useNavigate();
    const [otp, setOtp] = useState('');
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [errorMsg, setErrorMsg] = useState('');

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        setErrorMsg('');

        const requestUrl = `${config.get("API_URL")}/api/user/verify-otp`;
        const postData = {
            email,
            otp,
        };

        try {
            const response = await fetch(requestUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(postData)
            });

            if (!response.ok) {
                const errorResponse = await response.json(); // Assuming the server sends a JSON response for errors
                throw new Error('Network response was not ok: ' + (errorResponse.message || response.statusText));
            }

            const data = await response.json();
            console.log('Response:', data);

            if (data.message === 'OTP verification successful') {
                navigate('/login');
            } else {
                throw new Error(data.message || 'Verification failed: No success message received');
            }
        } catch (error) {
            console.error('Verification error:', error);
            setErrorMsg(error.message || 'Verification failed. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    // title
    document.title = "Verification Page | AiRE Brokers";

    return (
        <React.Fragment>
            <div className="account-pages my-0 pt-sm-1">
                <Container>
                    <Row className="justify-content-center my-0 pt-sm-1" style={{ "marginTop": "-7%" }}>
                        <Col md={8} lg={6} xl={5}>
                            <div className="text-center mb-1">
                                <Link to="/" className="auth-logo d-block">
                                    <img src={logodark} alt="" height="200" className="logo logo-dark"
                                        style={{ "width": "46%", "heigth": "0%" }} />
                                    <img src={logolight} alt="" height="200" className="logo logo-light"
                                        style={{ "width": "46%", "heigth": "10%" }} />
                                </Link>
                                <h4 style={{ "marginTop": "-5%" }}>Verify Your Account</h4>
                                <p className="text-muted mb-4">Enter the verification code sent to your email.</p>
                            </div>
                            <Card>
                                <CardBody>

                                    {errorMsg && <Alert color="danger">{errorMsg}</Alert>}
                                    <Form onSubmit={handleSubmit}>
                                        <FormGroup>
                                            <Label for="email">Email</Label>
                                            <InputGroup className="mb-3 bg-soft-light rounded-3">
                                                <span className="input-group-text text-muted" id="basic-addon3">
                                                    <i className="ri-user-2-line"></i>
                                                </span>
                                                <Input
                                                    type="email"
                                                    name="email"
                                                    id="email"
                                                    className="form-control form-control-lg border-light bg-soft-light"
                                                    placeholder="Enter your email"
                                                    value={email}
                                                    onChange={e => setEmail(e.target.value)}
                                                    required
                                                />
                                            </InputGroup>
                                        </FormGroup>
                                        <FormGroup>
                                            <Label for="otp">Verification Code</Label>
                                            <InputGroup className="mb-3 bg-soft-light rounded-3">
                                                <span className="input-group-text text-muted">
                                                    <i className="ri-shield-keyhole-line"></i>
                                                </span>
                                                <Input
                                                    type="text"
                                                    name="otp"
                                                    id="otp"
                                                    placeholder="Enter verification code"
                                                    className="form-control form-control-lg border-light bg-soft-light"
                                                    value={otp}
                                                    onChange={e => setOtp(e.target.value)}
                                                    required
                                                />
                                            </InputGroup>
                                        </FormGroup>
                                        <div className="d-grid">
                                            <Button
                                                color="new"
                                                block
                                                className="waves-effect waves-light custom-sign-in-button"
                                                type="submit"
                                                disabled={loading}
                                            >
                                                {loading ? <Spinner size="sm" color="light" /> : 'Sign In'}
                                            </Button>
                                        </div>
                                    </Form>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </div>
        </React.Fragment>
    );
};


export default VerificationPage;
