import React, { useState } from 'react';
import {
    Container,
    Row,
    Col,
    Card,
    CardBody,
    FormGroup,
    Button,
    Form,
    Input,
    Label,
    Alert,
    Spinner,
    InputGroup, InputGroupText
} from 'reactstrap';
import config from '../../config';
import { Link, useNavigate } from "react-router-dom";
import logodark from "../../assets/images/Aire Brokers Logo-01.png";
import logolight from "../../assets/images/Aire Brokers Logo-03.png";
import { t } from "i18next"; // Ensure you have the API endpoint configured here

const ResetPassword = () => {
    const [email, setEmail] = useState('');
    const [otp, setOtp] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState('');
    const [messageType, setMessageType] = useState('');
    const navigate = useNavigate();


    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        setMessage('');

        if (newPassword !== confirmPassword) {
            setMessage("Passwords do not match.");
            setMessageType('danger'); // Specify the alert type
            setLoading(false);
            return;
        }

        const payload = {
            email,
            otp,
            new_password: newPassword,
            confirm_password: confirmPassword,
        };

        try {
            const response = await fetch(`${config.get("API_URL")}/api/user/reset-passwd`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(payload),
            });

            const data = await response.json();
            console.log('Response:', data);
            if (!response.ok) throw new Error(data.message || 'Error resetting password');

            setMessage('Password reset successfully. Please login with your new password.');
            setMessageType('success'); // Specify the alert type as success
            setEmail('');
            setOtp('');
            setNewPassword('');
            setConfirmPassword('');
            navigate('/login');

        } catch (error) {
            setMessage(error.message || 'Error occurred');
            setMessageType('danger'); // Specify the alert type as danger
        } finally {
            setLoading(false);
        }
    };


    return (
        <React.Fragment>

            <div className="account-pages my-0 pt-sm-1">
                <Container>
                    <Row className="justify-content-center" style={{ "marginTop": "-7%" }}>
                        <Col md={8} lg={6} xl={5} >
                            <div className="text-center mb-4">
                                <Link to="/" className="auth-logo mb-2 d-block">
                                    <img src={logodark} alt="" height="200" className="logo logo-dark"
                                        style={{ "width": "46%", "heigth": "0%" }} />
                                    <img src={logolight} alt="" height="200" className="logo logo-light"
                                        style={{ "width": "46%", "heigth": "10%" }} />
                                </Link>

                                <h4>{t('Sign in')}</h4>
                                <p className="text-muted mb-4">{t('Sign in to continue to AiRE Brokers')}.</p>

                            </div>

                            <Card>
                                <CardBody className="p-4">
                                    {message && <Alert color={messageType} className="mt-4">{message}</Alert>}

                                    <div className="p-3">

                                        <Form onSubmit={handleSubmit}>
                                            <FormGroup>
                                                <Label for="email">Email</Label>
                                                <InputGroup>
                                                    <InputGroupText>
                                                        <i className="ri-mail-line"></i>
                                                    </InputGroupText>
                                                    <Input
                                                        type="email"
                                                        name="email"
                                                        id="email"
                                                        placeholder="Enter your email"
                                                        value={email}
                                                        onChange={(e) => setEmail(e.target.value)}
                                                        required
                                                    />
                                                </InputGroup>
                                            </FormGroup>

                                            <FormGroup>
                                                <Label for="otp">OTP</Label>
                                                <InputGroup>
                                                    <InputGroupText>
                                                        <i className="ri-shield-keyhole-line"></i>
                                                    </InputGroupText>
                                                    <Input
                                                        type="text"
                                                        name="otp"
                                                        id="otp"
                                                        placeholder="Enter verification code"
                                                        value={otp}
                                                        onChange={(e) => setOtp(e.target.value)}
                                                        required
                                                    />
                                                </InputGroup>
                                            </FormGroup>

                                            <FormGroup>
                                                <Label for="newPassword">New Password</Label>
                                                <Input
                                                    type="password"
                                                    name="newPassword"
                                                    id="newPassword"
                                                    placeholder="New password"
                                                    value={newPassword}
                                                    onChange={(e) => setNewPassword(e.target.value)}
                                                    required
                                                />
                                            </FormGroup>

                                            <FormGroup>
                                                <Label for="confirmPassword">Confirm Password</Label>
                                                <Input
                                                    type="password"
                                                    name="confirmPassword"
                                                    id="confirmPassword"
                                                    placeholder="Confirm password"
                                                    value={confirmPassword}
                                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                                    required
                                                />
                                            </FormGroup>

                                            <Button
                                                color="new"
                                                type="submit"
                                                disabled={loading}
                                                className="w-100"
                                            >
                                                {loading ? <Spinner size="sm" color="light" /> : 'Reset Password'}
                                            </Button>

                                        </Form>
                                    </div>
                                </CardBody>
                            </Card>
                        </Col>
                    </Row>
                </Container>
            </div>
        </React.Fragment>
    );
}


export default ResetPassword;
