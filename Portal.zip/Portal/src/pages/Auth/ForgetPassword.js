import React, { useEffect } from 'react';
import { connect } from 'react-redux';
import { Link, Navigate, useNavigate } from 'react-router-dom';

//Import formik validation
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { Container, Row, Col, Card, CardBody, FormGroup, Alert, Form, Input, Button, FormFeedback, Label, InputGroup } from 'reactstrap';

//Import actions and helpers
import { forgetPassword, apiError } from '../../redux/actions';

//i18n
import { useTranslation } from 'react-i18next';

//Import Images
import logodark from "../../assets/images/Aire Brokers Logo-01.png";
import logolight from "../../assets/images/Aire Brokers Logo-03.png";
import config from "../../config";

/**
 * Forget Password component
 * @param {*} props 
 */
const ForgetPassword = (props) => {

    const clearError = () => {
        props.apiError("");
    }
    const [loading, setLoading] = React.useState(false);
    const { t } = useTranslation();
    const navigate = useNavigate();

    useEffect(clearError);

    // validation
    const formik = useFormik({
        initialValues: {
            email: ''
        },
        validationSchema: Yup.object({
            email: Yup.string()
                .required('Required')
        }),
        onSubmit: async (values, { setSubmitting, resetForm }) => {
            setLoading(true);
            try {
                const response = await fetch(`${config.get("API_URL")}/api/user/forgot-passwd`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json; charset=utf-8'
                    },
                    body: JSON.stringify({
                        email: values.email
                    })
                });

                const data = await response.json();

                if (response.ok) {
                    // Handle success
                    console.log('Success:', data.message);
                    // You can set a success message or state here
                    // e.g., props.passwordResetSuccess(data.message);
                    resetForm({});
                    navigate('/reset-password');
                } else {
                    // Handle errors
                    console.error('Error:', data.error);
                    // You can set an error message or state here
                    // e.g., props.apiError(data.error);
                }
            } catch (error) {
                console.error('Error:', error);
                // You can set an error message or state here
                // e.g., props.apiError(error);
            }

            setLoading(false);
            setSubmitting(false);
        },
    });

    document.title = "Forgot Password | AiRE Brokers"


    return (
        <React.Fragment>
            <div className="account-pages my-0 pt-sm-1">
                <Container>
                    <Row className="justify-content-center" style={{ "marginTop": "-7%" }}>
                        <Col md={8} lg={6} xl={5}>
                            <div className="text-center mb-1">
                                <Link to="/" className="auth-logo d-block">
                                    <img src={logodark} alt="" height="200" className="logo logo-dark"
                                        style={{ "width": "46%", "heigth": "0%" }} />
                                    <img src={logolight} alt="" height="200" className="logo logo-light"
                                        style={{ "width": "46%", "heigth": "10%" }} />
                                </Link>

                                <h4 style={{ "marginTop": "-5%" }}>{t('Reset Password')}</h4>

                            </div>

                            <Card>
                                <CardBody className="p-4">
                                    <div className="p-3">
                                        {
                                            props.error && <Alert variant="danger">{props.error}</Alert>
                                        }
                                        {
                                            props.passwordResetStatus ? <Alert variant="success"
                                                className="text-center mb-4">{props.passwordResetStatus}</Alert>
                                                : <Alert variant="success"
                                                    className="text-center mb-4">{t('Enter your Email and instructions will be sent to you')}!</Alert>
                                        }
                                        <Form onSubmit={formik.handleSubmit}>

                                            <FormGroup className="mb-4">
                                                <Label className="form-label">{t('Email')}</Label>
                                                <InputGroup className="mb-3 bg-soft-light rounded-3">
                                                    <span className="input-group-text border-light text-muted">
                                                        <i className="ri-mail-line"></i>
                                                    </span>
                                                    <Input
                                                        type="text"
                                                        id="email"
                                                        name="email"
                                                        className="form-control form-control-lg border-light bg-soft-light"
                                                        placeholder="Enter Email"
                                                        onChange={formik.handleChange}
                                                        onBlur={formik.handleBlur}
                                                        value={formik.values.email}
                                                        invalid={formik.touched.email && formik.errors.email ? true : false}
                                                    />
                                                    {formik.touched.email && formik.errors.email ? (
                                                        <FormFeedback
                                                            type="invalid">{formik.errors.email}</FormFeedback>
                                                    ) : null}
                                                </InputGroup>
                                            </FormGroup>

                                            <div className="d-grid">
                                                <Button
                                                    color="new"
                                                    block
                                                    className="waves-effect waves-light"
                                                    type="submit"
                                                >
                                                    {loading ?
                                                        <span className="spinner-border spinner-border-sm" role="status"
                                                            aria-hidden="true"></span> : t('Reset')}
                                                </Button></div>

                                        </Form>
                                    </div>
                                </CardBody>
                            </Card>

                            <div className="mt-1 text-center">
                                <p>{t('Remember It')} ? <Link to="login"
                                    className="font-weight-medium text-primary"> {t('Signin')} </Link>
                                </p>
                                <p>© {new Date().getFullYear()} {t('AiRE Brokers')}.</p>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        </React.Fragment>
    )
}


const mapStateToProps = (state) => {
    const { user, loading, error, passwordResetStatus } = state.Auth;
    return { user, loading, error, passwordResetStatus };
};

export default connect(mapStateToProps, { forgetPassword, apiError })(ForgetPassword);