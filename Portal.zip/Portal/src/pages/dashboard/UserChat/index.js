import React, { useState, useEffect, useRef } from "react";
import {
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  UncontrolledDropdown,
  Modal,
  ModalHeader,
  ModalBody,
  CardBody,
  Button,
  ModalFooter,
} from "reactstrap";
import { connect } from "react-redux";

import SimpleBar from "simplebar-react";

import withRouter from "../../../components/withRouter";

//Import Components
import UserProfileSidebar from "../../../components/UserProfileSidebar";
import SelectContact from "../../../components/SelectContact";
import UserHead from "./UserHead";
import ImageList from "./ImageList";
import ChatInput from "./ChatInput";
import FileList from "./FileList";

//actions
import { openUserSidebar, setFullUser } from "../../../redux/actions";

//Import Images
import avatar4 from "../../../assets/images/users/avatar-4.jpg";
import avatar1 from "../../../assets/images/users/avatar-1.jpg";
import chatbg from "../../../assets/images/chatBg/housebg.jpg";
import user from "../../../assets/images/chatBg/user.png";
import customerSupport from "../../../assets/images/users/customer_support.png";
//i18n
import { useTranslation } from "react-i18next";
import config from "../../../config";
import mqtt from "mqtt";
import Loader from "../../../components/loader";
import { formatDate } from "../../utils";
import SharedFileDirectory from "../shareFileDirectory/SharedFileDirectory";

function UserChat(props) {
  const ref = useRef();
  const [modal, setModal] = useState(false);
  const { t } = useTranslation();
  const [allUsers] = useState(props.recentChatList);
  const [chatMessages, setchatMessages] = useState([]);
  const [senderMsg, setSenderMsg] = useState("");
  const [allMsg, setAllMsg] = useState([]);
  const [receiverCusMsg, setRecieverCusMsg] = useState([]);
  const [shareFileNameDir, setShareFileNameDir] = useState([]);

  // websocket connect
  const MQTT_WEBSOCKET_URL = config.get("MQTT_WEBSOCKET_URL");

  const clientId = "test-client_" + Math.random().toString(16).substr(2, 8);

  useEffect(() => {
    const options = {
      username: config.get("USER_NAME"),
      password: config.get("PASSWORD"),
      clientId: clientId,
    };

    const client = mqtt.connect(MQTT_WEBSOCKET_URL, options);
    client.on("connect", () => {
      client.subscribe("user_chat/" + props.profileDetail.email);
    });

    client.on("message", (topic, message) => {
      const payload = JSON.parse(message.toString());
      console.log(payload, "############payload");
      setRecieverCusMsg([payload.message_content[0]]);
      scrolltoBottom();
    });

    client.on("error", (error) => {
      console.error(error.message);
    });
    console.log();
    return () => {
      client.end();
    };
  }, [props.profileDetail]);

  const toggle = () => setModal(!modal);

  // admin message
  const addMessage = (message, type) => {
    var messageObj = null;
    let d = new Date();
    var n = d.getSeconds();

    switch (type) {
      case "textMessage":
        messageObj = {
          message: message,
          // time: "00:" + n,
          // userType: "sender",
          // image: avatar4,
          // isFileMessage: false,
          // isImageMessage: false,
        };
        break;

      case "fileMessage":
        messageObj = {
          media_file: message,
          // size: message.size,
          // time: "00:" + n,
          // userType: "sender",
          // image: avatar4,
          // isFileMessage: true,
          // isImageMessage: false,
        };
        break;

      // case "imageMessage":
      //   var imageMessage = [{ image: message }];
      //   messageObj = {
      //     id: chatMessages.length + 1,
      //     message: "image",
      //     imageMessage: imageMessage,
      //     size: message.size,
      //     time: "00:" + n,
      //     userType: "sender",
      //     image: avatar4,
      //     isImageMessage: true,
      //     isFileMessage: false,
      //   };
      //   break;

      default:
        break;
    }

    //add message object to chat
    setchatMessages([...chatMessages, messageObj]);
    setSenderMsg(messageObj);

    // let copyallUsers = [...allUsers];
    // copyallUsers[props.active_user].messages = [...chatMessages, messageObj];
    // copyallUsers[props.active_user].isTyping = false;
    // props.setFullUser(copyallUsers);
    scrolltoBottom();
  };

  // scroll msg of chat
  function scrolltoBottom() {
    if (ref.current.el) {
      ref.current.getScrollElement().scrollTop =
        ref.current.getScrollElement().scrollHeight;
    }
  }

  // const deleteMessage = (id) => {
  //   let conversation = chatMessages;

  //   var filtered = conversation.filter(function (item) {
  //     return item.id !== id;
  //   });

  //   setchatMessages(filtered);
  // };

  // customer chat
  const handleCustomerSupportChat = async () => {
    try {
      const token = localStorage.getItem("authUser").replace(/"/g, "");
      if (!token) {
        throw new Error("No auth token found");
      }
      const requestUrl = `${config.get("API_URL")}/api/user/send-message`;
      const formData = new FormData();

      if (senderMsg.message) {
        formData.append("message", senderMsg.message);
      }
      if (senderMsg.media_file) {
        formData.append("media_file", senderMsg.media_file);
      }

      const response = await fetch(requestUrl, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Request failed");
      }
      const data = await response.json();
      scrolltoBottom();
    } catch (error) {
      console.error("Error:", error);
    }
  };

  useEffect(() => {
    if (chatMessages.length > 0) {
      handleCustomerSupportChat();
    }
  }, [chatMessages]);

  // all message of customer and admin
  const fetchData = async () => {
    try {
      const token = localStorage.getItem("authUser").replace(/"/g, "");
      const requestUrl = `${config.get("API_URL")}/api/user/check_response`;
      const response = await fetch(requestUrl, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      const result = await response.json();
      setAllMsg(result);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    fetchData();
    scrolltoBottom();
  }, []);

  useEffect(() => {
    if (receiverCusMsg && receiverCusMsg.length > 0) {
      setAllMsg((prevMessages) => {
        if (!Array.isArray(prevMessages)) {
          prevMessages = [];
        }
        return [...prevMessages, ...receiverCusMsg];
      });
      scrolltoBottom();
    }
  }, [receiverCusMsg]);

  useEffect(() => {
    const mediaFileName =
      allMsg.length > 0 && allMsg?.filter((ele) => ele.media);
    setShareFileNameDir(mediaFileName);
  }, [allMsg]);
  const mediaExists =
    shareFileNameDir[0] && shareFileNameDir[0].hasOwnProperty("media");




  return (
    <React.Fragment>
      <div className="user-chat w-100 overflow-hidden">
        <div className="d-lg-flex">
          <div
            className={
              props.userSidebar
                ? "w-70 overflow-hidden position-relative"
                : "w-100 overflow-hidden position-relative"
            }
          >
            {/* render user head */}
            <UserHead
              sellerDetails={{
                owner_name: "Customer Support",
                profile_pic: customerSupport,
              }}
              mediaExists={mediaExists}
            />
            <div className=" d-flex justify-content-between w-100">
              <div className={mediaExists ? " w-75" : "w-100"}>
                <SimpleBar
                  style={{
                    maxWidth: "100%",
                  }}
                  ref={ref}
                  className="chat-conversation p-5 p-lg-4"
                  id="messages"
                >
                  <ul className="list-unstyled mb-0">
                    {allMsg.length > 0 &&
                      allMsg?.map((chat, key) =>
                        chat.isToday && chat.isToday === true ? (
                          <li key={"dayTitle" + key}>
                            <div className="chat-day-title">
                              <span className="title">Today</span>
                            </div>
                          </li>
                        ) : (
                          // : props.recentChatList[props.active_user].isGroup ===
                          //   true ? (
                          //   <li
                          //     key={key}
                          //     className={chat.userType === "sender" ? "right" : ""}
                          //   >
                          //     <div className="conversation-list">
                          //       <div className="chat-avatar">
                          //         {chat.userType === "sender" ? (
                          //           <img src={avatar1} alt="chatvia" />
                          //         ) : props.recentChatList[props.active_user]
                          //             .profilePicture === "Null" ? (
                          //           <div className="chat-user-img align-self-center me-3">
                          //             <div className="avatar-xs">
                          //               <span className="avatar-title rounded-circle bg-primary-subtle text-dark">
                          //                 {chat.userName && chat.userName.charAt(0)}
                          //               </span>
                          //             </div>
                          //           </div>
                          //         ) : (
                          //           <img
                          //             src={
                          //               props.recentChatList[props.active_user]
                          //                 .profilePicture
                          //             }
                          //             alt="chatvia"
                          //           />
                          //         )}
                          //       </div>

                          //       <div className="user-chat-content">
                          //         <div className="ctext-wrap">
                          //           <div className="ctext-wrap-content">
                          //             {chat.message && (
                          //               <p className="mb-0">{chat.message}</p>
                          //             )}
                          //             {chat.imageMessage && (
                          //               // image list component
                          //               <ImageList images={chat.imageMessage} />
                          //             )}
                          //             {chat.fileMessage && (
                          //               //file input component
                          //               <FileList
                          //                 fileName={chat.fileMessage}
                          //                 fileSize={chat.size}
                          //               />
                          //             )}
                          //             {chat.isTyping && (
                          //               <p className="mb-0">
                          //                 typing
                          //                 <span className="animate-typing">
                          //                   <span className="dot ms-1"></span>
                          //                   <span className="dot ms-1"></span>
                          //                   <span className="dot ms-1"></span>
                          //                 </span>
                          //               </p>
                          //             )}
                          //             {!chat.isTyping && (
                          //               <p className="chat-time mb-0">
                          //                 <i className="ri-time-line align-middle"></i>{" "}
                          //                 <span className="align-middle">
                          //                   {chat.time}
                          //                 </span>
                          //               </p>
                          //             )}
                          //           </div>
                          //           {!chat.isTyping && (
                          //             <UncontrolledDropdown className="align-self-start">
                          //               <DropdownToggle
                          //                 tag="a"
                          //                 className="text-muted ms-1"
                          //               >
                          //                 <i className="ri-more-2-fill"></i>
                          //               </DropdownToggle>
                          //               <DropdownMenu>
                          //                 <DropdownItem>
                          //                   {t("Copy")}{" "}
                          //                   <i className="ri-file-copy-line float-end text-muted"></i>
                          //                 </DropdownItem>
                          //                 <DropdownItem>
                          //                   {t("Save")}{" "}
                          //                   <i className="ri-save-line float-end text-muted"></i>
                          //                 </DropdownItem>
                          //                 <DropdownItem onClick={toggle}>
                          //                   Forward{" "}
                          //                   <i className="ri-chat-forward-line float-end text-muted"></i>
                          //                 </DropdownItem>
                          //                 <DropdownItem
                          //                   onClick={() => deleteMessage(chat.id)}
                          //                 >
                          //                   Delete{" "}
                          //                   <i className="ri-delete-bin-line float-end text-muted"></i>
                          //                 </DropdownItem>
                          //               </DropdownMenu>
                          //             </UncontrolledDropdown>
                          //           )}
                          //         </div>
                          //         {
                          //           <div className="conversation-name">
                          //             {chat.userType === "sender"
                          //               ? "Patricia Smith"
                          //               : chat.userName}
                          //           </div>
                          //         }
                          //       </div>
                          //     </div>
                          //   </li>
                          // )
                          <li
                            key={key}
                            className={
                              chat.is_response === false ? "right" : ""
                            }
                          >
                            <div className="conversation-list">
                              {chatMessages[key + 1] ? (
                                chatMessages[key].is_response ===
                                chatMessages[key + 1].is_response ? (
                                  <div className="chat-avatar">
                                    <div className="blank-div"></div>
                                  </div>
                                ) : (
                                  <div className="chat-avatar">
                                    {/* {chat.is_response === true ? (
                                  <img src={avatar1} alt="chatvia" />
                                ) : props.recentChatList[props.active_user]
                                    .profilePicture === "Null" ? (
                                  <div className="chat-user-img align-self-center me-3">
                                    <div className="avatar-xs">
                                      <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
                                        {props.recentChatList[
                                          props.active_user
                                        ].name.charAt(0)}
                                      </span>
                                    </div>
                                  </div>
                                ) : (
                                  <img
                                    src={
                                      props.recentChatList[props.active_user]
                                        .profilePicture
                                    }
                                    alt="chatvia"
                                  />
                                )} */}
                                  </div>
                                )
                              ) : (
                                //profile pic
                                <div className="chat-avatar">
                                  {chat.is_response !== false ? (
                                    <img src={customerSupport} alt="chatvia" />
                                  ) : props.profileDetail?.profile_pic !==
                                    null ? (
                                    props.profileDetail?.profile_pic ? (
                                      <img
                                        src={`${config.get("API_URL")}/${
                                          props.profileDetail?.profile_pic
                                        }`}
                                        alt="profilepic"
                                      />
                                    ) : (
                                      <Loader
                                        style={{
                                          width: "20px",
                                          height: "20px",
                                          border: "3px solid  #ccd2cc",
                                        }}
                                      />
                                    )
                                  ) : (
                                    <div className="avatar-xs">
                                      <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
                                        {props.profileDetail?.email[0].toUpperCase()}
                                      </span>
                                    </div>
                                  )}
                                </div>
                              )}

                              <div className="user-chat-content">
                                <div className="ctext-wrap">
                                  <div>
                                    {chat.timestamp && (
                                      <div className=" d-flex align-items-baseline">
                                        {chat.is_response === true && (
                                          <p
                                            style={{
                                              marginBottom: "0",
                                              fontSize: "12px",
                                              fontWeight: "600",
                                              paddingLeft: "5px",
                                            }}
                                          >
                                            customer support
                                          </p>
                                        )}
                                        <p
                                          style={{
                                            marginBottom: "0",
                                            fontSize: "10px",
                                            paddingLeft: "5px",
                                          }}
                                        >
                                          {formatDate(chat.timestamp)}
                                        </p>
                                      </div>
                                    )}
                                    <div className="ctext-wrap-content">
                                      {chat.media && (
                                        <FileList
                                          fileName={chat.media}
                                          // fileSize={chat.size}
                                        />
                                      )}
                                      {chat.message && (
                                        <p className="mb-0">{chat.message}</p>
                                      )}
                                    </div>
                                    {/* {chat.isTyping && (
                                  <p className="mb-0">
                                    typing
                                    <span className="animate-typing">
                                      <span className="dot ms-1"></span>
                                      <span className="dot ms-1"></span>
                                      <span className="dot ms-1"></span>
                                    </span>
                                  </p>
                                )} */}
                                    {/* {!chat.isTyping && (
                                <p className="chat-time mb-0">
                                  <i className="ri-time-line align-middle"></i>{" "}
                                  <span className="align-middle">
                                    {chat.time}
                                  </span>
                                </p>
                              )} */}
                                  </div>
                                  {/* {!chat.isTyping && (
                              <UncontrolledDropdown className="align-self-start ms-1">
                                <DropdownToggle tag="a" className="text-muted">
                                  <i className="ri-more-2-fill"></i>
                                </DropdownToggle>
                                <DropdownMenu>
                                  <DropdownItem>
                                    {t("Copy")}{" "}
                                    <i className="ri-file-copy-line float-end text-muted"></i>
                                  </DropdownItem>
                                  <DropdownItem>
                                    {t("Save")}{" "}
                                    <i className="ri-save-line float-end text-muted"></i>
                                  </DropdownItem>
                                  <DropdownItem onClick={toggle}>
                                    Forward{" "}
                                    <i className="ri-chat-forward-line float-end text-muted"></i>
                                  </DropdownItem>
                                  <DropdownItem
                                    onClick={() => deleteMessage(chat.id)}
                                  >
                                    Delete{" "}
                                    <i className="ri-delete-bin-line float-end text-muted"></i>
                                  </DropdownItem>
                                </DropdownMenu>
                              </UncontrolledDropdown>
                            )} */}
                                </div>

                                {/* here is profile name */}
                                {/* {
                              <div className="conversation-name">
                                {chat.is_response === false
                                  ? props.profileDetail.firstName
                                  : "Customer Support"}
                              </div>
                            } */}
                              </div>
                            </div>
                          </li>
                        )
                      )}
                  </ul>
                </SimpleBar>

                {/* <Modal backdrop="static" isOpen={modal} centered toggle={toggle}>
              <ModalHeader toggle={toggle}>Forward to...</ModalHeader>
              <ModalBody>
                <CardBody className="p-2">
                  <SimpleBar style={{ maxHeight: "200px" }}>
                    <SelectContact handleCheck={() => { }} />
                  </SimpleBar>
                  <ModalFooter className="border-0">
                    <Button color="primary">Forward</Button>
                  </ModalFooter>
                </CardBody>
              </ModalBody>
            </Modal> */}

                <ChatInput onaddMessage={addMessage} />
              </div>
              {mediaExists && (
                <SharedFileDirectory shareFileNameDir={shareFileNameDir} />
              )}
              {/* <UserProfileSidebar
            activeUser={props.recentChatList[props.active_user]}
          /> */}
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

const mapStateToProps = (state) => {
  const { active_user } = state.Chat;
  const { userSidebar } = state.Layout;
  return { active_user, userSidebar };
};

export default withRouter(
  connect(mapStateToProps, { openUserSidebar, setFullUser })(UserChat)
);
