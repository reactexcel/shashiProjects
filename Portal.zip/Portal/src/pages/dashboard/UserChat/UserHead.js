import React, { useState } from "react";
import {
  Dropdown,
  DropdownMenu,
  DropdownItem,
  DropdownToggle,
  Button,
  Input,
  Row,
  Col,
  Modal,
  ModalBody,
} from "reactstrap";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

import { openUserSidebar, setFullUser } from "../../../redux/actions";

//import images
import customerSupport from "../../../assets/images/users/customer_support.png";
import config from "../../../config";

function UserHead(props) {
  // const [dropdownOpen, setDropdownOpen] = useState(false);
  // const [dropdownOpen1, setDropdownOpen1] = useState(false);
  // const [Callmodal, setCallModal] = useState(false);
  // const [Videomodal, setVideoModal] = useState(false);

  // const toggle = () => setDropdownOpen(!dropdownOpen);
  // const toggle1 = () => setDropdownOpen1(!dropdownOpen1);
  // const toggleCallModal = () => setCallModal(!Callmodal);
  // const toggleVideoModal = () => setVideoModal(!Videomodal);

  // const openUserSidebar = (e) => {
  //   e.preventDefault();
  //   props.openUserSidebar();
  // };

  // function closeUserChat(e) {
  //   e.preventDefault();
  //   var userChat = document.getElementsByClassName("user-chat");
  //   if (userChat) {
  //     userChat[0].classList.remove("user-chat-show");
  //   }
  // }

  // function deleteMessage() {
  //   let allUsers = props.users;
  //   let copyallUsers = allUsers;
  //   copyallUsers[props.active_user].messages = [];

  //   props.setFullUser(copyallUsers);
  // }

  return (
    <React.Fragment>
      <div className="px-2 py-2 pb-1 px-lg-2 pt-lg-2 pb-lg-1 border-bottom  border-2 user-chat-topbar">
        <Row className="align-items-center">
          <Col sm={12} xs={8}>
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-block d-lg-none me-2 ms-0">
                {/* <Link
                  to="#"
                  onClick={(e) => closeUserChat(e)}
                  className="user-chat-remove text-muted font-size-16 p-2"
                >
                  <i className="ri-arrow-left-s-line"></i>
                </Link> */}
              </div>
              {(props.sellerDetails &&
                props.sellerDetails.profile_pic !== null &&
                props.sellerDetails.profile_pic !== undefined) ||
              (props.sellerDetails.owner_profile !== null &&
                props.sellerDetails.owner_profile !== undefined) ? (
                <div className="me-2 ms-0">
                  {(props.sellerDetails?.profile_pic ||
                    props.sellerDetails?.owner_profile) &&
                  props.sellerDetails.owner_name === "Customer Support" ? (
                    <img
                      src={props.sellerDetails?.profile_pic}
                      className="rounded-circle avatar-xs"
                      alt="customerProfilePic"
                    />
                  ) : (
                    <img
                      src={`${config.get("API_URL")}/${
                        props.sellerDetails?.profile_pic
                          ? props.sellerDetails?.profile_pic
                          : props.sellerDetails?.owner_profile
                      }`}
                      className="rounded-circle avatar-xs"
                      alt="chatvia"
                    />
                  )}
                </div>
              ) : (
                <div className="chat-user-img align-self-center me-3">
                  <div className="avatar-xs">
                    <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
                      {props.sellerDetails &&
                        (props.sellerDetails.owner_email
                          ? props.sellerDetails.owner_email[0].toUpperCase()
                          : props.sellerDetails.email
                          ? props.sellerDetails.email[0].toUpperCase()
                          : props.sellerDetails.first_name
                          ? props.sellerDetails.first_name[0].toUpperCase()
                          : props.sellerDetails.owner_name
                          ? props.sellerDetails.owner_name[0].toUpperCase()
                          : null)}
                    </span>
                  </div>
                </div>
              )}

              <div className="flex-grow-1 overflow-hidden">
                <h5 className="font-size-16 mb-0 text-truncate">
                  {props.sellerDetails && (
                    <Link
                      to="#"
                      onClick={(e) => openUserSidebar(e)}
                      className="text-reset user-profile-show"
                    >
                      {(
                        props.sellerDetails.owner_name ||
                        (props.sellerDetails.first_name &&
                        props.sellerDetails.last_name
                          ? `${props.sellerDetails.first_name} ${props.sellerDetails.last_name}`
                          : props.sellerDetails.first_name) ||
                        props.sellerDetails.owner_email ||
                        props.sellerDetails.email
                      )
                        .charAt(0)
                        .toUpperCase() +
                        (
                          props.sellerDetails.owner_name ||
                          (props.sellerDetails.first_name &&
                          props.sellerDetails.last_name
                            ? `${props.sellerDetails.first_name} ${props.sellerDetails.last_name}`
                            : props.sellerDetails.first_name) ||
                          props.sellerDetails.owner_email ||
                          props.sellerDetails.email
                        ).slice(1)}
                    </Link>
                  )}
                  {/* {props.sellerDetails.owner_email &&
                    (() => {
                      switch (props.users[props.active_user].status) {
                        case "online":
                          return (
                            <>
                              <i
                                className="ri-record-circle-fill font-size-10  d-inline-block ms-2"
                                style={{ color: "#32eb0e" }}
                              ></i>
                            </>
                          );

                        case "away":
                          return (
                            <>
                              <i
                                className="ri-record-circle-fill font-size-10  d-inline-block ms-1"
                                style={{ color: "#de2110" }}
                              ></i>
                            </>
                          );

                        case "offline":
                          return (
                            <>
                              <i className="ri-record-circle-fill font-size-10 text-secondary d-inline-block ms-1"></i>
                            </>
                          );

                        default:
                          return;
                      }
                    })()} */}
                </h5>
                {props.sellerDetails.address ||
                  (props.sellerDetails.property_address && (
                    <p style={{ marginBottom: "0px", fontSize: "12px" }}>
                      {props.sellerDetails.address ||
                        props.sellerDetails.property_address}
                    </p>
                  ))}
              </div>
              {props.mediaExists && (
                <h5
                  className="py-2 text-center"
                  style={{ paddingRight: "80px" }}
                >
                  Directory
                </h5>
              )}
            </div>
          </Col>
          <Col sm={8} xs={4}>
            {/* <ul className="list-inline user-chat-nav text-end mb-0">

                            <li className="list-inline-item">
                                <Dropdown isOpen={dropdownOpen} toggle={toggle}>
                                    <DropdownToggle color="none" className="btn nav-btn " type="button">
                                        <i className="ri-search-line"></i>
                                    </DropdownToggle>
                                    <DropdownMenu className="p-0 dropdown-menu-end dropdown-menu-md">
                                        <div className="search-box p-2">
                                            <Input type="text" className="form-control bg-light border-0" placeholder="Search.."/>
                                        </div>
                                    </DropdownMenu>                                
                                </Dropdown>
                            </li>
                            <li className="list-inline-item d-none d-lg-inline-block me-2 ms-0">
                                <button type="button" onClick={toggleCallModal} className="btn nav-btn" >
                                    <i className="ri-phone-line"></i>
                                </button>
                            </li>
                            <li className="list-inline-item d-none d-lg-inline-block me-2 ms-0">
                                <button type="button" onClick={toggleVideoModal} className="btn nav-btn">
                                    <i className="ri-vidicon-line"></i>
                                </button>
                            </li>

                            <li className="list-inline-item d-none d-lg-inline-block me-2 ms-0">
                                <Button type="button" color="none" onClick={(e) => openUserSidebar(e)} className="nav-btn user-profile-show">
                                    <i className="ri-user-2-line"></i>
                                </Button>
                            </li>

                            <li className="list-inline-item">
                                <Dropdown isOpen={dropdownOpen1} toggle={toggle1}>
                                    <DropdownToggle className="btn nav-btn " color="none" type="button" >
                                        <i className="ri-more-fill"></i>
                                    </DropdownToggle>
                                    <DropdownMenu className="dropdown-menu-end">
                                        <DropdownItem className="d-block d-lg-none user-profile-show" onClick={(e) => openUserSidebar(e)}>View profile <i className="ri-user-2-line float-end text-muted"></i></DropdownItem>
                                        <DropdownItem>Archive <i className="ri-archive-line float-end text-muted"></i></DropdownItem>
                                        <DropdownItem>Muted <i className="ri-volume-mute-line float-end text-muted"></i></DropdownItem>
                                        <DropdownItem onClick={(e) => deleteMessage(e)}>Delete <i className="ri-delete-bin-line float-end text-muted"></i></DropdownItem>
                                    </DropdownMenu>
                                </Dropdown>
                            </li>

                        </ul> */}
          </Col>
        </Row>
      </div>

      {/* Start Audiocall Modal */}
      {/* <Modal tabIndex="-1" isOpen={Callmodal} toggle={toggleCallModal} centered>
                <ModalBody>
                    <div className="text-center p-4">
                        <div className="avatar-lg mx-auto mb-4">
                            <img src={user} alt="" className="img-thumbnail rounded-circle" />
                        </div>

                        <h5 className="text-truncate">Doris Brown</h5>
                        <p className="text-muted">Start Audio Call</p>

                        <div className="mt-5">
                            <ul className="list-inline mb-1">
                                <li className="list-inline-item px-2 me-2 ms-0">
                                    <button type="button" className="btn btn-danger avatar-sm rounded-circle" onClick={toggleCallModal}>
                                        <span className="avatar-title bg-transparent font-size-20">
                                            <i className="ri-close-fill"></i>
                                        </span>
                                    </button>
                                </li>
                                <li className="list-inline-item px-2">
                                    <button type="button" className="btn btn-success avatar-sm rounded-circle">
                                        <span className="avatar-title bg-transparent font-size-20">
                                            <i className="ri-phone-fill"></i>
                                        </span>
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </ModalBody>
            </Modal> */}

      {/* Start VideoCall Modal */}
      {/* <Modal tabIndex="-1" isOpen={Videomodal} toggle={toggleVideoModal} centered>
                <ModalBody>
                    <div className="text-center p-4">
                        <div className="avatar-lg mx-auto mb-4">
                            <img src={user} alt="" className="img-thumbnail rounded-circle" />
                        </div>

                        <h5 className="text-truncate">Doris Brown</h5>
                        <p className="text-muted">Start Video Call</p>

                        <div className="mt-5">
                            <ul className="list-inline mb-1">
                                <li className="list-inline-item px-2 me-2 ms-0">
                                    <button type="button" className="btn btn-danger avatar-sm rounded-circle" onClick={toggleVideoModal}>
                                        <span className="avatar-title bg-transparent font-size-20">
                                            <i className="ri-close-fill"></i>
                                        </span>
                                    </button>
                                </li>
                                <li className="list-inline-item px-2">
                                    <button type="button" className="btn btn-success avatar-sm rounded-circle">
                                        <span className="avatar-title bg-transparent font-size-20">
                                            <i className="ri-vidicon-fill"></i>
                                        </span>
                                    </button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </ModalBody>
            </Modal> */}
    </React.Fragment>
  );
}

const mapStateToProps = (state) => {
  const { users, active_user } = state.Chat;
  return { ...state.Layout, users, active_user };
};

export default connect(mapStateToProps, { openUserSidebar, setFullUser })(
  UserHead
);
