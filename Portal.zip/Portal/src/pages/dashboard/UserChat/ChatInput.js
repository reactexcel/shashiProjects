import React, { useEffect, useState } from "react";
import {
  Button,
  Input,
  Row,
  Col,
  UncontrolledTooltip,
  ButtonDropdown,
  DropdownToggle,
  DropdownMenu,
  Label,
  Form,
  InputGroup,
} from "reactstrap";
// import EmojiPicker from "emoji-picker-react";
import { CiSquareRemove } from "react-icons/ci";
import { pointer } from "@testing-library/user-event/dist/cjs/pointer/index.js";

function ChatInput(props) {
  const [textMessage, settextMessage] = useState("");
  // const [isOpen, setisOpen] = useState(false);
  const [file, setfile] = useState(null);
  const [mediaFileName, setMedialFileName] = useState(null);
  const [media_msg, setMedia_msg] = useState({
    message: null,
    media_file: null,
  });

  // const toggle = () => setisOpen(!isOpen);

  // const onEmojiClick = (event) => {
  //   settextMessage(textMessage + event.emoji);
  // };

  const handleChange = (e) => {
    if (e.target.type === "file") {
      const selectedFile = e.target.files[0];
      setfile(selectedFile);
      setMedia_msg((prevMediaMsg) => ({
        ...prevMediaMsg,
        media_file: selectedFile,
      }));
      setMedialFileName(selectedFile?.name);
      e.target.value = null;
    } else {
      settextMessage(e.target.value);
      setMedia_msg((prevMediaMsg) => ({
        ...prevMediaMsg,
        message: e.target.value,
      }));
    }
  };

  const onaddMessage = (e, textMessage) => {
    e.preventDefault();
    if (textMessage !== "") {
      props.onaddMessage(textMessage, "textMessage");
      settextMessage("");
    }

    if (file !== null) {
      props.onaddMessage(file, "fileMessage");
      setfile(null);
      setMedialFileName(null);
      settextMessage("");
    }
    if (media_msg.media_file && media_msg.message !== null) {
      props.onaddMessage(media_msg, "media_msg");
      setMedia_msg({ media_file: null, message: null });
      setfile(null);
      setMedialFileName(null);
      settextMessage("");
      return;
    }
  };

  const handleRemoveMediaFile = () => {
    setMedia_msg({ media_file: null, message: null });
    setMedialFileName(null);
    setfile(null);
    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = null;
    }
  };

  useEffect(() => {
    setMedialFileName(null);
    setfile(null);
    settextMessage("");
    setMedia_msg({ media_file: null, message: null });
  }, [props.sellerDetails]);

  return (
    <React.Fragment>
      {mediaFileName !== null && (
        <div
          className=" position-absolute z-3 p-1 rounded-2 d-flex gap-3"
          style={{ bottom: "80px", left: "28px", backgroundColor: "#dce0dd" }}
        >
          <p className="p-2">{mediaFileName}</p>
          <CiSquareRemove
            onClick={handleRemoveMediaFile}
            size={24}
            cursor={"pointer"}
          />
        </div>
      )}
      <div className="chat-input-section p-3 p-lg-4 border-top mb-0 position-relative ">
        <Form onSubmit={(e) => onaddMessage(e, textMessage)}>
          <Row className="g-0">
            <Col xs="auto">
              <div className="chat-input-links ms-md-2">
                <ul className="list-inline mb-0 ms-0">
                  {/* <li className="list-inline-item">
                    <ButtonDropdown
                      className="emoji-dropdown"
                      direction="up"
                      isOpen={isOpen}
                      toggle={toggle}
                    >
                      <DropdownToggle
                        id="emoji"
                        color="link"
                        className="text-decoration-none font-size-16 btn-lg waves-effect"
                      >
                        <i className="ri-emotion-happy-line"></i>
                      </DropdownToggle>
                      <DropdownMenu className="dropdown-menu-end">
                        <EmojiPicker onEmojiClick={onEmojiClick} />
                      </DropdownMenu>
                    </ButtonDropdown>
                    <UncontrolledTooltip target="emoji" placement="top">
                      Emoji
                    </UncontrolledTooltip>
                  </li> */}
                  <li className="list-inline-item input-file">
                    <Label
                      id="files"
                      className="btn btn-link text-decoration-none font-size-20 btn-lg waves-effect"
                    >
                      <svg
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M11.9702 12.5V16C11.9702 17.93 13.5402 19.5 15.4702 19.5C17.4002 19.5 18.9702 17.93 18.9702 16V10.5C18.9702 6.63 15.8402 3.5 11.9702 3.5C8.10022 3.5 4.97021 6.63 4.97021 10.5V16.5C4.97021 19.81 7.66022 22.5 10.9702 22.5"
                          stroke="#001659"
                          stroke-width="1.5"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>

                      <Input
                        onChange={(e) => handleChange(e)}
                        type="file"
                        name="fileInput"
                        size="60"
                      />
                    </Label>
                    <UncontrolledTooltip target="files" placement="top">
                      Attached File
                    </UncontrolledTooltip>
                  </li>
                  {/* <li className="list-inline-item">
                    <Button
                      type="submit"
                      className="waves-effect waves-light"
                    >
                      <svg
                        width="24"
                        height="25"
                        viewBox="0 0 24 25"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M16.1401 3.46004L7.11012 6.46004C1.04012 8.49004 1.04012 11.8 7.11012 13.82L9.79012 14.71L10.6801 17.39C12.7001 23.46 16.0201 23.46 18.0401 17.39L21.0501 8.37004C22.3901 4.32004 20.1901 2.11004 16.1401 3.46004ZM16.4601 8.84004L12.6601 12.66C12.5101 12.81 12.3201 12.88 12.1301 12.88C11.9401 12.88 11.7501 12.81 11.6001 12.66C11.4606 12.5189 11.3824 12.3285 11.3824 12.13C11.3824 11.9316 11.4606 11.7412 11.6001 11.6L15.4001 7.78004C15.6901 7.49004 16.1701 7.49004 16.4601 7.78004C16.7501 8.07004 16.7501 8.55004 16.4601 8.84004Z"
                          fill="#001659"
                        />
                      </svg>
                    </Button>
                  </li> */}
                </ul>
              </div>
            </Col>
            <Col>
              <div
                style={{ border: "2px solid #E2E8F0" }}
                className=" rounded-4"
              >
                <InputGroup>
                  <Input
                    type="text"
                    value={textMessage}
                    onChange={handleChange}
                    className="form-control form-control-lg bg-white border-white rounded-4"
                    placeholder="Type a message..."
                  />
                  <Button
                    type="submit"
                    className="waves-effect waves-light bg-white rounded-4"
                  >
                    <svg
                      width="24"
                      height="25"
                      viewBox="0 0 24 25"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M16.1401 3.46004L7.11012 6.46004C1.04012 8.49004 1.04012 11.8 7.11012 13.82L9.79012 14.71L10.6801 17.39C12.7001 23.46 16.0201 23.46 18.0401 17.39L21.0501 8.37004C22.3901 4.32004 20.1901 2.11004 16.1401 3.46004ZM16.4601 8.84004L12.6601 12.66C12.5101 12.81 12.3201 12.88 12.1301 12.88C11.9401 12.88 11.7501 12.81 11.6001 12.66C11.4606 12.5189 11.3824 12.3285 11.3824 12.13C11.3824 11.9316 11.4606 11.7412 11.6001 11.6L15.4001 7.78004C15.6901 7.49004 16.1701 7.49004 16.4601 7.78004C16.7501 8.07004 16.7501 8.55004 16.4601 8.84004Z"
                        fill="#001659"
                      />
                    </svg>
                  </Button>
                </InputGroup>
              </div>
            </Col>
          </Row>
        </Form>
      </div>
    </React.Fragment>
  );
}

export default ChatInput;
