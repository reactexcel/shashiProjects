// import React from "react";
// import { Card } from "reactstrap";
// import { Link } from "react-router-dom";
// import config from "../../../config";
// import pdfImg from "../../../assets/images/chatBg/pdf.png";
// import docImg from "../../../assets/images/chatBg/docx.jpg";
// import pptxImg from "../../../assets/images/chatBg/pptx.jpg";
// import txtImg from "../../../assets/images/chatBg/txt.png";
// import xlsxImg from "../../../assets/images/chatBg/xlsx.png";
// import csvImg from "../../../assets/images/chatBg/csv.png";

// const FileList = (props) => {

//   const getFileType = (fileName) => {
//     const extension = fileName.split(".").pop().toLowerCase();
//     if (extension === "pdf") {
//       return "pdf";
//     } else if (["png", "jpg", "jpeg"].includes(extension)) {
//       return "image";
//     } else if (["docx", "doc"].includes(extension)) {
//       return "docx";
//     } else if (["xls", "xlsx"].includes(extension)) {
//       return "xlsx";
//     } else if (["ppt", "pptx"].includes(extension)) {
//       return "pptx";
//     } else if (["txt"].includes(extension)) {
//       return "txt";
//     } else if (["csv"].includes(extension)) {
//       return "csv";
//     } else {
//       return "unknown";
//     }
//   };

//   const renderFile = (fileType) => {
//     switch (fileType) {
//       case "pdf":
//         return (
//           <img src={pdfImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "docx":
//         return (
//           <img src={docImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "xlsx":
//         return (
//           <img src={xlsxImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "pptx":
//         return (
//           <img src={pptxImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "txt":
//         return (
//           <img src={txtImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "csv":
//         return (
//           <img src={csvImg} alt="file" width={150} className="rounded-3" />
//         );
//       case "image":
//         return (
//           <img
//             src={`${config.get("API_URL")}/${props.fileName}`}
//             alt="file"
//             width={150}
//             className="rounded-3"
//           />
//         );

//       default:
//         return <p>Unknown file</p>;
//     }
//   };

//   const download = async (fileName) => {
//     try {
//       const response = await fetch(`${config.get("API_URL")}${fileName}`);
//       const blob = await response.blob();
//       const url = window.URL.createObjectURL(blob);
//       const link = document.createElement("a");
//       link.href = url;
//       link.setAttribute("download", fileName);
//       document.body.appendChild(link);
//       link.click();
//       link.remove();
//     } catch (error) {
//       console.error("Error downloading file:", error);
//     }
//   };

//   const fileType = getFileType(props.fileName);
//   let fileNameWithExtension = props.fileName
//     .split("/")
//     .pop()
//     .split("_")
//     .slice(2)
//     .join("_");

//   // Extracting extension from the filename
//   const extension = fileNameWithExtension.split(".").pop();
//   if (fileNameWithExtension.length > 20) {
//     fileNameWithExtension =
//       fileNameWithExtension.substring(0, 20) + "..." + "." + extension;
//   }

//   console.log(props.fileNameWithExtension,"%%%%%%%%%%file");
//   console.log(props.fileName,"%%%%%%%%%%nameeeeeeeee");

//   return (
//     <React.Fragment>
//       <Card className="p-2 mb-2">
//         <div className="d-flex align-items-center">
//           <div>{renderFile(fileType)}</div>
//           <div className="ms-4">
//             <ul className="list-inline mb-0 font-size-24">
//               <li className="list-inline-item">
//                 <Link
//                   to="#"
//                   className="text-muted"
//                   onClick={() => download(props.fileName)}
//                 >
//                   <i className="ri-download-2-line"></i>
//                 </Link>
//               </li>
//             </ul>
//           </div>
//         </div>
//         <p className=" pb-0 mb-0 py-1 text-start" style={{ fontSize: "12px" }}>
//           {fileNameWithExtension}
//         </p>
//       </Card>
//     </React.Fragment>
//   );
// };

// export default FileList;
import React from "react";
import { Card } from "reactstrap";
import { Link } from "react-router-dom";
import config from "../../../config";
import pdfImg from "../../../assets/images/chatBg/pdf.png";
import docxImg from "../../../assets/images/chatBg/docx.jpg";
import pptxImg from "../../../assets/images/chatBg/pptx.jpg";
import txtImg from "../../../assets/images/chatBg/txt.png";
import xlsxImg from "../../../assets/images/chatBg/xlsx.png";
import csvImg from "../../../assets/images/chatBg/csv.png";
import { download } from "../../utils";

const FileList = ({ fileName }) => {
  const getFileType = (fileName) => fileName.split(".").pop().toLowerCase();
  const fileType = getFileType(fileName);
  const extension = fileName.split(".").pop();

  const getFileImage = (fileType) => {
    switch (fileType) {
      case "pdf":
        return pdfImg;
      case "docx":
        return docxImg;
      case "pptx":
        return pptxImg;
      case "txt":
        return txtImg;
      case "xlsx":
        return xlsxImg;
      case "csv":
        return csvImg;
      default:
        return null;
    }
  };

  const docExtensions = ["pdf", "docx", "pptx", "txt", "xlsx", "csv"];
  const imgExtensions = ["jpg", "png", "jpeg"];
  const renderFile = docExtensions.includes(fileType) ? (
    <img
      src={getFileImage(fileType)}
      alt="file"
      width={150}
      className="rounded-3"
    />
  ) : imgExtensions.includes(fileType) ? (
    <img
      src={`${config.get("API_URL")}/${fileName}`}
      alt="file"
      width={150}
      className="rounded-3"
    />
  ) : (
    <p>Unknown file</p>
  );

 

  const fileNameWithExtension =
    fileName.split("/").pop().split("_").slice(1).join("_").substring(0, 20) +
    (fileName.length > 20 ? "..." : "") +
    "." +
    extension;

  return (
    <Card className="p-2 mb-2">
      <div className="d-flex align-items-center">
        <div>{renderFile}</div>
        <div className="ms-4">
          <ul className="list-inline mb-0 font-size-24">
            <li className="list-inline-item">
              <Link
                to="#"
                className="text-muted"
                onClick={() => download(fileName)}
              >
                <i className="ri-download-2-line"></i>
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <p className="pb-0 mb-0 py-1 text-start" style={{ fontSize: "12px" }}>
        {fileNameWithExtension}
      </p>
    </Card>
  );
};

export default FileList;
