import React from "react";
import { connect } from "react-redux";

import { TabContent, TabPane } from "reactstrap";

//Import Components
import Profile from "./Tabs/Profile";
import Chats from "./Tabs/Chats";
import Groups from "./Tabs/Groups";
// import Contacts from "./Tabs/Contacts";
import Settings from "./Tabs/Settings";
import Properties from "../Properties/properties";

function ChatLeftSidebar(props) {
  const activeTab = props.activeTab;
  return (
    <React.Fragment>
      <div className="chat-leftsidebar me-lg-1">
        <TabContent activeTab={activeTab}>
          {/* Start ProfileMain tab-pane */}
          <TabPane tabId="properties" id="pills">
            profile content
            <Properties />
          </TabPane>
          {/* Start chats tab-pane  */}
          <TabPane tabId="chat" id="pills-chat">
            {/* chats content */}
            <Chats
              recentChatUserList={props.recentChatUserList}
              recentCustomerChatUserList={props.recentCustomerChatUserList}
              sellerDetails={props.sellerDetails}
              openUserChat={props.openUserChat}
            />
          </TabPane>
          {/* Start settings tab-pane */}
          <TabPane tabId="settings" id="pills-setting">
            {/* Settings content */}
            <Settings />
          </TabPane>
          {/* End settings tab-pane */}
        </TabContent>
        {/* end tab content */}
      </div>
    </React.Fragment>
  );
}

const mapStatetoProps = (state) => {
  return {
    ...state.Layout,
  };
};

export default connect(mapStatetoProps, null)(ChatLeftSidebar);
