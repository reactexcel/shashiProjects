// import React, { Component } from "react";
// import { Input, InputGroup } from "reactstrap";
// import { Link } from "react-router-dom";
// import { connect } from "react-redux";

// //simplebar
// import SimpleBar from "simplebar-react";

// //actions
// import {
//   setconversationNameInOpenChat,
//   activeUser,
// } from "../../../redux/actions";

// //components
// import OnlineUsers from "./OnlineUsers";

// class Chats extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       searchChat: "",
//       recentChatList: this.props.recentChatList,
//     };
//     this.openUserChat = this.openUserChat.bind(this);
//     this.handleChange = this.handleChange.bind(this);
//   }

//   componentDidMount() {
//     var li = document.getElementById("conversation" + this.props.active_user);
//     if (li) {
//       li.classList.add("active");
//     }
//   }

//   componentDidUpdate(prevProps) {
//     if (prevProps !== this.props) {
//       this.setState({
//         recentChatList: this.props.recentChatList,
//       });
//     }
//   }

//   UNSAFE_componentWillReceiveProps(nextProps) {
//     if (this.props.recentChatList !== nextProps.recentChatList) {
//       this.setState({
//         recentChatList: nextProps.recentChatList,
//       });
//     }
//   }

//   handleChange(e) {
//     this.setState({ searchChat: e.target.value });
//     var search = e.target.value;
//     let conversation = this.state.recentChatList;
//     let filteredArray = [];

//     //find conversation name from array
//     for (let i = 0; i < conversation.length; i++) {
//       if (
//         conversation[i].name.toLowerCase().includes(search) ||
//         conversation[i].name.toUpperCase().includes(search)
//       )
//         filteredArray.push(conversation[i]);
//     }

//     //set filtered items to state
//     this.setState({ recentChatList: filteredArray });

//     //if input value is blanck then assign whole recent chatlist to array
//     if (search === "")
//       this.setState({ recentChatList: this.props.recentChatList });
//   }

//   openUserChat(e, chat) {
//     e.preventDefault();

//     //find index of current chat in array
//     var index = this.props.recentChatList.indexOf(chat);

//     // set activeUser
//     this.props.activeUser(index);

//     var chatList = document.getElementById("chat-list");
//     var clickedItem = e.target;
//     var currentli = null;

//     if (chatList) {
//       var li = chatList.getElementsByTagName("li");
//       //remove coversation user
//       for (var i = 0; i < li.length; ++i) {
//         if (li[i].classList.contains("active")) {
//           li[i].classList.remove("active");
//         }
//       }
//       //find clicked coversation user
//       for (var k = 0; k < li.length; ++k) {
//         if (li[k].contains(clickedItem)) {
//           currentli = li[k];
//           break;
//         }
//       }
//     }

//     //activation of clicked coversation user
//     if (currentli) {
//       currentli.classList.add("active");
//     }

//     var userChat = document.getElementsByClassName("user-chat");
//     if (userChat) {
//       userChat[0].classList.add("user-chat-show");
//     }

//     //removes unread badge if user clicks
//     var unread = document.getElementById("unRead" + chat.id);
//     if (unread) {
//       unread.style.display = "none";
//     }
//   }

//   render() {
//     const{sellerDetails}=this.props
//     return (
//       <React.Fragment>
//         <div>
//           <div className="px-4 pt-4">
//             <h4 className="mb-4">Chats</h4>
//             <div className="search-box chat-search-box">
//               <InputGroup className="mb-3 rounded-3">
//                 <span
//                   className="input-group-text text-muted bg-light pe-1 ps-3"
//                   id="basic-addon1"
//                 >
//                   <i className="ri-search-line search-icon font-size-18"></i>
//                 </span>
//                 <Input
//                   type="text"
//                   value={this.state.searchChat}
//                   onChange={(e) => this.handleChange(e)}
//                   className="form-control bg-light"
//                   placeholder="Search messages or users"
//                 />
//               </InputGroup>
//             </div>
//             {/* Search Box */}
//           </div>

//           {/* online users */}
//           <OnlineUsers />

//           {/* Start chat-message-list  */}
//           <div>
//             {/* <button>customer support</button>    */}
//             <h5 className="mb-3 px-3 font-size-16">Recent</h5>
//             <SimpleBar className="chat-message-list">
//               <ul
//                 className="list-unstyled chat-list chat-user-list px-2"
//                 id="chat-list"
//               >
//                 {this.state.recentChatList.map((chat, key) => (
//                   <li
//                     key={key}
//                     id={"conversation" + key}
//                     // className={
//                     //   chat.unRead
//                     //     ? "unread"
//                     //     : chat.isTyping
//                     //     ? "typing"
//                     //     : key === this.props.active_user
//                     //     ? "active"
//                     //     : ""
//                     // }
//                   >
//                     <Link to="#" onClick={(e) => this.openUserChat(e, chat)}>
//                       <div className="d-flex">
//                         {chat.profilePicture === "Null" ? (
//                           <div
//                             // className={
//                             //   "chat-user-img " +
//                             //   chat.status +
//                             //   " align-self-center ms-0"
//                             // }
//                           >
//                             <div className="avatar-xs">
//                               <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
//                                 {chat.name.charAt(0)}
//                               </span>
//                             </div>
//                             {/* {chat.status && (
//                               <span className="user-status"></span>
//                             )} */}
//                           </div>
//                         ) : (
//                           <div
//                             // className={
//                             //   "chat-user-img " +
//                             //   chat.status +
//                             //   " align-self-center ms-0"
//                             // }
//                           >

//                             <img
//                               src={chat.profilePicture}
//                               className="rounded-circle avatar-xs"
//                               alt="chatvia"
//                             />

//                             {/* {chat.status && (
//                               <span className="user-status"></span>
//                             )} */}
//                           </div>
//                         )}

//                         <div className="flex-grow-1 overflow-hidden">
//                           <h5 className="text-truncate font-size-15 mb-1 ms-3">
//                             {chat.name}
//                           </h5>
//                           <p className="chat-user-message font-size-14 text-truncate mb-0 ms-3">
//                             {/* {chat.isTyping ? (
//                               <>
//                                 typing
//                                 <span className="animate-typing">
//                                   <span className="dot ms-1"></span>
//                                   <span className="dot ms-1"></span>
//                                   <span className="dot ms-1"></span>
//                                 </span>
//                               </>
//                             ) : (
//                               <>
//                                 {chat.messages &&
//                                 chat.messages.length > 0 &&
//                                 chat.messages[chat.messages.length - 1]
//                                   .isImageMessage === true ? (
//                                   <i className="ri-image-fill align-middle me-1"></i>
//                                 ) : null}
//                                 {chat.messages &&
//                                 chat.messages.length > 0 &&
//                                 chat.messages[chat.messages.length - 1]
//                                   .isFileMessage === true ? (
//                                   <i className="ri-file-text-fill align-middle me-1"></i>
//                                 ) : null}
//                                 {chat.messages && chat.messages.length > 0
//                                   ? chat.messages[chat.messages.length - 1]
//                                       .message
//                                   : null}
//                               </>
//                             )} */}
//                           </p>
//                         </div>
//                         <div className="font-size-11">
//                           {/* {chat.messages && chat.messages.length > 0
//                             ? chat.messages[chat.messages.length - 1].time
//                             : null} */}
//                         </div>
//                         {chat.unRead === 0 ? null : (
//                           <div
//                             className="unread-message"
//                             id={"unRead" + chat.id}
//                           >
//                             <span className="badge badge-soft-danger rounded-pill">
//                               {/* {chat.messages && chat.messages.length > 0
//                                 ? chat.unRead >= 20
//                                   ? chat.unRead + "+"
//                                   : chat.unRead
//                                 : ""} */}
//                             </span>
//                           </div>
//                         )}
//                       </div>
//                     </Link>
//                   </li>
//                 ))}
//               </ul>
//             </SimpleBar>
//           </div>
//           {/* End chat-message-list */}
//         </div>
//       </React.Fragment>
//     );
//   }
// }

// const mapStateToProps = (state) => {
//   const { active_user } = state.Chat;
//   return { active_user };
// };

// export default connect(mapStateToProps, {
//   setconversationNameInOpenChat,
//   activeUser,
// })(Chats);

// import React, { useState, useEffect } from "react";
// import { Input, InputGroup } from "reactstrap";
// import { Link } from "react-router-dom";
// import { useSelector, useDispatch } from "react-redux";

// // simplebar
// import SimpleBar from "simplebar-react";

// // actions
// import {
//   setconversationNameInOpenChat,
//   activeUser,
// } from "../../../redux/actions";

// // components
// import OnlineUsers from "./OnlineUsers";

// const Chats = () => {
//   const [searchChat, setSearchChat] = useState("");
//   const recentChatList = useSelector((state) => state.Chat.recentChatList);
//   console.log(recentChatList,"%%%%%%%%%%%%%%%%%&&&&&&&&&&&");
//   const active_user = useSelector((state) => state.Chat.active_user);
//   const dispatch = useDispatch();

//   useEffect(() => {
//     const li = document.getElementById("conversation" + active_user);
//     if (li) {
//       li.classList.add("active");
//     }
//   }, [active_user]);

//   const handleChange = (e) => {
//     setSearchChat(e.target.value);
//     const search = e.target.value.toLowerCase();
//     const filteredArray = recentChatList.filter(
//       (chat) =>
//         chat.name.toLowerCase().includes(search) ||
//         chat.name.toUpperCase().includes(search)
//     );
//     dispatch(setconversationNameInOpenChat(filteredArray));
//   };

//   const openUserChat = (e, chat) => {
//     e.preventDefault();
//     const index = recentChatList.indexOf(chat);
//     dispatch(activeUser(index));

//     const chatList = document.getElementById("chat-list");
//     const clickedItem = e.target;
//     let currentli = null;

//     if (chatList) {
//       const li = chatList.getElementsByTagName("li");
//       for (let i = 0; i < li.length; ++i) {
//         if (li[i].classList.contains("active")) {
//           li[i].classList.remove("active");
//         }
//       }
//       for (let k = 0; k < li.length; ++k) {
//         if (li[k].contains(clickedItem)) {
//           currentli = li[k];
//           break;
//         }
//       }
//     }

//     if (currentli) {
//       currentli.classList.add("active");
//     }

//     const userChat = document.getElementsByClassName("user-chat");
//     if (userChat) {
//       userChat[0].classList.add("user-chat-show");
//     }

//     const unread = document.getElementById("unRead" + chat.id);
//     if (unread) {
//       unread.style.display = "none";
//     }
//   };

//   return (
//     <React.Fragment>
//       <div>
//         <div className="px-4 pt-4">
//           <h4 className="mb-4">Chats</h4>
//           <div className="search-box chat-search-box">
//             <InputGroup className="mb-3 rounded-3">
//               <span
//                 className="input-group-text text-muted bg-light pe-1 ps-3"
//                 id="basic-addon1"
//               >
//                 <i className="ri-search-line search-icon font-size-18"></i>
//               </span>
//               <Input
//                 type="text"
//                 value={searchChat}
//                 onChange={handleChange}
//                 className="form-control bg-light"
//                 placeholder="Search messages or users"
//               />
//             </InputGroup>
//           </div>
//         </div>

//         <OnlineUsers />

//         <div>
//           <h5 className="mb-3 px-3 font-size-16">Recent</h5>

//           <SimpleBar className="chat-message-list">
//             <ul
//               className="list-unstyled chat-list chat-user-list px-2"
//               id="chat-list"
//             >
//               {recentChatList?.map((chat, key) => (
//                 <li
//                   key={key}
//                   id={"conversation" + key}
//                   className={
//                     chat.unRead
//                       ? "unread"
//                       : chat.isTyping
//                       ? "typing"
//                       : key === active_user
//                       ? "active"
//                       : ""
//                   }
//                 >
//                   <Link to="#" onClick={(e) => openUserChat(e, chat)}>
//                     <div className="d-flex">
//                       {chat.profilePicture === "Null" ? (
//                         <div
//                           className={
//                             "chat-user-img " +
//                             chat.status +
//                             " align-self-center ms-0"
//                           }
//                         >
//                           <div className="avatar-xs">
//                             <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
//                               {chat.name.charAt(0)}
//                             </span>
//                           </div>
//                           {chat.status && <span className="user-status"></span>}
//                         </div>
//                       ) : (
//                         <div
//                           className={
//                             "chat-user-img " +
//                             chat.status +
//                             " align-self-center ms-0"
//                           }
//                         >
//                           <img
//                             src={chat.profilePicture}
//                             className="rounded-circle avatar-xs"
//                             alt="chatvia"
//                           />
//                           {chat.status && <span className="user-status"></span>}
//                         </div>
//                       )}
//                       <div className="flex-grow-1 overflow-hidden">
//                         <h5 className="text-truncate font-size-15 mb-1 ms-3">
//                           {chat.name}
//                         </h5>
//                         <p className="chat-user-message font-size-14 text-truncate mb-0 ms-3">
//                           {chat.isTyping ? (
//                             <>
//                               typing
//                               <span className="animate-typing">
//                                 <span className="dot ms-1"></span>
//                                 <span className="dot ms-1"></span>
//                                 <span className="dot ms-1"></span>
//                               </span>
//                             </>
//                           ) : (
//                             <>
//                               {chat.messages &&
//                               chat.messages.length > 0 &&
//                               chat.messages[chat.messages.length - 1]
//                                 .isImageMessage === true ? (
//                                 <i className="ri-image-fill align-middle me-1"></i>
//                               ) : null}
//                               {chat.messages &&
//                               chat.messages.length > 0 &&
//                               chat.messages[chat.messages.length - 1]
//                                 .isFileMessage === true ? (
//                                 <i className="ri-file-text-fill align-middle me-1"></i>
//                               ) : null}
//                               {chat.messages && chat.messages.length > 0
//                                 ? chat.messages[chat.messages.length - 1]
//                                     .message
//                                 : null}
//                             </>
//                           )}
//                         </p>
//                       </div>
//                       <div className="font-size-11">
//                         {chat.messages && chat.messages.length > 0
//                           ? chat.messages[chat.messages.length - 1].time
//                           : null}
//                       </div>
//                       {chat.unRead === 0 ? null : (
//                         <div className="unread-message" id={"unRead" + chat.id}>
//                           <span className="badge badge-soft-danger rounded-pill">
//                             {chat.messages && chat.messages.length > 0
//                               ? chat.unRead >= 20
//                                 ? chat.unRead + "+"
//                                 : chat.unRead
//                               : ""}
//                           </span>
//                         </div>
//                       )}
//                     </div>
//                   </Link>
//                 </li>
//               ))}
//             </ul>
//           </SimpleBar>
//           <button>customer support</button>
//         </div>
//       </div>
//     </React.Fragment>
//   );
// };

// export default Chats;

import React, { useState, useEffect } from "react";
import { Input, InputGroup } from "reactstrap";
import { Link, useLocation } from "react-router-dom";
import { connect } from "react-redux";
import SimpleBar from "simplebar-react";
import {
  setconversationNameInOpenChat,
  activeUser,
} from "../../../redux/actions";
import OnlineUsers from "./OnlineUsers";
import avatar1 from "../../../assets/images/users/avatar-1.jpg";
import user from "../../../assets/images/chatBg/user.png";
import { RiCustomerService2Fill } from "react-icons/ri";
import config from "../../../config";

const Chats = ({
  openUserChat,
  recentChatUserList,
  sellerDetails,
  recentCustomerChatUserList,
}) => {
  const [searchChat, setSearchChat] = useState("");
  const [filteredChatList, setFilteredChatList] = useState([]);
  const [customerChatList, setCustomerChatList] = useState([]);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [unreadmessageCount, setUnreadMessageCount] = useState(null);

  useEffect(() => {
    setFilteredChatList(recentChatUserList);
    setCustomerChatList(recentCustomerChatUserList);
    const msgno = localStorage.getItem("msgCount");
    setUnreadMessageCount(msgno);
  }, [recentChatUserList, recentCustomerChatUserList]);

  const handleChange = (e) => {
    setSearchChat(e.target.value);
    const search = e.target.value.toLowerCase();
    const filteredArray = recentChatUserList.filter((conversation) =>
      conversation.first_name.toLowerCase().includes(search)
    );
    setFilteredChatList(filteredArray);
    const filteredCustomerArray = recentCustomerChatUserList.filter(
      (conversation) => conversation.owner_name.toLowerCase().includes(search)
    );
    setCustomerChatList(filteredCustomerArray);

    if (search === "") {
      setFilteredChatList(recentChatUserList);
      setCustomerChatList(recentCustomerChatUserList);
    }
  };

  const handleChatItemClick = (e, chat) => {
    if (chat === "customerSupport") {
      setActiveIndex(-1);
      openUserChat(e, "customerSupport");
    } else {
      setActiveIndex({ user_id: chat.user_id, property_id: chat.property_id });
      openUserChat(e, chat);
    }
  };

  return (
    <>
      <div style={{ overflow: "auto" }}>
        <div className=" ml-4 px-3">
          <h5 className="py-4">Chats</h5>
          {/* {unreadmessageCount !== null && (
            <h5 className="text-black text-center d-flex gap-1 justify-content-center align-items-center mb-0 py-3">
              Messages
              <span
                style={{
                  borderRadius: "50%",
                  width: "19px",
                  height: "19px",
                  backgroundColor: "#FF0000",
                  fontSize: "14px",
                  color: "#fff",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                {unreadmessageCount}
              </span>
            </h5>
          )} */}
          <div className="search-box chat-search-box mt-3">
            <InputGroup className="mb-3 rounded-3">
              <span
                className="input-group-text text-muted pe-1 ps-3 py-0"
                style={{ backgroundColor: "#f3f3f3" }}
                id="basic-addon1"
              >
                <i className="ri-search-line search-icon font-size-18"></i>
              </span>
              <Input
                type="text"
                value={searchChat}
                onChange={handleChange}
                className="form-control"
                style={{ backgroundColor: "#f3f3f3" }}
                placeholder="Search messages or users"
              />
            </InputGroup>
          </div>
        </div>
        {/* <OnlineUsers /> */}
        <div>
          <div className=" d-flex justify-content-between px-4">
            <h5 className="mb-3  font-size-16">Recent</h5>
            <span
              style={{ cursor: "pointer" }}
              onClick={(e) => handleChatItemClick(e, "customerSupport")}
            >
              customer support <RiCustomerService2Fill size={28} />
            </span>
          </div>
          <SimpleBar className="chat-message-list">
            <ul
              className="list-unstyled chat-list chat-user-list mx-3"
              id="chat-list"
            >
              {filteredChatList.length > 0 &&
                filteredChatList.map((chat, index) => {
                  return (
                    <li
                      key={index}
                      onClick={(e) => handleChatItemClick(e, chat)}
                      className={
                        chat.user_id === activeIndex.user_id &&
                        chat.property_id === activeIndex.property_id
                          ? "active"
                          : ""
                      }
                      style={{ marginBottom: "6px" }}
                    >
                      <Link to="#" className="d-flex align-items-center">
                        {chat.profile_pic === null ? (
                          <div>
                            <div className="avatar-xs">
                              <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
                                {chat.owner_email
                                  ? chat?.owner_email[0].toUpperCase()
                                  : chat?.email[0].toUpperCase()}
                              </span>
                            </div>
                          </div>
                        ) : (
                          <div>
                            <img
                              src={`${config.get("API_URL")}/${
                                chat.profile_pic
                              }`}
                              className="rounded-circle avatar-xs"
                              alt="chatvia"
                            />
                          </div>
                        )}
                        <div className="flex-grow-1 overflow-hidden">
                          {chat.first_name && (
                            <div className=" d-flex gap-2">
                              <p className="text-truncate text-black font-size-15 mb-0 ms-3 text-capitalize fw-bold">
                                {chat.first_name}
                              </p>
                              <p className="text-truncate text-black font-size-15 mb-0  text-capitalize fw-bold">
                                {chat.last_name}
                              </p>
                            </div>
                          )}
                          <h5 className="text-truncate font-size-15 mb-1 ms-3 text-secondary">
                            {chat.owner_email ? chat.owner_email : chat.email}
                          </h5>
                          <p className="text-truncate font-size-12 mb-1 ms-3 text-secondary">
                            {chat.property_address}
                          </p>
                          {/* <p className="chat-user-message font-size-14 text-truncate mb-0 ms-3"></p> */}
                        </div>
                        <div className="font-size-11"></div>
                        {/* {chat.unRead === 0 ? null : (
                          <div
                            className="unread-message"
                            id={"unRead" + chat.id}
                          >
                            <span className="badge badge-soft-danger rounded-pill"></span>
                          </div>
                        )} */}
                      </Link>
                    </li>
                  );
                })}
              {/* {customerChatList.length > 0 && <hr />} */}
              {customerChatList.length > 0 &&
                customerChatList.map((chat, index) => {
                  return (
                    <li
                      key={index}
                      onClick={(e) => handleChatItemClick(e, chat)}
                      style={{ marginBottom: "6px" }}
                      className={
                        chat.property_id === activeIndex.property_id
                          ? "active"
                          : ""
                      }
                    >
                      <Link to="#" className="d-flex align-items-center">
                        <div>
                          <div className="avatar-xs">
                            <span className="avatar-title rounded-circle bg-primary-subtle text-primary">
                              {chat.owner_email
                                ? chat?.owner_email[0].toUpperCase()
                                : chat.owner_name
                                ? chat.owner_name[0].toUpperCase()
                                : chat?.email
                                ? chat?.email[0].toUpperCase()
                                : null}
                            </span>
                          </div>
                        </div>
                        <div className="flex-grow-1 overflow-hidden">
                          {chat.owner_name && (
                            <div className=" d-flex gap-2">
                              <p className="text-truncate text-black font-size-15 mb-0 ms-3 text-capitalize fw-bold">
                                {chat.owner_name}
                              </p>
                            </div>
                          )}
                          <p className="text-truncate font-size-12 mb-1 ms-3 text-secondary">
                            {chat.property_id}
                          </p>
                          <p className="text-truncate font-size-12 mb-1 ms-3 text-secondary">
                            {chat.property_address}
                          </p>
                        </div>
                        <div className="font-size-11"></div>
                      </Link>
                    </li>
                  );
                })}
            </ul>
          </SimpleBar>
        </div>
      </div>
    </>
  );
};

const mapStateToProps = (state) => {
  const { active_user } = state.Chat;
  return { active_user };
};

export default connect(mapStateToProps, {
  setconversationNameInOpenChat,
  activeUser,
})(Chats);
