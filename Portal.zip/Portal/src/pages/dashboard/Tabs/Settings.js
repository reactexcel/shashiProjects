import React, { useEffect, useState } from 'react';
import { Dropdown, DropdownMenu, DropdownItem, DropdownToggle, Card, Button, Input } from "reactstrap";

import SimpleBar from "simplebar-react";

//Import components
import CustomCollapse from "../../../components/CustomCollapse";

//Import Images
import avatar1 from "../../../assets/images/users/avatar-1.jpg";

//i18n
import { useTranslation } from 'react-i18next';
import config from "../../../config";

function Settings() {
    const [loading, setLoading] = useState(false);
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [message, setMessage] = useState('');
    const [initialData, setInitialData] = useState({});
    const toggle = () => setDropdownOpen(!dropdownOpen);
    const accessToken = localStorage.getItem("authUser");
    const [profileImageUrl, setProfileImageUrl] = useState(null);
    const [profileImage, setProfileImage] = useState(null);
    const [userData, setUserData] = useState({
        first_name: "",
        last_name: "",
        phone: "",
    });

    const handleFileChange = (event) => {
        setProfileImage(event.target.files[0]);
    };

    useEffect(() => {
        const fetchProfile = async () => {
            if (accessToken) {
                try {
                    const profileUrl = `${config.get("API_URL")}/api/user/profile`;
                    const response = await fetch(profileUrl, {
                        method: "GET",
                        headers: { Authorization: `Bearer ${accessToken.replace(/^"|"$/g, '')}` },
                    });
                    const data = await response.json();
                    setUserData({
                        first_name: data.first_name,
                        last_name: data.last_name,
                        phone: data.phone,
                    });
                    setInitialData({
                        first_name: data.first_name,
                        last_name: data.last_name,
                        phone: data.phone,
                    });

                    if (data.profile_pic === null || data.profile_pic === undefined) {
                        const imageUrl = avatar1;
                        setProfileImageUrl(imageUrl);
                    } else {
                        data.profile_pic = "/" + data.profile_pic;
                        const imageUrl = data.profile_pic ? `${config.get("API_URL")}${data.profile_pic}` : avatar1;
                        console.log(imageUrl);
                        setProfileImageUrl(imageUrl);
                    }
                } catch (error) {
                    console.error("Error fetching profile:", error);
                }
            }
        };

        fetchProfile();
    }, [accessToken]);

    const { t } = useTranslation();

    const handleImageChange = (event) => {
        setProfileImage(event.target.files[0]);
    };

    const handleInputChange = (field, value) => {
        setUserData(prevState => ({ ...prevState, [field]: value }));
    };

    const handleUpdateProfile = async () => {
        setLoading(true);
        const formDat = new FormData();

        // Iterate over userData to find changed fields and update them
        for (const fieldKey in userData) {
            if (userData[fieldKey] !== initialData[fieldKey]) {
                formDat.append(fieldKey, userData[fieldKey]);
            }
        }

        // Add the profile image to the form data
        if (profileImage) {
            formDat.append('profile_pic', profileImage);
        }

        try {
            const response = await fetch(`${config.get("API_URL")}/api/user/update`, {
                method: "PUT",
                headers: {
                    "Authorization": `Bearer ${accessToken.replace(/^"|"$/g, '')}`,
                },
                body: formDat,
            });
            const data = await response.json();
            console.log(data);
            if (data.message) {
                setMessage({ text: data.message, type: 'success' });
                setLoading(false);
            } else if (data.error) {
                setMessage({ text: data.error, type: 'error' });
                setLoading(false);
            }
        } catch (error) {
            setMessage({ text: 'Error updating user data.', type: 'error' });
            console.error("Error:", error);
            setLoading(false);
        }

        // Update initialData to reflect the new state
        setInitialData(userData);
    };

    useEffect(() => {
        if (message.text) {
            const timer = setTimeout(() => setMessage(''), 3000);
            return () => clearTimeout(timer);
        }
    }, [message]);

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <React.Fragment>
            <div className="Editprofile">
                <div className="px-4 pt-4">
                    <h4 className="mb-0">{t('Settings')}</h4>
                </div>

                <div className="text-center border-bottom p-4">
                    <div className="mb-4 profile-user">
                        <img
                            src={profileImage ? URL.createObjectURL(profileImage) : profileImageUrl}
                            className="rounded-circle avatar-lg img-thumbnail"
                            alt="ProfileMain"
                        />

                        <Button
                            type="button"
                            color="light"
                            className="avatar-xs p-0 rounded-circle profile-photo-edit"
                            onClick={() => document.getElementById('file-input').click()}
                        >
                            <i className="ri-pencil-fill"></i>
                        </Button>
                        <Input
                            id="file-input"
                            type="file"
                            accept=".png, .jpg, .jpeg, .webp"
                            style={{ display: 'none' }}
                            onChange={handleFileChange}
                        />
                    </div>

                    <h5 className="font-size-16 mb-1 text-truncate">{`${userData.first_name} ${userData.last_name}`}</h5>
                </div>

                {/* End profile user */}

                {/* Start User profile description */}
                <SimpleBar style={{ maxHeight: "100%" }} className="p-4 user-profile-desc">
                    <div id="profile-setting-accordion" className="custom-accordion">
                        <Card className="accordion-item border mb-2">
                            <CustomCollapse title="Personal Info" isOpen={true}>
                                {message.text && (
                                    <div
                                        className={`alert ${message.type === 'error' ? 'alert-danger' : 'alert-success'}`}
                                        role="alert">
                                        {message.text}
                                    </div>
                                )}
                                <div>
                                    <p className="text-muted mb-1">{t('First Name')}</p>
                                    <Input
                                        type="text"
                                        value={userData.first_name}
                                        onChange={(e) => handleInputChange('first_name', e.target.value)}
                                    />
                                </div>
                                <div className="mt-4">
                                    <p className="text-muted mb-1">{t('Last Name')}</p>
                                    <Input
                                        type="text"
                                        value={userData.last_name}
                                        onChange={(e) => handleInputChange('last_name', e.target.value)}
                                    />
                                </div>
                                <div className="mt-4">
                                    <p className="text-muted mb-1">{t('Phone')}</p>
                                    <Input
                                        type="text"
                                        value={userData.phone}
                                        onChange={(e) => handleInputChange('phone', e.target.value)}
                                    />
                                </div>

                            </CustomCollapse>
                        </Card>
                        <div className="text-center mt-4">
                            <Button
                                color="new"
                                block
                                className="waves-effect waves-light custom-sign-in-button"
                                onClick={handleUpdateProfile}
                                disabled={loading}>
                                {loading ? (
                                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                ) : t('Update Profile')}
                            </Button>
                        </div>

                    </div>
                    {/* end profile-setting-accordion */}
                </SimpleBar>
                {/* End User profile description */}
            </div>
        </React.Fragment>
    );
}

export default Settings;