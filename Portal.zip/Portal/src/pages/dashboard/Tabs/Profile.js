import React, { useEffect, useState } from "react";
import {
  Card, Dropdown, DropdownItem, DropdownMenu, DropdownToggle,
} from "reactstrap";
import { Link } from 'react-router-dom';

//Import components
import CustomCollapse from "../../../components/CustomCollapse";
import AttachedFiles from "../../../components/AttachedFiles";

//Import Images
import avatar1 from "../../../assets/images/users/avatar-1.jpg";

//i18n
import { useTranslation } from "react-i18next";

import config from "../../../config";

function Profile(props) {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [isOpen1, setIsOpen1] = useState(true);
  const [isOpen2, setIsOpen2] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [profileImageUrl, setProfileImageUrl] = useState(null);
  const [profileImage, setProfileImage] = useState(null);
  const [profile, setProfile] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    role: "",
  });

  useEffect(() => {
    const accessToken = localStorage.getItem("authUser");
    if (accessToken) {
      setIsLoading(true);
      const token = accessToken.replace(/^"|"$/g, '');
      const profileUrl = `${config.get("API_URL")}/api/user/profile`;

      fetch(profileUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then(response => response.json())
        .then(data => {
          console.log("ProfileMain data:", data);
          setProfile({
            firstName: data.first_name,
            lastName: data.last_name,
            email: data.email,
            phone: data.phone,
            role: data.role,
          });
          if (data.profile_pic === null || data.profile_pic === undefined) {
            const imageUrl = avatar1;
            setProfileImageUrl(imageUrl);
            setIsLoading(false); // Stop loading
          } else {
            data.profile_pic = "/" + data.profile_pic;
            const imageUrl = data.profile_pic ? `${config.get("API_URL")}${data.profile_pic}` : avatar1;
            console.log(imageUrl);
            setProfileImageUrl(imageUrl);
            setIsLoading(false); // Stop loading
          }
        })
        .catch(error => {
          console.error("Error fetching profile:", error);
          setIsLoading(false); // Stop loading on error
        });
    }
  }, []);

  /* intilize t variable for multi language implementation */
  const { t } = useTranslation();

  const toggleCollapse1 = () => {
    setIsOpen1(!isOpen1);
    setIsOpen2(false);
  };

  const toggleCollapse2 = () => {
    setIsOpen2(!isOpen2);
    setIsOpen1(false);
  };

  const toggle = () => setDropdownOpen(!dropdownOpen);

  return (
    <React.Fragment>
      <div className="glass-effect">

        <div className="px-4 pt-4">
          <div className="user-chat-nav float-end">
            <div className="user-chat-nav float-end">
            </div>
            <Dropdown isOpen={dropdownOpen} toggle={toggle}>
              <DropdownToggle
                tag="a"
                className="font-size-18 text-muted dropdown-toggle"
              >
                <i className="ri-more-2-fill"></i>
              </DropdownToggle>
              <DropdownMenu className="dropdown-menu-end">
                <DropdownItem><Link to="/ProfileEdit" className="text-muted">{t('Edit Profile')}</Link></DropdownItem>
                <DropdownItem><Link to="/forget-password" className="text-muted">{t('Change Password')}</Link></DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
          <h4 className="mb-0">{t("My Profile")}</h4>
        </div>

        <div className="flex-container">
          {isLoading ? (
            <div className="text-center">
              <div className="spinner-border text-primary" role="status">
                <span className="sr-only"></span>
              </div>
            </div>
          ) : (
            <div className="img-container">
              <img
                src={profileImage ? URL.createObjectURL(profileImage) : profileImageUrl}
                className="rounded-circle avatar-lg img-thumbnail"
                alt="ProfileMain"
              />
              <h5 className="font-size-16 mb-1 text-truncate">
                {profile.firstName} {profile.lastName}
              </h5>
            </div>
          )}

          <div className="info-container">
            <div id="profile-user-accordion-1" className="custom-accordion">
              <Card className="shadow-none border mb-2" style={{ "background": "#ffff" }}>
                <CustomCollapse
                  title="About"
                  iconClass="ri-user-2-line"
                  isOpen={isOpen1}
                  toggleCollapse={toggleCollapse1}
                >
                  <div>
                    <p className="text-muted mb-1">{t("Name")}</p>
                    <h5 className="font-size-14">
                      {profile.firstName} {profile.lastName}
                    </h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">{t("Email")}</p>
                    <h5 className="font-size-14">{profile.email}</h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">{t("Phone")}</p>
                    <h5 className="font-size-14">{profile.phone}</h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">{t("Role")}</p>
                    <h5 className="font-size-14 mb-0">{profile.role}</h5>
                  </div>
                </CustomCollapse>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default Profile;
