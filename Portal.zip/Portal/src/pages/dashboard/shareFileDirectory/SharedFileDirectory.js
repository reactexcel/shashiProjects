// import React from "react";

// const SharedFileDirectory = ({ shareFileNameDir }) => {

//   return (
//     <div className="w-25 px-3">
//       <h6 className="text-black d-flex gap-1 align-items-center mb-0 py-3">
//         Shared Files
//         <span
//           style={{
//             borderRadius: "50%",
//             width: "20px",
//             height: "20px",
//             backgroundColor: "#FFECE3",
//             fontSize: "12px",
//             color: "#000",
//             display: "flex",
//             alignItems: "center",
//             justifyContent: "center",
//           }}
//         >
//           2
//         </span>
//       </h6>
//       {shareFileNameDir.map((ele) => {
//         return (
//           <card>
//             <div className=" d-flex align-items-center gap-2">
//               <div
//                 style={{
//                   backgroundColor: "#FFECE3",
//                   padding: "14px",
//                   cursor: "pointer",
//                 }}
//                 className="rounded-3"
//               >
//                 <svg
//                   width="24"
//                   height="24"
//                   viewBox="0 0 24 24"
//                   fill="none"
//                   xmlns="http://www.w3.org/2000/svg"
//                 >
//                   <path
//                     d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
//                     stroke="#001659"
//                     stroke-width="1.5"
//                     stroke-linecap="round"
//                     stroke-linejoin="round"
//                   />
//                   <path
//                     d="M9 11.51L12 14.51L15 11.51M12 14.51V6.51001M6 16.51C9.89 17.81 14.11 17.81 18 16.51"
//                     stroke="#001659"
//                     stroke-width="1.5"
//                     stroke-linecap="round"
//                     stroke-linejoin="round"
//                   />
//                 </svg>
//               </div>
//               <div>
//                 <h6 className="mb-0">
//                   {ele.media
//                     .split("/")
//                     .pop()
//                     .split("_")
//                     .slice(1)
//                     .join("_")
//                     .substring(0,10)}
//                 </h6>
//                 <div className=" d-flex justify-content-center align-items-center gap-2 text-secondary">
//                   <p className="mb-0 fw-bold">PDF</p>
//                   <p className="mb-0 fw-bold">9mb</p>
//                 </div>
//               </div>
//             </div>
//           </card>
//         );
//       })}
//     </div>
//   );
// };

// export default SharedFileDirectory;
  
import React from "react";
import { download } from "../../utils";

const SharedFileDirectory = ({ shareFileNameDir }) => {
  return (
    <div className="w-25 px-3">
      <h6 className="text-black d-flex gap-1 align-items-center mb-0 py-3">
        Shared Files
        <span
          style={{
            borderRadius: "50%",
            width: "20px",
            height: "20px",
            backgroundColor: "#FFECE3",
            fontSize: "12px",
            color: "#000",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {shareFileNameDir.length}
        </span>
      </h6>
      {shareFileNameDir.map((ele) => {
        const filenameWithExtension = ele.media.split("/").pop();
        const filenameOnly = filenameWithExtension.split("_")[2];
        const fileExtension = filenameWithExtension.split(".").pop();
        return (
          <div key={ele.msg_id} className="my-2">
            <div className=" d-flex align-items-center gap-2">
              <div
                style={{
                  backgroundColor: "#FFECE3",
                  padding: "14px",
                  cursor: "pointer",
                }}
                className="rounded-3"
                onClick={() => download(ele.media)}
              >
                <svg
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M9 22H15C20 22 22 20 22 15V9C22 4 20 2 15 2H9C4 2 2 4 2 9V15C2 20 4 22 9 22Z"
                    stroke="#001659"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M9 11.51L12 14.51L15 11.51M12 14.51V6.51001M6 16.51C9.89 17.81 14.11 17.81 18 16.51"
                    stroke="#001659"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>
              </div>
              <div>
                <h6 className="mb-0"  style={{fontSize:"14px"}}>
                  {filenameOnly}.{fileExtension}
                </h6>
                <div className=" d-flex align-items-center gap-2 text-secondary">
                  <p className="mb-0 fw-bold" style={{fontSize:"12px"}}>{fileExtension.toUpperCase()}</p>
                  {/* <p className="mb-0 fw-bold">9mb</p> */}
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default SharedFileDirectory;
