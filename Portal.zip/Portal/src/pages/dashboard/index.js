import React, { useEffect, useState } from "react";
import ChatLeftSidebar from "./ChatLeftSidebar";
import UserChat from "./UserChat/index";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import BuyerSellerChat from "./BuyerSellerChat";
import config from "../../config";
import SellerBuyerChat from "./SellerBuyerChat";




const Index = () => {
  const users = useSelector((state) => state.Chat.users);
  const [sellerDetails, setSellerDetails] = useState(null);
  const [selectedChat, setSelectedChat] = useState("customerSupport");
  const [profileDetail, setProfileDetail] = useState({
    firstName: "",
    email: "",
    role: "",
    phone: "",
    userId: "",
    profile_pic: "",
  });
  const [recentChatUserList, setRecentChatUserList] = useState([]);
  const [recentCustomerChatUserList, setRecentCustomerChatUserList] = useState([]);
  const location = useLocation();


  useEffect(() => {
    if (location.state) {
      setSellerDetails(location.state);
    }
  }, [location]);

  useEffect(() => {
    document.title = "Chat | AiRE Brokers";
  }, []);

  useEffect(() => {
    if (sellerDetails && sellerDetails.property_id) {
      setSelectedChat(
        `${sellerDetails.seller_id}-${sellerDetails.property_id}`
      );
    }
  }, [sellerDetails]);

  const openUserChat = (e, chat) => {
    e.preventDefault();
    setSelectedChat(chat);
    setSellerDetails(chat);
  };

  // profile data
  useEffect(() => {
    const accessToken = localStorage.getItem("authUser");
    if (accessToken) {
      const token = accessToken.replace(/^"|"$/g, "");
      const profileUrl = `${config.get("API_URL")}/api/user/profile`;
      fetch(profileUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          setProfileDetail({
            firstName: data.first_name,
            email: data.email,
            role: data.role,
            userId: data.uuid,
            phone: data.phone,
            profile_pic: data.profile_pic,
          });
        })
        .catch((error) => {
          console.error("Error fetching profile:", error);
        });
    }
  }, []);


  useEffect(() => {
    const accessToken = localStorage.getItem("authUser");
    if (accessToken) {
      const token = accessToken.replace(/^"|"$/g, "");
      const recentChatUserList = `${config.get("API_URL")}/api/users/chat/list`;

      fetch(recentChatUserList, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          // console.log(data,"ddddddddaaaaaaaaaaaaaaaaaa");
          setRecentChatUserList(data);
        })
        .catch((error) => {
          console.error("Error fetching profile:", error);
        });
    }
  }, []);


  useEffect(() => {
    const accessToken = localStorage.getItem("authUser");
    if (accessToken) {
      const token = accessToken.replace(/^"|"$/g, "");
      const recentChatUserList = `${config.get("API_URL")}/api/users/customer/property/chat/list`;

      fetch(recentChatUserList, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          // console.log(data,"ddddddddaaaaaaaaaaaaaaaaaa");
          setRecentCustomerChatUserList(data);
        })
        .catch((error) => {
          console.error("Error fetching profile:", error);
        });
    }
  }, []);


  return (
    <>
      <div className="chat-index">
        <ChatLeftSidebar
          sellerDetails={sellerDetails}
          recentChatUserList={recentChatUserList}
          recentCustomerChatUserList={recentCustomerChatUserList}
          openUserChat={openUserChat}
        />

        {/* user chat */}
        {selectedChat === "customerSupport" ? (
          <UserChat
            recentChatList={users}
            sellerDetails={sellerDetails}
            profileDetail={profileDetail}
          />
        ) : (
          <>
            {/* {
            profileDetail.role && profileDetail.role === "buyer" ? (
              <BuyerSellerChat
                profileDetail={profileDetail}
                sellerDetails={sellerDetails}
                selectedChat={selectedChat}
              />
            ) : profileDetail.role === "seller" ? (
              <SellerBuyerChat
                profileDetail={profileDetail}
                sellerDetails={sellerDetails}
                selectedChat={selectedChat}
              />
            ) : (
              <div className=" d-flex justify-content-center align-items-center w-100">
                <Loader />
              </div>
            )} */}
            <BuyerSellerChat
              profileDetail={profileDetail}
              sellerDetails={sellerDetails}
              selectedChat={selectedChat}
            />
          
          </>
        )}
      </div>
    </>
  );
};

export default Index;
