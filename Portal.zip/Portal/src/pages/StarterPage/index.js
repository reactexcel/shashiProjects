import React from 'react';

function Index(props) {

    document.title = "Starter Page | AiRE Brokers"
    return (
        <React.Fragment>
            
        </React.Fragment>
    );
}

export default Index;