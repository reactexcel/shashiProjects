import React, { useState } from 'react';
import { Card } from 'reactstrap';
import CustomCollapse from "../../components/CustomCollapse";
import { Link } from 'react-router-dom';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';
import avatar1 from "../../assets/images/users/avatar-1.jpg";

const ProfileCard = () => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const toggle = () => setDropdownOpen(prevState => !prevState);

  // Static profile data
  const profile = {
    firstName: "John",
    lastName: "Doe",
    email: "john.doe@example.com",
    phone: "+1234567890",
    role: "Seller",
    profileImageURL: avatar1
  };

  // Dummy function for CustomCollapse toggle
  const toggleCollapse1 = () => {};

  // Assuming isOpen1 state is managed outside for the CustomCollapse component
  const isOpen1 = true;

  return (
    <React.Fragment>
      <div className="glass-effect">
        <div className="px-2 pt-2">
          <div className="user-chat-nav float-end">
            <Dropdown isOpen={dropdownOpen} toggle={toggle}>
              <DropdownToggle tag="a" className="font-size-18 text-muted dropdown-toggle">
                <i className="ri-more-2-fill"></i>
              </DropdownToggle>
              <DropdownMenu className="dropdown-menu-end">
                <DropdownItem><Link to="/ProfileEdit" className="text-muted">Edit Profile</Link></DropdownItem>
                <DropdownItem><Link to="/forget-password" className="text-muted">Change Password</Link></DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </div>
          <h4 className="mb-0">My Profile</h4>
        </div>

        <div className="flex-container">
          <div className="img-container">
            <img src={profile.profileImageURL} className="rounded-circle avatar-lg img-thumbnail" alt="profile" />
            <h5 className="font-size-16 mb-1 text-truncate">{profile.firstName} {profile.lastName}</h5>
          </div>

          <div className="info-container">
            <div id="profile-user-accordion-1" className="custom-accordion">
              <Card className="shadow-none border mb-2" style={{ background: "#ffff" }}>
                <CustomCollapse
                  title="About"
                  iconClass="ri-user-2-line"
                  isOpen={isOpen1}
                  toggleCollapse={toggleCollapse1}
                >
                  <div>
                    <p className="text-muted mb-1">Name</p>
                    <h5 className="font-size-14">{profile.firstName} {profile.lastName}</h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">Email</p>
                    <h5 className="font-size-14">{profile.email}</h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">Phone</p>
                    <h5 className="font-size-14">{profile.phone}</h5>
                  </div>

                  <div className="mt-4">
                    <p className="text-muted mb-1">Role</p>
                    <h5 className="font-size-14 mb-0">{profile.role}</h5>
                  </div>
                </CustomCollapse>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
};

export default ProfileCard;