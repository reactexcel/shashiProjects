import React, { useState, useEffect } from 'react';
import { Box, Typography, IconButton, Grid, Card, CardActionArea, CardMedia, CardActions } from '@mui/material';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import DeleteIcon from '@mui/icons-material/Delete'; // Import Delete icon
import { useDropzone } from 'react-dropzone';

function ImageUpload({ property }) {
    const [files, setFiles] = useState([]);

    const handleDrop = (acceptedFiles) => {
        const newFilesWithPreview = acceptedFiles.map(file =>
            Object.assign(file, {
                preview: URL.createObjectURL(file)
            })
        );
        setFiles(prevFiles => [...prevFiles, ...newFilesWithPreview]);
    };

    useEffect(() => {
        return () => {
            files.forEach(file => URL.revokeObjectURL(file.preview));
        };
    }, [files]);

    const handleDeleteImage = (index) => {
        // Create a new array excluding the file at the specified index
        const newFiles = files.filter((_, i) => i !== index);
        setFiles(newFiles);

        // Optionally, if you're managing existing images, you'd also handle their deletion here
    };

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop: handleDrop,
        accept: 'image/*',
        multiple: true
    });

    return (
        <>
            <Grid item xs={12}>
                <Box {...getRootProps()} className="uploadButton" style={{ cursor: "pointer" }}>
                    <input {...getInputProps()} accept="image/*" multiple />
                    <Box className="dragDropArea" sx={{ border: '2px dashed #ccc', padding: '20px', textAlign: 'center', backgroundColor: 'white', borderRadius: '10px', transition: 'background-color 0.3s ease' }}>
                        {isDragActive ? (
                            <Typography color="textSecondary">Drop the images here ...</Typography>
                        ) : (
                            <Typography color="textSecondary">Drag some images here, or click to select images</Typography>
                        )}
                        <IconButton color="primary" aria-label="upload picture" component="label">
                            <PhotoCamera />
                        </IconButton>
                    </Box>
                </Box>
            </Grid>
            <Grid item xs={12} style={{ marginTop: "20px"}}>
                <Grid container spacing={2}>
                    {files.map((file, index) => (
                        <Grid item xs={12} sm={4} md={3} key={index}>
                            <Card sx={{ position: 'relative', boxShadow: 1 }}>
                                <CardActionArea>
                                    <CardMedia
                                        component="img"
                                        image={file.preview}
                                        alt={`New Image Preview ${index}`}
                                        loading="lazy"
                                        sx={{ height: 140, objectFit: 'cover' }}
                                    />
                                </CardActionArea>
                                <CardActions sx={{ position: 'absolute', top: 0, right: 0 }}>
                                    <IconButton aria-label="delete" size="small" onClick={() => handleDeleteImage(index)}>
                                        <DeleteIcon fontSize="inherit" />
                                    </IconButton>
                                </CardActions>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </Grid>
        </>
    );
}

export default ImageUpload;