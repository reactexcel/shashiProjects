import React, { useRef, useState, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getRequest, postRequest } from '../../apis/apiService.js'
import "./Docs.css";
import DownloadIcon from "@mui/icons-material/Download";
import FileUploadIcon from "@mui/icons-material/FileUpload";
import DescriptionIcon from "@mui/icons-material/Description";
import {
  Box,
  Container,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TablePagination,
  TableSortLabel,
  TextField,
  Typography,
  styled,
} from "@mui/material";
import FileUpload from "@mui/icons-material/FileUpload";
import config from "../../config.js";
import { downloadFile } from "../utils.js";


const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

function Docs() {


  const [data, setData] = useState([]);

  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [sortBy, setSortBy] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedType, setSelectedType] = useState(null);
  const [loading, setLoading] = useState(false);
  const [index, setIndex] = useState(null);
  // file state
  const [file, setFile] = useState(null);

  // Get the token from localStorage or wherever it's stored
  const accessToken = localStorage.getItem("authUser");

  const handleFilterByType = (type) => {
    setSelectedType(type);
  };

  const handleSort = (column) => {
    if (column === sortBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("asc");
    }
  };

  //* filter start */

  const filteredData = data.filter((item) => {
    // filter by select
    const folderLower = item.propertyType ? item.propertyType.toLowerCase() : ''; // Safely handle undefined folder
    const selectedTypeLower = selectedType ? selectedType.toLowerCase() : '';
    return selectedType === null || folderLower === selectedTypeLower;
  }).filter((item) =>
    // filter by search
    Object.values(item).some(
      (value) =>
        typeof value === "string" &&
        value.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  //* filter start */

  const sortedData = [...filteredData].sort((a, b) => {
    if (sortBy && sortOrder) {
      if (sortOrder === "asc") {
        return a[sortBy] > b[sortBy] ? 1 : -1;
      } else {
        return a[sortBy] < b[sortBy] ? 1 : -1;
      }
    }
    return 0;
  });
  // console.log("data",sortedData)

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  //* upload input file handler */

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
    if (selectedFile) {
      handleUpload(selectedFile)
    }
  };

  //* upload input file handler end */


  //* upload file handler */

  const handleUpload = async (filefile) => {
    // console.log("clicked")
    try {
      const formData = new FormData();
      formData.append('file', filefile);

      await postRequest("upload-doc", accessToken, formData);

    } catch (error) {
      console.log(error)
    }
  };

  //* upload file handler end */

  //* get user document data handler */

  const _getUserDocHandler = async () => {
    try {

      // code here
      const token = accessToken.replace(/['"]+/g, '');
      const res = await getRequest("user/uploaded-documents", token)
      const strArr = ["Common", "Condo"]

      // modify api data add new data type

      const modifiedData = res.map((data) => {
        const strIndx = Math.floor(Math.random() * strArr.length)
        const propertyType = strArr[strIndx]
        return { ...data, propertyType }
      })

      // set data in state

      setData(modifiedData)

    } catch (error) {
      console.log({ error });
    }
  }

  useEffect(() => {
    _getUserDocHandler()
  }, [accessToken])

  //* get user document data handler end */

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>

      <Box className="docs-box">

        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            my: 4,
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px",
          }}
        >

          <Box>
            <Typography
              variant="h6"
              component="div"
              sx={{ ps: 2, color: "#232D8E" }}
            >
              Documents
            </Typography>
          </Box>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              flexWrap: "wrap",
              gap: "20px",
            }}
          >
            <Typography variant="p" component="div">
              Search
            </Typography>
            <TextField
              variant="outlined"
              className="search-input"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </Box>
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            my: 4,
            justifyContent: "space-evenly",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px",
          }}
        >
          <Button
            variant="outlined"
            onClick={() => handleFilterByType(null)}
            className={selectedType === null ? "active" : ""}
          >
            Common
          </Button>
          <Button

            onClick={() => handleFilterByType("condo")}
            variant={selectedType === "condo" ? "contained" : "outlined"}
          >
            Condo
          </Button>
          {/* <Button
            
            onClick={() => handleFilterByType("multiFamily")}
            variant={selectedType === "multiFamily" ? "contained" : "outlined"}
          >
            MultiFamily
          </Button>
          <Button
            
            onClick={() => handleFilterByType("singleFamily")}
            variant={selectedType === "singleFamily" ? "contained" : "outlined"}
          >
            SingleFamily
          </Button> */}
          {/* <Button
            
            onClick={() => handleFilterByType("townhouse")}
            variant={selectedType === "townhouse" ? "contained" : "outlined"}
          >
            Townhouse
          </Button> */}
        </Box>
        <Box>
          <TableContainer component={Paper}>
            <Table aria-label="simple table">
              <TableHead>
                <TableRow>
                  <TableCell>
                    <TableSortLabel
                      active={sortBy === "name"}
                      direction={sortOrder}
                      onClick={() => handleSort("name")}
                    >
                      Users
                    </TableSortLabel>
                  </TableCell>
                  <TableCell>Documents</TableCell>
                  <TableCell>
                    {/* <Button component="label"
                        key={"user_doc"}
                          role={undefined}
                          variant="outlined"
                          tabIndex={-1}
                          startIcon={[ <DescriptionIcon />,<FileUploadIcon />]}>
                          Upload Docs
                            <VisuallyHiddenInput type="file" key={"user_doc"} onChange={handleFileChange} />
                        </Button> */}
                  </TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {sortedData
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row, i) => (
                    <TableRow key={row.name}>
                      <TableCell>{row.name}</TableCell>
                      <TableCell>
                        <Button variant="outlined" key={row.name}
                          disabled={loading && index === i}
                          onClick={() => {
                            downloadFile(`${config.get("API_URL")}${row.url}`, row.name, setLoading, setIndex);
                            setIndex(i)
                          }}
                        >
                          <DescriptionIcon /> <DownloadIcon /> {loading && index === i ? "Loading..." : "Download Docs"}
                        </Button>
                      </TableCell>
                      <TableCell>
                        <Button component="label"
                          key={row.name}
                          role={undefined}
                          variant="outlined"
                          tabIndex={-1}
                          startIcon={[<DescriptionIcon />, <FileUploadIcon />]}>
                          Upload Docs
                          <VisuallyHiddenInput type="file" key={row.id} onChange={handleFileChange} />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
            rowsPerPageOptions={[5, 10, 25]}
            component="div"
            className="table-paginations"
            count={filteredData.length}
            rowsPerPage={rowsPerPage}
            page={page}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        </Box>
      </Box>
    </Container>
  );
}

export default Docs;
