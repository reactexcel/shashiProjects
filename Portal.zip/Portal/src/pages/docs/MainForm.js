

import React, { useState } from "react";
import "./Docs.css";
import {
  Box,
  Container,
  Button,
  Typography,
} from "@mui/material";
import FlForms from "./FlForms";
import MnForms from "./MnForms";

const MainForm = () => {
  const [toggalTab, setToggleTab] = useState("FLFORM")

  const tabHandler = (tab) => {
    if (toggalTab === "FLFORM") {
      setToggleTab(tab)
    } else {
      setToggleTab(tab)
    }
  }

  return (
    <Container maxWidth="lg" sx={{
      // mt: 4,
      // mb: 4,
      background: "radial-gradient(rgba(255, 94, 20, 0.4), rgba(158, 110, 230, 0.28))",
      height: "100%"
    }}>
      {/* <Box className="docs-box"> */}
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          my: 4,
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "20px",

        }}
      >


        <select class="form-select form-select-sm" aria-label=".form-select-sm example" style={{ width: "220px", height: "48px" }}>
          <option >Select State</option>
          <option value="1">Minnesota</option>
          <option value="2">Florida</option>

        </select>

        <Box>
          <Typography
            variant="h6"
            component="div"
            sx={{ ps: 2, color: "#232D8E" }}
          >
            {`Available Folders ${toggalTab === "FLFORM" ? "FL Forms" : "MN Forms"}`}
          </Typography>
        </Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px",
          }}
        >
          <Button variant="contained" onClick={() => tabHandler("FLFORM")}>
            FL FORMS
          </Button>

          <Button variant="contained" onClick={() => tabHandler("MNFORM")}>
            MN FORMS
          </Button>
        </Box>
      </Box>
      {toggalTab === "FLFORM" ? <FlForms key={toggalTab} /> : <MnForms key={toggalTab} />}
      {/* </Box> */}
    </Container>
  )
}

export default MainForm