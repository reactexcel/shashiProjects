import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Docs.css";
import {
  Box,
  Menu,
  MenuItem,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TablePagination,
  TableSortLabel,
  TextField,
  Typography,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
} from "@mui/material";
import { postRequest } from "../../apis/apiService";

function MnForms() {


  const [data, setData] = useState([]);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [sortBy, setSortBy] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [searchTerm, setSearchTerm] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  // Get the token from localStorage or wherever it's stored
  const accessToken = localStorage.getItem("authUser");
  const [openMenu, setOpenMenu] = useState(false);
  const [openMenuMove, setOpenMenuMove] = useState(false);
  const [openPopupUpdate, setOpenPopupUpdate] = useState(false);
  const [file, setFile] = useState(null);
  const [selectedOption, setSelectedOption] = useState("");
  const [inputValue, setInputValue] = useState("");
  const [inputDescriptionValue, setInputDescriptionValue] = useState("");
  const [selectedType, setSelectedType] = useState(null);

  const handleSort = (column) => {
    if (column === sortBy) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortBy(column);
      setSortOrder("asc");
    }
  };

  const filteredData = data
    .filter((item) => selectedType === null || item.folder.toLowerCase() === selectedType.toLowerCase())
    .filter((item) =>
      Object.values(item).some(
        (value) =>
          typeof value === "string" &&
          value.toLowerCase().includes(searchTerm.toLowerCase())
      )
    );

  const sortedData = [...filteredData].sort((a, b) => {
    if (sortBy && sortOrder) {
      if (sortOrder === "asc") {
        return a[sortBy] > b[sortBy] ? 1 : -1;
      } else {
        return a[sortBy] < b[sortBy] ? 1 : -1;
      }
    }
    return 0;
  });

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  const handleClickMenu = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };
  const handleInputChangeDescription = (e) => {
    setInputDescriptionValue(e.target.value);
  };

  const handleCloseModal = () => {
    setFile(null);
    setSelectedOption("");
    setInputValue("");
    setOpenMenu(false);
  };

  const handleCloseModal2 = () => {
    setOpenPopupUpdate(false);
  };

  const handleCloseModal3 = () => {
    setOpenMenuMove(false);
  };



  const handleFilterByType = (type) => {
    setSelectedType(type);
  };

  const handleUpload = async (filefile) => {


    try {
      const formData = new FormData();
      formData.append('file', file);

      await postRequest("upload-doc", accessToken, formData);

      handleCloseModal();

    } catch (error) {
      console.log(error)
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {

        const token = accessToken.replace(/['"]+/g, '');

        const response = await fetch('http://192.168.12.121:5090/api/docs', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const jsonData = await response.json();
        const flFormsData = jsonData.filter(item => item.type === "MN_Forms");
        setData(flFormsData);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [accessToken]);

  console.log({ data });

  return (
    <>

      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          my: 4,
          justifyContent: "space-evenly",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <Button
          variant="outlined"
          onClick={() => handleFilterByType(null)}
          className={selectedType === null ? "active" : ""}
        >
          Common
        </Button>
        <Button

          onClick={() => handleFilterByType("condo")}
          variant={selectedType === "condo" ? "contained" : "outlined"}
        >
          Condo
        </Button>
        <Button

          onClick={() => handleFilterByType("multiFamily")}
          variant={selectedType === "multiFamily" ? "contained" : "outlined"}
        >
          MultiFamily
        </Button>
        <Button

          onClick={() => handleFilterByType("singleFamily")}
          variant={selectedType === "singleFamily" ? "contained" : "outlined"}
        >
          SingleFamily
        </Button>
        <Button

          onClick={() => handleFilterByType("townhouse")}
          variant={selectedType === "townhouse" ? "contained" : "outlined"}
        >
          Townhouse
        </Button>
      </Box>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          my: 4,
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <Box></Box>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "20px",
          }}
        >
          <Typography variant="p" component="div">
            Search
          </Typography>
          <TextField
            variant="outlined"
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </Box>
      </Box>
      <Box>
        <TableContainer component={Paper}>
          <Table aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>
                  <TableSortLabel
                    active={sortBy === "name"}
                    direction={sortOrder}
                    onClick={() => handleSort("name")}
                  >
                    Documents
                  </TableSortLabel>
                </TableCell>
                <TableCell>Actions</TableCell>
                <TableCell></TableCell>
              </TableRow>
            </TableHead>
            {/* <TableBody>
                {sortedData
                  .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                  .map((row) => (
                    <TableRow key={row.id}>
                      <TableCell>
                        <Link to={row.link}>{row.name}</Link>
                      </TableCell>
                      <TableCell>
                        <Button
                          id="basic-button"
                          aria-controls={anchorEl ? "basic-menu" : undefined}
                          aria-haspopup="true"
                          onClick={handleClickMenu}
                        >
                          ...
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody> */}



            {/* {data && data.length > 0 ? (
      <Table>
        <TableBody>
          {data.map((row) => (
            <TableRow key={row.id}>
              <TableCell>
                <Link to={row.link}>{row.name}</Link>
              </TableCell>
              <TableCell>
                <Button
                  id="basic-button"
                  aria-controls={anchorEl ? "basic-menu" : undefined}
                  aria-haspopup="true"
                  onClick={handleClickMenu}
                >
                  ...
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    ) : (
      <p>Loading...</p>
    )} */}

            {sortedData && sortedData.length > 0 ? (
              <Table>
                <TableBody>
                  {sortedData
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((row) => (
                      <TableRow key={row.name}>
                        <TableCell>
                          <Link to={row.url}>{row.name}</Link>
                        </TableCell>
                        <TableCell>
                          <Button
                            id="basic-button"
                            aria-controls={anchorEl ? "basic-menu" : undefined}
                            aria-haspopup="true"
                            onClick={handleClickMenu}
                          >
                            ...
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            ) : (
              <p>No data found.</p>
            )}

          </Table>
        </TableContainer>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          className="table-paginations"
          count={filteredData.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Box>
      <Menu
        id="basic-menu"
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        <MenuItem onClick={() => setOpenPopupUpdate(true)}>Update</MenuItem>
        <MenuItem onClick={() => setOpenMenuMove(true)}>Move</MenuItem>
      </Menu>
      {/* upload document popup */}
      <Dialog open={openMenu} onClose={handleCloseModal}>
        <DialogTitle
          style={{
            mb: 3,
          }}
        >
          Upload Document
        </DialogTitle>

        <DialogContent>
          <input
            style={{
              marginBottom: "20px",
            }}
            type="file"
            onChange={handleFileChange}
          />
          <FormControl fullWidth>
            <InputLabel>Select Option</InputLabel>
            <Select value={selectedOption} onChange={handleOptionChange}>
              <MenuItem value="option1">Option 1</MenuItem>
              <MenuItem value="option2">Option 2</MenuItem>
              <MenuItem value="option3">Option 3</MenuItem>
            </Select>
          </FormControl>
          <Typography
            variant="h6"
            component="div"
            sx={{
              textAlign: "center",
            }}
          >
            OR
          </Typography>
          <TextField
            fullWidth
            label="Create New Folder"
            value={inputValue}
            onChange={handleInputChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseModal}>Cancel</Button>
          <Button onClick={handleUpload}>Upload</Button>
        </DialogActions>
      </Dialog>

      {/* update popup */}

      <Dialog open={openPopupUpdate} onClose={handleCloseModal2}>
        <DialogTitle
          style={{
            mb: 3,
          }}
        >
          Update Document
        </DialogTitle>

        <DialogContent>
          <TextField
            fullWidth
            label="Description"
            rows={4}
            multiline
            style={{
              marginBottom: "20px",
            }}
            value={inputDescriptionValue}
            onChange={handleInputChangeDescription}
          />

          <TextField
            fullWidth
            label="Rename"
            value={inputValue}
            onChange={handleInputChange}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseModal2}>Cancel</Button>
          <Button onClick={handleCloseModal2}>Save</Button>
        </DialogActions>
      </Dialog>

      {/* move document popup */}

      <Dialog open={openMenuMove} onClose={handleCloseModal3}>
        <DialogTitle
          style={{
            mb: 3,
          }}
        >
          Move Document
        </DialogTitle>

        <DialogContent>
          <FormControl fullWidth>
            <InputLabel>Select Option</InputLabel>
            <Select value={selectedOption} onChange={handleOptionChange}>
              <MenuItem value="option1">Option 1</MenuItem>
              <MenuItem value="option2">Option 2</MenuItem>
              <MenuItem value="option3">Option 3</MenuItem>
            </Select>
          </FormControl>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseModal3}>Cancel</Button>
          <Button onClick={handleCloseModal3}>Move</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

export default MnForms;
