import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Typography, Grid, IconButton, Card, CardMedia, CardActionArea, CardActions, Box, Backdrop, CircularProgress } from '@mui/material';
import PhotoCamera from '@mui/icons-material/PhotoCamera';
import DeleteIcon from '@mui/icons-material/Delete';
import { useDropzone } from 'react-dropzone';
import { useFormik } from 'formik';
import { useTranslation } from 'react-i18next';
import { Button, Input, InputGroup, Alert } from 'reactstrap';
import config from "../../config";
import BathtubOutlinedIcon from '@mui/icons-material/BathtubOutlined';

const EditProperties = () => {
    const [loading, setLoading] = useState(false);
    const { t } = useTranslation();
    const { id } = useParams();
    const [messageInfo, setMessageInfo] = useState({ message: '', type: '' });
    const [initialValues, setInitialValues] = useState({});
    const [profileImage, setProfileImage] = useState(null);


    useEffect(() => {
        const propertyData = JSON.parse(localStorage.getItem('currentProperty'));
        if (propertyData) {
            setInitialValues(propertyData);
            formik.setValues(propertyData);
        } else {
            setMessageInfo({ message: 'No property data found', type: 'error' });
        }
    }, []);

    const onDrop = (acceptedFiles) => {
        formik.setFieldValue('images', [
            ...formik.values.images,
            ...acceptedFiles.map(file => ({
                file,
                preview: URL.createObjectURL(file),
                isNew: true,
            })),
        ]);
    };

    const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

    const handleDeleteImage = async (index) => {
        const image = formik.values.images[index];
        if (image.isNew) {
            setLoading(true);
            // Remove from the form state
            const filteredImages = formik.values.images.filter((_, idx) => idx !== index);
            formik.setFieldValue('images', filteredImages);
            setLoading(false);
        } else {
            setLoading(true);
            console.log('Remove image:', image, image.url);
            // Call the API to remove the image
            try {
                const body = {
                    property_id: id,
                    image_url: image, // Assuming each image object has a URL property
                };
    
                const response = await fetch(`${config.get("API_URL")}/api/user/properties/image/remove`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': 'Bearer ' + localStorage.getItem('authUser').replace(/^"|"$/g, ''),
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(body),
                });
                const data = await response.json();
                if (response.ok) {
                    setLoading(false);
                    setMessageInfo({ message: 'Image removed successfully', type: 'success' });
                    const filteredImages = formik.values.images.filter((_, idx) => idx !== index);
                    formik.setFieldValue('images', filteredImages);
                } else {
                    setLoading(false);
                    setMessageInfo({ message: data.message || 'Failed to remove image', type: 'error' });
                }
            } catch (error) {
                setLoading(false);
                console.error('Failed to delete image:', error);
                setMessageInfo({ message: 'Failed to delete image', type: 'error' });
            }
        }
    };


    const handleFileChange = (event) => {
        setProfileImage(event.target.files[0]);
    };

    const formik = useFormik({
        initialValues: {
            address: '',
            status: '',
            images: [],
            baths: 0,
            beds: 0,
            kitchen: 0,
            latitude: 0.0,
            longitude: 0.0,
            owner_info: {},
            property_id: ''
        },
        enableReinitialize: true,
        onSubmit: async (values) => {
            setLoading(true);
            const modifiedValues = new FormData();
        
            Object.keys(values).forEach((key) => {
                if (key === 'images') {
                    values[key].forEach((image, index) => {
                        modifiedValues.append(`image`, image.file);
                    });
                } else if (values[key] !== initialValues[key]) {
                    modifiedValues.append(key, values[key]);
                }
            });

            if (profileImage) {
                modifiedValues.append('profile_pic', profileImage);
            }

   
                try {
                    const images = modifiedValues.getAll('image');
                    modifiedValues.delete('image');

                    if (images.length > 0) {
                        for (let image of images) {
                            const formData = new FormData();
                            for (let pair of modifiedValues.entries()) {
                                formData.append(pair[0], pair[1]);
                            }
                            formData.append('image', image);

                            for (let pair of formData.entries()) {
                                console.log(pair[0]+ ', '+ pair[1]); 
                            }

                            const response = await fetch(`${config.get("API_URL")}/api/user/properties/${id}`, {
                                method: 'PUT',
                                headers: {
                                    'Authorization': 'Bearer ' + localStorage.getItem('authUser')?.replace(/^"|"$/g, '')
                                },
                                body: formData,
                            });

                            console.log(response);

                            const data = await response.json();
                            console.log('Property updated:', data);
                            setLoading(false);
                            setMessageInfo({ message: 'Property updated successfully', type: 'success' });
                        }
                    } else {
                        const formData = new FormData();
                        for (let pair of modifiedValues.entries()) {
                            formData.append(pair[0], pair[1]);
                        }

                        const response = await fetch(`${config.get("API_URL")}/api/user/properties/${id}`, {
                            method: 'PUT',
                            headers: {
                                'Authorization': 'Bearer ' + localStorage.getItem('authUser')?.replace(/^"|"$/g, '')
                            },
                            body: formData,
                        });

                        console.log(response);

                        const data = await response.json();
                        console.log('Property updated:', data);
                        setLoading(false);
                        setMessageInfo({ message: 'Property updated successfully', type: 'success' });
                    }
            } catch (error) {
                console.error('Failed to update property:', error);
                setLoading(false);
                setMessageInfo({ message: 'Failed to update property', type: 'error' });
            } finally {
                setLoading(false);
            }
        },
    });

    useEffect(() => {
        const propertyData = JSON.parse(localStorage.getItem('currentProperty'));
        if (propertyData) {
            setInitialValues(propertyData);
            formik.setValues(propertyData);
        } else {
            setMessageInfo({ message: 'No property data found', type: 'error' });
        }
    }, []);


    return (
        <>
                <Backdrop
            sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1, opacity: 0.5 }} // Adjust opacity as needed
            open={loading}
        >
            <CircularProgress color="inherit" />
        </Backdrop>
            <form onSubmit={formik.handleSubmit} className='editPropertiesContainer'>

                <Box className="editPropertiesContainer" sx={{ p: 4, margin: 'auto', maxWidth: 900, flexGrow: 1 }}>
                    <h1 className='myPropertiesHeading'>Edit Property</h1>

                    <Grid container spacing={3}>
                        <Grid item xs={12}>
                            {messageInfo.message && messageInfo.type === 'success' && (
                                <Alert variant="success" className="text-center mb-4">
                                    {messageInfo.message}
                                </Alert>
                            )}
                            {messageInfo.message && messageInfo.type === 'error' && (
                                <Alert variant="danger" className="text-center mb-4">
                                    {messageInfo.message}
                                </Alert>
                            )}
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-file-list-3-line"></i> {/* Changed icon for status */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Status"
                                    variant="outlined"
                                    name="status"
                                    placeholder='Enter Status'
                                    value={formik.values.status}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control" // Adjusted background color
                                />
                            </InputGroup>
                        </Grid>
                        <Grid item xs={12}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-map-pin-line"></i> {/* Changed icon for address */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Address"
                                    variant="outlined"
                                    name="address"
                                    placeholder='Enter Address'
                                    value={formik.values.address}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control" // Adjusted background color
                                />
                            </InputGroup>
                        </Grid>

                        <Grid item xs={12} sm={6}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-hotel-bed-line"></i> {/* Icon for beds */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Beds"
                                    variant="outlined"
                                    name="beds"
                                    type="number"
                                    min={0}
                                    placeholder='Enter Number of Beds'
                                    value={formik.values.beds}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control"
                                />
                            </InputGroup>
                        </Grid>

                        <Grid item xs={12} sm={6}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <BathtubOutlinedIcon fontSize="small" />
                                </span>
                                <Input
                                    fullWidth
                                    label="Baths"
                                    variant="outlined"
                                    name="baths"
                                    type="number"
                                    min={0}
                                    placeholder='Enter Number of Baths'
                                    value={formik.values.baths}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control"
                                />
                            </InputGroup>
                        </Grid>

                        <Grid item xs={12} sm={6}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-restaurant-line"></i> {/* Icon for kitchen */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Kitchen"
                                    variant="outlined"
                                    name="kitchen"
                                    type="number"
                                    min={0}
                                    placeholder='Enter Number of Kitchens'
                                    value={formik.values.kitchen}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control"
                                />
                            </InputGroup>
                        </Grid>

                        <Grid item xs={12} sm={6}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-map-pin-line"></i> {/* Reusing the icon for latitude */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Latitude"
                                    variant="outlined"
                                    name="latitude"
                                    type="number"
                                    min={0}
                                    placeholder='Enter Latitude'
                                    value={formik.values.latitude}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control"
                                />
                            </InputGroup>
                        </Grid>

                        <Grid item xs={12} sm={6}>
                            <InputGroup className="bg-soft-light rounded-3">
                                <span className="input-group-text border-light text-muted">
                                    <i className="ri-map-pin-line"></i> {/* Reusing the icon for longitude */}
                                </span>
                                <Input
                                    fullWidth
                                    label="Longitude"
                                    variant="outlined"
                                    name="longitude"
                                    type="number"
                                    min={0}
                                    placeholder='Enter Longitude'
                                    value={formik.values.longitude}
                                    onChange={formik.handleChange}
                                    className="form-control form-control-lg border-light bg-white form-control"
                                />
                            </InputGroup>
                        </Grid>


                        <Grid item xs={12}>
                            <Box {...getRootProps()} className="uploadButton" style={{ cursor: "pointer" }}>
                                <input {...getInputProps()} accept="image/*" multiple onChange={handleFileChange} />
                                <Box className="dragDropArea" sx={{ border: '2px dashed #ccc', padding: '20px', textAlign: 'center', backgroundColor: 'white', borderRadius: '10px', transition: 'background-color 0.3s ease' }}>
                                    {isDragActive ? (
                                        <Typography color="textSecondary">Drop the images here ...</Typography>
                                    ) : (
                                        <Typography color="textSecondary">Drag some images here, or click to select images</Typography>
                                    )}
                                    <IconButton color="primary" aria-label="upload picture" component="label">
                                        <PhotoCamera />
                                    </IconButton>
                                </Box>
                            </Box>
                        </Grid>
                            <Grid item xs={12}>
                            <Grid container spacing={2}>
                                {formik.values.images && formik.values.images.map((item, index) => (
                                <Grid item xs={12} sm={6} md={4} key={index}>
                                    <Card sx={{ position: 'relative', boxShadow: 1 }}>
                                    <CardActionArea>
                                        <CardMedia
                                        component="img"
                                        image={item.preview || `${config.get("API_URL")}${item}`}
                                        alt={`Property Image ${index}`}
                                        loading="lazy"
                                        sx={{ height: 140, objectFit: 'cover' }}
                                        />
                                    </CardActionArea>
                                    <CardActions sx={{ position: 'absolute', top: 0, right: 0 }}>
                                        <IconButton aria-label="delete" size="small" onClick={() => handleDeleteImage(index)}>
                                        <DeleteIcon fontSize="inherit" />
                                        </IconButton>
                                    </CardActions>
                                    </Card>
                                </Grid>
                                ))}
                            </Grid>
                            </Grid>
                        <Grid item xs={12}>
                            <div className="d-grid">
                                <Button
                                    color="new"
                                    block
                                    className="waves-effect waves-light custom"
                                    type="submit"
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                                    ) : (
                                        t('Update')
                                    )}
                                </Button>
                            </div>
                        </Grid>
                    </Grid>
                </Box>
            </form>

        </>
    );
};

export default EditProperties;