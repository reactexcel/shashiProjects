import * as React from "react";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { styled } from "@mui/material/styles";
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import CardActions from "@mui/material/CardActions";
import Avatar from "@mui/material/Avatar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import HouseSidingIcon from "@mui/icons-material/HouseSiding";
import { red } from "@mui/material/colors";
import GpsNotFixedIcon from "@mui/icons-material/GpsNotFixed";
import Default from "../../assets/images/default.jpg";
import { Box, Button, Container } from "@mui/material";
import config from "../../config";
import Pagination from "@mui/material/Pagination";

export default function Properties() {
  const [properties, setProperties] = useState([]);
  const [expanded, setExpanded] = useState(false);
  const [openNewPropertyModal, setOpenNewPropertyModal] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentProperties = properties.slice(indexOfFirstItem, indexOfLastItem);
  const pageCount = Math.ceil(properties.length / itemsPerPage);

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const [formData, setFormData] = useState({
    address: "",
    baths: 0,
    beds: 0,
    city: "",
    description: "",
    images: [],
    kitchen: 0,
    latitude: 0,
    longitude: 0,
    name: "",
    owner_bio: "",
    owner_email: "",
    owner_name: "",
    owner_number: "",
    owner_profile: "",
    price: 0,
    property_id: "",
    property_type: 0,
    seller_id: "",
    size: 0,
    state: "",
    status: "",
  });
  const [currentPanel, setCurrentPanel] = useState(1);
  const navigate = useNavigate();
  useEffect(() => {
    const fetchUserProperties = async () => {
      try {
        let authUser = localStorage.getItem("authUser");
        if (!authUser) {
          console.error("Access token not found");
          return;
        }
        authUser = authUser.replace(/^"|"$/g, "");

        const profileResponse = await fetch(`${config.get("API_URL")}/api/user/profile`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${authUser}`,
          },
        });

        if (!profileResponse.ok) {
          const error = await profileResponse.json();
          throw new Error(`Failed to fetch user profile: ${error.error}`);
        }

        const profileData = await profileResponse.json();
        const uuid = profileData.uuid; // Assuming 'uuid' is the correct key

        let apiEndpoint = `${config.get("API_URL")}/api/user/properties`;
        const response = await fetch(apiEndpoint, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${authUser}`,
          },
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(`Failed to fetch properties: ${error.error}`);
        }

        const propertiesData = await response.json();
        if (Array.isArray(propertiesData)) {
          const filteredProperties = propertiesData.filter(property =>
            property.owner_info && property.owner_info.user_id !== uuid
          );
          setProperties(filteredProperties);
        } else {
          console.error("Expected properties data to be an array but got:", typeof propertiesData, propertiesData);
          setProperties([]);
        }
      } catch (error) {
        console.error("Error fetching properties:", error.message);
      }
    };

    fetchUserProperties();
  }, []);




  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const handleOpenNewPropertyModal = () => {
    setOpenNewPropertyModal(true);
    setCurrentPanel(1);
  };

  const handleCloseNewPropertyModal = () => {
    setOpenNewPropertyModal(false);
  };

  const handleChange = (key, value) => {
    setFormData({
      ...formData,
      [key]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Submit logic here
  };

  const handleNextPanel = () => {
    setCurrentPanel(currentPanel + 1);
  };

  const handlePreviousPanel = () => {
    setCurrentPanel(currentPanel - 1);
  };

  const navigateToChatPage = async (
    seller_id,
    name,
    price,
    property_id,
    owner_email,
    owner_name,
    address,
    owner_profile,
    user_id
  ) => {
    try {
      const authUser = localStorage.getItem("authUser");
      if (!authUser) {
        throw new Error("Access token not found");
      }

      // const addBuyerResponse = await fetch(
      //   `${config.get("API_URL")}/api/users/buyers/add`,
      //   {
      //     method: "POST",
      //     headers: {
      //       "Content-Type": "application/json",
      //       Authorization: `Bearer ${authUser}`,
      //     },
      //     body: JSON.stringify({
      //       property_id,
      //       seller_id,
      //     }),
      //   }
      // );

      // if (!addBuyerResponse.ok) {
      //   throw new Error("Failed to add buyer");
      // }

      // If buyer is successfully added, log the success message
      console.log("Buyer added successfully to seller");

      // Navigate to the chat page
      navigate("/chat", {
        state: {
          seller_id,
          name,
          price,
          property_id,
          owner_email,
          owner_name,
          address,
          owner_profile,
          user_id
        },
      });
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <h4 className="mb-4 properties">Properties</h4>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "center",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: "20px",
          padding: "2rem",
          "&::after": {
            content: '""',
            flex: "auto",
          },
        }}
      >
        {currentProperties.map((property, index) => (
          <Card
            sx={{
              width: 343,
              minHeight: 500,
              maxWidth: 343,
              borderRadius: "12px",
              padding: 1.5,
              boxShadow: "0px 14px 80px rgba(34, 35, 58, 0.2)",
              display: "flex",
              flexDirection: "column",
              flexGrow: 1,
              marginBottom: 2,
            }}
            key={index}
          >
            <CardHeader
              avatar={
                <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
                  {property.owner_info.name ? property.owner_info.name[0] : "?"}
                </Avatar>
              }
              title={property.owner_info.name || "Unknown Owner"}
              subheader={`Status: ${property.status || "Unknown"}`}
            />
            <CardMedia
              component="img"
              image={
                property.images && property.images.length > 0
                  ? property.images[0]
                  : Default
              }
              alt={property.name || "No Title"}
              sx={{
                height: 0,
                paddingTop: "56.25%", // 16:9 aspect ratio
              }}
            />
            <CardContent sx={{ flexGrow: 1 }}>
              <Typography
                variant="h6"
                component="div"
                sx={{ display: "flex", alignItems: "center", mt: 2 }}
              >
                <HouseSidingIcon sx={{ fontSize: 18, color: "green", mr: 1 }} />
                {property.name || "No Name"}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {property.description || "No Description Available"}
              </Typography>
              <Typography
                variant="subtitle1"
                component="div"
                sx={{ display: "flex", alignItems: "center", mt: 2 }}
              >
                <GpsNotFixedIcon sx={{ fontSize: 18, color: "green", mr: 1 }} />
                {property.address}
              </Typography>
            </CardContent>
            <CardActions sx={{ justifyContent: "center" }}>
              <Button
                onClick={() =>
                  navigateToChatPage(
                    property.seller_id,
                    property.name || "Unnamed Property",
                    property.price,
                    property.property_id,
                    property.owner_info.email,
                    property.owner_info.name,
                    property.address,
                    property.owner_info.profile,
                    property.owner_info.user_id
                  )
                }
                sx={{
                  backgroundImage:
                    "linear-gradient(147deg, #fe8a39 0%, #FF5E14 74%)",
                  boxShadow: "0px 4px 12px rgba(252, 56, 56, 0.4)",
                  borderRadius: 20,
                  color: "white",
                  px: 3,
                }}
              >
                Contact Seller
              </Button>
            </CardActions>
          </Card>
        ))}
      </Box>
      <Pagination
        count={pageCount}
        page={currentPage}
        onChange={handlePageChange}
        color="primary" // default color
        sx={{
          "& .MuiPaginationItem-root": {
            color: "#232D8E", // Change text and icon color
            backgroundColor: "lightblue", // Change background color
          },
          "& .Mui-selected": {
            color: "white", // Change text and icon color for selected page
            backgroundColor: "#232D8E", // Change background color for selected page
          },
          "& .MuiPaginationItem-ellipsis": {
            color: "gray", // Change color of ellipsis
          },
          display: "flex",
          justifyContent: "center",
        }}
      />
    </Container>
  );
}
