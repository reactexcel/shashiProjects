import React, { useRef, useState, useCallback, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Sell.css";
import { useDropzone } from "react-dropzone";
import { PhotoCamera } from "@mui/icons-material";
import { Typography, IconButton } from "@mui/material";
import GooglePlacesAutocomplete from "react-google-autocomplete";
import successImage from './../../assets/images/success.png';
import { Snackbar, Alert } from '@mui/material';


import {
  Box,
  Container,
  FormControlLabel,
  Radio,
  RadioGroup,
  Stepper,
  Step,
  StepLabel,
  Button,
} from "@mui/material";
import Page1 from "../../assets/images/seller_page-0001.png";
import Page2 from "../../assets/images/seller_page-0002.png";
import Page3 from "../../assets/images/seller_page-0003.png";
import Page4 from "../../assets/images/seller_page-0004.png";
import SignatureCanvas from "react-signature-canvas";
import config from "../../config";
import StripeComponent from "./StripeComponent";
import ImageUpload from "../ImageUpload";

function Sell() {
  const canvaPageOne = useRef(null);
  const canvaPageThree = useRef(null);
  const canvaPageFour = useRef(null);
  const [file, setFile] = useState(null); // State to hold the uploaded file
  const [transaction_id, setTransactionId] = useState(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const handleCloseSnackbar = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpenSnackbar(false);
  };

  const showError = (message) => {
    setErrorMessage(message);
    setOpenSnackbar(true);
  };

  const [data, setData] = useState({
    seller_address: "",
    row_radio_buttons_group: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(value,"VVVVALLLLLLLLLLLL");
    setData({
      ...data,
      [name]: value,
    });
  };

  const handleAddressSelect = (place) => {
    setData({
      ...data,
      seller_address: place.formatted_address,
    });
  };

  console.log(data,"inputtttt data");
  const [errorMessage, setErrorMessage] = useState("");
  const [activeStep, setActiveStep] = useState(0);
  const history = useNavigate();
  const steps = ["", "", "", ""];
  const [fileUrl, setFileUrl] = useState("./seller.pdf");
  const onDrop = useCallback((acceptedFiles) => {
    // Assuming you want only the first file if multiple are dropped
    const file = acceptedFiles[0];
    setFile(file);
    setFileUrl(URL.createObjectURL(file)); // Create a URL for preview
  }, []);
  const [files, setFiles] = useState([]);
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });


  const thumbs = files.map((file) => (
    <div
      key={file.name}
      style={{
        display: "inline-flex",
        borderRadius: 2,
        border: "1px solid #eaeaea",
        marginBottom: 8,
        marginRight: 8,
        width: 100,
        height: 100,
        padding: 4,
        boxSizing: "border-box",
      }}
    >
      <div style={{ display: "flex", minWidth: 0, overflow: "hidden" }}>
        <img
          src={file.preview}
          style={{ display: "block", width: "auto", height: "100%" }}
          // Revoke data uri after image is loaded
          onLoad={() => {
            URL.revokeObjectURL(file.preview);
          }}
        />
      </div>
    </div>
  ));

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Implement your submit logic here
  };

  const handleFileChange = (event) => {
    // Handle the file logic here
    console.log(event.target.files);
  };

  const handleNext = async () => {
    let canProceed = true;
  
    if (activeStep === 0 && !data.seller_address.trim()) {
      showError("Address cannot be empty.");
      return; // Stop the function if the condition is not met
    }
  
    if (activeStep === 0) {
      // Await the API call and get response
      const isSuccess = await addProperty({
        seller_address: data.seller_address,
        property_type: data.row_radio_buttons_group,
      });
  
      // Update canProceed based on API response (assuming addProperty returns a boolean)
      canProceed = isSuccess;
    }
  
    if (activeStep === 2) {
      // This would also need to be awaited if it's an async operation
      await saveSignatureOnServer();
    }
    console.log("Can proceed:", canProceed)
    if (canProceed) {
      const isLastStep = activeStep === steps.length - 1;
      if (!isLastStep || paymentSuccess) {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
      } else {
        console.log("Attempted to proceed without payment success on last step");
      }
      setErrorMessage("");
    }

    const isLastStep = activeStep === steps.length - 1;
    if (!isLastStep || paymentSuccess) {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else {
        // Handle scenario where it's the last step but payment hasn't been processed
        showError("Please complete the payment to proceed.");
    }
    setErrorMessage("");
  };
  

  if (paymentSuccess && activeStep === steps.length - 1) {
    console.log("Displaying thank you step.");
}
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const sigCanvasRef = useRef();

  useEffect(() => {
    if (sigCanvasRef.current) {
      const canvas = sigCanvasRef.current.getCanvas();
      if (canvas.getContext) {
        const ctx = canvas.getContext("2d");

        ctx.fillStyle = "white";
        ctx.fillRect(0, 0, canvas.width / 2, canvas.height / 2);
      }
    }
  }, []);
  useEffect(() => {
    if (activeStep === 2) {
      drawCurrentDateonPageThree();
      getCurrentUserProfile();
    }
  }, [activeStep]);

  const addProperty = async (body) => {
    try {
      const accessToken = localStorage.getItem("authUser");

      if (accessToken) {
        const token = accessToken.replace(/^"|"$/g, ""); // Clean the token
        const addSellUrl = `${config.get("API_URL")}/api/user/properties/add/property-type-selection`;

        const response = await fetch(addSellUrl, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(body),
        });

        const responseData = await response.json();
        console.log(responseData);
        if (responseData.error) {
          showError(`Error: ${responseData.error}`);
          return;
      }
        setTransactionId(responseData.transaction_id);
        localStorage.setItem("transaction_id", responseData.transaction_id);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getCurrentUserProfile = async () => {
    try {
      const accessToken = localStorage.getItem("authUser");
      console.log("🚀 ~ getCurrentUserProfile ~ accessToken:", accessToken);
      if (accessToken) {
        const token = accessToken.replace(/^"|"$/g, ""); // Clean the token
        const url = `${config.get("API_URL")}/api/user/profile`;

        const response = await fetch(url, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });
        const data = await response.json();
        drawFullNameOnPage(data.first_name, data.last_name);
      }
    } catch (error) {
      showError(`Error: ${error}`);
      console.log("error in current profile::", error);
    }
  };

  const drawFullNameOnPage = (firstName, lastName) => {
    const fullName = `${firstName} ${lastName}`;
    const canvas = canvaPageOne.current;
    if (canvas) {
      const ctx = canvas?.getContext("2d");
      const img = new Image();
      img.onload = () => {
        const aspectRatio = img.width / img.height;
        canvas.width = img.width;
        canvas.height = canvas.width / aspectRatio;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.font = "bold 30px Arial";
        ctx.fillStyle = "red";
        const x = canvas.width / 11;
        const y = canvas.height / 2.65;
        ctx.fillText(fullName, x, y);
      };

      img.src = Page1;
    }
  };

  const drawCurrentDateonPageThree = () => {
    const canvas = canvaPageThree.current;
    if (canvas) {
      const ctx = canvas?.getContext("2d");
      const img = new Image();
      img.onload = () => {
        const aspectRatio = img.width / img.height;
        canvas.width = img.width;
        canvas.height = canvas.width / aspectRatio;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        ctx.font = "bold 30px Arial";
        ctx.fillStyle = "red";
        const x = canvas.width / 1.26;
        const y = canvas.height / 1.62;
        ctx.fillText(new Date().toLocaleDateString(), x, y);
      };

      img.src = Page3;
    }
  };

  const drawSignatureonPageFour = () => {
    const canvas = canvaPageThree.current;
    if (canvas) {
      const ctx = canvas?.getContext("2d");
      const img = new Image();
      img.onload = () => {
        const aspectRatio = img.width / img.height;
        canvas.width = img.width;
        canvas.height = canvas.width / aspectRatio;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const x = canvas.width / 6.5;
        const y = canvas.height / 1.7;
        ctx.drawImage(sigCanvasRef.current.getCanvas(), x, y);
        ctx.font = "bold 30px Arial";
        ctx.fillStyle = "red";
        const dateX = canvas.width / 1.26;
        const dateY = canvas.height / 1.62;
        ctx.fillText(new Date().toLocaleDateString(), dateX, dateY);
      };
      img.src = Page3;
    }
  };

  const saveSignatureOnServer = async () => {
    const accessToken = localStorage.getItem("authUser");
    const token = accessToken.replace(/^"|"$/g, "");
    const url = `${config.get("API_URL")}/api/user/properties/add/save-pdf`;

    const signature = sigCanvasRef.current
      .getTrimmedCanvas()
      .toDataURL("image/png");

    console.log("🚀 ~ saveSignatureOnServer ~ signature", signature);
    const body = {
      "transaction_id": transaction_id,
      "signature_data": signature,
    };

    console.log("~ body", body);
    // loop and print the body
    for (const [key, value] of Object.entries(body)) {
      // console.log(`${key}: ${value}`);
    }

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
        credentials: "include",
      });

      const responseData = await response.json(); // Convert the response to JSON
      console.log(responseData); // Log the response data to the console
    } catch (error) {
      console.log("error in saveSignatureOnServer::", error);
    }
  };

  const handlePaymentResponse = (status) => {
    console.log("Payment success status:", status);
    if (status === 200) {
        setPaymentSuccess(true);
        setActiveStep((prevActiveStep) => prevActiveStep + 1); // Automatically move to the next step if payment is successful
    } else {
        console.log("Payment failed or incomplete");
    }
};

  

  console.log(data?.seller_address);
  return (
    <Container>
      <form
        style={{
          display: "flex",
          justifyContent: "center",
          flexDirection: "column",
        }}
        onSubmit={handleSubmit}
        className="form"
        id="survey-form"
      >
        <Stepper
          activeStep={activeStep}
          alternativeLabel
          style={{ width: "50%", margin: "0 auto" }}
        >
          {steps.map((label, index) => (
            <Step key={index}>
              <StepLabel
                StepIconProps={{
                  style: {
                    color: activeStep === index ? "#F15A24" : "#232D8E", // Green when active, grey otherwise
                  },
                }}
                style={{
                  color: activeStep === index ? "darkgreen" : "#999", // Text color
                }}
              >
                {label}
              </StepLabel>
            </Step>
          ))}
        </Stepper>

        <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity="error" sx={{ width: '100%' }}>
          {errorMessage}
        </Alert>
      </Snackbar>

        {activeStep === 0 && (
          <Container>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center", // Changed to 'flex-start' to align items at the top of the container
                flexWrap: "wrap",

                padding: "2rem",
                "&::after": {
                  content: '""',
                  flex: "auto",
                },
              }}
            >
              <h3 style={{ textAlign: "center", color: "#232D8E" }}>
                Sell Your Property Fast!
              </h3>
              <p style={{ textAlign: "center", color: "#8A8A8A" }}>
                Thank you for taking the time to help us improve the platform.
              </p>
              <div className="user_details">
                <div className="input_pox">
                  <label className="datails" htmlFor="seller_address">
                    Complete Address
                  </label>
                
                  <input
                    type="text"
                    name="seller_address"
                    id="seller_address"
                    placeholder="Complete Address ..."
                    value={data?.seller_address}
                    onChange={handleChange}
                  />
                  {/* <GooglePlacesAutocomplete
                  />
                 <GooglePlacesAutocomplete
                    apiKey={config.get("GOOGLE_API_KEY")}
                    onPlaceSelected={(place) => {
                      setData({ seller_address: place.formatted_address })
                    }}
                  /> */}
                 
                </div>
                <div className="input_pox">
                  <span className="datails">Property Type</span>
                  <div className="property-type-radio">
                    <RadioGroup
                      row
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="row_radio_buttons_group"
                      value={data.row_radio_buttons_group}
                      onChange={handleChange}
                    >
                      <FormControlLabel
                        value="Single Family"
                        control={<Radio />}
                        label="Single Family"
                      />
                      <FormControlLabel
                        value="Condo"
                        control={<Radio />}
                        label="Condo"
                      />
                      <FormControlLabel
                        value="Townhouse"
                        control={<Radio />}
                        label="Townhouse"
                      />
                      <FormControlLabel
                        value="Multifamily (2+ units)"
                        control={<Radio />}
                        label="Multifamily (2+ units)"
                      />
                    </RadioGroup>
                  </div>
                </div>
              </div>
            </Box>
          </Container>
        )}

        {activeStep === 1 && (
          <Container>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                flexWrap: "wrap",
                padding: "2rem",
                "&::after": {
                  content: '""',
                  flex: "auto",
                },
              }}
            >
              <h3 style={{ textAlign: "center", color: "#232D8E" }}>
                Sell Your Property Fast!
              </h3>
              <p style={{ textAlign: "center", color: "#8A8A8A" }}>
                Thank you for taking the time to help us improve the platform.
              </p>
              <div className="user_details">
                <div className="input_pox">
                  <label className="datails" htmlFor="seller_address">
                    Upload Your Property's image
                  </label>
                  {/* Replace the existing upload logic with the ImageUpload component */}
                  <ImageUpload />
                </div>
              </div>
            </Box>
          </Container>
        )}

        {activeStep === 2 && (
          <Container>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center", // Changed to 'flex-start' to align items at the top of the container
                flexWrap: "wrap",

                padding: "2rem",
                "&::after": {
                  content: '""',
                  flex: "auto",
                },
              }}
            >
              <h3 style={{ textAlign: "center", color: "#232D8E" }}>
                Sell Your Property Fast!
              </h3>
              <p style={{ textAlign: "center", color: "#8A8A8A" }}>
                Thank you for taking the time to help us improve the platform.
              </p>
              <div className="user_details">
                <label className="datails" htmlFor="seller_address">
                  Read the contract carefully!
                </label>
                <div style={{ height: "750px", width: "100%" }}>
                  <div class="image-container" id="image-container">
                    {/* <img src={Page1} alt="" class="pdf-image" /> */}
                    <canvas
                      ref={canvaPageOne}
                      // id="canvas"
                      className="pdf-image"
                    ></canvas>
                    <img src={Page2} alt="" class="pdf-image" />
                    {/* <img src={Page3} alt="" class="pdf-image" id="last" /> */}
                    <canvas
                      ref={canvaPageThree}
                      id="last"
                      className="pdf-image"
                    ></canvas>
                    <div className="seller-date" id="currentDate"></div>

                    <img src={Page4} alt="Image" class="pdf-image" />
                  </div>
                  <br />
                  <SignatureCanvas
                    ref={sigCanvasRef}
                    onEnd={() => drawSignatureonPageFour()}
                    penColor="#232D8E"
                    canvasProps={{
                      className: "sigCanvas",
                    }}
                    style={{
                      border: "1px solid black",
                      backgroundColor: "#fff",
                    }} // Optionally add a border to visualize the canvas edges
                  />
                </div>
                <br />
              </div>
            </Box>
          </Container>
        )}
        {activeStep === 3 && (
          <Container>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center", // Changed to 'flex-start' to align items at the top of the container
                flexWrap: "wrap",

                padding: "2rem",
                "&::after": {
                  content: '""',
                  flex: "auto",
                },
              }}
            >
              <h3 style={{ textAlign: "center", color: "#232D8E" }}>
                Sell Your Property Fast!
              </h3>
              <p style={{ textAlign: "center", color: "#8A8A8A" }}>
                Thank you for taking the time to help us improve the platform.
              </p>
              <StripeComponent onPaymentSuccess={handlePaymentResponse} />
              <div className="user_details"></div>
            </Box>
          </Container>
        )}
        {paymentSuccess && activeStep === steps.length && (
            <Container>
              <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", padding: "2rem" }}>
              <img src={successImage} alt="Success"
                style={{height: "60vh", width: "100vh"}} />
                <h3 style={{ textAlign: "center", color: "#232D8E" }}>Thank You!</h3>
                <p style={{ textAlign: "center", color: "#8A8A8A", marginBottom: "-7%" }}>Your transaction has been successfully processed.</p>
              </Box>
            </Container>
          )}


          {activeStep !== steps.length && (
            <div className="navigation-buttons">

            <button
              style={{
                background: "white",
                color: "#000",
                border: "1px solid #F15A24",
              }}
              name="submit"
              className="btn_submit btn-next"
              disabled={activeStep === 0}
              onClick={handleBack}
            >
              Back
            </button>
          {activeStep < steps.length - 1 && !paymentSuccess && (
              <button id="submit" name="submit" className="btn_submit btn-next" onClick={handleNext}>Next</button>
            )}

        </div>
        )}

      </form>
    </Container>
  );
}

export default Sell;