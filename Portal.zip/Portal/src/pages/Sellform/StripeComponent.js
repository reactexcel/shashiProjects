import React, { useState } from "react";
import {
  CardNumberElement,
  CardExpiryElement,
  CardCvcElement,
  useStripe,
  useElements,
} from "@stripe/react-stripe-js";
import config from "../../config";
import "./CustomCardInput.css";
import CircularProgress from '@mui/material/CircularProgress';
import { Snackbar, Alert } from '@mui/material';

const StripeComponent = ({ onPaymentSuccess }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [promoCode, setPromoCode] = useState("");
  const [loading, setLoading] = useState(false); // Loading state
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  const showError = (message) => {
    setErrorMessage(message);
    setOpenSnackbar(true);
  };

  const onClickPay = async (payment) => {
    if (!stripe || !elements) {
      return;
    }

    setLoading(true);
    const cardNumber = elements.getElement(CardNumberElement);

    try {
      const { paymentMethod, error } = await stripe.createPaymentMethod({
        type: "card",
        card: cardNumber,
      });

      const { token, errorToken } = await stripe.createToken(cardNumber);

      if (error || errorToken) {
        showError("Error creating payment method: " + (error || errorToken).message);
        setLoading(false);
        return;
      }

      await sendThePaymentToServer(paymentMethod.id, token.id, payment);
    } catch (error) {
      showError("Payment error: " + error.message);
      setLoading(false);
    }
  };

  const sendThePaymentToServer = async (paymentMethodId, tokenId, payment) => {
    const token = localStorage.getItem("authUser");
    const url = `${config.get("API_URL")}/api/user/properties/add/checkout`;
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token.replace(/^"|"$/g, ""),
        },
        body: JSON.stringify({
          transaction_id: localStorage.getItem("transaction_id"),
          token: tokenId,
          code: paymentMethodId,
          payment_amount: payment,
        }),
      });

      if (response.ok) {
        onPaymentSuccess(200);
      } else {
        throw new Error('Payment not successful');
      }
    } catch (error) {
      showError("Server error during payment: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="payment_div">
      {loading && (
        <div className="overlay">
          <CircularProgress size={68} />
        </div>
      )}
      <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity="error" sx={{ width: '100%' }}>
          {errorMessage}
        </Alert>
      </Snackbar>
      <label className="datails">Card Information:</label>
      <div className="input">
        <CardNumberElement />
      </div>
      <div className="row_inputs">
        <div className="input" style={{marginRight: "10px"}}>
          <CardExpiryElement />
        </div>
        <div className="input">
          <CardCvcElement />
        </div>
      </div>
      <div className="input_pox">
        <label className="datails">Promo Code</label>
        <input
          type="text"
          className="input"
          placeholder="Promo Code"
          value={promoCode}
          onChange={(e) => setPromoCode(e.target.value)}
        />
      </div>
      <div className="paymentbtns_div">
        <div
          onClick={() => onClickPay("497")}
          className="payment_card"
          disabled={!stripe || loading}
        >
          <p className="text_1">Market Blast Package</p>
          <p className="text_bold">$497</p>
          <p className="description">
            For just $497, ignite your listing's visibility this package offers:
          </p>
          <button className="pay_button" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Pay Now'}
          </button>
        </div>
        <div
          onClick={() => onClickPay("997")}
          className="payment_card"
          disabled={!stripe || loading}
        >
          <p className="text_1">Ultimate Seller Suit</p>
          <p className="text_bold">$997</p>
          <p className="description">
            Our premium package at $997 delivers the ultimate selling toolkit
          </p>
          <button className="pay_button" disabled={loading}>
            {loading ? <CircularProgress size={24} /> : 'Pay Now'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default StripeComponent;

