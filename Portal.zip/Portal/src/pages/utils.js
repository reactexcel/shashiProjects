import config from "../config";

export function downloadFile(url, filename, setLoading, setIndex) {
  setLoading(true);
  fetch(url)
    .then((response) => response.blob())
    .then((blob) => {
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = filename;
      anchor.click();
      URL.revokeObjectURL(url); // Cleanup
      setLoading(false);
      setIndex(null);
    })
    .catch((error) => {
      console.error("Error downloading file:", error);
      setLoading(false);
      setIndex(null);
    });
}
// export function downloadFile(url, filename) {
//     // Create a hidden anchor element
//     const anchor = document.createElement('a');
//     // Set the URL and filename for download
//     anchor.href = url;
//     anchor.download = filename;
//     anchor.target = "_blank"; // Open in new tab
//     anchor.rel = "noopener noreferrer"; // Security best practice
//     document.body.appendChild(anchor);
//     // Trigger a click on the anchor element
//     anchor.click();

//     // Clean up
//     document.body.removeChild(anchor);
//   }

// formatter date
export function formatDate(timestampStr) {
  const timestamp = new Date(timestampStr);
  const currentDate = new Date();
  if (
    timestamp.getDate() === currentDate.getDate() &&
    timestamp.getMonth() === currentDate.getMonth() &&
    timestamp.getFullYear() === currentDate.getFullYear()
  ) {
    const diffMinutes = Math.round((currentDate - timestamp) / (1000 * 60));
    if (diffMinutes < 60 && diffMinutes > 1) {
      return `${diffMinutes} min`;
    }
    if (diffMinutes < 1) {
      return "Now";
    }
    if (diffMinutes > 60 && diffMinutes === 60) {
      const diffHours = Math.round(diffMinutes / 60);
      return `${diffHours} Hr`;
    }
  }
  const yesterday = new Date(currentDate);
  yesterday.setDate(currentDate.getDate() - 1);
  if (
    timestamp.getDate() === yesterday.getDate() &&
    timestamp.getMonth() === yesterday.getMonth() &&
    timestamp.getFullYear() === yesterday.getFullYear()
  ) {
    const options = {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    };
    return "Yesterday " + timestamp.toLocaleTimeString("en-US", options);
  }
  if (
    timestamp.getMonth() === currentDate.getMonth() &&
    timestamp.getFullYear() === currentDate.getFullYear()
  ) {
    const options = {
      weekday: "short",
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    };
    return timestamp.toLocaleDateString("en-US", options);
  }
  const options = {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  };
  return timestamp.toLocaleDateString("en-US", options);
}



export const download = async (fileName) => {
  try {
    const response = await fetch(`${config.get("API_URL")}${fileName}`);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();
    link.remove();
  } catch (error) {
    console.error("Error downloading file:", error);
  }
};