// users/actions.js
export const fetchProfileData = () => ({
    type: 'FETCH_PROFILE_DATA',
});

export const setProfileData = (data) => ({
    type: 'SET_PROFILE_DATA',
    payload: data,
});
