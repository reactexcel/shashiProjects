import { call, put, takeEvery } from 'redux-saga/effects';
import { setProfileData } from './actions';
import config from '../../config';

function* fetchProfileDataSaga() {
    try {
        const accessToken = localStorage.getItem("authUser");
        const token = accessToken?.replace(/^"|"$/g, "");
        const profileUrl = `${config.get("API_URL")}/api/user/profile`;
        const response = yield call(fetch, profileUrl, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        const data = yield response.json();
        yield put(setProfileData(data));
    } catch (error) {
        console.error("Error fetching profile:", error);
        // Optionally, dispatch an error action here
    }
}

export function* watchFetchProfileData() {
    yield takeEvery('FETCH_PROFILE_DATA', fetchProfileDataSaga);
}
