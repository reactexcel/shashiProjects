// import React, { Component } from 'react';
// import withRouter from "../components/withRouter";
// import { connect } from "react-redux"
// import PropTypes from "prop-types";
// import { changeLayoutMode } from '../redux/actions';

// class NonAuth extends Component {
//     constructor(props) {
//         super(props);
//         this.state={};
//         this.capitalizeFirstLetter.bind(this);
//     }

//     capitalizeFirstLetter = string => {
//         return string.charAt(1).toUpperCase() + string.slice(2);
//     };

//     componentDidMount(){
//         var getLayoutMode = localStorage.getItem("layoutMode");
//         this.props.changeLayoutMode(getLayoutMode);
//         if (getLayoutMode) {
//             this.props.changeLayoutMode(getLayoutMode);
//         } else {
//             this.props.changeLayoutMode(this.props.layoutMode);
//         }

//         // let currentage = this.capitalizeFirstLetter(this.props.router.location.pathname);
//     }
//     render() {
//         return <React.Fragment>
//             {this.props.children}
//         </React.Fragment>;
//     }
// }

// NonAuth.propTypes = {
//     layoutMode: PropTypes.any,
//   };

// const mapStateToProps = state => {
//     const { layoutMode } = state.Layout;
//     return { layoutMode };
//   };

// export default withRouter(connect(mapStateToProps, { changeLayoutMode })(NonAuth))

import React, { useEffect } from "react";
import { connect, useDispatch, useSelector } from "react-redux";
import { changeLayoutMode } from "../redux/actions";

function NonAuth({ children }) {
  const dispatch = useDispatch();

  useEffect(() => {
    const getLayoutMode = localStorage.getItem("layoutMode");
    if (getLayoutMode) {
      dispatch(changeLayoutMode(getLayoutMode));
    } else {
      dispatch(changeLayoutMode(layoutMode));
    }
  }, []);

  const layoutMode = useSelector((state) => state.Layout.layoutMode);

  return <React.Fragment>{children}</React.Fragment>;
}

const mapStateToProps = (state) => ({
  layoutMode: state.Layout.layoutMode,
});

export default connect(mapStateToProps, { changeLayoutMode })(NonAuth);
