import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  Nav,
  NavItem,
  NavLink,
  UncontrolledTooltip,
  Dropdown,
  DropdownItem,
  DropdownToggle,
  DropdownMenu,
} from "reactstrap";
import classnames from "classnames";
import { connect, useDispatch, useSelector } from "react-redux";

import { setActiveTab, changeLayoutMode } from "../../redux/actions";
import AddCircleOutlineOutlinedIcon from "@mui/icons-material/AddCircleOutlineOutlined";
import DescriptionIcon from "@mui/icons-material/Description";
import FolderIcon from "@mui/icons-material/Folder";
//Import Images
import logo from "../../assets/images/logo.svg";
import avatar1 from "../../assets/images/users/avatar-1.jpg";

// i18n
import i18n from "../../i18n";

// Flags
import usFlag from "../../assets/images/flags/us.jpg";
import spain from "../../assets/images/flags/spain.jpg";
import germany from "../../assets/images/flags/germany.jpg";
import italy from "../../assets/images/flags/italy.jpg";
import russia from "../../assets/images/flags/russia.jpg";
import { createSelector } from "reselect";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import config from "../../config";
import { fetchProfileData } from "../../redux/user/actions";

function LeftSidebarMenu() {
  const dispatch = useDispatch();
  const profileData = useSelector((state) => state.profile.profileData);
  const layoutMode = useSelector((state) => state.Layout.layoutMode);
  const activeTab = useSelector((state) => state.activeTab);

  // States for dropdown controls
  const [dropdownOpenMobile, setDropdownOpenMobile] = useState(false);
  const [dropdownOpen2, setDropdownOpen2] = useState(false);
  const [dropdownOpenDocs, setDropdownOpenDocs] = useState(false);
  const [dropdownOpenDocsInner, setDropdownOpenDocsInner] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [lng, setLng] = useState("English");

  // Toggle functions for dropdowns
  const toggleMobile = () => setDropdownOpenMobile(!dropdownOpenMobile);
  const toggle2 = () => setDropdownOpen2(!dropdownOpen2);
  const toggleDocs = () => setDropdownOpenDocs(!dropdownOpenDocs);
  const toggleDocsInner = () =>
    setDropdownOpenDocsInner(!dropdownOpenDocsInner);
  const toggleDropdown = () => setDropdownOpen(!dropdownOpen);

  // Redux action dispatchers
  const toggleTab = (tabName) => {
    dispatch(setActiveTab(tabName));
  };
  const onChangeLayoutMode = () => {
    dispatch(changeLayoutMode(layoutMode === "dark" ? "light" : "dark"));
  };

  useEffect(() => {
    if (!profileData) {
      dispatch(fetchProfileData());
    }
  }, [dispatch, profileData]);

  /* changes language according to clicked language menu item */
  const changeLanguageAction = (lng) => {
    /* set the selected language to i18n */
    i18n.changeLanguage(lng);

    if (lng === "sp") setLng("Spanish");
    else if (lng === "gr") setLng("German");
    else if (lng === "rs") setLng("Russian");
    else if (lng === "it") setLng("Italian");
    else if (lng === "eng") setLng("English");
  };
  const [profileImageUrl, setProfileImageUrl] = useState(avatar1); // Default to local avatar image

  const getInitials = (firstName, lastName) => {
    return `${firstName[0]}${lastName[0]}`;
  };

  const renderProfileImage = () => {
    if (profileData?.profile_pic) {
      return `${config.get("API_URL")}/${profileData.profile_pic}`;
    }
    return avatar1;
  };

  return (
    <React.Fragment>
      <div className="side-menu flex-lg-column me-lg-1">
        {/* LOGO */}
        <div className="navbar-brand-box">
          <Link to="/" className="logo logo-dark">
            <span className="logo">
              <img src={logo} alt="logo" height="60" />
            </span>
          </Link>

          <Link to="/" className="logo logo-light">
            <span className="logo-sm">
              <img src={logo} alt="logo" height="30" />
            </span>
          </Link>
        </div>
        {/* end navbar-brand-box  */}

        {/* Start side-menu nav */}
        <div className="flex-lg-column my-auto">
          <Nav
            className="side-menu-nav nav-pills justify-content-center"
            role="tablist"
          >
            <NavItem id="Properties">
              <a href="/properties" className="nav-link" style={{ color: "#ffffff" }}>
                <HomeOutlinedIcon style={{ color: "#232D8E" }} />

              </a>
              <UncontrolledTooltip target="Properties" placement="top">
                List properties
              </UncontrolledTooltip>
            </NavItem>
            <NavItem id="Sell">
              <a href="/sell" className="nav-link">
                <AddCircleOutlineOutlinedIcon style={{ color: "#232D8E" }} />
              </a>
              <UncontrolledTooltip target="Sell" placement="top">
                Sell Property
              </UncontrolledTooltip>
            </NavItem>
            <NavItem id="Chats">
              <a href="/chat" className="nav-link">
                <i
                  style={{ color: "#232D8E" }}
                  className="ri-message-3-line"
                ></i>
              </a>
              <UncontrolledTooltip target="Chats" placement="top">
                Chats
              </UncontrolledTooltip>
            </NavItem>
            <NavItem id="Myproperties">
              <a href="/MyProperties" className="nav-link">
                <i
                  style={{ color: "#232D8E" }}
                  className="ri-building-2-line"
                ></i>
              </a>
              <UncontrolledTooltip target="Myproperties" placement="top">
                My Properties
              </UncontrolledTooltip>
            </NavItem>

            <Dropdown
              nav
              isOpen={dropdownOpenDocs}
              toggle={() => setDropdownOpenDocs(!dropdownOpenDocs)}
              className="btn-group dropup profile-user-dropdown docs"
            >
              <DropdownToggle nav>
                <DescriptionIcon style={{ color: "#232D8E" }} />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem style={{ backgroundColor: "#fbfaff" }}>
                  Documents
                </DropdownItem>
                <DropdownItem divider sx={{ marginTop: 0, marginBottom: 0 }} />
                {/* <DropdownItem
                  style={{
                    paddingRight: 0,
                  }}
                >
                  <Dropdown
                    nav
                    direction="right"
                    isOpen={dropdownOpenDocsInner}
                    toggle={toggleDocsInner}
                    className={"second-develop-dropdown"}
                    onMouseOver={() => setDropdownOpenDocsInner(true)}
                    onMouseLeave={() => setDropdownOpenDocsInner(false)}
                  >
                    <DropdownToggle
                      className="dropdown-item custom-nav-item"
                      nav
                    >
                      Template
                    </DropdownToggle>
                    <DropdownMenu>
                      <DropdownItem href="/documents/fl-forms">
                        <FolderIcon /> Fl Forms
                      </DropdownItem>
                      <DropdownItem href="/documents/mn-forms">
                        <FolderIcon /> Mn Forms
                      </DropdownItem>
                    </DropdownMenu>
                  </Dropdown>
                </DropdownItem> */}
                <DropdownItem href="/documents/templates">Templates</DropdownItem>
                <DropdownItem href="/users/docs/">User Docs</DropdownItem>
              </DropdownMenu>
            </Dropdown>

            <Dropdown
              nav
              isOpen={dropdownOpenMobile}
              toggle={() => setDropdownOpenMobile(!dropdownOpenMobile)}
              className="profile-user-dropdown d-inline-block d-lg-none dropup"
            >
              <DropdownToggle nav>
                <img
                  src={renderProfileImage()}
                  alt="Profile"
                  className="profile-user rounded-circle"
                />
              </DropdownToggle>
              <DropdownMenu className="dropdown-menu-end">
                <DropdownItem href="/ProfileMain">
                  Profile{" "}
                  <i className="ri-profile-line float-end text-muted"></i>
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem href="/logout">
                  Log out{" "}
                  <i className="ri-logout-circle-r-line float-end text-muted"></i>
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </Nav>
        </div>
        {/* end side-menu nav */}

        <div className="flex-lg-column d-none d-lg-block">
          <Nav className="side-menu-nav justify-content-center">

            <Dropdown
              nav
              isOpen={dropdownOpen}
              className="nav-item btn-group dropup profile-user-dropdown"
              toggle={() => setDropdownOpen(!dropdownOpen)}
            >
              <DropdownToggle className="nav-link mb-2" tag="a">
                <img
                  src={renderProfileImage()}
                  alt="Profile"
                  className="profile-user rounded-circle"
                />
              </DropdownToggle>
              <DropdownMenu>
                <DropdownItem href="/ProfileMain">
                  Profile{" "}
                  <i className="ri-profile-line float-end text-muted"></i>
                </DropdownItem>
                <DropdownItem divider />
                <DropdownItem href="/logout">
                  Log out{" "}
                  <i className="ri-logout-circle-r-line float-end text-muted"></i>
                </DropdownItem>
              </DropdownMenu>
            </Dropdown>
          </Nav>
        </div>
      </div>
    </React.Fragment>
  );
}

export default LeftSidebarMenu;
