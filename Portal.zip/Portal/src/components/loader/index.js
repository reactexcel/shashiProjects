import "../loader/loader.css";
const Loader = ({style}) => {
  return (
    <div className=" d-flex flex-column">
      <p className="loader" style={style}></p>
      {/* <p>Loading...</p> */}
    </div>
  );
};

export default Loader;
