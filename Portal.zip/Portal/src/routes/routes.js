import React from "react";
import { Navigate } from "react-router-dom";
import { Elements } from "@stripe/react-stripe-js";
import stripePromise from "../pages/Sellform/stripe";
import MyProperties from "../pages/MyProperties/MyProperties";
import EditProperties from "../pages/MyProperties/EditProperties";
import Profilecard from "../pages/ProfileCard/Profilecard";
import MainForm from "../pages/docs/MainForm";

// lazy load all the views
const Dashboard = React.lazy(() => import("../pages/dashboard/index"));
const StarterPage = React.lazy(() => import("../pages/StarterPage/index"));

// auth
const Login = React.lazy(() => import("../pages/Auth/Login"));
const Logout = React.lazy(() => import("../pages/Auth/Logout"));
const ForgetPassword = React.lazy(() => import("../pages/Auth/ForgetPassword"));
const Register = React.lazy(() => import("../pages/Auth/Register"));
const LockScreen = React.lazy(() => import("../pages/Auth/LockScreen"));
const VerificationPage = React.lazy(() => import("../pages/Auth/VerificationPage"));
const ResetPassword = React.lazy(() => import("../pages/Auth/ResetPassword"));
const Properties = React.lazy(() => import("../pages/Properties/properties")) 
const Sell = React.lazy(() => import("../pages/Sellform/Sell")) 
const ProfileMain = React.lazy(() => import("../pages/Profile/ProfileMain"))
const Settings = React.lazy(() => import("../pages/dashboard/Tabs/Settings"))
const UserDocs = React.lazy(() => import("../pages/docs/Docs"))
const FlForms = React.lazy(() => import("../pages/docs/FlForms"))
const MnForms = React.lazy(() => import("../pages/docs/MnForms"))
// declare all routes
const authProtectedRoutes = [
  { path: "/chat", component: <Dashboard /> },
  { path: "/pages-starter", component: <StarterPage /> },
  { path: "/properties", component: <Properties /> },
  { path: "/Sell", component: <Sell /> },
  { path: "/ProfileMain", component: <ProfileMain /> },
  { path: "/ProfileEdit", component: <Settings /> },
  { path: "/MyProperties", component: <MyProperties /> },
  { path: "/EditProperties/:id", component: <EditProperties /> },
  { path: "/ProfileDetails", component: <Profilecard /> },
  { path: "/users/docs/", component: <UserDocs /> },
  { path: "/documents/fl-forms/", component: <FlForms /> },
  // { path: "/documents/mn-forms/", component: <MainForm /> },
  { path: "/documents/templates/", component: <MainForm /> },
    // this route should be at the end of all other routes
  // eslint-disable-next-line react/display-name
  {
    path: "/",
    exact: true,
    component: <Navigate to="/properties" />,
  },
  { path: "*", component: <Navigate to="/properties" /> },
];

const publicRoutes = [
  { path: "/logout", component: <Logout /> },
  { path: "/login", component: <Login /> },
  { path: "/forget-password", component: <ForgetPassword /> },
  { path: "/register", component: <Register /> },
  { path: "/lock-screen", component: <LockScreen />},
  { path: "/verify-email", component: <VerificationPage /> },
  { path: "/reset-password", component: <ResetPassword /> },
  

];

export { authProtectedRoutes, publicRoutes };
