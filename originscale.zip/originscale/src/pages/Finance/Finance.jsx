const Finance = () => {
  return (
    <div>
      I am finance page
    </div>
  )
}

export default Finance
