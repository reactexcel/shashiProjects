
const Make = () => {
  return (
    <div>
      I am make component
    </div>
  )
}

export default Make
