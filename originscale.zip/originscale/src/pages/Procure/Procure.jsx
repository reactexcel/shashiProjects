import React from 'react'

const Procure = () => {
  return (
    <div>Procure</div>
  )
}

export default Procure