
const Inventory = () => {
  return (
    <div>
     I am Inventory page 
    </div>
  )
}

export default Inventory
