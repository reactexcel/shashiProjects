import { Card, Form } from "react-bootstrap";
import DataRequestTable from "./DataRequestTable";
import CustomButton from "../../../../components/CustomButton";
import { Divider, Stack, Typography } from "@mui/material";

const Onboarding = [
  {
    title: "Total requests",
    value: "0",
  },
  {
    title: "Total partners",
    value: "0",
  },
  {
    title: "In progress",
    value: "0",
  },
  {
    title: "Submitted",
    value: "0",
  },
  {
    title: "Rework requested",
    value: "0",
  },
  {
    title: "Reviewed",
    value: "0",
  },
  {
    title: "Declined",
    value: "0",
  },
  {
    title: "Cancelled",
    value: "0",
  },
];

const DataRequest = () => {
  return (
    <div>
      <Card
        style={{
          padding: "20px",
          marginBottom: "20px",
          borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        }}
      >
        <Typography variant="inherit" sx={{ fontWeight: "600" }}>
          Data Requests
        </Typography>
        <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
        <Stack style={{ display: "flex", flexDirection: "row" }}>
          <Stack direction={'row'} spacing={2} width={'100%'} >
            {Onboarding.map((item, i) => (
              <Card key={i} style={{ padding: "10px", boxShadow: '6px 6px 11px #625d5dc2 inset',width:'100%'
            }}>
                <Card.Title style={{ fontSize: "12px", color: "gray" }}>
                  {item.title}
                </Card.Title>
                <Card.Text style={{ fontWeight: "bold" }}>
                  {item.value}
                </Card.Text>
              </Card>
            ))}
          </Stack>
        </Stack>
      </Card>

      <Card
        style={{
          padding: "20px",
          marginBottom: "20px",
          width: "100%",
          borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", 
        }}
      >
        <Form
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Stack
            direction={'row'} spacing={2} width={'50%'}  sx={{alignItems:'center',justifyContent:'space-between'} } >
            <Form.Group
              className="mb-3 w-10"
              controlId="exampleForm.ControlInput1"
            >
              <Form.Control type="email" placeholder="name@example.com" />
            </Form.Group>
            <Form.Select
              className="mb-3 w-20"
              aria-label="Default select example"
              style={{ width: "20%" }}
            >
              <option>Show</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </Form.Select>
            <Form.Group
              className="mb-3 w-5"
              // style={{ width: "10%" }}
              controlId="exampleForm.ControlInput1"
            >
              <Form.Control type="Text" placeholder="name@example.com" />
            </Form.Group>
            <Form.Group
              className="mb-3"
              controlId="exampleForm.ControlInput1"
            >
              <Form.Control type="email" placeholder="name@example.com" />
            </Form.Group>
          </Stack>
          <Stack
          direction={'row'} spacing={2} sx={{alignItems:'center'}}
          >
            <Form.Select
              aria-label="Default select example"
              style={{ width: "120px", height: "35px" }}
            >
              <option>Actions</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </Form.Select>
            <CustomButton
              btnText={"Create data request"}
              styles={{ padding: "5px 10px" }}
            />
          </Stack>
        </Form>
        <Divider sx={{ border: "1px solid gray", margin: "10px 0px",mb:'10px' }} />
        <DataRequestTable />
      </Card>
    </div>
  );
};

export default DataRequest;
