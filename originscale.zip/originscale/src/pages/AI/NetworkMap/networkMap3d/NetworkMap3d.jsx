// import React, { useState, useRef, useEffect } from "react";
// import { Wrapper } from "@googlemaps/react-wrapper";
// import {
//   PerspectiveCamera,
//   Scene,
//   AmbientLight,
//   WebGLRenderer,
//   Matrix4,
// } from "three";
// import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader";

// export default function NetworkMap3d({selectedLocation}) {
//   return (
//     <Wrapper apiKey={ import.meta.env.VITE_APP_GOOGLE_MAP_API_KEY}>
//       <MyMap selectedLocation={selectedLocation}/>
//     </Wrapper>
//   );
// }

// function MyMap({selectedLocation}) {
//   console.log(selectedLocation,"%%%%%%%%%%%%%%%%%%");
//   const overlayRef = useRef();
//   const [_map, setMap] = useState();
//   const ref = useRef();

//   const mapOptions = {
//     mapId: import.meta.env.VITE_APP_GOOGLE_MAP_API_KEY,
//     center: { selectedLocation.lat,selectedLocation.lan },
//     zoom: 17,
//     disableDefaultUI: true,
//     heading: 25,
//     tilt: 25,
//   };

//   useEffect(() => {
//     if (!overlayRef.current) {
//       const instance = new window.google.maps.Map(ref.current, mapOptions);
//       setMap(instance);
//       overlayRef.current = createOverlay(instance);
//     }
//   }, []);

//   return <div ref={ref} id="map" />;
// }

// function createOverlay(map) {
//   const overlay = new google.maps.WebGLOverlayView();
//   let renderer, scene, camera, loader;

//   overlay.onAdd = () => {
//     scene = new Scene();
//     camera = new PerspectiveCamera();
//     const light = new AmbientLight(0xffffff, 0.9);
//     scene.add(light);

//     loader = new GLTFLoader();
//     loader.loadAsync("/low_poly_scooter/scene.gltf").then((object) => {
//       const group = object.scene;
//       group.scale.setScalar(25);
//       group.rotation.set(Math.PI / 2, 0, 0);
//       group.position.setZ(-120);
//       scene.add(group);
//     });
//   };

//   overlay.onContextRestored = ({ gl }) => {
//     renderer = new WebGLRenderer({
//       canvas: gl.canvas,
//       context: gl,
//       ...gl.getContextAttributes(),
//     });
//     renderer.autoClear = false;

//     loader.manager.onLoad = () => {
//       renderer.setAnimationLoop(() => {
//         map.moveCamera({
//           tilt: mapOptions.tilt,
//           heading: mapOptions.heading,
//           zoom: mapOptions.zoom,
//         });

//         if (mapOptions.tilt < 60) {
//           mapOptions.tilt += 0.5;
//         } else if (mapOptions.zoom < 20) {
//           mapOptions.zoom += 0.05;
//         } else if (mapOptions.heading < 125) {
//           mapOptions.heading += 0.5;
//         } else {
//           renderer.setAnimationLoop(null);
//         }
//       });
//     };
//   };

//   overlay.onDraw = ({ transformer }) => {
//     const matrix = transformer.fromLatLngAltitude({
//       lat: mapOptions.center.lat,
//       lng: mapOptions.center.lng,
//       altitude: 120,
//     });
//     camera.projectionMatrix = new Matrix4().fromArray(matrix);

//     overlay.requestRedraw();
//     renderer.render(scene, camera);
//     renderer.resetState();
//   };

//   overlay.setMap(map);

//   return overlay;
// }

// import { useRef, useEffect } from "react";
// import { Wrapper } from "@googlemaps/react-wrapper";
// import yellowHouse from "../../../../assets/img1/marker/yellowhousesq1.webp";
// import blueHouse from "../../../../assets/img1/marker/bluehousesq1.webp";
// import redHouse from "../../../../assets/img1/marker/redhousesq1.webp";

// export default function NetworkMap3d({
//   selectedLocation,
//   stockStatus,
//   locationName,
// }) {
//   return (
//     <Wrapper apiKey={import.meta.env.VITE_APP_GOOGLE_MAP_API_KEY}>
//       <MyMap
//         selectedLocation={selectedLocation}
//         stockStatus={stockStatus}
//         locationName={locationName}
//       />
//     </Wrapper>
//   );
// }

// export function MyMap({ selectedLocation, stockStatus, locationName }) {
//   const overlayRef = useRef();
//   const ref = useRef();

//   useEffect(() => {
//     if (!overlayRef.current && selectedLocation) {
//       const mapOptions = {
//         center: { lat: selectedLocation.lat, lng: selectedLocation.lng },
//         zoom: 17,
//         disableDefaultUI: true,
//         heading: 25,
//         tilt: 25,
//       };

//       const instance = new window.google.maps.Map(ref.current, mapOptions);

//       new window.google.maps.Marker({
//         position: { lat: selectedLocation.lat, lng: selectedLocation.lng },
//         map: instance,

//         title: locationName || "",
//         icon: {
//           url:
//             stockStatus === "balance"
//               ? yellowHouse
//               : stockStatus === "stockout"
//               ? redHouse
//               : stockStatus === "excessstock"
//               ? blueHouse
//               : "",
//           scaledSize: { width: 50, height: 50 },
//         },
//       });
//     }
//   }, [selectedLocation]);

//   return <div ref={ref} id="map" />;
// }

import React, { useState, useEffect } from "react";
import { FaEye } from "react-icons/fa";
import { IoStorefrontSharp } from "react-icons/io5";

const NetworkMap3d = ({ selectedLocation }) => {
  const [streetViewVisible, setStreetViewVisible] = useState(true);

  let panorama;
  useEffect(() => {
    const initMap = () => {
      const location = selectedLocation;
      const map = new window.google.maps.Map(document.getElementById("map"), {
        center: location,
        zoom: 19,
        streetViewControl: false,
      });

      document
        .getElementById("toggle")
        .addEventListener("click", toggleStreetView);

      // const cafeMarker = new window.google.maps.Marker({
      //   position: { selectedLocation },
      //   map,
      //   icon: "https://chart.apis.google.com/chart?chst=d_map_pin_icon&chld=cafe|FFFF00",
      //   title: "Cafe",
      // });

      panorama = map.getStreetView();
      panorama.setPosition(location);
      panorama.setPov({
        heading: 265,
        pitch: 0,
      });
    };

    window.initMap = initMap;
    loadScript();
    
  }, []);

  // useEffect(() => {
  //   if (document.getElementsByClassName("gm-iv-close")) {
  //     document
  //       .getElementsByClassName("gm-iv-close")
  //       .addEventListener("click", function () {
  //         console.log("Button clicked!$$$$$$$$$$$$$");
  //       });
  //     // console.log("$$$$$$$$$$$$$$$+===================");
  //   }
  // }, []);



  const toggleStreetView = () => {
    const toggle = panorama.getVisible();
    console.log(toggle,"%%%%%%%%%%%%%%%%%%");
    if (toggle == false) {
      panorama.setVisible(true);
      setStreetViewVisible(false);
    } else {
      panorama.setVisible(false);
      setStreetViewVisible(true);
    }
  };


  const loadScript = () => {
    const script = document.createElement("script");
    script.src = `https://maps.googleapis.com/maps/api/js?key=${
      import.meta.env.VITE_APP_GOOGLE_MAP_API_KEY
    }&callback=initMap`;
    script.async = true;
    document.body.appendChild(script);
    console.log("heloo==================$$$$$$$$$$$$$$$$");
  };

  // console.log("", "$$$$$$$$$$$$$$$");


  return (
    <div style={{ position: "relative" }}>
      {streetViewVisible && (
        <button
          id="toggle"
          onClick={toggleStreetView}
          style={{
            border: "none",
            backgroundColor: "#fff",
            color: "#000",
            padding: "8px 19px",
            borderRadius: "2px",
            display: "flex",
            alignItems: "center",
            gap: "5px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
            position: "absolute",
            top: "55px",
            left: "10px",
            zIndex: "1000",
          }}
        >
          <IoStorefrontSharp />
          Store View
          <FaEye size={20} cursor="pointer" color="blue" />
        </button>
      )}
      <div id="map" style={{ width: "100%", height: "530px" }}></div>
    </div>
  );
};

export default NetworkMap3d;
