import {
  Button,
  Chip,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import CustomButton, { CustomOutlineButton } from "../../../components/CustomButton";

const Overview = () => {
  return (
    <>
      <Stack sx={{ gap: 2 }}>
        <Stack
          sx={{
            backgroundColor: "white",
            height: "250px",
            padding: "15px",
            gap: 2,
            boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
          borderRadius:'20px' 
                 }}
        >
          <Stack sx={{ fontWeight: "bold", flexDirection: "row", gap: 2 }}>
            Overall Influence Fectores
            <InfoIcon />
          </Stack>
          <Divider sx={{ border: "1px solid black" }} />
          <Stack sx={{ flexDirection: "row", gap: 2 }}>
            <Stack
              sx={{
                flexDirection: "row",
                justifyContent: "space-between",
                width: "30%",
                borderRadius: "10px",
                alignItems: "center",
                padding: "3px 9px",
                boxShadow: "rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset"
              }}
            >
              <Typography variant="caption">Description</Typography>
              <Chip
                label=" 91%"
                sx={{ background: "#30B5A1", color: "white" }}
              />
            </Stack>
            <Stack
              sx={{
                flexDirection: "row",
                justifyContent: "space-between",
                width: "30%",
                borderRadius: "10px",
                alignItems: "center",
                padding: "3px 9px",
                boxShadow: "rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset"
              }}
            >
              <Typography variant="caption">Product Group</Typography>
              <Chip
                label=" 95%"
                sx={{ background: "#30B5A1", color: "white" }}
              />
            </Stack>
            <Stack
              sx={{
                flexDirection: "row",
                justifyContent: "space-between",
                width: "30%",
                borderRadius: "10px",
                alignItems: "center",
                padding: "3px 5px",
                boxShadow: "rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset"
              }}
            >
              <Typography variant="caption">Unit Price</Typography>
              <Chip
                label=" 89%"
                sx={{ background: "#30B5A1", color: "white" }}
              />
            </Stack>
          </Stack>
        </Stack>

        <Stack
          sx={{
            backgroundColor: "white",
            height: "200px",
            padding: "15px",
            gap: 2,
            boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
            borderRadius:'20px' 
          }}
        >
          <Stack
            sx={{
              fontWeight: "bold",
              flexDirection: "row",
              gap: 2,
              justifyContent: "space-between",
            }}
          >
            <Stack sx={{ flexDirection: "row", gap: 2 }}>
              Forecast Accuracy Metrics
              <InfoIcon />
            </Stack>
            <Stack sx={{ flexDirection: "row", gap: 3 }}>
              <CustomOutlineButton
                btnText={"Recalculate"}
              />
              <CustomButton
                btnText={"Download"}
              />
            </Stack>
          </Stack>
          <Divider sx={{ border: "1px solid black" }} />
          <Stack
            sx={{
              flexDirection: "row",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
              padding: "30px 0px",
            }}
          >
            <WarningAmberIcon sx={{ color: "red" }} />
            <Typography sx={{ fontSize: "14px" }}>
              Please contact your data admin to update outbond+_order line data
              for the recently closed time window and click on 'Recalculate' to
              compute Accuracy metrics
            </Typography>
          </Stack>
        </Stack>
      </Stack>
    </>
  );
};

export default Overview;
