import React from "react";
import Chart from "./Chart";
import {
  Box,
  Card,
  Chip,
  Divider,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Switch,
  TextField,
  Typography,
} from "@mui/material";
// import { Button } from 'react-bootstrap';
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import RemoveRedEyeOutlinedIcon from "@mui/icons-material/RemoveRedEyeOutlined";
import PanoramaFishEyeOutlinedIcon from "@mui/icons-material/PanoramaFishEyeOutlined";
import CustomButton, {
  CustomOutlineButton,
} from "../../../components/CustomButton";
import DemandAccordion from "./DemandAccordion";

const label = { inputProps: { "aria-label": "Switch demo" } };

const data = {
  labels: [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "sep",
    "oct",
    "Nov",
    "Dec",
  ],
  datasets: [
    {
      label: "First dataset",
      data: [33, 53, 85, 41, 44, 65, 20, 55, 77, 90, 60, 40],
      fill: false,
      backgroundColor: "blue",
      borderColor: "blue",
    },
  ],
};

const options = {
  responsive: true,
  plugins: {
    legend: {
      position: "top",
    },
    title: {
      display: true,
      text: "",
      fontSize: 20,
    },
  },
  scales: {
    x: {
      title: {
        display: false,
        text: "Time",
        color: "#000000",
        font: {
          size: 20,
          weight: "bold",
        },
      },
      ticks: {
        maxRotation: 45,
        minRotation: 45,
        color: "#000000",
        font: {
          weight: "bold",
        },
        maxTicks: 12,
      },
    },
    y: {
      title: {
        display: false,
        text: "Value",
        color: "#000000",
        font: {
          size: 20,
          weight: "bold",
        },
      },
    },
  },
};

const measuresData = [
  {
    id: 1,
    name: "Median Demand",
  },
  {
    id: 2,
    name: "Demand plan",
  },
  {
    id: 3,
    name: "Actual Demand",
  },
  {
    id: 4,
    name: "Prior Year",
  },
];
const Demands = () => {
  const [age, setAge] = React.useState("");

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  return (
    <Box>
      <Card
        sx={{
          display: "flex",
          justifyContent: "space-between",
          padding: " 10px 20px ",
          textAlign: "center",
          alignItems: "center",
          marginBottom: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          borderRadius: "20px",
        }}
      >
        <Stack
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "10px",
          }}
        >
          <Typography variant="body1" fontWeight={600}>
            Demand Plan
          </Typography>
          <Chip size="small" label="Active" sx={{ background: "#fff",  boxShadow: "#30B5A1 2px 5px 10px inset", fontWeight:"600",fontSize:'9px' }} />
        </Stack>
        <Stack
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "5px",
          }}
        >
          <Typography variant={"caption"}>
            Last Plan Generated : 2/12/2024
          </Typography>
          <CustomOutlineButton
            btnText={"Export"}
            styles={{
              variant: "outlined",
              textTransform: "capitalize",
              padding: "3px 15px",
            }}
          />
          <CustomButton
            btnText={"Publish"}
            styles={{ textTransform: "capitalize", padding: "3px 15px" }}
          />
        </Stack>
      </Card>
      <Card
        sx={{
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          borderRadius: "20px",
          p: "10px",
        }}
      >
        <Stack sx={{ flexDirection: "row", alignItems: "center", gap: 5, justifyContent: "flex-end", padding: "10px 10px" }}  >
          <CustomButton btnText={"Change Category/Product"} />
        </Stack>
        <Divider sx={{ border: "1px solid black" }} />

        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            padding: "20px",
            alignItems: "center",
            gap: "5px",
          }}
        >
          <Box>
            <Typography sx={{ fontWeight: 600 }}>
              Total Demand: 66,282
            </Typography>
            <Typography>Period: 9/1/2023-4/1/2024</Typography>
          </Box>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "end",
              gap: "10px",
            }}
          >
            <Box>
              <Typography sx={{ fontSize: "12px" }}>Time interval</Typography>
              <FormControl fullWidth size="small" sx={{ width: "100px" }}>
                <InputLabel id="demo-simple-select-label">Months</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={age}
                  label="Months"
                  onChange={handleChange}
                >
                  <MenuItem value={10}>Month</MenuItem>
                  <MenuItem value={20}>Week</MenuItem>
                  <MenuItem value={30}>Day</MenuItem>
                </Select>
              </FormControl>
            </Box>
            <Box>
              <Typography sx={{ fontSize: "12px" }}>
                Planning horizon start
              </Typography>
              <TextField
                id="outlined-basic"
                variant="outlined"
                type="date"
                size="small"
              />
            </Box>
            <Box>
              <Typography sx={{ fontSize: "12px" }}>
                Planning horizon end
              </Typography>
              <TextField
                id="outlined-basic"
                variant="outlined"
                type="date"
                size="small"
              />
            </Box>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                paddingRight: "7px",
                borderRadius: "6px",
                border: "1px solid lightgray",
                height: "fit-content",
              }}
            >
              <Switch {...label} defaultChecked />
              <Typography>Graph</Typography>
            </Box>
          </Box>
        </Box>

        <Stack sx={{ display: "flex", flexDirection: "row", width: "100%" }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              padding: "15px",
              width: "300px",
              justifyContent: "start",
              backgroundColor: "lightgray",
              gap: "6px",
            }}
          >
            <Box
              sx={{ display: "flex", gap: 4, justifyContent: "space-between" }}
            >
              <Typography sx={{ fontWeight: "600" }}>Measures</Typography>
              <InfoOutlinedIcon />
            </Box>
            {measuresData.map((val) => {
              return (
                <Typography
                  variant="caption"
                  sx={{
                    border: "1px solid gray",
                    width: "fit-content",
                    background: "#fff",
                    padding: "2px 6px",
                    borderRadius: "8px",
                  }}
                  key={val.id}
                >
                  {" "}
                  <PanoramaFishEyeOutlinedIcon /> {val.name}{" "}
                  <RemoveRedEyeOutlinedIcon />{" "}
                </Typography>
              );
            })}
          </Box>
          <Box sx={{ width: "100%" }}>
            <Chart data={data} options={options} />
          </Box>
        </Stack>
        <DemandAccordion />
      </Card>
    </Box>
  );
};

export default Demands;