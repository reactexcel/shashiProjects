import React, { useState } from "react";
import {
  Box,
  Button,
  FormControl,
  MenuItem,
  OutlinedInput,
  Select,
  Stack,
} from "@mui/material";
import Table from "./InsightTable/Table";
import ListIcon from "@mui/icons-material/List";
import InsightCardsTable from "./InsightsCardsTable/InsightCardsTable";
import Chip from "@mui/material/Chip";
import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import CustomButton, { FloatingButton } from "../../../components/CustomButton";
import EditIcon from '@mui/icons-material/Edit';

const top100Films = [
  { title: "All Risk", year: 1994 },
  { title: "All statuses", year: 1972 },
  { title: "Largest devision", year: 1974 },
  { title: "sonest impact", year: 1994 },
  { title: "Gladiator", year: 2000 },
  { title: "The Great Dictator", year: 1940 },
  { title: "Cinema Paradiso", year: 1988 },
  { title: "The Lives of Others", year: 2006 },
  { title: "Grave of the Fireflies", year: 1988 },
  { title: "Paths of Glory", year: 1957 },
  { title: "Django Unchained", year: 2012 },
  { title: "The Shining", year: 1980 },
  { title: "WALL·E", year: 2008 },
  { title: "American Beauty", year: 1999 },
];

const Insights = () => {
  const [renderComponent, setrenderComponent] = useState("cards");

  const fixedOptions = [top100Films[6]];
  const [value, setValue] = React.useState([...fixedOptions, top100Films[13]]);

  return (
    <Stack spacing={2}>
      <Stack
        bgcolor={"white"}
        direction={"row"}
        sx={{
          justifyContent: "space-between",
          p: "10px 20px",
          mb: "10px",
          alignItems: "center",
          borderRadius: "15px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        }}
      >
        <FormControl
          sx={{ borderRadius: "20px", width: { md: "50%", lg: "75%" } }}
          size="small"
        >
          <Select
            labelId="demo-select-small-label"
            id="demo-select-small"
            defaultValue={10}
          >
            <MenuItem value={10}>
              Inventory Insights for Southest / Parts 8{" "}
            </MenuItem>
            <MenuItem value={20}>
              Inventory Risk Insights for Atlanata DC / Produce
            </MenuItem>
          </Select>
        </FormControl>
    
        <FloatingButton color="secondary" label="edit" icon={<EditIcon fontSize={"20px"} />} size="small" />
        <CustomButton
          btnText={"+ New Insight Watchlist"}
          styles={{ padding: "7px 15px", fontSize: "12px" }}
          onClick={() => console.log("clickme")}
        />
      </Stack >

      <Stack
        sx={{
          flexDirection: { md: "column", lg: "row" },
          justifyContent: "space-between",
          backgroundColor: "white",
          height: { md: "100px", lg: "70px" },
          alignItems: { md: "start", lg: "center" },
          padding: "25px",
          borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        }}
      >
        <Box sx={{ position: "relative",}}>
          <SearchOutlinedIcon
            sx={{
              position: "absolute",
              left: 5,
              top: "22%",
              color: "#00000042",
            }}
          />
          <OutlinedInput
            placeholder="Search"
            sx={{
              height: "40px",
              "& .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input": {
                padding: "9px 36px",
              },
            }}
          />
        </Box>
        <Stack direction={'row'} sx={{justifyContent: "space-between" }}>
          <Autocomplete
            sx={{ mr: 2 }}
            multiple
            value={value}
            onChange={(event, newValue) => {
              setValue([
                ...fixedOptions,
                ...newValue.filter(
                  (option) => fixedOptions.indexOf(option) === -1
                ),
              ]);
            }}
            options={top100Films}
            getOptionLabel={(option) => option.title}
            renderTags={(tagValue, getTagProps) =>
              tagValue.map((option, index) => (
                <Chip
                  key={index}
                  label={option.title}
                  {...getTagProps({ index })}
                  disabled={fixedOptions.indexOf(option) !== -1}
                />
              ))
            }
            renderInput={(params) => <TextField {...params} label="Show" />}
          />
          <Stack
            sx={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >

            <Button
              size="small"
              onClick={() => setrenderComponent("cards")}
              sx={{
                flexDirection: "row",
                color: `${renderComponent === "cards" ? "" : "white"} `,
                boxShadow: `${renderComponent === "cards" ? "#c7e2de 2px 3px 3px  3px inset" : ""}`, background: `${renderComponent === "cards" ? "" : "#30B5A1"} `,
                "&:hover": {
                  background: renderComponent !== "card" ? "lightblue" : "",
                  color: "white"
                }
              }}
            >
              <ListIcon /> Card
            </Button>

            <Button
              size="small"
              onClick={() => setrenderComponent("Table")}
              sx={{
                flexDirection: "row",
                color: `${renderComponent === "cards" ? "white" : ""} `,
                boxShadow: `${renderComponent === "cards" ? "" : "#c7e2de 2px 3px 3px  3px inset"}`, background: `${renderComponent === "cards" ? "#30B5A1" : ""}`,
                "&:hover": {
                  background: renderComponent !== "card" ? "lightblue" : "",
                  color: "white"
                }
              }}
            >
              <ListIcon /> Table
            </Button>
          </Stack>
        </Stack>
      </Stack>
      <Box>
        {renderComponent === "cards" ? (
          <InsightCardsTable />
        ) : renderComponent === "Table" ? (
          <Table />
        ) : null}
      </Box>
    </Stack >
  );
};

export default Insights;
