
//react bootstrap import
import Card from "react-bootstrap/Card";
import Form from "react-bootstrap/Form";
import { Image } from "react-bootstrap";


// MUI import 
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import ButtonGroup from "@mui/material/ButtonGroup";
import HighlightOutlinedIcon from '@mui/icons-material/HighlightOutlined';
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import WarningAmberOutlinedIcon from "@mui/icons-material/WarningAmberOutlined";
import LocationOnOutlinedIcon from "@mui/icons-material/LocationOnOutlined";
import ViewInArOutlinedIcon from "@mui/icons-material/ViewInArOutlined";
import VolunteerActivismOutlinedIcon from '@mui/icons-material/VolunteerActivismOutlined';
import QueryStatsOutlinedIcon from '@mui/icons-material/QueryStatsOutlined';
import AutoGraphRoundedIcon from '@mui/icons-material/AutoGraphRounded';
import AccessAlarmsRoundedIcon from '@mui/icons-material/AccessAlarmsRounded';
import { Chip, Divider, Stack, Typography } from "@mui/material";
import UpdateOutlinedIcon from '@mui/icons-material/UpdateOutlined';
import AssistantOutlinedIcon from '@mui/icons-material/AssistantOutlined';


//internal files
import binoculars from "../../../assets/img1/binoculars.svg";
import earth from "../../../assets/img1/earth.svg";
import map from "../../../assets/img1/static/map.png";
import cube from "../../../assets/img1/static/cube.png";
import chat from "../../../assets/img1/static/chat.png";
import CustomButton from "../../../components/CustomButton";
import './MainHomecss.css'


const Products = [
  {
    name: "All Products",
    value: "136",
    color: "#d573d3",
  },
  {
    name: "Balanced",
    value: "136",
    color: "#30B5A1"
  },
  {
    name: "Stock Out Risk",
    value: "0",
    color: "#58a9e8"
  },
  {
    name: "Excess Stock Risk",
    value: "0",
    color: "#5eb56a"

  },
];

const MainHome = () => {

  return (
    <Stack spacing={2}>
      <Stack direction={'row'} sx={{
        display: "flex",
        justifyContent: "space-between",
        bgcolor: "white",
        padding: "10px",
        marginBottom: "15px",
        alignItems: "center",
        boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
        borderRadius: '15px'
      }}>
        <Typography variant="body1" fontWeight={"600"}>
          Good Afternoon, Abhinav
        </Typography>

        <CustomButton
          btnText={"Manage Dashboard"}
          styles={{ padding: "3px 13px", fontSize: "12px" }}
          onClick={() => console.log("clickme")}
        />
      </Stack>

      <Stack spacing={2} >
        <Stack direction={'row'} spacing={2}>
          <Card className="w-50 card_container" style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }}>
            <Card.Body>
              <Box
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "start",
                  alignItems: "center",
                  gap: "5px",
                }}
              >
                <Box>
                  <Image src={binoculars} />
                </Box>
                <Box>
                  <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                    Insights
                  </Typography>
                </Box>
              </Box>
              <Divider sx={{ border: "1px solid gray", margin: "20px 0px" }} />
              <Card.Text>Watchlist</Card.Text>
              <Form.Select aria-label="Default select example">
                <option>Test</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </Form.Select>
              <div style={{ margin: "20px", paddingTop: "20px" }}>
                <Card.Title
                  style={{
                    fontWeight: "bold",
                    textAlign: "center",
                    fontSize: "15px",
                  }}
                >
                  Scanning for insights.
                </Card.Title>
                <Card.Text
                  style={{ color: "gray", textAlign: "center", fontSize: "12px" }}
                >
                  Some quick example text to build on the card title and
                </Card.Text>
              </div>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <CustomButton
                  btnText={"Open Insights"}
                  styles={{ padding: "3px 13px", fontSize: "12px" }}
                  onClick={() => console.log("clickme")}
                />
              </Box>
            </Card.Body>
          </Card>

          <Card className="w-100 card_container" style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }}>
            <Card.Body>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "row",
                    gap: "5px",
                    alignItems: "center",
                  }}
                >
                  <div style={{ marginBottom: "12px" }}>
                    <Image src={earth} />
                  </div>
                  <Card.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
                    Inventory Health
                  </Card.Title>
                </div>

                <ButtonGroup>
                  <Button variant="secondary">
                    <LocationOnOutlinedIcon fontSize={"16"} />
                  </Button>
                  <Button sx={{ background: "#30B5A1", outline: "none", border: "none" }}>
                    <ViewInArOutlinedIcon fontSize={"16"} sx={{
                      color: "#fff", "&hover": {
                        color: "#30B5A1"
                      }
                    }} />
                  </Button>
                </ButtonGroup>
              </div>
              <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  gap: "15px",
                  justifyContent: "space-around",
                  textAlign: "start",
                  alignItems: 'center'
                }}
              >
                <Image src={map} width={300} height={200} style={{ borderRadius: "10px" }} />
                <Stack sx={{
                  padding: '11px',
                  boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
                  background: '#6633991a',
                  borderRadius: '20px',
                  width: 220
                }}
                >
                  <Typography style={{ fontSize: "16px", fontWeight: "bold" }}>
                    Products in view
                  </Typography>
                  <Divider
                    sx={{ border: "1px solid gray", margin: "5px 0px 10px" }}
                  />

                  <Box style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                    {Products.map((item, i) => (
                      <div
                        key={i}
                        style={{
                          background: "lightgrey",
                          borderRadius: "10px",
                          textAlign: "start",
                          fontSize: "14px",
                          padding: "5px 10px",
                          display: "flex",
                          justifyContent: "space-between",
                          alignItems: "center"

                        }}
                      >
                        <Typography variant="caption">{item.name}</Typography>{" "}
                        <Chip sx={{ background: `${item.color}`, color: '#fff', width: "40px", fontSize: "10px" }} size="small" label={item.value} />
                      </div>
                    ))}
                  </Box>
                  <Box sx={{ marginTop: "10px", display: "flex ", justifyContent: "center" }}>
                    <CustomButton
                      btnText={"Open Map"}
                      styles={{ padding: "3px 13px", fontSize: "12px" }}
                      onClick={() => console.log("clickme")}
                    />
                  </Box>
                </Stack>
              </div>
            </Card.Body>
          </Card>

          <Card style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }} className="w-50 card_container">
            <Card.Body>
              <Stack
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }}
                spacing={3}
              >
                <Box sx={{ display: "flex", alignItems: "center", textAlign: "left", width: "100%" }}>
                  <HighlightOutlinedIcon />
                  <Typography sx={{ fontSize: "15px", fontWeight: "bold" }}>Inventory Visibility</Typography>
                </Box>
                <Divider sx={{
                  border: "1px solid gray", width: "100%"
                }} />
                <Image
                  src={cube}
                  width={200}
                  style={{ borderRadius: "10px", margin: "15px" }}
                />
                <Box sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }} >
                  <Card.Text style={{ fontWeight: "bold", fontSize: "14px" }}>
                    Checkout Inventory visibility
                  </Card.Text>
                  <CustomButton
                    btnText={"View Inventory"}
                    styles={{ padding: "3px 13px", fontSize: "12px" }}
                    onClick={() => console.log("clickme")}
                  />
                </Box>
              </Stack>
          </Card.Body>
        </Card>
        </Stack>
        <Stack direction={'row'} spacing={2}>



          <Card style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }} className="w-100 card_container" >
          <Card.Body>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "start",
                alignItems: "center",
                gap: "5px",
              }}
            >
              <div style={{ marginBottom: "12px" }}>
                  <VolunteerActivismOutlinedIcon />
              </div>
              <Card.Title style={{ fontSize: "15px", fontWeight: "bold" }}>
                Connection Health
              </Card.Title>
            </div>
              <div style={{ fontSize: "13px", color: "gray", margin: "0px 0px 10px 0px " }}>
                <UpdateOutlinedIcon />
                Last 24 hours</div>

            <div style={{ fontSize: "12px", color: "gray" }}>
              Select Connection
            </div>
            <Form.Select aria-label="Default select example">
              <option>All</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </Form.Select>
          </Card.Body>
        </Card>

          <Card style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }} className="w-100 card_container">
          <Card.Body>
              <Box
              style={{
                display: "flex",
                flexDirection: "row",
                  justifyContent: "flex-start",
                alignItems: "center",
                gap: "5px",
              }}
            >

                <QueryStatsOutlinedIcon />
                <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                  Supply data
                </Typography>
              </Box>

              <div style={{ marginTop: "20px", width: "100%" }}>
                <Typography variant="subtitle2">
                  You are a couple of steps closer to a healthier supply chain.
                </Typography>
            </div>
          </Card.Body>
        </Card>
          <Card style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }} className="w-100 card_container">
          <Card.Body>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                  justifyContent: "flex-start",
                alignItems: "center",
                gap: "5px",
              }}
            >
                <AutoGraphRoundedIcon />
                <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                  Progress
                </Typography>
            </div>

            <div
              style={{
                display: "flex",
                flexDirection: "row",
                justifyContent: "center",
                alignItems: "center",
              }}
            >

              <Image
                src={chat}
                width={150}
                style={{ borderRadius: "10px", margin: "15px" }}
              />
              <Box>
                  <Card.Text style={{ fontWeight: "bold", fontSize: "14px" }}>
                    Start a conversation
                  </Card.Text>
                  <CustomButton
                    btnText={"Go to Collaboration"}
                    styles={{ padding: "3px 13px", fontSize: "12px" }}
                    onClick={() => console.log("clickme")}
                  />

              </Box>
            </div>
          </Card.Body>
        </Card>
        </Stack>


        <Stack direction={{ md: 'row', xs: 'column' }} spacing={2} sx={{ height: '200px' }} >
          <Card className="w-100 card_container" style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: "25px" }}>
          <Card.Body>
              <Box sx={{ display: "flex", justifyContent: "flex-start", gap: 1 }}>
                <AssistantOutlinedIcon />
                <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                    Supplier Fill Rate
                </Typography>
              <InfoOutlinedIcon />
            </Box>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                height: "80%",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <WarningAmberOutlinedIcon />
                  <Typography sx={{ fontSize: '14px', fontWeight: 'bold' }}>
                  Insufficient data
                </Typography>
              </div>
                <Typography variant="caption" sx={{ fontSize: '10px' }}>
                Click info icon for more details
              </Typography>
            </div>
          </Card.Body>
        </Card>

          <Card className="w-100 card_container" style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: '25px' }} >
          <Card.Body>
            <Box sx={{ display: "flex", justifyContent: "space-between" }}>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  gap: "5px",
                }}
              >
                <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                    Sell Through Rate
                </Typography>
              </div>
              <InfoOutlinedIcon />
            </Box>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                height: "80%",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <WarningAmberOutlinedIcon />
                  <Typography sx={{ fontSize: '14px', fontWeight: 'bold' }}>
                  Insufficient data
                </Typography>
              </div>
                <Typography variant="caption" sx={{ fontSize: '10px' }}>
                Click info icon for more details
              </Typography>
            </div>
          </Card.Body>
        </Card>

          <Card className="w-100 card_container" style={{ boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: '25px' }}>
          <Card.Body>
            <Box sx={{ display: "flex", justifyContent: "space-between" }}>
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  alignItems: "center",
                  gap: "5px",
                }}
              >
                  <AccessAlarmsRoundedIcon />
                <Typography style={{ fontSize: "15px", fontWeight: "bold" }}>
                    Order Cycle Time
                </Typography>
              </div>
              <InfoOutlinedIcon />
            </Box>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
                height: "80%",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <WarningAmberOutlinedIcon />
                  <Typography sx={{ fontSize: '14px', fontWeight: 'bold' }}
                >
                  Insufficient data
                </Typography>
              </div>
                <Typography variant="caption" sx={{ fontSize: '10px' }}>
                Click info icon for more details
              </Typography>
            </div>
          </Card.Body>
        </Card>
        </Stack>



      </Stack>

    </Stack>
  );
};

export default MainHome;
