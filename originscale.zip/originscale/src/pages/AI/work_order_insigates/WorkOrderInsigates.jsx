import { Card, Typography } from "@mui/material"

const WorkOrderInsigates = () => {
  return (
    <div>
      <Card
        sx={{
          display: "flex",
          boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: '15px'
        }}
      >
        <Typography variant="body1" sx={{ padding: "10px 20px", fontSize: "18px", fontWeight: "600" }}>
          Work Order Insigates
        </Typography>
      </Card>
    </div>
  )
}

export default WorkOrderInsigates
