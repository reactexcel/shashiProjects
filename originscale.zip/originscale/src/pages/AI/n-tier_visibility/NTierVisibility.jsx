import { Card, Typography } from "@mui/material"

const NTierVisibility = () => {
  return (
    <div>
      <Card
        sx={{
          display: "flex",
          boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: '15px'
        }}
      >
        <Typography variant="body1" sx={{ padding: "10px 20px", fontSize: "18px", fontWeight: "600" }}>
          N-Tier Visibility
        </Typography>
      </Card>
    </div>
  )
}

export default NTierVisibility
