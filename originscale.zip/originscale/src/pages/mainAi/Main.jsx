import { Outlet} from "react-router-dom"
import SideBar from "../../components/sideBar/SideBar"
import Footer from "../../components/footer/Footer"
import { Box, Stack } from "@mui/material"

const Main = () => {
  return (
    <Box>
      <SideBar SideBarpages={<Stack spacing={2} sx={{ height: "100vh" }}>
        <div style={{ flex: 1 }}>
          <Stack spacing={2} sx={{ height: "100%", justifyContent: "space-between" }}>
            <Outlet />
            <Footer />
          </Stack>
        </div>
      </Stack>} />

    </Box>
  )
}

export default Main


