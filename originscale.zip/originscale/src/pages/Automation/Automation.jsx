const Automation = () => {
  return (
    <div>
        i am Automation page      
    </div>
  )
}

export default Automation
