const Product = () => {
  return (
    <div>
      I am Product page
    </div>
  )
}

export default Product
