const Bundle = () => {
  return (
    <div>
        I am Bundle page      
    </div>
  )
}

export default Bundle
