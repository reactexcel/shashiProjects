const StockTransfer = () => {
  return (
    <div>
        I am Stock Transfer page     
    </div>
  )
}

export default StockTransfer
