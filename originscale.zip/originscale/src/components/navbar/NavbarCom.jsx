import Navbar from "react-bootstrap/Navbar";
import sell from "../../assets/img1/sell.svg";
import make from "../../assets/img1/make.svg";
import source from "../../assets/img1/source.svg";
import trace from "../../assets/img1/trace.svg";
import inventory from "../../assets/img1/inventory.svg";
import kit from "../../assets/img1/kit.svg";
import stocktransfer from "../../assets/img1/stocktransfer.svg";
import automation from "../../assets/img1/automation.svg";
import { Dropdown } from "react-bootstrap";
import { Link, NavLink } from "react-router-dom";
import Ai from "../../assets/img1/ai.svg";
import { useState } from "react";
import logo from "../../assets/img1/logo.svg";
import { AppBar, Box, IconButton, Stack, Toolbar } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";

function NavbarCom({ hanldeToggleDrawer }) {
  const AppBarData = [
    { name: "Sell", icon: sell, path: "sell" },
    { name: "Make", icon: make, path: "make" },
    { name: "Procure", icon: source, path: "Procure" },
    { name: "Finance", icon: trace, path: "finance" },
    { name: "Inventory", icon: inventory, path: "inventory" },
    { name: "Automation", icon: automation, path: "automation" },
    { name: "Stock Transfer", icon: stocktransfer, path: "stock_transfer" },
    { name: "Bundle", icon: kit, path: "bundle" },
    { name: "A.I", icon: Ai, path: "ai" },
  ];
  return (
    <AppBar style={{ zIndex: 2, width: "100%" }} sx={{ background: "white" }}>
      <Toolbar>
        <Navbar.Brand>
          <Link to={"/"}>
            <img src={logo} alt="OriginScale" width={"150px"} height={"70px"} />
          </Link>
        </Navbar.Brand>
        <IconButton
          onClick={hanldeToggleDrawer}
          size="medium"
          sx={{ display: { md: "none", xs: "block" }, ml: "auto" }}
        >
          <MenuIcon />
        </IconButton>
        <Stack
          direction={"row"}
          spacing={0.5}
          sx={{
            display: { md: "flex", xs: "none" },
            ml: "auto",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          {AppBarData.map((e, index) => {
            return (
              <NavLink
                to={e.path}
                key={index}
                className={({ isActive }) =>
                  `${isActive ? "nav-link2" : ""} nav-link`
                }
                style={{
                  fontWeight: 400,
                  textDecoration: "none",
                }}
              >
                <div className="text-center px-2 ">
                  <img style={{ width: "15px" }} src={e.icon} />
                  <p className="m-0">{e.name}</p>
                </div>
              </NavLink>
            );
          })}
          <Dropdown>
            <Dropdown.Toggle className="border " id="dropdown-basic">
              Add New
            </Dropdown.Toggle>

            <Dropdown.Menu>
              <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
              <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
              <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </Stack>
      </Toolbar>
    </AppBar>
  );
}

export default NavbarCom;
