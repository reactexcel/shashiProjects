import { useState } from "react";
import { GoHome } from "react-icons/go";
import { GoTelescope } from "react-icons/go";
import { FiBox } from "react-icons/fi";
import { RiMapPinRangeLine } from "react-icons/ri";
import { TbAlignBoxBottomRight } from "react-icons/tb";
import { IoIosListBox } from "react-icons/io";
import { CgMenuBoxed } from "react-icons/cg";
import { MdDataExploration } from "react-icons/md";
import { BsBullseye } from "react-icons/bs";
import { FaCalendarAlt } from "react-icons/fa";
import "./sidebar.css";
import { NavLink, useLocation } from "react-router-dom";
import { Box, Typography } from "@mui/material";
const SideBar = ({ SideBarpages }) => {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();
  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };
  const sidebarItems = [
    { Icon: GoHome, name: "Home",path:"" },
    { Icon: GoTelescope, name: "Insights", path: "insights" },
    { Icon: FiBox, name: "Inventory visibility", path: "inventory_visibility" },
    { Icon: RiMapPinRangeLine, name: "Network Map", path: "network_map" },
    {
      Icon: IoIosListBox,
      name: "Work order insigates",
      path: "work_order_insigates",
    },
    {
      Icon: TbAlignBoxBottomRight,
      name: "Demand Planing",
      path: "demand_planing",
    },
    { Icon: CgMenuBoxed, name: "Supply Planing", path: "supply_planing" },
    { Icon: MdDataExploration, name: "Sustainability", path: "sustainability" },
    { Icon: BsBullseye, name: "Data lake", path: "data_lake" },
    {
      Icon: FaCalendarAlt,
      name: "N-Tier visibility",
      path: "n-tier_visibility",
    },
  ];

  return (
    <Box
      className={`s-layout ${isOpen ? "s-sidebar-open" : ""}`}
    >
      <Box>
        <Box
          className="s-sidebar__nav"
        >
          <Box sx={{ md: "block", xs: "none" }}>
            <a
              className={`s-sidebar__trigger ${
                isOpen ? "start" : "end"
                } ms-auto `}
              onClick={toggleSidebar}
              style={{ transform: `${!isOpen ? "rotate(180deg)" : ""}` }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="30"
                height="30"
                fill="currentColor"
                className={`bi bi-caret-left-square-fill text-white ${isOpen} ? "mx-lg-4 "  : ""`}
                viewBox="0 0 16 16"
              >
                <path d="M0 2a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2zm10.5 10V4a.5.5 0 0 0-.832-.374l-4.5 4a.5.5 0 0 0 0 .748l4.5 4A.5.5 0 0 0 10.5 12" />
              </svg>
            </a>
          </Box>
          <ul>
            {sidebarItems.map((item, index) => (
              <li key={index}>
                <NavLink
                  to={item.path}
                  style={{
                    width: "100%",
                    display: "flex",
                    alignItems: "center",
                    padding: "10px",
                    gap: 23,
                    transition:'all .2s ease-out',
                  }}
                  className={` ${location.pathname ===
                    (index === 0 ? "/ai" + item.path : "/ai/" + item.path)
                    ? "active-sidebar"
                    : "pending"
                    }`}
                >
                  <item.Icon style={{ fontSize: "30px" }} />
                  <Typography style={{ alignSelf: "center", margin: "0" }}>
                    {item.name}
                  </Typography>
                </NavLink>
              </li>
            ))}
          </ul>
        </Box>
      </Box>
      <Box
        sx={{
          position: "relative",
          overflowX: "hidden",
          background: "#b6b6d552",
          p: "20px",
          overflowY: "scroll",
        }}
        className="s-layout__content"
      >
        {SideBarpages}
      </Box>
    </Box>
  );
};
export default SideBar;
