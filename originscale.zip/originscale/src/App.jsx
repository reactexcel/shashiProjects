import { Box, Stack } from "@mui/material";
import "./App.css";
import { Outlet } from "react-router-dom";
import NavbarCom from "./components/navbar/NavbarCom";
import { useState } from "react";

const App = () => {
  const [Drawer, setDrawer] = useState(false);
  return (
    <Stack>
      <NavbarCom hanldeToggleDrawer={()=>setDrawer(!Drawer)} />
      <Box pt={9}>
        <Outlet />
      </Box>
    </Stack>
  );
};

export default App;
