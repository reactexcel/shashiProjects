import Button from "@mui/material/Button";
import React from "react";
import Fab from '@mui/material/Fab';

const CustomButton = ({
     styles,
     variant,
     btnText,
     onClick,
     start_icon,
     end_icon,
}) => {
     return (
          <>
               <Button
                    sx={{
                         ...styles,
                         background: "#30B5A1",
                         color: "#fff",
                         outline: "none",
                         transition: "none",
                         border: "none",
                         textTransform: "capitalize",
                         "&:hover": {
                              background: "#fff",
                              color: "#30B5A1",
                              border: "1px solid #30B5A1",
                         },
                    }}
                    variant={variant ? variant : "outlined"}
                    startIcon={start_icon}
                    endIcon={end_icon}
                    onClick={onClick}
               >
                    {btnText && btnText}
               </Button>
          </>
     );
};

export const CustomOutlineButton = ({
     styles,
     variant,
     btnText,
     onClick,
     start_icon,
     end_icon,
}) => {
     return (
          <>
               <Button
                    sx={{
                         ...styles,
                         transition: "none",
                         textTransform: "capitalize",
                         background: "#fff",
                         color: "#30B5A1",
                         border: "1px solid #30B5A1",
                    }}
                    variant="outlined"
                    startIcon={start_icon}
                    endIcon={end_icon}
                    onClick={onClick}
               >
                    {btnText && btnText}
               </Button>
          </>
     );
};

export const FloatingButton = ({ icon, label, color, size }) => {
     return (
          <Fab color={color} aria-label={label} size={size}>
               {icon}
          </Fab>
     )
}


export default CustomButton;
