const Footer = () => {
  return (
    <footer style={{boxShadow: 'rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px',display:'flex',alignItems:'center',padding:'12px',width: '100%',alignSelf:'center',backgroundColor:"white",borderRadius:'10px'}}
    
  >
    <div>
      <p className='m-0' >
        &copy; {1900 + new Date().getYear()}{" "}
        <a href="https://www.originscale.io/" style={{color:'#11bfe3'}} target="_blank">originscale</a>
      </p>
    </div>
  </footer>
  )
}

export default Footer
