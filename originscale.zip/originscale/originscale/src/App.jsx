import { Box, Stack } from "@mui/material";
import "./App.css";
import Dashboard from "./pages/dashboard";
import { Outlet } from "react-router-dom";
import NavbarCom from "./components/navbar/NavbarCom";
import { useState } from "react";
import SideBar from "./components/sideBar/SideBar";
import Footer from "./components/footer/Footer";

const App = () => {
  const [Drawer, setDrawer] = useState(false);
  return (
    <Stack>
      <NavbarCom hanldeToggleDrawer={()=>setDrawer(!Drawer)} />
      <Box pt={9}>
        <Box 
        // sx={{ display: { md: "block", xs: "none" } }}
        >
          <Outlet />
        </Box>
        {/* <Box sx={{ display: { md: "none", xs: "block" } }}>
        <SideBar
          SideBarpages={
            <>
              <div>
                <Outlet />
              </div>
              <Footer />
            </>
          }
          Drawer={Drawer}
        />
      </Box> */}
      
      </Box>
      
    </Stack>
  );
};

export default App;
