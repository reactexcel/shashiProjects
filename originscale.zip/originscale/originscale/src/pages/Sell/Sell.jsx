import React from 'react'

const Sell = () => {
  return (
    <div>
      I am sell page
    </div>
  )
}

export default Sell
