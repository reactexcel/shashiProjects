import * as React from 'react';
import PropTypes from 'prop-types';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Overview from './supplyPlannningCom/Overview';
import PurchaseOrder from './supplyPlannningCom/PurchaseOrder';
import { Stack } from '@mui/material';
import Replenishment from './supplyPlannningCom/Replenishment';
import PlanException from "./supplyPlannningCom/PlanException"

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Stack spacing={2} sx={{mt:'15px'}}>
          {children}
        </Stack>
      )}
    </div>
  );
}

CustomTabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function SupplyPlaning() {
  const [value, setValue] = React.useState(0);
  const TabData = ["Overview", "Purchase Order Requests", "Replenishment Plan", "Plan Exceptions"]
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%' }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', bgcolor: 'white', borderRadius: "10px", boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", }}>
        <Tabs variant='scrollable' value={value} onChange={handleChange} aria-label="basic tabs example" sx={{ paddingLeft: "10px" }}>
          {TabData.map((e, i) => {
            return <Tab key={i} sx={{ fontWeight: '600' }} label={e} {...a11yProps(i)} />
          })}
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <Overview />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <PurchaseOrder />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={2}>
        <Replenishment />
      </CustomTabPanel>
      <CustomTabPanel value={value} index={3}>
        <PlanException />
      </CustomTabPanel>
    </Box>
  );
}