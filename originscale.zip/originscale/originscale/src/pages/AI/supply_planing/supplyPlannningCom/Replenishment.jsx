import {  Stack, Typography } from '@mui/material'
import CustomButton from '../../../../components/CustomButton'

const Replenishment = () => {
  return (
    <Stack direction="row" bgcolor={'white'} sx={{ bgcolor: 'white',  p: 2, justifyContent: 'space-between', alignItems: 'center',            boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
    borderRadius:'20px'  }}>
      <Typography sx={{ fontWeight: 'bold', fontSize: '16px' }} >Select a product And site to view Plan Details</Typography>
      <CustomButton btnText="Change Product/Shite" />
    </Stack>
  )
}

export default Replenishment
