import { Box, OutlinedInput, Stack } from "@mui/material";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import  { FloatingButton } from "../../../../components/CustomButton";
import FilterAltIcon from "@mui/icons-material/FilterAlt";

const SupplyPlanningFilterCom = ({ handleFilter }) => {
  return (
    <Stack
      direction={"row"}
      width={"100%"}
      bgcolor={"white"}
      p={"10px 20px"}
      borderRadius={2}
      sx={{ justifyContent: "space-between", alignItems: "center",            boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px',
      borderRadius:'20px'  }}
    >
      <FloatingButton size="medium" color="secondary" label="filter" icon={<FilterAltIcon fontSize="24px" />} />
      <Box sx={{ position: "relative" }}>
        <SearchOutlinedIcon
          sx={{
            position: "absolute",
            left: 5,
            top: "22%",
            color: "#00000042",
          }}
        />

        <OutlinedInput
          placeholder="Search"
          sx={{
            height: "40px",
            "& .css-1t8l2tu-MuiInputBase-input-MuiOutlinedInput-input": {
              padding: "9px 36px",
            },
          }}
        />
      </Box>
    </Stack>
  );
};

export default SupplyPlanningFilterCom;
