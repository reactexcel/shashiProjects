import TextSnippetOutlinedIcon from "@mui/icons-material/TextSnippetOutlined";
import SupplyPlanningFilterCom from "./SupplyPlanningFilterCom";
import PurchaseOrderTable from "./PurchaseOrderTable";

const PurchaseOrder = () => {
  const columns = [
    { field: 'purchaseReqId', headerName: 'Purchase Request Id', width: 160 },
    { field: 'actions', headerName: 'Actions', width: 120 },
    { field: 'status', headerName: 'Status', width: 120 },
    { field: 'orderQuality', headerName: 'Order Quality', width: 150 },
    { field: 'product', headerName: 'Product', width: 120 },
    { field: 'site', headerName: 'Site', width: 120 },
    { field: 'orderValue', headerName: 'Order Value', width: 150 },
    { field: 'vendor', headerName: 'Vendor', width: 120 },
    { field: 'reviewBy', headerName: 'Review By', width: 120 },
    { field: 'orderBy', headerName: 'Order By', width: 120 },
    { field: 'expectedDelivery', headerName: 'Expected Delivery', width: 180 },
  ];

  const rows = [
    { id: 1, purchaseReqId: 'PR001', actions: 'Approve', status: 'Pending', orderQuality: 10, product: 'Product A', site: 'Site 1', orderValue: 500, vendor: 'Vendor X', reviewBy: 'John Doe', orderBy: 'Jane Doe', expectedDelivery: '2024-04-10' },
    { id: 2, purchaseReqId: 'PR002', actions: 'Reject', status: 'Rejected', orderQuality: 15, product: 'Product B', site: 'Site 2', orderValue: 700, vendor: 'Vendor Y', reviewBy: 'Alice Smith', orderBy: 'Bob Johnson', expectedDelivery: '2024-04-15' },
    { id: 3, purchaseReqId: 'PR003', actions: 'Review', status: 'In Progress', orderQuality: 20, product: 'Product C', site: 'Site 3', orderValue: 900, vendor: 'Vendor Z', reviewBy: 'Emily Brown', orderBy: 'David Wilson', expectedDelivery: '2024-04-20' },
  ];

  return (
    <>
      <SupplyPlanningFilterCom />
      <PurchaseOrderTable columns={columns} rows={rows} tableHeading={<><TextSnippetOutlinedIcon /> Product Order Request</>} />
    </>
  );
};

export default PurchaseOrder;
