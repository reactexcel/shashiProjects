import {
  Box,
  Button,
  Card,
  Chip,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import { BiSolidBinoculars } from "react-icons/bi";
import ArrowForwardOutlinedIcon from "@mui/icons-material/ArrowForwardOutlined";
import { Gauge, gaugeClasses } from "@mui/x-charts/Gauge";
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import InventoryOutlinedIcon from '@mui/icons-material/InventoryOutlined';
const Overview = () => {
  return (
    <Box>
      <Card
        variant="outlined"
        sx={{
          display: "flex",
          justifyContent: "space-between",
          bgcolor: "white",
          padding: "10px",
          marginBottom: "15px",
          alignItems: "center",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          borderRadius: "15px",
        }}
      >
        <Typography
          sx={{
            fontWeight: "600",
            textTransform: "capitalize",
            fontSize: "16px",
          }}
        >
          Current Supply Plan
        </Typography>
        <Typography variant="caption">
          Last Plan Generated: {new Date().toISOString()}
        </Typography>
      </Card>
      <Stack direction={"row"} marginBottom={2} gap={2}>
        <Card
          sx={{
            width: "600px",
            height: "250px",
            padding: "20px",
            borderRadius: "30px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          }}
        >
          <Typography sx={{ fontWeight: "bold" }}>Supply Network</Typography>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack direction={"row"} justifyContent={"space-between"}>
            <Typography>Products</Typography>
            <Typography fontWeight={"bold"}>52</Typography>
          </Stack>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack direction={"row"} justifyContent={"space-between"}>
            <Typography>Sites</Typography>
            <Typography fontWeight={"bold"}>3</Typography>
          </Stack>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack direction={"row"} justifyContent={"space-between"}>
            <Typography>Suppliers</Typography>
            <Typography fontWeight={"bold"}>3</Typography>
          </Stack>
        </Card>

        <Card
          sx={{
            width: "100%",
            height: "250px",
            padding: "20px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
            borderRadius: "30px",
          }}
        >
          <Typography sx={{ fontWeight: "bold" }}> <Inventory2OutlinedIcon/> Inventory & Order</Typography>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack
            direction={"row"}
            // spacing={2}
            sx={{
              width: "100%",
              height: "78%",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Stack
              sx={{
                height: "100%",
                width: "100%",
                justifyContent: "center",
              }}
            >
              <Stack>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  <Box bgcolor={"skyblue"} width={"10px"} height={"10px"} />
                  On-Hand Inventory
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontWeight: "bold", ml: 2 }}
                >
                  $0
                </Typography>
              </Stack>
              <Stack>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  <Box bgcolor={"yellow"} width={"10px"} height={"10px"} />
                  On-Order Inventory
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontWeight: "bold", ml: 2 }}
                >
                  $0
                </Typography>
              </Stack>
              <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
              <Stack sx={{ ml: 2 }}>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  Total Inventory
                </Typography>
                <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                  $0
                </Typography>
              </Stack>
            </Stack>

            <Stack sx={{ height: "100%", width: "100%" }}>
              <Gauge
                value={50}
                startAngle={0}
                endAngle={360}
                innerRadius="80%"
                outerRadius="100%"
              />
            </Stack>
          </Stack>
        </Card>
        <Card
          sx={{
            width: "100%",
            height: "250px",
            padding: "20px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
            borderRadius: "30px",
          }}
        >
          <Typography sx={{ fontWeight: "bold" }}><InventoryOutlinedIcon/>Purchase Plan</Typography>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack
            direction={"row"}
            // spacing={2}
            sx={{
              width: "100%",
              height: "78%",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Stack
              sx={{
                height: "100%",
                width: "100%",
                justifyContent: "center",
              }}
            >
              <Stack>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  <Box bgcolor={"skyblue"} width={"10px"} height={"10px"} />
                  On-Hand Inventory
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontWeight: "bold", ml: 2 }}
                >
                  $0
                </Typography>
              </Stack>
              <Stack>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  <Box bgcolor={"yellow"} width={"10px"} height={"10px"} />
                  On-Order Inventory
                </Typography>
                <Typography
                  variant="caption"
                  sx={{ fontWeight: "bold", ml: 2 }}
                >
                  $0
                </Typography>
              </Stack>
              <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
              <Stack sx={{ ml: 2 }}>
                <Typography
                  variant="body2"
                  sx={{ display: "flex", gap: 1, alignItems: "center" }}
                >
                  Total Inventory
                </Typography>
                <Typography variant="caption" sx={{ fontWeight: "bold" }}>
                  $0
                </Typography>
              </Stack>
            </Stack>

            <Stack sx={{ height: "100%", width: "100%" }}>
              <Gauge
                value={50}
                startAngle={0}
                endAngle={360}
                innerRadius="80%"
                outerRadius="100%"
              />
            </Stack>
          </Stack>
        </Card>
      </Stack>

      <Stack direction={"row"} sx={{ minWidth: 275 }} gap={2}>
        <Card
          sx={{
            width: "40%",
            height: "250px",
            padding: "20px",
            borderRadius: "30px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography sx={{ fontWeight: "bold" }}>
              Plan to Purchase Order Conversion
            </Typography>
            <Chip label="Last 30 days" />
          </Box>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack direction={"row"}>
            <Stack sx={{ width: "300px" }} spacing={1}>
              <Typography
                variant="body2"
                sx={{ display: "flex", gap: 1, alignItems: "center" }}
              >
                <Box bgcolor={"yellow"} width={"10px"} height={"10px"} />
                Pending PO Convention
              </Typography>
              <Typography
                variant="body2"
                sx={{ display: "flex", gap: 1, alignItems: "center" }}
              >
                <Box bgcolor={"green"} width={"10px"} height={"10px"}></Box>
                Converted POs{" "}
              </Typography>
            </Stack>
            <Gauge
              value={20}
              startAngle={-110}
              endAngle={110}
              sx={{
                [`& .${gaugeClasses.valueText}`]: {
                  fontSize: 40,
                  transform: "translate(0px, 0px)",
                },
                height: "150px",
              }}
              text={({ value }) => `${value}%`}
            />
          </Stack>
        </Card>
        <Card
          sx={{
            width: "40%",
            height: "250px",
            padding: "20px",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
            borderRadius: "30px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography sx={{ fontWeight: "bold" }}>
              Purchase Order Automation Percentage
            </Typography>
            <Chip label="Last 30 days" />
          </Box>
          <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
          <Stack direction={"row"}>
            <Stack sx={{ width: "300px" }} spacing={1}>
              <Typography
                variant="body2"
                sx={{ display: "flex", gap: 1, alignItems: "center" }}
              >
                <Box bgcolor={"yellow"} width={"10px"} height={"10px"}></Box>
                Pending PO Convention
              </Typography>
              <Typography
                variant="body2"
                sx={{ display: "flex", gap: 1, alignItems: "center" }}
              >
                <Box bgcolor={"green"} width={"10px"} height={"10px"}></Box>
                Converted POs{" "}
              </Typography>
            </Stack>
            <Gauge
              value={40}
              startAngle={-110}
              endAngle={110}
              sx={{
                [`& .${gaugeClasses.valueText}`]: {
                  fontSize: 40,
                  transform: "translate(0px, 0px)",
                },
                height: "150px",
              }}
              text={({ value }) => `${value}%`}
            />
          </Stack>
        </Card>
      </Stack>

      <Card
        sx={{
          width: "100%",
          height: "250px",
          bgcolor: "white",
          padding: "15px",
          marginTop: "15px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
          borderRadius: "30px",
        }}
      >
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <BiSolidBinoculars />
            <Typography sx={{ fontWeight: "bold" }}>Supply Insights</Typography>
          </Box>

          <Box
            sx={{
              display: "flex",
              gap: 2,
              color: "gray",
              alignItems: "center",
            }}
          >
            <Box sx={{ bgcolor: "red", height: "10px", padding: "5px" }}></Box>
            <Typography>Need Approval</Typography>
            <Divider orientation="vertical" variant="middle" flexItem />
            <Box
              sx={{ bgcolor: "yellow", height: "10px", padding: "5px" }}
            ></Box>
            <Typography>Exception</Typography>
            <Divider orientation="vertical" variant="middle" flexItem />
            <Box
              sx={{ bgcolor: "green", height: "10px", padding: "5px" }}
            ></Box>
            <Typography>Scheduled for Release</Typography>
          </Box>
        </Box>
        <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
        <Card
          sx={{
            display: "flex",
            justifyContent: "space-between",
            marginTop: "20px",
            padding: "20px",
            borderLeft: "8px solid yellow",
            boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
            borderRadius: "20px",
          }}
        >
          <Typography>Products With Missing Supply Plan</Typography>
          <Button
            sx={{
              fontWeight: 600,
              textTransform: "capitalize",
              color: "black",
              borderColor: "black",
              "&:hover": {
                backgroundColor: "#f0f0f0",
                borderColor: "black",
              },
            }}
            size="small"
            variant="outlined"
          >
            <ArrowForwardOutlinedIcon />
          </Button>
        </Card>
      </Card>
    </Box>
  );
};

export default Overview;
