
import SupplyPlanningFilterCom from "./SupplyPlanningFilterCom";
import PurchaseOrderTable from "./PurchaseOrderTable";
import TextSnippetOutlinedIcon from "@mui/icons-material/TextSnippetOutlined";

const PlanException = () => {
  const columns = [
    { field: "product", headerName: "Product", width: 250 },
    { field: "site", headerName: "Site", width: 250 },
    { field: "exceptionType", headerName: "Exception Type", width: 250 },
    { field: "rootCause", headerName: "Root Cause", width: 250 },
    { field: "creationDate", headerName: "Creation Date", width: 250 },
  ];
  const rows = [
    { id: 1, product: "Product A", site: "Site 1", exceptionType: "Type A", rootCause: "Cause X", creationDate: "2024-03-29" },
    { id: 2, product: "Product B", site: "Site 2", exceptionType: "Type B", rootCause: "Cause Y", creationDate: "2024-03-28" },
    { id: 3, product: "Product C", site: "Site 3", exceptionType: "Type C", rootCause: "Cause Z", creationDate: "2024-03-27" },
    { id: 4, product: "Product D", site: "Site 4", exceptionType: "Type D", rootCause: "Cause W", creationDate: "2024-03-26" },
    { id: 5, product: "Product E", site: "Site 5", exceptionType: "Type E", rootCause: "Cause V", creationDate: "2024-03-25" },
  ];

  return (
    <>
      <SupplyPlanningFilterCom />
      <PurchaseOrderTable columns={columns} rows={rows} tableHeading={<><TextSnippetOutlinedIcon /> Exception</>} />
    </>
  );
};

export default PlanException;
