import * as React from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Divider, Stack, Typography } from "@mui/material";

export default function PurchaseOrderTable({ columns, rows, tableHeading }) {
  const [page, setPage] = React.useState(0);
  const [pageSize, setPageSize] = React.useState(10);

  const handleChangePage = (newPage) => {
    setPage(newPage);
  };

  const handleChangePageSize = (pageSize) => {
    setPageSize(pageSize);
  };

  return (
    <Stack
      sx={{
        width: "100%",
        bgcolor: "white",
        p: "20px",
        boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        borderRadius: "20px",
      }}
      borderRadius={2}
    >
      <Typography
        sx={{
          alignItems: "center",
          display: "flex",
          gap: 1,
          fontWeight: "bold",
          fontSize: "16px",
          textTransform: "capitalize",
          color: "#1E1E1E",
        }}
      >
        {tableHeading}
      </Typography>

      <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
      <div style={{ height: 400, width: "100%" }}>
        <DataGrid
          sx={{ color: "#1E1E1E" }}
          rows={rows}
          columns={columns}
          pagination
          pageSize={pageSize}
          page={page}
          onPageChange={handleChangePage}
          rowsPerPageOptions={[10, 25, 50]}
          onPageSizeChange={(newPageSize) => handleChangePageSize(newPageSize)}
        />
      </div>
    </Stack>
  );
}
