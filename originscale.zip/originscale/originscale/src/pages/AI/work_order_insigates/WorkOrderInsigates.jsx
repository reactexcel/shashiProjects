const WorkOrderInsigates = () => {
  return (
    <div>
      work_order_insigates page
    </div>
  )
}

export default WorkOrderInsigates
