import { useMemo } from "react";
import {
  MaterialReactTable,
  useMaterialReactTable,
} from "material-react-table";
import { Box, FormControl, MenuItem, Select, Stack, Typography } from "@mui/material";
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import SearchIcon from '@mui/icons-material/Search';

const ColorSquares = ({ color }) => (
  <Stack direction="row" spacing={1}>
    {[...Array(5)].map((_, index) => (
      <Box
        key={index}
        sx={{
          bgcolor: color,
          width: "20px",
          height: "20px",
          borderRadius: "5px",
        }}
      />
    ))}
    <Box
      sx={{
        bgcolor: "green",
        width: "20px",
        height: "20px",
        borderRadius: "5px",
      }}
    />
    <Box
      sx={{
        bgcolor: "green",
        width: "20px",
        height: "20px",
        borderRadius: "5px",
      }}
    />
    <SearchIcon/>
    <ChatBubbleOutlineIcon/>
  </Stack>
);

const data = [
  {
    name: {
      firstName: "John",
      lastName: "Doe",
    },
    // insightID:'hi',
    product:{
        name:'john',
        productDetail:{
            name:'BMW'
        }
    },
    // productDetail:'East Daphne',
    issue:'Stock Out',
    riskDays:'in 2 days',
    AvgDeviation:'31%',
    onHandInventory:'85',
    safetyStock:'42',
    projectdInventory: <ColorSquares color="red" />,
  },
];

const Table = () => {
  const repeatedData = useMemo(() => [...Array(5)].map(() => data[0]), []);
  
  const columns = useMemo(
    () => [
      {
        accessorKey: "name.firstName",
        header: "Inside Id",
        size: 150,
        Cell: ({ value }) => (
            <Box>
            <Typography sx={{fontSize:'12px'}}>SOR1333</Typography>
            <FormControl sx={{ minWidth: 120,borderRadius:'20px' }} size="small">
              <Select
                labelId="demo-select-small-label"
                id="demo-select-small"
                value={value}
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>Ten</MenuItem>
                <MenuItem value={20}>Twenty</MenuItem>
                <MenuItem value={30}>Thirty</MenuItem>
              </Select>
            </FormControl>
            </Box>
          ),
      },
      {
        accessorKey: "product.name",
        header: "Product",
        size: 150,
        Cell: () => (
            <Box sx={{display:'flex',flexDirection:'column'}}>
                <Typography sx={{fontSize:'13px',fontWeight:'bold'}} >Brake Pad</Typography>
                <Typography sx={{color:'gray',fontSize:'13px'}}>Atlanta Distribution Center</Typography>
            </Box>
          ),
      },
      {
        accessorKey: "issue",
        header: "Issue",
        size: 100,
        Cell: () => (
            <Box sx={{display:'flex',gap:1,alignItems:'center'}}>
                <Box sx={{bgcolor:'red',padding:'5px',height:'10px'}}></Box>
                <Typography sx={{fontSize:'14px', fontWeight:'bold'}}>Stock Out</Typography>
            </Box>
          ),
      },
      {
        accessorKey: "riskDays",
        header: "Risk Days",
        size: 100,
        Cell: () => (
            <Box sx={{bgcolor:'#FFc0cb',color:'red',borderRadius:'30px',padding:'3px',textAlign:'center'}}>in 2 days</Box>
          ),
      },
      {
        accessorKey: "AvgDeviation",
        header: "Avg.Deviation",
        size: 100,
      },
      {
        accessorKey: "onHandInventory",
        header: "On Hand Inventory",
        size: 100,
      },
      {
        accessorKey: "safetyStock",
        header: "Safety Stock",
        size: 100,
      },
      {
        accessorKey: "projectdInventory",
        header: "Projected Inventory",
        size: 200,
      },
    ],
    []
  );
  const table = useMaterialReactTable({
    columns,
    data: repeatedData,
  });
  return (
    <Stack sx={{ borderRadius: "20px",
    boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",p:"20px",bgcolor:'white'}} >
  <MaterialReactTable   table={table} />
  </Stack>)
};

export default Table;
