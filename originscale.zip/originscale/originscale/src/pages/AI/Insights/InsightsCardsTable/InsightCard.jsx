import { Box, Card, Chip, Stack, Tooltip } from "@mui/material";
import SummarizeOutlinedIcon from '@mui/icons-material/SummarizeOutlined';
import AddCommentIcon from "@mui/icons-material/AddComment";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import { Link } from "react-router-dom";

const InsightCard = () => {
  return (
    <Card
      sx={{
        backgroundColor: "white",
        padding: "15px",
        borderRadius: "10px",
        boxShadow: "rgba(0, 0, 0, 0.24) 5px  2px 10px 4px",
      }}
    >
      <Stack
        direction={"row"}
        spacing={2}
        sx={{
          justifyContent: "space-between",
          height: "40px",
          alignItems: "center",
        }}
      >
        <Stack sx={{ flexDirection: "row", fontWeight: "bold" }}>
          <Box> Stock out Risk</Box>
        </Stack>
        <Chip
          label={"In 6 Days"}
          sx={{ background: "#fff",  boxShadow: "#30B5A1 2px 5px 10px inset", fontWeight:"600" }}
        />
      </Stack>
      <Stack sx={{ flexDirection: "row", width: "80%", height: "60px" }}>
        Honey crips Apply at the ATL Distribution center
      </Stack>
      <Stack sx={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Box>
          <AddCommentIcon />
        </Box>
        <Link
          style={{
            flexDirection: "row",
            textDecoration: "none",
            color: "black",
            textAlign: "center",
          }}
        >
          <Tooltip title="View detail">
            <SummarizeOutlinedIcon />
          </Tooltip>
          <KeyboardArrowRightIcon />
        </Link>
      </Stack>
    </Card>
  );
};

export default InsightCard;
