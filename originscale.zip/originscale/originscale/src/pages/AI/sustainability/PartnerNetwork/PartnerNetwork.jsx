import { Button, Card} from "react-bootstrap";
import CustomButton from "../../../../components/CustomButton";
import { Divider, Stack, Typography } from "@mui/material";

const GettingStarted = [
  {
    title: "Step 1",
    value: "Invite partner into your AWS Supply Chain network.",
    buttonText: "Invite Partners",
  },
  {
    title: "Step 2",
    value: "Invite partner into your AWS Supply Chain network.",
    buttonText: "Create Data Requests",
  },
  {
    title: "Step 3",
    value: "Invite partner into your AWS Supply Chain network.",
  },
];

const Onboarding = [
  {
    title: "Onboarded",
    value: "0",
  },
  {
    title: "Pending invites",
    value: "0",
  },
  {
    title: "Expired invites",
    value: "0",
  },
  {
    title: "Accept rate",
    value: "0%",
  },
];

const DataRequests = [
  {
    title: "In progress",
    value: "0",
  },
  {
    title: "Overdues",
    value: "0",
  },
  {
    title: "Declined",
    value: "0",
  },
  {
    title: "Response rate",
    value: "0%",
  },
];

const PartnerNetwork = () => {
  return (
    <div>
      <Card
        style={{
          padding: "20px",
          marginBottom: "20px",
          borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        }}
      >
        <Stack
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems:"center"
          }}
        >
          <Card.Title>Getting Started</Card.Title>
          <CustomButton btnText={"Collapse"} />
        </Stack>
        <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
        <Stack
          style={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          {GettingStarted.map((item, i) => (
            <div key={i}>
              <Card.Title style={{ fontWeight: "bold", fontSize: "14px" }}>
                {item.title}
              </Card.Title>
              <Card.Text style={{ fontSize: "13px" }}>{item.value}</Card.Text>
              {i < 2 ? <CustomButton btnText={item.buttonText} /> : ""}
            </div>
          ))}
        </Stack>
      </Card>

      <Card style={{ padding: "20px",  borderRadius: "20px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px", }}>
        <Card.Title style={{ fontWeight: "bold" }}>Partner Overview</Card.Title>
        <Divider sx={{ border: "1px solid gray", margin: "10px 0px" }} />
        <Stack direction={'row'} spacing={19} sx={{justifyContent:'space-between'}}>
          <Stack width={'50%'} spacing={1}>
            <Typography variant="caption" sx={{fontWeight:'bold'}}>
              Onboarding metrics
            </Typography>
            <Stack direction={'row'} spacing={2} sx={{width:'100%'}}>
              {Onboarding.map((item, i) => (
                <Card key={i} style={{ padding: "10px",boxShadow: '6px 6px 11px #625d5dc2 inset',width:'100%'}}>
                  <Card.Title style={{ fontSize: "12px", color: "gray" }}>
                    {item.title}
                  </Card.Title>
                  <Card.Text style={{ fontWeight: "bold" }}>
                    {item.value}
                  </Card.Text>
                </Card>
              ))}
            </Stack>
          </Stack>
          <Stack width={'50%'} spacing={1}>
            <Typography variant="caption" sx={{fontWeight:'bold'}}>
              Data Requests
            </Typography>
            <Stack direction={'row'} spacing={2} sx={{width:'100%'}} >
              {DataRequests.map((item, i) => (
                <Card key={i} style={{ padding: "10px",boxShadow: '6px 6px 11px #625d5dc2 inset',width:'100%' }}>
                  <Card.Title style={{ fontSize: "12px", color: "gray" }}>
                    {item.title}
                  </Card.Title>
                  <Card.Text style={{ fontWeight: "bold" }}>
                    {item.value}
                  </Card.Text>
                </Card>
              ))}
            </Stack>
          </Stack>
        </Stack>
      </Card>
    </div>
  );
};

export default PartnerNetwork;
