import { Box, Typography } from "@mui/material";
import React from "react";

const DataLake = () => {
  return (
    <Box
      mb={"38%"}
      sx={{
        background: "white",
        padding: "20px 10px",
        borderRadius: "15px",
        boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
      }}
    >
      <Box sx={{ display: "flex", gap: "4px", alignItems: "center" }}>
        <Typography sx={{ fontSize: "22px", fontWeight: "bold" }}>
          DataLake
        </Typography>
      </Box>
    </Box>
  );
};

export default DataLake;
