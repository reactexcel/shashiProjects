import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import {
  GoogleMap,
  useJsApiLoader,
  MarkerF,
  InfoWindowF,
} from "@react-google-maps/api";
import NetworkMap3d from "./networkMap3d/NetworkMap3d";
import { Divider, List, ListItem, ListItemText } from "@mui/material";
import { FaSquare } from "react-icons/fa";
import yellowHouse from "../../../assets/img1/marker/yellowhousesq1.webp";
import blueHouse from "../../../assets/img1/marker/bluehousesq1.webp";
import redHouse from "../../../assets/img1/marker/redhousesq1.webp";
import { MdArrowBackIos } from "react-icons/md";

const containerStyle = {
  width: "100%",
  height: "530px",
};

const center = {
  lat: 27.5706,
  lng: 80.0982,
};

const markers = [
  {
    id: 1,
    name: "Delhi",
    status: "balance",
    stock: 26,
    position: { lat: 28.656473, lng: 77.242943 },
  },
  {
    id: 2,
    name: "Barelly",
    status: "stockout",
    stock: 0,
    position: { lat: 28.363535, lng: 79.485954 },
  },
  {
    id: 3,
    name: "Lucknow ",
    status: "excessstock",
    stock: 40,
    position: { lat: 26.85, lng: 80.949997 },
  },
  {
    id: 4,
    name: "Agra ",
    status: "stockout",
    stock: 0,
    position: { lat: 27.17667, lng: 78.008072 },
  },
  {
    id: 5,
    name: "Kanpur",
    status: "balance",
    stock: 30,
    position: { lat: 26.449923, lng: 80.331871 },
  },
];

const stockStatusData = [
  { id: "1", color: "#F7AA01", text: "Balance" },
  { id: "2", color: "#F71D06", text: "Stock Out" },
  { id: "3", color: "#00CDFF", text: "Excess Stock" },
];

function NetworkMap() {
  const [activeMarker, setActiveMarker] = useState(null);
  const [mapCenter, setMapCenter] = useState(center);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [stockStatus, setStockStatus] = useState(null);
  const [locationName, setLocationName] = useState(null);
  const [show3dmap, setShow3dmap] = useState(false);
  const [hoveredMarker, setHoveredMarker] = useState(null);

  const handleActiveMarker = (marker) => {
    if (marker.id === activeMarker) {
      return;
    }
    setActiveMarker(marker.id);
    const markerPosition = markers.find((m) => m.id === marker.id).position;
    setMapCenter(markerPosition);
    setSelectedLocation(marker.position);
    setStockStatus(marker.status);
    setLocationName(marker.name);
    setShow3dmap(true);
  };

  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: import.meta.env.VITE_APP_GOOGLE_MAP_API_KEY,
  });
  const [map, setMap] = React.useState(null);
  const [zoomIn, setZoomIn] = React.useState("");
  const onLoad = React.useCallback(function callback(map) {
    const bounds = new window.google.maps.LatLngBounds(center);
    map.fitBounds(bounds);
    setZoomIn(map.getZoom());
    setMap(map);
  }, []);
  const onUnmount = React.useCallback(function callback(map) {
    setMap(null);
    setMap(null);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setZoomIn(7);
    }, [1000]);

    return () => {
      setInterval(timer);
    };
  }, [show3dmap]);

  const handleShowMap = () => {
    setShow3dmap(false);
    setZoomIn(1);
    setActiveMarker(null);
    setHoveredMarker(null)
  };

  const handleMarkerHover = (markerId) => {
    setHoveredMarker(markerId);
  };

  const handleMarkerUnhover = () => {
    setHoveredMarker(null);
  };

  return (
    <Box>
      <Box
        sx={{
          display: { sm: "block", md: "flex" },
          justifyContent: "space-between",
          alignItems: "center",
          background: "white",
          padding: "0px 10px",
          mb: "10px",
          borderRadius: "15px",
          boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px",
        }}
      >
        <Box sx={{ display: "flex", gap: "4px", alignItems: "center" }}>
          {show3dmap && (
            <MdArrowBackIos
              onClick={handleShowMap}
              size={20}
              cursor="pointer"
              color="blue"
            />
          )}
          <Typography sx={{ fontSize: "22px", fontWeight: "bold" }}>
            Network Map
          </Typography>
        </Box>
        <List>
          <ListItem sx={{ display: "flex", gap: "14px" }}>
            {stockStatusData.map((status) => (
              <Box
                key={status.id}
                sx={{ display: "flex", alignItems: "center", gap: "4px" }}
              >
                <FaSquare color={status.color} />
                <ListItemText primary={status.text} />
              </Box>
            ))}
          </ListItem>
        </List>
      </Box>
      {isLoaded && !show3dmap ? (
        <GoogleMap
          center={mapCenter}
          zoom={zoomIn}
          onLoad={onLoad}
          onUnmount={onUnmount}
          onClick={() => setActiveMarker(null)}
          mapContainerStyle={containerStyle}
        >
          {markers.map((marker) => (
            <MarkerF
              key={marker.id}
              position={marker.position}
              onClick={() => handleActiveMarker(marker)}
              onMouseOver={() => handleMarkerHover(marker.id)}
              onMouseOut={handleMarkerUnhover}
              icon={{
                url:
                  marker.status === "balance"
                    ? yellowHouse
                    : marker.status === "stockout"
                    ? redHouse
                    : marker.status === "excessstock"
                    ? blueHouse
                    : "",
                scaledSize: { width: 40, height: 40 },
              }}
            >
              {hoveredMarker === marker.id && (
                <InfoWindowF>
                  <div
                    style={{
                      padding: "10px",
                    }}
                  >
                    <Typography variant="body1" fontWeight={"bold"}>
                      {marker.name}
                    </Typography>
                    <Typography variant="body2">Warehouse</Typography>
                    <Divider sx={{ backgroundColor: "#000" }} />
                    <Typography
                      variant="body2"
                      fontWeight="600"
                      display="flex"
                      gap={1}
                      alignItems="center"
                      mt={1}
                    >
                      All products
                      <span
                        style={{
                          backgroundColor: "gray",
                          color: "#fff",
                          padding: "0 2px",
                          borderRadius: "4px",
                          fontWeight: "400",
                          fontSize: "14px",
                          width: "24px",
                          height: "24px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        46
                      </span>
                    </Typography>
                    <Typography
                      variant="body2"
                      fontWeight="600"
                      display="flex"
                      gap={1}
                      alignItems="center"
                      mt={1}
                    >
                      Balance
                      <span
                        style={{
                          backgroundColor:
                            marker.status === "balance"
                              ? "green"
                              : marker.status === "stockout"
                              ? "red"
                              : marker.status === "excessstock"
                              ? "#00CDFF"
                              : "inherit",
                          color: "#fff",
                          padding: "0 2px",
                          borderRadius: "4px",
                          fontWeight: "400",
                          fontSize: "14px",
                          width: "24px",
                          height: "24px",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        {marker.stock}
                      </span>
                    </Typography>
                  </div>
                </InfoWindowF>
              )}
            </MarkerF>
          ))}
        </GoogleMap>
      ) : (
        <NetworkMap3d
          selectedLocation={selectedLocation}
          stockStatus={stockStatus}
          locationName={locationName}
          setSelectedLocation={setSelectedLocation}
        />
      )}
    </Box>
  );
}

export default React.memo(NetworkMap);
