// import React, { useState } from "react";
// import { AgChartsReact } from "ag-charts-react";

// const Chart = () => {
//   const [options, setOptions] = useState({
//     data: getData(),
//     series: [
//       {
//         xKey: "x",
//         yKey: "y",
//       },
//     ],
//     axes: [
//       {
//         position: "bottom",
//         type: "category",
//         title: {
//           text: "",
//         },
//         crossLines: [
//           {
//             type: "range",
//             range: ["Sep", "Dec"],
//           },
//         ],
//       },
//       {
//         position: "left",
//         type: "number",
//         title: {
//           text: "",
//         },
//         tick: {
//           count: 6,
//           values: [0, 400, 800, 1200, 1600, 2000],
//         },
//         crossLines: [
//           {
//             type: "line",
//             value: 11,
//           },
//         ],
//       },
//     ],
//     tooltip: {
//       enabled: true,
//       renderer: function (params) {
//         return {
//           content: `X: ${params.datum.x}, Y: ${params.datum.y}`,
//         };
//       },
//       style: {
//         backgroundColor: "black",
//         color: "white",
//         borderRadius: "5px",
//         cursor: "pointer",
//       },
//     },
//     // tooltip: {
//     //   enabled: true,
//     //   renderer: function (params) {
//     //     const { x, y } = params.datum;
//     //     return (
//     //       <div style={{ backgroundColor: "white", padding: "8px", border: "1px solid black" }}>
//     //         <div>
//     //           <strong>X:</strong> {x}
//     //         </div>
//     //         <div>
//     //           <strong>Y:</strong> {y}
//     //         </div>
//     //       </div>
//     //     );
//     //   },
//     // },
//   });

//   function getData() {
//     return [
//       {
//         x: "Jan",
//         y: 550,
//       },
//       {
//         x: "Feb",
//         y: 1060,
//       },
//       {
//         x: "Mar",
//         y: 2000,
//       },
//       {
//         x: "Apr",
//         y: 899,
//       },
//       {
//         x: "May",
//         y: 1930,
//       },
//       {
//         x: "Jun",
//         y: 1500,
//       },
//       {
//         x: "Jul",
//         y: 1800,
//       },
//       {
//         x: "Aug",
//         y: 1470,
//       },
//       {
//         x: "Sep",
//         y: 140,
//       },
//       {
//         x: "Oct",
//         y: 1020,
//       },
//       {
//         x: "Nov",
//         y: 800,
//       },
//       {
//         x: "Dec",
//         y: 307,
//       },
//     ];
//   }
//   return (
//     <div className="wrapper">
//       <AgChartsReact options={options} />
//     </div>
//   );
// };

// export default Chart;

// import {
//   LineChart,
//   Line,
//   XAxis,
//   YAxis,
//   CartesianGrid,
//   Tooltip,
//   Legend,
//   ReferenceLine,
//   ResponsiveContainer,
// } from "recharts";

// const data = [
//   { name: "Page A", uv: 4000, pv: 2400, amt: 2400 },
//   { name: "Page B", uv: 3000, pv: 1398, amt: 2210 },
//   { name: "Page C", uv: 2000, pv: 9800, amt: 2290 },
//   { name: "Page D", uv: 2780, pv: 3908, amt: 2000 },
//   { name: "Page E", uv: 1890, pv: 4800, amt: 2181 },
//   { name: "Page F", uv: 2390, pv: 3800, amt: 2500 },
//   { name: "Page G", uv: 3490, pv: 4300, amt: 2100 },
// ];

// const Charts = () => {
//   return (
//     <ResponsiveContainer width="100%" height="100%">
//       <LineChart
//         data={data}
//         margin={{
//           top: 20,
//           right: 50,
//           left: 20,
//           bottom: 5,
//         }}
//       >
//         <CartesianGrid strokeDasharray="3 3" />
//         <XAxis dataKey="name" />
//         <YAxis />
//         <Tooltip />
//         <Legend />
//         <ReferenceLine x="Page C" stroke="red" />
//         <Line
//           type="monotone"
//           dataKey="pv"
//           stroke="#8884d8"
//           strokeWidth={2}
//         />
//       </LineChart>
//     </ResponsiveContainer>
//   );
// };
// export default Charts;

import React, { useState } from "react";
import ReactApexChart from "react-apexcharts";

const Charts = () => {
  const [chartData, setChartData] = useState({
    series: [
      {
        name: "Actual Demand",
        data: [
          4.24, 3.45, 10.68, 9.0, 29.45, 19.25, 22.34, 9.78, 12.87, 7.79, 19.14,
          5.36, 13.52, 9.63, 17.41, 2.47, 7.69, 5.74,
        ],
      },
    ],
    options: {
      chart: {
        width: "100%",
        foreColor: "blue",
        height: "auto",
        height: 350,
        type: "line",
        id: "originscale",
        brush: {
          autoScaleYaxis: true,
        },
      },
      forecastDataPoints: {
        count: 7,
        dashArray: 2,
      },
      stroke: {
        width: 3,
        curve: "smooth",
      },
      xaxis: {
        type: "datetime",
        categories: [
          "1/11/2000",
          "2/11/2000",
          "3/11/2000",
          "4/11/2000",
          "5/11/2000",
          "6/11/2000",
          "7/11/2000",
          "8/11/2000",
          "9/11/2000",
          "10/11/2000",
          "11/11/2000",
          "12/11/2000",
          "1/11/2001",
          "2/11/2001",
          "3/11/2001",
          "4/11/2001",
          "5/11/2001",
          "6/11/2001",
        ],
        tickAmount: 8,
        // labels: {
        //   datetimeFormatter: {
        //     day: "dd MMM",
        //   },
        // },
        // labels: {
        //   formatter: function (value, timestamp, opts) {
        //     return opts.dateFormatter(new Date(timestamp), "dd MMM");
        //   },
        // },

        tickAmount: undefined,
        tickPlacement: "on",
        min: undefined,
        max: undefined,
        stepSize: undefined,
        range: undefined,
        floating: false,
        decimalsInFloat: undefined,
        overwriteCategories: undefined,
        position: "bottom",
        labels: {
          show: true,
          // rotate: -45,
          rotateAlways: false,
          hideOverlappingLabels: true,
          showDuplicates: true,
          trim: false,
          minHeight: undefined,
          maxHeight: 120,
          style: {
            colors: "#507dbf",
            fontSize: "12px",
            fontFamily: "Helvetica, Arial, sans-serif",
            fontWeight: 600,
          },
        },
        axisBorder: {
          show: true,
          color: "#000",
          height: 1,
          width: "100%",
          offsetX: 0,
          offsetY: 0,
        },
        axisTicks: {
          show: true,
          borderType: "solid",
          color: "#000",
          height: 4,
          offsetX: 0,
          offsetY: 0,
        },

        title: {
          text: "xyzzzzzzzzzzz",
          offsetX: 0,
          offsetY: 0,
          style: {
            color: "red",
            fontSize: "14px",
            fontFamily: "Helvetica, Arial, sans-serif",
            fontWeight: 600,
            cssClass: "apexcharts-xaxis-title",
          },
        },
        crosshairs: {
          show: true,
          width: "50%",
          position: "back",
          opacity: 0.2,
          stroke: {
            color: "#e8eaed",
            width: 0,
            dashArray: 0,
          },

          dropShadow: {
            enabled: true,
            top: 0,
            left: 0,
            blur: 1,
            opacity: 0.2,
          },
        },
        tooltip: {
          enabled: false,
        },
      },
      title: {
        text: "originscale",
        align: "left",
        style: {
          fontSize: "16px",
          color: "#666",
        },
      },
      fill: {
        type: "gradient",
        gradient: {
          shade: "dark",
          gradientToColors: ["#FDD835"],
          shadeIntensity: 1,
          type: "horizontal",
          opacityFrom: 1.5,
          opacityTo: 0.4,
          stops: [0, 100, 100, 100],
        },
      },
      yaxis: {
        min: 0,
        max: 40,
        labels: {
          style: {
            colors: "#000",
          },
        },
        // forceNiceScale: true,
      },
      grid: {
        show: true,
        borderColor: "#ededeb",
        position: "back",
        xaxis: {
          lines: {
            show: true,
          },
        },
        yaxis: {
          lines: {
            show: true,
          },
        },
        padding: {
          left: 12,
        },
      },

      markers: {
        size: 3,
        colors: ["#95aaed"],
        strokeColors: "#fff",
        strokeWidth: 1,
        shape: "circle",
        hover: {
          size: 3,
        },
      },

      annotations: {
        xaxis: [
          {
            x: new Date("11/15/2000").getTime(),
            strokeDashArray: 4,
            borderColor: "#FF0000",
            label: {
              borderColor: "#FF0000",
              style: {
                color: "#fff",
                background: "#FF0000",
              },
              // text: "Marker",
            },
          },
        ],
      },
    },
  });

  return (
    <div>
      <div id="chart">
        <ReactApexChart
          options={chartData.options}
          series={chartData.series}
          type="line"
          height={350}
        />
      </div>
      <div id="html-dist"></div>
    </div>
  );
};

export default Charts;
