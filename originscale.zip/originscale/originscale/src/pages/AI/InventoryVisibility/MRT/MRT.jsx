import PropTypes from "prop-types";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import Row from "./HideTable";
import "./mrt2.css";

function createData(name, calories, fat, carbs, protein, price) {
  return {
    name,
    calories,
    fat,
    carbs,
    protein,
    price,
    history: [
      {
        date: "2020-01-05",
        customerId: "11091700",
        amount: 3,
      },
    ],
  };
}
Row.propTypes = {
  row: PropTypes.shape({
    calories: PropTypes.number.isRequired,
    carbs: PropTypes.number.isRequired,
    fat: PropTypes.number.isRequired,
    history: PropTypes.arrayOf(
      PropTypes.shape({
        amount: PropTypes.number.isRequired,
        customerId: PropTypes.string.isRequired,
        date: PropTypes.string.isRequired,
      })
    ).isRequired,
    name: PropTypes.string.isRequired,
    price: PropTypes.number.isRequired,
    protein: PropTypes.number.isRequired,
  }).isRequired,
};

const rows = [
  createData("Warehouse", 45, 45, 0, 0, 0),
  createData("Warehouse", 46, 45, 0, 0, 0),
  createData("Warehouse", 45, 45, 0, 0, 0),
  createData("Warehouse", 46, 45, 0, 0, 0),
];

export default function MrtTable() {
  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow sx={{ backgroundColor: "#D3D3D3", }}>
            <TableCell sx={{ fontWeight: "bold" }}>Location</TableCell>
            <TableCell sx={{ fontWeight: "bold" }}>Size Type</TableCell>
            <TableCell sx={{ fontWeight: "bold" }} align="right">
              Products
            </TableCell>
            <TableCell sx={{ fontWeight: "bold" }} align="right">
              <span className="dotHeader" style={{ backgroundColor: "green" }}></span>
              Balanced
            </TableCell>
            <TableCell sx={{ fontWeight: "bold" }} align="right">
              <span className="dotHeader" style={{ backgroundColor: "red" }}></span>
              Stock out risk
            </TableCell>
            <TableCell sx={{ fontWeight: "bold" }} align="right">
              <span
                className="dotHeader"
                style={{ backgroundColor: "blue" }}
              ></span>
              Excess Stock risk
            </TableCell>
          </TableRow>
        </TableHead>


        <TableBody>
          {rows.map((row) => (
            <Row key={row.name} row={row} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
