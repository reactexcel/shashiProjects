import * as React from "react";
import Box from "@mui/material/Box";
import Collapse from "@mui/material/Collapse";
import IconButton from "@mui/material/IconButton";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableRow from "@mui/material/TableRow";
import Typography from "@mui/material/Typography";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import "./mrt2.css";
import { TableHead } from "@mui/material";

export default function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);

  return (
    <React.Fragment>
      <TableRow sx={{ "& > *": { borderBottom: "unset" }, }}>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell component="th" scope="row">
          {row.name}
        </TableCell>
        <TableCell align="right"  >
          {row.calories}
          <span
            className="dot"
            style={{
              marginLeft: "10px",
              backgroundColor:
                row.calories <= 10
                  ? "red"
                  : row.calories > 20
                    ? "green"
                    : "blue",
            }}
          ></span>
        </TableCell>
        <TableCell align="right">
          {row.fat}
          <span
            className="dot"
            style={{
              marginLeft: "10px",
              backgroundColor:
                row.fat < 10 ? "red" : row.fat > 20 ? "green" : "blue",
            }}
          ></span>
        </TableCell>
        <TableCell align="right">
          {row.carbs}
          <span
            className="dot"
            style={{
              marginLeft: "10px",
              backgroundColor:
                row.carbs < 10 ? "red" : row.carbs > 20 ? "green" : "purple",
            }}
          ></span>
        </TableCell>
        <TableCell align="right">
          {row.protein}
          <span
            className="dot"
            style={{
              marginLeft: "10px",
              backgroundColor: "blue",
            }}
          ></span>
        </TableCell>
      </TableRow>

      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography
                variant="h5"
                sx={{ fontWeight: "bold", fontSize: "18px" }}
                gutterBottom
                component="div"
              >
                Products at JBrothers - Bay City (REC)
              </Typography>
              <Table size="small" aria-label="purchases">
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      Product
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      category
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bold", fontSize: "15px" }}
                      align="right"
                    >
                      <div>on hand</div>
                      <div>safty stock</div>
                    </TableCell>
                    <TableCell
                      sx={{ fontWeight: "bold", fontSize: "15px" }}
                      align="right"
                    >
                      On order
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      In Transit
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      <div>prior</div>
                      <div>
                        <span>-7</span>
                        <span>-6</span> <span>-5</span> <span>-4</span>
                        <span>-3</span> <span>-2</span> <span>-1</span>
                      </div>
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      Today
                      <div>30/19</div>
                    </TableCell>
                    <TableCell sx={{ fontWeight: "bold", fontSize: "15px" }}>
                      Projected
                      <div className="d-flex justify-content-between ">
                        <div>30/20</div>
                        <div>30/21</div>
                        <div>30/22</div>
                        <div>30/23</div>
                      </div>
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {[1, 2, 3, 4].map((data, index) => (
                    // <TableRow key={historyRow.date}>
                    //   <TableCell component="th" scope="row">
                    //     {historyRow.date}
                    //   </TableCell>
                    //   <TableCell>{historyRow.customerId}</TableCell>

                    <TableRow key={index}>
                      <TableCell component="th" scope="row">
                        <div>int - Prepack(1 Oz)</div>
                        <div>IId_001</div>
                      </TableCell>
                      <TableCell>
                        <div>int - Prepack</div>
                        <div>(1 Oz)</div>
                      </TableCell>
                      <TableCell align="center">0</TableCell>
                      <TableCell align="center">0</TableCell>
                      <TableCell align="center">0</TableCell>
                      <TableCell align="right">
                        <div className="d-flex justify-content-between ">
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                        </div>
                      </TableCell>
                      <TableCell align="right">
                        <div className="d-flex justify-content-between ">
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                        </div>
                      </TableCell>
                      <TableCell align="right">
                        <div className="d-flex justify-content-between ">
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                          <div
                            className="square"
                            style={{ backgroundColor: "green" }}
                          ></div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}
