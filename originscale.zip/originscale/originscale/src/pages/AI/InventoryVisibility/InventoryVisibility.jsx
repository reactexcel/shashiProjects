
import Box from "@mui/material/Box";
import FormControl from "@mui/material/FormControl";
import MrtTable from "./MRT/MRT";
import { Card, Stack, Typography } from "@mui/material";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import { CustomOutlineButton } from "./../../../components/CustomButton";
import React from "react";


const InventoryVisibility = () => {
  const date = new Date()
  const [povitBy, setPovitBy] = React.useState('Location');

  const handleChange = (event) => {
    setPovitBy(event.target.value);
  };
  return (
    <Stack spacing={2}>
      <Card
        sx={{
          padding: " 10px 20px",
          display: { sm: "block", md: "flex" },
          justifyContent: "space-between",
          alignItems: "center",
          boxShadow: 'rgba(0, 0, 0, 0.24) 0px 3px 8px', borderRadius: '15px'
        }}
      >
        <Typography sx={{ fontSize: "22px", fontWeight: "bold" }}>
          Projected Inventory
        </Typography>
        <Box sx={{ display: "flex", alignItems: "center", gap: "3px", marginTop: { sm: "5px", md: "0px" } }}>
          <Typography sx={{ fontWeight: "bold" }} variant={"caption"}>Date Update</Typography>
          <Typography variant={"caption"} >{date.toString()}</Typography>
        </Box>
      </Card>
      <Card sx={{ backgroundColor: 'white', padding: "20px", borderRadius: '30px', boxShadow: "rgba(0, 0, 0, 0.24) 0px 3px 8px" }}>

        <Box
          sx={{
            display: { sm: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
            height: { sm: "120px", md: "60px" },
          }}
        >
          <FormControl
            sx={{
              width: "450px",
              border: "1px solid lightgray",
              borderRadius: "5px",
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-around",
              height: "45px",
              padding: "5px 0px",
            }}
          >
            <Stack sx={{ alignItems: "center", justifyContent: "center" }}>
              Povit By
            </Stack>
            <Select value={povitBy} sx={{
              width: "70%",
              "& .MuiOutlinedInput-notchedOutline": {
                border: "none !important",
              },
              "&:hover .MuiOutlinedInput-notchedOutline": {
                border: "none !important",
              },
              "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
                border: "none !important",
              }
            }} onChange={handleChange}>
              <MenuItem value={"Location"}>Location</MenuItem>
              <MenuItem value={"Product"}>Product</MenuItem>
            </Select>
          </FormControl>
          <CustomOutlineButton
            btnText={"Filter"}
            styles={{ padding: "7px 15px", fontSize: "12px" }}
            onClick={() => console.log("clickme")}
            start_icon={<FilterAltIcon />}
          />
        </Box>
        <Box>
          <MrtTable />
        </Box>
      </Card>
    </Stack>
  );
};

export default InventoryVisibility;
