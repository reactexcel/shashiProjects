import NavbarCom from "../../components/navbar/NavbarCom";
import SideBar from "../../components/sideBar/SideBar";
function Dashboard() {
  return (
    <>
      <NavbarCom />
      {/* <SideBar /> */}
    </>
  );
}

export default Dashboard;
