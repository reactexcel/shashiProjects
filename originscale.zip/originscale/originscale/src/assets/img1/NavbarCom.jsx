import Navbar from "react-bootstrap/Navbar";
import sell from "../img1/";
import make from "../img1/make.svg";
import source from "../img1/source.svg";
import trace from "../img1/trace.svg";
import inventory from "../img1/inventory.svg";
import kit from "../img1/kit.svg";
import stocktransfer from "../img1/stocktransfer.svg";
import automation from "../img1/automation.svg";
import { Dropdown } from "react-bootstrap";
import { Link } from "react-router-dom";
import Ai from "../img1/ai.svg";
import { useState } from "react";
import logo from "../img1/logo.svg";
import { AppBar, Box, IconButton, Stack, Toolbar } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";

function NavbarCom({hanldeToggleDrawer}) {
  const [selectedIcon, setSelectedIcon] = useState(null);

  const AppBarData = [
    { name: "Sell", icon: sell, path: "sell" },
    { name: "Make", icon: make, path: "make" },
    { name: "Procure", icon: source },
    { name: "Finance", icon: trace },
    { name: "Inventory", icon: inventory },
    { name: "Automation", icon: automation },
    { name: "Stock Transfer", icon: stocktransfer },
    { name: "Bundle", icon: kit },
    { name: "A.I", icon: Ai, path: "ai" },
  ];
  return (
    <AppBar
      style={{ zIndex: 2, width: "100%" }}
      sx={{background:"white"}}
    >
      <Toolbar>
      <Navbar.Brand>
        <img src={logo} alt="OriginScale" width={"150px"} height={"70px"} />
      </Navbar.Brand>
      <IconButton onClick={hanldeToggleDrawer} size="medium" sx={{display: { md: "none", xs: "block" },ml:'auto'}}>
        <MenuIcon />
      </IconButton>
      <Stack
        direction={"row"}
        spacing={0.5}
        sx={{
          display: { md: "flex", xs: "none" },
          ml: "auto",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {AppBarData.map((e, index) => {
          return (
            <Link
              to={e.path}
              key={index}
              className={`${
                selectedIcon === index ? "nav-link2" : null
              } nav-link`}
              style={{
                fontWeight: 400,
                textDecoration: "none",
              }}
              onClick={() => setSelectedIcon(index)}
            >
              <div className="text-center px-2 ">
                <img style={{ width: "15px" }} src={e.icon} />
                <p className="m-0">{e.name}</p>
              </div>
            </Link>
          );
        })}
        <Dropdown >
          <Dropdown.Toggle className="border " id="dropdown-basic">
            Add New
          </Dropdown.Toggle>

          <Dropdown.Menu>
            <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
            <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
            <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
          </Dropdown.Menu>
        </Dropdown>
      </Stack>
      </Toolbar>
    </AppBar>
  );
}

export default NavbarCom;
