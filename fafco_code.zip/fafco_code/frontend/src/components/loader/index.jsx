import "../loader/loader.css";
const Loader = () => {
  return (
    <div className=" d-flex flex-column">
      <p className="loader"></p>
    </div>
  );
};

export default Loader;
