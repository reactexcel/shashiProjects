from django.contrib import admin
from .models import Claim,UploadClaimDocument

admin.site.register(Claim)
admin.site.register(UploadClaimDocument)
