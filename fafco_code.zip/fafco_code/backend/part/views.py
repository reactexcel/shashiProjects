from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from .models import Part, Profile,Partcsv
from .serializers import PartSerializer, PartcsvSerializer
from rest_framework.permissions import IsAuthenticated



class PartAPI(APIView):
    permission_classes = [IsAuthenticated]

    
    # def get(self, request,profile_id):
    #     print('ttttttttttttttttttttttttttttttttt')
    #     print(profile_id,'deeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee')
    #     parts = Part.objects.filter(registration=profile_id)  
    #     print(parts)    
    #     serializer = PartSerializer(parts, many=True)
    #     response = Response(serializer.data, status=200)
    #     response.success_message = "Fetched Data."
    #     return response
    def post(self, request):
        data = request.data
        parts = get_object_or_404(Profile, customer=request.user.id,
                                  pk=data["profile_id"])
        data["registration"] = parts.id
        serializer = PartSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            response = Response(serializer.data, status=200)
            response.success_message = "Part created successfully"
            return response
        response = Response(serializer.errors, status=200)
        response.success_message = "Error occured."
        return response


class PartListAPI(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, profile_id):
        parts = Part.objects.filter(registration=profile_id)  
        serializer = PartSerializer(parts, many=True)
        response = Response(serializer.data, status=200)
        response.success_message = "Fetched Data."
        return response

class PartupdatedeleteAPI(APIView):
    

    def get(self, request, profile_id, part_id):
        
        part = get_object_or_404(Part, registration=profile_id, pk=part_id)
        data = {
            "id": part.pk,
            "part_number": part.part_number,
            "part_description": part.part_description,
            "product_line": part.product_line,
            "active": part.active,
            "registration": part.registration_id
        }
        return Response(data, status=200)

    def patch(self, request, profile_id, part_id):
        part = get_object_or_404(Part, pk=part_id, registration=profile_id)

        part_number = request.data.get('part_number')
        profile_part = Part.objects.filter(part_number=part_number, registration= profile_id)

        if profile_part:
            return Response(
               {'error': 'Part is already exist for this profile'},
                status=status.HTTP_400_BAD_REQUEST
            )
        part_data = get_object_or_404(Partcsv, part_number=part_number)
        data = {
            "part_number": part_data.part_number,
            "part_description": part_data.part_description,
            "product_line": part_data.product_line,
        }

        serializer = PartSerializer(part, data=data, partial=True)
        if serializer.is_valid():
            serializer.save()
            response = Response(serializer.data, status=200)
            response.success_message = "Updated Data Successfully"
            return response
        response = Response(serializer.errors, status=200)
        response.success_message = "Error Occured."
        return response

    def delete(self, request, profile_id, part_id):
        part = get_object_or_404(Part, pk=part_id, registration=profile_id)
        part.delete()
        return Response({"message": "Part deleted Successfully","status":True},
                        status=status.HTTP_200_OK)


class PartcsvListView(APIView):
    def get(self, request):
        parts = Partcsv.objects.all()
        serializer = PartcsvSerializer(parts, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)