
def generate_absolute_uri(request, url):
    return request.build_absolute_uri(url)
