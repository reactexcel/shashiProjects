import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Login from './components/login';
import Home from './components/home';
import Nav from './components/nav';
import User from './components/user';
import Report from './components/report';
import ClaimManagement from './components/claim_management/ClaimManagement';
import OrderEngine from './components/orderEngine';
import ProductEngine from './components/productEngine';
import SupplierMap from './components/supplierMap';
import Role from './components/role';
import Brand from './components/brand';
import { Provider } from 'react-redux';
import appStore from './common/app.store';
import ResetPassword from './components/resetPassword';
import ForgotPassword from './components/forgotPassword';
import { Box } from '@mui/material';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import PATH from './components/utils/path';
function App() {
  console.log(process.env.REACT_APP_DASHBOARD_API_URL);
 
  const router = createBrowserRouter([
    {
      path: PATH.LOGIN,
      element: <Login />,
    },
    {
      path: PATH.FORGOTPASSWORD,
      element: <ForgotPassword />,
    },
    {
      path: PATH.RESETPASSWORD,
      element: <ResetPassword />,
    },
    {
      path:PATH.NAV,
      element: <Nav />,
      children: [
        {
          path: PATH.HOME,
          element: <Home />,
        },
        {
          path: PATH.ROLE,
          element: <Role />,
        },
        {
          path: PATH.BRAND,
          element: <Brand />,
        },
        {
          path: PATH.USER,
          element: <User />,
        },
        {
          path: PATH.REPORT,
          element: <Report />,
        },
        {
          path: PATH.CLAIMMANAGEMENT,
          element: <ClaimManagement />,
        },
        {
          path: PATH.ORDERENGINE,
          element: <OrderEngine />,
        },
        {
          path: PATH.PRODUCTENGINE,
          element: <ProductEngine />,
        },
        {
          path: PATH.SUPPLIERMAP,
          element: <SupplierMap />,
        },
      ],
    },
  ]);

  return (
    <Box>
      <Provider store={appStore}>
        <RouterProvider router={router} />
      </Provider>
    </Box>
  );
}

export default App;
