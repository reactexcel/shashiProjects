import React, { useState, useEffect } from 'react';
import axios from 'axios';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  Box,
  Card,
  CardContent,
  Checkbox,
  Dialog,
  DialogContent,
  IconButton,
  InputAdornment,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Typography,
} from '@mui/material';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import { faPenToSquare } from '@fortawesome/free-solid-svg-icons';
import { CommonButton } from './utils/CommonButton';
import SearchIcon from '@mui/icons-material/Search';

const Role = () => {
  const [roles, setRoles] = useState([]);
  const [roleName, setRoleName] = useState('');
  const [resources, setResources] = useState({
    compliance: true,
    measure: true,
    impactLabel: true,
    reports: true,
    settings: true,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [selectedRoleId, setSelectedRoleId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRoles, setFilteredRoles] = useState([]);
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    fetchRoles();
  }, []);

  const fetchRoles = async () => {
    try {
      const response = await axios.get(RestUrlsConstants.roleUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setRoles(response.data.data);
      setFilteredRoles(response.data.data);
      setShowTable(true);
    } catch (error) {
      console.error('Error fetching roles:', error);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!roleName.trim()) errors.roleName = 'Role Name is required';
    if (!Object.values(resources).includes(true)) errors.resources = 'At least one resource must be selected';

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const createRole = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const role = {
        name: roleName,
        ...resources,
      };

      const response = await httpService.post(RestUrlsConstants.roleUrl, role, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      if (!response.data) {
        throw new Error('Failed to create role');
      }

      await fetchRoles();
      setShowForm(false);
      setShowTable(true);
      setUpdateMode(false);
      resetForm();
    } catch (error) {
      setError(error?.response?.data?.message || 'Failed to create role');
    } finally {
      setLoading(false);
    }
  };

  const updateRole = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const updatedRole = {
        name: roleName,
        ...resources,
      };
      delete updatedRole.userManagement;
      if (selectedRoleId) {
        await httpService.patch(`${RestUrlsConstants.roleUrl}${selectedRoleId}`, updatedRole, {
          headers: { Authorization: localStorage.getItem('Authorization') },
        });

        await fetchRoles();
        setShowForm(false);
        setShowTable(true);
        setUpdateMode(false);
        resetForm();
      } else {
        throw new Error('Selected role ID is invalid or missing.');
      }
    } catch (error) {
      setError(error?.response?.data?.message || 'Failed to update role');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRole = (roleId) => {
    const selectedRole = roles.find((role) => role.id === roleId);
    setRoleName(selectedRole.name);
    setResources(selectedRole.resources);
    setSelectedRoleId(roleId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
    handleOpen();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (updateMode) {
      await updateRole();
    } else {
      await createRole();
    }
    handleClose();
  };

  const resetForm = () => {
    setRoleName('');
    setResources({
      compliance: true,
      measure: true,
      impactLabel: true,
      reports: true,
      settings: true,
    });
    setValidationErrors({});
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(!showTable);
    resetForm();
    handleOpen();
  };

  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    if (term.trim() === '') {
      setFilteredRoles(roles);
    } else {
      const filtered = roles.filter((brand) => brand.name.toLowerCase().includes(term.trim().toLowerCase()));
      setFilteredRoles(filtered);
    }
  };

  const totalPages = Math.ceil(filteredRoles.length / 5);

  const handlePageChange = (page) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const indexOfLastBrand = currentPage * 5;
  const indexOfFirstBrand = indexOfLastBrand - 5;
  const currentRoles = filteredRoles.slice(indexOfFirstBrand, indexOfLastBrand);

  const formatResourceName = (name) => {
    return name === 'impactLabel' ? 'Impact Label' : name;
  };

  const [modalOpen, setModalOpen] = useState(false);

  const handleOpen = () => {
    setModalOpen(true);
  };

  const handleClose = () => {
    setModalOpen(false);
  };

  return (
    <>
      <Card className="example" sx={{ borderRadius: '20px' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <CommonButton buttonName={'Add Role'} handleClick={toggleFormVisibility} />
            <TextField
              size="small"
              variant="outlined"
              placeholder="Search brands"
              value={searchTerm}
              onChange={handleSearchChange}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>

          <Dialog open={modalOpen} onClose={handleClose}>
            <DialogContent className='example'>
              <div className="card-body">
                <h3 className="mb-4 text-center">{updateMode ? 'Update Role' : 'Role Form'}</h3>
                <form onSubmit={handleSubmit}>
                  <div className="form-group mb-4 row">
                    <label htmlFor="roleName" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Role Name
                    </label>
                    <div className="col-sm-9">
                      <input
                        type="text"
                        id="roleName"
                        className="form-control"
                        placeholder="Role Name"
                        value={roleName}
                        onChange={(e) => setRoleName(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {validationErrors.roleName && <div className="text-danger">{validationErrors.roleName}</div>}
                    </div>
                  </div>

                  <div className="form-group mb-4 row">
                    <label className="col-sm-3 col-form-label font-weight-bold text-right">Resources</label>
                    <div className="col-sm-9">
                      {Object.entries(resources).map(
                        ([key, value]) =>
                          key !== 'userManagement' && (
                            <div className="form-check" key={key}>
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id={`resource-${key}`}
                                checked={value}
                                onChange={() => setResources((prevResources) => ({ ...prevResources, [key]: !value }))}
                              />
                              <label className="form-check-label" htmlFor={`resource-${key}`}>
                                {formatResourceName(key)}
                              </label>
                            </div>
                          )
                      )}
                      {validationErrors.resources && <div className="text-danger">{validationErrors.resources}</div>}
                    </div>
                  </div>

                  <div className="d-grid gap-2">
                    <button type="submit" className="btn btn-dark" disabled={loading}>
                      {loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                          <span className="sr-only">Loading...</span>
                        </>
                      ) : updateMode ? (
                        'Update Role'
                      ) : (
                        'Create Role'
                      )}
                    </button>
                  </div>
                </form>
                <div className="d-grid gap-2  mt-3">
                  <button
                    className="btn btn-secondary"
                    onClick={() => {
                      setShowForm(false);
                      setShowTable(true);
                      resetForm();
                      handleClose();
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Box>
            <TableContainer>
              <Typography sx={{ fontWeight: 'bold', mt: 4, fontSize: '24px' }}>ROLES</Typography>
              <Table sx={{ cursor: 'pointer' }}>
                <TableHead>
                  <TableRow>
                    <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Role Name</TableCell>
                    {Object.keys(resources).map((resource) => {
                      if (resource !== 'userManagement') {
                        return (
                          <TableCell sx={{ fontWeight: '700', fontSize: '12px', textTransform: 'capitalize' }} key={resource}>
                            {formatResourceName(resource)}
                          </TableCell>
                        );
                      }
                      return null;
                    })}
                    <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentRoles.map((role) => (
                    <TableRow key={role.id}>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{role.name}</TableCell>
                      {Object.entries(role.resources).map(([resource, hasAccess]) => {
                        if (resource !== 'userManagement') {
                          return (
                            <TableCell key={resource}>
                              <Checkbox size="small" checked={hasAccess} readOnly color="success" />
                            </TableCell>
                          );
                        }
                        return null;
                      })}
                      <TableCell onClick={() => handleUpdateRole(role.id)}>
                        <Typography
                          sx={{
                            display: 'flex',
                            gap: '10px',
                            alignItems: 'center',
                            fontSize: '12px',
                            ':hover': { background: 'lightgray', color: 'red' },
                            p: '4px',
                            borderRadius: '2px',
                            fontWeight: '700',
                          }}
                        >
                          <FontAwesomeIcon style={{ color: 'blue' }} icon={faPenToSquare} />
                          Edit
                        </Typography>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box mt={1} sx={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: 'gray' }}>Page: {currentPage}</span>
                <Box>
                  <IconButton disabled={currentPage === 1}>
                    <KeyboardArrowLeftIcon onClick={() => handlePageChange(currentPage - 1)} />
                  </IconButton>
                  <IconButton disabled={currentPage === totalPages}>
                    <KeyboardArrowRightIcon onClick={() => handlePageChange(currentPage + 1)} />
                  </IconButton>
                </Box>
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </>
  );
};

export default Role;
