import { Box, Button, Card, CardContent, Grid, Tab, Tabs, Typography } from '@mui/material';
import SelectedClaims from './selectedClaims';
import img1 from '../../images/claim.jpg';
import { CommonButton } from '../utils/CommonButton';
import { GrCertificate } from 'react-icons/gr';
import { IoCheckmarkDone } from 'react-icons/io5';
import { useState } from 'react';
import { FaHandPointUp } from 'react-icons/fa';
import { RiCompassFill } from 'react-icons/ri';
import ClaimCertification from './ClaimCertification';

const ClaimManagement = () => {
  const [showCertificate, setShowCertificate] = useState(false);
  // const [value, setValue] = useState(0);
  // const handleChange = (event, newValue) => {
  //   setValue(newValue);
  // };

  return (
    <>
      {showCertificate ? (
        <ClaimCertification setShowCertificate={setShowCertificate} />
      ) : (
        <Box>
          <Grid container spacing={2} pb={6}>
            <Grid item xs={12} md={6}>
              <Card sx={{ borderRadius: '10px', height: '200px', padding: '0px', boxShadow: 'none' }}>
                <CardContent sx={{ padding: '0px', display: 'flex' }}>
                  <Box>
                    <img src={img1} height={'200px'} width={'200px'} alt="" />
                  </Box>
                  <Box sx={{ p: 2, display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
                    <Box>
                      <Typography sx={{ fontWeight: 'bold', fontSize: '16px', color: '#000' }}>Goles and targets</Typography>
                      <Typography sx={{ color: 'gray', fontSize: '12px' }}>Your ongoing journey as a transparent and commited companies continues here</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <Typography sx={{ fontSize: '14px', fontWeight: 'bold' }}>
                        GOALS SETS <span style={{ fontSize: '16px' }}>{'0'}</span>
                      </Typography>
                      <Button variant="contained" disabled sx={{ borderRadius: '15px' }}>
                        Begin
                      </Button>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
            <Grid item xs={12} md={6} sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
              <Card sx={{ borderRadius: '10px', boxShadow: 'none' }}>
                <CardContent sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Typography sx={{ fontWeight: 'bold' }}>
                    <GrCertificate style={{ fontSize: '24px' }} /> Certifications and proof points{' '}
                  </Typography>
                  <Box sx={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                    <span style={{ fontWeight: 'bold' }}>2</span>
                    <CommonButton buttonName={'MANAGE'} handleClick={() => setShowCertificate(true)} />
                  </Box>
                </CardContent>
              </Card>
              <Box sx={{ display: 'flex', justifyContent: 'end' }}>
                <Button color="success" variant="outlined" sx={{ fontWeight: 'bold', textTransform: 'none', borderRadius: '10px' }}>
                  <IoCheckmarkDone style={{ fontSize: '20px' }} /> Submitted for review
                </Button>
              </Box>
            </Grid>
          </Grid>
          {/* <Box sx={{ flexGrow: 1, marginBottom: '20px' }}>
            <Box sx={{ display: 'flex', justifyContent: 'center' }}>
              <Tabs
              indicatorColor=''
               value={value} onChange={handleChange} sx={{ borderRadius: '20px' }}>
                <Tab
                  label={
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      <FaHandPointUp style={{ marginRight: 8, fontSize: '24px' }} /> Selected claim
                    </span>
                  }
                  sx={{
                    textTransform: 'none',
                    display: 'flex',
                    backgroundColor: '#d4d4d4',
                    color: '#000',
                    fontWeight: 'bold',
                    fontSize: '14px',
                    padding: '0px 50px',
                    '&:hover': {
                      backgroundColor: '#e0e0e0',
                    },
                    '&.Mui-selected': {
                      backgroundColor: '#545454',
                      color: '#fff',

                      borderBottom: 'none',
                    },
                    '&.MuiTabs-indicator': {
                      display: 'none',
                    },
                  }}
                />
                <Tab
                  label={
                    <span style={{ display: 'flex', alignItems: 'center' }}>
                      <RiCompassFill style={{ marginRight: 8, fontSize: '24px' }} /> Discovery mode
                    </span>
                  }
                  // className={classes.customTab}
                  sx={{
                    textTransform: 'none',
                    backgroundColor: '#d4d4d4',
                    color: '#000',
                    fontWeight: 'bold',
                    fontSize: '14px',
                    padding: '0px 50px',
                    '&:hover': {
                      backgroundColor: '#e0e0e0',
                    },
                    '&.Mui-selected': {
                      backgroundColor: '#545454',
                      color: '#fff',

                      borderBottom: 'none',
                    },
                    '&.MuiTabs-indicator': {
                      display: 'none',
                    },
                  }}
                />
              </Tabs>
            </Box>
          </Box> */}
          <SelectedClaims />
        </Box>
      )}
    </>
  );
};

export default ClaimManagement;
