import { Box, Button, Card, CardContent, DialogActions, DialogContentText, InputLabel, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import { IoMdArrowBack } from 'react-icons/io';
import CommonSwitch from '../utils/CommonSwitch';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import CommonDialog from '../utils/CommonDialog';
import { useRef, useState } from 'react';
import { IoIosInformationCircleOutline } from 'react-icons/io';
import { CommonButton } from '../utils/CommonButton';
import EditIcon from '@mui/icons-material/Edit';

const ClaimCertification = ({ setShowCertificate }) => {
  const [open, setOpen] = useState(false);
  const fileInputRef = useRef(null);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      console.log('Selected file:', file.name);
    }
  };
  const certificate = [
    {
      preview: 'preview',
      name: 'self declaration template company ownership',
      emmissionDate: '10/01/2022',
      expDate: '10/01/2023',
      validated: '02/08/2023',
    },
    {
      preview: 'preview',
      name: 'Gots certifications',
      emmissionDate: '16/12/2022',
      expDate: '16/12/2027',
      validated: '02/08/2023',
    },
  ];
  return (
    <>
      <Box>
        <Typography mb={3} onClick={() => setShowCertificate(false)} sx={{ fontSize: '14px', cursor: 'pointer' }}>
          <IoMdArrowBack /> Back
        </Typography>
        <Card sx={{ borderRadius: '20px', boxShadow: 'none' }}>
          <CardContent>
            <Typography sx={{ fontWeight: 'bold' }}>Certifications and proof points uploaded</Typography>
            <Box>
              <TableContainer>
                <Table sx={{ cursor: 'pointer' }}>
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Preview</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Name</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Date of emission</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>Expiration date</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>
                        Alerts <span>30 days before expiration date</span>
                      </TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }}>
                        Validated <span>From issuing today</span>
                      </TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {certificate.map((val, index) => (
                      <TableRow sx={{ ':hover': { background: '#f5f5f5' } }} key={index} onClick={() => handleClickOpen()}>
                        <TableCell sx={{ fontWeight: '700', fontSize: '12px', border: 'none' }}>{val.preview}</TableCell>
                        <TableCell sx={{ fontWeight: '700', fontSize: '12px', border: 'none' }}>{val.name}</TableCell>
                        <TableCell sx={{ fontWeight: '700', fontSize: '12px', border: 'none' }}>{val.emmissionDate}</TableCell>
                        <TableCell sx={{ fontWeight: '700', fontSize: '12px', border: 'none' }}>{val.expDate}</TableCell>
                        <TableCell sx={{ border: 'none' }}>
                          <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: '700', fontSize: '12px' }}>
                            <CommonSwitch /> ON
                          </Box>
                        </TableCell>
                        <TableCell sx={{ fontWeight: '700', fontSize: '12px', border: 'none' }}>
                          <CheckCircleIcon color="success" sx={{ fontSize: '16px' }} /> {val.validated}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          </CardContent>
        </Card>
        <CommonDialog
          heading={
            <span>
              Certification details <IoIosInformationCircleOutline />
            </span>
          }
          open={open}
          handleClose={handleClose}
          dialogWidth="70%"
        >
          <DialogContentText >
            <form>
            <InputLabel>Attachment</InputLabel>
              <input ref={fileInputRef} type="file" hidden  onChange={handleFileChange} />
              <Button sx={{height:"200px",width:"200px",color:"#fff",background:"#f2f2f2",":hover":{background:"#ededed"}}} variant="contained" onClick={handleButtonClick}>
                <EditIcon/>
              </Button>
            </form>
            <DialogActions>
              <Button sx={{ borderRadius: '15px', textTransform: 'none' }} variant="contained" color="error" onClick={handleClose}>
                Delete permanently
              </Button>
              <CommonButton buttonName={'save'} handleClick={handleClose} />
            </DialogActions>
          </DialogContentText>
        </CommonDialog>
      </Box>
    </>
  );
};
export default ClaimCertification;
