import Avatar from '@mui/material/Avatar';
import { deepOrange } from '@mui/material/colors';
import logo from '../images/renoon_app_icon.png';
import { Grid, Card, CardContent, Typography, Divider, Box, Table, TableHead, TableRow, TableCell, TableBody } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import OpenInNewOutlinedIcon from '@mui/icons-material/OpenInNewOutlined';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
const Home = () => {
  const retailers = [
    { name: 'Net-a-porter', status: 'Approved' },
    { name: 'LUISAVIAROMA', status: 'Pending' },
    { name: 'ANTONIOLI', status: 'Pending' },
  ];
  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <Card sx={{ boxShadow: 'none', borderRadius: '20px' }}>
            <CardContent sx={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
              <Avatar sx={{ bgcolor: deepOrange[500] }} style={{ marginRight: '30px', fontSize: '12px' }} alt="Remy Sharp" src="/broken-image.jpg">
                Demo
              </Avatar>
              <Typography fontWeight={'bold'}>Demo Account</Typography>
              <img src={logo} alt="Your Logo" width="35" height="35" style={{ borderRadius: '50%' }} />
              <span style={{ fontWeight: '600' }}>
                Renoon <br /> Score
              </span>
              <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50px' }}>
                <Divider orientation="vertical" sx={{ height: '100%', backgroundColor: 'gray' }} />
              </Box>
              <Typography sx={{ fontWeight: '600' }}>
                80<span style={{ fontSize: '10px', color: 'gray' }}>/705</span> <br /> 44°{' '}
                <span style={{ fontSize: '10px', color: 'gray' }}>
                  percentile
                  <InfoOutlinedIcon sx={{ fontSize: '14px' }} />
                </span>
              </Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <Card sx={{px:2,borderRadius:"20px"}}>
              <Table>
                <TableHead>
                  <TableRow sx={{ border: 'none' }}>
                    <TableCell sx={{border:"none",fontWeight:"bold",fontSize:"16px"}} >Retailer</TableCell>
                    <TableCell sx={{border:"none",fontWeight:"bold",fontSize:"16px"}}>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {retailers.map((retailer, index) => (
                    <TableRow key={index} sx={{":hover":{background:"#f5f5f5",cursor:"pointer"}}}>
                      <TableCell sx={{border:"none"}}>{retailer.name}</TableCell>
                      <TableCell sx={{display:"flex",justifyContent:"space-between",alignItems:"center",border:"none"}}>
                        <Typography sx={{fontSize:"12px",fontWeight:"600",  fontStyle:retailer.status==="Pending"?"italic":""}} >
                          {' '}
                          {retailer.status === 'Approved' && <CheckCircleIcon sx={{ color: 'blue',fontSize:"14px" }} />}
                          {retailer.status}
                        </Typography>
                        <OpenInNewOutlinedIcon sx={{fontSize:"16px" }} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
          </Card>
        </Grid>
      </Grid>
      <Box mt={6}>
      <Typography sx={{fontWeight:"bold"}}>Your Product</Typography>
      </Box>
    </>
  );
};

export default Home;
