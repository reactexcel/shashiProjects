import * as React from 'react';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';

export default function CommonOption(props) {
    const {label,options,handleChange,value,tooltip}=props;
  return (
    <FormControl sx={{mt:4}} >
   
      <FormLabel sx={{color:"#000",fontWeight:"600",fontSize:"14px"}}>{label}</FormLabel>
      <RadioGroup
        aria-labelledby="demo-radio-buttons-group-label"
        name="radio-buttons-group"
        value={value}
        onChange={handleChange}
      >
      {
        options.map((val)=>(
            <FormControlLabel sx={{color:"#000",fontSize:"12px"}} value={val} control={<Radio />} label={val} />
        ))
      }
      </RadioGroup>
    </FormControl>
  );
}
