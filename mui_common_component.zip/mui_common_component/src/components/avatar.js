import * as React from 'react';
import Box from '@mui/material/Box';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import LogoutIcon from '@mui/icons-material/Logout';
import Avatar from '@mui/material/Avatar';
import { deepOrange } from '@mui/material/colors';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { removeUser } from '../common/userSlice';
import Popover from '@mui/material/Popover';
export default function BasicList({ name, email,showLogout,setShowLogout }) {
  const dispatch = useDispatch();
  const firstName = name?.split(' ')[0][0].toUpperCase() + name?.split(' ')[0].slice(1);
  const lastName = name?.split(' ')[1] && name?.split(' ')[1] && name?.split(' ')[1][0].toUpperCase() + name?.split(' ')[1].slice(1);
  const navigation = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem('Authorization');
    localStorage.removeItem('resources');
    dispatch(removeUser());
    navigation('/login');
  };
  const id = showLogout ? 'simple-popover' : undefined;
  return (
    <>
      <Popover
        id={id}
        open={showLogout}
        anchorEl={showLogout}
        onClose={()=>setShowLogout(false)}
        sx={{marginTop:"50px"}}
        PaperProps={{
          sx: { width: '250px', padding: '16px' }  
        }}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'right',
        }}
      >
        <Box>
            <List>
              <ListItem disablePadding>
                <Avatar sx={{ bgcolor: deepOrange[500], marginRight: '10px', height: '40px' }} alt="Remy Sharp" src="/broken-image.jpg">
                  {name?.split(' ')[0] && name.split(' ')[0][0] && name.split(' ')[0][0].toUpperCase()}
                  {name?.split(' ')[1] && name.split(' ')[1][0] && name.split(' ')[1][0].toUpperCase()}
                </Avatar>
              </ListItem>
              <ListItem disablePadding className="f-w">
                {firstName + ' ' + lastName}
              </ListItem>
              <ListItem disablePadding style={{ color: '#6a6967' }}>
                {email}
              </ListItem>
              <ListItem onClick={handleLogout} disablePadding style={{ marginBottom: '10px', cursor: 'pointer' }}>
                <LogoutIcon></LogoutIcon>Log out
              </ListItem>
            </List>
        </Box>
      </Popover>
    </>
  );
}
