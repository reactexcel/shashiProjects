import { Typography } from '@mui/material'

const Profile = () => {
  return (
    <Typography>My Profile</Typography>
  )
}

export default Profile
