import { useEffect, useState } from 'react';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { useDispatch } from 'react-redux';
import { addUser, removeUser } from '../common/userSlice';
import { useNavigate } from 'react-router-dom';

const Auth = () => {
  const dispatch = useDispatch();
  const navigation = useNavigate();
  const handleClose = () => setsnackBar({ ...snackBar, open: false });
  const [snackBar, setsnackBar] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'center',
  });
  const douthentiction = () => {
    const token = localStorage.getItem('Authorization');
    if (token) {
      httpService
        .get(RestUrlsConstants.authUrl, { headers: { Authorization: localStorage.getItem('Authorization') } })
        .then((data) => {
          dispatch(addUser({ email: data.data.data.email, name: data.data.data.name }));
        })
        .catch(() => {
          setsnackBar({ ...snackBar, open: true });
          localStorage.removeItem('Authorization');
          dispatch(removeUser());
        });
    } else {
      navigation('/login');
    }
  };

  useEffect(() => {
    douthentiction();
  }, []);
  return { snackBar, handleClose };
};

export default Auth;
