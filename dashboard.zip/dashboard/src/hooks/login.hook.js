import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';

const useLoginHook = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [snackBar, setsnackBar] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'center',
    message: '',
  });

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClose = () => setsnackBar({ ...snackBar, open: false });
  const handleMouseDownPassword = (event) => event.preventDefault();
  const email = useRef(null);
  const password = useRef(null);
  const navigate = useNavigate();

  const signIn = async () => {
    if (email.current.value && password.current.value) {
      try {
        const login = await httpService.post(RestUrlsConstants.loginUrl, {
          email: email.current.value,
          password: password.current.value,
        });
        localStorage.setItem('Authorization', login.data.data.token);
        navigate('/');
      } catch {
        setsnackBar({ ...snackBar, open: true, message: 'Invalid credentials' });
      }
    }
  };

  useEffect(() => {
    if (localStorage.getItem('Authorization')) {
      navigate('/');
    }
  }, [navigate]);

  return { showPassword, snackBar, email, password, handleClickShowPassword, handleClose, handleMouseDownPassword, signIn };
};

export default useLoginHook;
