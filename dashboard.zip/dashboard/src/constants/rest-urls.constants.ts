export const RestUrlsConstants = {
  loginUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/user/login`,
  userUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/user/`,
  brandUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/brand/`,
  authUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/user/auth/`,
  claimUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/claims/`,
  roleUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/role/`,
  verifyEmailUrl: `${process.env.REACT_APP_DASHBOARD_API_URL}/user/verify-email`,
};
