import { BrowserRouter, Routes, Route } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import Login from './components/login';
import Home from './components/home';
import Nav from './components/nav';
import User from './components/user';
import Report from './components/report';
import ClaimManagement from './components/claim_management/ClaimManagement';
import OrderEngine from './components/orderEngine';
import ProductEngine from './components/productEngine';
import SupplierMap from './components/supplierMap';
import Role from './components/role';
import Brand from './components/brand';
import { Provider } from 'react-redux';
import appStore from './common/app.store';
import ResetPassword from './components/resetPassword';
import ForgotPassword from './components/forgotPassword';
function App() {
  console.log(process.env.REACT_APP_DASHBOARD_API_URL);
  return (
    <div className="App">
      <Provider store={appStore}>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login></Login>} />
            <Route path="/forgot-password" element={<ForgotPassword></ForgotPassword>} />
            <Route path="/reset-password/:token" element={<ResetPassword></ResetPassword>} />
            <Route path="/" element={<Nav></Nav>}>
              <Route path="home" element={<Home></Home>} />
              <Route path="role" element={<Role></Role>} />
              <Route path="brand" element={<Brand></Brand>} />
              <Route path="user" element={<User></User>} />
              <Route path="report" element={<Report></Report>} />
              <Route path="claim-management" element={<ClaimManagement></ClaimManagement>} />
              <Route path="order-engine" element={<OrderEngine></OrderEngine>} />
              <Route path="product-engine" element={<ProductEngine></ProductEngine>} />
              <Route path="supplier-map" element={<SupplierMap></SupplierMap>} />
            </Route>
          </Routes>
        </BrowserRouter>
      </Provider>
    </div>
  );
}

export default App;
