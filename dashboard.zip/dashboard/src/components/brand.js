import React, { useState, useEffect } from 'react';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';

const Brand = () => {
  const [brands, setBrands] = useState([]);
  const [filteredBrands, setFilteredBrands] = useState([]);
  const [brandName, setBrandName] = useState('');
  const [contractStartDate, setContractStartDate] = useState('');
  const [contractEndDate, setContractEndDate] = useState('');
  const [maxProducts, setMaxProducts] = useState('');
  const [maxUsers, setMaxUsers] = useState('');
  const [features, setFeatures] = useState('');
  const [contractFiles, setContractFiles] = useState([]);
  const [logo, setLogo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const [selectedBrandId, setSelectedBrandId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [formErrors, setFormErrors] = useState({});

  useEffect(() => {
    fetchBrands();
  }, []);

  useEffect(() => {
    setFilteredBrands(brands);
  }, [brands]);

  const fetchBrands = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.brandUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setBrands(response.data.data);
      setShowTable(true);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!brandName) errors.brandName = 'Brand Name is required';
    if (!contractStartDate) errors.contractStartDate = 'Contract Start Date is required';
    if (!contractEndDate) errors.contractEndDate = 'Contract End Date is required';
    if (!maxProducts) errors.maxProducts = 'Max Products is required';
    if (!maxUsers) errors.maxUsers = 'Max Users is required';
    if (!features) errors.features = 'Features are required';
    if (!contractFiles) errors.contractFiles = 'Contract Files are required';
    if (!logo) errors.logo = 'Logo is required';
    return errors;
  };

  const createBrand = async () => {
    try {
      setLoading(true);
      setError(null);

      const formData = new FormData();
      formData.append('name', brandName);
      formData.append('contractStartDate', contractStartDate.slice(0, 10));
      formData.append('contractEndDate', contractEndDate.slice(0, 10));
      formData.append('maxProducts', maxProducts);
      formData.append('maxUsers', maxUsers);
      formData.append('features', JSON.stringify(features.split(',').map((feature) => feature.trim())));

      for (let i = 0; i < contractFiles.length; i++) {
        formData.append('contractFiles', contractFiles[i]);
      }
      if (logo) {
        formData.append('logo', logo);
      }

      const response = await httpService.post(RestUrlsConstants.brandUrl, formData, {
        headers: {
          Authorization: localStorage.getItem('Authorization'),
          'Content-Type': 'multipart/form-data',
        },
      });

      if (!response.data) {
        throw new Error('Failed to create brand');
      }

      await fetchBrands();
      setShowForm(false);
      resetFormFields();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const updateBrand = async () => {
    try {
      setLoading(true);
      setError(null);

      const formData = new FormData();
      formData.append('name', brandName);
      formData.append('contractStartDate', contractStartDate.slice(0, 10));
      formData.append('contractEndDate', contractEndDate.slice(0, 10));
      formData.append('maxProducts', maxProducts);
      formData.append('maxUsers', maxUsers);
      formData.append('features', JSON.stringify(features.split(',').map((feature) => feature.trim())));

      if (Array.isArray(contractFiles)) {
        for (let i = 0; i < contractFiles.length; i++) {
          formData.append('contractFiles', contractFiles[i]);
        }
      }

      if (logo) {
        formData.append('logo', logo);
      }

      await httpService.put(`${RestUrlsConstants.brandUrl}${selectedBrandId}`, formData, {
        headers: {
          Authorization: localStorage.getItem('Authorization'),
          'Content-Type': 'multipart/form-data',
        },
      });

      await fetchBrands();
      setUpdateMode(false);
      setShowForm(false);
      resetFormFields();
      setSelectedBrandId(null);
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteBrand = async (brandId) => {
    try {
      setLoading(true);
      setError(null);

      await httpService.delete(`${RestUrlsConstants.brandUrl}${brandId}`, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      await fetchBrands();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateBrand = (brandId) => {
    const selectedBrand = brands.find((brand) => brand.id === brandId);
    setBrandName(selectedBrand.name);
    setContractStartDate(selectedBrand.contractStartDate);
    setContractEndDate(selectedBrand.contractEndDate);
    setMaxProducts(selectedBrand.maxProducts);
    setMaxUsers(selectedBrand.maxUsers);
    setFeatures(selectedBrand.features.join(','));
    setContractFiles([]);
    setLogo(null);
    setSelectedBrandId(brandId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    if (updateMode) {
      await updateBrand();
    } else {
      await createBrand();
    }
  };

  const resetFormFields = () => {
    setBrandName('');
    setContractStartDate('');
    setContractEndDate('');
    setMaxProducts('');
    setMaxUsers('');
    setFeatures('');
    setContractFiles([]);
    setLogo(null);
    setFormErrors({});
  };

  const handleDeleteBrand = async (brandId) => {
    if (window.confirm('Are you sure you want to delete this brand?')) {
      await deleteBrand(brandId);
    }
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(false);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleSearchClick = () => {
    const term = String(searchTerm);
    const filtered = brands.filter((brand) => brand.name.toLowerCase().includes(term.toLowerCase()));
    setFilteredBrands(filtered);
  };

  const handleFileChange = (e) => {
    const files = e.target.files;
    setContractFiles(files);
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    setLogo(file);
  };

  const indexOfLastBrand = currentPage * 10;
  const indexOfFirstBrand = indexOfLastBrand - 10;
  const currentBrands = filteredBrands.slice(indexOfFirstBrand, indexOfLastBrand);

  return (
    <div className="container mt-5">
      {!showForm && (
        <div className="d-flex justify-content-between align-items-center mb-3">
          <button className="btn btn-dark" onClick={toggleFormVisibility}>
            Add Brand
          </button>
          <div className="input-group" style={{ maxWidth: '300px' }}>
            <input type="text" className="form-control" placeholder="Search brands" aria-label="Enter brand name" aria-describedby="basic-addon2" onChange={(e) => setSearchTerm(e.target.value)} />
            <div className="input-group-append">
              <button className="btn btn-dark" type="button" onClick={handleSearchClick}>
                Search
              </button>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <div className="card bg-light border mt-4 mx-auto" style={{ maxWidth: '50%' }}>
          <div className="card-body">
            <h3 className="mb-4 text-center">{updateMode ? 'UPDATE BRAND' : 'BRAND ONBOARDING FORM'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group mb-4 row">
                <label htmlFor="brandName" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Brand Name
                </label>
                <div className="col-sm-9">
                  <input
                    type="text"
                    id="brandName"
                    className="form-control"
                    placeholder="Brand Name"
                    value={brandName}
                    onChange={(e) => setBrandName(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.brandName && <div className="text-danger">{formErrors.brandName}</div>}
                </div>
              </div>

              <div className="form-group mb-4 row">
                <label htmlFor="contractStartDate" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Contract Start Date
                </label>
                <div className="col-sm-9">
                  <input
                    type="date"
                    id="contractStartDate"
                    className="form-control"
                    placeholder="Contract Start Date"
                    value={contractStartDate ? contractStartDate.slice(0, 10) : ''}
                    onChange={(e) => setContractStartDate(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.contractStartDate && <div className="text-danger">{formErrors.contractStartDate}</div>}
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="contractEndDate" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Contract End Date
                </label>
                <div className="col-sm-9">
                  <input
                    type="date"
                    id="contractEndDate"
                    className="form-control"
                    placeholder="Contract End Date"
                    value={contractEndDate ? contractEndDate.slice(0, 10) : ''}
                    onChange={(e) => setContractEndDate(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.contractEndDate && <div className="text-danger">{formErrors.contractEndDate}</div>}
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="maxProducts" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Max Products
                </label>
                <div className="col-sm-9">
                  <input
                    type="number"
                    id="maxProducts"
                    className="form-control"
                    placeholder="Max Products"
                    value={maxProducts}
                    onChange={(e) => setMaxProducts(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.maxProducts && <div className="text-danger">{formErrors.maxProducts}</div>}
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="maxUsers" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Max Users
                </label>
                <div className="col-sm-9">
                  <input
                    type="number"
                    id="maxUsers"
                    className="form-control"
                    placeholder="Max Users"
                    value={maxUsers}
                    onChange={(e) => setMaxUsers(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.maxUsers && <div className="text-danger">{formErrors.maxUsers}</div>}
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="features" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Features
                </label>
                <div className="col-sm-9">
                  <input
                    type="text"
                    id="features"
                    className="form-control"
                    placeholder="Features"
                    value={features}
                    onChange={(e) => setFeatures(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {formErrors.features && <div className="text-danger">{formErrors.features}</div>}
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="contractFiles" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Contract Files
                </label>
                <div className="col-sm-9">
                  <input type="file" id="contractFiles" className="form-control" onChange={handleFileChange} multiple style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} />
                </div>
              </div>
              <div className="form-group mb-4 row">
                <label htmlFor="logo" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Logo
                </label>
                <div className="col-sm-9">
                  <input type="file" id="logo" className="form-control" onChange={handleLogoChange} multiple style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} />
                </div>
              </div>

              <div className="d-grid gap-2">
                <button type="submit" className="btn btn-dark">
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                      <span className="sr-only">Loading...</span>
                    </>
                  ) : updateMode ? (
                    'Update'
                  ) : (
                    'Submit'
                  )}
                </button>
              </div>
            </form>
            <div className="d-flex justify-content-center mt-3">
              <button
                className="btn btn-link btn-sm p-0"
                onClick={() => {
                  setShowForm(false);
                  setShowTable(true);
                  resetFormFields();
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showTable && (
        <div className="table-responsive mt-4">
          <h3>BRANDS</h3>
          <table className="table table-striped table-bordered table-hover">
            <thead className="thead-dark text-center">
              <tr>
                <th scope="col">Brand Name</th>
                <th scope="col">Contract Start Date</th>
                <th scope="col">Contract End Date</th>
                <th scope="col">Max Products</th>
                <th scope="col">Max Users</th>
                <th scope="col">Features</th>
                <th scope="col">Contract files</th>
                <th scope="col">Logo</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {currentBrands.map((brand, index) => (
                <tr key={brand.id}>
                  <td>{brand.name}</td>
                  <td>{new Date(brand.contractStartDate).toLocaleDateString()}</td>
                  <td>{new Date(brand.contractEndDate).toLocaleDateString()}</td>
                  <td>{brand.maxProducts}</td>
                  <td>{brand.maxUsers}</td>
                  <td>{brand.features.join(', ')}</td>
                  <td>
                    {brand.contractFiles.map((file, i) => (
                      <div key={i}>
                        <a href={`${file}`} rel="noopener noreferrer">
                          Download
                        </a>
                      </div>
                    ))}
                  </td>
                  <td>{brand.logo && <img src={`${brand.logo}`} alt="logo" className="rounded-circle" style={{ width: '30px', height: '30px' }} />}</td>

                  <td>
                    <button className="btn btn-link" onClick={() => handleUpdateBrand(brand.id)}>
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </button>
                    &nbsp;
                    <button className="btn btn-link text-danger" onClick={() => handleDeleteBrand(brand.id)}>
                      <FontAwesomeIcon icon={faTrashCan} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div>
            <nav>
              <ul className="pagination">
                {Array.from({ length: Math.ceil(filteredBrands.length / 10) }).map((_, index) => (
                  <li className={`page-item ${currentPage === index + 1 ? 'active' : ''}`} key={index}>
                    <button className="page-link" onClick={() => handlePageChange(index + 1)}>
                      {index + 1}
                    </button>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>
      )}
    </div>
  );
};

export default Brand;
