import React, { useState, useEffect } from 'react';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';

const User = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [brandId, setBrandId] = useState('');
  const [roleId, setRoleId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [brands, setBrands] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    fetchBrands();
    fetchRoles();
    fetchUsers();
  }, []);

  useEffect(() => {
    setFilteredUsers(users);
  }, [users]);

  const fetchBrands = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.brandUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setBrands(response.data.data);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.roleUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setRoles(response.data.data);
    } catch (error) {
      console.error('Error fetching roles:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.userUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setUsers(response.data.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!firstName.trim()) errors.firstName = 'First Name is required';
    if (!lastName.trim()) errors.lastName = 'Last Name is required';
    if (!email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email is invalid';
    }
    if (!updateMode && !password.trim()) errors.password = 'Password is required';
    if (!roleId) errors.roleId = 'Role is required';
    if (!brandId) errors.brandId = 'Brand is required';

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const createUser = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const user = {
        firstName,
        lastName,
        email,
        password,
        roleId,
        brandId,
      };

      const response = await httpService.post(RestUrlsConstants.userUrl, user, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      if (!response.data) {
        throw new Error('Failed to create user');
      }

      await fetchUsers();
      setShowForm(false);
      setFirstName('');
      setLastName('');
      setPassword('');
      setEmail('');
      setBrandId('');
      setRoleId('');
      setShowTable(true);
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const updateUser = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const updatedUser = {
        firstName,
        lastName,
        email,
        roleId,
        brandId,
      };

      if (password.trim() !== '') {
        updatedUser.password = password;
      }

      await httpService.put(`${RestUrlsConstants.userUrl}${selectedUserId}`, updatedUser, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      await fetchUsers();
      setUpdateMode(false);
      setShowForm(false);
      setShowTable(true);
      setFirstName('');
      setLastName('');
      setPassword('');
      setEmail('');
      setBrandId('');
      setRoleId('');
      setSelectedUserId(null);
    } catch (error) {
      if (error?.response?.data?.message?.includes('duplicate key error')) {
        setError('A user with this email already exists.');
      } else {
        setError(error?.response?.data?.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = (userId) => {
    const selectedUser = users.find((user) => user.id === userId);
    setFirstName(selectedUser.firstName);
    setLastName(selectedUser.lastName);
    setEmail(selectedUser.email);
    setPassword('');
    setBrandId(selectedUser.brandId);
    setRoleId(selectedUser.roleId);
    setSelectedUserId(userId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (updateMode) {
      await updateUser();
    } else {
      await createUser();
    }
  };

  const deleteUser = async (userId) => {
    try {
      setLoading(true);
      setError(null);

      await httpService.delete(`${RestUrlsConstants.userUrl}${userId}`, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      await fetchUsers();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteUser = async (userId) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      await deleteUser(userId);
    }
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(!showTable);
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleSearchClick = () => {
    const term = String(searchTerm);
    const filtered = users.filter(
      (user) => user.firstName.toLowerCase().includes(term.toLowerCase()) || user.lastName.toLowerCase().includes(term.toLowerCase()) || user.email.toLowerCase().includes(term.toLowerCase())
    );
    setFilteredUsers(filtered);
  };

  const indexOfLastUser = currentPage * 10;
  const indexOfFirstUser = indexOfLastUser - 10;
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

  return (
    <div className="container mt-5">
      {!showForm && (
        <div className="d-flex justify-content-between align-items-center mb-3">
          <button className="btn btn-dark" onClick={toggleFormVisibility}>
            Add User
          </button>
          <div className="input-group" style={{ maxWidth: '300px' }}>
            <input type="text" className="form-control" placeholder="Search users" aria-label="Enter username" aria-describedby="basic-addon2" onChange={(e) => setSearchTerm(e.target.value)} />
            <div className="input-group-append">
              <button className="btn btn-dark" type="button" onClick={handleSearchClick}>
                Search
              </button>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <div className="card bg-light border mt-4 mx-auto" style={{ maxWidth: '400px' }}>
          <div className="card-body">
            <h3 className="mb-4 text-center">{updateMode ? 'UPDATE USER' : 'USER ONBOARDING FORM'}</h3>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="form-group mb-4">
                <input
                  type="text"
                  id="firstName"
                  className="form-control"
                  placeholder="First Name"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                />
                {validationErrors.firstName && <div className="text-danger">{validationErrors.firstName}</div>}
              </div>
              <div className="form-group mb-4">
                <input
                  type="text"
                  id="lastName"
                  className="form-control"
                  placeholder="Last Name"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                />
                {validationErrors.lastName && <div className="text-danger">{validationErrors.lastName}</div>}
              </div>
              <div className="form-group mb-4">
                <input
                  type="email"
                  id="email"
                  className="form-control"
                  placeholder="Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                />
                {validationErrors.email && <div className="text-danger">{validationErrors.email}</div>}
              </div>
              {!updateMode && (
                <div className="form-group mb-4">
                  <input
                    type="password"
                    id="password"
                    className="form-control"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                  />
                  {validationErrors.password && <div className="text-danger">{validationErrors.password}</div>}
                </div>
              )}
              <div className="form-group mb-4">
                <select id="roleId" className="form-control" value={roleId} onChange={(e) => setRoleId(e.target.value)} style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}>
                  <option value="">Select Role</option>
                  {roles.map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
                </select>
                {validationErrors.roleId && <div className="text-danger">{validationErrors.roleId}</div>}
              </div>
              <div className="form-group mb-4">
                <select id="brandId" className="form-control" value={brandId} onChange={(e) => setBrandId(e.target.value)} style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}>
                  <option value="">Select Brand</option>
                  {brands.map((brand) => (
                    <option key={brand.id} value={brand.id}>
                      {brand.name}
                    </option>
                  ))}
                </select>
                {validationErrors.brandId && <div className="text-danger">{validationErrors.brandId}</div>}
              </div>
              <button type="submit" className="btn btn-dark mt-3 w-100" disabled={loading}>
                {loading ? (updateMode ? 'Updating User...' : 'Creating User...') : updateMode ? 'Update User' : 'Create User Account'}
              </button>
            </form>
            <div className="d-flex justify-content-center mt-3">
              <button
                className="btn btn-link btn-sm p-0"
                onClick={() => {
                  setShowForm(false);
                  setShowTable(true);
                  setError(null);
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {showTable && (
        <div className="table-responsive mt-4">
          <h3>USERS</h3>
          <table className="table table-striped table-bordered table-hover">
            <thead className="thead-dark text-center">
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {currentUsers.map((user, index) => (
                <tr key={index}>
                  <td>{user.firstName}</td>
                  <td>{user.lastName}</td>
                  <td>{user.email}</td>
                  <td>
                    <button name="update" onClick={() => handleUpdateUser(user.id)} className="btn btn-link">
                      <FontAwesomeIcon icon={faPenToSquare} />
                    </button>
                    &nbsp;
                    <button name="delete" onClick={() => handleDeleteUser(user.id)} className="btn btn-link text-danger">
                      <FontAwesomeIcon icon={faTrashCan} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <nav aria-label="Page navigation example">
            <ul className="pagination">
              {Array.from({ length: Math.ceil(filteredUsers.length / 10) }, (_, index) => (
                <li className={`page-item ${index + 1 === currentPage ? 'active' : ''}`} key={index}>
                  <button className="btn btn-dark page-link" onClick={() => handlePageChange(index + 1)}>
                    {index + 1}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}
    </div>
  );
};

export default User;
