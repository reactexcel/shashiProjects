import Avatar from '@mui/material/Avatar';
import { deepOrange } from '@mui/material/colors';
import logo from '../images/renoon_app_icon.png';
import Image from 'react-bootstrap/Image';
import { Card, Button, Badge, ListGroup } from 'react-bootstrap';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowUpRightFromSquare } from '@fortawesome/free-solid-svg-icons';
const Home = () => {
  const retailers = [
    { name: 'Net-a-porter', status: 'Approved', icon: '✔️' },
    { name: 'LUISAVIAROMA', status: 'Pending', icon: '' },
    { name: 'ANTONIOLI', status: 'Pending', icon: '' },
  ];
  return (
    <>
      <div className="left-side">
        <div className="row mt-5 p-3">
          <div className="col-md-6">
            <Card>
              <Card.Body className="d-flex flex-row justify-content-around align-items-center">
                <Avatar sx={{ bgcolor: deepOrange[500] }} style={{ marginRight: '30px' }} alt="Remy Sharp" src="/broken-image.jpg">
                  Demo
                </Avatar>
                <Card.Title>Demo Account</Card.Title>
                <div className="d-flex justify-content-around align-items-center flex-row">
                  <Image src={logo} alt="Your Logo" width="40" height="40" roundedCircle />
                  <div>Renoon Score</div>
                </div>
                |
                <div className="d-flex flex-column">
                  <div>Score 80/705</div>
                  <div>44° percentile</div>
                </div>
              </Card.Body>
            </Card>
          </div>
          <div className="col-md-6">
            <ListGroup>
              <ListGroup.Item variant="primary" className="fw-bold">
                <div className="row">
                  <div className="col">Retailer</div>
                  <div className="col text-center">Status</div>
                  <div className="col"></div>
                </div>
              </ListGroup.Item>
              {retailers.map((retailer, index) => (
                <ListGroup.Item key={index} className="d-flex justify-content-between align-items-center">
                  <div className="col">{retailer.name}</div>
                  <div className="col text-center">
                    <Badge bg={retailer.status === 'Approved' ? 'primary' : 'secondary'}>
                      {retailer.icon} {retailer.status}
                    </Badge>
                  </div>
                  <div className="col text-end">
                    <Button variant="outline-secondary" size="sm" className="ms-2">
                      <FontAwesomeIcon icon={faArrowUpRightFromSquare} />
                    </Button>
                  </div>
                </ListGroup.Item>
              ))}
            </ListGroup>
          </div>
        </div>
        <p class="h4 p-5">Your Products</p>
      </div>
    </>
  );
};

export default Home;
