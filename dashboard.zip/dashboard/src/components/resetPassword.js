import { useState, useRef } from 'react';
import useForgotPasswordHook from '../hooks/forgotPassword.hook';
import TextField from '@mui/material/TextField';
import FormControl from '@mui/material/FormControl';
import InputLabel from '@mui/material/InputLabel';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Button from '@mui/material/Button';
import Snackbar from '@mui/material/Snackbar';

const ResetPassword = () => {
  const { showPassword, snackBar, handleClickShowPassword, handleClose, handleMouseDownPassword, resetPassword } = useForgotPasswordHook();

  const newPassword = useRef(null);
  const confirmPassword = useRef(null);

  const handleResetPassword = () => {
    if (newPassword.current.value === confirmPassword.current.value) {
      resetPassword(newPassword.current.value);
    } else {
      console.error('Passwords do not match');
    }
  };

  return (
    <div className="w-100">
      <div className="m-top-6">
        <div className="w-100 center">
          <img src={require('../images/renoon_app_icon.png')} alt="panda" className="w-5 b-radius-20 m-50px"></img>
        </div>
        <div className="w-100 center">
          <div className="login-container">
            <p className="login-text">Set a new password</p>
            <form onSubmit={(e) => e.preventDefault()} className="p-hor-15">
              <FormControl variant="outlined" fullWidth margin="normal" required>
                <InputLabel htmlFor="outlined-adornment-new-password">New Password</InputLabel>
                <OutlinedInput
                  inputRef={newPassword}
                  id="outlined-adornment-new-password"
                  type={showPassword ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton aria-label="toggle password visibility" onClick={handleClickShowPassword} onMouseDown={handleMouseDownPassword} edge="end">
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                  label="New Password"
                  inputProps={{ minLength: 8 }}
                />
              </FormControl>

              <FormControl variant="outlined" fullWidth margin="normal" required>
                <InputLabel htmlFor="outlined-adornment-confirm-password">Confirm Password</InputLabel>
                <OutlinedInput
                  inputRef={confirmPassword}
                  id="outlined-adornment-confirm-password"
                  type={showPassword ? 'text' : 'password'}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton aria-label="toggle password visibility" onClick={handleClickShowPassword} onMouseDown={handleMouseDownPassword} edge="end">
                        {showPassword ? <VisibilityOff /> : <Visibility />}
                      </IconButton>
                    </InputAdornment>
                  }
                  label="Confirm Password"
                  inputProps={{ minLength: 8 }}
                />
              </FormControl>

              <Button
                variant="contained"
                fullWidth
                type="submit"
                style={{
                  background: 'black',
                  fontWeight: '1000',
                  marginTop: '10px',
                }}
                onClick={handleResetPassword}
              >
                Reset Password
              </Button>
            </form>
            <Snackbar
              open={snackBar.open}
              autoHideDuration={2000}
              message="Password reset successful"
              anchorOrigin={{
                vertical: snackBar.vertical,
                horizontal: snackBar.horizontal,
              }}
              onClose={handleClose}
              className="snackBarColor"
              key={snackBar.vertical + snackBar.horizontal}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
