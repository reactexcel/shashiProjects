import React from 'react';

const SupplierMap = () => {
  return (
    <div>
      <h2>Supplier Map Page</h2>
    </div>
  );
};

export default SupplierMap;
