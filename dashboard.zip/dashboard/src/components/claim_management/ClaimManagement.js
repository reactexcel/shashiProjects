import ClaimCards from './claimCards';
import SelectedClaims from './selectedClaims';
const ClaimManagement = () => {
  return (
    <div className="left-side">
      <SelectedClaims />
      <ClaimCards />
    </div>
  );
};
export default ClaimManagement;
