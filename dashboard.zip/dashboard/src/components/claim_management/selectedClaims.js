import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Button } from 'react-bootstrap';
import { FaCheck } from 'react-icons/fa';
import { RestUrlsConstants } from '../../constants/rest-urls.constants';
import axios from 'axios';
import httpService from '../../service/http.service';

const ToggleButton = ({ id, label, selected, fetchClaim }) => {
  const toggleSelect = () => {
    updateSelectedClaim();
  };
  const updateSelectedClaim = async () => {
    try {
      const response = await httpService.patch(RestUrlsConstants.claimUrl + id, { selected: !selected }, { headers: { Authorization: localStorage.getItem('Authorization') } });
      console.log(response);
      fetchClaim();
    } catch (error) {
      console.error('Error fetching claims:', error);
    }
  };

  return (
    <Button variant={selected ? 'success' : 'secondary'} onClick={toggleSelect} className="m-2">
      {selected && <FaCheck />} {label}
    </Button>
  );
};

const SelectedClaims = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetchClaim();
  }, []);

  const fetchClaim = async () => {
    try {
      const response = await axios.get(RestUrlsConstants.claimUrl, { headers: { Authorization: localStorage.getItem('Authorization') } });
      console.log(response);
      setData(response.data.data.claims);
    } catch (error) {
      console.error('Error fetching claims:', error);
    }
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col">
          <h2>Selected claims</h2>
          <p>Select the values you want to claim.</p>
          {data.map((item, index) => (
            <ToggleButton key={index} id={item.id} fetchClaim={fetchClaim} selected={item.selected} label={item.name} />
          ))}
          {/* <Button variant="primary">Confirm selection</Button> */}
        </div>
      </div>
    </div>
  );
};

export default SelectedClaims;
