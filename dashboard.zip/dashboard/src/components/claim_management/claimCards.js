import React from 'react';
import claim from '../../images/claim.jpg';

const cardData = [
  { title: 'Card title 1', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
  { title: 'Card title 2', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
  { title: 'Card title 3', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
  { title: 'Card title 4', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
  { title: 'Card title 5', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
  { title: 'Card title 6', text: "Some quick example text to build on the card title and make up the bulk of the card's content.", answered: '0/16' },
];

const ClaimCards = () => {
  return (
    <div className="container">
      <div className="row gy-5 py-5">
        {cardData.map((card, index) => (
          <div className="col-sm-12 col-md-6 col-lg-4" key={index}>
            <div className="card">
              <img className="card-img-top" src={claim} style={{ height: '200px' }} alt="Card image cap" />
              <div className="card-body">
                <h5 className="card-title">{card.title}</h5>
                <p className="card-text">{card.text}</p>
                <div className="d-flex flex-column justify-content-end font-weight-bold">
                  <div>Questions Answered</div>
                  <div>{card.answered}</div>
                </div>
                <a href="#" className="btn btn-primary">
                  Begin
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ClaimCards;
