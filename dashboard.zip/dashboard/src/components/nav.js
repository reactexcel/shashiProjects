import { useState } from 'react';
import { Sidebar, Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import { Link, Outlet } from 'react-router-dom';
import WalletRoundedIcon from '@mui/icons-material/WalletRounded';
import SettingsApplicationsRoundedIcon from '@mui/icons-material/SettingsApplicationsRounded';
import HomeIcon from '@mui/icons-material/Home';
import AssessmentIcon from '@mui/icons-material/Assessment';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AssignmentIcon from '@mui/icons-material/Assignment';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import Snackbar from '@mui/material/Snackbar';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import { deepOrange } from '@mui/material/colors';
import BasicList from './avatar';
import Auth from '../hooks/auth.hook';
import { useSelector } from 'react-redux';
const Nav = () => {
  const [showLogout, setShowLogout] = useState(false);
  const { snackBar, handleClose } = Auth();
  const user = useSelector((store) => store.user);
  return (
    <div style={{ display: 'flex' }}>
      <Sidebar className="app" style={{ position: 'fixed', height: '100vh' }}>
        <Menu>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            <img src={require('../images/renoon_app_icon.png')} alt="panda" className="logo-dashboard" />
            <h1 className="font-weight-bold" style={{ color: 'white', marginLeft: '10px' }}>
              Renoon
            </h1>
          </div>
          <MenuItem component={<Link to="home" className="link" />} icon={<HomeIcon />}>
            Home
          </MenuItem>
          <SubMenu label="User Mangement" icon={<ManageAccountsIcon />}>
            <MenuItem component={<Link to="/brand" className="link" />}>Brand</MenuItem>
            <MenuItem component={<Link to="/role" className="link" />}>Role</MenuItem>
            <MenuItem component={<Link to="/user" className="link" />}>User</MenuItem>
          </SubMenu>
          <SubMenu label="Measures" icon={<AssessmentIcon />}>
            <MenuItem component={<Link to="/claim-management" className="link" />}>Claim Management</MenuItem>
            <MenuItem component={<Link to="/order-engine" className="link" />}>Order Engine</MenuItem>
            <MenuItem component={<Link to="/product-engine" className="link" />}>Product Engine</MenuItem>
            <MenuItem component={<Link to="/supplier-map" className="link" />}>Supplier Map</MenuItem>
          </SubMenu>
          <SubMenu label="Compliance" icon={<AssignmentIcon />}>
            <MenuItem> Overview</MenuItem>
            <MenuItem> Production Complaiance </MenuItem>
          </SubMenu>
          <SubMenu label="Reports" icon={<TrendingUpIcon />}>
            <MenuItem> Reporting </MenuItem>
            <MenuItem> Overview </MenuItem>
            <MenuItem> Product LCA </MenuItem>
            <MenuItem> Clustering </MenuItem>
          </SubMenu>
          <SubMenu label="Impact Label" icon={<WalletRoundedIcon />}>
            <MenuItem> E-com Widget </MenuItem>
            <MenuItem> QR codes </MenuItem>
            <MenuItem> Analytics </MenuItem>
          </SubMenu>
          <MenuItem component={<Link to="home" className="link" />} icon={<SettingsApplicationsRoundedIcon />}>
            Settings
          </MenuItem>
        </Menu>
      </Sidebar>
      <div className="w-100" style={{ marginLeft: '320px' }}>
        <Box>
          <AppBar position="static" sx={{ height: 75 }} onClick={() => setShowLogout(false)}>
            <Toolbar variant="dense" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Typography variant="h6" color="white" component="div">
                Home
              </Typography>
            </Toolbar>
          </AppBar>

          <div className="position-avatar">
            <div onClick={() => setShowLogout(true)} style={{ display: 'flex', alignItems: 'center' }}>
              <Avatar sx={{ bgcolor: deepOrange[500], marginRight: '10px', height: '40px' }} alt="Remy Sharp" src="/broken-image.jpg">
                {user?.name?.split(' ')[0] && user.name.split(' ')[0][0] && user?.name.split(' ')[0][0].toUpperCase()}
                {user?.name?.split(' ')[1] && user.name.split(' ')[1][0] && user?.name.split(' ')[1][0].toUpperCase()}
              </Avatar>
            </div>
          </div>

          {showLogout && (
            <div>
              <BasicList name={user?.name} email={user?.email}>
                {' '}
              </BasicList>
            </div>
          )}
        </Box>
        <div onClick={() => setShowLogout(false)}>
          <Outlet></Outlet>
        </div>
      </div>
      <Snackbar
        open={snackBar.open}
        autoHideDuration={2000}
        message="Your session has been expired"
        anchorOrigin={{
          vertical: snackBar.vertical,
          horizontal: snackBar.horizontal,
        }}
        onClose={handleClose}
        className="snackBarColor"
        key={snackBar.vertical + snackBar.horizontal}
      />
    </div>
  );
};

export default Nav;
