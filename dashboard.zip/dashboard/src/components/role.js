import React, { useState, useEffect } from 'react';
import axios from 'axios';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenSquare } from '@fortawesome/free-solid-svg-icons';

const Role = () => {
  const [roles, setRoles] = useState([]);
  const [roleName, setRoleName] = useState('');
  const [resources, setResources] = useState({
    compliance: true,
    measure: true,
    impactLabel: true,
    reports: true,
    settings: true,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [selectedRoleId, setSelectedRoleId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRoles, setFilteredRoles] = useState([]);
  const [validationErrors, setValidationErrors] = useState({});

  useEffect(() => {
    fetchRoles();
  }, []);

  const fetchRoles = async () => {
    try {
      const response = await axios.get('http://localhost:3001/role', {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setRoles(response.data.data);
      setFilteredRoles(response.data.data);
      setShowTable(true);
    } catch (error) {
      console.error('Error fetching roles:', error);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!roleName.trim()) errors.roleName = 'Role Name is required';
    if (!Object.values(resources).includes(true)) errors.resources = 'At least one resource must be selected';

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const createRole = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const role = {
        name: roleName,
        ...resources,
      };

      const response = await httpService.post(RestUrlsConstants.roleUrl, role, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      if (!response.data) {
        throw new Error('Failed to create role');
      }

      await fetchRoles();
      setShowForm(false);
      setShowTable(true);
      setUpdateMode(false);
      resetForm();
    } catch (error) {
      setError(error?.response?.data?.message || 'Failed to create role');
    } finally {
      setLoading(false);
    }
  };

  const updateRole = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const updatedRole = {
        name: roleName,
        ...resources,
      };
      delete updatedRole.userManagement;
      if (selectedRoleId) {
        await httpService.patch(`${RestUrlsConstants.roleUrl}${selectedRoleId}`, updatedRole, {
          headers: { Authorization: localStorage.getItem('Authorization') },
        });

        await fetchRoles();
        setShowForm(false);
        setShowTable(true);
        setUpdateMode(false);
        resetForm();
      } else {
        throw new Error('Selected role ID is invalid or missing.');
      }
    } catch (error) {
      setError(error?.response?.data?.message || 'Failed to update role');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateRole = (roleId) => {
    const selectedRole = roles.find((role) => role.id === roleId);
    setRoleName(selectedRole.name);
    setResources(selectedRole.resources);
    setSelectedRoleId(roleId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (updateMode) {
      await updateRole();
    } else {
      await createRole();
    }
  };

  const resetForm = () => {
    setRoleName('');
    setResources({
      compliance: true,
      measure: true,
      impactLabel: true,
      reports: true,
      settings: true,
    });
    setValidationErrors({});
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(!showTable);
    resetForm();
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handleSearchClick = () => {
    const term = searchTerm.toLowerCase();
    const filtered = roles.filter((role) => role.name.toLowerCase().includes(term));
    setFilteredRoles(filtered);
  };

  const indexOfLastRole = currentPage * 10;
  const indexOfFirstRole = indexOfLastRole - 10;
  const currentRoles = filteredRoles.slice(indexOfFirstRole, indexOfLastRole);

  const formatResourceName = (name) => {
    return name === 'impactLabel' ? 'Impact Label' : name;
  };

  return (
    <div className="container mt-5">
      {!showForm && (
        <div className="d-flex justify-content-between align-items-center mb-3">
          <button className="btn btn-dark" onClick={toggleFormVisibility}>
            Add Role
          </button>
          <div className="input-group" style={{ maxWidth: '300px' }}>
            <input type="text" className="form-control" placeholder="Search roles" aria-label="Enter role name" aria-describedby="basic-addon2" onChange={(e) => setSearchTerm(e.target.value)} />
            <div className="input-group-append">
              <button className="btn btn-dark" type="button" onClick={handleSearchClick}>
                Search
              </button>
            </div>
          </div>
        </div>
      )}
      {showForm && (
        <div className="card bg-light border mt-4 mx-auto" style={{ maxWidth: '50%' }}>
          <div className="card-body">
            <h3 className="mb-4 text-center">{updateMode ? 'Update Role' : 'Role Form'}</h3>
            <form onSubmit={handleSubmit}>
              <div className="form-group mb-4 row">
                <label htmlFor="roleName" className="col-sm-3 col-form-label font-weight-bold text-right">
                  Role Name
                </label>
                <div className="col-sm-9">
                  <input
                    type="text"
                    id="roleName"
                    className="form-control"
                    placeholder="Role Name"
                    value={roleName}
                    onChange={(e) => setRoleName(e.target.value)}
                    style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                    required
                  />
                  {validationErrors.roleName && <div className="text-danger">{validationErrors.roleName}</div>}
                </div>
              </div>

              <div className="form-group mb-4 row">
                <label className="col-sm-3 col-form-label font-weight-bold text-right">Resources</label>
                <div className="col-sm-9">
                  {Object.entries(resources).map(
                    ([key, value]) =>
                      key !== 'userManagement' && (
                        <div className="form-check" key={key}>
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id={`resource-${key}`}
                            checked={value}
                            onChange={() => setResources((prevResources) => ({ ...prevResources, [key]: !value }))}
                          />
                          <label className="form-check-label" htmlFor={`resource-${key}`}>
                            {formatResourceName(key)}
                          </label>
                        </div>
                      )
                  )}
                  {validationErrors.resources && <div className="text-danger">{validationErrors.resources}</div>}
                </div>
              </div>

              <div className="d-grid gap-2">
                <button type="submit" className="btn btn-dark" disabled={loading}>
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                      <span className="sr-only">Loading...</span>
                    </>
                  ) : updateMode ? (
                    'Update Role'
                  ) : (
                    'Create Role'
                  )}
                </button>
              </div>
            </form>
            <div className="d-flex justify-content-center mt-3">
              <button
                className="btn btn-link btn-sm p-0"
                onClick={() => {
                  setShowForm(false);
                  setShowTable(true);
                  resetForm();
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
      {showTable && (
        <div className="table-responsive mt-4">
          <h3>ROLES</h3>
          <table className="table table-striped table-bordered table-hover">
            <thead className="text-center">
              <tr>
                <th>Role Name</th>
                {Object.keys(resources).map((resource) => {
                  if (resource !== 'userManagement') {
                    return <th key={resource}>{formatResourceName(resource)}</th>;
                  }
                  return null;
                })}
                <th>Action</th>
              </tr>
            </thead>
            <tbody className="text-center">
              {currentRoles.map((role) => (
                <tr key={role.id}>
                  <td>{role.name}</td>
                  {Object.entries(role.resources).map(([resource, hasAccess]) => {
                    if (resource !== 'userManagement') {
                      return (
                        <td key={resource}>
                          <input type="checkbox" className="info" checked={hasAccess} readOnly />
                        </td>
                      );
                    }
                    return null;
                  })}
                  <td>
                    <button
                      name="update"
                      className="btn btn-light"
                      onClick={() => {
                        handleUpdateRole(role.id);
                      }}
                    >
                      <FontAwesomeIcon icon={faPenSquare} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <nav>
            <ul className="pagination">
              {Array.from({ length: Math.ceil(filteredRoles.length / 10) }, (_, i) => (
                <li className={`page-item ${currentPage === i + 1 ? 'active' : ''}`} key={i}>
                  <button className="page-link" onClick={() => handlePageChange(i + 1)}>
                    {i + 1}
                  </button>
                </li>
              ))}
            </ul>
          </nav>
        </div>
      )}
    </div>
  );
};

export default Role;
