import { useState } from "react";
import "./App.css";
import Input from "./components/input";
import Button from "./components/button";

function App() {
  const [count, setCount] = useState(0);

  // const handleClick = () => {
  //   setCount((prev) => prev + 1);
  // };

  return (
    <>
      <Input inputType={"text"} placeHolder={"first name"} />
      <Button value={"Click Here"}  setCount={setCount}/>
      <p>{count > 0 && count}</p>
    </>
  );
}

export default App;
