type ButtonProps = {
  value: string;
  buttonType?: "button" | "submit" | "reset";
  // handleClick: () => void;
  setCount: React.Dispatch<React.SetStateAction<number>>;
};

function Button({
  value,
  buttonType,
  // handleClick,
  setCount,
}: ButtonProps) {

  
  const handleClick = () => {
    return setCount((prev) => prev + 1);
  };

  return (
    <button type={buttonType} onClick={handleClick}>
      {value}
    </button>
  );
}

export default Button;
