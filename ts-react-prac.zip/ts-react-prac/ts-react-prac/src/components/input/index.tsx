

type inputProps = {
  inputType: string;
  placeHolder:string,
};



const Input = ({ inputType,placeHolder }:inputProps) => {
  return <input type={inputType} placeholder={placeHolder}/>;
};

export default Input;
