import ERC20_ABI from '../abi/ERC20_ABI'
import Web3 from 'web3'
const web3 = new Web3(process.env.REACT_APP_RPC);

const balanceOf = async (token, address) => {
  const contract = new web3.eth.Contract(ERC20_ABI, token)
  return await contract.methods.balanceOf(address).call()
}

export default balanceOf