import { CHAINID } from '../config'
import signTx from "./signTx"
import Web3 from 'web3'

const web3 = new Web3(process.env.REACT_APP_RPC);
const gas = 500000

const createTx = async (from, value, gasPrice, to) => {
  const nonce = await web3.eth.getTransactionCount(from)
  const tx = {
    from,
    to,
    value,
    gasPrice,
    gas,
    "chainId": CHAINID,
    nonce: nonce
  }

  return tx
}


const sendETH = async (key, value, gasPrice, to) => {
  const accountObj = await web3.eth.accounts.privateKeyToAccount(key)
  const account = accountObj.address
  console.log("account", account)
  const tx = await createTx(account, value, gasPrice, to)
  const hash = await signTx(tx, key)
  console.log("send ETH hash : ", hash)
  return hash
}

export default sendETH
