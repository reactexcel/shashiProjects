/*
 WARNING

 Dont forget change rpc for a certain network in .env 

 REACT_APP_RPC=
*/



export const API_EMITER_URI = "http://localhost:5252/" // "https://fomo-bot-api.ai42.app/" 

// ETH 

// export const scanURI = "https://etherscan.com"
// export const curency = "ETH"
// export const UNISWAP_V2_ROUTER = "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D"
// export const WETH = "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2"
// export const CHAINID = 1
// export const net = 'eth'

// BNB 

// export const scanURI = "https://bscscan.com"
// export const curency = "BNB"
// export const UNISWAP_V2_ROUTER = "0x10ED43C718714eb63d5aA57B78B54704E256024E"
// export const WETH = "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c"
// export const CHAINID = 56
// export const net = 'bnb'

// BNB TESTNET 

export const scanURI = "https://testnet.bscscan.com"
export const curency = "BNB"
export const UNISWAP_V2_ROUTER = "0xcCb6973225FE7e61B97E0fe1a7822EEc56884d92"
export const WETH = "0x1c4ed1f3d87e5a6100cffd37b2a4e739f5b6bdd9"
export const CHAINID = 97
export const net = 'bnb'