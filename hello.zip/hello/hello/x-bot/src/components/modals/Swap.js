import * as React from 'react';
import Button from '@mui/material/Button';
import Modal from '@mui/joy/Modal';
import ModalClose from '@mui/joy/ModalClose';
import Sheet from '@mui/joy/Sheet';
import { 
  FormControl, 
  InputLabel, 
  Input, 
  CircularProgress,
  TextField,
  Autocomplete,
  FormLabel
} from '@mui/material';
import tradeETHtoERC20 from '../../helpers/tradeETHtoERC20.js';
import tradeERC20toETH from '../../helpers/tradeERC20toETH.js';
import tradeERC20toERC20 from '../../helpers/tradeERC20toERC20';
import Web3 from 'web3';
import Typography from '@mui/joy/Typography';
import { scanURI, WETH, UNISWAP_V2_ROUTER } from '../../config';
import getTokens from '../../storage/getTokens';
import { isAddress } from 'web3-utils';
import decimals from '../../helpers/decimals.js';
import allowance from '../../helpers/allowance.js';
import approveERC20 from '../../helpers/approveERC20.js';


const swap = async (tokens, from, to, amount, setHash, setShowPending) => {
  // check inputs
  if(!amount && Number(amount) <= 0)
    return alert("Please input amount")

  const fromObj = tokens.filter(item => item.symbol === from)
  if(!fromObj[0])
    return alert("Please select from")

  const toObj = tokens.filter(item => item.symbol === to)
  if(!toObj[0])
    return alert("Please select to")

  // check key
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const key = localStorage.getItem("key");

  if(!key)
    return alert("Need set key")
  
  // show loading
  setShowPending(true)
  
  // prepare tx data
  const _decimals = fromObj[0].decimals 
  ? fromObj[0].decimals
  : await decimals(fromObj[0].address)

  // convert input to wei 
  const value = String(parseInt(amount * 10**_decimals))
  // get current gas price
  const gasPrice = await web3.eth.getGasPrice()

  let hash
  
  // trade ETH to ERC20
  if(String(fromObj[0].address).toLowerCase() === String(WETH).toLowerCase()){
    hash = await tradeETHtoERC20(key, value, 1, gasPrice, toObj[0].address)
  }
  // ERC20 case 
  else{
    // check allowance
    const account = localStorage.getItem("account")
    const _allowance = await allowance(fromObj[0].address, account, UNISWAP_V2_ROUTER)
    
    // approve it not enough allowance
    if(amount > _allowance / 10**_decimals){
      const maxApprove = "115792089237316195423570985008687907853269984665640564039457584007913129639935"
      await approveERC20(key, maxApprove, gasPrice, fromObj[0].address, UNISWAP_V2_ROUTER)
    }

    // trade ERC20 to ETH
    if(String(toObj[0].address).toLowerCase() === String(WETH).toLowerCase()){
      hash = await tradeERC20toETH(key, value, 1, gasPrice, fromObj[0].address)
    }

    // trade ERC20 to ERC20
    if(String(toObj[0].address).toLowerCase() === String(WETH).toLowerCase()){
      hash = await tradeERC20toERC20(
        key, 
        value, 
        1, 
        gasPrice, 
        fromObj[0].address, 
        toObj[0].address
      )
    }
  }
  
  // display result
  setShowPending(false)
  setHash(hash)
}

export default function BuyTokens() {
  const [open, setOpen] = React.useState(false);
  const [amount, setAmount] = React.useState(0);
  const [from, setFrom] = React.useState("");
  const [to, setTo] = React.useState("");
  const [hash, setHash] = React.useState("");
  const [showPending, setShowPending] = React.useState(false);
  const [symbols, setSymbols]  = React.useState([]);
  const [customIndex, setCustomIndex]  = React.useState(1);
  const [tokens, setTokens] = React.useState([]);

  React.useEffect(() => {
    const _tokens = getTokens()
    const symbols = _tokens.map(i => i.symbol)
    setSymbols(symbols)
    setTokens(_tokens)
  }, [])
  
  // helper for catch address input 
  const handleInput = (e,v, direction) => {
    if(isAddress(v)){
      const customSymbol = `Custom token ${customIndex}`
      setCustomIndex(customIndex + 1)
      
      symbols.push(customSymbol)
      setSymbols(symbols)

      tokens.push(
        {
          "name": customSymbol,
          "symbol": customSymbol,
          "address": v,
          "chainId": null,
          "decimals": null,
          "logoURI": null,
        }
      )

      setTokens(tokens)

      if(direction === "From")
        setFrom(customSymbol)

      if(direction === "To")
        setTo(customSymbol)
    }
  }

  return (
    <React.Fragment>
      <Button variant="contained" size="small" style={{width: "10em"}} onClick={() => setOpen(true)}>
        Swap
      </Button>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => setOpen(false)}
        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: 'md',
            p: 3,
            boxShadow: 'lg',
          }}
        >
          <ModalClose variant="plain" sx={{ m: 1 }} />
          
          <br/>
          <br/>

          <FormLabel component="legend"> 
             <small> Select symbol or paste address </small>
          </FormLabel> 
          
          <Autocomplete
            value={from}
            disablePortal
            id="from"
            options={symbols}
            sx={{ width: 250 }}
            onInputChange={(e, v) => handleInput(e, v, "From")}
            onChange={(e, v) => setFrom(v)}
            renderInput={(params) => <TextField {...params} label="From" />}
          />
     
          <br/>

          <Autocomplete
            value={to}
            disablePortal
            id="to"
            options={symbols}
            sx={{ width: 250 }}
            onInputChange={(e, v) => handleInput(e, v, "To")}
            onChange={(e, v) => setTo(v)}
            renderInput={(params) => <TextField {...params} label="To" />}
          />

          <br/>

          <FormControl onChange={(e) => setAmount(e.target.value)} sx={{ width: 250 }}>
            <InputLabel>Swap amount</InputLabel>
            <Input/>
          </FormControl>

          <br/>
          <br/>

          <Button 
            variant="contained" 
            size="small" 
            style={{width: "10em"}}
            onClick={() => swap(tokens, from, to, amount, setHash, setShowPending)}
          >
            Swap
          </Button>
          <br/>
          {
            showPending
            ?
            (
              <>
              <br/>
              <CircularProgress />
              <small>processing transaction ...</small>
              </>
            )
            : null
          }
          {
            hash && hash.length > 0
            ?
            (
              <Typography id="modal-desc" textColor="text.tertiary">
                Transaction: {<a href={scanURI + '/tx/' + hash} target="_blank" rel="noreferrer">{hash.slice(0, 10)}</a>}
              </Typography>
            )
            : null
          }
        </Sheet>
      </Modal>
    </React.Fragment>
  );
}