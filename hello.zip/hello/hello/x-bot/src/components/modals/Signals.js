import React, { useEffect, useState } from 'react';
import Button from '@mui/material/Button';
import Modal from '@mui/joy/Modal';
import ModalClose from '@mui/joy/ModalClose';
import Sheet from '@mui/joy/Sheet';
import { 
    FormControl, 
    InputLabel, 
    Input,
    FormControlLabel,
    FormGroup,
    Switch,
    FormLabel
} from '@mui/material';

export default function Signals() {
  const [open, setOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [ethAmount, setEthAmount] = useState(0);

  useEffect(() => {
    const _signals = localStorage.getItem("signals")
    if(_signals){
      const signals = JSON.parse(_signals)
      const isActive = signals.isActive
      const ethAmount = signals.ethAmount
      setIsActive(isActive)
      setEthAmount(ethAmount)
    }else{
      setIsActive(false)
      setEthAmount(0)
    }

  },[setIsActive])

  const activateHandler = () => {
    const signals = localStorage.getItem("signals")
    ? JSON.parse(localStorage.getItem("signals"))
    : { isActive:false, ethAmount:0 }

    signals.isActive = !isActive

    setIsActive(!isActive)
    localStorage.setItem("signals", JSON.stringify(signals))
  }

  const ethAmountHandler = (ethAmount) => {
    if(isNaN(ethAmount) || ethAmount < 0)
      return

    const signals = localStorage.getItem("signals")
    ? JSON.parse(localStorage.getItem("signals"))
    : { isActive:false, ethAmount:0 }

    signals.ethAmount = ethAmount

    setEthAmount(ethAmount)
    localStorage.setItem("signals", JSON.stringify(signals))
  }

  return (
    <React.Fragment>
      <Button variant="contained" size="small" style={{width: "10em"}} onClick={() => setOpen(true)}>
        Signals
      </Button>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => setOpen(false)}
        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: 'md',
            p: 3,
            boxShadow: 'lg',
          }}
        >
          <ModalClose variant="plain" sx={{ m: 1 }} />

          <FormGroup>
            <FormControlLabel 
              control={
               <Switch 
                 defaultChecked={isActive} 
                 onChange={(e) => activateHandler()}
               />
            } label="Activate" 
            />
          </FormGroup>

          <br/>
          
          <FormControl onChange={(e) => console.log(e.target.value)}>
            <InputLabel>ETH amount</InputLabel>
            <Input value={ethAmount} onChange={(e) => ethAmountHandler(e.target.value)}/>
            <FormLabel component="legend"> 
             <small> Set the amount of ETH to automatic purchase by platform signals </small>
            </FormLabel> 
          </FormControl>
        </Sheet>
      </Modal>
    </React.Fragment>
  );
}