# .env 

```
REACT_APP_RPC=
```

