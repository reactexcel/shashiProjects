import React from "react";
import { Navigate, Outlet } from "react-router-dom";

const ProtectedRoute = ({children}) => {
  if ("") {
    return <Navigate />;
  }
  return children ? children : <Outlet />;
};

export default ProtectedRoute;
