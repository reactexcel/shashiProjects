import React from "react";
import { Routes, Route } from "react-router-dom";
import HomePage from "../pages/HomePage";
import Signup from "../features/signup";
import ProtectedRoute from "./ProtectedRoute";

const AllRoutes = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<HomePage/>} />
        <Route path="/signup" element={<Signup/>} />
        <Route element={<ProtectedRoute/>}>
          <Route path="/adminpoll"/>
        </Route>
      </Routes>
    </>
  );
};
export default AllRoutes;
