export const inputFieldSignupData=[
    {id:"1",name:"Email",placeholder:"Enter Your Email",type:"text",autoComplete:"off"},
    {id:"2",name:"Password",placeholder:"Enter Your Password",type:"password",autoComplete:"off"},
    
]
export const inputFieldLoginData=[
    {id:"1",name:"Email",placeholder:"Enter Your Email",type:"text",autoComplete:"off"},
    {id:"2",name:"Password",placeholder:"Enter Your Password",type:"password",autoComplete:"off"},
]