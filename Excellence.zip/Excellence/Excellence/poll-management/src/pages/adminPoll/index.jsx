import React from 'react'

const AdminPoll = () => {
  return (
    <div>
      AdminPoll
    </div>
  )
}

export default AdminPoll
