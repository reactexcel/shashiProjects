import React from 'react'

const GuestPoll = () => {
  return (
    <div>
      GuestPoll
    </div>
  )
}

export default GuestPoll
