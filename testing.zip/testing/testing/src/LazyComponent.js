// LazyComponent.js

import React from 'react';

const LazyComponent = () => {
    return (
        <div>
            <h2>This is the lazy-loaded component</h2>
            <p>This component is loaded lazily using React.lazy and Suspense.</p>
        </div>
    );
}

export default LazyComponent;
