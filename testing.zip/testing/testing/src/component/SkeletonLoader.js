const SkeletonLoader = ({ itemCount }) => (
    <div className="skeleton-loader">
      {Array.from({ length: itemCount }, (_, index) => (
        <div className="skeleton-item" key={index}></div>
      ))}
    </div>
  );

  export default SkeletonLoader