import { Suspense, lazy, useId, useState } from "react";
import "./App.css";
import SkeletonLoader from "./component/SkeletonLoader";
const LazyComponent = lazy(() => import('./LazyComponent'));
// Assuming `LazyComponent.js` is in the same directory as `App.js`

function App() {
  const ids = useId()
  const [data, setData] = useState({ firstName: "", city: "", age: "", password: "" })

  const handleChange = (e) => {
    /* setData({...data,firstName:e.target.value})    // if we have upadate single */

    /* setData(prev => ({ ...prev, firstName: e.target.value}))  // if we have update single  */


    /* setData(prev => {
      return {
        ...prev, firstName: e.target.value    // if we have update single
       }
     }) */


    /* setData({ ...data, [e.target.name]: e.target.value })  // for multiple update */


  }
  console.log(ids, "@@@@@@@@@@@@@@@@22");

  return (
    <div className="App">
      {/* <SkeletonLoader itemCount={8} /> */}
      {/* <Suspense fallback={<div>Loading...</div>}>
        <LazyComponent />
      </Suspense> */}
      <input type="text" name="firstName" placeholder="name" onChange={handleChange} />
      <input type="text" name="city" placeholder="city" onChange={handleChange} />
      <input type="number" name="age" placeholder="age" onChange={handleChange} />
      <input type="password" name="password" aria-describedby={ids} placeholder="password" onChange={handleChange} />
      <p id={ids}>
        The password should contain at least 18 characters
      </p>   
    </div>
  );
}

export default App;
