import React from "react";
import "./App.css";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import { Pages } from "./Utils/Pages";
import MultiChart from "./Components/Pages/MultiChart";
import { ChakraProvider } from "@chakra-ui/react";
import MainLayouts from "./Layouts/MainLayouts";
import Dashboard from "./Components/Pages/Dashboard";
import { Box } from "@chakra-ui/react";
import NewPares from "./Components/Pages/NewPares/"


const router = createBrowserRouter([
  {
    path: Pages.NEWPARSE,
    element: <MainLayouts />,
    children: [
      {
        path: Pages.DASHBOARD,
        element: <Dashboard />,
      },
      {
        path: Pages.NEWPARSE,
        element: <NewPares />,
      },
      {
        path: Pages.MULTICHART,
        element: <MultiChart />,
      },
    ],
  },
]);

function App() {
  return (
    <Box className="App">
      <ChakraProvider>
        <RouterProvider router={router} />
      </ChakraProvider>
    </Box>
  );
}

export default App;
