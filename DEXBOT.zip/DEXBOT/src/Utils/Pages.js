
export const Pages = {
   DASHBOARD:"/",
   NEWPAIRS:"/pairs",
   MULTICHART:'/multichart',
   WALLET:'/wallet'

}