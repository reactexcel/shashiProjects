import React, { useState } from "react";
import {
  Input,
  IconButton,
  Stack,
  InputGroup,
  InputRightElement,
  useColorModeValue,
} from "@chakra-ui/react";
import { SearchIcon } from "@chakra-ui/icons";

const SearchBar = (props) => {
  const { open } = props;
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    console.log("Search Query:", searchQuery);
  };

  const searchIcon = useColorModeValue("#161A1E", "#fff");

  return (
    <Stack direction="row" my={1} width="100%" display={!open && "none"}>
      <InputGroup width="80%">
        <Input
          placeholder="Searh"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          _focus={{ border: "none" }}
          sx={{ backgroundColor: "#28282D", color: "#fff  " }}
        />
        <InputRightElement width="3rem">
          <IconButton
            bg="none"
            _hover="none"
            _active="none"
            aria-label="Search"
            icon={<SearchIcon sx={{ _hover: { color: searchIcon } }} />}
            onClick={handleSearch}
          />
        </InputRightElement>
      </InputGroup>
    </Stack>
  );
};

export default SearchBar;
