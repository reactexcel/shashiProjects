import React, { useState } from 'react'
import { Box, Button, ListItem, OrderedList, useColorModeValue } from '@chakra-ui/react'
import { IoMdArrowDropdown } from 'react-icons/io'

const nav3Data = [
    { name: "PancakeSwap" },
    { name: "UniswapV3" },
    { name: "UniswapV3" },
    { name: "ApeSwap" },
    { name: "Uniswap" },
    { name: "SushiSwap" },
    { name: "PancakeSwapV3" },
    { name: "Biswap" },
    { name: "SushiSwap" },
    { name: "KyberSwap" },

]

const moreData = [
    { name: "PancakeSwap" },
    { name: "UniswapV3" },
    { name: "UniswapV3" },
    { name: "ApeSwap" },
    { name: "Uniswap" },
    { name: "SushiSwap" },
    { name: "PancakeSwapV3" },
    { name: "Biswap" },
    { name: "SushiSwap" },
    { name: "KyberSwap" },
    { name: "Biswap" },
    { name: "SushiSwap" },
    { name: "KyberSwap" },

]

const DashboardNav = () => {

    const [show, setShow] = useState(false)
    const boxBg = useColorModeValue("gray.300", "gray.700")
    const dropdownBg = useColorModeValue("gray.100", "gray.200")
    const textColor = useColorModeValue("#000", "#fff")

    const dropdownOpen = () => {
        setShow(!show)
    }
    return (
        <>
        </>
        // <Box bg={boxBg} display="flex" alignItems="center" p={2}>
        //     <OrderedList px={4} className='container' width={{base:"80%",md:"90%"}} color={textColor} fontWeight="500" listStyleType="none" display="flex" gap={4} overflow="auto">
        //         {
        //             nav3Data.map((item, key) => (
        //                 <ListItem key={key}>
        //                     {item.name}
        //                 </ListItem>
        //             ))
        //         }
        //     </OrderedList>
        //     <Box width={{base:"20%",md:"10%"}} textAlign="right">
        //         <Button px={4} onClick={dropdownOpen} colorScheme='teal' size='sm' gap={1} fontSize="16px" fontWeight="bold">More <IoMdArrowDropdown /></Button>
        //     </Box>
        //     <Box sx={{ position: "relative",}}>
        //         <OrderedList className='container'  listStyleType="none" height="400px" mt={5}  px={5} sx={{ position: "absolute", top: "0",right:"20px", background:dropdownBg, color: "black",transition:".1s ease-in-out",borderRadius:"10px",borderTopRightRadius:"0px" ,overflow:"hidden",overflowY:"auto",}} visibility={show ? "hidden" : "visible"}>
        //             {
        //                 moreData.map((item, key) => (
        //                     <ListItem onClick={dropdownOpen} key={key} py={2} sx={{ fontWeight: "500", fontsize: "xs",cursor:"pointer" }}>{item.name}</ListItem>
        //                 ))
        //             }
        //         </OrderedList>
        //     </Box>
        // </Box>
    )
}

export default DashboardNav
