import React from "react";
import { NavLink } from "react-router-dom";
import { IoMdMenu } from "react-icons/io";
import {
  Box,
  Image,
  Link,
  ListItem,
  UnorderedList,
  useColorModeValue,
  useDisclosure,
} from "@chakra-ui/react";
import SearchBar from "../Search";
import { Slider } from "../Drawer/Slider";
import { Connect } from "../Wallet/Connect";
import { Text } from "@chakra-ui/react";

function NavBar() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navBg = useColorModeValue("#fff", "#000");
  const logoColor = useColorModeValue("#000", "#fff");
  return (
    <>
      <Box
        height="10vh"
        bg={navBg}
        px={5}
        // py={2}
        gap={1}
        width="100%"
        sx={{ display: "flex", alignItems: "center" }}
      >
        <Link
          sx={{
            color: logoColor,
            fontWeight: "bold",
            fontSize: "1.6rem",
            textDecoration: "none",
            width: "15%",
            _hover: { textDecoration: "none" },
          }}
        >
          <NavLink to="/"> DEXBOT</NavLink>
        </Link>
        <Box gap={1} sx={{ display: "flex", width: "100%" }}>
          <Box
            py={3}
            gap={1}
            width={{ base: "100%", md: "50%" }}
            sx={{
              border: "1px solid #323233",
              textAlign: "center",
              borderRadius: "8px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Text fontSize="13px" color="#9B9BA0">
              24H VOLUME :
            </Text>
            <Text fontWeight="700">$3.17B</Text>
          </Box>
          <Box
            py={3}
            gap={1}
            width={{ base: "100%", md: "50%" }}
            sx={{
              border: "1px solid #323233",
              textAlign: "center",
              borderRadius: "8px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Text fontSize="13px" color="#9B9BA0">
              24H TXNS :
            </Text>
            <Text fontWeight="700">3,519,391</Text>
          </Box>
        </Box>
      </Box>
    </>
  );
}

export default NavBar;
