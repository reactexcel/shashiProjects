import React from 'react'
import { Box,IconButton, Image, ListItem, OrderedList, Text } from '@chakra-ui/react'
import { BsLightningChargeFill } from 'react-icons/bs'
import { IoIosArrowForward } from 'react-icons/io'
import { useRef } from 'react';

const NavData = [
    { id: 1, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'ШАЙЛУШАЙ' },
    { id: 2, image: "https://photos.pinksale.finance/file/pinksale-logo-upload/1694955139527-07671c85d9c6310e88e23e1fd5feeaec.jpeg", caption: 'ШАЙЛУШАЙ' },
    { id: 3, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'BANANA' },
    { id: 4, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'FINE' },
    { id: 5, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'WAPPLE' },
    { id: 6, image: "https://photos.pinksale.finance/file/pinksale-logo-upload/1694955139527-07671c85d9c6310e88e23e1fd5feeaec.jpeg", caption: 'ШАЙЛУШАЙ' },
    { id: 7, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'ƎԀƎԀ' },
    { id: 8, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'SALLY' },
    { id: 9, image: "https://cryptologos.cc/logos/bnb-bnb-logo.svg", caption: 'PEPEKING' },
    { id: 10, image: "https://cryptologos.cc/logos/ethereum-eth-logo.svg", caption: 'DORKL' },
    { id: 11, image: "https://cryptologos.cc/logos/bnb-bnb-logo.svg", caption: '2049' },
];

const Navbar2 = () => {
    const containerRef = useRef(null);
    const handleScrollRight = () => {
        if (containerRef.current) {
          containerRef.current.scrollTo({
            left: containerRef.current.scrollLeft + 100,
            behavior: 'smooth',
          });
        }
      };

    return (
        <></>
        // <Box
        //     sx={{ borderTop: '1px solid lightgray', borderBottom: '1px solid lightgray', display: 'flex', alignItems: 'center' }}>
        //     <Box height="100%" px={2} display="flex" alignItems="center" fontWeight="500">
        //         <BsLightningChargeFill fontSize="1.2rem" /> <Text display={{ base: 'none', md: 'block' }}>Trending</Text>
        //     </Box>
        //     <OrderedList className="container" overflow="auto"  ref={containerRef} width="100%" gap={{base:10,md:5}}  py={2} px={2} listStyleType="none" display="flex">
        //         {NavData.map((item) => (
        //             <ListItem  key={item.id} display="flex" alignItems="center" justifyContent="center" gap={1} fontSize="14px" fontWeight="500">
        //                 #{item.id}<Text> {item.caption}</Text> <Image src={item.image} alt={item.caption} width="20px" height="20px" borderRadius="50%" />
        //             </ListItem>
        //         ))}
        //     </OrderedList>
        //     <IconButton
        //     height="100%"
        //         variant="outline"
        //         aria-label='done'
        //         display={{ base: 'block', md: 'none' }}
        //         size="sm"
        //         icon={<IoIosArrowForward fontSize="1.5rem" />}
        //         onClick={handleScrollRight}
        //     />
        // </Box>
    );
};

export default Navbar2;