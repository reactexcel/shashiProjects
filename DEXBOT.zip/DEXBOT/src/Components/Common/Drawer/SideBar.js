import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  Box,
  UnorderedList,
  ListItem,
  Text,
  useColorModeValue,
  useColorMode,
  OrderedList,
  Link,
} from "@chakra-ui/react";
import { BiWallet } from "react-icons/bi";
import { AiOutlineMenuFold, AiOutlineMenuUnfold } from "react-icons/ai";
import { HiSun, HiMoon } from "react-icons/hi";
import {
  FaTwitter,
  FaTelegramPlane,
  FaStar,
  FaBell,
  FaWallet,
  FaNewspaper,
  FaCode,
  FaApple,
} from "react-icons/fa";
import { FaArrowTrendUp } from "react-icons/fa6";
import { TbBoxMultiple } from "react-icons/tb";
import { LuArrowUpDown } from "react-icons/lu";
import { RiAdvertisementFill } from "react-icons/ri";
import { DiAndroid } from "react-icons/di";
import SearchBar from "../Search";

const SideBar = () => {
  const { toggleColorMode } = useColorMode();
  const sidebarbg = useColorModeValue("gray.100", "#111116");
  const [open, setOpen] = useState(false);
  const toggleMenu = () => {
    setOpen(!open);
  };

  const boxBg = useColorModeValue("#fff", "#424247");
  const hoverBg = useColorModeValue("", "#1D1D22");

  return (
    <Box bg={sidebarbg} w="100%" display={{ base: "none", md: "block" }}>
      <Box height="90vh">
        <Text variant="h1">
          <span style={{fontWeight:700}}>DEX</span>BOT
        </Text>
        <UnorderedList
          className="container"
          pt={1}
          pr={3}
          listStyleType="none"
          fontSize={{ sm: "md" }}
          fontWeight="600"
          overflow="auto"
        >
          <SearchBar open={open} />
          <ListItem
            pb={2}
            onClick={toggleMenu}
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            fontWeight="500"
            borderBottom="1px solid lightgray"
          >
            <Box
              display={open ? "flex" : "none"}
              alignItems="center"
              backgroundColor={boxBg}
              py={1}
              borderRadius="8px"
              px={7}
              gap={1}
              cursor="pointer"
            >
              <Text
                display={open ? "block" : "none"}
                sx={{ transition: ".5s" }}
              >
                Get the App!
              </Text>
              <FaApple style={{ display: !open && "none" }} />
              <DiAndroid style={{ display: !open && "none" }} />
            </Box>
            {open ? (
              <AiOutlineMenuFold fontSize="1.3rem" />
            ) : (
              <AiOutlineMenuUnfold fontSize="1.3rem" />
            )}
          </ListItem>
          <ListItem
            mt={1}
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaStar fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Watchlist
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaBell fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Alerts
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/pairs"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <TbBoxMultiple fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Multicharts
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <BiWallet fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                New Pairs
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <LuArrowUpDown fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Gainers & Losers
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaWallet fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Portfolio
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaNewspaper fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                News
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaArrowTrendUp fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Trends
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <RiAdvertisementFill fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Advertise
              </Text>
            </NavLink>
          </ListItem>
          <ListItem
            p={2}
            borderRadius={5}
            sx={{ _hover: { background: hoverBg }, transition: ".5s" }}
          >
            <NavLink
              to="/wallet"
              style={{ display: "flex", alignItems: "center", gap: "10px" }}
            >
              <FaCode fontSize="1.3rem" />
              <Text fontSize="14px" display={open ? "block" : "none"}>
                Api
              </Text>
            </NavLink>
          </ListItem>
        </UnorderedList>
        <OrderedList
          pt={1}
          pr={3}
          listStyleType="none"
          borderTop="1px solid lightgray"
          fontWeight="500"
        >
          <ListItem px={2} py={1}>
            <Link
              style={{
                display: open && "flex",
                alignItems: "center",
                gap: "15px",
              }}
            >
              <FaTelegramPlane fontSize="1.3rem" />
              <FaTwitter fontSize="1.3rem" />
            </Link>
          </ListItem>
          <ListItem px={2} mt={2}>
            <HiSun
              onClick={toggleColorMode}
              color="lightgray"
              fontSize="1.5rem"
            />
          </ListItem>
          <ListItem px={2}>
            <HiMoon onClick={toggleColorMode} color="#000" fontSize="1.5rem" />
          </ListItem>
        </OrderedList>
      </Box>
    </Box>
  );
};

export default SideBar;
