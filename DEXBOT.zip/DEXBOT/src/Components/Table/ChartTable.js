import React from "react";
import {
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  TableContainer,
  useColorModeValue,
} from "@chakra-ui/react";

const ChartTable = () => { 
  const tableTextColor = useColorModeValue("gray.600", "#fff");
  const tableBg = useColorModeValue("gray.100", "#28282D");

  const tableData = [
    {
      id: "1",
      token: "data 1",
      price: 0.2453,
      txn: 8522,
      volume: 15.5,
      makers: 4555,
      fiveMinute: -0.92,
      oneHour: -6.67,
      sixHour: 2.39,
      twentyFourHour: 260,
      Liquidity: 517,
      FDV: 14.6,
    },
    {
      id: "1",
      token: "data 2",
      price: 0.2018,
      txn: 9522,
      volume: 19.5,
      makers: 3227,
      fiveMinute: -0.84,
      oneHour: -3.67,
      sixHour: 1.39,
      twentyFourHour: 160,
      Liquidity: 241,
      FDV: 17.6,
    },
    {
      id: "1",
      token: "data 3",
      price: 0.1443,
      txn: 7425,
      volume: 12.5,
      makers: 9825,
      fiveMinute: -0.76,
      oneHour: -8.67,
      sixHour: 4.39,
      twentyFourHour: 200,
      Liquidity: 614,
      FDV: 15.6,
    },
    {
      id: "1",
      token: "data 4",
      price: 0.2453,
      txn: 9522,
      volume: 19.5,
      makers: 3227,
      fiveMinute: -0.92,
      oneHour: -6.67,
      sixHour: 2.39,
      twentyFourHour: 260,
      Liquidity: 517,
      FDV: 17.6,
    },
    {
      id: "1",
      token: "data 5",
      price: 0.2453,
      txn: 9522,
      volume: 19.5,
      makers: 3227,
      fiveMinute: -0.92,
      oneHour: -6.67,
      sixHour: 2.39,
      twentyFourHour: 260,
      Liquidity: 517,
      FDV: 17.6,
    },
    {
      id: "1",
      token: "data 6",
      price: 0.2453,
      txn: 9522,
      volume: 19.5,
      makers: 3227,
      fiveMinute: -0.92,
      oneHour: -6.67,
      sixHour: 2.39,
      twentyFourHour: 260,
      Liquidity: 517,
      FDV: 17.6,
    },
    {
      id: "1",
      token: "data 7",
      price: 0.2453,
      txn: 9522,
      volume: 19.5,
      makers: 3227,
      fiveMinute: -0.92,
      oneHour: -6.67,
      sixHour: 2.39,
      twentyFourHour: 260,
      Liquidity: 517,
      FDV: 17.6,
    },
  ];

  return (
    <Box>
      <TableContainer className="container">
        <Table variant="simple">
          <Thead bg="#39393E">
            <Tr bg="#39393E">
              <Th
                sx={{
                  position: "sticky",
                  left: "0",
                  zIndex: "1000",
                  color: "#fff",
                  backgroundColor:"#39393E"
                }}
              >
                TOKEN
              </Th>
              <Th color="#fff" >PRICE</Th>  
              <Th color="#fff">TXNS</Th>
              <Th color="#fff">VOLUME</Th>
              <Th color="#fff">Makers</Th>
              <Th color="#fff">5M</Th>
              <Th color="#fff">1H</Th>
              <Th color="#fff">6H</Th>
              <Th color="#fff">24H</Th>
              <Th color="#fff">LIQUIDITY</Th>
              <Th color="#fff">FDV</Th>
            </Tr>
          </Thead>
          <Tbody bg={tableBg} color={tableTextColor}>
            {tableData.map((ele) => (
              <Tr key={ele.id} style={{ fontSize: "14px" }}>
                <Td
                  sx={{
                    position: "sticky",
                    left: "0",
                    // zIndex: "500",
                    fontWeight: 700,
                  }}
                  bg={tableBg}
                >
                  {ele.token}
                </Td>
                <Td>$ {ele.price}</Td>
                <Td>{ele.txn}</Td>
                <Td>$ {ele.volume} M</Td>
                <Td>{ele.makers}</Td>
                <Td color="#48B96A">{ele.fiveMinute} %</Td>
                <Td>{ele.oneHour} %</Td>
                <Td color="#48B96A">{ele.sixHour} %</Td>
                <Td color="#E26060">{ele.twentyFourHour} %</Td>
                <Td>$ {ele.Liquidity} K</Td>
                <Td>$ {ele.FDV} M</Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default ChartTable;
