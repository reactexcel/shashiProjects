import React from 'react'

const SizeTable = () => {
  return (
      <>
      
      </>
  )
}

export default SizeTable