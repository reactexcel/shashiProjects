const categories = [
    {
        category : 'Men',
        subCategory : 'Men Topwear',
        items : ['Casual-Shirts','Core-Tee', 'Evening-Shirts','Formal-Shirts','Kurta','T-Shirts','Sweat-Shirts','Polo-tShirts','Waist-Coat']
    },
    {
        category : 'Men',
        subCategory : 'Men Bottomwear',
        items : ['Chino','Pyjamas','Denim','Trackpants','Formal-Trousers','Joggers']
    },
    {
        category : 'Women',
        subCategory : 'Women Topwear',
        items : ['Dress','Shirts','Kurta','Kurta and Pants','Core-Tee','Sweat-Shirts','Tunic','Top','T-Shirts','Co-ord-Sets']
    },
    {
        category : 'Women',
        subCategory : 'Women Bottomwear',
        items : ['Jeggings','Leggings','Pants','Trousers']
    }
]