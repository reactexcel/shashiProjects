
const AboutUs = () => {
    return (
        <>
            <div className="absolute top-5 bg-[#FFAE00] md:h-64 h-48 w-full -z-10"></div>
            <div className=" p-6 max-w-7xl mx-auto my-16 ">
                <h2 className="text-center font-bold text-3xl lg:text-5xl ">
                    About US
                </h2>
                <div className="text-center w-full px-2 py-12 mx-auto">
                    <h1 className='text-3xl my-3 capitalize font-bold'>Our Founders</h1>
                    <div className='lg:flex justify-center items-start p-2'>
                        <div className='mx-4'>
                            {/* <img src={} className='w-48 h-60 object-cover rounded-lg mx-auto' alt="XYZZZ" /> */}
                            <h2 className="capitalize text-3xl font-bold mt-4">XYZZZ</h2>
                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Incidunt quibusdam harum quam repellat voluptatibus nisi iure exercitationem inventore numquam explicabo minima veniam error accusantium cum quisquam aliquam enim at provident eveniet, dolorem neque facilis libero illum. Eveniet magni reiciendis quo rem doloribus non beatae libero perspiciatis, illum quis laboriosam tempora! Aspernatur blanditiis error accusamus ratione quia laudantium non soluta. Amet saepe autem quas necessitatibus a maxime facilis rem, corporis porro voluptates illum pariatur vitae architecto quis asperiores illo? Veritatis, corrupti fuga! Deleniti nam at dolore excepturi sed earum inventore ipsum, natus, praesentium laborum numquam consequuntur doloribus quae veniam recusandae ea.</p>
                        </div>
                        <div className='mx-4'>
                            {/* <img src={} className='w-48 h-60 object-cover rounded-lg mx-auto' alt="XYZZZ" /> */}
                            <h2 className="capitalize text-3xl font-bold mt-4">XYZZZ</h2>
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facere eos ducimus dolorum hic eligendi, ipsam porro voluptate quod commodi itaque tenetur ab numquam? Inventore dolor fuga harum magni possimus, ad alias provident totam sapiente blanditiis temporibus nam expedita deleniti quod esse similique itaque in molestiae quae animi et id? Magni blanditiis corrupti suscipit consequuntur, perferendis illum tempore vero consequatur. Consectetur, dolores hic harum, tempora distinctio porro voluptatum debitis quia nobis numquam, natus nisi saepe reprehenderit blanditiis totam tempore ut ducimus architecto cupiditate aspernatur labore assumenda ipsa similique voluptatem? Dolores nostrum eaque aut repellat officia recusandae fugiat ullam? Tempore, eligendi corporis?</p>
                        </div>
                    </div>
                </div>
                <div className="flex flex-wrap justify-center items-center my-20 text-center w-full">
                    <div className=' w-4/5 md:flex items-center block '>
                        <div className='relative shadow-lg top-6 left-0 md:top-0 md:left-6 z-20 w-80 md:w-full mx-auto h-32 rounded-lg bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-yellow-400 via-yellow-400 to-orange-500'>
                            <h3 className="font-bold mt-10 md:pt-0 pt-12 text-xl md:px-12 px-3  font-bold drop-shadow">
                                Introduction
                            </h3>
                        </div>
                        <div className='p-4 rounded-2xl border border-gray-100 shadow-2xl'>
                            <p className="lg:px-16 px-4 mt-6 pb-6">
                               Lorem ipsum dolor sit amet consectetur adipisicing elit. Vero quod enim necessitatibus qui repellat nobis obcaecati reiciendis magnam quas eum distinctio, recusandae voluptatem? Nemo cupiditate quis dicta rerum sit alias ullam pariatur, cum in debitis! Quam quia nesciunt deleniti est temporibus sed vel. Tenetur, ab non minus perferendis aliquid ea provident cupiditate ratione voluptas accusantium nobis eaque quaerat consequatur maiores, itaque dolorem excepturi ex, dicta deleniti eum voluptate nam repudiandae. Necessitatibus, quam? Eaque molestiae dignissimos ducimus? Repellendus et commodi tempore doloremque amet consequuntur dolorum corrupti quam accusantium? Perferendis itaque illo vero in quibusdam dolorem qui sit provident vel aliquam alias assumenda soluta quas eius, impedit voluptates architecto consectetur laborum.
                            </p>
                        </div>
                    </div>

                </div>
                <div className="flex flex-wrap justify-center items-center my-20 text-center w-full">
                    <div className=' w-4/5 md:flex items-center block '>
                        <div className='relative shadow-lg top-6 left-0 md:top-0 md:left-6 z-20 w-80 md:w-full mx-auto h-32 rounded-lg bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-yellow-400 via-yellow-400 to-orange-500'>
                            <h3 className="font-bold mt-10 md:pt-0 pt-12 text-xl md:px-10 px-3  font-bold drop-shadow">
                                Vision and Values <p className="w-[150px]"> </p>
                            </h3>
                        </div>
                        <div className='p-4 rounded-2xl border border-gray-100 shadow-2xl'>
                            <p className="lg:px-16 px-4 mt-6 pb-6">
                              Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum labore libero distinctio tempora eveniet qui amet eligendi blanditiis nihil, incidunt a, corrupti, assumenda quae ratione consequuntur? Assumenda ratione sapiente facere dicta suscipit ab accusantium voluptate totam id exercitationem quo est hic repudiandae voluptatem, modi impedit et odio dolor obcaecati debitis.
                            </p>
                        </div>
                    </div>

                </div>

                <div className="flex flex-wrap justify-center items-center my-20 text-center w-full">
                    <div className=' w-4/5 md:flex items-center block '>
                        <div className='relative shadow-lg top-6 left-0 md:top-0 md:left-6 z-20 w-80 md:w-full mx-auto h-32 rounded-lg bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-yellow-400 via-yellow-400 to-orange-500'>
                            <h3 className="font-bold mt-10 md:pt-0 pt-12 text-xl md:px-12 px-3  font-bold drop-shadow">
                                Product Range <p className="w-[150px]"> </p>
                            </h3>
                        </div>
                        <div className='p-4 rounded-2xl border border-gray-100 shadow-2xl'>
                            <p className="lg:px-16 px-4 mt-6 pb-6">
                               Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet, reiciendis sunt. Velit cupiditate ex, culpa debitis blanditiis itaque. Omnis optio nesciunt non nostrum doloremque consequatur consequuntur debitis in, quo recusandae eveniet repellendus ad excepturi incidunt amet voluptatum necessitatibus velit nemo sunt natus placeat! Enim animi et nemo nihil expedita voluptatum.
                            </p>
                        </div>
                    </div>

                </div>
                <div className="flex flex-wrap justify-center items-center my-20 text-center w-full">
                    <div className=' w-4/5 md:flex items-center block '>
                        <div className='relative shadow-lg top-6 left-0 md:top-0 md:left-6 z-20 w-80 md:w-[30rem] mx-auto h-32 rounded-lg bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-yellow-400 via-yellow-400 to-orange-500'>
                            <h3 className="font-bold mt-8 md:pt-0 pt-12 text-xl md:px-12 px-3  font-bold drop-shadow">
                                Empowering Fashion for All
                            </h3>
                        </div>
                        <div className='p-4 rounded-2xl border border-gray-100 shadow-2xl'>
                            <p className="lg:px-16 px-4 mt-6 pb-6">
                              Lorem ipsum dolor, sit amet consectetur adipisicing elit. At odio, quae distinctio accusamus ipsa facere mollitia ratione alias fuga officiis eligendi recusandae quisquam possimus aspernatur veritatis! Minus culpa eos possimus repellat sint totam. Nemo laborum a excepturi maiores officia qui rem reiciendis at, sit, nostrum perspiciatis eos quae hic. Commodi?
                            </p>
                        </div>
                    </div>

                </div>
            </div>

        </>
    );
};

export default AboutUs;
