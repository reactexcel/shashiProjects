import { banner9,banner10} from "../assets/banners";
import { mobile1,mobile2} from "../assets/banners/mobile";

export const BannerData = [
    {
        id : 1,
        img: banner9,
        smimg:mobile1
    },
    {
        id : 2,
        img: banner10,
        smimg:mobile2
    },
]