import GEGreen1 from './10020153836_SAGEGREEN_/10020153836_SAGEGREEN_1.jpg';
import GEGreen2 from './10020153836_SAGEGREEN_/10020153836_SAGEGREEN_2.jpg';
import GEGreen3 from './10020153836_SAGEGREEN_/10020153836_SAGEGREEN_3.jpg';
import GEGreen4 from './10020153836_SAGEGREEN_/10020153836_SAGEGREEN_4.jpg';
import GEGreen5 from './10020153836_SAGEGREEN_/10020153836_SAGEGREEN_5.jpg';
import Wine1 from './10020153923_WINE_/10020153923_WINE_1.jpg'
import Wine2 from './10020153923_WINE_/10020153923_WINE_2.jpg'
import Wine3 from './10020153923_WINE_/10020153923_WINE_3.jpg'
import Wine4 from './10020153923_WINE_/10020153923_WINE_4.jpg'
import Wine5 from './10020153923_WINE_/10020153923_WINE_5.jpg'
import Maroon1 from './10020154021_MAROON_/10020154021_MAROON_1.jpg'
import Maroon2 from './10020154021_MAROON_/10020154021_MAROON_2.jpg'
import Maroon3 from './10020154021_MAROON_/10020154021_MAROON_3.jpg'
import Maroon4 from './10020154021_MAROON_/10020154021_MAROON_4.jpg'
import Maroon5 from './10020154021_MAROON_/10020154021_MAROON_5.jpg'
import Darknavy1 from './10020154230_DARKNAVY_/10020154230_DARKNAVY_1.jpg'
import Darknavy2 from './10020154230_DARKNAVY_/10020154230_DARKNAVY_2.jpg'
import Darknavy3 from './10020154230_DARKNAVY_/10020154230_DARKNAVY_3.jpg'
import Darknavy4 from './10020154230_DARKNAVY_/10020154230_DARKNAVY_4.jpg'
import Darknavy5 from './10020154230_DARKNAVY_/10020154230_DARKNAVY_5.jpg'
import White1 from './10020154319_WHITE_/10020154319_WHITE_1.jpg'
import White2 from './10020154319_WHITE_/10020154319_WHITE_2.jpg'
import White3 from './10020154319_WHITE_/10020154319_WHITE_3.jpg'
import White4 from './10020154319_WHITE_/10020154319_WHITE_4.jpg'
import White5 from './10020154319_WHITE_/10020154319_WHITE_5.jpg'
import Skyblue1 from './10020154498_SKYBLUE_/10020154498_SKYBLUE_1.jpg'
import Skyblue2 from './10020154498_SKYBLUE_/10020154498_SKYBLUE_2.jpg'
import Skyblue3 from './10020154498_SKYBLUE_/10020154498_SKYBLUE_3.jpg'
import Skyblue4 from './10020154498_SKYBLUE_/10020154498_SKYBLUE_4.jpg'
import Skyblue5 from './10020154498_SKYBLUE_/10020154498_SKYBLUE_5.jpg'
import DarkNavys1 from './10020156830_DarkNavy_/10020156830_DarkNavy_1.jpg'
import DarkNavys2 from './10020156830_DarkNavy_/10020156830_DarkNavy_2.jpg'
import DarkNavys3 from './10020156830_DarkNavy_/10020156830_DarkNavy_3.jpg'
import DarkNavys4 from './10020156830_DarkNavy_/10020156830_DarkNavy_4.jpg'
import DarkNavys5 from './10020156830_DarkNavy_/10020156830_DarkNavy_5.jpg'
import Navy1 from './10020155511_NAVY_/10020155511_NAVY_1.jpg'
import Navy2 from './10020155511_NAVY_/10020155511_NAVY_2.jpg'
import Navy3 from './10020155511_NAVY_/10020155511_NAVY_3.jpg'
import Navy4 from './10020155511_NAVY_/10020155511_NAVY_4.jpg'
import Navy5 from './10020155511_NAVY_/10020155511_NAVY_5.jpg'

export {
    GEGreen1,
    GEGreen2,
    GEGreen3,
    GEGreen4,
    GEGreen5,
    Wine1,
    Wine2,
    Wine3,
    Wine4,
    Wine5,
    Maroon1,
    Maroon2,
    Maroon3,
    Maroon4,
    Maroon5,
    Darknavy1,
    Darknavy2,
    Darknavy3,
    Darknavy4,
    Darknavy5,
    White1,
    White2,
    White3,
    White4,
    White5,
    Skyblue1,
    Skyblue2,
    Skyblue3,
    Skyblue4,
    Skyblue5,
    DarkNavys1,
    DarkNavys2,
    DarkNavys3,
    DarkNavys4,
    DarkNavys5,
    Navy1,
    Navy2,
    Navy3,
    Navy4,
    Navy5
}