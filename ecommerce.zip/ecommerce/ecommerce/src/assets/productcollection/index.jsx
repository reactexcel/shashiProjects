import col1 from './col1.jpg'
import col2 from './col2.jpg'
import col3 from './col3.jpg'
import col4 from './col4.jpg'
import col5 from './col5.jpg'
import col6 from './col6.jpg'
import col7 from './col7.jpg'

export {
    col1,
    col2,
    col3,
    col4,
    col5,
    col6,
    col7
}