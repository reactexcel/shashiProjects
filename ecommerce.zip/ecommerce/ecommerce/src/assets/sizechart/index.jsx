import CasualBottomwear_boxer from './men/Casual Bottomwear/boxermen.jpeg'
import CasualBottomwear_chinos from './men/Casual Bottomwear/chinosmen.jpeg'
import CasualBottomwear_jeans from './men/Casual Bottomwear/jeansmen.jpeg'
import CasualBottomwear_joggers from './men/Casual Bottomwear/joggersmen.jpeg'
import CasualBottomwear_knittedshorts from './men/Casual Bottomwear/knittedshortsmen.jpeg'
import CasualBottomwear_pajama from './men/Casual Bottomwear/pajamamen.jpeg'
import CasualBottomwear_trackpants from './men/Casual Bottomwear/trackpantsmen.jpeg'

import Eveningwear_shirt from './men/Evening wear/casualshirt.jpeg'

import CasualTopwear_casualshirt from './men/Casual Topwear/casualshirt.jpeg'
import CasualTopwear_sweatshirt from './men/Casual Topwear/sweatshirtmen.jpeg'
import CasualTopwear_tshirt from './men/Casual Topwear/tshirtmen.jpeg'
import CasualTopwear_waistcoat from './men/Casual Topwear/waistcoatmen.jpeg'

import Ethnicwear_kurta from './men/Ethnic Wear/kurtamen.jpeg'

import Formalwear_shirt from './men/Formal wear/formalshirt.jpeg'
import Formalwear_trousers from './men/Formal wear/formaltrouser.jpeg'

import bottom_cm from './women/bottom_cm.jpeg'
import bottom_inch from './women/bottom_inches.jpeg'
import top_cm from './women/top_cm.jpeg'
import top_inches from './women/top_inches.jpeg'

import sizeguide from './diagram/size-guide.jpg'

export {
    CasualBottomwear_boxer,CasualBottomwear_chinos,CasualBottomwear_jeans,CasualBottomwear_joggers,CasualBottomwear_knittedshorts,CasualBottomwear_pajama,CasualBottomwear_trackpants,
    Eveningwear_shirt,
    CasualTopwear_casualshirt,CasualTopwear_sweatshirt,CasualTopwear_tshirt,CasualTopwear_waistcoat,
    Ethnicwear_kurta,
    Formalwear_shirt,Formalwear_trousers,

    bottom_cm,bottom_inch,top_cm,top_inches,
    sizeguide

}