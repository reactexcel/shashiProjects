import banner9 from "./banner9.jpg";
import banner10 from "./banner10.jpg";

import logo from "./logo.jpg";

export {
    banner9,
    banner10,
    logo
}