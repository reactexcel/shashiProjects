import "./App.css";
import { ChakraProvider } from "@chakra-ui/react";
import Dashboard from "./pages/Dashboard";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Fairness from "./pages/Fairness";
import About from "./pages/About";
import Referrals from "./pages/Referrals";

function App() {
  return (
    <ChakraProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/Fairness" element={<Fairness />} />
          <Route path="/About" element={<About />} />
          <Route path="/Referrals" element={<Referrals />} />
        </Routes>
      </BrowserRouter>
    </ChakraProvider>
  );
}

export default App;
