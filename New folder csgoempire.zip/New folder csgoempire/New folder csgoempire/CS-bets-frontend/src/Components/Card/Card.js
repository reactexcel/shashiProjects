import { Box, Button, Card, CardBody, Text } from "@chakra-ui/react";
import BetIcon from "../Icon";

const CardBox = (props) => {
  const { textValue, buttonValue, color, bg, hoverBg } = props;
  return (
    <Card
      my={2}
      sx={{
        width: { base: "49%", md: "24%" },
        height: "18%",
        backgroundColor: "#000",
        borderRadius:"8px"
      }}
    >
      <CardBody
        padding="0px"
        sx={{ backgroundColor: "#000", color: "#fff", borderRadius: "10px" }}
      >
        <Box
          px={2}
          py={2}
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-evenly",
          }}
        >
          <Box sx={{ display: "flex", gap: "10px" }}>
            <BetIcon />
            <BetIcon />
          </Box>
          <Text fontWeight="semibold" fontSize={14}>
            {textValue}
          </Text>
        </Box>
        <Box sx={{ marginTop: "10px" }}>
          <Button
            sx={{
              width: "100%",
              backgroundColor: `${bg}`,
              color: `${color}`,
              _hover: { backgroundColor: `${hoverBg}` },
            }}
          >
            {buttonValue}
          </Button>
        </Box>
      </CardBody>
      <CardBody backgroundColor="#141414" borderRadius="0 0 8px 8px">
        <Box sx={{ height: "50px" }}></Box>
      </CardBody>
    </Card>
  );
};

export default CardBox;
