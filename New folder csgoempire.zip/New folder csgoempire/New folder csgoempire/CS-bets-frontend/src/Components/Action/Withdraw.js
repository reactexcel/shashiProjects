import { Button } from '@chakra-ui/react'
import React from 'react'

function Withdraw() {
  return (
   <React.Fragment>
     <Button
    px={5}
    bg={{base:"#74777a",md:"#24252F"}}
    color={{base:"#DCDCDC",md:"#9293A6"}}
    size="sm"
    sx={{ _hover: { backgroundColor: "#333541" } }}
  >
    Withdraw
  </Button>
   </React.Fragment>
  )
}

export default Withdraw

