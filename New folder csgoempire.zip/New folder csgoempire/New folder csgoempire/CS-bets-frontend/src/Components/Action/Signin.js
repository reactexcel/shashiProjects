import { Button } from "@chakra-ui/react";
import React from "react";
import { BiLogoSteam } from "react-icons/bi";

const Signin = () => {
  return (
    <React.Fragment>
      <a href="https://steamcommunity.com/login/home/?goto=">
        <Button
          bg="#01BF4D"
          size="sm"
          px={5}
          width={{ base: "100%", md: "auto" }}
          sx={{
            _hover: { backgroundColor: "#00E359" },
            boxShadow: "1px 2px 2px #056308",
          }}
        >
          <BiLogoSteam style={{ marginRight: "4px" }} />
          Sign in
        </Button>
      </a>
    </React.Fragment>
  );
};

export default Signin;
