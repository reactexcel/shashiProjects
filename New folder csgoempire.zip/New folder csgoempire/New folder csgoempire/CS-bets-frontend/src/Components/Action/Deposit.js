import { Button } from '@chakra-ui/react'
import React from 'react'

const Deposit = () => {
  return (
    <>
    <Button
          bg="#E9B10E"
          size="sm"
          px={5}
          sx={{
            _hover: { backgroundColor: "#FFCF42" },
            boxShadow: "1px 2px 2px #9C5C00",
          }}
        >
          Deposit
        </Button>
    </>
  )
}

export default Deposit
