import { NavLink } from "react-router-dom";
import {
  Box,
  ListItem,
  OrderedList,
} from "@chakra-ui/react";
import { RxCrossCircled } from "react-icons/rx";
import { FaCoins } from "react-icons/fa";
import { FaBattleNet } from "react-icons/fa";
import Withdraw from "../Action/Withdraw";
import Deposit from "../Action/Deposit";
import Signin from "../Action/Signin";

function Navbar() {
  return (
    <Box
      sx={{
        backgroundColor: "#24252F",
        color: "#9293A6",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
      px={3}
    >
      <OrderedList
        listStyleType={"none"}
        py={4}
        sx={{
          display: "flex",
          fontSize: "14px",
          fontWeight: "bold",
          alignItems: "center",
        }}
        gap={6}
      >
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            display: "flex",
            alignItems: "center",
            gap: "1",
          }}
        >
          <RxCrossCircled fontSize={18} />
          <NavLink to="/#">ROULETTE</NavLink>
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            display: "flex",
            alignItems: "center",
            gap: "1",
          }}
        >
          <FaBattleNet fontSize={17} />
          <NavLink to="/#">MATCH BETTING</NavLink>
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            display: "flex",
            alignItems: "center",
            gap: "1",
          }}
        >
          <FaCoins />
          <NavLink to="/#">COINFLIP</NavLink>
        </ListItem>
      </OrderedList>
      <Box display="flex" gap={3} fontWeight="bold">
        <Withdraw />
        <Deposit />
        <Signin />
      </Box>
    </Box>
  );
}

export default Navbar;
