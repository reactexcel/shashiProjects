import { Box, Grid, GridItem,Text } from "@chakra-ui/react";
import React from "react";

function Sidebar() {
  return (
    <Box>
      <Grid>
        <GridItem className="example">
          <Text>SideNavbar</Text>
        </GridItem>
      </Grid>
    </Box>
  );
}

export default Sidebar;
