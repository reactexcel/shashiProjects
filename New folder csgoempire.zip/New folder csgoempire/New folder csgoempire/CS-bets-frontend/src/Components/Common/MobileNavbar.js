import { Box, Heading } from "@chakra-ui/react";
import React from "react";
import DrawerMobile from "./MobileRightDrawer";

const MobileNavbar = () => {
  return (
    <Box
      width="100%"
      bg="#24252F"
      px={3}
      height="8vh"
      sx={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <Heading sx={{ fontStyle: "italic", color: "#FFFFFF", fontSize: "28px" }}>
        CSGO<span style={{ color: "#E9B10E" }}>EMPIRE</span>
      </Heading>
      <DrawerMobile />
    </Box>
  );
};

export default MobileNavbar;
