import { Box, ListItem, OrderedList, Select } from "@chakra-ui/react";
import React from "react";
import FreeCase from "./FreeCase";
import DailyCoins from "./DailyCoins";
import BonusCase from "./BonusCase";
import { NavLink } from "react-router-dom";


const TopNavbar = () => {
  return (
    <Box
      py={1}
      color="#9293A6"
      sx={{
        display: "flex",
        backgroundColor: { base: "#1F2029", md: "16181F" },
      }}
      gap={4}
    >
      <OrderedList
        listStyleType={"none"}
        sx={{
          display: { base: "block", md: "flex" },
          fontSize: { base: "16px", md: "12px" },
          fontWeight: "600",
          alignItems: "center",
        }}
        gap={4}
      >
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            display: "flex",
            alignItems: "center",
            gap: "1",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <FreeCase />
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <NavLink to="/Fairness">Fairness</NavLink>
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <BonusCase />
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <NavLink to="/Referrals">Referrals</NavLink>
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <NavLink to="/About">About</NavLink>
        </ListItem>
        <ListItem
          sx={{
            _hover: { color: "#E9B10E" },
            transition: ".3s",
            display: "flex",
            alignItems: "center",
            gap: "1",
            padding: { base: "8px 0", md: "5px 0" },
          }}
        >
          <DailyCoins />
        </ListItem>
        <ListItem>
          <Select
            size={"xs"}
            sx={{
              border: "none",
              fontWeight: "600",
              _hover: { color: "#E9B10E" },
              fontSize: { base: "16px", md: "12px" },
              margin: { base: "8px 0", md: "auto" },
            }}
          >
            <option value="option1">Option 1</option>
            <option value="option2">Option 2</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
            <option value="option3">Option 3</option>
          </Select>
        </ListItem>
      </OrderedList>
    </Box>
  );
};

export default TopNavbar;
