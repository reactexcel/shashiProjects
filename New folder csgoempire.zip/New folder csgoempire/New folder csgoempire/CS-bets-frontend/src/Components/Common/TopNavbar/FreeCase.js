import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  Button,
  Text,
  Link,
} from "@chakra-ui/react";
import React from "react";
import { AiFillGift } from "react-icons/ai";
import { BiLogoSteam } from "react-icons/bi";

function FreeCase() {
  const OverlayTwo = () => <ModalOverlay />;
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [overlay, setOverlay] = React.useState("");
  return (
    <>
      <Button
        sx={{
          _hover: { color: "#E9B10E" },
          transition: ".3s",
          display: "flex",
          alignItems: "center",
          gap: "1",
          padding: { base: "8px 0", md: "5px 0" },
          background: "transparent",
          color: "#8392A6",
          fontSize: { base: "16px", md: "12px" },
          height: "18px",
        }}
        onClick={() => {
          setOverlay(<OverlayTwo />);
          onOpen();
        }}
      >
        Free Case
        <AiFillGift />
      </Button>
      <Modal isCentered isOpen={isOpen} onClose={onClose}>
        {overlay}
        <ModalContent
          bg="#26263d"
          sx={{ width: "340px", height: "200px", textAlign: "center" }}
        >
          <ModalHeader color="#fff">Sign in</ModalHeader>
          <ModalCloseButton color="#fff" />
          <ModalBody>
            <Text color="#9293A6">Please sign in to start playing!</Text>
            <a href="https://steamcommunity.com/login/home/?goto=">
              <Button
                bg="#01BF4D"
                size="sm"
                width="100%"
                mt={8}
                sx={{
                  _hover: { backgroundColor: "#00E359" },
                  boxShadow: "1px 2px 2px #056308",
                }}
              >
                <BiLogoSteam style={{ marginRight: "4px" }} />
                  Sign in
              </Button>
            </a>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  );
}
export default FreeCase;
