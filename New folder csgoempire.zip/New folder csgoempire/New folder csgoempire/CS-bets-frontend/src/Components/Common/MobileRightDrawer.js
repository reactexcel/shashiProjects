import React from "react";
import {
  Box,
  Button,
  Drawer,
  DrawerBody,
  DrawerContent,
  DrawerOverlay,
  IconButton,
  useDisclosure,
} from "@chakra-ui/react";
import { GiHamburgerMenu } from "react-icons/gi";
import Withdraw from "../Action/Withdraw";
import Deposit from "../Action/Deposit";
import Signin from "../Action/Signin";
import { NavLink } from "react-router-dom";
import { RxCrossCircled } from "react-icons/rx";
import { FaCoins } from "react-icons/fa";
import { FaBattleNet } from "react-icons/fa";
import TopNavbar from "./TopNavbar/TopNavbar";

function DrawerMobile() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = React.useRef();

  return (
    <>
      <IconButton
        onClick={onOpen}
        aria-label="Search database"
        sx={{
          _hover: { backgroundColor: "transparent" },
          backgroundColor: "transparent",
          color: "#9293A6",
          fontSize: "28px",
        }}
        icon={
          <GiHamburgerMenu style={{ color: isOpen ? "#E9B10E" : "9293A6" }} />
        }
      />
      <Drawer
        isOpen={isOpen}
        placement="right"
        onClose={onClose}
        finalFocusRef={btnRef}
      >
        <DrawerOverlay />
        <DrawerContent mt="8vh" sx={{ backgroundColor: "#1F2029" }}>
          <DrawerBody>
            <Box
              gap={4}
              p={4}
              bg="#24252F"
              mt={3}
              sx={{
                display: "flex",
                flexFlow: "row wrap",
                justifyContent: "center",
                borderRadius: "8px",
              }}
            >
              <Withdraw />
              <Deposit />
              <Signin />
            </Box>
            <Box py={5} color="#9293A6">
              <Button
                p={3}
                sx={{
                  width: "100%",
                  _hover: { color: "#E9B10E" },
                  transition: ".3s",
                  display: "flex",
                  alignItems: "center",
                  gap: "1",
                  borderRadius: "8px",
                  backgroundColor: "#24252F",
                  color: "#9293A6",
                }}
              >
                <RxCrossCircled fontSize={18} />
                <NavLink to="/#">ROULETTE</NavLink>
              </Button>
              <Button
                my={3}
                p={3}
                sx={{
                  width: "100%",
                  _hover: { color: "#E9B10E" },
                  transition: ".3s",
                  display: "flex",
                  alignItems: "center",
                  gap: "1",
                  borderRadius: "8px",
                  backgroundColor: "#24252F",
                  color: "#9293A6",
                }}
              >
                <FaBattleNet fontSize={17} />
                <NavLink to="/#">MATCH BETTING</NavLink>
              </Button>
              <Button
                p={3}
                sx={{
                  width: "100%",
                  _hover: { color: "#E9B10E" },
                  transition: ".3s",
                  display: "flex",
                  alignItems: "center",
                  gap: "1",
                  borderRadius: "8px",
                  backgroundColor: "#24252F",
                  color: "#9293A6",
                }}
              >
                <FaCoins />
                <NavLink to="/#">COINFLIP</NavLink>
              </Button>
            </Box>
            <TopNavbar />
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
}
export default DrawerMobile;
