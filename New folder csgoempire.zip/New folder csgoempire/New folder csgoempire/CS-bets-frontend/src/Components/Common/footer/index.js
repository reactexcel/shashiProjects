import { Box, Flex, Heading, Text } from "@chakra-ui/react";

const Footer = () => {
  return (
    <Box py={10} px={40}  sx={{ backgroundColor: "#16181F" }}>
      <Flex sx={{ justifyContent: "space-between",width:"80%" }}>
        <Box sx={{width:"70%"}}>
          <Heading as="h2" size="md" fontStyle="italic">
            CSGO <span style={{ color: "#E9B10E" }}>EMPIRE</span>
          </Heading>
          <Box sx={{fontSize:"12px",color:"#9293A6"}}>
          <Text pt={8}>
            CSGOEmpire is operated by Moonrail Limited B.V., Korporaalweg 10,
            Curaçao (Company Registration No. 148182). A company licensed and
            regulated by the laws of Curaçao under license number 8048/JAZ.
          </Text>
          <Text py={3}>
            Payments may be handled on behalf of Moonrail Limited B.V. by JHOLT
            LTD, Voukourestiou, 25, NEPTUNE HOUSE, 1st floor, Flat/Office 11,
            3045, Limassol, Cyprus (Company Registration No. HE393291) as per
            the agreement between the two companies.
          </Text>
          <Text pt={4}>Copyright © 2016 - 2023. All rights reserved.</Text>
          </Box>
        </Box>
        <Box sx={{width:"10%"}}>
            <Heading as="h2" size="xs">About</Heading>
        </Box>
      </Flex>
    </Box>
  );
};

export default Footer;
