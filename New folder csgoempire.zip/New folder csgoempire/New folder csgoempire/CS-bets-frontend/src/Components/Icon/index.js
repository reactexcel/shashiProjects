import { Box } from "@chakra-ui/react";

const BetIcon = () => {
  return (
    <Box
      sx={{
        width: "35px",
        height: "35px",
        borderRadius: "50%",
        backgroundColor: "gray",
      }}
    ></Box>
  );
};

export default BetIcon;
