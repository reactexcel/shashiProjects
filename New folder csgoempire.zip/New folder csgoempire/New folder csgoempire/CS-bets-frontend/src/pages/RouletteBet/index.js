import { Box, Button, ButtonGroup, Input, InputGroup } from "@chakra-ui/react";
import React from "react";
import CardBox from "../../Components/Card/Card";

const buttonData = [
  { id: "1", value: "CLEAR", bgColor: "transparent" },
  { id: "2", value: "+1", bgColor: "#383D46" },
  { id: "3", value: "+10", bgColor: "#383D46" },
  { id: "4", value: "+100", bgColor: "#383D46" },
  { id: "5", value: "+1000", bgColor: "#383D46" },
  { id: "6", value: "1/2", bgColor: "#383D46" },
  { id: "7", value: "x2", bgColor: "#383D46" },
  { id: "8", value: "MAX", bgColor: "#383D46" },
];

const cardButtonData = [
  {
    id: "1",
    value: "Place Bet",
    textValue: "Win 2x",
    color: "#fff",
    bg: "#DE4C41",
    hoverBg: "#d63427",
  },
  {
    id: "2",
    value: "Place Bet",
    textValue: "Win 14x",
    color: "#fff",
    bg: "#00C74D",
    hoverBg: "#0e9e46",
  },
  {
    id: "3",
    value: "Place Bet",
    textValue: "Win 2x",
    color: "#fff",
    bg: "#21252B",
    hoverBg: "#383d45",
  },
  {
    id: "4",
    value: "Place Bet",
    textValue: "Win 7x",
    color: "#fff",
    bg: "#38434F",
    hoverBg: "#333e4a",
  },
];
const RouletteBet = () => {
  return (
    <Box px={2} mt={16}>
      <Box
        px={2}
        py={1}
        sx={{
          width: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          backgroundColor: "#000",
          borderRadius: "8px",
          border: "1px solid #403f3f",
        }}
      >
        <InputGroup
          width="100%"
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Input
            placeholder="Enter Amount"
            sx={{
              border: "none",
              outline: "none",
              _focusVisible: { outline: "none", border: "none" },
            }}
          />
          <ButtonGroup>
            {buttonData.map((ele) => {
              return (
                <Button
                  key={ele.id}
                  sx={{
                    height: "32px",
                    backgroundColor: `${ele.bgColor}`,
                    color: "#fff",
                    fontSize: "12px",
                    _hover: { backgroundColor: `${ele.bgColor}` },
                  }}
                >
                  {ele.value}
                </Button>
              );
            })}
          </ButtonGroup>
        </InputGroup>
      </Box>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          flexFlow: "row wrap",
        }}
      >
        {cardButtonData.map((ele) => {
          return (
            <CardBox
              key={ele.id}
              textValue={ele.textValue}
              buttonValue={ele.value}
              bg={ele.bg}
              hoverBg={ele.hoverBg}
              color={ele.color}
            />
          );
        })}
      </Box>
    </Box>
  );
};

export default RouletteBet;
