import { Box } from '@chakra-ui/react'
import React from 'react'

const FairnessBonusCase = () => {
  return (
  <Box>
    FairnessBonusCase
  </Box>
  )
}

export default FairnessBonusCase
