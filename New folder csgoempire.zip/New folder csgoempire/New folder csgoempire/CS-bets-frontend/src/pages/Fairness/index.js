import { Box, Button, ButtonGroup } from "@chakra-ui/react";
import Layout from "../Layout";
import Info from "./fairnessInfo";
import FairnessRoulette from "./fairnessRoulette";
import CoinFlip from "./fairnessCoinFlip";
import FairnessBonusCase from "./fairnessBonusCase";
import { useState } from "react";

const fairnessButtonData = [
  { id: "1", value: "Info" },
  { id: "2", value: "Roulette" },
  { id: "3", value: "Coinflip" },
  { id: "4", value: "Bonus Cases" },
];

const FairnessTabs = (tabValue) => {
  switch (tabValue) {
    case "Info":
      return <Info />;
    case "Roulette":
      return <FairnessRoulette />;
    case "Coinflip":
      return <CoinFlip />;
    case "Bonus Cases":
      return <FairnessBonusCase />;
    default:
      return tabValue;
  }
};

const Fairness = () => {
  const [tabValue, setTabValue] = useState("Info");
  const [id, setId] = useState(1);

  const handleClick = (ele) => {
    setId(ele.id);
    setTabValue(ele.value);
  };

  return (
    <Layout>
      <Box p={10}>
        <ButtonGroup>
          {fairnessButtonData.map((ele) => {
            const hoverbg = ele.id === id ? "#edb10e" : "#333541";
            return (
              <Button
                key={ele.id}
                sx={{
                  color: "#DCDCDC",
                  fontSize: "14px",
                  height: "35px",
                }}
                backgroundColor={ele.id === id ? "#E9B10E" : "#24252F"}
                _hover={{
                  backgroundColor: hoverbg,
                  color: "#DCDCDC",
                }}
                onClick={() => handleClick(ele)}
              >
                {ele.value}
              </Button>
            );
          })}
        </ButtonGroup>
        <Box mt={8}>{FairnessTabs(tabValue)}</Box>
      </Box>
    </Layout>
  );
};

export default Fairness;
