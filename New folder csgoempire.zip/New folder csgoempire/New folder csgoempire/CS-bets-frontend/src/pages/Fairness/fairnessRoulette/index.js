import { Box } from "@chakra-ui/react";
import React from "react";

const FairnessRoulette = () => {
  return <Box>FairnessRoulette</Box>;
};

export default FairnessRoulette;
