import {
  Box,
  Button,
  Flex,
  Heading,
  Image,
  Input,
  Text,
} from "@chakra-ui/react";

import Infoimg from "../../../assets/fairnessImg.jpg";

const Info = () => {
  return (
    <Flex
      pt={4}
      sx={{ width: "100%", justifyContent: "space-between", gap: "55px" }}
    >
      <Box sx={{ width: "50%" }}>
        <Heading as="h2" size="md">
          HOW CAN I KNOW THAT THE GAME IS FAIR?
        </Heading>
        <Text textAlign="justify" py={2} fontSize={14}>
          The game results have been generated BEFORE you even place your bet,
          and most importantly, we can prove it.
        </Text>
        <Text fontSize={14}>
          Before each round, we actually give you the round result in a hashed
          format
        </Text>
        <Text py={2} fontSize={14}>
          Before the round, we give you the hash of the secret seed which the
          round result is based on. After the round ends, we publish the secret
          seed, which you can then compare to the hash to make sure that they
          match. With this system we can prove that the results were fair and
          pre-generated.
        </Text>
        <Box>
          <Image src={Infoimg} alt="fairness" />
        </Box>
      </Box>
      <Box sx={{ width: "50%" }}>
        <Text fontSize={14} pb={6}>
          For each verifiable bet (except in roulette and coinflip where we use
          different systems), a client seed, a server seed and a nonce are used
          as the input parameters.
        </Text>
        <Box>
          <Heading as="h3" fontSize={12}>
            Client Seed
          </Heading>
          <Text fontSize={14} py={3}>
            This is a passphrase or a randomly generated string that is
            determined by the player or their browser. This can be edited and
            changed regularly by yourself.
          </Text>
        </Box>
        <Flex
          p={1}
          sx={{
            border: "1px solid #333541",
            borderRadius: "6px",
            alignItems: "center",
            backgroundColor:"#141419"
          }}
          my={2}
        >
          <Input
            sx={{ border: "none",fontSize:"12px", _focusVisible: { border: "none" } }}
            value={"3LfCrRRX--KQTant7ANSPe5IyrQ0XKAG"}
          />
          <Button
            sx={{
              backgroundColor: "#E9B10E",
              height: "32px",
              color:"#000",
              _hover: { backgroundColor: "#ffbc05" },
            }}
          >
            Save
          </Button>
        </Flex>
        <Box>
          <Heading as="h3" fontSize={12} pt={4}>
            Server Seed
          </Heading>
          <Text fontSize={14} py={3}>
            To reveal the hashed server seed, the seed must be rotated by the
            player, which triggers the replacement with a newly generated seed.
            From this point you are able to verify any bets made with the
            previous server seed to verify both the legitimacy of the server
            seed with the encrypted hash that was provided.
          </Text>
        </Box>
        <Text fontSize={14} py={3}>
          Login to see your server seed.
        </Text>
      </Box>
    </Flex>
  );
};

export default Info;
