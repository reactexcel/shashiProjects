import { Box } from "@chakra-ui/react";

const CoinFlip = () => {
  return <Box>CoinFlip</Box>;
};

export default CoinFlip;
