import React, { useState, useEffect } from "react";
import "./roulette.css";
import { Box } from "@chakra-ui/react";
import RouletteBet from "../RouletteBet";

const RouletteItem = () => {
  const [x, setX] = useState(999);
  const [timer, setTimer] = useState(0);

  const numbers = {
    0: 525,
    1: 0,
    2: 150,
    3: 300,
    4: 450,
    5: 675,
    6: 825,
    7: 975,
    8: 1050,
    9: 900,
    10: 750,
    11: 600,
    12: 375,
    13: 225,
    14: 75,
  };

  const roll = () => {
    let newNumber;
    if (x === 999) {
      newNumber = Math.floor(Math.random() * 14);
    } else {
      newNumber = x;
    }

    const cycles = Math.floor(randomKaanNumber(2, 4));
    const scrollForNumber = randomKaanNumber(0, 72);
    const scrollAmount =
      825 + numbers[newNumber] + scrollForNumber + 1125 * cycles;

    const rouletteArea = document.getElementById("roulette_area");

    if (rouletteArea) {
      rouletteArea.classList.remove("spin_animation");
      setTimeout(() => {
        rouletteArea.classList.remove("spin_animation_back");
        rouletteArea.classList.add("spin_animation");
        rouletteArea.style.backgroundPositionX = "-262.5px";
        rouletteArea.style.backgroundPositionX = `-${scrollAmount}px`;
      }, 10);

      setTimeout(() => {
        setX(999);
      }, 6000);

      setTimeout(() => {
        setTimer(0);
      }, 1);
    }
  };

  const loops = () => {
    setTimeout(() => {
      const rouletteArea = document.getElementById("roulette_area");
      if (rouletteArea) {
        rouletteArea.classList.remove("spin_animation");
        rouletteArea.classList.add("spin_animation_back");
        rouletteArea.style.backgroundPositionX = "-262.5px";
      }
    }, 3800);

    setTimer(0);
    setTimeout(() => {
      setTimer(100);
    }, 1);

    setTimeout(roll, 5000);
  };

  useEffect(() => {
    loops();
    const intervalId = setInterval(loops, 12000);
    return () => clearInterval(intervalId);
  }, []);

  const randomKaanNumber = (min, max) => {
    return Math.random() * (max - min) + min;
  };

  return (
    <Box className="roulette_wraper" pt={12}>
      <Box className="roulette__container">
        <Box
          sx={{
            backgroundColor: "#1c1f24",
            marginTop: "20px",
            borderRadius: "20px",
          }}
        >
          <Box className="roulette_overflow">
            <Box id="roulette_area"></Box>
          </Box>
        </Box>
        <Box className="timer_bar" mt={8}>
          <Box
            className="timer"
            id="timer"
            style={{ width: `${timer}%` }}
          ></Box>
        </Box>
      </Box>
      <RouletteBet />
    </Box>
  );
};

export default RouletteItem;
