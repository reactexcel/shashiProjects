import Layout from "./Layout";
import RouletteItem from "../pages/CsgoRoulette/RouletteItem"

const Dashboard = () => {
  return (
    <Layout>
    <RouletteItem/>
    </Layout>
  );
};

export default Dashboard;
