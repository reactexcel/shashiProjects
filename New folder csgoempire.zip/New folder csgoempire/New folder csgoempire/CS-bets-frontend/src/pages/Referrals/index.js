import React from 'react'

const Referrals = () => {
  return (
    <div>
      Referrals
    </div>
  )
}

export default Referrals
