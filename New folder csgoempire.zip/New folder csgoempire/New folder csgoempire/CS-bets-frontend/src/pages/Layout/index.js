import { Box, Button, Heading, Tooltip } from "@chakra-ui/react";
import TopNavbar from "../../Components/Common/TopNavbar/TopNavbar";
import Navbar from "../../Components/Common/Navbar";
import Sidebar from "../../Components/Common/Sidebar";
import MobileNavbar from "../../Components/Common/MobileNavbar";
import {TfiHeadphoneAlt} from "react-icons/tfi"
import { NavLink } from "react-router-dom";
import Footer from "../../Components/Common/footer";

const Layout = ({ children }) => {
  return (
    <Box width="100%">
      <Box sx={{ display: { base: "none", md: "block" } }}>
        <Box bg="gray" display="flex">
          <Box
            width={{ base: "100%", md: "20%" }}
            bg="#24252F"
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
           <NavLink to="/">
            <Heading
              sx={{
                fontStyle: "italic",
                color: "#FFFFFF",
                fontSize: "28px",
              }}
            >
              CSGO<span style={{ color: "#E9B10E" }}>EMPIRE</span>
            </Heading>
            </NavLink> 
          </Box>
          <Box width="80%">
            <TopNavbar />
            <Navbar />
          </Box>
        </Box>
      </Box>
      <Box sx={{ display: { base: "block", md: "none" } }}>
        <MobileNavbar />
      </Box>
      <Box
        sx={{
          display: "flex",
          width: "100%",
          // height: { base: "92vh", md: "88vh" },
        }}
      >
        <Box bg="#1F2029" color="#fff" width="20%">
          <Sidebar />
        </Box>
        <Box width="80%" bg="#1A1C24" color="#fff">
          {children}
          <Footer/>
        </Box>
        <Tooltip
              label="open Live Chat"
              hasArrow
              bg="#000"
              placement="auto"
              borderRadius="8px"
            >
              <Button
                sx={{
                  backgroundColor: "#383D46",
                  width: "50px",
                  height: "50px",
                  borderRadius: "50%",
                  position: "fixed",
                  bottom: "6",
                  zIndex: "1000",
                  right: "6",
                  color: "#fff",
                  _hover: { backgroundColor: "#32353b" },
                }}
              >
                <TfiHeadphoneAlt fontSize="50px" />
              </Button>
            </Tooltip>
      </Box>
    </Box>
  );
};

export default Layout;
