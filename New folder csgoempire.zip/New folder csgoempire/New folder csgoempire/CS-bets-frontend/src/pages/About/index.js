import { Box } from '@chakra-ui/react'
import React from 'react'

const About = () => {
  return (
   <Box>
    About
   </Box>
  )
}

export default About
