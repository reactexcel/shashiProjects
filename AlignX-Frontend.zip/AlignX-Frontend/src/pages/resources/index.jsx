import { Box } from "@mui/material";

const Resources = () => {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
  return (
    <Box sx={{ maxWidth: "1250px" }} mx={"auto"} height={"70vh"}>
      Resources
    </Box>
  );
};

export default Resources;
