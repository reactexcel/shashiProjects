import WWhite1 from './20020291019_White_/20020291019_White_1.jpg'
import WWhite2 from './20020291019_White_/20020291019_White_2.jpg'
import WWhite3 from './20020291019_White_/20020291019_White_3.jpg'
import WWhite4 from './20020291019_White_/20020291019_White_4.jpg'
import WWhite5 from './20020291019_White_/20020291019_White_5.jpg'
import WMustard1 from './20020291115_Mustard_/20020291115_Mustard_1.jpg'
import WMustard2 from './20020291115_Mustard_/20020291115_Mustard_2.jpg'
import WMustard3 from './20020291115_Mustard_/20020291115_Mustard_3.jpg'
import WMustard4 from './20020291115_Mustard_/20020291115_Mustard_4.jpg'
import WMustard5 from './20020291115_Mustard_/20020291115_Mustard_5.jpg'
import WMustard6 from './20020291115_Mustard_/20020291115_Mustard_6.jpg'
import WMustard7 from './20020291115_Mustard_/20020291115_Mustard_7.jpg'
import WBlue1 from './20020291217_Blue_/20020291217_Blue_1.jpg'
import WBlue2 from './20020291217_Blue_/20020291217_Blue_2.jpg'
import WBlue3 from './20020291217_Blue_/20020291217_Blue_3.jpg'
import WBlue4 from './20020291217_Blue_/20020291217_Blue_4.jpg'
import WBlue5 from './20020291217_Blue_/20020291217_Blue_5.jpg'

export {
    WWhite1,
    WWhite2,
    WWhite3,
    WWhite4,
    WWhite5,
    WMustard1,
    WMustard2,
    WMustard3,
    WMustard4,
    WMustard5,
    WMustard6,
    WMustard7,
    WBlue1,
    WBlue2,
    WBlue3,
    WBlue4,
    WBlue5
}
