import dress from './image1.jpeg';
import dress2 from './image2.jpeg';
import dress3 from './image3.jpg';
import dress4 from './image4.jpg';
import dress5 from './image5.jpg';
import dress6 from './image6.jpg';


export {
    dress,
    dress2,
    dress3,
    dress4,
    dress5,
    dress6
}