import mobile1 from './Banner1.jpg';
import mobile2 from './Banner2.jpg';
import mobile3 from './Banner4.jpg';
import mobile4 from './Banner6.jpg';
import mobile5 from './Banner7.jpg';
import mobile6 from './formalwomen.jpg'
import cat2 from './cat2.jpg'
import cat3 from './cat3.jpg'
export {
    mobile1,mobile2,mobile3,mobile4,mobile5,mobile6,cat2,cat3
}