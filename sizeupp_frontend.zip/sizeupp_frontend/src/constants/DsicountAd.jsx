
import { DarkNavys1, GEGreen1, Maroon1, Navy1, Skyblue1, Wine1 } from '../assets/images/men'
import { WBlue1, WMustard1, WWhite1 } from '../assets/images/women'

export const DiscountAdImages = [
    {
        id : 1,
        img : WWhite1
    },
    {
        id : 2,
        img : GEGreen1
    },
    {
        id : 3,
        img : Maroon1
    },
    {
        id : 4,
        img : WMustard1
    },
    {
        id : 5,
        img : Wine1
    },
    {
        id : 6,
        img : WBlue1
    },
    {
        id : 7,
        img : Maroon1
    },
    {
        id : 8,
        img : DarkNavys1
    },
    {
        id : 9,
        img : Navy1
    },
    {
        id : 10,
        img : Skyblue1
    },
    {
        id : 11,
        img : GEGreen1
    },
    {
        id : 12,
        img : WBlue1
    },
    {
        id : 13,
        img : WMustard1
    },
]