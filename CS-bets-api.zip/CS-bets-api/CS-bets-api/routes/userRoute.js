const express = require("express");
const userController = require("../controllers/userController");
const joi_validator = require("../joi-validator/joi-userWallet-validation");
const web3Middleware = require("../middleware/web3Middleware");

const router = express.Router();

// generate random number and place the prediction
router.post(
  "/random-number",
  web3Middleware,
  joi_validator.validateUserWithAmount,
  userController.generateRandomNumber
);

// register with wallet address
router.patch(
  "/register-with-wallet",
  web3Middleware,
  joi_validator.validateWalletAddress,
  userController.registerWithWallet
);

module.exports = router;
