const express = require("express");
const walletController = require("../controllers/applicationController");
const joi_validator = require("../joi-validator/joi-application-validation");
const web3hMiddleware = require("../middleware/web3Middleware");

const router = express.Router();

// register user using wallet id
router.post(
  "/withdraw-amount",
  web3hMiddleware,
  joi_validator.validateWithdrawalAmount,
  walletController.withdrawalAmount
);

module.exports = router;
