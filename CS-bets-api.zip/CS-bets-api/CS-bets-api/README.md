# CS-bets-api

### Database Configurations and .env File

Make sure to create a `.env` file in the directory of your project with the following configurations:

```
PORT=
DB_USERNAME=
DB_PASSWORD=
DB_NAME=
DB_HOST=
MAX =
```

### Commands for Database

```
CREATE DATABASE "CSGO";
```

### Run the migration to set up the database tables

npx sequelize-cli db:migrate

```
CREATE TABLE `UserWallets` (
  `walletAddress` varchar(255) NOT NULL,
  `virtualBalance` decimal(10,2) DEFAULT '100.00',
  `walletToken` text NOT NULL,
  PRIMARY KEY (`walletAddress`)
)

CREATE TABLE `Applications` (
  `walletAddress` varchar(255) NOT NULL,
  `amount` decimal(10,2) DEFAULT '0.00',
  `timestamp` bigint DEFAULT NULL,
  PRIMARY KEY (`walletAddress`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`walletAddress`) REFERENCES `UserWallets` (`walletAddress`)
)

```
