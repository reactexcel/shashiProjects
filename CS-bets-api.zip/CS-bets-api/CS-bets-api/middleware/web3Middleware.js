const Web3Token = require("web3-token");

const web3Middleware = async (req, res, next) => {
  try {
    const token = req.headers["authorization"];
    console.log(token,"++");
    if (!token && !token.startsWith("Bearer")) {
      return res
        .status(400)
        .json({ message: "Invalid token or token formet wrong" });
    }
    if (token && token.startsWith("Bearer")) {
      let Token = token.split(" ")[1];

      let { address, body } = await Web3Token.verify(Token);
      req.User = { address, Token, body };
      next();
    }
  } catch (error) {
    console.error(error);
    return res.status(401).json(error);
  }
};
module.exports = web3Middleware;
