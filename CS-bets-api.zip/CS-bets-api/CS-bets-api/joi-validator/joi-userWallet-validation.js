const Joi = require("joi");

const validateUserWithAmount = (req, res, next) => {
  const schema = Joi.object({
    walletAddress: Joi.string(),
    amount: Joi.number(),
    walletToken: Joi.string(),
  });

  const { error, value } = schema.validate(req.body);

  if (error) {
    return res.status(400).json({ error: error.details[0].message });
  }

  req.body = value;
  return next();
};

const validateWalletAddress = (req, res, next) => {
  const schema = Joi.object({
    address: Joi.string().required(),
    amount: Joi.number(),
    walletToken: Joi.string(),
  });

  const { error, value } = schema.validate(req.body);

  if (error) {
    return res.status(400).json({ error: error.details[0].message });
  }

  req.body = value;
  return next();
};

module.exports = {
  validateUserWithAmount,
  validateWalletAddress,
};
