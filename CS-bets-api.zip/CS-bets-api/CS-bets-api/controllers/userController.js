const { UserWallet } = require("../models");

// register user with walletId controller
const registerWithWallet = async (req, res) => {
  const { address, Token } = req.User;

  try {
    const userwalletAddress = await UserWallet.findOne({
      where: { walletAddress: address },
      raw: true,
    });
    if (userwalletAddress && userwalletAddress.walletToken !== Token) {
      await UserWallet.update(
        {
          walletToken: Token,
        },
        { where: { walletAddress: address } }
      );
      return res.status(200).json("Token updated");
    } else {
      await UserWallet.create({
        walletAddress: address,
        walletToken: Token,
      });
      return res.status(201).json({
        success: true,
        message: "User Registered Successfully with WalletAddress",
      });
    }
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, error: error.message });
  }
};

// generate random number for placing the prediction
const generateRandomNumber = async (req, res) => {
  const { number } = req.body;
  const address = req.User.address;

  const userwalletAddress = await UserWallet.findOne({
    where: { walletAddress: address },
    raw: true,
  });
  console.log(userwalletAddress.amount);
  const randomNumber = Math.floor(Math.random() * process.env.MAX) + 1;

  if (randomNumber === number) {
    await UserWallet.update(
      {
        amount: userwalletAddress.amount + 1,
      },
      { where: { walletAddress: address } }
    );
    return res.json("true");
  } else {
    await UserWallet.update(
      {
        amount: userwalletAddress.amount - 1,
      },
      { where: { walletAddress: address } }
    );
    return res.json("false");
  }
};

module.exports = { generateRandomNumber, registerWithWallet };
