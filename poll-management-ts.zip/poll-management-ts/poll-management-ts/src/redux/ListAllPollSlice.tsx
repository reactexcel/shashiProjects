import { createSlice } from "@reduxjs/toolkit";

const initialState = { data: [] };

export const ListAllPollSlice = createSlice({
  name: "ListAllPoll",
  initialState,
  reducers: {
    ListAllPollData(state, action) {
      console.log(action, "!!!!!!!!!!!!!111");
    },
  },
});

export const { ListAllPollData } = ListAllPollSlice.actions;
export default ListAllPollSlice.reducer;
