import { createSlice } from "@reduxjs/toolkit";

const initialState = { data: [] };

export const AddPollSlice = createSlice({
  name: "AddPoll",
  initialState,
  reducers: {
    AddPoll(state, action) {
      state.data = action.payload;
    },
  },
});

export const { AddPoll } = AddPollSlice.actions;
export default AddPollSlice.reducer;
