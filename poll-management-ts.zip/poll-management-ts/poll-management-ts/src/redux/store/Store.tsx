import { configureStore } from "@reduxjs/toolkit";
import SignupSlice from "../SignupSlice";
import LoginSlice from "../LoginSlice";
import AddPollSlice from "../AddPollSlice";
import ListAllPollSlice from "../ListAllPollSlice";

export const store = configureStore({
  reducer: {
    SignupSlice: SignupSlice,
    LoginSlice: LoginSlice,
    AddPollSlice: AddPollSlice,
    ListAllPollSlice: ListAllPollSlice,
  },
});
