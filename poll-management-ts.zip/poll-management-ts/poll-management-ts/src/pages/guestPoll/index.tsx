
const GuestPoll = () => {
  return (
    <div>
      GuestPoll
    </div>
  )
}

export default GuestPoll
