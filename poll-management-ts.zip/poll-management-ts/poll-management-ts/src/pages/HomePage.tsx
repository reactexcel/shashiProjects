import LoginForm from "../features/login";

const HomePage = () => {
  return <LoginForm/>;
};

export default HomePage;
