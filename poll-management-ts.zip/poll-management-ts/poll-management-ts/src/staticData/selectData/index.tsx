export const selectData=[
    {id:1,name:"Guest"},
    {id:2,name:"Admin"},
]