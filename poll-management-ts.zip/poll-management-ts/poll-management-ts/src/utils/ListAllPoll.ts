import { APIEnpoint } from "../config/Config";

export const ListAllPoll = async (dispatch: any) => {
  try {
    const response = await APIEnpoint.get(`list_polls`);
    console.log(response, "rrrrrrrrrrrreeeeeeeeeeeeesssss");
    dispatch(ListAllPoll(response.data.data));
  } catch (error) {
    console.error("Error during registration:", error);
  }
};
