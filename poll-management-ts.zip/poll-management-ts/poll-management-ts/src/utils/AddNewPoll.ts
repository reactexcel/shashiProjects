import { Dispatch } from "@reduxjs/toolkit";
import { APIEnpoint } from "../config/Config";
import { AddPoll } from "../redux/AddPollSlice";

interface AddNewPollType {
  dispatch: Dispatch;
  inputTextTitle: string;
  inputTextOption: string;
}

export const AddNewPoll = async ({
  dispatch,
  inputTextTitle,
  inputTextOption,
}: AddNewPollType): Promise<void> => {
  try {
    const response = await APIEnpoint.post(
      `add_poll?title=${inputTextTitle}&options=${inputTextOption}`
    );
    dispatch(AddPoll(response.data.data));
  } catch (error) {
    console.error("Error during registration:", error);
  }
};
