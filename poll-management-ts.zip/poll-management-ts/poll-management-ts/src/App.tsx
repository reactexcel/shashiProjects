import { BrowserRouter } from "react-router-dom";
import "./App.css";
import AllRoutes from "./router";
import { Provider } from "react-redux";
import { store } from "./redux/store/Store";

const App = () => {
  return (
    <div className="App">
      <Provider store={store}>
        <BrowserRouter>
          <AllRoutes />
        </BrowserRouter>
      </Provider>
    </div>
  );
};

export default App;
