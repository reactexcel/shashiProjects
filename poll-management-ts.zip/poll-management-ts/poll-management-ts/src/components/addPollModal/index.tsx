import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Modal from "@mui/material/Modal";
import { TextField } from "@mui/material";
import { AddNewPoll } from "../../utils/AddNewPoll";
import { useDispatch } from "react-redux";
import { useState } from "react";
import { ListAllPoll } from "../../utils/ListAllPoll";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 400,
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  textAlign: "center",
  marginTop: "10px",
};

export default function AddPollModal() {
  const dispatch = useDispatch();
  const [inputTextTitle, setInputTextTitle] = useState("");
  const [inputTextOption, setInputTextOption] = useState("");
  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [option, setOption] = useState([{ option: "" }]);

  const AddOption = () => {
    if (option.length > 3) {
      console.log("error");
    } else {
      setOption([...option, { option: "" }]);
    }
  };

  const callApi = () => {
    AddNewPoll({ dispatch, inputTextTitle, inputTextOption });
    ListAllPoll(dispatch);
  };

  return (
    <div>
      <Button
        onClick={handleOpen}
        variant="contained"
        color="success"
        size="small"
      >
        Add Poll
      </Button>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography
            id="modal-modal-title"
            variant="h1"
            component="h1"
            sx={{ fontWeight: "700", fontSize: "24px" }}
          >
            ADD POLL
          </Typography>
          <TextField
            sx={{ width: "100%", margin: "10px 0" }}
            label="Title"
            variant="standard"
            value={inputTextTitle}
            onChange={(e) => setInputTextTitle(e.target.value)}
          />
          {option.map((e, i) => {
            return (
              <TextField
                key={i}
                sx={{ width: "100%", margin: "10px 0" }}
                label={`option ${i + 1}`}
                variant="standard"
                value={inputTextOption}
                onChange={(e) => setInputTextOption(e.target.value)}
              />
            );
          })}

          <Button variant="contained" size="small" onClick={AddOption}>
            Add more option
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={{ width: "70%", margin: "10px 0" }}
            onClick={() => callApi()}
          >
            Add
          </Button>
        </Box>
      </Modal>
    </div>
  );
}
