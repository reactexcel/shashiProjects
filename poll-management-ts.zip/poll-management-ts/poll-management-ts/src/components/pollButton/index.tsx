interface PollButtonType {
  value: string;
  buttonstyle: string;
  type: "submit";
}

const PollButton = (props: PollButtonType) => {
  const { value, buttonstyle, type } = props;

  return (
    <button type={type} className={buttonstyle}>
      {value}
    </button>
  );
};

export default PollButton;
