# models.py
from django.db import models

class BrokerApplication(models.Model):
    role = models.CharField(max_length=255, null=True, blank=True)
    employment_type = models.CharField(max_length=255, null=True, blank=True)
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    suffix = models.CharField(max_length=255, blank=True, null=True)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=10)
    about_yourself = models.TextField(null=True, blank=True)
    appointment_date = models.DateTimeField(null=True, blank=True)
    # Add other fields as needed
