# serializers.py
from rest_framework import serializers
from .models import BrokerApplication


class BrokerApplicationSerializer(serializers.ModelSerializer):
    class Meta:
        model = BrokerApplication
        fields = '__all__'
