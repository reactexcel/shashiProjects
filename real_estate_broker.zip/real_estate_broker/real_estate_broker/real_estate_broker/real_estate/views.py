# views.py
from django.shortcuts import render
from django.views import View
from .serializers import BrokerApplicationSerializer
from django.http import HttpResponseRedirect
from django.urls import reverse
from .models import BrokerApplication
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django.http import JsonResponse


class BrokerApplicationSubmitView(View):
    template_name = 'broker_application_form.html'
    success_template_name = 'success_template.html'

    def get(self, request, *args, **kwargs):
        form = BrokerApplicationSerializer()
        return render(request, self.template_name, {'form': form})

    def post(self, request):
        print(request, "iiiiiiiiiiiiiiiiiii")
        data = request.POST  # Use request.POST to access form data

        print(data, "rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr")

        broker_email = data.get("email")

        try:
            broker = BrokerApplication.objects.get(email=broker_email)
            form = BrokerApplicationSerializer(broker, data=data, partial=True)
        except BrokerApplication.DoesNotExist:
            broker = None
            form = BrokerApplicationSerializer(data=data)

        if form.is_valid():
            form.save()
            messages.success(request, 'Updated!')
            return JsonResponse({'success': True})  # Return a JSON response on success
        else:
            messages.error(request, 'An error occurred!')
            return JsonResponse({'success': False, 'errors': form.errors})