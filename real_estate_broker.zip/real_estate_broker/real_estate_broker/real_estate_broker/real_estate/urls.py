# urls.py
from django.urls import path
from .views import BrokerApplicationSubmitView

urlpatterns = [
    path('broker_submit/', BrokerApplicationSubmitView.as_view(), name='broker_application_submit'),
    # path('success/', SuccessTemplateView.as_view(), name='success_template'),  # Add a URL for the success template
]
