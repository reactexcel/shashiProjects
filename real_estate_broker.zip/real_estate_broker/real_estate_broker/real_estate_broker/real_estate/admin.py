from django.contrib import admin
from .models import BrokerApplication
# Register your models here.

admin.site.register(BrokerApplication)