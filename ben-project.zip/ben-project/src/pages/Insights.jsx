import React from 'react'
// import ExampleWithLocalizationProvider from '../components/InsightTable'

const Insights = () => {
  return (
    <div>
      {/* <ExampleWithLocalizationProvider/> */}
    </div>
  )
}

export default Insights
