import React from 'react'
import "chart.js/auto";
import { Line } from 'react-chartjs-2'

const Chart = ({data,options}) => {
  return (
    <div className="App">
      <Line data={data} options={options} height={`100px`} />
    </div>
  )
}

export default Chart
