import { Box, Button, Stack, Typography } from '@mui/material'
import React from 'react'

const Home = () => {
  return (
    <div>
                    <Box sx={{ display: 'flex', gap: 5 }}>
                    <Stack sx={{ backgroundColor: 'white', width: '50%', height: '40vh', borderRadius: '10px', padding: '10px', justifyContent: 'end' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                            <Typography>Last synced: 3/19/24, 3:41:54 PM </Typography>
                            <Button sx={{ color: 'white', backgroundColor: 'blue' }}>Open Connections</Button>
                        </Box>
                    </Stack>
                    <Box sx={{ backgroundColor: 'white', width: '20%', height: '40vh', borderRadius: '10px' }}>
                    </Box>
                    <Box sx={{ backgroundColor: 'white', width: '20%', height: '40vh', borderRadius: '10px' }}>

                    </Box>
                </Box>      
    </div>
  )
}

export default Home
