import * as React from "react";
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import MuiDrawer from "@mui/material/Drawer";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import InboxIcon from "@mui/icons-material/MoveToInbox";
import MailIcon from "@mui/icons-material/Mail";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import ChatBubbleOutlineOutlinedIcon from "@mui/icons-material/ChatBubbleOutlineOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import PinDropOutlinedIcon from "@mui/icons-material/PinDropOutlined";
import EnergySavingsLeafOutlinedIcon from "@mui/icons-material/EnergySavingsLeafOutlined";
import InsightsOutlinedIcon from "@mui/icons-material/InsightsOutlined";
import Inventory2OutlinedIcon from "@mui/icons-material/Inventory2Outlined";
import InventoryOutlinedIcon from "@mui/icons-material/InventoryOutlined";

import HomeIcon from "@mui/icons-material/Home";
import { BiSolidBinoculars } from "react-icons/bi";
import { PiMapPinLineFill } from "react-icons/pi";
import { FaClipboardList } from "react-icons/fa";
import { BsClipboardDataFill } from "react-icons/bs";
import { VscChecklist } from "react-icons/vsc";
import { SiLeaflet } from "react-icons/si";
import { MdOutlineCyclone } from "react-icons/md";
import { GiSplitCross } from "react-icons/gi";
import { SiDialogflow } from "react-icons/si";
import { IoMdChatboxes } from "react-icons/io";
import { IoIosNotifications } from "react-icons/io";
import { IoSettings } from "react-icons/io5";
// import { Link } from "react-router-dom";

import {
  Button,
  FormControl,
  InputLabel,
  NativeSelect,
  Stack,
} from "@mui/material";
import { Link } from "react-router-dom";

const drawerWidth = 240;

const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "flex-end",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
}));

const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  zIndex: theme.zIndex.drawer + 1,
  transition: theme.transitions.create(["width", "margin"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

const Drawer = styled(MuiDrawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

const sidebarIcons = [
  {
    icon: <HomeOutlinedIcon />,
    iconName: "Home",
    path: "/",
  },
  {
    icon: <InsightsOutlinedIcon />,
    iconName: "Insights",
    path: "Insights",
  },
  {
    icon: <Inventory2OutlinedIcon />,
    iconName: "Inventory Visiblity",
    path: "Inventory_Visiblity",
  },
  {
    icon: <PinDropOutlinedIcon />,
    iconName: "Network Map",
    path: "Network_Map",
  },
  {
    icon: <HomeOutlinedIcon />,
    iconName: "Work Order Insights",
    path: "Work_Order_Insights",
  },
  {
    icon: <HomeOutlinedIcon />,
    iconName: "Demand Planning",
    path: "Demand_Planning",
  },
  {
    icon: <InventoryOutlinedIcon />,
    iconName: "Supply Planning",
    path: "Supply_Planning",
  },
  {
    icon: <EnergySavingsLeafOutlinedIcon />,
    iconName: "Sustainability",
    path: "Sustainability",
  },
  {
    icon: <HomeOutlinedIcon />,
    iconName: "Data Lake",
    path: "Data_Lake",
  },
  {
    icon: <HomeOutlinedIcon />,
    iconName: "N-Tier Visibility",
    path: "N-Tier-Visibility",
  },
];

const sideNavbarLink = [
 
  {
    title: "Home",
    path: "/",
    icon: <HomeIcon />,
  },
  {
    title: "Insights",
    path: "/insights",
    icon: <BiSolidBinoculars />,
  },
  {
    title: "Inventory Visibility",
    path: "/inventoryVisibility",
    icon: <SiDialogflow />,
  },
  {
    title: "Network Map",
    path: "/networkMap",
    icon: <PiMapPinLineFill />,
  },
  {
    title: "Work Order Insights",
    path: "/workOrderInsights",
    icon: <FaClipboardList />,
  },
  {
    title: "Demanding Planing",
    path: "/demandingPlaning",
    icon: <BsClipboardDataFill />,
  },
  {
    title: "Supply Planing",
    path: "/supplyPlaning",
    icon: <VscChecklist />,
  },
  {
    title: "Sustainability",
    path: "/sustainability",
    icon: <SiLeaflet />,
  },
  {
    title: "Data Lake",
    path: "/dataLake",
    icon: <MdOutlineCyclone />,
  },
  {
    title: "N-Tier Visibility",
    path: "/nTierVisibility",
    icon: <GiSplitCross />,
  },
];

export default function Header({ child }) {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const [selectedIcon, setSelectedIcon] = React.useState(null);
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  const handleDrawerClose = () => {
    setOpen(false);
  };
  return (
    <Box sx={{ display: "flex", backgroundColor: "#E5E4E2", height: "100vh" }}>
      <CssBaseline />
      <AppBar position="fixed" open={open} sx={{ backgroundColor: "white" }}>
        <Toolbar>
          <IconButton
            color="black"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            sx={{
              marginRight: 5,
              ...(open && { display: "none" }),
            }}
          >
            <MenuIcon />
          </IconButton>
          <Box
            sx={{
              width: "100vw",
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <Typography variant="h6" noWrap component="div" color="grey">
              Originscale.io
            </Typography>
            <Box
              sx={{
                color: "black",
                display: "flex",
                gap: 3,
                alignItems: "center",
              }}
            >
              <ChatBubbleOutlineOutlinedIcon />
              <NotificationsNoneOutlinedIcon />
              <FormControl fullWidth>
                <NativeSelect
                  defaultValue={30}
                  inputProps={{
                    name: "age",
                    id: "uncontrolled-native",
                  }}
                >
                  <option value={10}>Ten</option>
                  <option value={20}>Twenty</option>
                  <option value={30}>Thirty</option>
                </NativeSelect>
              </FormControl>
              <Box
                sx={{
                  backgroundColor: "limegreen",
                  color: "white",
                  padding: "5px",
                  borderRadius: "8px",
                }}
              >
                AS
              </Box>
            </Box>
          </Box>
        </Toolbar>
      </AppBar>

      <Drawer variant="permanent" open={open}>
        <DrawerHeader sx={{ backgroundColor: "white" }}>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "rtl" ? (
              <ChevronRightIcon />
            ) : (
              <ChevronLeftIcon />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List
          sx={{
            display: "flex",
            justifyContent: "space-between",
            flexDirection: "column",
            height: "100vh",
          }}
        >
          <Box>
            {sidebarIcons.map((data, index) => (
              <Link key={index} to={data.path}>
                <ListItem disablePadding sx={{ display: "block" }}>
                  <ListItemButton
                    sx={{
                      minHeight: 48,
                      justifyContent: open ? "initial" : "center",
                      px: 2.5,
                      bgcolor:
                        selectedIcon === index ? "lightblue" : "transparent",
                      borderRadius: 3,
                      border:
                        selectedIcon === index ? "2px solid blue" : "none",
                      margin: 1,
                    }}
                    onClick={() => setSelectedIcon(index)}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 0,
                        mr: open ? 3 : "auto",
                        justifyContent: "center",
                        color: "black",
                      }}
                    >
                      {data.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={data.iconName}
                      sx={{ opacity: open ? 1 : 0 }}
                    />
                  </ListItemButton>
                </ListItem>
              </Link>
            ))}
          </Box>
          <ListItem disablePadding sx={{ display: "block" }}>
            <ListItemButton
              sx={{
                minHeight: 48,
                justifyContent: open ? "initial" : "center",
                px: 2.5,
              }}
            >
              <ListItemIcon
                sx={{
                  minWidth: 0,
                  mr: open ? 3 : "auto",
                  justifyContent: "center",
                  color: "black",
                }}
              >
                <SettingsOutlinedIcon />
              </ListItemIcon>
              <ListItemText primary="Settings" sx={{ opacity: open ? 1 : 0 }} />
            </ListItemButton>
          </ListItem>
        </List>
      </Drawer>
      <Box component="main" sx={{ flexGrow: 1, p: 3 }}>
        <DrawerHeader />
        {child}
      </Box>
    </Box>
  );
}
