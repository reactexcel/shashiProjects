import { createBrowserRouter } from "react-router-dom";
import App from "../App";
import Home from "../components/Home";
import Insights from "../pages/Insights";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { path: "", element: <Home /> },
      { path: "insights", element: <Insights /> },
    ],
  },
]);
