// import React from 'react'
// import Chart from './components/Chart';
// import Header from './components/Header';

// const data = {
//   labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "sep", "oct", "Nov", "Dec"],
//   datasets: [
//     {
//       label: "First dataset",
//       data: [33, 53, 85, 41, 44, 65, 20, 55, 77, 90, 60, 40],
//       fill: false,
//       backgroundColor: "blue",
//       borderColor: "blue"
//     },
//   ]
// };

// const options = {
//   responsive: true,
//   plugins: {
//     legend: {
//       position: "top",
//     },
//     title: {
//       display: true,
//       text: "",
//       fontSize: 20,
//     },
//   },
//   scales: {
//     x: {
//       title: {
//         display: true,
//         text: "Time",
//         color: "#000000",
//         font: {
//           size: 20,
//           weight: "bold",
//         },
//       },
//       ticks: {
//         maxRotation: 45,
//         minRotation: 45,
//         color: "#000000",
//         font: {
//           weight: "bold",
//         },
//         maxTicks: 12,
//       },
//     },
//     y: {
//       title: {
//         display: true,
//         text: "Value",
//         color: "#000000",
//         font: {
//           size: 20,
//           weight: "bold",
//         },
//       },
//     }
//   }
// };

// const App = () => {
//   return (
//     <div className="App">
//     <Header/>
//       {/* <h1>chart</h1>
//       <Chart data={data} options={options} /> */}
//     </div>
//   )
// }

// export default App
import React from 'react'
import Header from './components/Header'
import { Outlet } from 'react-router-dom'

const App = () => {
  return <Header child={<Outlet/>} />
}

export default App
