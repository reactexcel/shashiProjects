import React, { useEffect, useState } from "react";
import { dispatch } from "../../redux/store/store";
import { useFormik } from "formik";
import { optionsAdd, resetReducer } from "../../redux/reducers/optionsSlice";
import { TextField, CircularProgress } from "@mui/material";
import Button from "../button/Button";
import "../editpoll/EditPoll.css";
import "../addpoll/AddPoll.css";
import { optionSchema } from "../../utilities/utilities";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";
import CloseIcon from "@mui/icons-material/Close";

const AddOptionPoll = () => {
  const loading = useSelector((state) => state.optionsSlice.isLoading);
  const status = useSelector((state) => state.optionsSlice.isSuccess);
  const [error, setError] = useState(false);
  const navigate = useNavigate();
  const { addoptionId } = useParams();
  const location = useLocation();

  useEffect(() => {
    if (status) {
      dispatch(resetReducer());
      navigate("/adminpoll");
    }
  }, [status]);

  const formikData = useFormik({
    initialValues: {
      option: "",
    },
    onSubmit: (values) => {
      try {
        if (
          location.state.options.map((e) => e.option).includes(values.option)
        ) {
          setError(true);
        } else {
          dispatch(optionsAdd(values, addoptionId));
        }
      } catch (error) {}
    },
    validationSchema: optionSchema,
  });

  const handleHome = () => {
    navigate("/adminpoll");
  };

  const handleClose = () => {
    setError(false);
  };

  return (
    <div className="adminPollContainer editContainer">
      <div className="editBox">
        <form autoComplete="off" onSubmit={formikData.handleSubmit}>
          <div className="textfieldContainer">
            <p className="text">Title</p>
            <TextField
              className="textUpdate"
              type="text"
              value={location.state.title}
              disabled
            />
          </div>
          <div className="textfieldContainer">
            <p className="text">Add Option</p>
            <TextField
              className="textUpdate"
              type="text"
              name="option"
              id="option"
              value={formikData.values.option}
              onChange={formikData.handleChange}
            />
          </div>
          <div className="buttonsContainer">
            <div className="button">
              <Button
                value={
                  loading ? (
                    <CircularProgress size="1rem" color="inherit" />
                  ) : (
                    "Submit"
                  )
                }
                classname={"buttonStyle"}
                type={"submit"}
              />
            </div>
            <div className="button">
              <Button
                value={"Back To Home"}
                classname={"buttonStyle"}
                type={"button"}
                onclick={handleHome}
              />
            </div>
          </div>
          {error && (
            <div className="error">
              <p>Duplicate option is not allowed</p>
              <CloseIcon className="close" onClick={handleClose} />
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default AddOptionPoll;
