import Web3 from 'web3'

const web3ForRead = () => {
  const web3 = new Web3(process.env.REACT_APP_WEB3_NODE)
  return web3
}

export default web3ForRead
