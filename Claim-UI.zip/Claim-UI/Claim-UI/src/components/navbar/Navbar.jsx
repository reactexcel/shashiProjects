import React,{ useState} from 'react'
import './navbar.css'
import { RiMenu3Line, RiCloseLine } from 'react-icons/ri';
import logo from '../../assets/logo.png'
import { Link } from "react-router-dom";
import Wallet from '../Wallet'

const Menu = () => (
  null
 )

 const Navbar = (props) => {
  const [toggleMenu,setToggleMenu] = useState(false)

  return (
    <div className='navbar'>
      <div className="navbar-links">
        <div className="navbar-links_logo">
          <img src={logo} alt="logo" />
          <Link to="/">
            <h1>Fetch</h1>
          </Link>
        </div>
        <div className="navbar-links_container">
         <Menu />
        </div>
      </div>

      <Wallet props={props}/>

      <div className="navbar-menu">
        {toggleMenu ?
        <RiCloseLine  color="#fff" size={27} onClick={() => setToggleMenu(false)} />
        : <RiMenu3Line color="#fff" size={27} onClick={() => setToggleMenu(true)} />}
        {toggleMenu && (
          <div className="navbar-menu_container scale-up-center" >
            <div className="navbar-menu_container-links">
             <Menu />
            </div>
            <div className="navbar-menu_container-links-sign">

            </div>
            </div>
        )}
      </div>
    </div>
  )
}

export default Navbar
