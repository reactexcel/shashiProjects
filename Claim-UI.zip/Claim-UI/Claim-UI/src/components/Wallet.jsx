import React from 'react';
import getWeb3 from '../models/getWeb3'
import {
  NETID,
  NetIdMessage
} from '../config'
import Web3Context from '../context/Web3Context';

const connectWallet = async(setWeb3, setAccounts, setNetId) =>{
  await getWeb3().then(async (response) => {
    setWeb3(response)

    setNetId(await response.eth.net.getId())

    response.eth.getAccounts().then((result) => {
      setAccounts(result)
    });
  });
}

function Wallet(props) {
  const context = React.useContext(Web3Context)

  const web3 = context.web3
  const setWeb3 = context.setWeb3
  const setAccounts = context.setAccounts
  const netId = context.netId
  const setNetId = context.setNetId

  return (
    <div>
    {(web3)
      ?
      <>
      <p style={{ color:'white' }}>
      Account Connected
      </p>

      {
        netId && NETID !== netId
        ?
        (
          <p style={{"color":"red"}}>ERROR: {NetIdMessage}</p>
        )
        : null
      }
      </>
      :
      <div className="login-button">
       <button
        type='button'
        className='login-writeButton'
        onClick = {() => connectWallet(setWeb3, setAccounts, setNetId)}
        >
         Connect wallet
       </button>
      </div>
      }
    </div>
    );
}

export default Wallet
