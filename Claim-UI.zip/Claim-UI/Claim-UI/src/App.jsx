import React, { useState } from 'react';
import './App.css';
import {Navbar,Footer} from './components'
import {
  Home,
} from './pages'
import { Routes, Route } from "react-router-dom";
import Web3Context from './context/Web3Context';


function App() {
  const [web3, setWeb3] = useState(null)
  const [accounts, setAccounts] = useState(null)
  const [netId, setNetId] = useState(null)

  return (
    <div>
      <Web3Context.Provider value={{ web3, setWeb3, accounts, setAccounts, netId, setNetId }}>
      <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
          </Routes>
      <Footer />
      </Web3Context.Provider>
    </div>
  );
}

export default App;
