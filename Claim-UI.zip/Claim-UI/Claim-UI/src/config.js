export const API_ENDPOINT = "http://localhost:9123/"
export const Merkle = "0x701AF32fCfEE084E147dC5007a6DE3eCaFC8FD3b"
export const NETID = 97n
export const NetIdMessage = "Please connect to BNB testnet, and reload page"
export const USDTDecimals = 18
