import React, { useState, useEffect } from 'react';
import './home.css'
import Web3Context from '../../context/Web3Context';
import axios from 'axios'
import MerkleABI from '../../abi/MerkleABI'
import {
  USDTDecimals,
  Merkle,
  NETID,
  NetIdMessage,
  API_ENDPOINT
} from '../../config'

// helper for call contract
const withdraw = async (e, web3, accounts, root, amount) => {
  e.preventDefault()

  if(!web3)
    return alert("Please connect wallet")

  const proofData = await axios.get(API_ENDPOINT + "get-prof/" + root + "/" + accounts[0] + "/" + amount)
  const merkle = new web3.eth.Contract(MerkleABI, Merkle)
  const isClaimed = await merkle.methods.claimed(root, accounts[0]).call()

  if(isClaimed){
    return alert("Alredy withdrawed")
  }

  const proof = proofData.data.result
  merkle.methods.claim(
    proof,
    accounts[0],
    amount,
    root
  ).send({ from:accounts[0] })
}

// helper for load data
const loadData = async (accounts, setShowLoad, setWithdraws, setChecked) => {
  try{
    const rootsData = await axios.get(API_ENDPOINT + 'roots')
    const roots = rootsData.data.result
    const withdraws = []
    
    for(let i = 0; i < roots.length; i++){
      const detailsData = await axios.get(API_ENDPOINT + 'get-data-by-root/' + roots[i])
      const detailsArr = detailsData.data.result.data

      const result = detailsArr.find(item => item.address === accounts[0])

      if(result){
        result.root = roots[i]
        withdraws.push(result)
      }
    }
  
    setWithdraws(withdraws)
    setShowLoad(false)
    setChecked(true)

  }catch(e){
    alert("Cant load data")
    console.log('error', e)
  }
}


const Home = () => {
  const context = React.useContext(Web3Context)
  const web3 = context.web3
  const accounts = context.accounts
  const [showLoad, setShowLoad] = useState(false)
  const [withdraws, setWithdraws] = useState([])
  const [cheked, setChecked] = useState(false)
  
  // load data when wallet connected
  useEffect(async () => {
    // check if user connected
    if(web3 && accounts){
     // check net id
     const netId = Number(await web3.eth.net.getId())
     if(netId === Number(NETID)){
      // load data
      setShowLoad(true)
      await loadData(
        accounts, 
        setShowLoad, 
        setWithdraws,
        setChecked
        )
     }else {
      alert(NetIdMessage)
     }
    }
  }, [web3, accounts])


  return (
    <div className='create section__padding'>
      <div className="create-container">
        <form className='writeForm' autoComplete='off'>
        {
          !web3
          ?
          (
            <div className="formGroup">
              <label>Please connect wallet</label>
            </div>
          )
          :
          (
          <>
          {
          showLoad
          ?
          (
            <div className="formGroup">
              <label>Load data ...</label>
            </div>
          )
          : 
          (
            withdraws.length > 0
            ?
            (
              withdraws.map(i => {
                return(
                  <div key={i.root}>
                    <p> Amount: {i.amount / 10**USDTDecimals}</p>
                    <button
                      onClick={(e) => withdraw(e, web3, accounts, i.root, i.amount)}
                      className='writeButton'
                    >
                     Withdraw
                    </button>
                  </div>
                )
              })
            )
            :
            (
              <>
              {
                cheked
                ?
                (
                  <>Nothing to withdraw yet</>
                )
                : null
              }
              </>
            )
          )
          }
          </>
          )
        }
        </form>
      </div>
    </div>

  )
};

export default Home;
