import { Box, Card, Tab, Tabs, Typography } from "@mui/material";
import "./App.css";
import UploadDocsTable from "./UploadDocsTable";
import { useState } from "react";

function CustomTabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box padding={{ xs: 1, sm: 3 }}>
          <Box>{children}</Box>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

function App() {
  const [value, setValue] = useState(0);

  const data = [
    {
      id: 1,
      actionButtons: null,
      Part: "ABC123",
      Action: "Repair",
      ProblemDesc: "Broken component",
      Barcode: "1234567890",
      DateInstalled: "2024-04-28",
    },
    {
      id: 2,
      actionButtons: null,
      Part: "DEF456",
      Action: "Replacement",
      ProblemDesc: "Faulty sensor",
      Barcode: "0987654321",
      DateInstalled: "2024-03-15",
    },
    {
      id: 3,
      actionButtons: null,
      Part: "GHI789",
      Action: "Maintenance",
      ProblemDesc: "Routine check-up",
      Barcode: "1357924680",
      DateInstalled: "2024-01-10",
    },
  ];

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
        <Tabs
          value={value}
          onChange={handleChange}
          aria-label="basic tabs example"
        >
          <Tab label="Trending List" {...a11yProps(0)} />
          <Tab label="Ads Spots" {...a11yProps(1)} />
        </Tabs>
      </Box>
      <CustomTabPanel value={value} index={0}>
        <Card
          sx={{
            boxShadow: "rgba(0, 0, 0, 0.35) 0px 5px 15px",
            marginBottom: "20px",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              bgcolor: "#1976D2",
              color: "white",
              padding: "10px",
              marginBottom: "10px",
            }}
          >
            <Typography>Pool</Typography>
          </Box>
          <Box margin={3}>
            <Box sx={{ overflow: "auto" }}>
              <UploadDocsTable userData={data} />
            </Box>
          </Box>
        </Card>
      </CustomTabPanel>
      <CustomTabPanel value={value} index={1}>
        <p>hello</p>
      </CustomTabPanel>
    </Box>
  );
}

export default App;
