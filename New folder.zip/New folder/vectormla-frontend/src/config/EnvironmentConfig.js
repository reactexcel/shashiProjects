const dev = {
	API_ENDPOINT_URL:
		// 'http://vmla-lb-8a1424eb75dd7261.elb.us-east-1.amazonaws.com:8000/api/'
		'https://vmlanalytics.com/api/'
};

const prod = {
	API_ENDPOINT_URL: `https://${window.location.hostname?.replace(
		'www.',
		''
	)}/api/`
};

const test = {
	API_ENDPOINT_URL: `https://${window.location.hostname?.replace(
		'www.',
		''
	)}/api/`
};
const getEnv = () => {
	switch (process.env.NODE_ENV) {
		case 'development':
			return dev.API_ENDPOINT_URL;
		case 'production':
			return prod.API_ENDPOINT_URL;
		case 'test':
			return test.API_ENDPOINT_URL;
		default:
			break;
	}
};

export const API = getEnv();
