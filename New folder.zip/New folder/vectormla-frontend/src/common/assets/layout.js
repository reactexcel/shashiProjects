// dimensions

export const filter = 260;
export const header = 35;
export const upperHeader = 34;
export const lowerHeader = 150;

export const collapsedDrawerWidth = 32;
export const emptyAlphaCellWidth = 0;
export const aplphaCellWidth = 100;
export const aplphaCellHeight = 21;
export const numberCellWidth = 25;
export const cashflowHeader = 200;
export const numLeftPrefix = 1;
export const numTopPrefix = 4;

// color
export const primaryColor = '#194775';
export const blueColor = '#2888d1';
export const darkBlueColor = '#1367a8';

// theme
export const appContainer = {
	position: 'relative',
	width: `calc(100% - ${
		collapsedDrawerWidth + numberCellWidth + emptyAlphaCellWidth
	}px)`,
	minHeight: '100vh',
	marginLeft: collapsedDrawerWidth + numberCellWidth + emptyAlphaCellWidth,
	paddingBlock: aplphaCellHeight + numTopPrefix + 18,
	overflowY: 'clip'
};

export const appContentContainer = {
	width: '100%'
};

export const contentHeaderContainer = {
	cursor: 'pointer',
	display: 'flex',
	marginTop: 20,
	'& img': {
		marginLeft: 10
	}
};
export const contentHeader = {
	fontSize: 13,
	fontWeight: 'bold',
	fontFamily: 'Roboto',
	// color: '#313132',
	color: '#266696',
	borderBottom: '4px solid #266696!important',
	margin: 0,
	display: 'inline-block'
};
