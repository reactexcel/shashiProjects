import React from 'react';
import { makeStyles, Typography, FormControl, Select } from '@material-ui/core';
import { primaryColor } from '../../assets/layout';

const root = {
	width: '100%',
	'& label.Mui-focused': {
		color: primaryColor
	},
	'& .MuiOutlinedInput-root': {
		'&.Mui-focused fieldset': {
			borderColor: primaryColor
		}
	},
	'& .MuiInputLabel-outlined': {
		zIndex: 1,
		transform: 'translate(14px, 12px) scale(1)'
	},
	'& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
		transform: 'translate(14px, -6px) scale(0.75)',
		fontWeight: 600
	}
};

const useStyles = makeStyles((theme) => ({
	sidemenu__select__Field: {
		paddingTop: 20,
		color: primaryColor
	},
	sidemenu__select__Field_layr: {
		color: primaryColor
	},
	root: {
		...root
	},
	root_layr: {
		...root,
		backgroundColor: '#f7f8fa'
	},
	header_select_input: {
		color: 'grey',
		marginTop: 0
	},
	header_select: {
		height: 42,
		fontSize: '0.875rem',
		fontFamily: 'Roboto',
		fontWeight: 500,
		lineHeight: 1.57,
		borderRadius: 0
	}
}));

const MuiSelectField = ({
	label,
	input,
	children,
	defaultValue,
	value,
	view,
	native = true,
	disabled,
	className
}) => {
	const classes = useStyles();
	return (
		<div
			className={
				view
					? view === 'sbs'
						? classes.sidemenu__select__Field
						: classes.sidemenu__select__Field_layr
					: className
			}
		>
			{view === 'sbs' && (
				<Typography style={{ float: 'left', fontSize: '12px' }}>
					{label}
				</Typography>
			)}
			<FormControl
				required
				disabled={disabled}
				className={view === 'sbs' ? classes.root : classes.root_layr}
			>
				<Select
					required
					native={native}
					variant="outlined"
					value={value}
					labelWidth={0}
					{...input}
					className={classes.header_select}
				>
					{children}
				</Select>
			</FormControl>
		</div>
	);
};

export default MuiSelectField;
