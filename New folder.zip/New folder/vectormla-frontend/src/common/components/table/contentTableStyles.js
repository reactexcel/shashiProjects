import { makeStyles } from '@material-ui/core';
import { contentHeaderContainer, contentHeader } from '../../assets/layout';
const lightGray = '#f7f8fa';
const darkGray = '#D8DDE3';
const lightBlue = '#d6ecff';
const fontColor = '#334152';
const headerHoverColor = '#1D4261';

const tableCell = {
	fontSize: 11,
	paddingBlock: 1,
	paddingInline: 5,
	minWidth: 110,
	textAlign: 'right',
	border: '1px solid #D8DDE3',
	borderBottom: '0px',
	color: fontColor
};
export const useStyles = makeStyles({
	bodyCell: {
		...tableCell,
		borderLeft: '0px',
		'&:hover': {
			cursor: 'default',
			color: '#c97513',
			backgroundColor: '#d6ecff'
		}
	},
	table: {
		marginBottom: 10,
		borderSpacing: 0,
		fontFamily: 'Roboto',
		border: `1px solid ${darkGray}`,
		borderLeft: '0px',
		borderTop: '0px',
		borderBottom: 'none',
		borderCollapse: 'separate',
		'& tr:first-child': {
			'& :hover': {
				backgroundColor: `${headerHoverColor}!important`
			},
			'& td': {
				backgroundColor: '#266696!important',
				color: '#fff',
				'& :hover': {
					backgroundColor: `${headerHoverColor}!important`
				}
			}
		},
		'& tr:last-child': {
			borderBottom: 'none',
			'& td': {
				borderBottom: `1px solid ${darkGray}`
			}
		},
		'& tr:not(:first-child)': {
			'& td': {
				color: fontColor,
				cursor: 'default',
				'&:hover': {
					color: '#c97513',
					backgroundColor: lightBlue
				}
			},
			'& td:first-child': {
				borderLeft: `1px solid ${darkGray}`
			},
			'& td:not(:first-child)': {
				'&:hover': {
					// border: `1px solid ${darkBlue}`
				}
			}
		},
		'& tr': {
			'& td:first-child': {
				// position: 'fixed',
			}
		}
	},
	table__row_white: {
		height: 20,
		position: 'relative',
		backgroundColor: '#FFF'
	},
	table__row_lightGray: {
		height: 20,
		position: 'relative',
		backgroundColor: lightGray
	},
	contentHeaderContainer,
	contentHeader
});
