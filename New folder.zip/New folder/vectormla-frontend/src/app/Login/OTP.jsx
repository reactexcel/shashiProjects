import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import home from '../../common/assets/images/home-slider1.svg';
import desktop from '../../common/assets/images/desktop.svg';
import Header from '../../landing/header/Header';
import { loginMFA, retrieveUserInfo } from '../store/actions/auth.action';

const OTP = ({ history }) => {
	document.body.classList.add('full');

	const dispatch = useDispatch();
	const [MFA, setMFA] = useState(null);

	const submit = (e) => {
		e.preventDefault();

		dispatch(
			loginMFA({ otp: MFA }, history, () => {
				dispatch(
					retrieveUserInfo(() => {
						history.push({
							pathname: '/app/homepage'
						});
					})
				);
			})
		);
	};
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<div className="login">
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="sign_up">
				<div className="container cont">
					<div className="row cont_sign">
						<div className="col-md-6 col-lg-5 left">
							<div className="title_block">
								<h3>
									<span className="static">Multi-factor </span>
									<span className="static blue">Authentication</span>
									{/* <span className="ind">ML</span> */}
								</h3>
								<img src={desktop} alt="" />
							</div>

							{!JSON.parse(localStorage.getItem('userOTP'))?.qr_url && (
								<p className="info">Enter an MFA code to complete sign-in.</p>
							)}

							{JSON.parse(localStorage.getItem('userOTP'))?.qr_url && (
								<>
									<p className="info">
										This QR code is a one-time display triggered by your
										administrator for MFA validation. Scan it with your
										authenticator app, replace any existing accounts as needed,
										and enter the current OTP for validation.
									</p>
									<img
										style={{
											width: 'auto',
											maxHeight: '120px',
											objectFit: 'contain',
											marginBottom: '10px'
										}}
										src={JSON.parse(localStorage.getItem('userOTP'))?.qr_url}
										alt=""
									/>
								</>
							)}
							<form onSubmit={submit}>
								<div className="form_control">
									<label label="mfa">MFA Code:</label>
									<input
										onChange={(e) => setMFA(e.target.value)}
										type="text"
										name="mfa"
									/>
								</div>
								<button type="submit">{'submit'}</button>
							</form>
						</div>
						<div className="col-md-6 col-lg-7 right">
							<img src={home} className="img-fluid" alt="" />
							<div
								style={{
									width: 100,
									height: 100,
									marginLeft: 250,
									position: 'absolute'
								}}
								onClick={() =>
									history.push({
										pathname: '/adminpanel/login'
									})
								}
							/>
						</div>
					</div>
				</div>
				<div className="footer-access-text">
					<div className="container-fluid access_text">
						<div className="row">
							<div className="col">
								<p>
									Access the Vector <span className="ind">ML</span> Platform
									wherever you are. Vector <span className="ind">ML</span> keeps
									you connected from virtually anywhere, from any device
								</p>
							</div>
						</div>
					</div>
					<div className="container light_copyright">
						<div className="row">
							<div className="col">
								<h6>
									Copyright 2021 Vector <span className="ind">ML</span>Analytics
									Inc All rights reserved.
								</h6>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default withRouter(OTP);
