export const notationData = {
	headers: [
		'Daily Settlement Factor',
		'Accrued Interest per $100',
		'Remaining Principal Balance',
		'Monthly Coupon Rate',
		'Convexity',
		'Coupon Rate',
		'Period Cash Flow',
		'Accrued Days',
		'Modified Duration',
		'Pool Factor',
		'Full Price of MBS per $100',
		'Interest Payment Cash Flow',
		'Liquidation Rate',
		'Liquidation Cash Flow in Month k',
		'MBS Term to Maturity',
		'Scheduled Monthly MBS Payment',
		'Market Price per 100',
		'Monthly Partial Prepayment Rate',
		'Partial Prepayment Rate',
		'Partial Prepayment Cash Flow in Month k',
		'Monthly Liquidation Rate',
		'Monthly WAC Rate',
		'Weighted Average Remaining Amortization',
		'Scheduled Principal Cash Flow',
		'Scheduled Remaining Principal',
		'Days from Settle to WAMD + 14',
		'Tranche Amount at k=0 of tranche maturing i months before maturity, M',
		'Constant Monthly Unscheduled Principal Payment Rate',
		'Unscheduled Principal Cash Flow',
		'Unscheduled Principal Payment Rate',
		'Weighted Average Mortgage Coupon',
		'Weighted Average Maturity',
		'Liquidation Fraction',
		'Monthly Yield',
		'Bond Equivalent Yield',
		'Money Market Yield'
	],
	rows: [
		[
			'a',
			'AI',
			'Bk; B0=1, BM=0',
			'c',
			'CX',
			'C',
			'CFk',
			'd',
			'DMod',
			'F; 0 <=F <=1',
			'FP',
			'Ik',
			'LQR (annual percentage)',
			'lqrk',
			'M (months)',
			'MPk',
			'P',
			'p',
			'PPR (annual percentage)',
			'pprk',
			'q',
			'r',
			'RAMk (months)',
			'Sk',
			'SRPk',
			't',
			'TRM-i',
			'u',
			'Uk',
			'UPP (annual percentage)',
			'WAC (semi-annual percentage)',
			'WAMD (calendar date)',
			'x (decimal)',
			'y',
			'Ys',
			'Ymmkt'
		]
	]
};
export const annualizingFormula = [
	{
		header: 'Old Annualizing Formula',
		details: [
			{
				text: 'This appendix shows how unusually large annualized prepayment rates could be obtained under the old formulas. For simplicity, we will only consider total prepayments. Let u be the constant monthly prepayment rate. Under the old standard, u is annualized using the formula:\n\n(1+u)12-1\nThis is an appropriate annualizing formula in the situation where the principal grows over time, as is the case with compound interest. However, the formula is not appropriate for MBS prepayment, a situation where principal decays over time. For example, if an MBS experiences total monthly prepayments at rate u, the balance remaining after one month is, ignoring scheduled principal reductions,\n\nBk+1=Bk(1-u)\n\nSimilarly, the balance after two months is:\n\nBk+2=Bk(1-u)· (1-u)\nIt follows that the balance after one year is:\n\nBk+12=Bk(1-u)12\nThe annualized prepayment rate, UPP, is therefore calculated thus:\n\n(1-UPP)=(1-u)12\nUPP=1-(1-u)12\nThe following table compares the results of the old and new annualizing formulas for different values of u, the total monthly prepayment rate:',
				tableData: {
					headers: ['u', 'Old UPP', 'New UPP'],
					rows: [
						['1.84%', '24.49%', '20.0%'],
						['4.17%%', '63.23%', '40.0%'],
						['7.35%', '134.26%', '60.0%'],
						['12.55%', '313.25%', '80.0%']
					]
				}
			},
			{
				text: 'As noted previously, the new method of annualizing better reflects the actual principal paid down, but otherwise does not affect the MBS pricing calculations.'
			}
		]
	}
];
export const pprLqr = [
	{
		header: 'Appropriateness pf PPR and LQR',
		details: [
			{
				text: 'The standard formulas use separate annualized rates of partial prepayment and liquidation, PPR and LQR. Though this approach works in practice, it involves a minor technical inconsistency.\n\nLet p be the constant monthly partial prepayment rate, and q the constant monthly liquidation rate. For simplicity, we ignore scheduled principal payments. The remaining principal balance after one month is:\n\nBk+1=Bk(1-q)·(1-p)\nand after two months is:\n\nBk+2=Bk(1-q)·(1-p) ·(1-q)·(1-p)\nSimilarly, the remaining balance after one year is:\n\nBk+12=Bk(1-q)12 ·(1-p)12\nWe can thus write the total annual prepayment rate, UPP:\n\n(1-UPP)=(1-q)12 ·(1-p)12\nUPP=1-(1-q)12 ·(1-p)12\nStrictly speaking, there is no way to separate the expression (1-p)12 from the expression (1-q)12 and thereby obtain separate expressions for the annual rates PPR and LQR. The two expressions are inter-dependent (for this reason, the expression UPP is provided in the standard formulas).\n\nHowever, because partial prepayments, p, tend to be low and relatively invariant, the standard formulas\n\nPPR=1-(1-p)12\nLQR=1-(1-q)12\nreasonably approximate the reductions in principal that result when constant rates p and q are applied in the standard formulas for one year. Thus, the Canadian investment dealers have agreed that the expressions PPR and LQR are reasonable in practice.'
			}
		]
	}
];
export const penaltyInterest = [
	{
		header: 'Penalty Interest Payments in PCBOND',

		details: [
			{
				text: "Penalty interest payments, though not included in the standard formulas, can affect the price and yield of a mortgage-backed security. PCBOND Manager Software includes the following calculation for the penalty interest cash flow:\n\nPIPk=SRPk · q · r · pipm\nwhere\n\nPIPk=penalty interest cash flow in month k\nSRPk=scheduled remaining principal\nq=constant monthly liquidation rate\nr=weighted average mortgage rate expressed on a monthly basis\npipm=number of month's interest payments charged as a penalty.\n\nNot all mortgage liquidations are subject to penalty. For example, penalties may be waived if the borrower refinances with the same institution. The number of penalty months, pipm, must be adjusted to reflect this. If 50% of liquidations are required to pay a three month penalty, we might use a value of 1.5 for pipm. The term pipm is assumed to be constant for the life of the security.\n\nTo incorporate penalties into mortgage-backed security pricing, the penalty interest payment, PIPk, is added to the standard cash flow formula shown in equation [10]:\n\nCFk=(1-c)Bk-1 - Bk + PIPk"
			}
		]
	}
];
export const terminology = [
	{
		header: 'Calculating MBS Cash Flows',
		details: [
			{
				text: 'Part of the Guide to Terminology and Calculations for Mortgage-Backed Securities.\n\nIn this section and the next, we present the standard cash flow and pricing calculations for a mortgage-backed security consisting of a single tranche. In the final section, we show how this single-tranche approach is easily generalized for a multi-tranche security.'
			}
		]
	},
	{
		header: 'MONTHLY MBS COUPON ANAD WAC',
		details: [
			{
				text: 'The typical Canadian balloon mortgage has fixed-level payments made monthly and a mortgage rate compounded semi-annually. In order to calculate MBS cash flows, we convert the annual MBS coupon and the annual weighted average mortgage rate to monthly rates:',
				img: '1'
			}
		]
	},
	{
		header: 'MONTHLY PAYMENT',
		details: [
			{
				text: "In the calculations that follow, we wish to price the mortgage-backed security at some time k=0. This can be at issue, or at some later date in the security's life. The first step is to calculate the scheduled monthly payment at the pricing date k=0. All calculations are per dollar of remaining principal balance at the time of pricing, Bo.",
				img: '2'
			},
			{
				text: 'where\n\nRAM0=remaining average amortization at time of price r=weighted average mortgage coupon, expressed on a monthly basis.\n\nWhen calculating MP1, it is assumed that all mortgages in the single-tranche pool have the same mortgage rate and amortization schedule.\n\nWhen a mortgage in the pool liquidates, there is one less mortgage contributing to the monthly payment on the mortgage-backed security. Thus, the monthly payment must be reduced to account for liquidations. If q denotes the constant fraction of mortgages that liquidate each month, then 1-q denotes the fraction remaining. Thus, the monthly payment after k months is:',
				img: '3'
			},

			{
				text: 'This could also be calculated recursively as:',
				img: '4'
			},

			{
				text: 'As long as there are a reasonable number of mortgages remaining in the pool, liquidations do not substantially affect the term or amortization of the security. This is because the liquidation of one mortgage has no affect on the cash flows of the mortgages that remain in the pool. The situation is reversed in the case of partial prepayments, which leave the monthly payment unchanged, but reduce the term and amortization of the mortgage.'
			}
		]
	},
	{
		header: 'SCHEDULED REMAINING PRINCIPAL BALANCE',
		details: [
			{
				text: "The scheduled remaining principal, denoted SRPk, is the previous month's balance less scheduled principal payments. In the standard formulas, it is calculated as follows. Last month's balance is grossed-up by r, the monthly weighted average mortgage rate. The monthly payment of scheduled interest and principal, MPk, is then subtracted from this grossed-up figure to obtain SRPk:",
				img: '5'
			},
			{
				text: 'where\n\nMPk=MPk-1·(1-q)\nr=monthly weighted average mortgage rate\nB0=1\nBM=0'
			}
		]
	},
	{
		header: 'REMAINING PRINCIPAL BALANCE',
		details: [
			{
				text: 'The remaining principal balance for month k can be calculated by applying the prepayment rates, q and p, to the scheduled remaining principal, SRPk:',
				img: '6'
			}
		]
	},
	{
		header: 'MONTHLY CASH FLOW',
		details: [
			{
				text: 'The monthly cash flow received by the MBS holder, CFk, is calculated as follows:',
				img: '7'
			},
			{
				text: 'The valuation standards do not consider penalty interest payments. To incorporate penalties into MBS pricing, a term denoting the monthly penalty interest payment, PIPkwould be added to the right hand side of the above equation. This calculation, included in the PCBOND Manager Software, is shown in Appendix 4. '
			}
		]
	}
];
export const prepaymentRate = [
	{
		header: 'MONTHLY PREPAYMENT AND LIQUIDATION RATES',
		details: [
			{
				text: 'The standard MBS valuation model uses a constant monthly partial prepayment rate, p, and a constant monthly liquidation rate, q, to generate the amortization schedule for a hypothetical mortgage used to represent the underlying mortgage pool. Typically, p and q will be obtained from prepayment forecasts. In the example that follows, we adopt a naive forecasting strategy to illustrate how p and q can be calculated from historical data.\n\nTable 1 shows 12 months of scheduled and unscheduled cash flows for a hypothetical NHA mortgage-backed security. Each month, a liquidation rate, qk, can be calculated using the following formula:',
				img: '8'
			},
			{
				text: 'where\n\nlqrk=liquidation cashflow in month k\nSRPK=remaining principal after scheduled principal payment\n\nAfter removing liquidated mortgages from the pool, a partial prepayment rate, pk, can be calculated on those mortgages that remain:',
				img: '9'
			},
			{
				text: 'where\n\npprk=prepayment cashflow in month k\n\nThe historical monthly rates of liquidation and partial prepayment are displayed in the columns on the right of Table 1 (the total monthly prepayment rate, uk, displayed in the rightmost column, is discussed in a later section). For the purposes of this example, it is assumed that the constants p and q equal their historical averages over this 12 month period. Thus,',
				img: '10',
				tableData: {
					headers: [
						'period',
						'Principal Balance Bk',
						'Scheduled Principal Sk',
						'Interest Ik',
						'Scheduled Remaining Principal SRPk',
						'Partial Cash Flow pprk',
						'lqrk',
						'pk %',
						'qk %',
						'uk %'
					],
					rows: [
						[
							'1',
							'35,023,627',
							'53,089',
							'35,023,627',
							'34,970,538',
							'83,625',
							'882,045',
							'0.25',
							'2.52',
							'2.76'
						],
						[
							'2',
							'34,004,868',
							'54,703',
							'271,262',
							'33,950,165',
							'35,023,627',
							'61,443',
							'752,714',
							'0.19%',
							'2.22%',
							'2.40%'
						],
						[
							'3',
							'33,136,008',
							'49,842',
							'264,342',
							'33,086,166',
							'35,877',
							'1,026,762',
							'0.11%',
							'3.10%',
							'3.21%'
						],
						[
							'4',
							'32,023,527',
							'47,189',
							'255,481',
							'31,976,338',
							'14,335',
							'1,215,956',
							'0.05%',
							'3.80%',
							'3.85%'
						],
						[
							'5',
							'30,746,047',
							'46,162',
							'245,306',
							'30,699,885',
							'12,703',
							'1,680,656',
							'0.04%',
							'5.47%',
							'5.52%'
						],
						[
							'6',
							'29,006,526',
							'44,812',
							'231,452',
							'28,961,714',
							'15,624',
							'1,249,260',
							'0.06%',
							'4.31%',
							'4.37%'
						],
						[
							'7',
							'27,696,830',
							'43,582',
							'221,020',
							'27,653,248',
							'24,460',
							'1,096,247',
							'0.09%',
							'3.96%',
							'4.05%'
						],
						[
							'8',
							'26,532,541',
							'42,483',
							'211,747',
							'26,490,058',
							'21,644',
							'347,319',
							'0.08%',
							'1.31%',
							'1.39%'
						],
						[
							'9',
							'26,121,094',
							'42,706',
							'208,470',
							'26,078,389',
							'21,844',
							'199,955',
							'0.08%',
							'0.77%',
							'0.85%'
						],
						[
							'10',
							'25,856,590',
							'43,159',
							'206,363',
							'25,813,430',
							'24,388',
							'59,834',
							'0.09%',
							'0.23%',
							'0.33%'
						],
						[
							'11',
							'25,729,209',
							'42,904',
							'205,349',
							'25,686,304',
							'84,292',
							'338,739',
							'0.33%',
							'1.32%',
							'1.65%'
						],
						[
							'12',
							'25,263,274',
							'41,640',
							'201,638',
							'25,221,634',
							'86,503',
							'210,743',
							'0.35%',
							'0.84%',
							'1.18%'
						],
						['13', '24,924,387', '', '', '', '', '', '', '', ''],
						['Totals', '', '', '', '', '', '486,738', '9,060,230', '', '', ''],
						['Averages', '', '', '', '', '', '', '0.14', '2.49', '2.63']
					]
				}
			}
		]
	},
	{
		header: 'ANNUALIZED PREPAYMENT AND LIQUIDATION RATES',
		details: [
			{
				text: 'The terms CPR and SMM have been replaced by the terms Partial Prepayment Rate, denoted PPR, and Liquidation Rate, denoted LQR. Both are expressed as lifetime constants on an annualized basis. They are calculated from monthly constants as follows:',
				img: '11'
			},
			{
				text: 'where\n\nPPR=annualized constant partial prepayment rate\nLQR=annualized constant liquidation rate\np=constant lifetime partial prepayment rate expressed on a monthly basis\nq=constant lifetime liquidation rate expressed on a monthly basis\n\nThis method of annualizing the monthly prepayment rates produces numbers that reflect the actual prepayment experience over the year. Continuing the example from the previous section, we obtain the following annual figures:',
				img: '12'
			},

			{
				text: 'The above figures are very similar to the actual percentage reductions in principal due to partial prepayments and liquidations. For example, the actual percentage reduction due to liquidations can be calculated as follows:',
				img: '13'
			},

			{
				text: 'This is close to the LQR value of 26.10%.\n\nIn contrast to the above, the old method of annualizing p and q produces annual prepayment figures that are less representative of actual experience. For example,',
				img: '14'
			},
			{
				text: 'For small values, the difference between the old and new formulas is not significant. However, the discrepancy increases dramatically as the level of p or q increases.\n\nIt should be noted that the discrepancy between the old and new annualizing formulas does not affect the validity of prices calculated under the old formulas. The true inputs to the MBS amortization schedule are the monthly values p and q. The purpose of the new formulas for PPR and LQR is merely to generate annualized prepayment rates that more accurately reflect the principal which would be prepaid if constant monthly numbers p and q were applied for a year.\n\nAppendix 3 provides further discussion of the annualized figures PPR and LQR.'
			}
		]
	}
];
export const misFormula = [
	{
		header: 'Miscellaneous Formulas',
		details: [
			{
				text: 'When the time from the settlement date to WAMD is one year or less, mortgage-backed securities are quoted according to Canadian money market convention (i.e. simple interest on an actual/365 day basis). A semi-annual bond yield is converted to a simple interest yield using the formula:',
				img: '15'
			},
			{
				text: 'where t=WAMD - Settle + 14 days\n\nNote that 14 days is added to the time between WAMD and the settlement date to account for the fact that payments are made on the 15th of each month, 14 days after the record date.\n\nBy re-arranging the above formula, a money market rate can be converted to a bond-equivalent yield:',
				img: '16'
			}
		]
	},
	{
		header: 'SCHEDULED INTEREST',
		details: [{ text: 'Ik=c·Bk-1 [30]' }]
	},
	{
		header: 'SCHEDULED PRINCIPLE',
		details: [{ text: 'Sk=MPk-r·Bk-1 [31]' }]
	}
];
export const priceCalculation = [
	{
		header: 'FULL PRICE PER $100',
		details: [
			{
				text: 'The full price of the MBS, assuming a single tranche that repays at time M, is calculated:',
				img: '17'
			},
			{
				text: 'where',
				tableData: {
					headers: ['a=', ' '],
					rows: [
						[
							'Number of days from settlement to the 15th of next month',
							'Number of days in settlement month'
						]
					]
				}
			}
		]
	},
	{
		header: 'ACCURATE INTEREST PER $100',
		details: [
			{
				text: 'Accrued interest per $100 is calculated:',
				img: '18'
			},
			{
				text: 'where',
				tableData: {
					headers: ['d=', ' '],
					rows: [
						[
							'Number of days from 1st of settlement month to settlement date',
							'Number of days in settlement month'
						]
					]
				}
			},
			{
				text: 'c=monthly MBS coupon'
			}
		]
	},
	{
		header: 'MARKET PER $100',
		details: [
			{
				text: 'The market price is simply the full MBS price less accrued interest:\n\nP=FP - AI [13]'
			}
		]
	}
];
export const riskMeasures = [
	{
		header: 'DURATION',
		details: [
			{
				text: 'Modified duration, DMod, for a single-tranche MBS maturing at M can be calculated using the formula:',
				img: '19'
			}
		]
	},
	{
		header: 'CONVEXITY',
		details: [
			{
				text: 'Similarly, convexity, Cx, can be calculated using the formula:',
				img: '20'
			}
		]
	},
	{
		header: 'VAL01',
		details: [
			{
				text: 'VAL01, the dollar value of a 100 basis point change in yield, can be calculated as follows:',
				img: '21'
			},
			{
				text: 'where\n\nFP(Ys)=price plus accrued calculated at a semi-annual yield of Ys;\n\nDuration and convexity can also be calculated using shocks to the yield curve:;',
				img: '22'
			},
			{
				img: '23'
			},
			{
				text: 'Note that, in the numerators of equations 20 through 22, accrued interest cancels out; thus, market prices could be used. However, in the denominators of 21 and 22, the full price including accrued interest must be used.'
			}
		]
	}
];
export const totalPayments = [
	{
		header: 'TOTAL PAYMENTS',
		details: [
			{
				text: 'Standard practice will generally be to quote prepayment in terms of the separate annualized rates PPR and LQR. However, at times it is also useful to quote prepayment in terms of an annualized total prepayment rate, denoted UPP, and the fraction of prepayments that are due to liquidations, denoted x.\n\nAs can be seen from equation [6], total monthly prepayments, u, are related to partial prepayments p and liquidations q in the following manner:\n\n(1-u)=(1-q)·(1-p)\n\nor\n\nu=1-(1-q)·(1-p) [14]\n\nThe fraction of total prepayments that is due to liquidations is calculated as:',
				img: '24'
			},
			{
				text: 'Given a constant rate, u, the annualized total unscheduled principal prepayment rate (UPP) is calculated:\n\nUPP=[1-(1-u)12]·100 [16]\n\nMonthly rates, uk, can be calculated from historical cash flows:',
				img: '25'
			},
			{
				text: 'Appendix 3 provides additional discussion on the relationship between UPP and the separate rates PPR and LQR.'
			}
		]
	}
];
export const treatingTranche = [
	{
		header: 'TREATING EACH TRANCHE AS A SEPARATE SECURITY',
		details: [
			{
				text: 'The preceding formulas can be used to price a multi-tranche MBS by treating each tranche as though it were a separate security. For example, the monthly payment on a tranche maturing five months before maturity, M, can be calculated using the formula:',
				img: '26'
			},
			{
				text: 'Following this approach through all the cash flow equations allows us to calculate a price for the tranche.\n\nOnce we obtain prices for each tranche, we calculate the MBS price as an average of the individual tranche prices weighted by the dollar amount of the tranches:',
				img: '27'
			},
			{
				text: 'where\n\nTRM-i=remaining principal balance at k=0 of the trache maturing i months before maturity, M.\n\nVAL01 is also calculated as an average of the tranche VAL01s weighted by the dollar amount of the tranches.\n\nThe risk measures Duration and Convexity are calculated as above. However, instead of weighting by outstanding face value TRM-i, we weight by market value:',
				img: '28'
			},
			{
				text: 'Similarly, convexity is calculated:',
				img: '29'
			}
		]
	},
	{
		header: 'TREATING EACH TRANCHE AS A SEPARATE SECURITY',
		details: [
			{
				text: 'The calculation of the weighted average maturity date (WAMD) of an MBS pool proceeds as follows. First, we calculate the weighted average number of days between the maturity date of the first tranche to mature, and the maturities of the remaining tranches. For a six tranche security, the calculation is as follows:',
				img: '30'
			},
			{
				text: 'where\n\nM-i=maturity date of the tranche maturing i months before M\ndM-i=number of days between the maturity date of the first tranche and M-i\nTRM-i=remaining principal amount of tranche M-i\n\nThe weighted average maturity date is calculated by rounding ',
				img: '31'
			},
			{
				text: 'to the nearest integer, then adding this weighted average number of days to the first tranche date:\n\nWAMD=Maturity Date of First Tranche + ',
				img: '31'
			}
		]
	}
];
