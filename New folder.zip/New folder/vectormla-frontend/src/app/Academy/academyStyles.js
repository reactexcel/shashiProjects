import { makeStyles } from '@material-ui/core';
import {
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
} from '../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	contentHeaderContainer,
	contentHeader,
	appContainer,
	appContentContainer
}));
