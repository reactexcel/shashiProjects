import React from 'react';
import { useSelector } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import { useStyles } from './academyStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import ContentContainer from '../components/contentContainer/ContentContainer';
import {
	terminology,
	notationData,
	annualizingFormula,
	pprLqr,
	penaltyInterest,
	prepaymentRate,
	misFormula,
	priceCalculation,
	riskMeasures,
	totalPayments,
	treatingTranche
} from './academyData';
import pdf from './nha_mbs_indemnity_calculation_methodology.pdf';

const Academy = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const classes = useStyles();

	const { ref: homeRef, height: homeHeight } = useComponentSize();

	if (!user?.allowed_pages?.includes(5)) return <div></div>;

	return (
		<div ref={homeRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={homeHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<ContentContainer
							header={'NHA MBS Indemnity Calculation Methodology'}
							content={[
								{
									hoveredText: 'Download'
								}
							]}
							onClick={() => {
								window.open(pdf);
							}}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Notation'}
							content={[
								{
									header: 'Notation',
									details: [
										{
											tableData: notationData
										}
									]
								}
							]}
							tableLeftAlign
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Old Annualizing Formula'}
							content={annualizingFormula}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Appropriateness of PPR and LQR'}
							content={pprLqr}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Penalty Interest Payments in PCBOND'}
							content={penaltyInterest}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={
								'Terminology and Calculations for Mortgage-Backed Securities'
							}
							content={terminology}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Calculating Prepayment Rates'}
							content={prepaymentRate}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Miscellaneous Formulas'}
							content={misFormula}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Price Calculations'}
							content={priceCalculation}
							collapsed={collapsed}
							tableLeftAlign
						/>
						<ContentContainer
							header={'Risk Measures'}
							content={riskMeasures}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Total Prepayment (UPP)'}
							content={totalPayments}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Tranche Payments'}
							content={treatingTranche}
							collapsed={collapsed}
						/>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default Academy;
