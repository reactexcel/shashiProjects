import { API } from '../../config/EnvironmentConfig';
import axios from 'axios';
import { toast } from 'react-toastify';

export const getUsers = (callback) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}user/retrieve`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data));
};

export const getTwoFactorList = (callback) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}multifactorauth/qrcode/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res?.data?.results));
};

export const deleteUser = (id, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.delete(`${API}user/delete?id=${id}`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};
export const resetUserPass = (id) => {
	const session = localStorage.getItem('user');
	return axios
		.put(`${API}user/resetpass?id=${id}`, null, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then(() => {
			// Toastify
			toast.success('Password reset successfuly', {
				autoClose: 5000
			});
		})
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0], {
					autoClose: 5000
				});
			}
		});
};

export const mfaToggle = (id, callback) => {
	const session = localStorage.getItem('user');
	return axios
		.post(
			`${API}multifactorauth/qrcode/${id}/mfa_toggle/`,
			{},
			{
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => {
			// Toastify
			callback();
			toast.success(res.data, {
				autoClose: 5000
			});
		})
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0], {
					autoClose: 5000
				});
			}
		});
};

export const createUser = (userData, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.post(`${API}user/create`, userData, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};
export const updateUserData = (userData, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.put(`${API}user/update?id=${userData.id}`, userData, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};
