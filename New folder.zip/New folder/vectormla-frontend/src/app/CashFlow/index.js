// FPNA 3.1.2
import CashFlow from './CashFlow';

export default CashFlow;
