import React, { useState } from 'react';
import { compose } from 'recompose';
import { connect, Field, reduxForm } from 'react-redux';
import { Button, Grid, Typography } from '@material-ui/core';
import InfoIcon from '@material-ui/icons/Info';
import { useStyles } from './sideMenuStyles';
import { cashFlowSelect, selectGroup } from '../../helpers/Fields';
import MuiTextField from '../../common/Select/Text';
import { getTables, tableRequest } from '../../state/actions';

const SideMenuA = ({
	view,
	formvalues,
	formData,
	scenarioMount,
	setScenarioMount
}) => {
	const classes = useStyles();
	const [menus, setMenus] = useState({
		assets: true,
		structure: true,
		liability: true,
		layr: true
	});
	// control the gross_cummulative_loss ( text or select ) based on ml_default_model value
	// if ml_default_model is 0 ( Manual Input ) then its text input, else select input
	const [grossIsText, setGrossIsText] = useState(
		formvalues.ml_default_model === 0
	);

	const handleMenuChange = (menu) => {
		setMenus({
			...menus,
			[`${menu}`]: !menus[`${menu}`]
		});
	};

	// modify the field values
	// ml_default_model and gross_cummulative_loss
	if (formData?.select?.values?.ml_default_model == 1) {
		formData.select.values.gross_cummulative_loss = 0.01;
		grossIsText && setGrossIsText(false);
	} else if (formData?.select?.values?.ml_default_model == 2) {
		formData.select.values.gross_cummulative_loss = 0.02;
		grossIsText && setGrossIsText(false);
	} else {
		// make grossIsText true only if its false to prevent infinite loop
		!grossIsText && setGrossIsText(true);
	}
	// LGD
	if (formData?.select?.values?.recovery_rate) {
		formData.select.values.LGD = 1 - formData.select.values.recovery_rate;
	}

	//change values of selects when senarios change
	scenarioMount &&
		formvalues &&
		Object.keys(formvalues).map(
			(f) => (formData.select.values[f] = formvalues[f])
		);

	// some fields are disabled in some conditions
	const isDisabled = (fieldData) => {
		if (
			(fieldData.name === 'gross_cummulative_loss') &
			(formData?.select?.values?.ml_default_model != 0)
		)
			return true;
		if (fieldData.name === 'advance_rate_sub') return true;
		if (fieldData.name === 'LGD') return true;
		return false;
	};

	const renderSelectField = (fieldData, type) => {
		switch (type) {
			case 'text':
				return (
					<Field
						name={fieldData.name}
						label={fieldData.label}
						required
						disabled={isDisabled(fieldData)}
						view={view}
						component={MuiTextField}
					/>
				);
			default:
				return (
					<Field
						name={fieldData.name}
						label={fieldData.label}
						required
						value={
							fieldData.name === 'gross_cummulative_loss'
								? 0.01
								: formvalues[fieldData.name]
						}
						disabled={isDisabled(fieldData)}
						view={view}
						onchange={() => setScenarioMount(false)}
						onFocus={() => {
							setScenarioMount(false);
						}}
						component={fieldData.component}
					>
						{fieldData.items &&
							fieldData.items.map((item, index) => (
								<option key={index} value={item.value}>
									{item.label}
								</option>
							))}
					</Field>
				);
		}
	};
	const renderlayrFields = () => (
		<Grid
			container
			style={{ padding: '35px 0px' }}
			wrap="wrap"
			justify="center"
		>
			{menus.layr ? (
				<>
					<Grid item xs={12} md={7} lg={5}>
						<Button
							onClick={() => handleMenuChange('assets')}
							fullWidth
							className={classes.parametrHead}
						>
							<Typography variant="subtitle1">Assest</Typography>
							{/* <div className={classes.parametrHead_arrow} >
                {!menus.assets ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
              </div> */}
						</Button>

						{/* {renderCheckBox('assets')} */}
						<div className={classes.mbt50} />

						{menus.assets && (
							<Grid container justify="space-between">
								<Grid item xs={12} md={6} lg={6}>
									<Grid container>
										{/* <Typography variant="subtitle1" align="left" style={{ width: '100%', fontWeight: 'bold' }}>Interest Rate</Typography> */}
										{cashFlowSelect.assetsFeilds
											.filter((item) => selectGroup.intrest.includes(item.name))
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid className={classes.selectInput} item xs={6}>
														{renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
									</Grid>
								</Grid>
								<Grid item md={1} />
								<Grid item xs={12} md={5} lg={5}>
									<Grid
										container
										className={classes.inputCollection}
										style={{ marginBottom: 15 }}
									>
										<Typography
											variant="subtitle1"
											align="left"
											style={{ marginBottom: 15 }}
											className={classes.TypoHead}
										>
											Credit Risk
										</Typography>
										{cashFlowSelect.assetsFeilds
											.filter((item) =>
												selectGroup.defaultInput.includes(item.name)
											)
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid className={classes.selectInput} item xs={6}>
														{fieldData.name === 'gross_cummulative_loss' &&
														grossIsText
															? renderSelectField(fieldData, 'text')
															: renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
										{cashFlowSelect.assetsFeilds
											.filter((item) =>
												selectGroup.recovery.includes(item.name)
											)
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid className={classes.selectInput} item xs={6}>
														{renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
									</Grid>

									<Grid container className={classes.inputCollection}>
										<Typography
											variant="subtitle1"
											align="left"
											className={classes.TypoHead}
										>
											Prepayment Risk
										</Typography>
										{cashFlowSelect.assetsFeilds
											.filter((item) =>
												selectGroup.prepayment.includes(item.name)
											)
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid className={classes.selectInput} item xs={6}>
														{renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
									</Grid>
								</Grid>
							</Grid>
						)}
					</Grid>

					<Grid item md={2} lg={1} />

					<Grid item xs={6} md={3} lg={3}>
						<Button
							onClick={() => handleMenuChange('liability')}
							fullWidth
							className={classes.parametrHead}
						>
							<Typography variant="subtitle1">Liability</Typography>
							{/* <div className={classes.parametrHead_arrow}>
                {!menus.liability ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
              </div> */}
						</Button>

						<div className={classes.mbt50} />

						{menus.liability && (
							<Grid container className={classes.inputCollection}>
								<Grid item xs={3}></Grid>
								<Grid item xs={4}>
									<Typography
										align="left"
										variant="subtitle1"
										className={classes.TypoHead}
									>
										Senior Debt
									</Typography>
								</Grid>
								<Grid item xs={1}></Grid>
								<Grid item xs={4}>
									<Typography
										align="left"
										variant="subtitle1"
										className={classes.TypoHead}
									>
										Sub Debt
									</Typography>
								</Grid>
								{cashFlowSelect.assetsFeilds2
									.filter((item) =>
										selectGroup.advancedRate.includes(item.name)
									)
									.map((fieldData, index) => (
										<React.Fragment key={index}>
											<Grid className={classes.selectLabel} item xs={2}>
												<Typography variant="subtitle2" align="left">
													{fieldData.label}
												</Typography>
											</Grid>
											<Grid className={classes.selectIconGrid} item xs={1}>
												<InfoIcon className={classes.selectIcon} />
											</Grid>
											<Grid className={classes.selectInput} item xs={4}>
												{renderSelectField(fieldData)}
											</Grid>
											<Grid item xs={1}></Grid>
											<Grid item className={classes.selectInput} xs={4}>
												{renderSelectField(cashFlowSelect.assetsFeilds3[index])}
											</Grid>
										</React.Fragment>
									))}
							</Grid>
						)}
					</Grid>

					<Grid item lg={1} />

					<Grid item xs={6} md={12} lg={2}>
						<Button
							onClick={() => handleMenuChange('structure')}
							fullWidth
							className={classes.parametrHead}
						>
							<Typography variant="subtitle1">Structure</Typography>
							{/* <div className={classes.parametrHead_arrow}>
                {!menus.structure ? <ArrowDropUpIcon /> : <ArrowDropDownIcon />}
              </div> */}
						</Button>

						<div className={classes.mbt50} />

						{menus.structure && (
							<Grid container spacing={2}>
								<Grid item md={4} lg={12} style={{ marginBottom: 9 }}>
									<Grid container className={classes.inputCollection}>
										{/* <Typography align="left" variant="subtitle1" style={{ width: '100%', fontWeight: 'bold' }}>Triggers</Typography> */}
										{cashFlowSelect.assetsFeilds1
											.filter((item) =>
												selectGroup.triggers.includes(item.name)
											)
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid
														className={classes.selectInput}
														item
														xs={6}
														key={index}
													>
														{renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
									</Grid>
								</Grid>

								<Grid item md={4} lg={12}>
									<Grid container className={classes.inputCollection}>
										<Typography
											align="left"
											variant="subtitle1"
											className={classes.TypoHead}
										>
											Hedging
										</Typography>
										{cashFlowSelect.assetsFeilds1
											.filter((item) => selectGroup.swap.includes(item.name))
											.map((fieldData, index) => (
												<React.Fragment key={index}>
													<Grid className={classes.selectLabel} item xs={5}>
														<Typography variant="subtitle2" align="left">
															{fieldData.label}
														</Typography>
													</Grid>
													<Grid className={classes.selectIconGrid} item xs={1}>
														<InfoIcon className={classes.selectIcon} />
													</Grid>
													<Grid
														className={classes.selectInput}
														item
														xs={6}
														key={index}
													>
														{renderSelectField(fieldData)}
													</Grid>
												</React.Fragment>
											))}
									</Grid>
								</Grid>
							</Grid>
						)}
					</Grid>
				</>
			) : (
				<div className={classes.emptyParam}>
					<Typography variant="h6" align="left">
						Parameters
					</Typography>
				</div>
			)}
		</Grid>
	);

	return (
		<div className={classes.sidemenu}>
			<form className={view === 'layr' && classes.form}>
				{view === 'layr' && renderlayrFields()}
			</form>
		</div>
	);
};

const mapStateTopProps = ({ table, form }) => ({ table, formData: form });

export default compose(
	connect(mapStateTopProps, { getTables, tableRequest }),
	reduxForm({ form: 'select', destroyOnUnmount: false })
)(SideMenuA);
