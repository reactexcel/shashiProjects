import React from 'react';
import {
	Button,
	Dialog,
	DialogActions,
	DialogContent,
	DialogTitle
} from '@material-ui/core/Button';
import { SideMenuA } from './index';

function ParamasModal({
	handleClose,
	open,
	view = 'layr',
	formvalues,
	scenarioMount,
	setScenarioMount
}) {
	const renderSide = () => {
		return (
			<SideMenuA
				view={view}
				initialValues={formvalues}
				formvalues={formvalues}
				scenarioMount={scenarioMount}
				setScenarioMount={setScenarioMount}
			/>
		);
	};
	return (
		<>
			<Dialog
				fullWidth={true}
				maxWidth={'lg'}
				open={open}
				onClose={handleClose}
				aria-labelledby="max-width-dialog-title"
			>
				<DialogTitle id="max-width-dialog-title">Parameters</DialogTitle>
				<DialogContent>{renderSide()}</DialogContent>
				<DialogActions>
					<Button
						variant="contained"
						color="primary"
						style={{ textTransform: 'capitalize' }}
						onClick={handleClose}
					>
						Close
					</Button>
				</DialogActions>
			</Dialog>
		</>
	);
}

export default ParamasModal;
