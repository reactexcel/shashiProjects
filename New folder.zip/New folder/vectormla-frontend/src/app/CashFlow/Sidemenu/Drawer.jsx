import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withRouter, Link } from 'react-router-dom';
import clsx from 'clsx';
import {
	Divider,
	Hidden,
	ListItemText,
	SwipeableDrawer,
	List,
	ListItem
} from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { logout } from '../../store/actions/auth.action';
import logo from '../../../common/assets/images/logo.png';

const useStyles = makeStyles({
	list: {
		width: 250,
		textAlign: 'left'
	},
	fullList: {
		width: 'auto'
	},
	// drawer
	drawerHeader: {
		width: 100
	},
	header_listItem: {
		padding: '0px 10px',
		'&:hover': {
			backgroundColor: '#fff'
		}
	}
});

function SideMenuDrawer({ open, handleClose, history }) {
	const user = useSelector((state) => state.auth.user);
	const classes = useStyles();
	const dispatch = useDispatch();
	let items = [
		{ label: 'Cash Flow', link: '/cashflow' },
		{ label: 'Securitization', link: '' },
		{ label: 'Treasury', link: '' },
		{ label: 'Credit Risk', link: '/crm' },
		{ label: 'Prepayment', link: '/prepayment' },
		{ label: 'Pricing', link: '' },
		{ label: 'FP&A', link: '' },
		{ label: 'Basel', link: '' },
		{ label: 'ALCO', link: '' },
		{ label: 'Dashboard', link: '/dashboard' }
	];

	const toggleDrawer = (anchor, open) => (event) => {
		if (
			event &&
			event.type === 'keydown' &&
			(event.key === 'Tab' || event.key === 'Shift')
		) {
			return;
		}

		handleClose(false);
	};

	const list = () => (
		<div
			className={clsx(classes.list)}
			role="presentation"
			onClick={toggleDrawer()}
			onKeyDown={toggleDrawer()}
		>
			<List>
				<Link to="/">
					<ListItem button className={classes.header_listItem}>
						<img src={logo} alt="logo" className={classes.drawerHeader} />
					</ListItem>
				</Link>
			</List>
			<Divider />
			<List>
				{user.admin && (
					<>
						<Link to="/admin/panel">
							<ListItem button>
								<ListItemText>Panel</ListItemText>
							</ListItem>
						</Link>
						<Divider />
					</>
				)}

				<Hidden lgUp>
					{items.map((item, index) => (
						<React.Fragment key={index}>
							<Link to={item.link}>
								<ListItem button>
									<ListItemText>{item.label}</ListItemText>
								</ListItem>
							</Link>
							<Divider />
						</React.Fragment>
					))}
				</Hidden>

				<Divider />

				{user && (
					<>
						<ListItem
							button
							onClick={() => dispatch(logout(() => history.push('/login')))}
						>
							<ListItemText>Sign Out</ListItemText>
						</ListItem>
						<Divider />
					</>
				)}
			</List>
		</div>
	);

	return (
		<div>
			<React.Fragment>
				<SwipeableDrawer
					anchor="left"
					style={{ zIndex: 9999999 }}
					open={open}
					onClose={toggleDrawer()}
					onOpen={toggleDrawer()}
				>
					{list('left')}
				</SwipeableDrawer>
			</React.Fragment>
		</div>
	);
}
export default withRouter(SideMenuDrawer);
