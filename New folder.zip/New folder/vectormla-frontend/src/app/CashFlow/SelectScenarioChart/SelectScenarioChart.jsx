import React, { useState } from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { Popper, InputBase, Button, Typography } from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { useStyles, DarkCheckbox } from './selectScenarioChartStyles';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const SelecrCharts = ({
	senarioData,
	selectedScenario,
	setSelectedScenario
}) => {
	const classes = useStyles();
	const [anchorEl, setAnchorEl] = useState(null);
	const handleClick = (event) => setAnchorEl(event.currentTarget);

	const handleClose = (event, reason) => {
		if (reason === 'toggleInput') return;
		if (anchorEl) anchorEl.focus();
		setAnchorEl(null);
	};

	const open = Boolean(anchorEl);
	const id = open ? 'scenario-label' : undefined;
	return (
		<>
			<div className={classes.root}>
				<Button
					disableRipple
					className={classes.button}
					aria-describedby={id}
					onClick={handleClick}
				>
					<span>Scenarios List</span>
					<ExpandMoreIcon />
				</Button>
			</div>
			<Popper
				id={id}
				open={open}
				anchorEl={anchorEl}
				placement="bottom-start"
				className={classes.popper}
			>
				<div className={classes.header}>Select no. of Scenarios to display</div>
				{senarioData.length > 0 && (
					<Autocomplete
						open
						onClose={handleClose}
						multiple
						classes={{
							paper: classes.paper,
							option: classes.option,
							popperDisablePortal: classes.popperDisablePortal
						}}
						disablePortal
						renderTags={() => null}
						noOptionsText="No labels"
						id="checkboxes-tags-demo"
						options={senarioData}
						disableCloseOnSelect
						value={selectedScenario}
						onChange={(e, scena) => {
							setSelectedScenario(scena);
						}}
						limitTags={1}
						size="small"
						getOptionLabel={(option) => '' + option?.id}
						renderOption={(option, state) => {
							return (
								<div style={{ display: 'flex' }}>
									<DarkCheckbox
										icon={icon}
										checkedIcon={checkedIcon}
										style={{ marginRight: '8px', flex: 1 }}
										checked={
											selectedScenario.find((se) => se.id === option.id)
												? true
												: false
										}
									/>
									<Typography style={{ marginTop: '8px', flex: 9 }}>
										{`${option?.scenario}`}
									</Typography>
								</div>
							);
						}}
						style={{ width: 300 }}
						renderInput={(params) => (
							<InputBase
								ref={params.InputProps.ref}
								inputProps={params.inputProps}
								autoFocus
								className={classes.inputBase}
							/>
						)}
					/>
				)}
			</Popper>
		</>
	);
};

export default SelecrCharts;
