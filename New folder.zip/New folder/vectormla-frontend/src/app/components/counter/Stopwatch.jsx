import React, { useEffect, useState } from 'react';
import { useStyles } from '../portfolio/portfolioStyles';
import { useSelector } from 'react-redux';
import { CircularProgress } from '@material-ui/core';

const Stopwatch = ({ model, status, timerOnSuccess, runningTaskId }) => {
	const user = useSelector((state) => state.auth.user);
	const { calc_time_seconds5, calc_time_seconds6, calc_time_seconds0 } =
		useSelector((state) => state.fpna);
	const [time, setTime] = useState(undefined);
	let interval = null;
	let start =
		new Date() -
		(runningTaskId
			? localStorage.getItem(`${model}/${user?.id}/${runningTaskId}`) || 0
			: 0);

	useEffect(() => {
		if (
			model !== 'fpna5' &&
			model !== 'fpna5-3-1' &&
			model !== 'fpna6' &&
			model !== 'fpna5-3-1-0' &&
			model !== 'fpna5-2-1-0' &&
			model !== 'fpna5-1-1-0'
		) {
			if (time !== undefined && runningTaskId) {
				localStorage.setItem(`${model}/${user?.id}/${runningTaskId}`, time);
			}
		}
	}, [time]);

	useEffect(() => {
		if (
			model !== 'fpna5' &&
			model !== 'fpna5-3-1' &&
			model !== 'fpna5-2-1-0' &&
			model !== 'fpna6' &&
			model !== 'fpna0' &&
			model !== 'fpna5-1-1-0' &&
			model !== 'fpna5-3-1-0'
		) {
			interval = setInterval(() => {
				if (status === 'SUCCESS') {
					clearInterval(interval);
					localStorage.removeItem(`${model}/${user?.id}/${runningTaskId}`);
				}
				let current = new Date();
				setTime(+current - +start);
			}, 10);
			return () => {
				if (status === 'SUCCESS') {
					localStorage.removeItem(`${model}/${user?.id}/${runningTaskId}`);
				}
				clearInterval(interval);
			};
		}
	}, [status, runningTaskId]);

	const classes = useStyles();

	function formatTime(seconds) {
		const minutes = Math.floor(seconds / 60);
		const remainingSeconds = seconds % 60;

		const formattedMinutes = String(minutes).padStart(2, '0');
		const formattedSeconds = String(remainingSeconds).padStart(2, '0');

		return (
			<>
				<span>{formattedMinutes}:</span>
				<span>{formattedSeconds}</span>
			</>
		);
	}

	if (
		['pending'].includes(('' + status).toLowerCase()) ||
		(['success'].includes(('' + status).toLowerCase()) && timerOnSuccess)
	)
		return (
			<button
				style={{
					marginTop:
						model === 'fpna0'
							? '-25px'
							: model === 'fpna3'
							? '-60px'
							: [
									'credit2',
									'fpna5',
									'fpna5-3-1',
									'fpna6',
									'fpna0',
									'fpna5-1-1-0',
									'fpna5-2-1-0',
									'fpna5-3-1-0'
							  ].includes(model)
							? '-25px'
							: model === 'fpna4'
							? '-85px'
							: '-60px',
					position: 'absolute',
					marginLeft: [
						'fpna3',
						'fpna5',
						'fpna5-3-1',
						'fpna5-2-1-0',
						'fpna5-1-1-0',
						'fpna6',
						'fpna0',
						'fpna5-3-1-0'
					].includes(model)
						? '453px'
						: ['fpna4'].includes(model)
						? '373px'
						: '401px',
					fontSize: '12px'
				}}
				className={classes.header__save}
			>
				{model === 'fpna5' ||
				model === 'fpna6' ||
				model === 'fpna5-3-1' ||
				model === 'fpna5-1-1-0' ||
				model === 'fpna5-2-1-0' ||
				model === 'fpna5-3-1-0' ||
				model === 'fpna0' ? (
					<>
						{(model === 'fpna5' ||
							model === 'fpna5-3-1' ||
							model === 'fpna5-3-1-0' ||
							model === 'fpna5-2-1-0' ||
							model === 'fpna5-1-1-0') &&
						calc_time_seconds5 !== undefined ? (
							formatTime(calc_time_seconds5)
						) : model === 'fpna0' && calc_time_seconds0 !== undefined ? (
							formatTime(calc_time_seconds0)
						) : model === 'fpna6' && calc_time_seconds6 !== undefined ? (
							formatTime(calc_time_seconds6)
						) : (
							<div
								style={{
									display: 'flex',
									alignItems: 'center',
									justifyContent: 'center',
									gap: 5,
									fontSize: 10
								}}
							>
								Loading{' '}
								<div
									style={{
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'center'
									}}
								>
									<CircularProgress style={{ color: '#266696' }} size={10} />
								</div>
							</div>
						)}
					</>
				) : (
					<>
						<span>{('0' + Math.floor((time / 60000) % 60)).slice(-2)}:</span>
						<span>{('0' + Math.floor((time / 1000) % 60)).slice(-2)}</span>
					</>
				)}
			</button>
		);
	else return <></>;
};
export default Stopwatch;
