import React, { useState } from 'react';
import { Divider } from '@material-ui/core';
import { useStyles } from './contentContainerStyle';
import {
	MinusSquare,
	PlusSquare
} from '../../components/AssestFunctions/assestFun';
import MainTable from '../Table/MainTable';

import downArrow from '../../../common/assets/vector/images/arrow.svg';

import academy1 from '../../assets/academy/academy1.png';
import academy2 from '../../assets/academy/academy2.png';
import academy3 from '../../assets/academy/academy3.png';
import academy4 from '../../assets/academy/academy4.png';
import academy5 from '../../assets/academy/academy5.png';
import academy6 from '../../assets/academy/academy6.png';
import academy7 from '../../assets/academy/academy7.png';
import academy8 from '../../assets/academy/academy8.png';
import academy9 from '../../assets/academy/academy9.png';
import academy10 from '../../assets/academy/academy10.png';
import academy11 from '../../assets/academy/academy11.png';
import academy12 from '../../assets/academy/academy12.png';
import academy13 from '../../assets/academy/academy13.png';
import academy14 from '../../assets/academy/academy14.png';
import academy15 from '../../assets/academy/academy15.png';
import academy16 from '../../assets/academy/academy16.png';
import academy17 from '../../assets/academy/academy17.png';
import academy18 from '../../assets/academy/academy18.png';
import academy19 from '../../assets/academy/academy19.png';
import academy20 from '../../assets/academy/academy20.png';
import academy21 from '../../assets/academy/academy21.png';
import academy22 from '../../assets/academy/academy22.png';
import academy23 from '../../assets/academy/academy23.png';
import academy24 from '../../assets/academy/academy24.png';
import academy25 from '../../assets/academy/academy25.png';
import academy26 from '../../assets/academy/academy26.png';
import academy27 from '../../assets/academy/academy27.png';
import academy28 from '../../assets/academy/academy28.png';
import academy29 from '../../assets/academy/academy29.png';
import academy30 from '../../assets/academy/academy30.png';
import academy31 from '../../assets/academy/academy31.png';
import { useEffect } from 'react';

const imgs = [
	academy1,
	academy2,
	academy3,
	academy4,
	academy5,
	academy6,
	academy7,
	academy8,
	academy9,
	academy10,
	academy11,
	academy12,
	academy13,
	academy14,
	academy15,
	academy16,
	academy17,
	academy18,
	academy19,
	academy20,
	academy21,
	academy22,
	academy23,
	academy24,
	academy25,
	academy26,
	academy27,
	academy28,
	academy29,
	academy30,
	academy31
];
const ContentContainer = ({
	header,
	content,
	tableLeftAlign,
	onClick,
	collapsed
}) => {
	const classes = useStyles();
	const [visible, setVisible] = useState(false);

	const filterHeaderExist = Object.keys(
		content.filter((item, i) => item.header)
	);
	let stateKeys = {};
	filterHeaderExist.map((item) => (stateKeys[item] = false));

	const [state, setState] = useState(stateKeys);
	useEffect(() => {
		if (collapsed >= 1) {
			setVisible(true);
		} else if (collapsed === 0 && visible) {
			setVisible(false);
		}
	}, [collapsed]);
	const handleStateChange = (key) =>
		setState({
			...state,
			[`${key}`]: !state[`${key}`]
		});

	return (
		<div>
			<div
				className={classes.contentHeaderContainer}
				onClick={() => {
					setVisible(!visible);
				}}
			>
				<p className={classes.contentHeader}>{header}</p>
				<img src={downArrow} alt="down-arrow" />
			</div>
			<Divider style={{ marginBottom: 20 }} />
			{visible &&
				content.map((section, i) => (
					<div key={`con-${i}`}>
						{section.header && (
							<div style={{ display: 'flex' }}>
								{state[i] ? (
									<MinusSquare
										className={classes.headerIcon}
										onClick={() => handleStateChange(i)}
									/>
								) : (
									<PlusSquare
										className={classes.headerIcon}
										onClick={() => handleStateChange(i)}
									/>
								)}
								<p className={classes.header}>{section.header}</p>
							</div>
						)}
						{(!section.header || state[i]) && (
							<div>
								{section.hoveredText && (
									<div onClick={onClick && onClick}>
										<p className={classes.hoveredText}>{section.hoveredText}</p>
									</div>
								)}
								{section.details && (
									<>
										{section.details.map((item, k) => (
											<div key={`detailsCon-${k}`}>
												<div>
													<p className={classes.text}>{item.text}</p>
												</div>
												{item.img && (
													<div>
														<center>
															<img key={k} src={imgs[item.img - 1]} alt="" />
														</center>
														<div>
															<p className={classes.text}>[{item.img}]</p>
														</div>
													</div>
												)}
												{item.tableData && (
													<MainTable
														header={item.tableData.headers}
														data={item.tableData.rows}
														attributes={Object.keys(item.tableData.rows[0])}
														tableId={0}
														key={0}
														disableHeader
														onLeft={tableLeftAlign}
													/>
												)}
											</div>
										))}
									</>
								)}
							</div>
						)}
					</div>
				))}
		</div>
	);
};
export default ContentContainer;
