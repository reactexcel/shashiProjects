import React from 'react';

function NumberOfLoans({ data }) {
	return (
		<div className="numberOfLoansContainer">
			{data?.map((column, columnIndex) => {
				return (
					<div className="numberOfLoansColumn" key={columnIndex}>
						{column.map((row, rowIndex) => {
							return (
								<div className="numberOfLoansRow" key={rowIndex}>
									<p className="numberLoanTitle">{row.title}</p>
									<p className="numberLoanAmount">{row.amount}</p>
								</div>
							);
						})}
					</div>
				);
			})}
		</div>
	);
}

export default NumberOfLoans;
