import React, { useState } from 'react';
import {
	Button,
	Dialog,
	DialogTitle,
	Grid,
	IconButton,
	Typography
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import TextField from '../../../common/components/fields/TextField';
import { useStyles } from './portfolioStyles';
import { toast } from 'react-toastify';

const AddPortfolioDialog = ({
	open,
	handleClose,
	create,
	update,
	deleteObj
}) => {
	const classes = useStyles();
	const [name, setName] = useState('');
	const [file, setFile] = useState(null);

	const submit = () => {
		if ((open === 'create' || open === 'edit') && (!name || name.length < 3))
			return toast.warn('Name must be at least 3 characters!', {
				autoClose: 5000
			});
		else if (!file && open === 'create')
			return toast.warn('Excel File is required', {
				autoClose: 5000
			});
		else if (open === 'delete') {
			return (
				deleteObj(),
				handleClose(false),
				toast.success('Portfolio deleted successfully.', {
					autoClose: 5000
				})
			);
		} else if (open === 'edit') {
			update(name, () => {
				toast.success('Portfolio name is updated successfully.', {
					autoClose: 5000
				});
			});
		} else {
			create(name, file);
		}
		handleClose(false);
		setName('');
		setFile(null);
	};

	return (
		<Dialog
			className={classes.dialog}
			maxWidth="lg"
			open={open}
			onClose={handleClose}
		>
			<DialogTitle>
				{open === 'create'
					? 'Create '
					: open === 'edit'
					? 'Update '
					: 'Delete '}
				Portfolio
			</DialogTitle>
			{open === 'create' || open === 'edit' ? (
				<Grid container className={classes.content}>
					<TextField
						name={'name'}
						type={'text'}
						placeholder={'Portfolio Name'}
						defaultValue={name}
						onChange={(e) => {
							setName(e.target.value);
						}}
					/>
					<Grid
						style={{
							display: 'flex',
							width: '100%',
							justifyContent: 'space-between'
						}}
					>
						{open === 'create' && (
							<Grid>
								<input
									accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
									id="xlsx-upload-1"
									type="file"
									hidden
									onChange={(e) => setFile(e.target?.files[0])}
								/>
								<Typography
									style={{ position: 'absolute', bottom: 20, fontSize: 10 }}
								>
									{file?.name}
								</Typography>

								<label
									htmlFor="xlsx-upload-1"
									style={{ margin: 0, fontSize: 10 }}
								>
									<Button className={classes.header__save} component="span">
										Upload
									</Button>
								</label>
							</Grid>
						)}
						<Button
							className={classes.header__save}
							style={{ margin: 0 }}
							onClick={submit}
						>
							{open === 'create'
								? 'Create'
								: open === 'edit'
								? 'Confirm'
								: 'Delete'}
						</Button>
					</Grid>
				</Grid>
			) : (
				<Grid container className={classes.content}>
					<label>Are you sure you want to delete this portfolio?</label>
					<Grid
						style={{
							display: 'flex',
							width: '100%',
							justifyContent: 'space-between'
						}}
					>
						<Button
							className={classes.header__save}
							style={{ margin: 0 }}
							onClick={handleClose}
						>
							Cancel
						</Button>
						<Button
							className={classes.header__save}
							style={{ margin: 0 }}
							onClick={submit}
						>
							Delete
						</Button>
					</Grid>
				</Grid>
			)}
			<IconButton
				className={classes.create__close}
				onClick={handleClose}
				aria-label="close"
			>
				<CloseIcon />
			</IconButton>
		</Dialog>
	);
};

export default AddPortfolioDialog;
