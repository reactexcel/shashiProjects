import React from 'react';
import { makeStyles } from '@material-ui/core';
import {
	primaryColor,
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';
import { withStyles } from '@material-ui/core/styles';
import { Checkbox } from '@material-ui/core';

export const useStyles = makeStyles((theme) => ({
	root2: {
		minHeight: 90,
		boxShadow: 'none',
		flexGrow: 1,
		zIndex: 0,
		backgroundColor: 'transparent'
	},
	root3: {
		minHeight: 90,
		boxShadow: 'none',
		flexGrow: 1,
		zIndex: 0,
		backgroundColor: 'transparent',
		'& .MuiFormControl-root': {
			margin: '0px 0px 9px'
		}
	},
	runContainer: {
		width: '100%',
		display: 'flex',
		alignItems: 'center'
	},
	label: {
		color: '#000',
		width: 50,
		fontSize: '12px',
		fontFamily: 'Roboto'
	},
	header__save: {
		textTransform: 'capitalize',
		height: 25,
		width: 75,
		marginRight: 5,
		marginLeft: 0,
		color: '#53687E !important',
		borderRadius: '4px',
		border: '1px solid #7991aa',
		backgroundColor: 'white',
		'&:hover': {
			backgroundColor: '#7991AA',
			border: '1px solid #53687E',
			color: 'white !important'
		},
		[theme.breakpoints.down('sm')]: {
			width: 65
		}
	},
	selectIcon: {
		width: 16,
		margin: '0 15px 0 10px',
		color: '#dbdcde',
		'&:hover': {
			cursor: 'pointer'
		}
	},
	login__input: {
		width: 175,
		height: 25,
		backgroundColor: '#F0F0F0',
		borderRadius: 0,
		color: '#194775',
		fontSize: '11px'
	},
	dialog: {
		display: 'flex',
		alignItems: 'center',
		justifyContent: 'center'
	},
	content: {
		backgroundColor: theme.palette.background.paper,
		boxShadow: theme.shadows[5],
		borderRadius: 5,
		width: 400,
		height: 120,
		paddingInline: 20
	},
	create__close: {
		position: 'absolute',
		top: 0,
		right: 0
	},
	contentHeaderContainer,
	contentHeader,
	progressContainer: {
		width: '95%',
		justifyContent: 'center',
		display: 'flex',
		position: 'absolute',
		marginTop: -20
	},
	segmentRoot: {
		position: 'relative'
	},
	segmentDropdown: {
		position: 'absolute',
		top: 28,
		right: 0,
		left: 0,
		zIndex: 11,
		padding: theme.spacing(1),
		backgroundColor: '#f7f8fa',
		boxShadow: '0 3px 12px rgba(27,31,35,.15)',
		minWidth: '300px'
	},
	segmentSelect: {
		color: 'rgba(0, 0, 0, 0.87)',
		padding: '0px 0px 0px 12px',
		width: '174px',
		fontSize: '11px',
		background: '#f7f8fa',
		fontFamily: 'Roboto',
		fontWeight: 500,
		lineHeight: '1.18em',
		borderRadius: 0,
		border: '1px solid rgba(190, 191, 192, 1)',
		height: '24px',
		display: 'flex',
		justifyContent: 'space-between',
		alignItems: 'center',
		cursor: 'pointer',
		'& > svg': {
			width: 30,
			height: 17
		}
	},
	segment_checkLabel: {
		fontSize: '13px',
		fontFamily: 'Roboto',
		fontWeight: 'bold'
	}
}));

export const DarkCheckbox = withStyles({
	root: {
		color: 'grey',
		'&$checked': {
			color: primaryColor
		}
	},
	checked: {}
})((props) => <Checkbox color="default" {...props} />);
