import { makeStyles } from '@material-ui/core';
import {
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';

const buttonStyles = {
	textTransform: 'capitalize',
	height: 25,
	width: 75,
	marginTop: 18,
	marginRight: 5,
	marginLeft: 0,
	paddingRight: 4,
	paddingLeft: 4,
	fontSize: '11px',
	color: '#53687E !important',
	borderRadius: '4px',
	border: '1px solid #7991aa',
	backgroundColor: '#F7F8FA',
	'&:hover': {
		backgroundColor: '#7991AA !important',
		border: '1px solid #53687E',
		color: 'white !important'
	}
};

const initiateTab__continueButton = {
	...buttonStyles,
	marginTop: 30,
	width: 120,
	justifyContent: 'left',
	paddingLeft: 12,
	backgroundColor: '#5C8CB0 !important',
	color: 'white !important'
};

const initiateTab__reportButton = {
	...buttonStyles,
	marginTop: 18,
	width: 120,
	justifyContent: 'left',
	paddingLeft: 12
};

const defaultTabTable = {
	width: '960px',
	'& td': {
		fontSize: 11,
		paddingBlock: 1,
		paddingInline: 5,
		width: '25%',
		height: '22px',
		border: '1px solid #D8DDE3',
		fontFamily: 'Roboto',
		color: '#595959',
		backgroundColor: `white !important`,
		// '&:hover': {
		// 	backgroundColor: `rgba(38, 102, 150, 0.18) !important`
		// },
		'&.greyCell': {
			backgroundColor: `#F9F9F9 !important`
		}
	}
};

export const useStyles = makeStyles((theme) => ({
	contentHeaderContainer,
	contentHeader,
	header__generateButton: {
		...buttonStyles,
		width: 120
	},
	header__note: {
		marginTop: '14px',
		fontSize: '6px',
		width: 470
	},
	tabsTable: {
		marginTop: '20px',
		width: '960px',
		'& td': {
			fontSize: 11,
			paddingBlock: 1,
			paddingInline: 5,
			width: '25%',
			height: '22px',
			border: '1px solid #D8DDE3',
			fontWeight: 'bold',
			fontFamily: 'Roboto',
			color: '#266696',
			cursor: 'pointer',
			backgroundColor: `white !important`,
			'&:hover': {
				backgroundColor: `rgba(38, 102, 150, 0.1) !important`
			},
			'&.active': {
				backgroundColor: `rgba(38, 102, 150, 0.18) !important`
			},
			'& img': {
				marginRight: '2px'
			}
		}
	},
	tabsTable__img1: {
		width: '13px',
		height: '13px'
	},
	tabsTable__img2: {
		width: '12px',
		height: '12px'
	},
	tabsTable__img3: {
		width: '11px',
		height: '11px'
	},
	tabsTable__img4: {
		width: '11px',
		height: '11px'
	},
	initiateTab__table: {
		marginTop: '5px',
		...defaultTabTable
	},
	initiateTab__tableLabel: {
		paddingTop: '12px !important',
		paddingBottom: '2px !important',
		paddingInline: '0 !important',
		border: '0 !important',
		fontWeight: 'bold'
	},
	initiateTab__continueButton: {
		...initiateTab__continueButton
	},
	initiateTab__reportButton: {
		...initiateTab__reportButton
	},
	reviewTab__confirmButton: {
		...initiateTab__continueButton
	},
	reviewTab__editButton: {
		...initiateTab__reportButton
	},
	monitorTab__headMain: {
		fontSize: '11px',
		fontWeight: 'bold',
		marginTop: '12px',
		color: '#595959'
	},
	monitorTab__headBody: {
		fontSize: '11px',
		color: '#595959'
	},
	monitorTab__table: {
		marginTop: '-4px',
		...defaultTabTable
	},
	monitorTab__eventHistory: {
		fontSize: '11px',
		fontWeight: 'bold',
		marginTop: '15px',
		color: '#595959'
	},
	monitorTab__cancelButton: {
		...initiateTab__reportButton,
		marginTop: '10px'
	}
}));
