import React from 'react';
import Autocomplete from '@material-ui/lab/Autocomplete';
import { Popper, InputBase } from '@material-ui/core';
import {
	CheckBoxIcon,
	ExpandMoreIcon,
	CheckBoxOutlineBlankIcon
} from '@material-ui/icons';
import { useStyles, DarkCheckbox } from './editSelectStyles';

import { Button } from '@material-ui/core';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

const EditSelect = ({
	senarioData,
	checkedList,
	handleScenario,
	scenario,
	handleReplicate,
	handleDelete,
	editName,
	editNameField,
	handleCheckbox,
	handleCloseEdit,
	handleDoneEdit,
	renderTextField,
	setEditNameField,
	selectForm,
	Field
}) => {
	const classes = useStyles();
	const [anchorEl, setAnchorEl] = React.useState(null);
	const handleClick = (event) => {
		setAnchorEl(event.currentTarget);
	};
	const handleClose = (event, reason) => {
		if (reason === 'toggleInput') {
			return;
		}
		if (anchorEl) {
			anchorEl.focus();
		}
		setAnchorEl(null);
		handleCloseEdit();
	};

	const open = Boolean(anchorEl);
	const id = open ? 'scenario-label' : undefined;

	return (
		<>
			<div className={classes.root}>
				<Button
					disableRipple
					className={classes.button}
					aria-describedby={id}
					onClick={handleClick}
				>
					{/* <span>{senarioData[0]?.scenarios.find(se => se.id === scenario)?.name}</span> */}
					<span>{scenario}</span>
					<ExpandMoreIcon />
				</Button>
			</div>
			<Popper
				id={id}
				open={open}
				anchorEl={anchorEl}
				placement="bottom-start"
				className={classes.popper}
			>
				<Autocomplete
					open
					onClose={handleClose}
					multiple
					classes={{
						paper: classes.paper,
						option: classes.option,
						popperDisablePortal: classes.popperDisablePortal
					}}
					disablePortal
					renderTags={() => null}
					noOptionsText="No labels"
					id="checkboxes-tags-demo"
					options={senarioData[0].scenarios}
					disableCloseOnSelect
					value={checkedList}
					limitTags={1}
					size="small"
					getOptionLabel={(option) => option.name}
					renderOption={(option, state) => {
						return (
							<div style={{ display: 'flex', textAlign: 'left' }}>
								<div style={{ marginRight: '8px' }}>
									<DarkCheckbox
										icon={icon}
										checkedIcon={checkedIcon}
										checked={checkedList.includes(option)}
										onChange={() => handleCheckbox(option)}
									/>
								</div>
								<div
									className={classes.checkbox_typo}
									onClick={() => {
										handleScenario(option.name);
									}}
									onDoubleClick={() => setEditNameField(option.name)}
								>
									{option.name}
								</div>
							</div>
						);
					}}
					renderInput={(params) => {
						return (
							<>
								{params.inputProps.value && editNameField ? (
									<InputBase
										inputProps={params.inputProps}
										placeholder={
											editNameField
												? editNameField
												: 'To Edit Double Click On any Option'
										}
										className={classes.inputBase}
										autoFocus
									/>
								) : (
									<InputBase
										ref={params.InputProps.ref}
										inputProps={params.inputProps}
										placeholder={
											editNameField
												? editNameField
												: 'To Edit Double Click On any Option'
										}
										className={classes.inputBase}
										autoFocus
									/>
								)}
								<div className={classes.divButtonEdit}>
									<Button
										disableRipple
										className={classes.buttonEdit}
										onClick={handleReplicate}
										disabled={
											checkedList.length !== 1 || params.inputProps.value
										}
									>
										<span>Replicate</span>
									</Button>
									<Button
										disableRipple
										className={classes.buttonEdit}
										onClick={handleDelete}
										disabled={
											checkedList.length === 0 ||
											senarioData[0].scenarios.length === 1 ||
											params.inputProps.value
										}
									>
										<span>Delete</span>
									</Button>
									<Button
										disableRipple
										className={classes.buttonEdit}
										onClick={() => handleDoneEdit(params.inputProps.value)}
										disabled={!params.inputProps.value || !editNameField}
									>
										<span>Edit</span>
									</Button>
								</div>
							</>
						);
					}}
				/>
			</Popper>
		</>
	);
};

export default EditSelect;
