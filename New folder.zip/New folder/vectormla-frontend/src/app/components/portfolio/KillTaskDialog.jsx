import React from 'react';
import {
	Button,
	Dialog,
	DialogTitle,
	Grid,
	IconButton
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { useStyles } from './portfolioStyles';

const KillTaskDialog = ({ open, handleClose, kill }) => {
	const classes = useStyles();

	const submit = () => {
		kill();
	};

	return (
		<Dialog
			className={classes.dialog}
			maxWidth="lg"
			open={open}
			onClose={handleClose}
		>
			<DialogTitle>Stop Task</DialogTitle>
			<Grid container className={classes.content}>
				<label>Are you sure you want to stop this task?</label>
				<Grid
					style={{
						display: 'flex',
						width: '100%',
						justifyContent: 'space-between'
					}}
				>
					<Button
						className={classes.header__save}
						style={{ margin: 0 }}
						onClick={handleClose}
					>
						Cancel
					</Button>
					<Button
						className={classes.header__save}
						style={{ margin: 0 }}
						onClick={submit}
					>
						Stop
					</Button>
				</Grid>
			</Grid>
			<IconButton
				className={classes.create__close}
				onClick={handleClose}
				aria-label="close"
			>
				<CloseIcon />
			</IconButton>
		</Dialog>
	);
};

export default KillTaskDialog;
