import React, { useState } from 'react';

import {
	Button,
	Table,
	TableBody,
	TableCell,
	TableRow
} from '@material-ui/core';

import { useStyles } from './fundingRequestsStyles';

import iconCheckRing from '../../../common/assets/vector/images/icon_check_ring.svg';
import iconReview from '../../../common/assets/vector/images/icon_review.svg';
import iconInfo from '../../../common/assets/vector/images/icon_info.svg';
import iconTransaction from '../../../common/assets/vector/images/icon_transaction.svg';

function InitiateTable({
	onClickContinue,
	onClickGenerate,
	maximumCreditFacilityDraw,
	maximumAdvanceRatePercent,
	borrowingFromReceivableAssets,
	borrowingFromCash,
	totalBorrowingAmount,
	totalMaxAdvanceAmount,
	totalLoanOutstandingBefore,
	totalLoanOutstandingAfter,
	effectiveAdvanceRatePercentBefore,
	effectiveAdvanceRatePercentAfter
}) {
	const classes = useStyles();

	return (
		<>
			<div style={{ height: '36px' }} />
			<Table className={classes.initiateTab__table}>
				<TableBody>
					<TableRow>
						<TableCell className={classes.initiateTab__tableLabel}>
							Maximum Credit Facility Draw
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Maximum Credit Facility Draw
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Maximum Advance Rate %
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}></TableCell>
					</TableRow>
					<TableRow>
						<TableCell className="greyCell">
							{maximumCreditFacilityDraw}
						</TableCell>
						<TableCell>{maximumCreditFacilityDraw}</TableCell>
						<TableCell className="greyCell">
							{maximumAdvanceRatePercent}
						</TableCell>
						<TableCell>{maximumAdvanceRatePercent}</TableCell>
					</TableRow>
					<TableRow>
						<TableCell className={classes.initiateTab__tableLabel}>
							Borrowing From Receivable Assets
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Borrowing From Cash
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Total Borrowing Amount
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Total Max Advance Amount
						</TableCell>
					</TableRow>
					<TableRow>
						<TableCell className="greyCell">
							{borrowingFromReceivableAssets}
						</TableCell>
						<TableCell>{borrowingFromCash}</TableCell>
						<TableCell className="greyCell">{totalBorrowingAmount}</TableCell>
						<TableCell>{totalMaxAdvanceAmount}</TableCell>
					</TableRow>
					<TableRow>
						<TableCell className={classes.initiateTab__tableLabel}>
							Funding Impact
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Total Loan Outstanding
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}></TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Effective Advance Rate%
						</TableCell>
					</TableRow>
					<TableRow>
						<TableCell>Before</TableCell>
						<TableCell>{totalLoanOutstandingBefore}</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}></TableCell>
						<TableCell className="greyCell">
							{effectiveAdvanceRatePercentBefore}
						</TableCell>
					</TableRow>
					<TableRow>
						<TableCell>After</TableCell>
						<TableCell>{totalLoanOutstandingAfter}</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}></TableCell>
						<TableCell className="greyCell">
							{effectiveAdvanceRatePercentAfter}
						</TableCell>
					</TableRow>
				</TableBody>
			</Table>
			<div>
				<Button
					className={classes.initiateTab__continueButton}
					onClick={onClickContinue}
				>
					Continue &gt;&gt;
				</Button>
			</div>
			<div>
				<Button
					className={classes.initiateTab__reportButton}
					onClick={onClickGenerate}
				>
					Report Review
				</Button>
			</div>
		</>
	);
}

function ReviewTable({
	onClickConfirm,
	onClickEdit,
	amount,
	source,
	destination,
	fundingDate
}) {
	const classes = useStyles();

	return (
		<>
			<div style={{ height: '36px' }} />
			<Table className={classes.initiateTab__table}>
				<TableBody>
					<TableRow>
						<TableCell className={classes.initiateTab__tableLabel}>
							Amount
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Source
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Destination
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Funding Date
						</TableCell>
					</TableRow>
					<TableRow>
						<TableCell className="greyCell">{amount}</TableCell>
						<TableCell>{source}</TableCell>
						<TableCell className="greyCell">{destination}</TableCell>
						<TableCell>{fundingDate}</TableCell>
					</TableRow>
				</TableBody>
			</Table>
			<div>
				<Button
					className={classes.reviewTab__confirmButton}
					onClick={onClickConfirm}
				>
					Confirm &gt;&gt;
				</Button>
			</div>
			<div>
				<Button className={classes.reviewTab__editButton} onClick={onClickEdit}>
					Edit
				</Button>
			</div>
		</>
	);
}

function MonitorTable({
	onClickCancel,
	amount,
	source,
	destination,
	fundingDate
}) {
	const classes = useStyles();

	return (
		<>
			<div>
				<div className={classes.monitorTab__headMain}>
					Funding Request Submited
				</div>
				<div className={classes.monitorTab__headBody}>
					Your request has been submitted. We’ll update this page as soon as
					this request is approved.
				</div>
			</div>

			<Table className={classes.monitorTab__table}>
				<TableBody>
					<TableRow>
						<TableCell className={classes.initiateTab__tableLabel}>
							Amount
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Source
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Destination
						</TableCell>
						<TableCell className={classes.initiateTab__tableLabel}>
							Funding Date
						</TableCell>
					</TableRow>
					<TableRow>
						<TableCell className="greyCell">{amount}</TableCell>
						<TableCell>{source}</TableCell>
						<TableCell className="greyCell">{destination}</TableCell>
						<TableCell>{fundingDate}</TableCell>
					</TableRow>
				</TableBody>
			</Table>
			<div>
				<div className={classes.monitorTab__eventHistory}>Event History</div>
				<Button
					className={classes.monitorTab__cancelButton}
					onClick={onClickCancel}
				>
					Cancel Submission
				</Button>
			</div>
		</>
	);
}

function FundingRequests() {
	const [tableVisible, setTableVisible] = useState(false);
	const [visibleTab, setVisibleTab] = useState(0);

	const classes = useStyles();

	const sampleData = {
		maximumCreditFacilityDraw: '$3,800,124',
		maximumAdvanceRatePercent: '58.9%',
		borrowingFromReceivableAssets: '$4,226,339',
		borrowingFromCash: '$100',
		totalBorrowingAmount: '$4,226,339',
		totalMaxAdvanceAmount: '$3,800,124',
		totalLoanOutstandingBefore: '$0',
		totalLoanOutstandingAfter: '$3,800,124',
		effectiveAdvanceRatePercentBefore: '0%',
		effectiveAdvanceRatePercentAfter: '58.9%',
		// tab 2
		amount: '$1,240,850',
		source: 'JPMorgan Chase Bank, N.A (****5568)',
		destination: 'JPMorgan Chase Bank, N.A (****2450)',
		fundingDate: 'May 13, 2024'
	};

	return (
		<>
			<div
				className={classes.contentHeaderContainer}
				onClick={() => setTableVisible(!tableVisible)}
			>
				<p className={classes.contentHeader}>Funding Request</p>
			</div>
			{tableVisible && (
				<>
					<div style={{ marginBottom: 20 }}></div>

					<Button className={classes.header__generateButton} onClick={() => {}}>
						Funding Request
					</Button>

					<div className={classes.header__note}>
						Note: When generating a new funding request, Vector will
						automatically calculate the optimized funding amount. Recommended
						funding activity is based on portfolio assets, loan availability,
						and collections. Vector recommends the following funding request
						transaction. You can also choose a lower amount by adjusting the
						funding request amount.
					</div>

					<Table className={classes.tabsTable}>
						<TableBody>
							<TableRow>
								<TableCell
									className={visibleTab == 0 ? 'active' : ''}
									onClick={() => setVisibleTab(0)}
								>
									<img
										src={iconCheckRing}
										alt=""
										className={classes.tabsTable__img1}
									/>
									Initiate
								</TableCell>
								<TableCell
									className={visibleTab == 1 ? 'active' : ''}
									onClick={() => setVisibleTab(1)}
								>
									<img
										src={iconReview}
										alt=""
										className={classes.tabsTable__img2}
									/>
									Review
								</TableCell>
								<TableCell
									className={visibleTab == 2 ? 'active' : ''}
									onClick={() => setVisibleTab(2)}
								>
									<img
										src={iconInfo}
										alt=""
										className={classes.tabsTable__img3}
									/>
									Monitor
								</TableCell>
								<TableCell
									className={visibleTab == 3 ? 'active' : ''}
									onClick={() => setVisibleTab(3)}
								>
									<img
										src={iconTransaction}
										alt=""
										className={classes.tabsTable__img4}
									/>
									Transactions Log
								</TableCell>
							</TableRow>
						</TableBody>
					</Table>

					{visibleTab === 0 && (
						<InitiateTable
							{...sampleData}
							onClickContinue={() => {}}
							onClickReport={() => {}}
						/>
					)}

					{visibleTab === 1 && (
						<div style={{ height: '319px' }}>
							<ReviewTable
								{...sampleData}
								onClickContinue={() => {}}
								onClickReport={() => {}}
							/>
						</div>
					)}

					{visibleTab === 2 && (
						<div style={{ height: '307px' }}>
							<MonitorTable
								{...sampleData}
								onClickContinue={() => {}}
								onClickReport={() => {}}
							/>
						</div>
					)}

					{visibleTab === 3 && (
						<InitiateTable
							{...sampleData}
							onClickContinue={() => {}}
							onClickReport={() => {}}
						/>
					)}
				</>
			)}
		</>
	);
}

export default FundingRequests;
