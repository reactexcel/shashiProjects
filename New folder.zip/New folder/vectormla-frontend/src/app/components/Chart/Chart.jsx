// This Chart used for data that has Scenarios included
import React, { PureComponent, useMemo } from 'react';
import {
	AreaChart,
	Area,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	ResponsiveContainer,
	Legend
} from 'recharts';
import { primaryColor } from '../../../common/assets/layout';
import { balanceAttributes } from 'app/Fpna/tableHeader';

const Chart = ({
	dataT,
	nameLegend,
	sizeLegend = '14px',
	brushID,
	dataX,
	xDistance,
	format,
	defaultSelect,
	selectedScenario,
	noCharts,
	customTooltip
}) => {
	const generatedData = useMemo(() => {
		if (!dataT) return [];
		let arrData = [];
		dataT.map((d, index) => {
			if (dataT.length === 1) arrData = dataT[0];
			else if (dataT.length === 2)
				arrData = dataT[0].map((item, i) =>
					Object.assign({}, item, dataT[1][i])
				);
			else {
				if (index === 0) arrData = d;
				else arrData = d.map((item, i) => Object.assign({}, item, arrData[i]));
			}
		});
		return arrData;
	}, [dataT]);

	const formatYAxis = (tickItem) => {
		if (format) return +tickItem;
		else return +tickItem;
	};

	class CustomizedXAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			let dateStr = ('' + payload.value).split('-');
			return (
				<g transform={`translate(${x},${y})`}>
					<text x={5} y={0} dy={16} textAnchor="end" fontSize={14} fill="#666">
						{dateStr[0]}
					</text>
					<text x={5} y={15} dy={16} textAnchor="end" fontSize={14} fill="#666">
						{dateStr[1]}
					</text>
				</g>
			);
		}
	}

	class CustomizedYAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={-10}
						dy={16}
						textAnchor="end"
						fontSize={nameLegend === 'Projected Balance' ? 12 : 14}
						fill="#666"
					>
						{format === 'com'
							? Number(payload.value).toLocaleString()
							: [
									'Closing Balance',
									'Historical Balance',
									'Projected Balance'
							  ].includes(nameLegend)
							? payload.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
							: `${payload.value} %`}
					</text>
				</g>
			);
		}
	}

	const renderTooltipContent = (o) => {
		const { payload, label } = o;
		return (
			<div
				style={{
					backgroundColor: '#fff',
					border: '1px solid #000',
					marginTop: payload?.length > 18 ? '-90px' : '-50px'
				}}
			>
				<div style={{ fontSize: 14, marginLeft: 5 }}>
					{customTooltip ? `Period: ${label}` : `${label}`}
				</div>
				{payload &&
					payload.map((entry, index) => (
						<div
							key={`item-${index}1`}
							style={{
								color: entry.color,
								fontSize: payload.length > 16 ? 10.5 : 14,
								padding: payload.length > 16 ? 1.5 : 5
							}}
						>
							{`${entry.name} : ( ${Number(entry.value).toLocaleString()} )  `}
						</div>
					))}
			</div>
		);
	};

	const renderLegend = () => {
		return <div style={{ marginBottom: 15 }}> {nameLegend}</div>;
	};
	const getRandomColor = () => {
		const letters = '0123456789ABCDEF';
		let color = '#';
		for (let i = 0; i < 6; i++) {
			color += letters[Math.floor(Math.random() * 16)];
		}
		return color;
	};
	const colorMapping = {
		'1-15': '#1E76A9',
		'16-30': '#71BAEB',
		'1-30': '#46BAC2',
		'31-60': '#279E94',
		'61-90': '#1F7E76',
		'91-120': '#26509E'
	};

	const getColor = (nameChart) => {
		if (brushID === 'delinquency' && colorMapping[nameChart]) {
			return colorMapping[nameChart];
		}
		return defaultColor;
	};

	const defaultColor = '#1e76a9';
	return (
		<ResponsiveContainer width="100%" height="100%">
			<AreaChart
				data={dataT.length > 0 ? generatedData : dataT[0]}
				syncId={brushID}
				margin={{ top: 0, right: 0, left: 25, bottom: 30 }}
			>
				<CartesianGrid vertical={false} />
				<XAxis
					tickLine={true}
					dataKey={`${dataX}`}
					type="category"
					textAnchor="end"
					tickSize={6}
					tick={<CustomizedXAxisTick />}
				/>
				<YAxis
					tickLine={true}
					tickCount={7}
					type="number"
					textAnchor="end"
					tickFormatter={formatYAxis}
					tick={<CustomizedYAxisTick />}
				/>
				<Tooltip
					// allowEscapeViewBox={{ x: false, y: false }}
					content={renderTooltipContent}
				/>
				{!selectedScenario ? (
					noCharts.map((nameChart, index) => {
						return (
							<Area
								key={index}
								type="monotone"
								dataKey={nameChart}
								stroke={getColor(
									nameChart.includes('status_1a_del_prcnt')
										? '1-15'
										: nameChart.includes('status_1b_del_prcnt')
										? '16-30'
										: nameChart.includes('status_1_del_prcnt')
										? '1-30'
										: nameChart.includes('status_2_del_prcnt')
										? '31-60'
										: nameChart.includes('status_3_del_prcnt')
										? '61-90'
										: nameChart.includes('status_4_del_prcnt')
										? '91-120'
										: ''
								)}
								fill={brushID === 'Default' ? 'transparent' : '#e1eef7'}
								opacity={1}
								id={'index' + index}
								name={
									// Keeping the same naming logic you provided
									nameChart.includes('status_1a_del_prcnt')
										? '1-15'
										: nameChart.includes('status_1b_del_prcnt')
										? '16-30'
										: nameChart.includes('status_1_del_prcnt')
										? '1-30'
										: nameChart.includes('status_2_del_prcnt')
										? '31-60'
										: nameChart.includes('status_3_del_prcnt')
										? '61-90'
										: nameChart.includes('status_4_del_prcnt')
										? '91-120'
										: nameChart.includes('total_del_prcnt')
										? 'Total'
										: nameChart.includes('new_origination_a')
										? 'Monthly New Origination'
										: nameChart === 'monthly_chargeoff'
										? 'Monthly Chargeoff $'
										: nameChart.includes('monthly_chargeoff_prcnt')
										? 'Monthly Chargeoff %'
										: nameChart === 'recovery'
										? 'Recovery $'
										: nameChart.includes('recovery_prcnt')
										? 'Recovery %'
										: nameChart === 'interest'
										? 'Interest'
										: nameChart === 'closing_balance'
										? 'Closing Balance'
										: nameChart === 'cumulative_curve'
										? 'Cumulative Default curve'
										: nameChart === 'timing_curve'
										? 'Cumulative Timing Curve'
										: nameChart === 'principal'
										? 'Principal'
										: nameChart
								}
								animationDuration={2000}
								strokeWidth={3}
							/>
						);
					})
				) : selectedScenario.length > 0 ? (
					selectedScenario.map((select, index) => {
						return (
							<Area
								key={index}
								type="monotone"
								dataKey={`Scenario_${select.scenario}`}
								stroke={'#1e76a9'}
								fill={'#e1eef7'}
								opacity={1}
								id={'index' + index}
								name={`Scenario_${select.scenario}`}
								animationDuration={2000}
								strokeWidth={3}
							/>
						);
					})
				) : (
					<Area
						type="monotone"
						dataKey={`Scenario_${defaultSelect}`}
						stroke={'#1e76a9'}
						fill={'#e1eef7'}
						opacity={1}
						id={'index' + defaultSelect}
						name={`Scenario_${defaultSelect}`}
						animationDuration={2000}
						strokeWidth={3}
					/>
				)}
				<Legend
					content={renderLegend}
					verticalAlign="top"
					height={0}
					align="center"
					iconSize={0}
					wrapperStyle={{
						color: primaryColor,
						fontSize: sizeLegend,
						fontWeight: 600,
						letterSpacing: 1
					}}
				/>
			</AreaChart>
		</ResponsiveContainer>
	);
};

export default Chart;
