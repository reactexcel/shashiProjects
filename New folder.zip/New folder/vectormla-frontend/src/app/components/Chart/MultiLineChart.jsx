import React, { PureComponent } from 'react';
import {
	AreaChart,
	Area,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	ResponsiveContainer,
	Legend,
	Brush,
	LineChart,
	Line
} from 'recharts';
import { primaryColor } from '../../../common/assets/layout';

const MultiLineChart = ({
	dataT,
	nameLegend,
	sizeLegend = '14px',
	brushID,
	dataX,
	xDistance,
	format
}) => {
	function getRandomColor() {
		let letters = '0123456789ABCDEF';
		let color = '#';
		for (let i = 0; i < 6; i++) {
			color += letters[Math.floor(Math.random() * 16)];
		}
		return color;
	}

	const formatYAxis = (tickItem) => {
		if (format) return +tickItem;
		else return +tickItem;
	};

	const formatXAxis = (tickItem) => {
		return <></>;
	};

	class CustomizedXAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			let dateStr = ('' + payload.value).split('-');
			return (
				<g transform={`translate(${x},${y})`}>
					<text x={5} y={0} dy={16} textAnchor="end" fontSize={14} fill="#666">
						{dateStr[0]}
					</text>
					<text x={5} y={15} dy={16} textAnchor="end" fontSize={14} fill="#666">
						{dateStr[1]}
					</text>
				</g>
			);
		}
	}

	class CustomizedYAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={-10}
						dy={16}
						textAnchor="end"
						fontSize={14}
						fill="#666"
					>
						{format === 'com'
							? Number(payload.value).toLocaleString()
							: `${payload.value} %`}
					</text>
				</g>
			);
		}
	}

	const renderTooltipContent = (o) => {
		const { payload, label } = o;
		return (
			<div style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
				<div style={{ fontSize: 10 }}>{`${label}`}</div>
				{payload.map((entry, index) => (
					<div
						key={`item-${index}1`}
						style={{ color: entry.color, fontSize: 10 }}
					>
						{`${entry.name} : ( ${Number(entry.value).toLocaleString()} )  `}
					</div>
				))}
			</div>
		);
	};

	const renderLegend = (props) => {
		const { payload } = props;
		return <div>{nameLegend}</div>;
	};

	return (
		<ResponsiveContainer width="100%" height="100%">
			<LineChart
				data={dataT}
				syncId={brushID}
				margin={{ top: 0, right: 0, left: 0, bottom: 30 }}
			>
				{/* <Brush dataKey={`${dataX}`} height={16} y={xDistance} fill="#fff" /> */}
				<XAxis
					tickLine={true}
					tickCount={11}
					tickSize={6}
					dataKey={`${dataX}`}
					type="category"
					interval={1}
					textAnchor="end"
					tick={<CustomizedXAxisTick />}
					label={{
						value: brushID === 'Default' ? 'x-axis' : 'Period',
						position: 'insideBottom',
						offset: -23
					}}
				/>
				<YAxis
					tickLine={true}
					tickCount={10}
					type="number"
					textAnchor="end"
					tickFormatter={formatYAxis}
					tick={<CustomizedYAxisTick />}
					label={{
						value: 'Cumulative Loss %',
						angle: -90,
						position: 'insideLeft',
						offset: 15,
						dy: 80
					}}
				/>
				<Tooltip content={renderTooltipContent} />
				{Object.keys(dataT[0]).map((line, index) => {
					if (index > 0)
						return (
							<Line
								type="monotone"
								key={index}
								dataKey={`${line}`}
								stroke={getRandomColor()}
								fill={getRandomColor()}
								// opacity={0.35}
								name={`${line}`}
								activeDot={false}
								animationDuration={2000}
								dot={false}
							/>
						);
				})}
				<Legend
					content={renderLegend}
					verticalAlign="top"
					height={50}
					align="center"
					iconSize={0}
					wrapperStyle={{
						color: primaryColor,
						fontSize: sizeLegend,
						fontWeight: 600,
						letterSpacing: 1
					}}
				/>
			</LineChart>
		</ResponsiveContainer>
	);
};

export default MultiLineChart;
