import { makeStyles } from '@material-ui/core';

export const useStyles = makeStyles((theme) => ({
	selectIcon: {
		width: 16,
		margin: '0 15px 0 10px',
		color: '#dbdcde',
		'&:hover': {
			cursor: 'pointer'
		}
	},
	dropdownContainer: {
		display: 'flex',
		alignItems: 'center',
		marginRight: 50,
		marginBottom: 3
	},
	dropdown: {
		color: '#000',
		width: 90,
		fontSize: '12px',
		fontFamily: 'Roboto'
	},
	btn: {
		textTransform: 'capitalize',
		height: 25,
		width: 75,
		marginBottom: 25,
		marginLeft: 0,
		borderRadius: 0,
		border: '2px solid #7991aa',
		backgroundColor: 'white',
		color: '#53687E !important',
		[theme.breakpoints.down('sm')]: {
			width: 65
		},
		'&:hover': {
			background: '#7991AA',
			backgroundColor: '#99a8b7',
			border: '1px solid #53687E',
			color: '#fff !important'
		},
		marginRight: 15
	},
	tableHeader: {
		height: 430,
		width: 1390,
		marginTop: 20,
		padding: 30
	}
}));
