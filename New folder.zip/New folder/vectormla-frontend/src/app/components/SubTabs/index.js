import SubTabs from './SubTabs';

export default SubTabs;
