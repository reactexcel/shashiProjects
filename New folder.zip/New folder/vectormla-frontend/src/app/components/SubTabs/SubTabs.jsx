import React, { useEffect } from 'react';
import { Tabs, Tab } from '@material-ui/core';
import {
	useTabsStyles,
	useTabStyles,
	useHoveredTabStyles
} from './subTabsStyles';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { useSelector } from 'react-redux';

const SubTabs = ({
	tabs,
	tabStyle,
	tabProps,
	history,
	// match,
	// location,
	// children,
	// subHeader,
	onChange,
	value,
	setValue,
	parentID
}) => {
	const tabsClasses = useTabsStyles();
	const tabClasses = useTabStyles({ ...tabProps, ...tabStyle });
	const hoverdTabClasses = useHoveredTabStyles();
	const user = useSelector((state) => state.auth.user);

	useEffect(() => {
		setValue(value);
	}, [tabs]);

	const handleChange = (event, newValue) => {
		setValue(newValue);
		onChange(event, newValue);
	};

	return (
		<div style={{ marginLeft: 3 }}>
			<Tabs classes={tabsClasses} value={value} onChange={handleChange}>
				{tabs
					.map((itemTab, index) => ({
						...itemTab,
						active:
							user && user[`allowed_section${parentID}`]
								? !user[`allowed_section${parentID}`]?.includes(itemTab.id)
								: // for tabs dashboard and library
								index === 0
								? true
								: false
					}))
					// for tabs dashboard and library
					.sort((a, b) =>
						[5, 6].includes(+parentID)
							? b.active - a.active
							: a.active - b.active
					)
					.map((tab, index) => {
						return (
							<Tab
								key={index}
								{...tabProps}
								{...tab}
								disabled={
									user && user[`allowed_section${parentID}`]
										? !user[`allowed_section${parentID}`]?.includes(tab?.id)
										: !tab.active
								}
								label={
									user && user[`allowed_section${parentID}`]
										? !user[`allowed_section${parentID}`]?.includes(tab?.id)
											? `sheet ${index + 1}`
											: tab?.label
										: // for tabs dashboard and library
										tab.active
										? tab?.label
										: `sheet ${index + 1}`
								}
								classes={index === value ? hoverdTabClasses : tabClasses}
								onClick={() => tab.link && history.push(`${tab.link}`)}
							/>
						);
					})}
			</Tabs>
		</div>
	);
};

SubTabs.propTypes = {
	tabs: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.node.isRequired
		})
	),
	tabStyle: PropTypes.shape({
		bgColor: PropTypes.string,
		minWidth: PropTypes.shape({})
	}),
	tabProps: PropTypes.shape({})
};

SubTabs.defaultProps = {
	tabs: [],
	tabStyle: {},
	tabProps: {}
};

export default withRouter(SubTabs);
