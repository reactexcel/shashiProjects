import React from 'react';
import { makeStyles, TextField } from '@material-ui/core';
import { Typography } from '@material-ui/core';
import { primaryColor } from '../../../common/assets/layout';

const root = {
	width: '100%',
	marginTop: '10px',
	'& label.Mui-focused': {
		color: primaryColor
	},
	'& .MuiOutlinedInput-root': {
		'&.Mui-focused fieldset': {
			borderColor: primaryColor
		}
	},
	'& .MuiInputLabel-outlined': {
		zIndex: 1,
		transform: 'translate(14px, 12px) scale(1)'
	},
	'& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
		transform: 'translate(14px, -6px) scale(0.75)',
		fontWeight: 600
	}
};

const useStyles = makeStyles((theme) => ({
	sidemenu__select__Field: {
		paddingTop: 20,
		color: primaryColor
	},
	sidemenu__select__Field_layr: {
		color: primaryColor
	},
	root: {
		...root
	},
	root_layr: {
		...root,
		marginTop: 0,
		padding: '5px 0'
	},
	header_select_input: {
		color: 'grey',
		marginTop: 0
	},
	header_select: {
		height: 32,
		fontSize: '0.875rem',
		fontFamily: 'Roboto',
		fontWeight: 500,
		lineHeight: 1.57,
		'& .MuiOutlinedInput-root': {
			maxHeight: '100%'
		}
	}
}));

const MuiTextField = ({ label, input, view, disabled, type = 'number' }) => {
	const classes = useStyles();
	return (
		<div
			className={
				view === 'sbs'
					? classes.sidemenu__select__Field
					: classes.sidemenu__select__Field_layr
			}
		>
			{view === 'sbs' && (
				<Typography style={{ float: 'left', fontSize: '12px' }}>
					{label}
				</Typography>
			)}
			<TextField
				type={type}
				disabled={disabled}
				variant="outlined"
				{...input}
				className={classes.header_select}
			/>
		</div>
	);
};

export default MuiTextField;
