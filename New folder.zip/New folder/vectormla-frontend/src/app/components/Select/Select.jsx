import React from 'react';
import { makeStyles } from '@material-ui/core';
import { Typography } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import { primaryColor } from '../../../common/assets/layout';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

const root = {
	width: 175,
	margin: '10px 0px',
	'& label.Mui-focused': {
		color: primaryColor
	},
	'& .MuiOutlinedInput-root': {
		'&.Mui-focused fieldset': {
			borderColor: primaryColor
		}
	},
	'& .MuiInputLabel-outlined': {
		zIndex: 1,
		transform: 'translate(14px, 12px) scale(1)'
	},
	'& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
		transform: 'translate(14px, -6px) scale(0.75)',
		fontWeight: 600
	},
	'& .MuiOutlinedInput-input': {
		padding: '5px 14px'
	},
	'& svg': {
		width: 16,
		height: 16,
		padding: 0,
		position: 'absolute',
		right: 10,
		top: 7.5,
		'&:hover': {
			color: primaryColor
		},
		cursor: 'pointer'
	}
};

const useStyles = makeStyles((theme) => ({
	sidemenu__select__Field: {
		paddingTop: 20,
		color: primaryColor
	},
	sidemenu__select__Field_layr: {
		color: primaryColor
	},
	root: {
		...root
	},
	root_layr: {
		...root,
		backgroundColor: '#f7f8fa'
	},
	header_select_input: {
		color: 'grey',
		marginTop: 0
	},
	header_select: {
		height: 25,
		fontSize: '11px',
		fontFamily: 'Roboto',
		fontWeight: 500,
		lineHeight: '1.18em',
		borderRadius: 0,
		'& .MuiSelect-select:focus': {
			backgroundColor: 'transparent'
		}
	}
}));

const MuiSelectField = (props) => {
	let {
		label,
		input,
		children,
		value,
		view,
		native = true,
		disabled,
		change,
		onChange,
		defaultValue
	} = props;
	const classes = useStyles();

	const menuProps = {
		PaperProps: {
			style: {
				backgroundColor: '#fff',
				position: 'fixed',
				zIndex: 9999,
				maxHeight: 150,
				marginTop: 30
			}
		},
		style: {
			maxHeight: 150,
			maxWidth: 175
		}
	};

	return (
		<div
			className={
				view === 'sbs'
					? classes.sidemenu__select__Field
					: classes.sidemenu__select__Field_layr
			}
		>
			{view === 'sbs' && (
				<Typography
					style={{ float: 'left', fontSize: '12px', fontFamily: 'Roboto' }}
				>
					{label}
				</Typography>
			)}
			<FormControl
				disabled={disabled}
				className={view === 'sbs' ? classes.root : classes.root_layr}
			>
				<Select
					{...input}
					renderValue={(selected) => (
						<div style={{ position: 'relative' }}>
							<div>{selected}</div>
						</div>
					)}
					onChange={change || onChange}
					native={native}
					variant="outlined"
					value={value || defaultValue}
					defaultValue={defaultValue}
					labelWidth={0}
					className={classes.header_select}
					IconComponent={() => <ExpandMoreIcon />}
					MenuProps={menuProps}
				>
					{children}
				</Select>
			</FormControl>
		</div>
	);
};

export default MuiSelectField;
