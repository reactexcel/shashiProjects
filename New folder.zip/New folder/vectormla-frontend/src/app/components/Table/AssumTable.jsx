import React, { useState, useEffect } from 'react';
import {
	TableContainer,
	Select,
	Divider,
	CircularProgress,
	Input
} from '@material-ui/core';
import { useStyles } from './tableStyles';
import { MinusSquare, PlusSquare } from '../AssestFunctions/assestFun';
import { cashFlowSelect, fpnaSelect, selectGroup } from '../../helpers/Fields';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import downArrow from '../../../common/assets/vector/images/arrow.svg';

const AssumTable = ({
	data,
	scenariosNames,
	saveContent,
	onSave,
	tableId,
	tableName,
	type,
	collapsed
}) => {
	const classes = useStyles();
	const [state, setState] = useState(
		type === 'fpna'
			? { General: false, 'FP&A': false, 'Income Statement': false }
			: {
					Credit: false,
					Prepayment: false,
					'Senior Debt': false,
					'Sub Debt': false,
					Terms: false,
					Swaps: false
			  }
	);
	const [activeCell, setActiveCell] = useState(null);
	const [activeSection, setActiveSection] = useState(null);
	const [tableVisible, setTableVisible] = useState(null);
	const [scenarios, setSenarios] = useState(data && data[0]?.scenarios);
	const [changedScenarios, setChangedScenarios] = useState([]);
	const [editedValues, setEditedValues] = useState(generateFormData);

	useEffect(() => {
		if (saveContent) {
			let savedScenarios = changedScenarios.map((key) => scenarios[key]);
			onSave(savedScenarios);
			setChangedScenarios([]);
		}
		if (data !== scenarios) setSenarios(data && data[0]?.scenarios);
		if (collapsed >= 1) {
			setTableVisible(true);
		} else if (collapsed === 0 && tableVisible) {
			setTableVisible(false);
		}
	}, [saveContent, scenarios, data, collapsed]);

	function generateFormData() {
		let form = {};
		const list = scenarios?.map((x) => {
			let scenario = {
				...x.assumption.parameters,
				...x.assumption.parameters.main_params,
				...x.assumption.parameters.income_statement_params,
				...x.assumption.parameters.fpna_params
			};
			return scenario;
		});
		if (list)
			for (let i = 0; i < scenariosNames.length; i++) {
				form[`${scenariosNames[i]}`] = list[i];
			}

		return form;
	}
	const handleChange = (newValue, key, scenario, index, subAssm) => {
		setEditedValues({
			...editedValues,
			[`${scenario}`]: {
				...editedValues[`${scenario}`],
				[`${key}`]: newValue
			}
		});
		let updatedScenarios = scenarios;
		updatedScenarios[index].assumption[subAssm][key] = checkType(newValue);
		setSenarios(updatedScenarios);
		let changes = changedScenarios;
		if (!(index in changes)) changes.push(index);
		setChangedScenarios(changes);
	};

	const checkType = (value) => {
		if (!isNaN(value)) {
			if (value % 1 === 0) {
				return parseInt(value);
			} else {
				return parseFloat(value);
			}
		} else {
			return value;
		}
	};

	const handleCellHover = (headIndex, subSectionName) => {
		setActiveCell(tableId + headIndex);
		setActiveSection(subSectionName);
	};

	const handleCellLeave = () => {
		setActiveCell(null);
	};

	const toggleSubSections = (subSectionName) => {
		setState({ ...state, [`${subSectionName}`]: !state[`${subSectionName}`] });
	};

	const renderMainSection = (sectionName) => (
		<tr className={classes.table__row_darkGray}>
			<td
				className={classes.table__cell_head_dark_static}
				style={{
					fontWeight: 700,
					display: 'flex',
					alignItems: 'center',
					paddingLeft: 0
				}}
			>
				<span
					style={{
						height: '100%',
						display: 'inline-block',
						marginRight: 6
					}}
				></span>
				{sectionName}
			</td>
			{scenariosNames &&
				scenariosNames.map((scenariosName, index) => (
					<td key={index} className={classes.table__cell_static}></td>
				))}
		</tr>
	);

	const renderSubMainSection = (subSectionName) => (
		<>
			<tr className={classes.table__row_darkGray}>
				<td
					className={classes.table__cell_head_dark_static}
					style={{ display: 'flex', alignItems: 'center', paddingLeft: 0 }}
				>
					<span
						style={{
							width: 6,
							height: '100%',
							display: 'inline-block'
						}}
					></span>
					{state[`${subSectionName}`] ? (
						<MinusSquare
							onClick={() => toggleSubSections(subSectionName)}
							className={classes.icon}
							style={{
								width: 14,
								height: 14,
								marginBottom: 4
							}}
						/>
					) : (
						<PlusSquare
							onClick={() => toggleSubSections(subSectionName)}
							className={classes.icon}
							style={{
								width: 14,
								height: 14,
								marginBottom: 4
							}}
						/>
					)}
					{subSectionName}
				</td>
				{scenariosNames &&
					scenariosNames.map((scenariosName, index) => (
						<td key={index} className={classes.table__cell_static}></td>
					))}
			</tr>
		</>
	);

	const renderElementsSection = (
		subSelectGroup,
		subAssumption,
		subSectionName
	) => (
		<>
			{state[`${subSectionName}`] &&
				selectGroup[`${subSelectGroup}`]?.map((row, headIndex) => {
					const selectInput =
						type === 'fpna'
							? fpnaSelect.filter((item, index) => item.name === row)[0]
							: cashFlowSelect.filter((item, index) => item.name === row)[0];
					return (
						<tr
							className={
								headIndex % 2 === 0
									? classes.table__row_white
									: classes.table__row_lightGray
							}
							key={headIndex}
						>
							<td
								className={
									headIndex === activeCell - tableId &&
									subSectionName === activeSection
										? classes.table__cell_head_active
										: headIndex % 2 === 0
										? classes.table__cell_head_white
										: classes.table__cell_head_light
								}
								style={{ paddingLeft: 38 }}
								key={row}
							>
								{selectInput.label}
							</td>
							{/* generate row */}
							{scenariosNames &&
								scenariosNames.map((name, index) => {
									const col = scenarios.filter(
										(scenario) => scenario.name === name
									);
									return (
										<td
											key={index}
											onMouseEnter={(e) =>
												handleCellHover(headIndex, subSectionName)
											}
											onMouseLeave={(e) => handleCellLeave()}
											className={`${classes.table__cell}`}
										>
											<div>
												{selectInput.type === 'select' ? (
													<Select
														onChange={(e) =>
															handleChange(
																e.target.value,
																row,
																name,
																index,
																subAssumption
															)
														}
														disableUnderline
														IconComponent={() => (
															<ArrowDropDownIcon
																style={{ fillOpacity: 0, width: 2, height: 2 }}
															/>
														)}
														native
														className={classes.assumTable_select}
														value={
															(editedValues[`${name}`] &&
																editedValues[`${name}`][`${row}`]) ||
															col[0]?.assumption?.[`${subAssumption}`][`${row}`]
														}
													>
														{selectInput.items?.map((item, index) => (
															<option key={index} value={item.value}>
																{item.label}
															</option>
														))}
													</Select>
												) : (
													<Input
														className={classes.assumTable_select}
														value={
															(editedValues[`${name}`] &&
																editedValues[`${name}`][`${row}`]) ||
															col[0]?.assumption?.[`${subAssumption}`][
																`${row}`
															] ||
															selectInput.default
														}
														onChange={(e) =>
															handleChange(
																e.target.value,
																row,
																name,
																index,
																subAssumption
															)
														}
														disableUnderline={true}
													/>
												)}
											</div>
										</td>
									);
								})}
						</tr>
					);
				})}
		</>
	);

	const renderCashFlow = () => (
		<>
			{/* ASSET ==> Main Section <== */}
			{renderMainSection('Asset')}
			{/* Credit ==> Main SUB Section <== */}
			{renderSubMainSection('Credit')}
			{/* Credit ==> Elements */}
			{renderElementsSection('defaultInput', 'parameters', 'Credit')}

			{/* prepayment ==> Main SUB Section <== */}
			{renderSubMainSection('Prepayment')}
			{/* prepayment ==> Elements */}
			{renderElementsSection('prepayment', 'parameters', 'Prepayment')}

			{/* interest ==> Main SUB Section <==
            {renderSubMainSection("X")} */}
			{/* interest ==> Elements */}
			{renderElementsSection('intrest', 'parameters', 'X')}

			{/* Liability ==> Main Section <== */}
			{renderMainSection('Liability')}
			{/* senior debt ==> Main SUB Section <== */}
			{renderSubMainSection('Senior Debt')}
			{/* senior debt ==> Elements */}
			{renderElementsSection('advancedRate', 'senior_debt', 'Senior Debt')}

			{/* sub debt ==> Main SUB Section <== */}
			{renderSubMainSection('Sub Debt')}
			{/* sub debt ==> Elements */}
			{renderElementsSection('subDebt', 'sub_loan', 'Sub Debt')}

			{/* Structural ==> Main Section <== */}
			{renderMainSection('Structural')}
			{/* terms ==> Main SUB Section <== */}
			{renderSubMainSection('Terms')}
			{/* terms ==> Elements */}
			{renderElementsSection('triggers', 'structural_inputs', 'Terms')}

			{/* swaps ==> Main SUB Section <== */}
			{renderSubMainSection('Swaps')}
			{/* swaps ==> Elements */}
			{renderElementsSection('swap', 'structural_inputs', 'Swaps')}
		</>
	);

	const renderFpna = () => (
		<>
			{renderSubMainSection('General')}
			{renderElementsSection('fpnaGeneral', 'main_params', 'General')}

			{renderSubMainSection('Income Statement')}
			{renderElementsSection(
				'fpnaIncomeStatement',
				'income_statement_params',
				'Income Statement'
			)}
			{renderSubMainSection('FP&A')}
			{renderElementsSection('fpna', 'fpna_params', 'FP&A')}
		</>
	);

	return (
		<div>
			<div
				className={[classes.contentHeaderContainer]}
				onClick={() => {
					setTableVisible(!tableVisible);
				}}
			>
				<p className={classes.contentHeader}>{tableName}</p>
				<img alt="icon" src={downArrow} style={{ justifyContent: 'center' }} />
			</div>
			<Divider className={classes.tableDivider} />
			{tableVisible &&
				(data ? (
					<TableContainer className={classes.table__container}>
						<table
							className={classes.table}
							size="small"
							aria-label="a dense table"
						>
							<tbody>
								{/* Scenarios Names Row */}
								<tr className={classes.table__row_white}>
									<td className={classes.table__cell_head_white}></td>
									{scenariosNames &&
										scenariosNames.map((scenariosName, index) => (
											<td
												key={index}
												className={classes.table__cell}
												onMouseLeave={(e) => handleCellLeave()}
												onMouseEnter={(e) =>
													handleCellHover(index, (e.pageY - 60) / 20)
												}
											>
												<div>{scenariosName}</div>
											</td>
										))}
								</tr>
								{type !== 'fpna' ? renderCashFlow() : renderFpna()}
							</tbody>
						</table>
					</TableContainer>
				) : (
					<center>
						<CircularProgress style={{ color: '#266696' }} size={26} />
					</center>
				))}
		</div>
	);
};
export default AssumTable;
