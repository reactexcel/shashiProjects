export const CustomisedDownloadDataFields = {
	'Loan Data': ['2', '', 'loanmodel/', '?orient=split&download=1', ''],
	'Origination Pipeline': [
		'2',
		'',
		'pipelinevectors/',
		'?orient=split&dltable=pipelinevectors',
		''
	],
	'Historical Portfolio': [
		'2',
		'',
		'portfolio-vintage/',
		'?dltable=vintage_portfolio',
		''
	],
	'Asset Amortization - Current': [
		'2',
		'',
		'output-breakdown/',
		'loandata/',
		'?dltable=assetamort_breakdown1'
	],
	'Asset Amortization - Delinquent': [
		'2',
		'',
		'output-breakdown/',
		'delinquent/',
		'?dltable=assetamort_breakdown3'
	],
	'Asset Amortization - Forecast': [
		'2',
		'',
		'output-breakdown/',
		'pipeline/',
		'?dltable=assetamort_breakdown'
	],
	'Asset Amortization - Consolidated': [
		'2',
		'',
		'output-breakdown/',
		'?dltable=assetamort_breakdown2',
		''
	],
	'Equity Requirement - Current': [
		'2',
		'',
		'output-breakdown/',
		'loandata/',
		'?dltable=equity_requirement1'
	],
	'Equity Requirement - Forecast': [
		'2',
		'',
		'output-breakdown/',
		'pipeline/',
		'?dltable=equity_requirement0'
	],
	'Equity Requirement - Consolidated': [
		'2',
		'',
		'output-breakdown/',
		'?dltable=equity_requirement2',
		''
	],
	'Income Statement - Current': [
		'2',
		'',
		'output-breakdown/',
		'loandata/',
		'?dltable=incomestatement1'
	],
	'Income Statement - Forecast': [
		'2',
		'',
		'output-breakdown/',
		'pipeline/',
		'?dltable=incomestatement0'
	],
	'Income Statement - Consolidated': [
		'2',
		'',
		'output-breakdown/',
		'?dltable=incomestatement2',
		''
	],
	'Current Portfolio - Income Statement Support Schedule': [
		'2',
		'',
		'output-breakdown/',
		'loandata/',
		'?dltable=issuportschedule1'
	],
	'Forecast Portfolio - Income Statement Support Schedule': [
		'2',
		'',
		'output-breakdown/',
		'pipeline/',
		'?dltable=issuportschedule'
	],
	'Consolidated Portfolio - Income Statement Support Schedule': [
		'2',
		'',
		'output-breakdown/',
		'?dltable=issuportschedule2',
		''
	],
	'Roll Rates Schedule 1': [
		'2',
		'',
		'bucket-analysis/',
		'?dltable=bucket_analysis',
		''
	],
	'Roll Rates Schedule 2': [
		'2',
		'',
		'bucket-analysis1/',
		'?dltable=bucket_analysis1',
		''
	],
	'Roll Rates Schedule 3': ['2', '', 'roll-rate/', '?dltable=roll_rate', ''],
	'12 Month Average Roll Rate': [
		'2',
		'',
		'roll-rate-ave/',
		'?dltable=roll_rate_ave',
		''
	],
	'Equity Requirement - Delinquent': [
		'2',
		'',
		'output-breakdown/',
		'delinquent/',
		'?dltable=equity_requirement3'
	],
	'Income Statement - Delinquent': [
		'2',
		'',
		'output-breakdown/',
		'delinquent/',
		'?dltable=incomestatement3'
	],
	'Income Statement - Consolidated - Actual': [
		'2',
		'',
		'output-breakdown/',
		'?dltable=incomestatement_overheaddiff',
		''
	],
	'Outstanding Portfolio as % of Origination': [
		'2',
		'',
		'default-vintage-summary/',
		'?dltable=outstanding_df',
		''
	],
	'Cumulative Charge-off': [
		'2',
		'',
		'default-vintage-summary/',
		'?dltable=cumulative_chargeoff_df',
		''
	],
	'Cumulative Charge-off - Net of Recovery': [
		'2',
		'',
		'default-vintage-summary/',
		'?dltable=cumulative_chargeoff_netrecovery_df',
		''
	],
	'Monthly Charge-off': [
		'2',
		'',
		'default-vintage-summary/',
		'?dltable=monthly_chargeoff_df',
		''
	],
	'Monthly Charge-off Net of Recovery': [
		'2',
		'',
		'default-vintage-summary/',
		'?dltable=monthly_chargeoff_netrecovery_df',
		''
	],
	Vintage: ['2', '', 'default-vintage/', '?dltable=vintage_df', ''],
	'Balance Sheet': ['5', '', 'balancesheet/', '?dltable=balancesheet', ''],
	'Demand Deposits': [
		'5',
		'',
		'demand_deposits_currentbook/',
		'?dltable=demand_deposits_currentbook',
		''
	],
	'Term Deposits Current Book': [
		'5',
		'',
		'term_deposits_currentbook/',
		'?dltable=term_deposits_currentbook',
		''
	],
	'Interest Rate Vectors': [
		'5',
		'',
		'rate_new_values/',
		'?dltable=rate_new_values',
		''
	],
	'Term Deposits New': [
		'5',
		'',
		'term_deposits_new/',
		'?dltable=term_deposits_new',
		''
	],
	'Term Deposits Consolidated': [
		'5',
		'',
		'term_deposits_consolidated/',
		'?dltable=term_deposits_consolidated',
		''
	],
	'Historical Swaps': [
		'5',
		'',
		'historical_swap_table/',
		'?dltable=historical_swap_table',
		''
	],
	' Balance Sheet ': ['5', '', 'eve_table/', '?dltable=eve_table', ''],
	'PV Duration Convexity - Consolidated': [
		'5',
		'',
		'duration_consolidated_table/',
		'?dltable=duration_consolidated_table',
		''
	],
	'PV Duration Convexity - Pipeline': [
		'5',
		'',
		'duration_pipeline_table/',
		'?dltable=duration_pipeline_table',
		''
	],
	'PV Duration Convexity - Current': [
		'5',
		'',
		'duration_current_table/',
		'?dltable=duration_current_table',
		''
	],
	Rates: ['5', '', 'swap_table/', '?dltable=swap_table', ''],
	'Asset Amortization Consolidated': [
		'5',
		'',
		'assetamort_table/',
		'?dltable=assetamort_table',
		''
	],
	'Asset Amortization Pipeline': [
		'5',
		'',
		'assetamort_table_pipeline/',
		'?dltable=assetamort_table_pipeline',
		''
	],
	'Asset Amortization Pipeline Broker Mix': [
		'5',
		'',
		'assetamort_table_brokermix/',
		'?dltable=assetamort_table_brokermix',
		''
	],
	'Asset Amortization Current': [
		'5',
		'',
		'assetamort_table_current/',
		'?dltable=assetamort_table_current',
		''
	],
	'Other Liability - Accrued Interest': [
		'5',
		'',
		'ol_accrued_interest/',
		'?dltable=ol_accrued_interest',
		''
	],
	'Rate Analysis - Consolidated': [
		'5',
		'',
		'rate_analysis/',
		'?dltable=rate_analysis',
		''
	],
	'Rate Analysis - Current': [
		'5',
		'',
		'rate_analysis_current/',
		'?dltable=rate_analysis_current',
		''
	],
	'Rate Analysis - Pipeline': [
		'5',
		'',
		'rate_analysis_pipeline/',
		'?dltable=rate_analysis_pipeline',
		''
	],
	'Income Statement': [
		'5',
		'',
		'income_statement/',
		'?dltable=income_statement',
		''
	],
	'Amort Continuity Consolidated': [
		'5',
		'',
		'amort_continuity_compact/',
		'?dltable=amort_continuity_compact',
		''
	],
	'Amort Continuity Current': [
		'5',
		'',
		'amort_continuity_current_compact/',
		'?dltable=amort_continuity_current_compact',
		''
	],
	'Amort Continuity Pipeline': [
		'5',
		'',
		'amort_continuity_pipeline_compact/',
		'?dltable=amort_continuity_pipeline_compact',
		''
	],
	'Investment Support Schedule': [
		'5',
		'',
		'investment_supportschedule/',
		'?dltable=investment_supportschedule',
		''
	],
	'Product Cost Schedule': [
		'5',
		'',
		'product_cost_schedule/',
		'?dltable=product_cost_schedule',
		''
	],
	'Funding Pipeline': [
		'5',
		'',
		'pipelinevectors/',
		'?dltable=pipelinevectors',
		''
	],
	'Pipeline Support Schedule': [
		'5',
		'',
		'pipeline_supportschedule/',
		'?dltable=pipeline_supportschedule',
		''
	],
	'Risk Weighted Asset': ['5', '', 'rwa/', '?dltable=rwa', ''],
	'Risk Weighted Asset-TBSM': ['5', '', 'rwa_tbsm/', '?dltable=rwa', ''],
	'Deposit Matrix': ['5', '', 'deposit_matrix/', '?dltable=deposit_matrix', ''],
	'NII Table': ['5', '', 'nii_table/', '?dltable=nii_table', ''],
	'NII Schedule': ['5', '', 'nii_schedule/', '?dltable=nii_schedule', ''],
	'Loan Origination Fee': [
		'5',
		'',
		'loanorigination_supportschedule/',
		'?dltable=loanorigination_supportschedule',
		''
	],
	'Other Asset - Accrued Interest Support Schedule': [
		'5',
		'',
		'oa_accrued_interest/',
		'?dltable=oa_accrued_interest',
		''
	],
	'Mortgage Broker Commission': [
		'5',
		'',
		'mtgcommission_supportschedule/',
		'?dltable=mtgcommission_supportschedule',
		''
	],
	'Deposits Broker Commission': [
		'5',
		'',
		'giccommission_supportschedule/',
		'?dltable=giccommission_supportschedule',
		''
	],
	'Derivative Swap': [
		'5',
		'',
		'derivative_swap/',
		'?dltable=derivative_swap',
		''
	],
	ECL: ['5', '', 'ecl/', '?dltable=ecl', ''],
	'Projected Portfolio Daily': [
		'6',
		'',
		'daily_assetamort_table/',
		'?dltable=daily_assetamort_table',
		''
	],
	'Projected Portfolio Weekly': [
		'6',
		'',
		'weekly_assetamort_table/',
		'?dltable=weekly_assetamort_table',
		''
	],
	'Projected Portfolio Monthly': [
		'6',
		'',
		'assetamort_table/',
		'?dltable=assetamort_table',
		''
	],
	'Ineligible Receivables Monthly': [
		'6',
		'',
		'wh_ineligible/',
		'?dltable=wh_ineligible',
		''
	],
	'Ineligible Receivables Weekly': [
		'6',
		'',
		'wh_ineligible_weekly/',
		'?dltable=wh_ineligible_weekly',
		''
	],
	'Ineligible Receivables Daily': [
		'6',
		'',
		'wh_ineligible_daily/',
		'?dltable=wh_ineligible_daily',
		''
	],
	'Excess Concentration Limits': [
		'6',
		'',
		'excess_concentration_limits/',
		'?dltable=excess_concentration_limits',
		''
	],
	'Historical Portfolio Daily': [
		'6',
		'',
		'historical_daily_assetamort_table/',
		'?dltable=historical_daily_assetamort_table',
		''
	],
	'Loan Pricing': ['6', '', 'loan_pricing/', '?dltable=loan_pricing', ''],
	'Loan Pricing ': ['6', '', 'loan_pricing/', '?dltable=loan_pricing', ''],
	'Loan Pricing  ': ['9', '', 'loan_pricing/', '?dltable=loan_pricing', ''],
	'Historical Portfolio Weekly': [
		'6',
		'',
		'historical_weekly_assetamort_table/',
		'?dltable=historical_weekly_assetamort_table',
		''
	],
	'Historical Portfolio Monthly': [
		'6',
		'',
		'historical_monthly_assetamort_table/',
		'?dltable=historical_monthly_assetamort_table',
		''
	],
	'Borrowing Base Monthly': [
		'6',
		'',
		'borrowing_base/',
		'?dltable=borrowing_base',
		''
	],
	'Borrowing Base Weekly': [
		'6',
		'',
		'borrowing_base_weekly/',
		'?dltable=borrowing_base_weekly',
		''
	],
	'Borrowing Base Daily': [
		'6',
		'',
		'borrowing_base_daily/',
		'?dltable=borrowing_base_daily',
		''
	],
	'Interest Paid by Borrower Monthly': [
		'6',
		'',
		'interest_paid_by_borrower/',
		'?dltable=interest_paid_by_borrower',
		''
	],
	'Interest Paid by Borrower Weekly': [
		'6',
		'',
		'interest_paid_by_borrower_weekly/',
		'?dltable=interest_paid_by_borrower_weekly',
		''
	],
	'Interest Paid by Borrower Daily': [
		'6',
		'',
		'interest_paid_by_borrower_daily/',
		'?dltable=interest_paid_by_borrower_daily',
		''
	],
	'Default Vintage': ['6', '', 'df_cohort/', '?dltable=df_cohort', ''],
	'Static Pool Analysis': [
		'6',
		'',
		'df_origination/',
		'?dltable=df_origination',
		''
	],
	'Available Cash Daily': [
		'6',
		'',
		'daily_available_cash/',
		'?dltable=daily_available_cash',
		''
	],
	'Available Cash Monthly': [
		'6',
		'',
		'available_cash/',
		'?dltable=available_cash',
		''
	],
	'Cashflow Statement': [
		'6',
		'',
		'cashflow_statement/',
		'?dltable=cashflow_statement',
		''
	],
	'Balance Sheet ': ['6', '', 'balance_sheet/', '?dltable=balance_sheet', ''],
	'Income Statement ': [
		'6',
		'',
		'income_statement/',
		'?dltable=income_statement',
		''
	],
	'Bad Debt Support Schedule': [
		'6',
		'',
		'baddebt_expense/',
		'?dltable=baddebt_expense',
		''
	],
	'Projected Portfolio Run-off': [
		'6',
		'',
		'assetamort_table_current/',
		'?dltable=assetamort_table_current',
		''
	],
	'Projected Portfolio Run-on': [
		'6',
		'',
		'assetamort_table_pipeline/',
		'?dltable=assetamort_table_pipeline',
		''
	],
	'Historical SOFR Rates': [
		'6',
		'',
		'historical_sofr_rate/',
		'?dltable=historical_sofr_rate',
		''
	],
	'SOFR Forward Rates': [
		'6',
		'',
		'forward_rates/',
		'?dltable=forward_rates',
		''
	],
	'Forward Rates ': ['9', '', 'forward_rates/', '?dltable=forward_rates', ''],
	'SOFR Projected Rates': [
		'6',
		'',
		'projected_rates_table/',
		'?dltable=projected_rates_table',
		''
	],
	'Projected Rates ': [
		'5',
		'',
		'projected_rates_table/',
		'?dltable=projected_rates_table',
		''
	],
	'NI - Scenario Shocks': [
		'6',
		'',
		'shock_net_income/',
		'?dltable=shock_net_income',
		''
	],
	'PV and Duration': [
		'6',
		'',
		'duration_consolidated_table/',
		'?dltable=duration_consolidated_table',
		''
	],
	'Prepayment Curve Summary': [
		'6',
		'',
		'summary_output/',
		'?dltable=summary_output',
		''
	],
	'Prepayment Curve Percent': [
		'6',
		'',
		'summary_table_prcnt/',
		'?dltable=summary_table_prcnt',
		''
	],
	'Outstanding Portfolio as % of Origination ': [
		'6',
		'',
		'outstanding_df/',
		'?dltable=outstanding_df',
		''
	],
	'Cumulative Charge-off ': [
		'6',
		'',
		'cumulative_chargeoff_df/',
		'?dltable=cumulative_chargeoff_df',
		''
	],
	'Cumulative Charge-off - Net of Recovery ': [
		'6',
		'',
		'cumulative_chargeoff_netrecovery_df/',
		'?dltable=cumulative_chargeoff_netrecovery_df',
		''
	],
	'Monthly Charge-off ': [
		'6',
		'',
		'monthly_chargeoff_df/',
		'?dltable=monthly_chargeoff_df',
		''
	],
	'Monthly Charge-off Net of Recovery ': [
		'6',
		'',
		'monthly_chargeoff_netrecovery_df/',
		'?dltable=monthly_chargeoff_netrecovery_df',
		''
	],
	'Credit Historical Analysis': [
		'6',
		'',
		'vintage_df/',
		'?dltable=vintage_df',
		''
	],
	'12-Month Average Roll Rate': [
		'6',
		'',
		'roll_rate_ave/',
		'?dltable=roll_rate_ave',
		''
	],
	'Roll Rates Schedule 1 ': [
		'6',
		'',
		'bucket_analysis/',
		'?dltable=bucket_analysis',
		''
	],
	'Roll Rates Schedule 2 ': [
		'6',
		'',
		'bucket_analysis1/',
		'?dltable=bucket_analysis1',
		''
	],
	'Roll Rates Schedule 3 ': ['6', '', 'roll_rate/', '?dltable=roll_rate', ''],
	'Weighted Average Curve': [
		'6',
		'',
		'weighted_average_curve/',
		'?dltable=weighted_average_curve',
		''
	],
	'Loss Distribution': [
		'6',
		'',
		'loss_distribution/',
		'?dltable=loss_distribution',
		''
	]
};
