import React, { useState } from 'react';
import InfoIcon from '@material-ui/icons/Info';
import { Divider, IconButton } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import { useStyles } from '../contentContainer/contentContainerStyle';
import { useStyles as mainUseStyles } from './tableStyles';

import {
	MinusSquare,
	PlusSquare
} from '../../components/AssestFunctions/assestFun';
import MainTable from '../Table/MainTable';
import downArrow from '../../../common/assets/vector/images/arrow.svg';
import _ from 'lodash';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { useEffect } from 'react';

const DoubleTable = ({
	desc,
	header,
	content,
	tableLeftAlign,
	collapsed,
	mainheader,
	maindata,
	mainattributes,
	maintableId,
	mainfetchData,
	maindownload
}) => {
	const classes = useStyles();
	const mainClasses = mainUseStyles();

	const [visible, setVisible] = useState(false);
	const [showDesc, setShowDesc] = useState(false);

	const filterHeaderExist = Object.keys(
		content.filter((item, i) => item.header)
	);
	let stateKeys = {};
	filterHeaderExist.map((item) => (stateKeys[item] = false));

	const [state, setState] = useState(stateKeys);

	const transpose = (array) => {
		return array[0].map((_, c) => {
			return array.map((r) => {
				return r[c];
			});
		});
	};

	const exportToCSV = (csvData, header, fileName) => {
		let selectedHeader = [];
		let selectedData = [];
		header.forEach((head, headIndex) => {
			if (
				csvData &&
				csvData[0] &&
				Object.keys(csvData[0]).includes(mainattributes[headIndex])
			)
				selectedHeader.push(head);
		});
		csvData.forEach((item) => {
			selectedData.push(Object.values(_.pick(item, mainattributes)));
		});

		let excelData = JSON.parse(
			JSON.stringify(
				selectedData.table ? selectedData.table.rows : selectedData
			)
		);
		excelData.unshift(selectedHeader);

		excelData = excelData?.map((e) =>
			e.map((i) => {
				return !isNaN(i)
					? +i
					: !isNaN(i.replace(',', ''))
					? +i.replace(',', '')
					: !isNaN(i.replace('%', ''))
					? { v: +i.replace('%', '') / 100, t: 'n', z: '0.00%' }
					: i;
			})
		);

		excelData = transpose(excelData);
		const ws = XLSX.utils.json_to_sheet(excelData, {
			skipHeader: true
		});
		const wb = { Sheets: { data: ws }, SheetNames: ['data'] };
		const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
		const data = new Blob([excelBuffer], {
			type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
		});
		FileSaver.saveAs(data, fileName + '.xlsx');
	};

	useEffect(() => {
		if (collapsed >= 1) {
			setVisible(true);
		} else if (collapsed === 0 && visible) {
			setVisible(false);
		}
	}, [collapsed]);
	const handleStateChange = (key) =>
		setState({
			...state,
			[`${key}`]: !state[`${key}`]
		});

	return (
		<div>
			<div
				className={classes.contentHeaderContainer}
				onClick={() => {
					setVisible(!visible);
				}}
			>
				<p className={classes.contentHeader}>{header}</p>
				<div
					onMouseEnter={() => setShowDesc(true)}
					onMouseLeave={() => setShowDesc(false)}
				>
					<InfoIcon className={mainClasses.selectIcon} />
				</div>
				<img src={downArrow} alt="down-arrow" />
				<div
					className={mainClasses.popupContainer}
					style={{
						marginLeft: 50,
						marginTop: -50,
						display: showDesc ? 'block' : 'none'
					}}
				>
					<p className={mainClasses.popupText}>{desc || header}</p>
				</div>
			</div>
			{maindownload && (
				<IconButton
					style={{
						opacity: 0.5,
						position: 'absolute',
						right: '3.6%',
						marginTop: -37
					}}
					onClick={() => maindata && exportToCSV(maindata, mainheader, header)}
				>
					<GetAppIcon style={{ width: 20, height: 20 }} />
				</IconButton>
			)}
			<Divider style={{ marginBottom: 20 }} />
			{visible && (
				<div>
					<div>
						<MainTable
							header={mainheader}
							data={maindata}
							attributes={mainattributes}
							tableId={maintableId}
							fetchData={mainfetchData}
							disableHeader
							onLeft={tableLeftAlign}
						/>
						{content.map((section, i) => (
							<div key={`con-${i}`} style={i == 0 ? { marginTop: '1rem' } : {}}>
								{section.header && (
									<div style={{ display: 'flex', marginTop: '5px' }}>
										{state[i] ? (
											<MinusSquare
												className={classes.headerIcon}
												onClick={() => handleStateChange(i)}
											/>
										) : (
											<PlusSquare
												className={classes.headerIcon}
												onClick={() => handleStateChange(i)}
											/>
										)}
										<p className={classes.header}>{section.header}</p>
									</div>
								)}
								{(!section.header || state[i]) && (
									<div>
										{section.details && (
											<MainTable
												header={section.details.header}
												data={section.details.data}
												attributes={section.details.attributes}
												tableId={section.details.tableId}
												key={section.details.key}
												disableHeader
												onLeft={tableLeftAlign}
											/>
										)}
									</div>
								)}
							</div>
						))}
					</div>
				</div>
			)}
		</div>
	);
};
export default DoubleTable;
