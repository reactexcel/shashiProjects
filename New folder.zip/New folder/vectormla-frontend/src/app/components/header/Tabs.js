const emptyTabs = {
	link: '/app/analysis',
	subtabs: [
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	]
};

export const tabs = [
	{
		id: 0,
		label: 'Home',
		links: [],
		link: '/app/homepage',
		content: {
			Home: {
				link: '/app/homepage',
				subtabs: [{ label: 'Home', link: '', id: 1 }]
			}
		},
		subtabs: []
	},
	{
		id: 1,
		// link: '/app/cashflow',
		link: '/app/5-1-1',

		links: [
			// '/app/cashflow',
			// '/app/cashflow2',
			// '/app/default',
			// '/app/cashflow4',
			// '/app/prepayment',
			'/app/1-1-8',
			'/app/5-1-1-0',
			'/app/5-1-1',
			'/app/6-1-1',
			'/app/9-1-1'
		],
		label: 'Treasury',
		content: {
			'1.1 Cash Flow Projections & Analytics': {
				// link: '/app/cashflow',
				link: '/app/5-1-1',

				subtabs: [
					// { label: '1.1.1', link: '/app/cashflow', id: 101 },
					// { label: '1.1.2 Cashflow', link: '/app/cashflow2', id: 102 },
					// { label: '1.1.3', link: '/app/default', id: 103 },
					// { label: '1.1.4', link: '/app/cashflow4', id: 104 },
					// { label: '1.1.8', link: '/app/prepayment', id: 108 },
					{ label: '1.1.8', link: '/app/1-1-8', id: 104 },
					{ label: '5.1.1.0', link: '/app/5-1-1-0', id: 111 },
					{ label: '5.1.1', link: '/app/5-1-1', id: 105 },
					{ label: '6.1.1', link: '/app/6-1-1', id: 109 },
					{ label: '9.1.1', link: '/app/9-1-1', id: 110 },
					{ label: 'Sheet 4' },
					{ label: 'Sheet 5' },
					{ label: 'Sheet 6' },
					{ label: 'Notes' }
				]
			},
			'1.2 Loan Pricing & Valuation': emptyTabs,
			'1.3 Asset Liability Management (ALM)': emptyTabs,
			'1.4 Liquidity Management (CVA, FVA, MVA)': emptyTabs,
			'1.5 Deposit Management & Analytics': emptyTabs,
			'1.6 Duration Gap Analysis': emptyTabs,
			'1.7 Balance Sheet Modeling': emptyTabs,
			'1.8 Prepayment Analysis': {
				link: '/app/prepayment',
				subtabs: [
					{ label: '1.2.1 Prepayment', link: '/app/prepayment', id: 102 },
					{ label: '1.3.1 Default', link: '/app/default', id: 103 },
					{ label: 'Sheet 3' },
					{ label: 'Sheet 4' },
					{ label: 'Sheet 5' },
					{ label: 'Sheet 6' },
					{ label: 'Notes' }
				]
			},
			'1.9 Value at Risk (VaR) and Scenario Analysis': emptyTabs,
			'1.10 ALM Stress Testing': emptyTabs,
			'1.11 ALM Optimization': emptyTabs,
			'1.12 Internal Liquidity Adequacy Assessment Process (ILAAP)': emptyTabs,
			'1.13 Interest rate risk in the banking book (IRRBB)': emptyTabs,
			'1.14 Fund Transfer Pricing (FTP)': emptyTabs,
			'1.15 Interest Rate Lock Commitments (IRLCs)': emptyTabs,
			'1.16 ALCO Reporting': emptyTabs,
			'1.17 Interest Risk Management (MVE, NIM, Duration, etc.)': emptyTabs
		}
	},
	{
		id: 2,
		link: '/app/crm',
		links: [
			'/app/crm',
			'/app/crm2',
			'/app/1-2-3',
			// '/app/1-2-8',
			'/app/3-2-1',
			'/app/5-2-1-0',
			'/app/5-2-1',
			'/app/6-2-1',
			'/app/9-2-1'
		],
		label: 'Credit Risk',
		content: {
			'2.1 Probability of Default (PD)': {
				link: '/app/crm',
				subtabs: [
					{ label: '1.2.1', link: '/app/crm', id: 201 },
					{ label: '1.2.2', link: '/app/crm2', id: 202 },
					{ label: '1.2.3', link: '/app/1-2-3', id: 206 },
					// { label: '1.2.8', link: '/app/1-2-8', id: 208 },
					{ label: '3.2.1', link: '/app/3-2-1', id: 207 },
					{ label: '5.2.1.0', link: '/app/5-2-1-0', id: 208 },
					{ label: '5.2.1', link: '/app/5-2-1', id: 203 },
					{ label: '6.2.1', link: '/app/6-2-1', id: 204 },
					{ label: '9.2.1', link: '/app/9-2-1', id: 205 },
					{ label: 'notes' }
				]
			},
			'2.2 Loss given default (LGD)': emptyTabs,
			'2.3 Exposure at Default (EAD)': emptyTabs,
			'2.4 Expected Loss (EL)': emptyTabs,
			'2.5 IFRS 9 & Current Expected Credit Losses (CECL)': emptyTabs,
			'2.6 Performance Data & Strats': emptyTabs,
			'2.7 Credit Scorecard': emptyTabs,
			'2.8 Risk-Based Pricing': emptyTabs,
			'2.9 Machine Learning': emptyTabs,
			'2.10 Credit Rating Methodologies': emptyTabs,
			'2.11 Comprehensive Capital Analysis and Review (CCAR)': emptyTabs
		}
	},
	{
		id: 3,
		link: '/app/fpna',
		links: [
			'/app/fpna',
			'/app/fpna-1-3-2',
			'/app/fpna-2',
			'/app/fpna-3',
			// '/app/fpna-3-2',
			'/app/fpna-3-3-2',
			'/app/fpna-4',
			'/app/fpna-5',
			'/app/fpna-5-3-1-0',
			// '/app/fpna-5-2',
			'/app/fpna-6-3-1',
			'/app/fpna-9-3-1',
			// '/app/fpna-6-2',
			// '/app/fpna-9-2',
			'/app/fpna-0'
		],
		label: 'FP&A',
		content: {
			'3.1 Financial Projections': {
				link: '/app/fpna',
				subtabs: [
					{ label: '1.3.1', link: '/app/fpna', id: 301 },
					{ label: '1.3.2', link: '/app/fpna-1-3-2', id: 313 },
					{ label: '2.3.1', link: '/app/fpna-2', id: 302 },
					{ label: '3.3.1', link: '/app/fpna-3', id: 303 },
					{ label: '3.3.2', link: '/app/fpna-3-3-2', id: 314 },
					// { label: '3.3.2', link: '/app/fpna-3-2', id: 308 },

					{ label: '4.3.1', link: '/app/fpna-4', id: 304 },
					{ label: '5.3.1.0', link: '/app/fpna-5-3-1-0', id: 315 },
					{ label: '5.3.1', link: '/app/fpna-5', id: 305 },
					// { label: '5.3.2', link: '/app/fpna-5-2', id: 310 },
					{ label: '6.3.1', link: '/app/fpna-6-3-1', id: 306 },
					// { label: '6.3.2', link: '/app/fpna-6-2', id: 309 },
					{ label: '9.3.1', link: '/app/fpna-9-3-1', id: 311 },
					// { label: '9.3.2', link: '/app/fpna-9-2', id: 312 },
					{ label: 'FP&A 0', link: '/app/fpna-0', id: 307 }
				]
			},
			'3.2 Enterprise & Equity Valuation': emptyTabs,
			// '3.3 Loan Pricing)': emptyTabs,
			'3.4 Regulatory Reporting Basel II & III': emptyTabs,
			'3.5 IFRS 9 & IFRS 13 Accounting': emptyTabs,
			'3.6 Loans to Deposit Ratio (LDR))': emptyTabs,
			'3.7 Liquid Coverage Ratio (LCR))': emptyTabs,
			'3.8 Net Stable Funding Ratio (NSFR)': emptyTabs
		}
	},
	{
		id: 4,
		link: '/app/securitization',
		links: [
			'/app/securitization',
			{
				/*'/app/5-4-1',*/
			},
			'/app/6-4-1',
			'/app/9-4-1'
		],
		label: 'Capital Markets',
		content: {
			'4.1 Securitization Reporting': {
				link: '/app/securitization',
				subtabs: [
					{ label: '1.4.1', link: '/app/securitization', id: 401 },
					// { label: '5.4.1', link: '/app/5-4-1', id: 402 },
					{ label: '6.4.1', link: '/app/6-4-1', id: 403 },
					{ label: '9.4.1', link: '/app/9-4-1', id: 404 },
					{ label: 'Sheet 4' },
					{ label: 'Sheet 5' },
					{ label: 'Sheet 6' },
					{ label: 'Notes' }
				]
			},
			'4.2 Structuring ABS, RMBS, Warehouse': emptyTabs,
			'4.3 Credit Rating Methodology': emptyTabs,
			'4.4 Data Set Tapes': emptyTabs,
			'4.5 Portfolio Surveillance': emptyTabs,
			'4.6 Credit Facility Management': emptyTabs
		}
	},
	{
		id: 5,
		link: '/app/academy',
		links: ['/app/academy'],
		label: 'Library',
		content: {
			Academy: {
				link: '/app/academy',
				subtabs: [
					{ label: 'Academy', link: '/app/academy', id: 501 },
					{ label: 'Sheet 2' },
					{ label: 'Sheet 3' },
					{ label: 'Sheet 4' },
					{ label: 'Sheet 5' },
					{ label: 'Sheet 6' },
					{ label: 'Notes' }
				]
			}
		}
	},
	{
		id: 6,
		link: '/app/dashboard',
		links: ['/app/dashboard'],
		label: 'Dashboard',
		content: {
			Dashboard: {
				link: '/app/dashboard',
				subtabs: [
					{ label: 'Dashboard', link: '/app/dashboard', id: 601 },
					{ label: 'Sheet 2' },
					{ label: 'Sheet 3' },
					{ label: 'Sheet 4' },
					{ label: 'Sheet 5' },
					{ label: 'Sheet 6' },
					{ label: 'Notes' }
				]
			}
		}
	}
];
