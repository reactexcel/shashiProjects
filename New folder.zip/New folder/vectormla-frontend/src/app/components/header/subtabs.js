export const subTabs = [
	[],
	[
		{ label: '1.1.2 Cashflow2', link: '/app/cashflow2' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	],
	[
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	],
	[
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	],
	[
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	],
	[
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	],
	[
		{ label: 'Sheet 1' },
		{ label: 'Sheet 2' },
		{ label: 'Sheet 3' },
		{ label: 'Sheet 4' },
		{ label: 'Sheet 5' },
		{ label: 'Sheet 6' },
		{ label: 'Notes' }
	]
];
