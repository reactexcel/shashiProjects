import React from 'react';
import { useSelector } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import { useStyles } from './homepageStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import PointsContainer from '../components/pointsContainer/PointsContainer';

const HomePage = () => {
	const user = useSelector((state) => state.auth.user);
	const classes = useStyles();

	const { ref: homeRef, height: homeHeight } = useComponentSize();

	return (
		<div ref={homeRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={homeHeight} />

			<Grid
				container
				className={classes.appContentContainer}
				style={{ marginTop: 27 }}
				justify="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<PointsContainer
							id={1}
							header={`Financial Models Map`}
							data={[
								{
									header: 'Financial Planning and Analysis (FP&A)',
									points: [
										{
											singleLink: '/app/fpna',
											title: 'Financial Projections'
										},
										{
											singleLink: '/app/fpna',
											title: 'Deposit Modeling'
										},
										{
											singleLink: '/app/fpna',
											title: 'Enterprise & Equity Valuation'
										},
										{
											singleLink: '/app/fpna',
											title: 'Cash Flow Projections & Analytics'
										},
										{
											singleLink: '/app/fpna',
											title: 'Balance Sheet Modeling'
										},
										{
											singleLink: '/app/fpna',
											title: 'Prepayment Analysis'
										}
										// { singleLink: '/app/fpna', title: 'Loan Pricing' }
									],
									pointsAllowed: user?.allowed_section3,
									unlocked: user?.allowed_pages?.includes(3)
								},
								{
									header: 'Credit Risk',
									points: [
										{
											singleLink: '/app/crm',
											title: 'Probability of Default (PD)'
										},
										{
											singleLink: '/app/crm2',
											title: 'Loss given default (LGD)'
										},
										{
											singleLink: '/app/crm',
											title: 'Exposure at Default (EAD)'
										},
										{ singleLink: '/app/crm', title: 'Expected Loss (EL)' },
										{
											singleLink: '/app/crm',
											title: 'Performance Data & Strats'
										},
										{ singleLink: '/app/crm', title: 'Credit Scorecard' },
										{ singleLink: '/app/crm', title: 'Risk-Based Pricing' }
									],
									pointsAllowed: user?.allowed_section2,
									unlocked: user?.allowed_pages?.includes(2)
								},
								{
									header: 'Treasury ALM',
									points: [
										{
											singleLink: '/app/cashflow',
											title: 'Loan Pricing'
										},
										{
											singleLink: '/app/cashflow',
											title: 'Company Valuation'
										},
										{
											singleLink: '/app/cashflow',
											title: 'Asset Liability Management (ALM)'
										},
										{
											singleLink: '/app/cashflow',
											title: 'Duration Gap Analysis'
										},
										{
											singleLink: '/app/cashflow',
											title: 'ALCO Reporting'
										}
									],
									pointsAllowed: user?.allowed_section1,
									unlocked: user?.allowed_pages?.includes(1)
								},
								{
									header: 'Capital Markets',
									points: [
										{
											singleLink: '/app/securitization',
											title: 'Securitization Reporting'
										},
										{
											singleLink: '/app/securitization',
											title: 'Data Set Tapes'
										},
										{
											singleLink: '/app/securitization',
											title: 'Portfolio Surveillance'
										}
									],
									pointsAllowed: user?.allowed_section4,
									unlocked: user?.allowed_pages?.includes(4)
								}
							]}
						/>
						<br />
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default HomePage;
