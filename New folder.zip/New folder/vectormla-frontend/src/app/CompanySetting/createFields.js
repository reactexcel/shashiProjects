import TextField from '../../common/components/fields/TextField';

export const fields = [
	{
		name: 'first_name',
		placeholder: 'First Name',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'last_name',
		placeholder: 'Last Name',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'email',
		type: 'email',
		placeholder: 'Email',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'username',
		placeholder: 'Username',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'job_name',
		placeholder: 'Job Name',
		component: TextField,
		typeField: 'admin'
	}
];
