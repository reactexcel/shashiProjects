import { makeStyles } from '@material-ui/core';
import {
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader
} from '../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader,
	header__save: {
		textTransform: 'capitalize',
		height: 25,
		width: 120,
		marginRight: 5,
		marginLeft: 0,
		color: '#53687E !important',
		borderRadius: 0,
		border: '2px solid #7991aa',
		backgroundColor: 'white',
		'&:hover': {
			backgroundColor: '#7991AA',
			border: '2px solid #53687E',
			color: 'white !important'
		},
		[theme.breakpoints.down('sm')]: {
			width: 65
		}
	}
}));
