import CompanySetting from './CompanySetting';

export default CompanySetting;
