import {
	GET_PREPAYMENT_TABLES_SUCCESS,
	GET_PREPAYMENT_TABLES_FAILED,
	GET_PREPAYMENT_PORTFOLIOS_SUCCESS,
	GET_PREPAYMENT_PORTFOLIOS_FAILED,
	UPDATE_PREPAYMENT_PORTFOLIOS,
	START_PREPAYMENT_TIMER,
	TICK_PREPAYMENT_TIMER,
	STOP_LOADING,
	GET_PREPAYMENT_TABLES_CLEAN
} from '../types/prepayment.type';

const INITIAL_STATE = {
	tables: null,
	loading: false,
	error: null,
	portfolios: null,
	status: 'stopped',
	taskProgress: '0.0 %'
};

const prepaymentReducer = (state = INITIAL_STATE, action) => {
	switch (action.type) {
		case GET_PREPAYMENT_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios: action.payload,
				loading: false
			};
		case GET_PREPAYMENT_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_PREPAYMENT_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload }
			};
		case GET_PREPAYMENT_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case UPDATE_PREPAYMENT_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_PREPAYMENT_TABLES_CLEAN:
			return {
				...state,
				tables: null,
				loading: false,
				error: null
			};
		// case GET_PREPAYMENT_CHARTS_CLEAN:
		// 	return {
		// 		...state,
		// 		charts: null,
		// 		portfolios: null,
		// 		error: null,
		// 		loading: false
		// 	};
		case START_PREPAYMENT_TIMER:
			return {
				...state,
				status: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_PREPAYMENT_TIMER:
			if (state.minutes != 0 && state.seconds != 0) {
				return {
					...state,
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes != 0 && state.seconds == 0) {
				return {
					...state,
					status: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes == 0 && state.seconds != 0) {
				return {
					...state,
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return {
					...state,
					minutes: 4,
					seconds: 30,
					status: 'stopped'
				};
			}
		case STOP_LOADING:
			return {
				error: action.payload,
				loading: false
			};
		default:
			return state;
	}
};

export default prepaymentReducer;
