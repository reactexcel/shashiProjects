import {
	GET_CREDIT_TABLES_SUCCESS,
	GET_CREDIT_TABLES_FAILED,
	GET_CREDIT_RISK_2_TABLES_SUCCESS,
	GET_CREDIT_RISK_2_TABLES_FAILED,
	GET_CREDIT_RISK_2_PORTFOLIOS_SUCCESS,
	GET_CREDIT_RISK_2_PORTFOLIOS_FAILED,
	START_CREDIT_RISK_2_TIMER,
	STOP_CREDIT_RISK_2_TIMER,
	TICK_CREDIT_RISK_2_TIMER,
	GET_CREDIT_RISK_2_TABLES_CLEAN
} from '../types/credit.type';

const initialState = {
	tables: null,
	tables2: null,
	portfolios2: null,
	loading: false,
	error: null,
	minutes: 4,
	seconds: 30,
	status: 'stopped',
	taskProgress: '0.0 %'
};

const creditReducer = (state = initialState, action) => {
	const { minutes, seconds } = state;
	switch (action.type) {
		case GET_CREDIT_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload }
			};
		case GET_CREDIT_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CREDIT_RISK_2_TABLES_SUCCESS:
			return {
				...state,
				tables2: { ...state.tables2, ...action.payload }
			};
		case GET_CREDIT_RISK_2_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CREDIT_RISK_2_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios2: action.payload
			};
		case GET_CREDIT_RISK_2_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CREDIT_RISK_2_TABLES_CLEAN:
			return {
				...state,
				tables2: null,
				portfolios2: null,
				loading: false,
				error: null
			};
		case START_CREDIT_RISK_2_TIMER:
			return {
				...state,
				status: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_CREDIT_RISK_2_TIMER:
			if (minutes !== 0 && seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: seconds - 5,
					minutes
				};
			} else if (minutes !== 0 && seconds === 0) {
				return {
					...state,
					status: 'pending',
					seconds: 55,
					minutes: minutes - 1
				};
			} else if (minutes === 0 && seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: seconds - 5,
					minutes
				};
			} else {
				return {
					...state,
					minutes: 4,
					seconds: 30,
					status: 'stopped'
				};
			}
		case STOP_CREDIT_RISK_2_TIMER:
			return { ...state, minutes: 4, seconds: 30, status: action.payload };
		default:
			return state;
	}
};

export default creditReducer;
