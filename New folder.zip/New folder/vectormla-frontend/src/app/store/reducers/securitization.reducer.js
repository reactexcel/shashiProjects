import {
	GET_SECURITIZATION_PORTFOLIOS_SUCCESS,
	GET_SECURITIZATION_PORTFOLIOS_FAILED,
	UPDATE_SECURITIZATION_PORTFOLIOS,
	GET_SECURITIZATION_TABLES_SUCCESS,
	GET_SECURITIZATION_TABLES_FAILED,
	GET_SECURITIZATION_TABLES_CLEAN
} from '../types/securitization.type';

const INITIAL_STATE = {
	portfolios: null,
	tables: null,
	loading: false,
	error: null
};

const securitizationReducer = (state = INITIAL_STATE, action) => {
	switch (action.type) {
		case GET_SECURITIZATION_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios: action.payload,
				loading: false
			};
		case GET_SECURITIZATION_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};

		case UPDATE_SECURITIZATION_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_SECURITIZATION_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload },
				loading: false
			};
		case GET_SECURITIZATION_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_SECURITIZATION_TABLES_CLEAN:
			return {
				...state,
				tables: null,
				loading: false,
				error: null,
				portfolios: null
			};
		default:
			return state;
	}
};

export default securitizationReducer;
