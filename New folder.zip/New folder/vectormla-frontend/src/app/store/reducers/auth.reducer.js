import {
	LOGIN_SUCCESS,
	LOGIN_FAILED,
	LOGIN_REQUESTED,
	LOGOUT,
	USER_RETRIEVED_SUCCESS,
	USER_RETRIEVED_FAILED,
	USER_RETRIEVED_INIT
} from '../types/auth.type';

const initialState = {
	user: null,
	isAuthenticated: false,
	loading: false,
	error: null
};

const authReducer = (state = initialState, action) => {
	switch (action.type) {
		case LOGIN_REQUESTED:
		case USER_RETRIEVED_INIT:
			return {
				...state,
				loading: true
			};
		case LOGIN_SUCCESS:
			return {
				...state,
				isAuthenticated: true,
				loading: false,
				error: null
			};
		case LOGIN_FAILED:
			return {
				...state,
				user: null,
				isAuthenticated: false,
				loading: false,
				error: action.payload
			};
		case USER_RETRIEVED_SUCCESS:
			return {
				...state,
				user: action.payload,
				isAuthenticated: true,
				loading: false,
				error: null
			};
		case USER_RETRIEVED_FAILED:
			return {
				...state,
				user: null,
				isAuthenticated: false,
				loading: false,
				error: action.payload
			};
		case LOGOUT:
			return {
				...state,
				isAuthenticated: false,
				user: null
			};
		default:
			return state;
	}
};

export default authReducer;
