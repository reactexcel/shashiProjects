import { START_TIMER, STOP_TIMER, TICK_TIMER } from '../types/timer.type';
const initialState = {
	minutes: 100,
	seconds: 0,
	status: 'stopped'
};

const TimerReducer = (state = initialState, action) => {
	switch (action.type) {
		case START_TIMER:
			return {
				status: 'start',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_TIMER:
			if (state.minutes != 0 && state.seconds != 0) {
				return {
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes != 0 && state.seconds == 0) {
				return {
					status: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes == 0 && state.seconds != 0) {
				return {
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return initialState;
			}
		case STOP_TIMER:
			return { minutes: 4, seconds: 30, status: action.payload };
		default:
			return state;
	}
};
export default TimerReducer;
