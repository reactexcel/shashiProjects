import {
	KILL_TASK_INIT,
	KILL_TASK_SUCCESS,
	KILL_TASK_FAIL
} from '../types/killTask.type';

const initialState = {
	loading: false,
	error: null,
	status: null
};

const KillTaskReducer = (state = initialState, action) => {
	switch (action.type) {
		case KILL_TASK_INIT:
			return {
				loading: true,
				error: null,
				status: 'KILLING'
			};
		case KILL_TASK_SUCCESS:
			return {
				loading: false,
				error: null,
				status: 'SUCCESS'
			};
		case KILL_TASK_FAIL:
			return {
				loading: false,
				error: action.payload,
				status: 'STOPPED'
			};
		default:
			return state;
	}
};
export default KillTaskReducer;
