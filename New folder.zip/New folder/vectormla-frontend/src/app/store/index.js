import { createStore, combineReducers, applyMiddleware } from 'redux';
import reduxThunk from 'redux-thunk';
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import { reducer as formReducer } from 'redux-form';
import { composeWithDevTools } from 'redux-devtools-extension';
import AuthReducer from './reducers/auth.reducer';
import FpnaReducer from './reducers/fpna.reducer';
import SecuritizationReducer from './reducers/securitization.reducer';
import PrepaymentReducer from './reducers/prepayment.reducer';
import CreditReducer from './reducers/credit.reducer';
import CashflowReducer from './reducers/cashflow.reducer';
import DefaultReducer from './reducers/default.reducer';
import TimerReducer from './reducers/timer.reducer';

const persistConfig = {
	key: 'data',
	storage: storage,
	whitelist: ['auth']
};

let appReducer = combineReducers({
	auth: AuthReducer,
	fpna: FpnaReducer,
	securitization: SecuritizationReducer,
	prepayment: PrepaymentReducer,
	credit: CreditReducer,
	cashflow: CashflowReducer,
	default: DefaultReducer,
	form: formReducer,
	timer: TimerReducer
});

const rootReducer = (state, action) => {
	return appReducer(action.type === 'LOGOUT' ? undefined : state, action);
};
const pReducer = persistReducer(persistConfig, rootReducer);
const store = createStore(
	pReducer,
	composeWithDevTools(applyMiddleware(reduxThunk))
);

const persistor = persistStore(store);
export { persistor, store };
