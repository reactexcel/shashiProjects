import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/cashflow.type';
import { handleError, downloadFile } from './utils';

export const getPortfolios = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}treasury/portfolio-scenario/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CASHFLOW_PORTFOLIOS_SUCCESS,
				payload: res.data?.results
			});
			callback(res.data?.results);
		})
		.catch((err) => {
			handleError(err, Types.GET_CASHFLOW_PORTFOLIOS_FAILED, dispatch);
		});
};

export const createPortfolio =
	(name, company_id, data, callback) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_CASHFLOW_PORTFOLIOS
		});
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}treasury/portfolio-scenario/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, null, dispatch);
			});
	};

export const updatePortfolio = (model, data, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_CASHFLOW_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.put(`${API}treasury/portfolio-scenario/${model}/`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		});
};
export const deletePortfolio = (model, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_CASHFLOW_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.delete(`${API}treasury/portfolio-scenario/${model}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		});
};

export const downloadCashflowTemplate = async () => {
	const session = localStorage.getItem('user');
	let url = await `${API}treasury/template?token=${session}`;
	downloadFile(url);
};

export const downloadCashflowData = async (model) => {
	const session = localStorage.getItem('user');
	let url =
		await `${API}treasury/portfolio-scenario/${model}/download-inputfile?token=${session}`;
	downloadFile(url);
};

export const getPortfolioScenarios = (model, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}treasury/portfolio-scenario/${model}/portfolio/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CASHFLOW_SENARIOS_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CASHFLOW_SENARIOS_FAILED, dispatch);
		});
};

export const getPortfolioDetails =
	(model, type, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}treasury/portfolio/${model}/${type}/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_CASHFLOW_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_CASHFLOW_TABLES_FAILED, dispatch);
			});
	};

export const getChartsDetails = (model, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}treasury/portfolio-scenario/${model}/charts/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CASHFLOW_TABLES_SUCCESS,
				payload: { charts: res.data }
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CASHFLOW_TABLES_FAILED, dispatch);
		});
};
