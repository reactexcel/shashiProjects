import axios from 'axios';
import { API } from 'config/EnvironmentConfig';
import * as Types from '../types/killTask.type';
import { handleError } from './utils';
import { toast } from 'react-toastify';
export const killTaskFunc = (model, id, callback) => async (dispatch) => {
	dispatch({
		type: Types.KILL_TASK_INIT
	});
	const session = localStorage.getItem('user');
	let url = `${API}${model}/portfolio-scenario/${id}/revokecalculation/`;
	return axios
		.post(
			url,
			{},
			{
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => callback(res.data))
		.catch((err) => {
			model !== 'cfm5' && model !== 'cfm0'
				? handleError(err, null, dispatch)
				: toast.warn('Please upload the correct file', {
						autoClose: 5000
				  });
		});
};
