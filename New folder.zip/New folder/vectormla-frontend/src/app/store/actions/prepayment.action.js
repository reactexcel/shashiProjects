import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/prepayment.type';
import { handleError, downloadFile, notifyUser } from './utils';
import { stopTimer } from './timer.action';
export const getPrepayments = (model, type, callback) => (dispatch) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}prepayment/prepay-model/${model}/${type}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_PREPAYMENT_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_PREPAYMENT_TABLES_FAILED, dispatch);
		});
};

export const getPortfolios = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}prepayment/prepay-model/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_PREPAYMENT_PORTFOLIOS_SUCCESS,
				payload: res.data?.results
			});
			callback(res.data?.results);
		})
		.catch((err) => {
			handleError(err, Types.GET_PREPAYMENT_PORTFOLIOS_FAILED, dispatch);
		});
};

export const createPortfolio =
	(name, company_id, data, callback, modelName) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_PREPAYMENT_PORTFOLIOS
		});
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}prepayment/prepay-model/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, null, dispatch);
			});
	};
export const downloadPrepaymentTemplate = () => async (dispatch) => {
	const session = localStorage.getItem('user');
	let url = `${API}prepayment/template/?token=${session}`;
	downloadFile(url);
};

export const deletePortfolio =
	(model, callback, modelName) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_PREPAYMENT_PORTFOLIOS
		});
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		const session = localStorage.getItem('user');
		return axios
			.delete(`${API}prepayment/prepay-model/${model}/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				handleError(err);
			});
	};
export const updatePortfolio = (model, data, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_PREPAYMENT_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.put(`${API}prepayment/prepay-model/${model}/`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			notifyUser('Portfolio is updated successfully!');
			callback(res.data);
		})
		.catch((err) => {
			dispatch({ type: Types.STOP_LOADING, payload: err });
			dispatch(stopTimer('prepayment'));
			handleError(err);
		});
};

export const downloadPrepaymentData = async (model) => {
	const session = localStorage.getItem('user');
	let url =
		await `${API}prepayment/prepay-model/${model}/download-inputfile?token=${session}`;
	downloadFile(url);
};
