import { toast } from 'react-toastify';

export const handleError = (
	err,
	type = null,
	dispatch = null,
	showToast = true,
	warn = true,
	errCallback
) => {
	if (err.response) {
		if (err.response.status === 500) {
			!errCallback &&
				showToast &&
				toast[warn ? 'warn' : 'error']('Server Error');
			type && dispatch({ type, payload: ['Server Error'] });
		} else if (err.response.status > 500) {
			!errCallback &&
				showToast &&
				toast[warn ? 'warn' : 'error']('Connection Error');
			type && dispatch({ type, payload: ['Connection Error'] });
		} else if (err.response.status === 401) {
			const isUserExist = localStorage.getItem('user');
			localStorage.removeItem('user');
			isUserExist && window.location.reload();
		} else {
			let message = '';
			if (typeof Object.values(err.response.data)[0] === 'string')
				message = Object.values(err.response.data)[0];
			else message = Object.values(err.response.data)[0][0];

			!errCallback && showToast && toast[warn ? 'warn' : 'error'](message);
			type && dispatch({ type, payload: message });
		}
	}
};

export const notifyUser = (
	message = 'Proccess is completed successfully',
	status = 'success'
) => {
	toast[status](message);
};

export const downloadFile = (url, download = true) => {
	let a = document.createElement('a');
	a.href = url;
	a.target = '_blank';
	a.download = download;
	a.click();
	a.remove();
};
