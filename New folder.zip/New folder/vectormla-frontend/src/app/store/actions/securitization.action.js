import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/securitization.type';
import { handleError, notifyUser } from './utils';

export const getPortfolios = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}mbs_indemnity/mbs-model/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_SECURITIZATION_PORTFOLIOS_SUCCESS,
				payload: res.data?.results
			});
			callback(res.data?.results);
		})
		.catch((err) => {
			handleError(err, Types.GET_SECURITIZATION_PORTFOLIOS_FAILED, dispatch);
		});
};
export const createPortfolio =
	(name, company_id, data, callback) => async (dispatch) => {
		dispatch({ type: Types.UPDATE_SECURITIZATION_PORTFOLIOS });
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}mbs_indemnity/mbs-model/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				callback(res.data);
				notifyUser('Portfolio is created successfully!');
			})
			.catch((err) => {
				handleError(err, null, dispatch);
			});
	};
export const updatePortfolio = (model, data, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_SECURITIZATION_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.put(`${API}mbs_indemnity/mbs-model/${model}/`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
			notifyUser('Portfolio is updated successfully!');
		})
		.catch((err) => {
			handleError(err);
		});
};
export const deletePortfolio = (model, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_SECURITIZATION_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.delete(`${API}mbs_indemnity/mbs-model/${model}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		})
		.catch((err) => {
			handleError(err);
		});
};
export const downloadTemplate = () => async (dispatch) => {
	const session = localStorage.getItem('user');
	let url = `${API}mbs_indemnity/template?token=${session}`;
	let a = document.createElement('a');
	a.href = url;
	a.download = true;
	a.click();
	a.remove();
};
export const downloadFile =
	(model, template = false) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		let url = `${API}mbs_indemnity/mbs-model/${model}/download-${
			template ? 'template' : 'inputfile'
		}?token=${session}`;
		let a = document.createElement('a');
		a.href = url;
		a.download = true;
		a.click();
		a.remove();
	};
export const getPools = (model, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}mbs_indemnity/mbs-model/${model}/pools-data/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_SECURITIZATION_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_SECURITIZATION_TABLES_FAILED, dispatch);
		});
};

export const getGocRate = (model, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}mbs_indemnity/mbs-model/${model}/goc-rate/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_SECURITIZATION_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_SECURITIZATION_TABLES_FAILED, dispatch);
		});
};

export const getPoolDetails = (poolID, type, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}mbs_indemnity/pools-data/${poolID}/${type}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_SECURITIZATION_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_SECURITIZATION_TABLES_FAILED, dispatch);
		});
};
