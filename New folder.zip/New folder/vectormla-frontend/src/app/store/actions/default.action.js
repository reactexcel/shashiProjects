import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/default.type';
import { stopTimer } from './timer.action';
import { handleError, downloadFile, notifyUser } from './utils';

export const createPortfolio =
	(name, company_id, data, callback, modelName) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_DEFAULT_PORTFOLIOS
		});
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}default/default-model/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, null, dispatch);
			});
	};

export const downloadDefaultTemplate = () => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}default/template/?token=${session}`;
	downloadFile(url);
};

export const getPortfolios = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}default/default-model/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_DEFAULT_PORTFOLIOS_SUCCESS,
				payload: res.data?.results
			});
			callback(res.data?.results);
		})
		.catch((err) => {
			handleError(err, Types.GET_DEFAULT_PORTFOLIOS_FAILED, dispatch);
		});
};
export const deletePortfolio = (model, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_DEFAULT_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.delete(`${API}default/default-model/${model}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		})
		.catch((err) => {
			dispatch({ type: Types.STOP_LOADING, payload: err });
			handleError(err);
		});
};
export const getPortfolioDetails =
	(model, type, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}default/default-model/${model}/${type}/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_DEFAULT_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_DEFAULT_TABLES_FAILED, dispatch);
			});
	};

export const updatePortfolio =
	(model, data, callback, modelName) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_DEFAULT_PORTFOLIOS
		});
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		const session = localStorage.getItem('user');
		return axios
			.put(`${API}default/default-model/${model}/`, data, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				notifyUser('Portfolio is updated successfully!');
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				dispatch(stopTimer('default'));
				handleError(err);
			});
	};

export const downloadDefaultData = async (model) => {
	const session = localStorage.getItem('user');
	let url =
		await `${API}default/default-model/${model}/download-inputfile?token=${session}`;
	downloadFile(url);
};
