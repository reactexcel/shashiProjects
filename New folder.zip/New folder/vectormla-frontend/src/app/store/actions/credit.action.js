import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/credit.type';
import { handleError, notifyUser, downloadFile } from './utils';

export const getCreditRisk = (callback) => (dispatch) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}credit/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CREDIT_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CREDIT_TABLES_FAILED, dispatch);
		});
};
export const createPortfolio =
	(name, company_id, data, callback, modelName) => async (dispatch) => {
		dispatch({
			type: Types.UPDATE_CREDIT_RISK_2_PORTFOLIOS
		});
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}credit2/creditrisk-model/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, null, dispatch);
			});
	};
export const getPortfolios = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}credit2/creditrisk-model/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CREDIT_RISK_2_PORTFOLIOS_SUCCESS,
				payload: res.data?.results
			});
			callback(res.data?.results);
		})
		.catch((err) => {
			handleError(err, Types.GET_CREDIT_RISK_2_PORTFOLIOS_FAILED, dispatch);
		});
};
// To get tables data
export const getPortfolioDetails =
	(model, type, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}credit2/creditrisk-model/${model}/${type}/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_CREDIT_RISK_2_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_CREDIT_RISK_2_TABLES_FAILED, dispatch);
			});
	};
export const deletePortfolio = (model, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_CREDIT_RISK_2_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.delete(`${API}credit2/creditrisk-model/${model}/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		})
		.catch((err) => {
			//theres a line here for stopping timer check default action
			handleError(err);
		});
};

export const updatePortfolio = (model, data, callback) => async (dispatch) => {
	dispatch({
		type: Types.UPDATE_CREDIT_RISK_2_PORTFOLIOS
	});
	const session = localStorage.getItem('user');
	return axios
		.put(`${API}credit2/creditrisk-model/${model}/`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		})
		.catch((err) => {
			handleError(err);
		});
};
export const downloadCredit2Template = () => async (dispatch) => {
	const session = localStorage.getItem('user');
	let url = `${API}credit2/template/?token=${session}`;
	downloadFile(url);
};

export const downloadCredit2Data = async (model) => {
	const session = localStorage.getItem('user');
	let url =
		await `${API}credit2/creditrisk-model/${model}/download-inputfile?token=${session}`;
	downloadFile(url);
};
