import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/auth.type';
import { handleError } from './utils';

// export const login = (credentials, callback) => async (dispatch) => {
// 	dispatch({ type: Types.LOGIN_REQUESTED });
// 	try {
// 		const res = await axios.post(`${API}auth/login`, credentials);
// 		localStorage.setItem('user', res.data);
// 		dispatch({ type: Types.LOGIN_SUCCESS, payload: res.data });
// 		callback();
// 	} catch (err) {
// 		handleError(err, Types.LOGIN_FAILED, dispatch);
// 	}
// };

export const loginMFA =
	(credentials, history, callback) => async (dispatch) => {
		dispatch({ type: Types.LOGIN_REQUESTED });
		try {
			const res = await axios.post(`${API}auth/login_mfa`, {
				email:
					credentials?.email ||
					JSON.parse(localStorage.getItem('userOTP') || '{}')?.email,
				password:
					credentials?.password ||
					JSON.parse(localStorage.getItem('userOTP') || '{}')?.password,
				otp: credentials?.otp
			});
			dispatch({ type: Types.LOGIN_SUCCESS, payload: res.data });
			if (res.data.status === 0 && res?.data?.token) {
				// To login since there's a token and the admin disabled the MFA
				localStorage.setItem('user', res?.data?.token);
				dispatch(
					retrieveUserInfo(() => {
						history.push({
							pathname: '/app/homepage'
						});
					})
				);
			} else if (res.data.status === 1) {
				localStorage.setItem(
					'userOTP',
					JSON.stringify({ ...credentials, qr_url: res?.data?.qr_url })
				);
				history.push('/OTP');
				// To show the QR code
			} else {
				if (res?.data?.token) {
					localStorage.setItem('user', res?.data?.token);
					localStorage.removeItem('userOTP');
					callback();
				} else {
					localStorage.setItem('userOTP', JSON.stringify(credentials));
					history.push('/OTP');
				}
			}
		} catch (err) {
			handleError(err, Types.LOGIN_FAILED, dispatch);
		}
	};

export const retrieveUserInfo = (callback, errCallback) => async (dispatch) => {
	dispatch({ type: Types.USER_RETRIEVED_INIT });
	try {
		const session = localStorage.getItem('user');
		const res = await axios.get(`${API}auth/current`, {
			headers: { Authorization: `Token ${session}` }
		});

		dispatch({
			type: Types.USER_RETRIEVED_SUCCESS,
			payload: res.data
		});
		callback && callback();
	} catch (err) {
		handleError(
			err,
			Types.USER_RETRIEVED_FAILED,
			dispatch,
			'',
			'',
			errCallback
		);
		errCallback && errCallback();
	}
};

export const logout = (callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	await axios.get(`${API}auth/logout`, {
		headers: { Authorization: `Token ${session}` }
	});
	localStorage.removeItem('user');
	localStorage.clear();
	callback && callback();
	dispatch({
		type: Types.LOGOUT
	});
};
export const resetPassword = (id, data, callback) => async (dispatch) => {
	try {
		await axios.put(`${API}auth/password/reset?id=${id}`, data);
		callback && callback();
	} catch (err) {
		handleError(err, null, dispatch);
	}
};
