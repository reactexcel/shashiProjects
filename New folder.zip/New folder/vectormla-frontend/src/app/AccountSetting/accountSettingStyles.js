import { makeStyles } from '@material-ui/core';
import { unset } from 'lodash';
import {
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader
} from '../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader,
	header__save: {
		textTransform: 'capitalize',
		height: 25,
		width: 120,
		marginRight: 5,
		marginLeft: 0,
		color: '#53687E !important',
		borderRadius: 0,
		border: '2px solid #7991aa',
		backgroundColor: 'white',
		'&:hover': {
			backgroundColor: '#7991AA',
			border: '2px solid #53687E',
			color: 'white !important'
		},
		[theme.breakpoints.down('sm')]: {
			width: 65
		}
	},
	label: {
		color: '#000',
		width: 70,
		fontSize: '12px',
		fontFamily: 'Roboto'
	},
	textStyle: {
		'& .MuiInputBase-root': {
			'& input': {
				color: 'rgba(0, 0, 0, 0.87)',
				padding: '5px 12px',
				width: '150px',
				fontSize: '11px',
				background: '#f7f8fa',
				fontFamily: 'Roboto',
				fontWeight: 500,
				lineHeight: '1.18em',
				borderRadius: 0,
				border: '1px solid rgba(190, 191, 192, 1)'
			}
		}
	},
	gridChild: {
		display: 'flex',
		alignItems: 'center',
		marginBottom: -10,
		gap: '10px',
		position: 'relative'
	}
}));
