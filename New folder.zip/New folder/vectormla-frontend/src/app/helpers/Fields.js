import MuiSelectField from '../components/Select/Select';

import {
	interestRateItems,
	riskStressItem,
	marginItems,
	periodicCapItems,
	lifetimeCapItems,
	lifetimeFloorItems,
	rateResetFreqItems,
	couponPaymentFreqItems,
	durationChangeInYieldItems,
	prepayCurveItems,
	prepayStressItems,
	MLDefaultModelItems,
	grossCummulativeLossItems,
	lossStressItems,
	lossTimingCurveItems,
	recoveryRateItems,
	recoveryLagItems,
	yieldMaturityCurveItem,
	interestRateRevisionOnItems,
	/////////////////////////////////////////
	assetBasedFeesItems,
	reserveAccountItems,
	captureAllXsSpdItems,
	postTriggerDefaultMonthItems,
	defaultTriggerPrcntItems,
	swapActiveItems,
	swapRateInItems,
	swapRateOutItems,
	/////////////////////////////////////////
	advanceRateSeniorItems,
	liabilityInterestRateCurveSeniorItems,
	loanMarginSeniorItems,
	feesSeniorItems,
	reserveActiveSeniorItems,
	prinAllocationTypeSeniorItems,
	/////////////////////////////////////////
	liabilityInterestRateCurveSubItems,
	loanMarginSubItems,
	feesSubItems,
	advanceRateSubItems,
	reserveActivateAlwaysSubItems,
	prinAllocationTypeSubItems
} from './cashFlowSelectLists';

export const cashFlowSelect = [
	////////////////////////////////////////////
	{
		name: 'interest_rate_curve',
		label: 'Interest Rate',
		type: 'select',
		items: interestRateItems,
		default: 'Custom 2'
	},
	{
		name: 'interest_rate_revision_on',
		label: 'Interest Rate Revision',
		type: 'select',
		items: interestRateRevisionOnItems,
		default: 1
	},
	{
		name: 'yield_to_maturity_curve',
		label: 'Yield To Maturity Curve',
		type: 'select',
		items: yieldMaturityCurveItem,
		default: 'Yield-To-Maturity'
	},
	{
		name: 'risk_stress',
		label: 'Risk Stress',
		type: 'select',
		items: riskStressItem,
		default: 0.1
	},
	{
		name: 'margin',
		label: 'Margin',
		type: 'select',
		items: marginItems,
		default: 0
	},
	{
		name: 'periodic_cap',
		label: 'Periodic Cap',
		type: 'select',
		items: periodicCapItems,
		default: 1
	},
	{
		name: 'lifetime_cap',
		label: 'Lifetime Cap',
		type: 'select',
		items: lifetimeCapItems,
		default: 1
	},
	{
		name: 'lifetime_floor',
		label: 'Lifetime Floor',
		type: 'select',
		items: lifetimeFloorItems,
		default: 0
	},
	{
		name: 'rate_reset_freq',
		label: 'Rate Reset Freq',
		type: 'select',
		items: rateResetFreqItems,
		default: 1
	},
	{
		name: 'coupon_payment_freq',
		label: 'Coupon Payment Freq',
		type: 'select',
		items: couponPaymentFreqItems,
		default: 12
	},
	{
		name: 'duration_change_in_yield',
		label: 'Duration Change In Yield',
		type: 'select',
		items: durationChangeInYieldItems,
		default: 0.01 / 100
	},
	{
		name: 'prepay_curve',
		label: 'Prepay Curve',
		type: 'select',
		items: prepayCurveItems,
		default: 'SMM 0'
	},
	{
		name: 'prepay_stress',
		label: 'Prepay Stress',
		type: 'select',
		items: prepayStressItems,
		default: 1
	},
	{
		name: 'ml_default_model',
		label: 'ML Default Model',
		type: 'select',
		items: MLDefaultModelItems,
		default: 1
	},
	{
		name: 'gross_cummulative_loss',
		label: 'Cummulative PD',
		type: 'select',
		items: grossCummulativeLossItems,
		default: 0.01
	},
	{
		name: 'loss_stress',
		label: 'PD Stress',
		type: 'select',
		items: lossStressItems,
		default: 1
	},
	{
		name: 'loss_timing_curve',
		label: 'PD Timing Curve',
		type: 'select',
		items: lossTimingCurveItems,
		default: 'Timing Curve 1'
	},
	{
		name: 'recovery_rate',
		label: 'Recovery Rate',
		type: 'select',
		items: recoveryRateItems,
		default: 40 / 100
	},
	{
		name: 'recovery_lag',
		label: 'Recovery Lag',
		type: 'select',
		items: recoveryLagItems,
		default: 5
	},
	{
		name: 'LGD',
		label: 'LGD',
		type: 'select',
		items: recoveryRateItems,
		default: 5
	},

	////////////////////////////////////
	{
		name: 'asset_based_fees',
		label: 'Asset Based Fees',
		type: 'select',
		items: assetBasedFeesItems,
		default: 0.02
	},
	{
		name: 'reserve_account',
		label: 'Reserve Account',
		type: 'select',
		items: reserveAccountItems,
		default: 0.01
	},
	{
		name: 'capture_all_xs_spd',
		label: 'Capture All XS Spd',
		type: 'select',
		items: captureAllXsSpdItems,
		default: 'No'
	},
	{
		name: 'post_trigger_default_month',
		label: 'Post Trigger Default',
		type: 'select',
		items: postTriggerDefaultMonthItems,
		default: 3
	},
	{
		name: 'default_trigger_prcnt',
		label: 'Default Trigger Prcnt',
		type: 'select',
		items: defaultTriggerPrcntItems,
		default: 0.05
	},
	{
		name: 'swap_active',
		label: 'Swap Active',
		type: 'select',
		items: swapActiveItems,
		default: 'Yes'
	},
	{
		name: 'swap_rate_in',
		label: 'Swap Rate In',
		type: 'select',
		items: swapRateInItems,
		default: '1-Month LIBOR'
	},
	{
		name: 'swap_rate_out',
		label: 'Swap Rate Out',
		type: 'select',
		items: swapRateOutItems,
		default: 'Custom 1'
	},

	////////////////////////////////////
	{
		name: 'advance_rate',
		label: 'Advance Rate',
		type: 'select',
		items: advanceRateSeniorItems,
		default: 0.897470882776579
	},
	{
		name: 'liability_interest_rate_curve',
		label: 'Int Rate Curve',
		type: 'select',
		items: liabilityInterestRateCurveSeniorItems,
		default: '1-Month LIBOR'
	},
	{
		name: 'loan_margin',
		label: 'Int Rate Margin',
		type: 'select',
		items: loanMarginSeniorItems,
		default: 0.01
	},
	{
		name: 'fees',
		label: 'Fees',
		type: 'select',
		items: feesSeniorItems,
		default: 0.005
	},
	{
		name: 'reserve_active',
		label: 'Reserve Active',
		type: 'select',
		items: reserveActiveSeniorItems,
		default: 'Yes'
	},
	{
		name: 'prin_allocation_type',
		label: 'Principal Allocation',
		type: 'select',
		items: prinAllocationTypeSeniorItems,
		default: 'Pro Rate'
	},
	////////////////////////////////////////////
	{
		name: 'advance_rate',
		label: 'Advance Rate',
		type: 'select',
		items: advanceRateSubItems,
		default: 0.897470882776579
	},
	{
		name: 'liability_interest_rate_curve',
		label: 'Liability Interest Rate Curve',
		type: 'select',
		items: liabilityInterestRateCurveSubItems,
		default: 'Custom 1'
	},
	{
		name: 'loan_margin',
		label: 'Loan Margin',
		type: 'select',
		items: loanMarginSubItems,
		default: 0.0
	},
	{
		name: 'fees',
		label: 'Fees',
		type: 'select',
		items: feesSubItems,
		default: 0.0
	},
	{
		name: 'reserve_active_always',
		label: 'Reserve Active',
		type: 'select',
		items: reserveActivateAlwaysSubItems,
		default: 'No'
	},
	{
		name: 'prin_allocation_type',
		label: 'Prin Allocation Type',
		type: 'select',
		items: prinAllocationTypeSubItems,
		default: 'Pro Rate'
	}
];

export const fpnaSelect = [
	///////// GENERAL /////////////
	{
		name: 'risk_stress',
		label: 'Risk Stress',
		type: 'input',
		default: 0.1
	},
	{
		name: 'yield_to_maturity_curve',
		label: 'Yield To Maturity Curve',
		type: 'select',
		items: yieldMaturityCurveItem,
		default: 'Yield-To-Maturity'
	},
	{
		name: 'coupon_payment_freq',
		label: 'Coupon Payment Freq',
		type: 'input',
		default: 12
	},
	{
		name: 'duration_change_in_yield',
		label: 'Duration Change In Yield',
		type: 'input',
		default: 0.01 / 100
	},
	{
		name: 'prepay_curve',
		label: 'Prepay Curve',
		type: 'select',
		items: prepayCurveItems,
		default: 'SMM 0'
	},
	{
		name: 'prepay_stress',
		label: 'Prepay Stress',
		type: 'input',
		default: 1
	},
	{
		name: 'gross_cummulative_loss',
		label: 'Cummulative PD',
		type: 'input',
		default: 0.01
	},
	{
		name: 'loss_stress',
		label: 'PD Stress',
		type: 'input',
		default: 1
	},
	{
		name: 'loss_timing_curve',
		label: 'PD Timing Curve',
		type: 'select',
		items: lossTimingCurveItems,
		default: 'Timing Curve 1'
	},
	{
		name: 'recovery_rate',
		label: 'Recovery Rate',
		type: 'input',
		default: 40 / 100
	},
	{
		name: 'recovery_lag',
		label: 'Recovery Lag',
		type: 'input',
		default: 5
	},

	////////// INCOME STATEMENT /////////////
	{
		name: 'debt_prcnt',
		label: 'Debt Percentage',
		type: 'input',
		default: 0.9
	},
	{
		name: 'equity_prcnt',
		label: 'Equity Percentage',
		type: 'input',
		default: 0.1
	},
	{
		name: 'supercede_loan_level_interest_rate',
		label: 'Supercede Interest Rate',
		type: 'select',
		items: interestRateRevisionOnItems
	},
	{
		name: 'fpna_loan_level_interest_rate',
		label: 'FPNA Interest Rate',
		type: 'input',
		default: 9
	},
	{
		name: 'interest_income_rate',
		label: 'Interest Income Rate',
		type: 'input',
		default: 7.3
	},
	{
		name: 'discount_rate',
		label: 'Discount Rate',
		type: 'input',
		default: 7.35306377657358 / 100
	},
	{
		name: 'interest_expense_rate',
		label: 'Interest Expense Rate',
		type: 'input',
		default: 0.04
	},
	{
		name: 'annual_origination_lead_cost_rate',
		label: 'Annual Lead Cost Rate',
		type: 'input',
		default: 0.25 / 100
	},
	{
		name: 'annual_default_rate',
		label: 'Annual Default Rate',
		type: 'input',
		default: 0.0
	},
	{
		name: 'annual_mortgage_servicing_rate',
		label: 'Annual mortgage Rate',
		type: 'input',
		default: 0.25 / 100
	},
	{
		name: 'annual_overhead_capex_rate',
		label: 'Annual overhead Capex Rate',
		type: 'input',
		default: 0.5 / 100
	},
	{
		name: 'annual_fees_revenue_lower_rate_f_rate',
		label: 'Annual Fees Revenue Rate',
		type: 'input',
		default: -0.25 / 100
	},
	{
		name: 'tax_rate',
		label: 'Tax Rate',
		type: 'input',
		default: 0.4
	},
	///////// FPNA /////////////
	{
		name: 'common_shares',
		label: 'Common Shares',
		type: 'input',
		default: 0.4
	},
	{
		name: 'dividend_rate',
		label: 'Dividend Rate',
		type: 'input',
		default: 0.0
	},
	{
		name: 'required_equity_rate',
		label: 'Required Equity Rate',
		type: 'input',
		default: 0.1
	},
	{
		name: 'average_loan_amnt',
		label: 'Average Loan Amount',
		type: 'input',
		default: 0.4
	}
];
const defaultInput = [
	'ml_default_model',
	'gross_cummulative_loss',
	'loss_stress',
	'loss_timing_curve',
	'recovery_rate',
	'recovery_lag',
	'LGD'
];
const recovery = [];
const prepayment = ['prepay_curve', 'prepay_stress'];
const advancedRate = [
	'advance_rate',
	'loan_margin',
	'fees',
	'liability_interest_rate_curve',
	'prin_allocation_type',
	'reserve_active'
];
const subDebt = [
	'advance_rate',
	'liability_interest_rate_curve',
	'loan_margin',
	'fees',
	'reserve_active_always',
	'prin_allocation_type'
];
const triggers = [
	'asset_based_fees',
	'reserve_account',
	'capture_all_xs_spd',
	'default_trigger_prcnt',
	'post_trigger_default_month'
];
const swap = ['swap_active', 'swap_rate_in', 'swap_rate_out'];
const fpnaGeneral = [
	'risk_stress',
	'coupon_payment_freq',
	'duration_change_in_yield',
	'prepay_curve',
	'prepay_stress',
	'gross_cummulative_loss',
	'loss_stress',
	'loss_timing_curve',
	'recovery_rate',
	'recovery_lag',
	'yield_to_maturity_curve'
];
const fpnaIncomeStatement = [
	'debt_prcnt',
	'equity_prcnt',
	'supercede_loan_level_interest_rate',
	'fpna_loan_level_interest_rate',
	'interest_income_rate',
	'discount_rate',
	'interest_expense_rate',
	'annual_origination_lead_cost_rate',
	'annual_default_rate',
	'annual_mortgage_servicing_rate',
	'annual_overhead_capex_rate',
	'annual_fees_revenue_lower_rate_f_rate',
	'tax_rate'
];
const fpna = [
	'common_shares',
	'dividend_rate',
	'required_equity_rate',
	'average_loan_amnt'
];
///////////////////////////////////
export const selectGroup = {
	defaultInput,
	recovery,
	prepayment,
	advancedRate,
	triggers,
	swap,
	subDebt,
	fpnaGeneral,
	fpnaIncomeStatement,
	fpna
};
