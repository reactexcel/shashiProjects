import React, { useState } from 'react';
import { useStyles } from '.././components/Table/tableStyles';
import { CircularProgress } from '@material-ui/core';

const PDFViewer = ({ pdfUrl, pdfName, displayOnlyName = false, model }) => {
	const [tableVisible, setTableVisible] = useState(false);
	const classes = useStyles();

	return (
		<>
			<div
				className={classes.contentHeaderContainer}
				onClick={() => setTableVisible(!tableVisible)}
			>
				<p className={classes.contentHeader}>{pdfName}</p>
			</div>
			<div style={{ marginBottom: 20 }}></div>
			{tableVisible && pdfUrl && (
				<iframe
					src={pdfUrl}
					title="PDF Viewer"
					width="100%"
					height="700px"
					style={{ border: 'none' }}
				>
					This browser does not support PDFs. Please download the PDF to view
					it: <a href={pdfUrl}>Download PDF</a>.
				</iframe>
			)}
			{displayOnlyName && !pdfUrl && tableVisible ? (
				<div className={classes.progressContainer}>
					<CircularProgress
						style={{
							color: '#266696',
							marginTop: 0,
							marginLeft: '49%'
						}}
						size={26}
					/>
				</div>
			) : null}
		</>
	);
};

export default PDFViewer;
