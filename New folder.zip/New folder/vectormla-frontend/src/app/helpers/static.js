export const numberOfLoanValues = (model) => {
	const capitalMarketModels = ['securitization', 'fpna6-3'];
	const capitalMarkets = [
		[
			{
				title: 'Total Receivables',
				amount: '$ 262,350,000'
			},
			{
				title: 'Eligible Receivables',
				amount: '$ 245,349,999'
			}
		],
		[
			{
				title: 'Ineligible Receivables',
				amount: '$ 17,000,000'
			},
			{
				title: 'Remaining Eligible Receivables',
				amount: '$ 62,000,000'
			}
		],

		[
			{
				title: 'Facility Utilization',
				amount: '63.41%'
			},
			{
				title: 'Remaining Facility Amount',
				amount: '$ 76,800,002'
			}
		],
		[
			{
				title: 'Effective Advance Rate',
				amount: '80.00%'
			},
			{
				title: 'Expected Monthly Collections',
				amount: '$ 4,372,500'
			}
		],
		[
			{
				title: 'Excess concentration',
				amount: '$ 1,884,900'
			},
			{
				title: 'Covenant Breach',
				amount: 'No'
			}
		],
		[
			{
				title: 'Avg. RM of Pledged Recv',
				amount: '48.8 months'
			},
			{
				title: 'Delinquencies',
				amount: '0.01%'
			}
		]
	];

	const treasuryModels = [
		'prepayment',
		'fpna5-1-1-0',
		'fpna6-1-1',
		'fpna9-1-1'
	];
	const treasury = [
		[
			{
				title: 'SOFR %',
				amount: '4.30  %'
			},
			{
				title: 'Average Loan Rate',
				amount: '9.12%'
			}
		],
		[
			{
				title: 'index',
				amount: '1M SOFR + 4.01%'
			},
			{
				title: 'Prepayment Rate (CPR)',
				amount: '5.01%'
			}
		],

		[
			{
				title: '12 EaR -100 bps Parallel Shock',
				amount: '-$616,866'
			},
			{
				title: '12 EaR +100 bps Parallel Shock',
				amount: '-$800,798'
			}
		],
		[
			{
				title: '12 EaR +200 bps Parallel Shock',
				amount: '-$524,900'
			},
			{
				title: '12 EaR -200 bps Parallel Shock',
				amount: '-$892,765'
			}
		],
		[
			{
				title: 'EVE +100 bps Parallel Shock',
				amount: '-$616,866'
			},
			{
				title: 'EVE -100 bps Parallel Shock',
				amount: '-$800,798'
			}
		],
		[
			{
				title: 'EVE +200 bps Parallel Shock',
				amount: '-$524,900'
			},
			{
				title: 'EVE -200 bps Parallel Shock',
				amount: '-$892,765'
			}
		]
	];

	const fpnaModels = [
		'fpna1',
		'cashflow',
		'fpna2',
		'fpna3',
		'fpna4',
		'fpna5-3-1-0',
		'fpna6-3-1',
		'fpna9-3-1',
		'fpna0'
	];
	const fpna = [
		[
			{
				title: 'Cash',
				amount: '$ 4,120,276'
			},
			{
				title: 'Equity',
				amount: '$ 16,120,276'
			}
		],
		[
			{
				title: 'Loans',
				amount: '$ 116,077,563'
			},
			{
				title: 'Total Assets',
				amount: '$ 119,532,692'
			}
		],

		[
			{
				title: '12M Interest Income',
				amount: '$ 22,611,108'
			},
			{
				title: '12M Fee Income',
				amount: '$ 291,288'
			}
		],
		[
			{
				title: 'Interest Expense',
				amount: '$ 11,155,752'
			},
			{
				title: 'Interest Expense',
				amount: '$ 352,725'
			}
		],
		[
			{
				title: 'Current ROA %',
				amount: '-6.71%'
			},
			{
				title: 'Target ROA %',
				amount: '2%'
			}
		],
		[
			{
				title: 'Leverage',
				amount: '8.91'
			},
			{
				title: 'Leverate Target',
				amount: '10'
			}
		]
	];

	const creditRiskModels = [
		'credit2',
		'fpna5-2-1-0',
		'fpna6-2-1',
		'fpna9-2-1',
		'default'
	];
	const creditRisk = [
		[
			{
				title: 'Cumulative Probability of Default (PD)',
				amount: '$ 5.50%'
			},
			{
				title: 'Loss Given Default (LGD)',
				amount: '50%'
			}
		],
		[
			{
				title: 'Exposure at Default (EAD)',
				amount: '89%'
			},
			{
				title: 'Expected Loss (EL)',
				amount: '2.44%'
			}
		],

		[
			{
				title: 'Total Deliquency Account',
				amount: '8.9%'
			},
			{
				title: '0-30 Deliquent Account',
				amount: '4.0%'
			}
		],
		[
			{
				title: '31-60 Deliquent Account',
				amount: '2.9%'
			},
			{
				title: '61-90 Deliquent Account',
				amount: '2.0%'
			}
		],
		[
			{
				title: '91-120 Deliquent Account',
				amount: '2.0%'
			},
			{
				title: 'Credit Premium on New Origination',
				amount: '3.1%'
			}
		],
		[
			{
				title: 'Recovery Ratio',
				amount: '50%'
			},
			{
				title: 'Recovery Lag',
				amount: '12M'
			}
		]
	];

	if (treasuryModels.includes(model)) {
		return treasury;
	}
	if (fpnaModels.includes(model)) {
		return fpna;
	}
	if (capitalMarketModels.includes(model)) {
		return capitalMarkets;
	}
	if (creditRiskModels.includes(model)) {
		return creditRisk;
	}
};
