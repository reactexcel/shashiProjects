const poolHeader = [
	'Pool Number',
	'Month End Reporting Period Date',
	'Settlement Date',
	'Date First CPN',
	'WAL Year',
	'Coupon',
	'WAC',
	'RAM',
	'Core Liquidation Rate LQR',
	'Partial Prepayment Rate',
	'T1 Balance',
	'T2 Balance',
	'T3 Balance',
	'T4 Balance',
	'T5 Balance',
	'T6 Balance',
	'Maturity Date',
	'25 BPS',
	'Days Accrued',
	'Days in Month',
	'A Factor',
	'D Factor',
	'WAL Day',
	'WAL Date',
	'Monthly Coupon',
	'WAC Monthly Rate',
	'Monthly Core Liquidation Rate LQR',
	'Monthly Partial Prepayment Rate PPR',
	'AMT Outstanding',
	'T1 rem. Month',
	'T2 rem. Month',
	'T3 rem. Month',
	'T4 rem. Month',
	'T5 rem. Month',
	'T6 rem. Month',
	'Ys',
	'GOC rate',
	'A',
	'B',
	'X',
	'Y'
];
const poolAttributes = [
	'pool_number',
	'month_end_reporting_period_date',
	'settlement_date',
	'date_first_cpn',
	'wal_year',
	'coupon',
	'wac',
	'ram',
	'core_liquidation_rate_lqr',
	'partial_prepayment_rate',
	't1_balance',
	't2_balance',
	't3_balance',
	't4_balance',
	't5_balance',
	't6_balance',
	'maturity_date',
	'bps_25',
	'days_accrued',
	'days_in_month',
	'a',
	'd',
	'wal_day',
	'wal_date',
	'monthly_coupon',
	'wac_monthly_rate',
	'lqr_q',
	'ppr_p',
	'amt_outstanding',
	't1_month',
	't2_month',
	't3_month',
	't4_month',
	't5_month',
	't6_month',
	'ys',
	'goc_rate',
	'MD_A',
	'MD_B',
	'MD_X',
	'MD_Y'
];
const gocRateHeader = [
	'Ticker',
	'GOC Bond',
	'GOC Maturity Date',
	'GOC Rate',
	'MBS Model'
];
const gocRateAttributes = [
	'ticker',
	'goc_bond',
	'goc_maturity_date',
	'goc_rate',
	'mbs_model'
];

const trancheSumHeader = [
	'Tranche',
	'Discounted MBS CFt',
	'Full Price',
	'Opening Balance',
	'Weight',
	'Weight x Rate'
];
const trancheSumAttributes = [
	'tranche',
	'discounted_mbs_cft',
	'full_price',
	'opening_balance',
	'weight',
	'weight_x_rate'
];

const poolPriceHeader = [
	'Pool Number',
	'Accrued Interest',
	'Clean Price',
	'Factor Clean Price',
	'Factor Clean Price - 1',
	'WAFP Full Price',
	'MBS Model'
];

const poolPriceAttributes = [
	'pool_number',
	'accrued_interest',
	'clean_price',
	'factor_clean_price',
	'factor_clean_price_m_1',
	'wafp_full_price',
	'mbs_model'
];

const trancheHeader = [
	'Period',
	'Balance',
	'Interest',
	'Principal',
	'Monthly Payment',
	'Partial Prepayment Rate',
	'Core Liquidation Rate',
	'MBS Payment',
	'MBS CNP Payment',
	'MBS CF t',
	'Discount Factor',
	'Discount MBS CFt',
	'Pool ID'
];
const trancheAttributes = [
	'period',
	'balance',
	'interest',
	'principal',
	'monthly_payment',
	'partial_prepayment_rate',
	'core_liquidation_rate',
	'mbs_payment',
	'mbs_cnp_payment',
	'mbs_cf_t',
	'discount_factor',
	'discounted_mbs_cft',
	'pool'
];
module.exports = {
	poolHeader,
	poolAttributes,
	gocRateHeader,
	gocRateAttributes,
	trancheSumHeader,
	trancheSumAttributes,
	poolPriceHeader,
	poolPriceAttributes,
	trancheHeader,
	trancheAttributes
};
