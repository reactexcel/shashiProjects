export const populationByRegions = [
	{
		region: 'Asia',
		val: 4119626293
	},
	{
		region: 'Africa',
		val: 1012956064
	},
	{
		region: 'Northern America',
		val: 344124520
	},
	{
		region: 'Caribbean',
		val: 590946440
	},
	{
		region: 'Europe',
		val: 727082222
	},
	{
		region: 'Oceania',
		val: 35104756
	}
];

export const TypesOfLoans = [
	{
		region: '36 Months',
		val: 331.062
	},
	{
		region: '60 Months',
		val: 135.222
	}
];

export const AvgIntPreLoans = [
	{
		region: 'Defaulted Loans',
		val: 54.81
	},
	{
		region: 'Non Defaulted Loans',
		val: 45.19
	}
];

export const AvgAnnuPreLoans = [
	{
		region: 'Non Defaulted Loans',
		val: 50.79
	},
	{
		region: 'Defaulted Loans',
		val: 49.21
	}
];

export const AvgEmploymentLengthPredictedLoans = [
	{
		region: 'Non Defaulted Loans',
		val: 5.71
	},
	{
		region: 'Defaulted Loans',
		val: 4.57
	}
];
export const AvgDTIPredictedLoans = [
	{
		region: 'Non Defaulted Loans',
		val: 17.3
	},
	{
		region: 'Defaulted Loans',
		val: 15.8
	}
];
export const AvgMonthsSinceLastCreditLinePredicted = [
	{
		region: 'Non Defaulted Loans',
		val: 267.93
	},
	{
		region: 'Defaulted Loans',
		val: 228.75
	}
];

export const AvgOpenAccountsPredictedLoans = [
	{
		region: 'Non Defaulted Loans',
		val: 55
	},
	{
		region: 'Defaulted Loans',
		val: 45
	}
];

export const ownership = [
	{
		region: 'Mortgage',
		val: 50
	},
	{
		region: 'Rent',
		val: 35
	},
	{
		region: 'Own',
		val: 15
	}
	// {
	//   region: "Other",
	//   val: 0,
	// },
	// {
	//   region: "None",
	//   val: 0,
	// },
	// {
	//   region: "Any",
	//   val: 0,
	// },
];

export const TypesOfLoansByAmount = [
	{ age: '0-5K', number: 51 },
	{ age: '5K-10K', number: 98 },
	{ age: '10K-15K', number: 102 },
	{ age: '15K-20K', number: 65 },
	{ age: '20K-25K', number: 54 },
	{ age: '25K-30K', number: 84 }
];

export const grossProductData = [
	{
		state: 'Illinois',
		year1998: 423.721,
		year2001: 476.851,
		year2004: 528.904
	},
	{
		state: 'Indiana',
		year1998: 178.719,
		year2001: 195.769,
		year2004: 227.271
	},
	{
		state: 'Michigan',
		year1998: 308.845,
		year2001: 335.793,
		year2004: 372.576
	},
	{
		state: 'Ohio',
		year1998: 348.555,
		year2001: 374.771,
		year2004: 418.258
	},
	{
		state: 'Wisconsin',
		year1998: 160.274,
		year2001: 182.373,
		year2004: 211.727
	}
];

export const exportImportData = [
	{
		Country: 'CA',
		Export: 243,
		Import: 233
	},
	{
		Country: 'FL',
		Export: 529,
		Import: 335
	},
	{
		Country: 'GA',
		Export: 293,
		Import: 489
	},
	{
		Country: 'IL',
		Export: 2049,
		Import: 1818
	},
	{
		Country: 'NJ',
		Export: 799,
		Import: 886
	},
	{
		Country: 'NY',
		Export: 1547,
		Import: 2335
	},
	{
		Country: 'PA',
		Export: 455,
		Import: 475
	},
	{
		Country: 'TX',
		Export: 569,
		Import: 674
	},
	{
		Country: 'OH',
		Export: 468,
		Import: 680
	},
	{
		Country: 'VA',
		Export: 1407,
		Import: 1167
	}
];

export const citiesPopulation = [
	{
		value: 24256800,
		name: 'CA'
	},
	{
		value: 23500000,
		name: 'FL'
	},
	{
		value: 21516000,
		name: 'GA'
	},
	{
		value: 16787941,
		name: 'IL'
	},
	{
		value: 15200000,
		name: 'NY'
	},
	{
		value: 21416000,
		name: 'NJ'
	},
	{
		value: 16987941,
		name: 'PA'
	},
	{
		value: 11200000,
		name: 'OH'
	}
];

export const inflationData = [
	{
		date: new Date(2010, 0, 1),
		val2010: 1.63,
		val2011: 2.63
	},
	{
		date: new Date(2010, 1, 1),
		val2010: 2.11,
		val2011: 2.14
	},
	{
		date: new Date(2010, 2, 1),
		val2010: 2.68,
		val2011: 2.31
	},
	{
		date: new Date(2010, 3, 1),
		val2010: 3.16,
		val2011: 2.24
	},
	{
		date: new Date(2010, 4, 1),
		val2010: 3.57,
		val2011: 2.02
	},
	{
		date: new Date(2010, 5, 1),
		val2010: 3.56,
		val2011: 1.05
	},
	{
		date: new Date(2010, 6, 1),
		val2010: 3.63,
		val2011: 1.24
	},
	{
		date: new Date(2010, 7, 1),
		val2010: 3.77,
		val2011: 1.15
	},
	{
		date: new Date(2010, 8, 1),
		val2010: 3.87,
		val2011: 1.14
	},
	{
		date: new Date(2010, 9, 1),
		val2010: 3.53,
		val2011: 1.17
	},
	{
		date: new Date(2010, 10, 1),
		val2010: 3.39,
		val2011: 1.14
	},
	{
		date: new Date(2010, 11, 1),
		val2010: 2.96,
		val2011: 1.5
	}
];

export const dataSource = [
	{
		country: 'CA',
		medals: 112
	},
	{
		country: 'FL',
		medals: 100
	},
	{
		country: 'GA',
		medals: 60
	},
	{
		country: 'IL',
		medals: 49
	},
	{
		country: 'NJ',
		medals: 46
	},
	{
		country: 'NY',
		medals: 43
	},
	{
		country: 'PA',
		medals: 41
	},
	{
		country: 'TX',
		medals: 32
	},
	{
		country: 'OH',
		medals: 29
	},
	{
		country: 'VA',
		medals: 27
	}
	// {
	//   country: "Japan",
	//   medals: 25,
	// },
	// {
	//   country: "Ukraine",
	//   medals: 22,
	// },
	// {
	//   country: "Canada",
	//   medals: 20,
	// },
	// {
	//   country: "Spain",
	//   medals: 19,
	// },
];

export const AveragePredicted = [
	{
		AveragePredicted: 'Defaulted Loans',
		AveragePredictedOpen: 45.32,
		AveragePredictedLast: 62.28
	},
	{
		AveragePredicted: 'Non Defaulted Loans',
		AveragePredictedOpen: 54.68,
		AveragePredictedLast: 37.72
	}
];
