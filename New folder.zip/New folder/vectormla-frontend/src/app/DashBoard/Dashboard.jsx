import React, { useState } from 'react';
import { withRouter } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { compose } from 'recompose';
import { Field, reduxForm } from 'redux-form';
import { useStyles } from './dashboardStyles';
import { Typography, Grid, Button } from '@material-ui/core';
import StateAnalysis from './Pages/StateAnalysis';
import InfoIcon from '@material-ui/icons/Info';
import MuiSelectField from '../components/Select/Select';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';

const Dashboard = () => {
	const user = useSelector((state) => state.auth.user);
	const classes = useStyles();
	const [port, setPort] = useState(1);
	const { ref: dashboardRef, height: dashboardHeight } = useComponentSize();

	if (!user?.allowed_pages?.includes(6)) return <div></div>;

	const handlePortfolio = (e) => setPort(e.target.value);
	const handleRun = () => {};

	return (
		<div
			ref={dashboardRef}
			className={classes.appContainer}
			style={{ paddingTop: 0 }}
		>
			<RenderAlphaBar containerHeight={dashboardHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid container spacing={1} item xs={11}>
					{/*					<div className={classes.title}>
						<Grid
							item
							container
							xs={4}
							alignItems="center"
							style={{
								position: 'absolute',
								left: 0,
								top: -10,
								zIndex: 999,
								marginTop: '70px'
							}}
						>
							<Typography
								variant="subtitle2"
								align="left"
								style={{ color: '#000' }}
							>
								Portfolio
							</Typography>
							<InfoIcon className={classes.selectIcon} />
							<Field
								name="Portfolio"
								label="Portfolio"
								required
								native={true}
								value={+port}
								view={'lyar'}
								component={MuiSelectField}
								onChange={handlePortfolio}
							>
								{[{ id: 1, name: 'Lending Club' }].map((op, index) => {
									return (
										<option key={index} value={+op.id}>
											{op.name}
										</option>
									);
								})}
							</Field>
							<Button className={classes.header__run} onClick={handleRun}>
								Run
							</Button>
						</Grid>
						<Typography className={classes.title__typo}>
							LENDING CLUB
						</Typography>
							</div>*/}
					<StateAnalysis classes={classes} />
				</Grid>
			</Grid>
		</div>
	);
};

export default compose(
	reduxForm({ form: 'automl_select', destroyOnUnmount: false })
)(withRouter(Dashboard));
