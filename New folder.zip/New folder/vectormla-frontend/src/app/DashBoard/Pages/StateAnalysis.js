import React from 'react';
import { Grid } from '@material-ui/core';
import { withRouter } from 'react-router-dom';
import {
	DeveTree,
	Pie,
	BarDifferentColor,
	Bar,
	MainBarLine,
	BarMultiColor,
	StackedBar
} from '../Charts';
import { summaryArr } from './CommonAssests';
import MuiIntegratedTable from '../IntegratedTables/MuiIntegratedTable';

const StateAnalysis = ({ classes }) => {
	const chartArr = [
		{
			chart: <DeveTree classes={classes} />
		},
		{
			chart: <MainBarLine classes={classes} no={5} />
		},
		{
			chart: <Pie classes={classes} no={1} />
		},
		{
			chart: <BarDifferentColor classes={classes} />
		},
		{
			chart: <Bar classes={classes} />
		},
		// {
		//   chart: <BarMultiColor classes={classes} no={1} />,
		// },
		{
			chart: <BarMultiColor classes={classes} no={2} />
		},
		// {
		//   chart: <BarMultiColor classes={classes} no={3} />,
		// },
		{
			chart: <MainBarLine classes={classes} no={1} />
		},
		// {
		//   chart: <MainBarLine classes={classes} no={2} />,
		// },
		{
			chart: <MainBarLine classes={classes} no={3} />
		},
		{
			chart: <StackedBar classes={classes} />
		},
		{
			chart: <Pie classes={classes} no={2} />
		},

		{
			chart: <Pie classes={classes} no={5} />
		},
		{
			chart: <Pie classes={classes} no={6} />
		},
		{
			chart: <Pie classes={classes} no={4} />
		},
		{
			chart: <MainBarLine classes={classes} no={6} />
		}
	];
	return (
		<>
			<Grid
				container
				item
				xs={12}
				justify="space-around"
				style={{ margin: '90px 0px 40px 0px' }}
			>
				{summaryArr.map((m, index) => (
					<Grid xs={10} sm={5} md={4} lg={2} item key={index}>
						<div className={classes.main__div}>
							<div className={classes.header__typo}>{m.name}</div>
							<div className={classes.header__value}>{m.no}</div>
							<div className={classes.header__sub}>17-Dec-2020</div>
						</div>
					</Grid>
				))}
			</Grid>
			<Grid
				container
				item
				xs={12}
				justify="space-between"
				style={{ marginBottom: 40 }}
			>
				{chartArr.map((m, index) => (
					<Grid
						key={index}
						item
						container
						alignItems="flex-start"
						justify="flex-start"
						xs={10}
						sm={5}
						md={6}
						style={{ height: '400px', margin: '70px 0px 70px 0px' }}
					>
						{m.chart}
					</Grid>
				))}
			</Grid>
			{/* the draggable table <Grid
				container
				item
				xs={12}
				justify="space-around"
				style={{ minHeight: '10px', marginTop: 30 }}
			>
				<MuiIntegratedTable />
			</Grid>*/}
		</>
	);
};

export default withRouter(StateAnalysis);
