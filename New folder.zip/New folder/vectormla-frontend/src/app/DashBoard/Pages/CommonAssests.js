export const summaryArr = [
	{
		name: 'Total Number of Loans',
		value: 'total_number_of_loans',
		no: '466,285'
	},
	{
		name: 'Total Funded Amount',
		value: 'total_funded_amount',
		no: '6,664,052,450'
	},
	{ name: 'Average Loan Size', value: 'average_loan_size', no: '14,852' },
	{
		name: 'Total Charged-off Loans',
		value: 'total_charge_off_loans',
		no: '42,475'
	},
	{
		name: 'Avg Interest Rate %',
		value: 'average_interest_rate',
		no: '13.8 %'
	},
	{ name: 'Average DTI', value: 'average_dti', no: '17.2 %' }
];
