import React from 'react';
import PieChart, {
	Legend,
	Series,
	Tooltip,
	Format,
	Label,
	Connector,
	CommonSeriesSettings,
	HoverStyle,
	SelectionStyle,
	Hatching,
	Animation,
	Font,
	Margin
} from 'devextreme-react/pie-chart';
import {
	TypesOfLoans,
	ownership,
	AvgIntPreLoans,
	AvgAnnuPreLoans,
	AvgEmploymentLengthPredictedLoans,
	AvgDTIPredictedLoans,
	AvgMonthsSinceLastCreditLinePredicted,
	AvgOpenAccountsPredictedLoans
} from '../Data/deveData.js';
import { IconButton } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';

const DevePie = ({ classes, no }) => {
	const PieRef = React.createRef();

	//first is dark blue, second is cyan,third is yellow
	const service = [
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7', '#ECD46E'] },
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7'] },
		{ colorArray: ['#26649e', '#2CC9B7'] }
	];

	const dataSrc = [
		TypesOfLoans,
		ownership,
		AvgIntPreLoans,
		AvgAnnuPreLoans,
		AvgEmploymentLengthPredictedLoans,
		AvgDTIPredictedLoans,
		AvgMonthsSinceLastCreditLinePredicted,
		AvgOpenAccountsPredictedLoans
	];

	const titles = [
		'Loans By Term',
		'Home OwnerShip Status',
		'Average Interest Rate by Predicted Loans',
		'Average Annual Income by Predicted Loans',
		'Average Employment Length by Months',
		'Average DTI by Predicted Loans',
		'Average Months Since Last Credit Line of Predicted',
		'Average of Open Accounts by Predicted Loans'
	];

	const customizeTooltip = (arg) => {
		return {
			text: `${arg.percent * 100}%`
		};
	};

	const exportChart = () => {
		PieRef.current.instance.exportTo('Example', 'png');
	};

	//   const pointClickHandler = (e) => {
	//     e.target.select();
	//   };

	//   const pointClickHandlerVi = (e) => {
	//     toggleVisibility(e.target);
	//   };

	const legendClickHandler = (e) => {
		let arg = e.target;
		let item = e.component.getAllSeries()[0].getPointsByArg(arg)[0];
		toggleVisibility(item);
	};

	const toggleVisibility = (item) => {
		item.isVisible() ? item.hide() : item.show();
	};

	function onPointClick({ target: point }) {
		if (point.isSelected()) {
			point.clearSelection();
		} else {
			point.select();
		}
	}

	const customizeLabel = (e) => {
		// return `${e.argumentText} :\n${e.valueText}`;
		return `${e.argumentText} : ${e.valueText}`;
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>{titles[no - 1]}</div>
			<PieChart
				id="chart"
				ref={PieRef}
				type="doughnut"
				palette={service[no - 1].colorArray}
				dataSource={dataSrc[no - 1]}
				// onPointClick={onPointClick}
				onLegendClick={legendClickHandler}
				// innerRadius={1}
			>
				<Series argumentField="region">
					{/* <Label visible={true}>
            <Connector visible={true} />
          </Label> */}
					<Label
						// visible={no !== 2 ? true : false}
						visible={true}
						format="fixedPoint"
						customizeText={customizeLabel}
						backgroundColor="none"
					>
						<Font color="#000" />
						<Connector visible={true}></Connector>
					</Label>
					<SelectionStyle color="#ECD46E">
						<Hatching direction="none" />
					</SelectionStyle>
				</Series>
				<Legend
					margin={10}
					horizontalAlignment="center"
					verticalAlignment="bottom"
					itemTextPosition="left"
				/>
				{/* <Tooltip enabled={true} customizeTooltip={customizeTooltip} /> */}
				<Animation enabled={true} />
			</PieChart>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default DevePie;
