import React from 'react';
import {
	Chart,
	CommonSeriesSettings,
	Label,
	Format,
	Legend,
	Tooltip,
	SeriesTemplate,
	LoadingIndicator,
	ArgumentAxis,
	Tick,
	MinorTick,
	Font
} from 'devextreme-react/chart';
import { TypesOfLoansByAmount } from '../Data/deveData.js';
import { IconButton, Typography } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';

const BarDifferentColor = ({ classes }) => {
	const BarRef = React.createRef();

	const exportChart = () => {
		BarRef.current.instance.exportTo('Example', 'png');
	};

	//   const onPointClick = ({ target: point }) => {
	//     point.select();
	//   };

	const onLegendClick = ({ target: series }) => {
		if (series.isVisible()) {
			series.hide();
		} else {
			series.show();
		}
	};

	const customizeLabel = (e) => {
		return `${e.valueText}`;
	};

	const customizeTooltip = (arg) => {
		return {
			text: `${arg.seriesName} : ${arg.valueText}`
		};
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>Loans By Amount</div>
			<Chart
				id="chart"
				ref={BarRef}
				// title="Gross State Product within the Great Lakes Region"
				dataSource={TypesOfLoansByAmount}
				// onPointClick={onPointClick}
				palette={[
					//"#2CC9B7",
					'#26649E'
					// "#26649E",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#26649E",
				]}
				// onPointClick={pointClickHandler}
				onLegendClick={onLegendClick}
			>
				<CommonSeriesSettings
					hoverMode="allArgumentPoints"
					selectionMode="allArgumentPoints"
					argumentField="age"
					valueField="number"
					type="bar"
					ignoreEmptyPoints={true}
				>
					{/* <Label visible={true}>
            <Format type="fixedPoint" precision={0} />
            <Font color="#FFF" size={10} />
          </Label> */}
					<Label
						visible={true}
						backgroundColor="none"
						customizeText={customizeLabel}
					>
						<Font color="#000" size={10} />
						<Format type="fixedPoint" precision={0} />
					</Label>
				</CommonSeriesSettings>
				<SeriesTemplate nameField="age" />
				<Legend
					verticalAlignment="bottom"
					horizontalAlignment="center"
					itemTextPosition="left"
				></Legend>
				<LoadingIndicator enabled={true} />
				<Tooltip
					enabled={true}
					location="edge"
					customizeTooltip={customizeTooltip}
				/>
				<ArgumentAxis type="discrete">
					{/* or ValueAxis, or CommonAxisSettings */}
					<Tick visible={true} />
					<MinorTick visible={false} />
				</ArgumentAxis>
			</Chart>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default BarDifferentColor;
