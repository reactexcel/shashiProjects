import React from 'react';

import {
	Chart,
	Series,
	CommonSeriesSettings,
	Legend,
	ValueAxis,
	Title,
	Tooltip,
	ArgumentAxis
} from 'devextreme-react/chart';
import { IconButton } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import service from '../Data/data.js';

const StackedBar = ({ classes }) => {
	const BarRef = React.createRef();

	const exportChart = () => {
		BarRef.current.instance.exportTo('Example', 'png');
	};

	//   const onPointClick = ({ target: point }) => {
	//     point.select();
	//   };

	const onLegendClick = ({ target: series }) => {
		if (series.isVisible()) {
			series.hide();
		} else {
			series.show();
		}
	};

	const customizeTooltip = (arg) => {
		return {
			text: `${arg.seriesName} : ${arg.valueText}%`
		};
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>
				Loans Status % By Loan Issue Date
			</div>
			<Chart
				id="chart"
				dataSource={service.getData()}
				ref={BarRef}
				onLegendClick={onLegendClick}
			>
				<ArgumentAxis type="discrete" />
				<CommonSeriesSettings
					argumentField="year"
					valueField="Fully Paid1"
					type="stackedBar"
				/>
				<Series valueField="Charged Off1" name="Charged Off" color="#2CC9B7" />
				<Series valueField="Current1" name="Current" color="#2888D1" />
				<Series valueField="Fully Paid1" name="Fully Paid" color="#26649e" />
				<ValueAxis position="left">{/* <Title text="millions" /> */}</ValueAxis>
				<Legend
					verticalAlignment="bottom"
					horizontalAlignment="center"
					itemTextPosition="left"
				/>
				<Tooltip
					enabled={true}
					location="edge"
					customizeTooltip={customizeTooltip}
				/>
			</Chart>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default StackedBar;
