import React from 'react';
import TreeMap, {
	Tooltip,
	Size,
	Title,
	Colorizer
} from 'devextreme-react/tree-map';
import { IconButton } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import service from '../Data/data.js';

const DeveTree = ({ classes }) => {
	const DeveTreeRef = React.createRef();

	const exportChart = () => {
		DeveTreeRef.current.instance.exportTo('Example', 'png');
	};

	function customizeTooltip(arg) {
		const data = arg.node.data;

		return {
			text: arg.node.isLeaf()
				? `<span class="city">${data.name} </span> : ${arg.valueText}%`
				: null
		};
	}
	return (
		<div style={{ position: 'relative', width: '90%', height: '85%' }}>
			<div className={classes.values_title}>Top 10 States By Origination</div>
			<TreeMap
				id="treemap"
				dataSource={service.getDataTree()}
				ref={DeveTreeRef}
				colorizer={{
					palette: service.colorArray
				}}
			>
				<Size height={350} />
				<Tooltip enabled={true} customizeTooltip={customizeTooltip}></Tooltip>
			</TreeMap>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default DeveTree;
