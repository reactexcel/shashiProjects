// Credit Risk 1.2.8
import Prepayment from './Prepayment';

export default Prepayment;
