import { makeStyles } from '@material-ui/core';
import {
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
} from '../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	datechat__charts: {
		width: '100%',
		margin: '20px 0px auto'
	},
	container__chart: {
		// maxWidth: 500,
		height: 500
	},
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
}));
