import React, { useEffect, useState } from 'react';
import { Route, Switch, withRouter, Redirect } from 'react-router-dom';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { store } from './store';
import { retrieveUserInfo } from './store/actions/auth.action';
import PrivateRoute from 'routes-middleware/Private.route';

import Dashboard from './DashBoard/Dashboard';
import Header from './components/header/Header';
import Fpna from './Fpna/Fpna';
import FpnaV2 from './Fpna/FpnaV2';
import FpnaV3 from './Fpna/FpnaV3';
import FpnaV4 from './Fpna/FpnaV4';
import FpnaV5_3_1 from './Fpna/FpnaV5_3_1';
import FpnaV5_3_1_0 from './Fpna/FpnaV5_3_1_0';
import FpnaV5_1_1_new from './Fpna/FpnaV5_1_1_new';
import FpnaV5_1_1_0 from './Fpna/FpnaV5_1_1_0';
// import FpnaV5_1_1 from './Fpna/FpnaV5_1_1';
import FpnaV5_2_1 from './Fpna/FpnaV5_2_1';
import FpnaV5_2_1_0 from './Fpna/FpnaV5_2_1_0';
import FpnaV6_3_1 from './Fpna/FpnaV6_3_1';
import FpnaV6_1_1 from './Fpna/FpnaV6_1_1';
import FpnaV6_2_1 from './Fpna/FpnaV6_2_1';
import FpnaV6_4_1 from './Fpna/FpnaV6_4_1';
import FpnaV9_1_1 from './Fpna/FpnaV9_1_1';
import FpnaV9_2_1 from './Fpna/FpnaV9_2_1';
import FpnaV9_3_1 from './Fpna/FpnaV9_3_1';
import FpnaV9_4_1 from './Fpna/FpnaV9_4_1';
import FpnaV0 from './Fpna/FpnaV0';

import Prepayment from './Prepayment';
import CreditSpec from './CreditSpec';
import CreditRiskV2 from './CreditSpec/CreditRiskV2';
import CreditRiskV3 from './CreditSpec/CreditRiskV3';
import CashFlow from './CashFlow';
import Securitization from './Securitization';
import CashFlowV3 from './CashFlow/CashFlowV3';
import Default from './Default';
import HomePage from './HomePage';
import Academy from './Academy';
import CompanySetting from './CompanySetting';
import AccountSetting from './AccountSetting';
import Login from './Login/Login';
import OTP from './Login/OTP';

const App = () => {
	const [collapsed, setCollapsed] = useState(0);
	const dispatch = useDispatch();
	const session = localStorage.getItem('user');
	const { loading, user } = useSelector((state) => state.auth);

	useEffect(() => {
		session && dispatch(retrieveUserInfo());
		//eslint-disable-next-line
	}, []);

	if (loading && !user?.username) return <></>;

	return (
		<Provider store={store}>
			<Switch>
				<PrivateRoute path="/login" authPage={false} component={Login} />
				<PrivateRoute path="/OTP" authPage={false} component={OTP} />
				<>
					<Header collapsed={collapsed} setCollapsed={setCollapsed} />
					<div style={{ height: 60, fontFamily: 'Avenir !important' }} />
					{[
						// { path: '/app/cashflow', Component: CashFlow },
						{ path: '/app/fpna-1-3-2', Component: CashFlow },
						// { path: '/app/cashflow4', Component: CashFlowV3 },
						{ path: '/app/fpna-3-3-2', Component: CashFlowV3 },
						{ path: '/app/homepage', Component: HomePage },
						// { path: '/app/prepayment', Component: Prepayment },
						{ path: '/app/1-1-8', Component: Prepayment },
						{ path: '/app/crm', Component: CreditSpec },
						{ path: '/app/crm2', Component: CreditRiskV2 },
						{ path: '/app/securitization', Component: Securitization },
						{ path: '/app/fpna', Component: Fpna },
						{ path: '/app/fpna-0', Component: FpnaV0 },
						{ path: '/app/fpna-2', Component: FpnaV2 },
						{ path: '/app/fpna-4', Component: FpnaV4 },
						{ path: '/app/fpna-5', Component: FpnaV5_3_1 },
						{ path: '/app/fpna-5-3-1-0', Component: FpnaV5_3_1_0 },
						{ path: '/app/5-1-1', Component: FpnaV5_1_1_new },
						{ path: '/app/5-1-1-0', Component: FpnaV5_1_1_0 },
						{ path: '/app/5-2-1', Component: FpnaV5_2_1 },
						{ path: '/app/5-2-1-0', Component: FpnaV5_2_1_0 },
						// { path: '/app/5-4-1', Component: FpnaV5_4_1 },
						// { path: '/app/fpna-5-2', Component: FpnaV5_2 },
						{ path: '/app/fpna-3', Component: FpnaV3 },
						// { path: '/app/fpna-3-2', Component: CreditRiskV3 },
						{ path: '/app/3-2-1', Component: CreditRiskV3 },
						{ path: '/app/6-1-1', Component: FpnaV6_1_1 },
						{ path: '/app/6-2-1', Component: FpnaV6_2_1 },
						{ path: '/app/fpna-6-3-1', Component: FpnaV6_3_1 },
						// { path: '/app/fpna-9-2', Component: FpnaV9_3_2 },
						{ path: '/app/9-1-1', Component: FpnaV9_1_1 },
						{ path: '/app/9-2-1', Component: FpnaV9_2_1 },
						{ path: '/app/fpna-9-3-1', Component: FpnaV9_3_1 },
						// { path: '/app/fpna-6-2', Component: FpnaV6_2 },
						{ path: '/app/6-4-1', Component: FpnaV6_4_1 },
						{ path: '/app/9-4-1', Component: FpnaV9_4_1 },
						// { path: '/app/default', Component: Default },
						{ path: '/app/1-2-3', Component: Default },
						{ path: '/app/academy', Component: Academy },
						{ path: '/app/dashboard', Component: Dashboard },
						{ path: '/app/setting', Component: CompanySetting },
						{ path: '/app/account', Component: AccountSetting }
						// { path: '/app/adminpanel/home', Component: AdminHome }
					].map(({ path, Component }) => (
						<PrivateRoute
							key={path}
							collapsed={collapsed}
							path={path}
							component={Component}
							authPage={true}
						/>
					))}
				</>
				<Route path="*" render={() => <Redirect to="/" />} />
			</Switch>
		</Provider>
	);
};
export default withRouter(App);
