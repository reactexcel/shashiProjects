const requiredTables_FpnaV0 = ['ol_accrued_interest'];

const tableData_FpnaV0 = [
	{
		id: '35002',
		name: 'ol_accrued_interest',
		title: 'Other Liability - Accrued Interest'
	}
];

export { requiredTables_FpnaV0, tableData_FpnaV0 };
