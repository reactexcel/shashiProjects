import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import MainTable from '../components/Table/MainTable';
import { useStyles } from './fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import Portfolio from '../components/portfolio/Portfolio';
import {
	getPortfolios,
	createPortfolio,
	deletePortfolio,
	updatePortfolio,
	getPortfolioDetails,
	getPortfolioScenarios,
	downloadDataFile,
	downloadCustomReports,
	downloadFPNATemplate
} from '../store/actions/fpna.action';
import headers from './tableHeader';
import DoubleTable from '../components/Table/DoubleTable';
import { startTimer } from '../store/actions/timer.action';
import { GET_FPNA_TABLES_CLEAN } from '../store/types/fpna.type';

const Fpna = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { portfolios, scenarios, tables, seconds, minutes, status1 } =
		useSelector((state) => state.fpna);

	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();

	const [selectedPortfolio, setSelectedPortolio] = useState(null);
	const [selectedScenario, setSelectedScenario] = useState(null);

	const [dataType, setDataType] = useState('consolidated');

	const fetchPortfolio = () => {
		dispatch(
			getPortfolios('3', (res) => {
				setSelectedPortolio(res[0]);
				res[0] && fetchScenarios(res[0].id);
			})
		);
	};

	const fetchScenarios = (scenarioGroupId, tableUpdate = true) => {
		dispatch(
			getPortfolioScenarios('3', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario(portflioScenrios[0]);
				if (tableUpdate) {
					updateTables(portflioScenrios[0].id);
					if (!tables?.cashflowstatement)
						fetchPortfolioDetails(portflioScenrios[0].id, undefined, true);
					if (!tables?.tier4_term)
						fetchPortfolioDetails(
							portflioScenrios[0].id,
							'tier-balance-term',
							true
						);
					if (!tables?.pipelinevector)
						fetchPortfolioDetails(
							portflioScenrios[0].id,
							'pipelinevectors',
							true
						);
				}
			})
		);
	};
	const updateTables = (id) => {
		if (!tables) return;

		if (tables.pipelinevector) fetchPortfolioDetails(id, 'pipelinevectors');
		if (tables.cashflowstatement && dataType)
			fetchPortfolioDetails(id, dataType);
		if (tables.tier4_term) fetchPortfolioDetails(id, 'tier-balance-term');

		if (selectedScenario?.scenario === 0) return;

		if (tables.el) fetchPortfolioDetails(id, 'el');
		if (tables.el_value) fetchPortfolioDetails(id, 'el-value');
		if (tables.ead_value) fetchPortfolioDetails(id, 'ead-value');
		if (tables.ead_prcnt) fetchPortfolioDetails(id, 'ead-prcnt');
		if (tables.lgd) fetchPortfolioDetails(id, 'lgd');

		if (tables.migration) fetchPortfolioDetails(id, 'migration-matrix');
		if (tables.utilization) fetchPortfolioDetails(id, 'utilization-matrix');

		if (tables.exposure) fetchPortfolioDetails(id, 'exposure-matrix');
		if (tables.amort) fetchPortfolioDetails(id, 'amortization-matrix');
		if (tables.credit) fetchPortfolioDetails(id, 'credit-matrix');
		if (tables.pd) fetchPortfolioDetails(id, 'pd-matrix');
		if (tables.pd_value) fetchPortfolioDetails(id, 'pd-matrix-value');

		if (tables.ccf_matrix_factor)
			fetchPortfolioDetails(id, 'ccf-matrix-factor');
	};

	useEffect(() => {
		if (!portfolios && user?.allowed_pages?.includes(3)) fetchPortfolio();
		if (portfolios && !selectedPortfolio) setSelectedPortolio(portfolios[0]);
		if (scenarios && !selectedScenario) setSelectedScenario(scenarios[0]);
	}, [portfolios, user]);

	useEffect(() => {
		if (selectedScenario && status1 === 'SUCCESS')
			updateTables(selectedScenario.id);
	}, [status1]);

	useEffect(() => {
		return () => {
			dispatch({ type: GET_FPNA_TABLES_CLEAN });
		};
	}, []);

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(301)
	)
		return <div></div>;

	const fetchPortfolioDetails = (
		model,
		type = 'consolidated',
		portfolioExist = false
	) => {
		if (!model || (portfolios?.length === 0 && !portfolioExist)) return;
		dispatch(getPortfolioDetails('3', model, type));
	};
	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							port={selectedPortfolio?.id}
							id={selectedScenario?.id}
							model={'fpna1'}
							version={'03/08/2022'}
							loading={status1 === 'pending'}
							key={1001}
							portfolioList={portfolios || []}
							setPortfolio={(val) => {
								setSelectedPortolio(
									portfolios.filter((item) => item.id == val)[0]
								);
								fetchScenarios(val);
							}}
							senarioData={
								scenarios
									? scenarios?.map((item) => {
											if (item.scenario === 0)
												item.displayName = 'Consolidated 1-5';
											return item;
									  })
									: []
							}
							scenarioField={'scenario'}
							scenarioName={'Class'}
							scenario={selectedScenario?.scenario || {}}
							setScenario={(item) => {
								setSelectedScenario(item);
								if (portfolios.length === 0) return;
								if (!tables) {
									fetchPortfolioDetails(item.id);
									fetchPortfolioDetails(item.id, 'tier-balance-term');
								} else {
									updateTables(item.id);
								}
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio('3', name, user?.company_id, file, (res) => {
										dispatch(startTimer('cfm3', res.data.id));
										fetchPortfolio();
									})
								);
							}}
							update={(name, callback) => {
								dispatch(
									updatePortfolio('3', selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										callback();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio('3', selectedPortfolio?.id, () => {
										fetchPortfolio();
										dispatch({ type: GET_FPNA_TABLES_CLEAN });
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('cfm3', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(
										'3',
										selectedPortfolio?.id,
										formData,
										(res) => {
											fetchScenarios(selectedPortfolio?.id, false);
										}
									)
								);
							}}
							data={[
								{ key: 'consolidated', value: 'Pipeline/Future Portfolio' },
								{ key: 'loanmodel', value: 'Origination/Current Portfolio' }
							]}
							setData={(val) => {
								setDataType(val);
								if (portfolios.length === 0) return;
								fetchPortfolioDetails(selectedScenario?.id, val);
							}}
							downloadFile={() => {
								dispatch(downloadDataFile('3', selectedPortfolio?.id));
							}}
							downloadCustomReports={() => {
								dispatch(downloadCustomReports('3', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('3'));
							}}
							selectedData={dataType}
							collapsed={collapsed}
							seconds={seconds}
							status={status1}
							minutes={minutes}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						<MainTable
							header={headers.pipelineVecHeader}
							data={tables?.pipelinevector}
							attributes={headers.pipelineVecAttributes}
							tableId={1}
							tableName="Pipeline Vectors"
							fetchData={() => {
								if (!tables?.pipelinevector)
									fetchPortfolioDetails(
										selectedScenario?.id,
										'pipelinevectors'
									);
							}}
							collapsed={collapsed}
							download
						/>
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.migrationHeader}
								data={tables?.migration}
								attributes={headers.migrationAttributes}
								tableId={2}
								tableName="Migration Matrix"
								fetchData={() => {
									if (!tables?.migration)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'migration-matrix'
										);
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.utilizationHeader}
								data={tables?.utilization}
								attributes={headers.utilizationAttributes}
								tableId={3}
								tableName="Utilization Matrix"
								fetchData={() => {
									if (!tables?.utilization)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'utilization-matrix'
										);
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<DoubleTable
								header="Exposure Matrix with Tier Balances"
								content={[
									'tier1_balance',
									'tier2_balance',
									'tier3_balance',
									'tier4_balance',
									'tier5_balance',
									'tier6_balance'
								].map((key, i) => ({
									header: `Tier ${i + 1} Balance`,
									details: {
										header: tables &&
											tables['header_value'] && [
												'Period',
												...Object.values(tables['header_value']).slice(
													i * 9,
													i * 9 + 5
												),
												'WAV Commitment',
												'WAV Utilization',
												'WAV Balance'
											],
										data: tables && tables[key],
										attributes: [
											'period',
											`t${1 + i}a_1`,
											`t${1 + i}a_2`,
											`t${1 + i}a_3`,
											`t${1 + i}a_4`,
											`t${1 + i}a_5`,
											'wav_commitment',
											'wav_utilization',
											'wav_balance'
										],
										tableId: key + 100,
										key: `sec-2-${i}`
									}
								}))}
								collapsed={collapsed}
								key={1002}
								mainheader={headers.exposureHeader}
								maindata={tables?.exposure}
								mainattributes={headers.exposureAttributes}
								maintableId={13}
								mainfetchData={() => {
									if (!tables?.exposure)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'exposure-matrix'
										);
								}}
								maindownload
							/>
						)}

						{selectedScenario?.scenario !== 0 && (
							<DoubleTable
								header="Amortization Matrix with Tier Terms"
								content={[
									'tier1_term',
									'tier2_term',
									'tier3_term',
									'tier4_term',
									'tier5_term',
									'tier6_term'
								].map((key, i) => ({
									header: `Tier ${i + 1} Term`,
									details: {
										header: tables &&
											tables['header_value'] && [
												'Period',
												...Object.values(tables['header_value']).slice(
													i * 9 + 5,
													i * 9 + 9
												),
												'WAV Amort'
											],
										data: tables && tables[key],
										attributes: [
											'period',
											`t${1 + i}b_1`,
											`t${1 + i}b_2`,
											`t${1 + i}b_3`,
											`t${1 + i}b_4`,
											'wav_amort'
										],
										tableId: key + 200,
										key: `sec-${i}`
									}
								}))}
								key={1001}
								collapsed={collapsed}
								mainheader={headers.amortMatrixHeader}
								maindata={tables?.amort}
								mainattributes={headers.amortMatrixAttributes}
								maintableId={12}
								mainfetchData={() => {
									if (!tables?.amort)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'amortization-matrix'
										);
								}}
								maindownload
							/>
						)}

						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.creditHeader}
								data={tables?.credit}
								attributes={headers.creditAttributes}
								tableId={4}
								tableName="Annualized PD by Tier"
								fetchData={() => {
									if (!tables?.credit)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'credit-matrix'
										);
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.pdHeader}
								data={tables?.pd}
								attributes={headers.pdAttributes}
								tableId={5}
								tableName="Portfolio PD by Tier"
								fetchData={() => {
									if (!tables?.pd)
										fetchPortfolioDetails(selectedScenario?.id, 'pd-matrix');
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.pdHeader}
								data={tables?.pd_value}
								attributes={headers.pdAttributes}
								tableId={6}
								tableName="Portfolio PD by Tier $"
								fetchData={() => {
									if (!tables?.pd)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'pd-matrix-value'
										);
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.lgdHeader}
								data={tables?.lgd}
								attributes={headers.lgdAttributes}
								tableId={7}
								tableName="LGD"
								fetchData={() => {
									if (!tables?.lgd)
										fetchPortfolioDetails(selectedScenario?.id, 'lgd');
								}}
								collapsed={collapsed}
								download
							/>
						)}

						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.ccfInputHeader}
								data={tables?.ccf_matrix_factor}
								attributes={headers.ccfInputAttributes}
								tableId={8}
								tableName="Credit Conversion Factor (CCF) Input  - Utilization Ratio of the Unwithdrawn Amount %"
								fetchData={() => {
									if (!tables?.ccf_matrix_factor)
										fetchPortfolioDetails(
											selectedScenario?.id,
											'ccf-matrix-factor'
										);
								}}
								collapsed={collapsed}
								download
							/>
						)}

						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.eadValueHeader}
								data={tables?.ead_value}
								attributes={headers.eadValueAttributes}
								tableId={9}
								tableName="EAD $"
								fetchData={() => {
									if (!tables?.ead_value)
										fetchPortfolioDetails(selectedScenario?.id, 'ead-value');
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.eadPercentHeader}
								data={tables?.ead_prcnt}
								attributes={headers.eadPercentAttributes}
								tableId={10}
								tableName="EAD % of Commitment"
								fetchData={() => {
									if (!tables?.ead_prcnt)
										fetchPortfolioDetails(selectedScenario?.id, 'ead-prcnt');
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.elValueHeader}
								data={tables?.el_value}
								attributes={headers.elValueAttributes}
								tableId={11}
								tableName="EL $"
								fetchData={() => {
									if (!tables?.el_value)
										fetchPortfolioDetails(selectedScenario?.id, 'el-value');
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.lgdHeader}
								data={tables?.el}
								attributes={headers.lgdAttributes}
								tableId={12}
								tableName="EL % of Commitment"
								fetchData={() => {
									if (!tables?.el)
										fetchPortfolioDetails(selectedScenario?.id, 'el');
								}}
								collapsed={collapsed}
								download
							/>
						)}
						{selectedScenario?.scenario !== 0 && (
							<MainTable
								header={headers.loanModelHeader}
								data={tables?.pipeline_output}
								attributes={headers.loanModelAttributes}
								tableId={13}
								tableName="Loan Pricing Assumption"
								collapsed={collapsed}
								download
							/>
						)}
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort}
							attributes={headers.amortAttributes}
							tableId={14}
							tableName="Asset Amortization Table"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier1}
							attributes={headers.amortAttributes}
							tableId={15}
							tableName="Asset Amortization Table Tier 1"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier2}
							attributes={headers.amortAttributes}
							tableId={16}
							tableName="Asset Amortization Table Tier 2"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier3}
							attributes={headers.amortAttributes}
							tableId={17}
							tableName="Asset Amortization Table Tier 3"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier4}
							attributes={headers.amortAttributes}
							tableId={18}
							tableName="Asset Amortization Table Tier 4"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier5}
							attributes={headers.amortAttributes}
							tableId={19}
							tableName="Asset Amortization Table Tier 5"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables?.assetamort_tier6}
							attributes={headers.amortAttributes}
							tableId={20}
							tableName="Asset Amortization Table Tier 6"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.cfReportHeader}
							data={tables?.cfreport}
							attributes={headers.cfReportAttributes}
							tableId={21}
							tableName="CF Report - Output"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.structureHeader}
							data={tables?.structure}
							attributes={headers.structureAttributes}
							tableId={22}
							tableName="Expected Funding Structure"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.structureHeader}
							data={tables?.structure_unexpected}
							attributes={headers.structureAttributes}
							tableId={23}
							tableName="Unexpected Funding Structure"
							collapsed={collapsed}
							download
						/>

						<MainTable
							header={headers.incomeHeader}
							data={tables?.incomestatement}
							attributes={headers.incomeAttributes}
							tableId={24}
							tableName="Income Statement"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.balanceHeader}
							data={tables?.balancesheet}
							attributes={headers.balanceAttributes}
							tableId={25}
							tableName="Balance Sheet"
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.cashflowHeader}
							data={tables?.cashflowstatement}
							attributes={headers.cashflowAttributes}
							tableId={26}
							tableName="Cash Flow Statement"
							collapsed={collapsed}
							download
						/>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default Fpna;
