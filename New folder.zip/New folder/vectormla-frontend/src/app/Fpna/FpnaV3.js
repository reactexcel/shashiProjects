// THIS IS FPNA 3 fpna-3 FPNA6 FP&A 3.1.3
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider } from '@material-ui/core';
import Checkboxes from '../CashFlow/SelectScenarioChart/SelectScenarioChart';
import SelectChart from '../CashFlow/SelectCharts/SelectCharts';
import { useStyles } from './fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolio,
	downloadFPNA3Template,
	deletePortfolio,
	// getCharts3,
	updatePortfolio,
	downloadDataFile,
	getScenarioDetails,
	getPortfolioScenarios,
	getCalcStatus,
	getSegment,
	runCalculate,
	// downloadCustomReports,
	downloadFpna3CustomReports,
	updateSegmentReq,
	getSubPortofolios,
	getScenarioDetailsOutputBreakdown,
	getCashFlow2Charts
} from '../store/actions/fpna.action';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import Portfolio from '../components/portfolio/Portfolio';
import {
	loanHeaders2,
	loanPipelineHeaders2,
	dynamicHeaders
} from './liabilityTableFileds';
import {
	GET_FPNA3_TABLES_CLEAN,
	GET_CHARTS3_CLEAN,
	TASK_PROGRESS_FPNA3,
	STOP_FPNA3_TIMER
} from '../store/types/fpna.type';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import Chart from 'app/components/Chart/Chart';
// const Chart = lazy(() => import('../components/Chart/Chart')); // causes a problem in the header letter (A,B,C...) => FIXED
// const MainTable = lazy(() => import('../components/Table/MainTable')); // causes a problem in the header letter (A,B,C...) => FIXED

const CashFlowV2 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios3,
		// charts3,
		chashflow2charts,
		tables3,
		status3,
		seconds,
		minutes,
		scenarios3
		// subPortofolio3,
		// segment3,
		// taskProgress3
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [vintageKeys, setVintageKeys] = useState({});
	// const DataSelection = [
	// 	{
	// 		key: 'output/?incomestatement_orient=split',
	// 		value: 'Consolidated'
	// 	},
	// 	{
	// 		key: 'output/pipeline/?incomestatement_orient=split',
	// 		value: 'Forecast'
	// 	},
	// 	{
	// 		key: 'output/loandata/?incomestatement_orient=split',
	// 		value: 'Origination'
	// 	}
	// ];
	const [doubleDash, setDoubleDash] = useState({});
	const [doubleDashPortfolioSummary, setDoubleDashPortfolioSummary] = useState(
		{}
	);
	const [chartVisible, setChartVisible] = useState({
		chart1: false,
		chart2: false,
		chart3: false
	});
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [state, setState] = useState({
		openChart1: false,
		openChart2: false,
		openChart3: false,
		portfolio: false
	});
	const [chartsData, setChartsData] = useState([]);
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);

	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA3_TIMER,
			payload: { status3: 'stopped' }
		});
	};

	const dispatchClean = (unmount) => {
		dispatch({
			type: GET_FPNA3_TABLES_CLEAN,
			payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS3_CLEAN });
	};

	const killTaskFunction = (closeKillTaskDialog) => {
		let modelName = 'cfm2';
		dispatch(
			killTaskFunc(modelName, runningTaskId, () => {
				deleteFunction();
				closeKillTaskDialog();
				setRunningTaskId();
				stopTimerFunction();
				dispatch(stopTimer(modelName, 'STOPPED'));
			})
		);
	};
	const deleteFunction = () => {
		dispatch(
			deletePortfolio('2', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};

	useEffect(() => {
		if (!portfolios3 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		// if (portfolios3 && !selectedPortfolio) setSelectedPortfolio(portfolios3[0]);
		// if (scenarios3 && !selectedScenario[0])
		// 	setSelectedScenario([scenarios3[0]]);
	}, [user, portfolios3]);

	useEffect(() => {
		if (tables3?.vintage_df) {
			setDoubleDash(tables3.vintage_df['columns']);
		}
		if (tables3?.vintage_portfolio) {
			setDoubleDashPortfolioSummary(tables3?.vintage_portfolio['columns']);
		}
	}, [tables3]);

	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);

	useEffect(() => {
		if (selectedScenario[0] && status3 === 'SUCCESS') {
			updateTables(selectedScenario[0]?.id);
			fetchSubPorofolios(selectedScenario[0]);
		}
	}, [status3]);

	const calculateStatus = (supPorofolioId) => {
		supPorofolioId && dispatch(startTimer('cfm2', supPorofolioId, ''));
		getCalcStatus('cfm2/portfolio', selectedSubPorofolio[0]?.id, (res) => {
			if (res.task_state === 'SUCCESS') {
				updateTables(selectedSubPorofolio[0]?.id);
			}
			if (res.task_state !== 'SUCCESS')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: res.task_progress
				});
			else if (res.task_state === 'FAILURE')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: 'Failed'
				});
		});
	};

	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('2', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};

	useEffect(() => {
		if (selectedSubPorofolio && selectedSubPorofolio[0]?.id) {
			calculateStatus();
		}
	}, [selectedSubPorofolio]);

	useEffect(() => {
		return () => {
			dispatchClean('unmount');
			stopTimerFunction();
		};
	}, []);

	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('2', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, dataType, create);
			})
		);
	};

	const fetchScenarios = (scenarioGroupId, dataTypeVal, create) => {
		dispatch(
			getPortfolioScenarios('2', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm2', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const fetchSubPorofolios = (scenarioId) => {
		dispatch(
			getSubPortofolios('2', scenarioId?.id, (scenriosSubPortofolios) => {
				setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
				scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
			})
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('2', supPorofolioId));
	};

	// const updateSegment = (segmentID, data) => {
	// 	dispatch(updateSegmentReq('2', segmentID, data));
	// 	fetchSegments(selectedSubPorofolio[0]);
	// };
	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id, dataType);
	}, [selectedPortfolio]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [selectedScenario]);

	// useEffect(() => {
	// 	subPortofolio3?.results &&
	// 		subPortofolio3?.results.map((item) => fetchSegments(item));
	// }, [subPortofolio3]);

	const fetchScenarioDetails = (model, type, query = '') => {
		if (!model) return;
		dispatch(
			getScenarioDetails('2', model, type ? type : dataType, query, (data) => {
				if (type === 'default-vintage') {
					let finalObject = {};
					Object.keys(data?.vintage_df?.category).map(
						(item) =>
							(finalObject[`${item}`] = data?.vintage_df?.category[item])
					);
					setVintageKeys(finalObject);
				}
			})
		);
	};
	// const fetchAssetamortBreakdownDetails = (model, type, query = '') => {
	// 	if (!model) return;
	// 	dispatch(
	// 		getScenarioDetailsOutputBreakdown(model, type ? type : dataType, query)
	// 	);
	// };
	// const fetchAssetamortNoextraBreakdownDetails = (model, type, query = '') => {
	// 	if (!model) return;
	// 	dispatch(
	// 		getScenarioDetailsOutputBreakdown(model, type ? type : dataType, query)
	// 	);
	// };
	const fetchScenarioVintageSummary = (model, type, query = '', name) => {
		if (!model) return;
		dispatch(getScenarioDetails('2', model, type ? type : dataType, query));
	};

	const fetchScenarioDetailsPortfolioVintage = (
		model,
		type,
		query = '',
		name
	) => {
		if (!model) return;
		dispatch(getScenarioDetails('2', model, type ? type : dataType, query));
	};
	const updateTables = (id) => {
		if (!tables3 && !id) return;
		if (tables3?.loanmodel || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split');
		if (tables3?.loanmodel_g1 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=1');
		if (tables3?.loanmodel_g2 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=2');
		if (tables3?.loanmodel_g3 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=3');
		if (tables3?.loanmodel_g4 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=4');
		if (tables3?.loanmodel_g5 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=5');
		if (tables3?.loanmodel_g6 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=6');
		if (tables3?.loanmodel_g7 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=7');
		if (tables3?.fixedintrate || id) fetchScenarioDetails(id, 'fixedintrate');
		if (tables3?.pipeline || id) fetchScenarioDetails(id, 'pipeline');
		if (tables3?.pipelinevectors || id)
			fetchScenarioDetails(id, 'pipelinevectors', '?orient=split');
		if (tables3?.vintage_df || id) fetchScenarioDetails(id, 'default-vintage');
		if (tables3?.assetamort_breakdown1 || id)
			fetchScenarioDetailsPortfolioVintage(
				id,
				'output-breakdown',
				'loandata/',
				'Asset Amortization - Current'
			);
		if (tables3?.assetamort_breakdown2 || id)
			fetchScenarioDetailsPortfolioVintage(
				id,
				'output-breakdown',
				'',
				'Asset Amortization - Consolidated'
			);
		if (tables3?.assetamort_breakdown3 || id)
			fetchScenarioDetailsPortfolioVintage(
				id,
				'output-breakdown',
				'delinquent/',
				'Asset Amortization - Delinquent'
			);
		if (tables3?.vintage_portfolio || id)
			fetchScenarioDetailsPortfolioVintage(id, 'portfolio-vintage');
		// if (tables3?.assetamort_breakdown || id)
		// 	fetchAssetamortBreakdownDetails(id, 'output-breakdown', 'pipeline/');
		// if (tables3?.assetamort_noextra_breakdown || id)
		// 	fetchAssetamortNoextraBreakdownDetails(
		// 		id,
		// 		'output-breakdown',
		// 		'pipeline/'
		// 	);

		if (tables3?.outstanding_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'Outstanding Portfolio as % of Origination'
			);
		if (tables3?.cumulative_chargeoff_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'Charge Off Summary'
			);
		// if (tables3?.incomestatement || id)
		// 	fetchScenarioVintageSummary(
		// 		id,
		// 		'output-breakdown',
		// 		'pipeline/',
		// 		'Forecast Portfolio - Income Statement'
		// 	);
		if (tables3?.incomestatement1 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'loandata/',
				'Income Statement - Current'
			);
		if (tables3?.incomestatement2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Income Statement - Consolidated'
			);
		// if (tables3?.issuportschedule || id)
		// 	fetchScenarioVintageSummary(
		// 		id,
		// 		'output-breakdown',
		// 		'pipeline/',
		// 		'Forecast Portfolio - Income Statement Support Schedule'
		// 	);
		if (tables3?.issuportschedule1 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'loandata/',
				'Current Portfolio - Income Statement Support Schedule'
			);
		if (tables3?.issuportschedule2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Consolidated Portfolio - Income Statement Support Schedule'
			);
		if (tables3?.bucket_analysis || id)
			fetchScenarioVintageSummary(id, 'bucket-analysis', '', 'Roll Rates');
		if (tables3?.equity_requirement0 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'pipeline/',
				'Equity Requirement - Forecast'
			);
		if (tables3?.equity_requirement1 || id)
			fetchScenarioVintageSummary(
				id,
				'output',
				'loandata/',
				'Equity Requirement - Current'
			);
		if (tables3?.equity_requirement2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Equity Requirement - Consolidated'
			);
		if (tables3?.cumulative_chargeoff_netrecovery_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'EL - Charge Off Summary - Net of Recovery $'
			);
		if (
			tables3?.assetamort ||
			tables3?.balancesheet ||
			tables3?.cashflowstatement ||
			tables3?.liability ||
			tables3?.loanmodel ||
			tables3?.structure ||
			tables3?.assetamort_noextra ||
			tables3?.equity_requirement ||
			id
		)
			fetchScenarioDetails(id);
	};

	useEffect(() => {
		if (chashflow2charts) {
			let chart1 = [];
			let chart2 = [];
			let chart3 = [];
			let chart4 = [];
			let chart5 = [];
			let chart6 = [];
			let chart7 = [];
			let chart8 = [];
			let chart9 = [];
			let tempChart1 = [];
			let tempChart2 = [];
			let tempChart3 = [];
			let tempChart4 = [];
			let tempChart5 = [];
			let tempChart6 = [];
			let tempChart7 = [];
			let tempChart8 = [];
			let tempChart9 = [];

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart1.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_consolidated?.['closing_balance'][i]
				});
				chart1.push(tempChart1);
			});

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart2.push({
					date: val1,
					interest: chashflow2charts?.chart_consolidated?.['interest'][i]
				});
				chart2.push(tempChart2);
			});

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart3.push({
					date: val1,
					principal: chashflow2charts?.chart_consolidated?.['principal'][i]
				});
				chart3.push(tempChart3);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart4.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_current_portfolio?.['closing_balance'][i]
				});
				chart4.push(tempChart4);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart5.push({
					date: val1,
					interest: chashflow2charts?.chart_current_portfolio?.['interest'][i]
				});
				chart5.push(tempChart5);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart6.push({
					date: val1,
					principal: chashflow2charts?.chart_current_portfolio?.['principal'][i]
				});
				chart6.push(tempChart6);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart7.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_forecast?.['closing_balance'][i]
				});
				chart7.push(tempChart7);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart8.push({
					date: val1,
					interest: chashflow2charts?.chart_forecast?.['interest'][i]
				});
				chart8.push(tempChart8);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart9.push({
					date: val1,
					principal: chashflow2charts?.chart_forecast?.['principal'][i]
				});
				chart9.push(tempChart9);
			});

			let updatedCharts = [
				{
					ch: chart1,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart2,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart3,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				},
				{
					ch: chart4,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart5,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart6,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				},
				{
					ch: chart7,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart8,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart9,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				}
			];
			setChartsData(updatedCharts);
		}
	}, [chashflow2charts]);

	useEffect(() => {
		if (selectedSubPorofolio?.[0]?.id) {
			dispatch(getCashFlow2Charts(selectedSubPorofolio?.[0]?.id));
		}
	}, [selectedSubPorofolio]);

	const renderChart = (openType, startIndex, endIndex, chart_name) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() =>
						setChartVisible({
							...chartVisible,
							[openType]: !chartVisible?.[openType]
						})
					}
				>
					<p className={classes.contentHeader}>{`${chart_name} Charts`}</p>
				</div>
				{chartVisible?.[openType] && (
					<div className={classes.datechat__charts}>
						{chartsData?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								{chartsData.slice(startIndex, endIndex).map((itemChart) => {
									return (
										<Grid
											key={itemChart?.nameLegend}
											item
											xs={12}
											sm={12}
											md={4}
											className={classes.container__chart}
										>
											<Chart
												dataT={itemChart.ch}
												nameLegend={itemChart?.nameLegend}
												sizeLegend="14px"
												dataX={itemChart?.xIndex}
												xDistance={400}
												format={itemChart?.format}
												noCharts={itemChart?.noCharts}
												// customTooltip
											/>
										</Grid>
									);
								})}
							</Grid>
						)}
					</div>
				)}
			</div>
		);
	};

	const typeHeaders = (tableName, category) => {
		if (tableName === 'loanmodel') return loanHeaders2;
		else if (tableName === 'pipelinevectors') return dynamicHeaders(category);
		else if (tableName.includes('loanmodel_g')) return loanPipelineHeaders2;
		else if (tableName.includes('vintage_df')) return vintageKeys;
		else if (tableName === 'assetamort_breakdown')
			return dynamicHeaders(category);
		else if (tableName === 'assetamort_noextra_breakdown')
			return dynamicHeaders(category);
		else if (tableName.includes('vintage_portfolio'))
			return dynamicHeaders(category);
		else if (tableName.includes('assetamort_breakdown1'))
			return dynamicHeaders(category);
		else if (tableName.includes('assetamort_breakdown2'))
			return dynamicHeaders(category);
		else if (tableName.includes('assetamort_breakdown3'))
			return dynamicHeaders(category);
		else if (tableName.includes('outstanding_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('cumulative_chargeoff_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('equity_requirement0'))
			return dynamicHeaders(category);
		else if (tableName.includes('equity_requirement1'))
			return dynamicHeaders(category);
		else if (tableName.includes('equity_requirement3'))
			return dynamicHeaders(category);
		else if (tableName.includes('cumulative_chargeoff_netrecovery_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('equity_requirement2'))
			return dynamicHeaders(category);
		else if (tableName === 'incomestatement0') return dynamicHeaders(category);
		else if (tableName.includes('incomestatement1'))
			return dynamicHeaders(category);
		else if (tableName.includes('incomestatement2'))
			return dynamicHeaders(category);
		else if (tableName.includes('incomestatement3'))
			return dynamicHeaders(category);
		else if (tableName.includes('incomestatement_overheaddiff'))
			return dynamicHeaders(category);
		else if (tableName === 'issuportschedule') return dynamicHeaders(category);
		else if (tableName.includes('issuportschedule1'))
			return dynamicHeaders(category);
		else if (tableName.includes('issuportschedule2'))
			return dynamicHeaders(category);
		else return null;
	};

	const fetchSecondParams = (tableName) => {
		if (tableName === 'loanmodel') return 'loanmodel';
		else if (tableName === 'pipelinevectors') return 'pipelinevectors';
		else if (tableName.includes('loanmodel_g')) return 'loanmodel';
		else return '';
	};

	const fetchThirdParams = (tableName) => {
		if (tableName === 'loanmodel') return '?orient=split';
		else if (tableName === 'pipelinevectors') return '?orient=split';
		else if (tableName.includes('loanmodel_g'))
			return `?orient=split&grade_number=${tableName.slice(-1)}`;
		else return '?incomestatement_orient=split';
	};

	// const handleTableBoxChange = (e) => {
	// 	if (e.length > 0) {
	// 		let arr;
	// 		// compare between two array and return element
	// 		if (e.length > state.openChartsCash.length) {
	// 			arr = e.filter((val) => !state.openChartsCash.includes(val))[0];
	// 			return setState({
	// 				...state,
	// 				openChartsCash: [...state.openChartsCash, arr]
	// 			});
	// 		} else {
	// 			arr = state.openChartsCash.filter((val) => e.includes(val));
	// 			return setState({ ...state, openChartsCash: arr });
	// 		}
	// 	}
	// };

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator
	) => {
		return (verboseTableName === 'Vintage' ||
			verboseTableName === 'Portfolio') &&
			Object.keys(vintageKeys).length === 0 ? (
			<></>
		) : (
			<div>
				<MainTable
					header={tableData && tableData[tableName]?.columns}
					data={tableData && tableData[tableName]}
					attributes={
						tableData &&
						tableData[tableName]?.data &&
						Object.keys(tableData[tableName]?.columns)
					}
					multiSeparator={multiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					fetchData={() => {
						if (
							!tables3 ||
							!tables3.loanmodel ||
							!tables3.pipelinevectors ||
							!tables3.incomestatement0 ||
							!tables3.loanmodel_g1 ||
							!tables3.loanmodel_g2 ||
							!tables3.loanmodel_g3 ||
							!tables3.loanmodel_g4 ||
							!tables3.loanmodel_g5 ||
							!tables3.loanmodel_g6 ||
							!tables3.loanmodel_g7
						)
							fetchScenarioDetails(
								selectedScenario[0]?.id,
								fetchSecondParams(tableName),
								fetchThirdParams(tableName)
							);
					}}
					collapsed={collapsed}
					separator={typeHeaders(
						tableName,
						tableData?.[tableName]?.[multiSeparator ? 'category2' : 'category']
					)}
					nestedSeparator={typeHeaders(
						tableName,
						tableData?.[tableName]?.[!multiSeparator ? 'category2' : 'category']
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model={'2'}
					id={selectedSubPorofolio[0]?.id}
					doubleDash={doubleDash}
					doubleDashPortfolioSummary={doubleDashPortfolioSummary}
					modelName={'fpna3'}
				/>
			</div>
		);
	};
	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(303)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'fpna3'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							loading={status3 === 'pending'}
							key={1003}
							portfolioList={portfolios3 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios3.filter((item) => item.id == val)[0]
								);
								fetchScenarios(val, 'output/?incomestatement_orient=split');
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(
										'2',
										name,
										user?.company_id,
										file,
										(res) => {
											setRunningTaskId(res.data.id);
											fetchPortfolio('create');
											dispatch({
												type: TASK_PROGRESS_FPNA3,
												payload: '0.0 %'
											});
										},
										'fpna3'
									)
								);
							}}
							update={(name) => {
								dispatch(
									updatePortfolio('2', selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
									})
								);
							}}
							deleteObj={() => deleteFunction()}
							upload={(formData) => {
								dispatch(
									updatePortfolio(
										'2',
										selectedPortfolio?.id,
										formData,
										(res) => {
											setRunningTaskId(res.data.id);
											fetchScenarios(selectedPortfolio?.id, '', 'create');
										},
										'fpna3'
									)
								);
								dispatch({
									type: TASK_PROGRESS_FPNA3,
									payload: '0.0 %'
								});
							}}
							downloadFile={() => {
								dispatch(downloadDataFile('2', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNA3Template());
							}}
							// data={DataSelection}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios3?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => {
								setSelectedScenario([item]);
							}}
							// setSelectedSubPorofolio={(item) => {
							// 	setSelectedSubPorofolio(
							// 		subPortofolio3?.results.filter(
							// 			(itemm) => +itemm?.id === +item
							// 		)
							// 	);
							// }}
							// subPotofoliosData={subPortofolio3?.results}
							// selectedSubPorofolio={selectedSubPorofolio}
							// segmentData={segment3}
							// updateSegment={updateSegment}
							runCalculateFunction={runCalculateFunction}
							setData={(val) => {
								setDataType(val);
								selectedPortfolio?.id &&
									fetchScenarios(selectedPortfolio?.id, val);
								if (
									tables3 &&
									(tables3.assetamort ||
										tables3.balancesheet ||
										tables3.cashflowstatement ||
										tables3.liability ||
										tables3.structure ||
										tables3.assetamort_noextra ||
										tables3?.equity_requirement)
								)
									fetchScenarioDetails(selectedScenario[0]?.id, val);
							}}
							downloadCustomReports={() => {
								dispatch(downloadFpna3CustomReports(selectedScenario[0]?.id));
							}}
							collapsed={collapsed}
							selectedData={dataType}
							seconds={seconds}
							status={status3}
							minutes={minutes}
							// taskProgressPercent={taskProgress3}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{renderTable(
							'149',
							'vintage_portfolio',
							tables3,
							'Historical Portfolio'
						)}
						{renderTable(
							'1',
							'pipelinevectors',
							tables3,
							'Origination Pipeline'
						)}
						{renderTable(
							'1325',
							'assetamort_breakdown2',
							tables3,
							'Asset Amortization - Consolidated',
							'',
							'',
							true
						)}
						{renderTable(
							'1322',
							'assetamort_breakdown1',
							tables3,
							'Asset Amortization - Current',
							'',
							'',
							true
						)}
						{renderTable(
							'181',
							'assetamort_breakdown',
							tables3,
							'Asset Amortization - Forecast',
							'',
							'',
							true
						)}
						{renderTable(
							'56',
							'assetamort_breakdown3',
							tables3,
							'Asset Amortization - Delinquent',
							'',
							'',
							true
						)}
						{renderTable(
							'1013',
							'equity_requirement2',
							tables3,
							'Equity Requirement - Consolidated'
						)}
						{renderTable(
							'19013',
							'equity_requirement1',
							tables3,
							'Equity Requirement - Current'
							// '',
							// '',
							// [
							// 	'untitled',
							// 	'Portfolio',
							// 	'Active Portfolio Equity Requirement',
							// 	'Expected Loss Over 120'
							// ]
						)}
						{renderTable(
							'10153',
							'equity_requirement0',
							tables3,
							'Equity Requirement - Forecast'
							// '',
							// '',
							// [
							// 	'untitled',
							// 	'Portfolio',
							// 	'Active Portfolio Equity Requirement',
							// 	'Expected Loss Over 120'
							// ]
						)}
						{renderTable(
							'1300',
							'equity_requirement3',
							tables3,
							'Equity Requirement - Delinquent'
						)}
						{renderTable(
							'3235',
							'incomestatement2',
							tables3,
							'Income Statement - Consolidated',
							'',
							'',
							true
						)}
						{renderTable(
							'3005',
							'incomestatement_overheaddiff',
							tables3,
							'Income Statement - Consolidated - Actual',
							'',
							'',
							true
						)}
						{renderTable(
							'325',
							'incomestatement1',
							tables3,
							'Income Statement - Current',
							'',
							'',
							true
						)}
						{renderTable(
							'335',
							'incomestatement0',
							tables3,
							'Income Statement - Forecast',
							'',
							'',
							true
						)}
						{renderTable(
							'323',
							'incomestatement3',
							tables3,
							'Income Statement - Delinquent',
							'',
							'',
							true
						)}
						{renderTable('9', 'loanmodel', tables3, 'Loan Data')}
						{/*dataType != 'output/loandata/?incomestatement_orient=split' && (
							<MainTable
								// header={headers.pipelineAssumptionHeader}
								data={tables3}
								// attributes={headers.pipelineAssumptionAttributes}
								tableId={12}
								tableName="Pipeline Growth Assumptions"
								fetchData={() => {
									if (
										!tables3 ||
										!tables3.loanmodel_g1 ||
										!tables3.loanmodel_g2 ||
										!tables3.loanmodel_g3 ||
										!tables3.loanmodel_g4 ||
										!tables3.loanmodel_g5 ||
										!tables3.loanmodel_g6 ||
										!tables3.loanmodel_g7
									)
										[1, 2, 3, 4, 5, 6, 7].map((arr) =>
											fetchScenarioDetails(
												selectedScenario[0]?.id,
												fetchSecondParams('loanmodel'),
												fetchThirdParams(`loanmodel_g${arr}`)
											)
										);
								}}
								collapsed={collapsed}
								download
								separator={typeHeaders('loanmodel_g')}
								multiple={true}
								multipleArray={[
									'Grade 1',
									'Grade 2',
									'Grade 3',
									'Grade 4',
									'Grade 5',
									'Grade 6',
									'Grade 7'
								]}
								stateMultipleArray={stateMultipleArray}
								setStateMultipleArray={setStateMultipleArray}
								model={'2'}
								id={selectedScenario[0]?.id}
							/>
							)*/}
						{/*renderTable(
							'1013',
							'equity_requirement2',
							tables3,
							'Equity Requirement Consolidated',
							'',
							'',
							[
								'untitled',
								'Portfolio',
								'Active Portfolio Equity Requirement',
								'Expected Loss Over 120',
								'Operating Cashflow'
							]
						)*/}

						{/*renderTable(
							'32485',
							'issuportschedule1',
							tables3,
							'Current Portfolio - Income Statement Support Schedule',
							'',
							'',
							true
						)}
						{renderTable(
							'324852',
							'issuportschedule',
							tables3,
							'Forecast Portfolio - Income Statement Support Schedule',
							'',
							'',
							true
						)}
						{renderTable(
							'2482',
							'issuportschedule2',
							tables3,
							'Consolidated Portfolio - Income Statement Support Schedule',
							'',
							'',
							true
						)*/}
						{renderChart('chart2', 3, 6, 'Current Portfolio')}
						{renderChart('chart3', 6, undefined, 'Forecast Portfolio')}
						{renderChart('chart1', 0, 3, 'Consolidated Portfolio')}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default CashFlowV2;
