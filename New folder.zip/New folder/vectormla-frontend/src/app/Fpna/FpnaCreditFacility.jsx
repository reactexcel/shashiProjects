import { Typography } from '@material-ui/core';
import AntdSelect from 'app/components/Select/antdSelect';
import NumberOfLoans from 'app/components/portfolio/NumberOfLoans';
import { useStyles } from 'app/components/portfolio/portfolioStyles';
import React, { useState } from 'react';
import { Select } from 'antd';
const { Option } = Select;

const FpnaCreditFacility = ({ model }) => {
	const classes = useStyles();
	const [customSelect3, seCustomSelect3] = useState(
		'Lending Club Recievables , LLC'
	);

	return (
		<>
			<div
				style={{
					display: 'flex',
					alignItems: 'center',
					flexWrap: 'wrap',
					marginBottom: -10,
					gap: '12px',
					marginLeft: '-20px',
					marginTop: '10px',
					paddingLeft: '20px'
				}}
			>
				<Typography
					variant="subtitle2"
					align="left"
					className={`${classes.label}`}
					style={{
						color: '#2e628d',
						fontWeight: 'bold',
						fontSize: '13px',
						marginRight: '10px',
						width: 'fit-content'
					}}
				>
					Credit Facility
				</Typography>
				{model === 'fpna6-4-1' && (
					<AntdSelect
						width={'175px'}
						defaultValue={'Lending Club Recievables , LLC'}
						change={(e) => seCustomSelect3(e?.target?.value || e)}
					>
						<Option value="Lending Club Recievables">
							Lending Club Recievables , LLC
						</Option>
					</AntdSelect>
				)}
			</div>
		</>
	);
};

export default FpnaCreditFacility;
