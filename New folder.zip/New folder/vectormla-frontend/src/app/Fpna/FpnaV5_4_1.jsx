import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import {
	GET_FPNA5_TABLES_CLEAN,
	GET_CHARTS5_CLEAN,
	TASK_PROGRESS_FPNA5,
	STOP_FPNA5_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import { requiredTables_FpnaV5_4_1, tableData_FpnaV5_4_1 } from './fpna5Assets';
const FpnaV5_4_1 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { portfolios5, tables5, status5, scenarios5, staus5ScenarioID } =
		useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);

	useEffect(() => {
		if (!portfolios5 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios5?.[0]);
		if (staus5ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm5', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios5]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables5 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables5));
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA5_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS5_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm5', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status5 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status5 === 'STOPPED' ||
				status5 === 'FAILURE' ||
				status5 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status5]);

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('5', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTables_FpnaV5_4_1).map(
			(table) => fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('5', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'5',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna5'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA5,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables5) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('5', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};

	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'5',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA5,
							payload: '0.0 %'
						});
					},
					'fpna5'
				)
			)
		);
	};
	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('5', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('5', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm5', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm5/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm5', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA5,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA5,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm5', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm5', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('5', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA5_TIMER,
			payload: { status5: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status5)?.toLowerCase() === 'pending') {
			let modelName = 'cfm5';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};

	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;

		if (['Vintage', 'Portfolio'].includes(verboseTableName)) return null;

		const fetchData = () => {
			const tableKeys = Object.keys(tables5 || {});
			const isTableDataMissing = !tableKeys.includes(tableName);

			if (
				(['stopped', 'SUCCESS'].includes(('' + status5).toLowerCase()) &&
					isTableDataMissing) ||
				staus5ScenarioID !== selectedScenario?.[0]?.id
			) {
				fetchScenarioDetails(selectedScenario[0]?.id, tableName + '/');
			}
		};

		return (
			<div>
				<MainTable
					statusScenarioId={staus5ScenarioID}
					status={('' + status5).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="5"
					id={selectedScenario[0]?.id}
					modelName="fpna5"
					fetchData={fetchData}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableData_FpnaV5_4_1.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables5,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	if (
		!user?.allowed_pages?.includes(4) ||
		!user?.allowed_section4.includes(402)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna5'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status5).toLowerCase() === 'pending'}
							key={1005}
							portfolioList={portfolios5 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios5.filter((item) => item.id == val)[0]
								);
							}}
							create={(name, file) => createFunction(name, file)}
							update={(name) => updateFunction(name)}
							deleteObj={() => deleteFunction()}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('5', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('5'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios5?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('5', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status5}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<>{renderTables()}</>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV5_4_1;
