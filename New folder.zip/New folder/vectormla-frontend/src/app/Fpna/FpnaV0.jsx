import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import {
	GET_FPNA0_TABLES_CLEAN,
	GET_CHARTS0_CLEAN,
	TASK_PROGRESS_FPNA0,
	STOP_FPNA0_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import { requiredTables_FpnaV0, tableData_FpnaV0 } from './FpnaV0Assets';

const FpnaV0 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { portfolios0, tables0, status0, scenarios0, staus0ScenarioID } =
		useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);

	useEffect(() => {
		if (!portfolios0 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios0?.[0]);
		if (staus0ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm0', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios0]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables0 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables0));
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA0_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS0_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm0', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status0 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status0 === 'STOPPED' ||
				status0 === 'FAILURE' ||
				status0 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status0]);

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('0', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTables_FpnaV0).map((table) =>
			fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('0', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'0',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna0'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA0,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables0) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('0', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};
	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'0',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA0,
							payload: '0.0 %'
						});
					},
					'fpna0'
				)
			)
		);
	};

	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('0', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('0', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm0', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm0/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm0', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA0,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA0,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm0', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm0', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('0', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA0_TIMER,
			payload: { status0: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status0)?.toLowerCase() === 'pending') {
			let modelName = 'cfm0';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};

	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;

		if (['Vintage', 'Portfolio'].includes(verboseTableName)) return null;

		const fetchData = () => {
			const tableKeys = Object.keys(tables0 || {});
			const isTableDataMissing = !tableKeys.includes(tableName);

			if (
				(['stopped', 'SUCCESS'].includes(('' + status0).toLowerCase()) &&
					isTableDataMissing) ||
				staus0ScenarioID !== selectedScenario?.[0]?.id
			) {
				fetchScenarioDetails(selectedScenario[0]?.id, tableName + '/');
			}
		};

		return (
			<div>
				<MainTable
					statusScenarioId={staus0ScenarioID}
					status={('' + status0).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="0"
					id={selectedScenario[0]?.id}
					modelName="fpna0"
					fetchData={fetchData}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableData_FpnaV0.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables0,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(307)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />
			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna0'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status0).toLowerCase() === 'pending'}
							key={1007}
							portfolioList={portfolios0 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios0.filter((item) => item.id == val)[0]
								);
							}}
							create={(name, file) => createFunction(name, file)}
							update={(name) => updateFunction(name)}
							deleteObj={() => deleteFunction()}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('0', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('0'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios0?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('0', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status0}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<>{renderTables()}</>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV0;
