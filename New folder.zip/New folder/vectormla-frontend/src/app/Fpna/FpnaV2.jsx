import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid } from '@material-ui/core';
import { useStyles } from './fpnaStyles';
import MainTable from '../components/Table/MainTable';
import {
	getPortfolios,
	createPortfolio,
	deletePortfolio,
	updatePortfolio,
	getPortfolioDetails,
	downloadFPNA2Template,
	downloadDataFile
} from '../store/actions/fpna.action';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import Portfolio from '../components/portfolio/Portfolio';
import headers from './tableHeader';
import { GET_FPNA2_TABLES_CLEAN } from '../store/types/fpna.type';
import { startTimer } from 'app/store/actions/timer.action';
const Fpna2 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { portfolios2, loading, tables2, status2 } = useSelector(
		(state) => state.fpna
	);
	const dispatch = useDispatch();

	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();

	const [selectedPortfolio, setSelectedPortolio] = useState(null);

	const [dataType, setDataType] = useState('output');

	const fetchPortfolio = (fetchall = false) => {
		dispatch(
			getPortfolios('', (res) => {
				setSelectedPortolio(res[0]);
				fetchall && updateTables(res[0].id);
			})
		);
	};
	useEffect(() => {
		if (!portfolios2 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		if (portfolios2 && !selectedPortfolio) setSelectedPortolio(portfolios2[0]);
	}, [portfolios2, user]);

	useEffect(() => {
		return () => {
			dispatch({ type: GET_FPNA2_TABLES_CLEAN });
		};
	}, []);

	useEffect(() => {
		if (selectedPortfolio && status2 === 'SUCCESS')
			updateTables(selectedPortfolio?.id);
	}, [status2]);

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(302)
	)
		return <div></div>;

	const fetchPortfolioDetails = (model, type) => {
		if (!model) return;
		dispatch(getPortfolioDetails('', model, type ? type : dataType));
	};

	const updateTables = (id = selectedPortfolio.id) => {
		if (!tables2) return;
		if (tables2.loanmodel) fetchPortfolioDetails(id, 'loanmodel');
		if (tables2.marketintrate) fetchPortfolioDetails(id, 'marketintrate');
		if (tables2.pipeline) fetchPortfolioDetails(id, 'pipeline');
		if (tables2.pipelinevectors) fetchPortfolioDetails(id, 'pipelinevectors');
		if (tables2.vectors) fetchPortfolioDetails(id, 'vectors');
		if (
			tables2.assetamort ||
			tables2.balancesheet ||
			tables2.cashflowstatement ||
			tables2.incomestatement ||
			tables2.liability ||
			tables2.loanmodel_duration ||
			tables2.structure
		)
			fetchPortfolioDetails(id);
	};

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(302)
	)
		return <div></div>;
	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'fpna2'}
							port={selectedPortfolio?.id}
							portfolioList={portfolios2 || []}
							loading={loading}
							key={1002}
							setPortfolio={(val) => {
								setSelectedPortolio(
									portfolios2.filter((item) => item.id == val)[0]
								);
								updateTables(val);
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio('', name, user?.company_id, file, (res) => {
										dispatch(startTimer('cfm', res.data.id));
										fetchPortfolio();
									})
								);
							}}
							update={(name) => {
								dispatch(
									updatePortfolio('', selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio('', selectedPortfolio?.id, () => {
										fetchPortfolio(true);
										dispatch({ type: GET_FPNA2_TABLES_CLEAN });
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('cfm', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(
										'',
										selectedPortfolio?.id,
										formData,
										(res) => {
											updateTables();
										}
									)
								);
							}}
							downloadFile={() => {
								dispatch(downloadDataFile('', selectedPortfolio?.id));
							}}
							data={[
								{ key: 'output', value: 'Consolidated' },
								{ key: 'output/pipeline', value: 'Forecast' },
								{ key: 'output/loandata', value: 'Origination' }
							]}
							setData={(val) => {
								setDataType(val);
								if (
									tables2 &&
									(tables2.assetamort ||
										tables2.balancesheet ||
										tables2.cashflowstatement ||
										tables2.incomestatement ||
										tables2.liability ||
										tables2.loanmodel_duration ||
										tables2.structure)
								)
									fetchPortfolioDetails(selectedPortfolio?.id, val);
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNA2Template(selectedPortfolio?.id));
							}}
							selectedData={dataType}
							collapsed={collapsed}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						<MainTable
							header={headers.intRateHeader}
							data={tables2?.marketintrate}
							attributes={headers.intRateAttributes}
							tableId={1}
							tableName="Market Int Rate"
							fetchData={() => {
								if (!tables2?.marketintrate)
									fetchPortfolioDetails(selectedPortfolio?.id, 'marketintrate');
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.pipelineVecHeader}
							data={tables2?.pipelinevectors}
							attributes={headers.pipelineVecAttributes}
							tableId={11}
							tableName="Pipeline Vectors"
							fetchData={() => {
								if (!tables2?.pipelinevectors)
									fetchPortfolioDetails(
										selectedPortfolio?.id,
										'pipelinevectors'
									);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.pipelineHeader}
							data={tables2?.pipeline}
							attributes={headers.pipelineAttributes}
							tableId={12}
							tableName="Pipeline Growth Assumptions"
							fetchData={() => {
								if (!tables2?.pipeline)
									fetchPortfolioDetails(selectedPortfolio?.id, 'pipeline');
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.loanModelHeader}
							data={tables2?.loanmodel}
							attributes={headers.loanModelAttributes}
							tableId={2}
							tableName="Loan Data"
							fetchData={() => {
								if (!tables2?.loanmodel)
									fetchPortfolioDetails(selectedPortfolio?.id, 'loanmodel');
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.vectorHeader}
							data={tables2?.vectors}
							attributes={headers.vectorAttributes}
							tableId={3}
							tableName="Vectors"
							fetchData={() => {
								if (!tables2?.vectors)
									fetchPortfolioDetails(selectedPortfolio?.id, 'vectors');
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.amortHeader}
							data={tables2?.assetamort}
							attributes={headers.amortAttributes}
							tableId={5}
							tableName="Asset Amortization Table"
							fetchData={() => {
								if (!tables2?.assetamort)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.durationHeader}
							data={tables2?.loanmodel_duration}
							attributes={headers.durationAttributes}
							tableId={6}
							tableName="Duration Table"
							fetchData={() => {
								if (!tables2?.loanmodel_duration)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.liabilityHeader}
							data={tables2?.liability}
							attributes={headers.liabilityAttributes}
							tableId={4}
							tableName="Liability Table"
							fetchData={() => {
								if (!tables2?.liability)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.structureHeader}
							data={tables2?.structure}
							attributes={headers.structureAttributes}
							tableId={7}
							tableName="Structure"
							fetchData={() => {
								if (!tables2?.structure)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.incomeHeader}
							data={tables2?.incomestatement}
							attributes={headers.incomeAttributes}
							tableId={8}
							tableName="Income Statement"
							fetchData={() => {
								if (!tables2?.incomestatement)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.balanceHeader}
							data={tables2?.balancesheet}
							attributes={headers.balanceAttributes}
							tableId={9}
							tableName="Balance Sheet"
							fetchData={() => {
								if (!tables2?.balancesheet)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.cashflowHeader}
							data={tables2?.cashflowstatement}
							attributes={headers.cashflowAttributes}
							tableId={10}
							tableName="Cash Flow Statement"
							fetchData={() => {
								if (!tables2?.cashflowstatement)
									fetchPortfolioDetails(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default Fpna2;
