export const DummyDataForTable = {
	historical_dd: {
		columns: [
			'----',
			'----',
			'----',
			'----',
			'----',
			'----',
			'----',
			'----',
			'----',
			'----',
			'----'
		],
		index: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
		data: [
			[
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----'
			],
			[
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----'
			],
			[
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----'
			],
			[
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----',
				'----'
			]
		],
		category: {
			untitled: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
		},
		columns_original: ['----', '----', '----', '----']
	},
	deliverables_dd: {
		columns: [
			'Deliverable',
			'Compliance certificate',
			'Servicer Report',
			'Quarterly Financial Statements',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report',
			'Monthly Financial Statements',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report',
			'Weekly Borrowing Base Report'
		],
		index: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
		data: [
			[
				'Section',
				'Section 13.1(d)',
				'Section 10.2(f)',
				'Section 11.1(g)',
				'Section 11.1(g)',
				'Section 11.1(g)',
				'Section 11.1(g)',
				'Section 10.2(f)',
				'Section 11.1(g)',
				'Section 11.1(g)',
				'Section 11.1(g)',
				'Section 11.1(g)'
			],
			[
				'Due Date',
				'Fri, 28 June 2024',
				'Fri, 28 June 2024',
				'Fri, 28 June 2024',
				'Fri, 28 June 2024',
				'Fri, 21 June 2024',
				'Fri, 14 June 2024',
				'Fri, 7 June 2024',
				'Fri, 31 May 2024',
				'Fri, 31 May 2024',
				'Fri, 24 May 2024',
				'Fri, 17 May 2024',
				'Fri, 10 May 2024'
			],
			[
				'Status',
				'Pending',
				'Completed',
				'Overdue',
				'Completed',
				'Completed',
				'Urgent',
				'Completed',
				'Completed',
				'Completed',
				'Not Applicable',
				'Completed',
				'Completed'
			]
		],
		category: {
			untitled: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
		},
		columns_original: ['Deliverable', 'Section', 'Due Date', 'Status']
	}
};
