// THIS PAGE IS 1.2.3 in CREDIT RISK
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import {
	getPortfolios,
	deletePortfolio,
	getCharts3_2,
	getCharts3_3,
	getScenarioDetails,
	getPortfolioScenarios,
	getCalcStatus,
	getSegment,
	// downloadFpna3CustomReports,
	updateSegmentReq,
	getSubPortofolios
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import {
	// incomeStatementHeaders,
	// loanHeaders2,
	// pipelineVectorsHeaders2,
	// loanPipelineHeaders2,
	dynamicHeaders
} from '../Fpna/liabilityTableFileds';
import {
	GET_FPNA3_TABLES_CLEAN,
	GET_CHARTS3_CLEAN,
	TASK_PROGRESS_FPNA3,
	STOP_FPNA3_TIMER
} from '../store/types/fpna.type';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import Chart from 'app/components/Chart/Chart';
// const Chart = lazy(() => import('../components/Chart/MultiLineChart')); // causes a problem in the header letter (A,B,C...) => FIXED
// const MainTable = lazy(() => import('../components/Table/MainTable')); // causes a problem in the header letter (A,B,C...) => FIXED
import MainTable from 'app/components/Table/MainTable';

const CreditRisk3 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios3,
		charts3,
		charts3_3,
		tables3,
		status3,
		// seconds,
		// minutes,
		// scenarios3,
		// subPortofolio3,
		// segment3,
		taskProgress3
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const [chartsData, setChartsData] = useState([]);
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [vintageKeys, setVintageKeys] = useState({});
	const [outstandingDF, setOutstandingDFKeys] = useState({});
	const [cumulativeChargeoffDFKeys, setCumulativeChargeoffDFKeys] = useState(
		{}
	);
	const [
		cumulativeChargeoffNetrecoveryDFKeys,
		setCumulativeChargeoffNetrecoveryDFKeys
	] = useState({});
	const [doubleDash, setDoubleDash] = useState({});
	const [doubleDashPortfolioSummary, setDoubleDashPortfolioSummary] = useState(
		{}
	);
	const [portfolioVintageKeys, setPortfolioVintageKeys] = useState({});
	const [chartVisible, setChartVisible] = useState(false);
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);

	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA3_TIMER,
			payload: { status3: 'stopped' }
		});
	};

	const dispatchClean = (unmount) => {
		dispatch({
			type: GET_FPNA3_TABLES_CLEAN,
			payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS3_CLEAN });
	};

	const killTaskFunction = (closeKillTaskDialog) => {
		let modelName = 'cfm2';
		dispatch(
			killTaskFunc(modelName, runningTaskId, () => {
				deleteFunction();
				closeKillTaskDialog();
				setRunningTaskId();
				stopTimerFunction();
				dispatch(stopTimer(modelName, 'STOPPED'));
			})
		);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('2', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};

	useEffect(() => {
		if (!portfolios3 && user?.allowed_pages?.includes(2)) fetchPortfolio();
	}, [user, portfolios3]);

	useEffect(() => {
		if (tables3?.vintage_df) {
			setDoubleDash(tables3.vintage_df['columns']);
		}
		if (tables3?.vintage_portfolio) {
			setDoubleDashPortfolioSummary(tables3?.vintage_portfolio['columns']);
		}
	}, [tables3]);

	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);

	useEffect(() => {
		if (selectedScenario[0] && status3 === 'SUCCESS') {
			updateTables(selectedScenario[0]?.id);
			fetchSubPorofolios(selectedScenario[0]);
		}
	}, [status3]);

	const calculateStatus = (supPorofolioId) => {
		supPorofolioId && dispatch(startTimer('cfm2', supPorofolioId, ''));
		getCalcStatus('cfm2/portfolio', selectedSubPorofolio[0]?.id, (res) => {
			if (res.task_state === 'SUCCESS') {
				updateTables(selectedSubPorofolio[0]?.id);
			}
			if (res.task_state !== 'SUCCESS')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: res.task_progress
				});
			else if (res.task_state === 'FAILURE')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: 'Failed'
				});
		});
	};

	useEffect(() => {
		if (selectedSubPorofolio && selectedSubPorofolio[0]?.id) {
			calculateStatus();
		}
	}, [selectedSubPorofolio]);

	useEffect(() => {
		return () => {
			dispatchClean('unmount');
			stopTimerFunction();
		};
	}, []);

	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('2', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, dataType, create);
			})
		);
	};

	const fetchScenarios = (scenarioGroupId, dataTypeVal, create) => {
		dispatch(
			getPortfolioScenarios('2', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm2', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const fetchSubPorofolios = (scenarioId) => {
		dispatch(
			getSubPortofolios('2', scenarioId?.id, (scenriosSubPortofolios) => {
				setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
				scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
			})
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('2', supPorofolioId));
	};

	const updateSegment = (segmentID, data) => {
		dispatch(updateSegmentReq('2', segmentID, data));
		fetchSegments(selectedSubPorofolio[0]);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id, dataType);
	}, [selectedPortfolio]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [selectedScenario]);

	useEffect(() => {
		if (selectedSubPorofolio?.[0]?.id) {
			dispatch(getCharts3_2(selectedSubPorofolio?.[0]?.id));
			dispatch(getCharts3_3(selectedSubPorofolio?.[0]?.id));
		}
	}, [selectedSubPorofolio]);

	const fetchScenarioDetails = (model, type, query = '') => {
		if (!model) return;
		dispatch(
			getScenarioDetails('2', model, type ? type : dataType, query, (data) => {
				if (type === 'default-vintage') {
					let finalObject = {};
					Object.keys(data?.vintage_df?.category).map(
						(item) =>
							(finalObject[`${item}`] = data?.vintage_df?.category[item])
					);
					setVintageKeys(finalObject);
				}
			})
		);
	};
	const fetchScenarioVintageSummary = (model, type, query = '', name) => {
		if (!model) return;
		dispatch(
			getScenarioDetails('2', model, type ? type : dataType, query, (data) => {
				if (name === 'Outstanding Portfolio as % of Origination') {
					let finalObject = {};
					Object.keys(data?.outstanding_df?.category).map(
						(item) =>
							(finalObject[`${item}`] = data?.outstanding_df?.category[item])
					);
					setOutstandingDFKeys(finalObject);
				}
				if (name === 'Cumulative Charge-off') {
					let finalObject = {};
					Object.keys(data?.cumulative_chargeoff_df?.category).map(
						(item) =>
							(finalObject[`${item}`] =
								data?.cumulative_chargeoff_df?.category[item])
					);
					setCumulativeChargeoffDFKeys(finalObject);
				}
				if (name === 'Cumulative Charge-off - Net of Recovery') {
					let finalObject = {};
					Object.keys(data?.cumulative_chargeoff_netrecovery_df?.category).map(
						(item) =>
							(finalObject[`${item}`] =
								data?.cumulative_chargeoff_netrecovery_df?.category[item])
					);
					setCumulativeChargeoffNetrecoveryDFKeys(finalObject);
				}
			})
		);
	};
	const fetchScenarioDetailsPortfolioVintage = (model, type, query = '') => {
		if (!model) return;
		dispatch(
			getScenarioDetails('2', model, type ? type : dataType, query, (data) => {
				if (type === 'portfolio-vintage') {
					let finalObject = {};
					Object.keys(data?.vintage_portfolio?.category).map(
						(item) =>
							(finalObject[`${item}`] = data?.vintage_portfolio?.category[item])
					);
					setPortfolioVintageKeys(finalObject);
				}
			})
		);
	};

	const typeHeaders = (tableName, category) => {
		if (tableName === 'loanmodel') return dynamicHeaders(category);
		else if (tableName === 'incomestatement') return dynamicHeaders(category);
		else if (tableName === 'pipelinevectors') return dynamicHeaders(category);
		else if (tableName.includes('loanmodel_g')) return dynamicHeaders(category);
		else if (tableName.includes('vintage_df')) return dynamicHeaders(category);
		else if (tableName.includes('vintage_portfolio'))
			return dynamicHeaders(category);
		else if (tableName.includes('outstanding_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('cumulative_chargeoff_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('monthly_chargeoff_df'))
			return dynamicHeaders(category);
		else if (tableName === 'bucket_analysis') return dynamicHeaders(category);
		else if (tableName === 'roll_rate') return dynamicHeaders(category);
		else if (tableName.includes('bucket_analysis1'))
			return dynamicHeaders(category);
		else if (tableName.includes('roll_rate_ave'))
			return dynamicHeaders(category);
		else if (tableName.includes('monthly_chargeoff_netrecovery_df'))
			return dynamicHeaders(category);
		else if (tableName.includes('cumulative_chargeoff_netrecovery_df'))
			return dynamicHeaders(category);
		else return null;
	};

	const fetchSecondParams = (tableName) => {
		if (tableName === 'loanmodel') return 'loanmodel';
		else if (tableName === 'pipelinevectors') return 'pipelinevectors';
		else if (tableName.includes('loanmodel_g')) return 'loanmodel';
		else return '';
	};

	const fetchThirdParams = (tableName) => {
		if (tableName === 'loanmodel') return '?orient=split';
		else if (tableName === 'pipelinevectors') return '?orient=split';
		else if (tableName.includes('loanmodel_g'))
			return `?orient=split&grade_number=${tableName.slice(-1)}`;
		else return '?incomestatement_orient=split';
	};

	useEffect(() => {
		if (charts3 || charts3_3) {
			let chart1 = [];
			let chart2 = [];
			let chart3 = [];
			let chart4 = [];
			let chart5 = [];
			let chart6 = [];
			let chart7 = [];
			let chart8 = [];
			let chart9 = [];
			let chart10 = [];
			let tempChart1 = [];
			let tempChart2 = [];
			let tempChart3 = [];
			let tempChart4 = [];
			let tempChart5 = [];
			let tempChart6 = [];
			let tempChart7 = [];
			let tempChart8 = [];
			let tempChart9 = [];
			let tempChart10 = [];
			charts3?.chart1?.['date'].forEach((val1, i) => {
				tempChart1.push({
					date: val1,
					status_1_del_prcnt: charts3?.chart1?.['status_1_del_prcnt'][i],
					status_2_del_prcnt: charts3?.chart1?.['status_2_del_prcnt'][i],
					status_3_del_prcnt: charts3?.chart1?.['status_3_del_prcnt'][i],
					status_4_del_prcnt: charts3?.chart1?.['status_4_del_prcnt'][i],
					total_del_prcnt: charts3?.chart1?.['total_del_prcnt'][i]
				});
				chart1.push(tempChart1);
			});

			charts3?.chart2?.['date'].forEach((val1, i) => {
				tempChart2.push({
					date: val1,
					new_origination_a: charts3?.chart2?.['new_origination_a'][i]
				});
				chart2.push(tempChart2);
			});

			charts3?.chart3?.['date'].forEach((val1, i) => {
				tempChart3.push({
					date: val1,
					monthly_chargeoff: charts3?.chart3?.['monthly_chargeoff'][i]
				});
				chart3.push(tempChart3);
			});
			charts3?.chart4?.['date'].forEach((val1, i) => {
				tempChart4.push({
					date: val1,
					recovery: charts3?.chart4?.['recovery'][i]
				});
				chart4.push(tempChart4);
			});
			charts3_3?.chart5?.['period'].forEach((val1, i) => {
				tempChart5.push({
					date: val1,
					2018: charts3_3?.chart5?.['2018'][i],
					2019: charts3_3?.chart5?.['2019'][i],
					2020: charts3_3?.chart5?.['2020'][i],
					2021: charts3_3?.chart5?.['2021'][i],
					2022: charts3_3?.chart5?.['2022'][i],
					Average: charts3_3?.chart5?.['Average'][i]
				});
				chart5.push(tempChart5);
			});
			charts3_3?.chart6?.['period'].forEach((val1, i) => {
				tempChart6.push({
					date: val1,
					2018: charts3_3?.chart6?.['2018'][i],
					2019: charts3_3?.chart6?.['2019'][i],
					2020: charts3_3?.chart6?.['2020'][i],
					2021: charts3_3?.chart6?.['2021'][i],
					2022: charts3_3?.chart6?.['2022'][i],
					Average: charts3_3?.chart6?.['Average'][i]
				});
				chart6.push(tempChart6);
			});
			charts3_3?.chart7?.['period'].forEach((val1, i) => {
				tempChart9.push({
					date: val1,
					2018: charts3_3?.chart7?.['2018'][i],
					2019: charts3_3?.chart7?.['2019'][i],
					2020: charts3_3?.chart7?.['2020'][i],
					2021: charts3_3?.chart7?.['2021'][i],
					2022: charts3_3?.chart7?.['2022'][i],
					Average: charts3_3?.chart7?.['Average'][i]
				});
				chart9.push(tempChart9);
			});
			charts3_3?.chart8?.['period'].forEach((val1, i) => {
				tempChart10.push({
					date: val1,
					2018: charts3_3?.chart8?.['2018'][i],
					2019: charts3_3?.chart8?.['2019'][i],
					2020: charts3_3?.chart8?.['2020'][i],
					2021: charts3_3?.chart8?.['2021'][i],
					2022: charts3_3?.chart8?.['2022'][i],
					Average: charts3_3?.chart8?.['Average'][i]
				});
				chart10.push(tempChart10);
			});
			charts3?.chart3?.['date'].forEach((val1, i) => {
				tempChart7.push({
					date: val1,
					monthly_chargeoff_prcnt:
						charts3?.chart3?.['monthly_chargeoff_prcnt'][i]
				});
				chart7.push(tempChart7);
			});
			charts3?.chart4?.['date'].forEach((val1, i) => {
				tempChart8.push({
					date: val1,
					recovery_prcnt: charts3?.chart4?.['recovery_prcnt'][i]
				});
				chart8.push(tempChart8);
			});

			let updatedCharts = [
				{
					ch: chart1,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart2,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart3,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart4,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart5,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart6,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart7,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart8,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart9,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart10,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				}
			];
			setChartsData(updatedCharts);
		}
	}, [charts3, charts3_3]);
	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator
	) => {
		return (verboseTableName === 'Vintage' ||
			verboseTableName === 'Portfolio') &&
			Object.keys(vintageKeys).length === 0 ? (
			<></>
		) : (
			<div>
				<MainTable
					header={tableData && tableData[tableName]?.columns}
					data={tableData && tableData[tableName]}
					attributes={
						tableData &&
						tableData[tableName]?.data &&
						Object.keys(tableData[tableName]?.columns)
					}
					multiSeparator={multiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					fetchData={() => {
						if (
							!tables3 ||
							!tables3.loanmodel ||
							!tables3.pipelinevectors ||
							!tables3.incomestatement ||
							!tables3.loanmodel_g1 ||
							!tables3.loanmodel_g2 ||
							!tables3.loanmodel_g3 ||
							!tables3.loanmodel_g4 ||
							!tables3.loanmodel_g5 ||
							!tables3.loanmodel_g6 ||
							!tables3.loanmodel_g7
						)
							fetchScenarioDetails(
								selectedScenario[0]?.id,
								fetchSecondParams(tableName),
								fetchThirdParams(tableName)
							);
					}}
					collapsed={collapsed}
					separator={typeHeaders(
						tableName,
						tableData?.[tableName]?.[multiSeparator ? 'category2' : 'category']
					)}
					nestedSeparator={typeHeaders(
						tableName,
						tableData?.[tableName]?.[!multiSeparator ? 'category2' : 'category']
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model={'2'}
					id={selectedSubPorofolio[0]?.id}
					doubleDash={doubleDash}
					doubleDashPortfolioSummary={doubleDashPortfolioSummary}
					modelName={'fpna3'}
				/>
			</div>
		);
	};

	const updateTables = (id) => {
		if (!tables3 && !id) return;
		if (tables3?.loanmodel || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split');
		if (tables3?.loanmodel_g1 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=1');
		if (tables3?.loanmodel_g2 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=2');
		if (tables3?.loanmodel_g3 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=3');
		if (tables3?.loanmodel_g4 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=4');
		if (tables3?.loanmodel_g5 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=5');
		if (tables3?.loanmodel_g6 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=6');
		if (tables3?.loanmodel_g7 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=7');
		if (tables3?.fixedintrate || id) fetchScenarioDetails(id, 'fixedintrate');
		if (tables3?.pipeline || id) fetchScenarioDetails(id, 'pipeline');
		if (tables3?.pipelinevectors || id)
			fetchScenarioDetails(id, 'pipelinevectors', '?orient=split');
		if (tables3?.vintage_df || id) fetchScenarioDetails(id, 'default-vintage');
		if (tables3?.vintage_portfolio || id)
			fetchScenarioDetailsPortfolioVintage(id, 'portfolio-vintage');
		if (tables3?.outstanding_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'Outstanding Portfolio as % of Origination'
			);
		if (tables3?.cumulative_chargeoff_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'Cumulative Charge-off'
			);
		if (tables3?.bucket_analysis || id)
			fetchScenarioVintageSummary(
				id,
				'bucket-analysis',
				'',
				'Roll Rates Schedule 1'
			);
		if (tables3?.bucket_analysis1 || id)
			fetchScenarioVintageSummary(
				id,
				'bucket-analysis1',
				'',
				'Roll Rates Schedule 2'
			);
		if (tables3?.roll_rate || id)
			fetchScenarioVintageSummary(id, 'roll-rate', '', 'Roll Rates Schedule 3');
		if (tables3?.roll_rate_ave || id)
			fetchScenarioVintageSummary(
				id,
				'roll-rate-ave',
				'',
				'12 Month Average Roll Rate'
			);
		if (tables3?.cumulative_chargeoff_netrecovery_df || id)
			fetchScenarioVintageSummary(
				id,
				'default-vintage-summary',
				'',
				'Cumulative Charge-off - Net of Recovery'
			);
		if (
			tables3?.assetamort ||
			tables3?.balancesheet ||
			tables3?.cashflowstatement ||
			tables3?.incomestatement ||
			tables3?.liability ||
			tables3?.loanmodel ||
			tables3?.structure ||
			tables3?.assetamort_noextra ||
			tables3?.equity_requirement ||
			id
		)
			fetchScenarioDetails(id);
	};

	const renderChart = () => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>
				{chartVisible && (
					<div className={classes.datechat__charts}>
						<br />
						{chartsData?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[4]?.ch}
										nameLegend={`Cumulative Charge-off Vintage`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'per'}
										noCharts={[
											'2018',
											'2019',
											'2020',
											'2021',
											'2022',
											'Average'
										]}
										customTooltip
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[5]?.ch}
										nameLegend={`Cumulative Charge-off - Net of Recovery`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'per'}
										noCharts={[
											'2018',
											'2019',
											'2020',
											'2021',
											'2022',
											'Average'
										]}
										customTooltip
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[0]?.ch}
										nameLegend={`Delinquency`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'per'}
										noCharts={[
											'status_1_del_prcnt',
											'status_2_del_prcnt',
											'status_3_del_prcnt',
											'status_4_del_prcnt',
											'total_del_prcnt'
										]}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[8]?.ch}
										nameLegend={`Monthly Charge-off Vintage - Net of Recovery`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'com'}
										noCharts={[
											'2018',
											'2019',
											'2020',
											'2021',
											'2022',
											'Average'
										]}
										customTooltip
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[9]?.ch}
										nameLegend={`Monthly Charge-off - Net of Recovery`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'com'}
										noCharts={[
											'2018',
											'2019',
											'2020',
											'2021',
											'2022',
											'Average'
										]}
										customTooltip
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[1]?.ch}
										nameLegend={`Origination`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'com'}
										noCharts={['new_origination_a']}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[2]?.ch}
										nameLegend={`Charge Off $`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'com'}
										noCharts={['monthly_chargeoff']}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[6]?.ch}
										nameLegend={`Charge Off %`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'per'}
										noCharts={['monthly_chargeoff_prcnt']}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[3]?.ch}
										nameLegend={`Recovery $`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'com'}
										noCharts={['recovery']}
									/>
								</Grid>
								<Grid
									item
									xs={12}
									sm={12}
									md={4}
									className={classes.container__chart}
								>
									<Chart
										dataT={chartsData?.[7]?.ch}
										nameLegend={`Recovery %`}
										sizeLegend="14px"
										dataX={`date`}
										xDistance={400}
										format={'per'}
										noCharts={['recovery_prcnt']}
									/>
								</Grid>
							</Grid>
						)}
					</div>
				)}
			</div>
		);
	};

	if (
		!user?.allowed_pages?.includes(2) ||
		!user?.allowed_section2.includes(207)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />

			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable('1012', 'vintage_df', tables3, 'Vintage')}
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable(
								'1002',
								'outstanding_df',
								tables3,
								'Outstanding Portfolio as % of Origination'
							)}
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable(
								'10032',
								'cumulative_chargeoff_df',
								tables3,
								'Cumulative Charge-off'
							)}
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable(
								'102',
								'monthly_chargeoff_df',
								tables3,
								'Monthly Charge-off'
							)}
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable(
								'12032',
								'cumulative_chargeoff_netrecovery_df',
								tables3,
								'Cumulative Charge-off - Net of Recovery'
							)}
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable(
								'2032',
								'monthly_chargeoff_netrecovery_df',
								tables3,
								'Monthly Charge-off Net of Recovery'
							)}
						{renderTable(
							'24820',
							'bucket_analysis',
							tables3,
							'Roll Rates Schedule 1'
						)}
						{renderTable(
							'4820',
							'bucket_analysis1',
							tables3,
							'Roll Rates Schedule 2'
						)}
						{renderTable(
							'48200',
							'roll_rate',
							tables3,
							'Roll Rates Schedule 3',
							'',
							'',
							true
						)}
						{renderTable(
							'4200',
							'roll_rate_ave',
							tables3,
							'12 Month Average Roll Rate'
						)}
						{renderChart()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default CreditRisk3;
