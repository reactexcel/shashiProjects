import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider } from '@material-ui/core';
import { useStyles } from './creditSpecStyles';
import { chart4, chart3, chart60, chartData } from './creditSpecChartsData';
import Chart from '../components/Chart/CreditRiskChart';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import AutoMLTable from '../components/autoMLTable/AutoMLTable';
import MainTable from '../components/Table/MainTable';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import { getCreditRisk } from '../store/actions/credit.action';

const CreditSpec = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { tables } = useSelector((state) => state.credit);

	const dispatch = useDispatch();
	const classes = useStyles();
	const tableHeaders = [
		'ML Models',
		'Credit Rating',
		'Cumulative DF 36 Months',
		'Cumulative EL 36 Months'
	];
	const [tableState, setTableState] = useState({
		automl: false,
		graph: false,
		graph2: false
	});
	const { ref: creditSpecRef, height: creditSpecHeight } = useComponentSize();

	const handleTableStateChange = (tableName) =>
		setTableState({
			...tableState,
			[`${tableName}`]: !tableState[`${tableName}`]
		});
	useEffect(() => {
		if (collapsed >= 1) {
			setTableState({
				...tableState,
				[`graph`]: !tableState[`graph`],
				[`graph2`]: !tableState[`graph2`],
				[`automl`]: !tableState[`automl`]
			});
		} else if (collapsed === 0) {
			if (tableState['graph'] || tableState['graph2'] || tableState['automl'])
				setTableState({
					...tableState,
					[`graph`]: !tableState[`graph`],
					[`graph2`]: !tableState[`graph2`],
					[`automl`]: !tableState[`automl`]
				});
		}
	}, [collapsed]);

	useEffect(() => {
		if (!tables && user?.allowed_pages?.includes(2)) dispatch(getCreditRisk());
	}, [tables, user]);

	if (
		!user?.allowed_pages?.includes(2) ||
		!user?.allowed_section2.includes(201)
	)
		return <div></div>;

	const renderTable = (existTables, tableData) => {
		return (
			<div>
				{existTables.map((tableName, index) => (
					<MainTable
						header={tableData && tableData[tableName]?.table?.headers}
						data={tableData && tableData[tableName]?.table?.rows}
						attributes={
							tableData && Object.keys(tableData[tableName]?.table?.rows[0])
						}
						tableId={index}
						key={index}
						tableName={tableName}
						fetchData={() => {}}
						collapsed={collapsed}
						download
					/>
				))}
			</div>
		);
	};

	const renderCharts = () => {
		return (
			<div>
				<div
					className={[classes.contentHeaderContainer]}
					onClick={() => handleTableStateChange('graph')}
				>
					<p className={classes.contentHeader}>Cumulative Graphs</p>
				</div>
				{tableState['graph'] && (
					<div className={classes.datechat__charts}>
						<Grid
							container
							spacing={1}
							justify="flex-start"
							alignItems="center"
							direction="row"
							style={{ position: 'relative', maxWidth: 1900 }}
						>
							<Grid
								key={'grid-1'}
								item
								xs={12}
								sm={12}
								md={4}
								className={classes.container__chart}
							>
								<Chart
									dataT={chartData}
									nameLegend={`60M Cumulative DF`}
									sizeLegend="18px"
									brushID={`Cumulative Default`}
									value={`Cumulative Default`}
									dataX={'timeline'}
									xDistance={380}
									format={'per'}
									maxY={10}
								/>
							</Grid>
							<Grid
								key={0}
								item
								xs={12}
								sm={12}
								md={4}
								className={classes.container__chart}
							>
								<Chart
									dataT={chart60}
									nameLegend={`60M Cumulative EL`}
									sizeLegend="18px"
									brushID={`Cum_EL`}
									value={`Cum_EL`}
									dataX={'timeline'}
									xDistance={380}
									format={'per'}
									maxY={10}
								/>
							</Grid>
						</Grid>
					</div>
				)}
			</div>
		);
	};

	const renderCharts2 = () => {
		return (
			<div>
				<div
					className={[classes.contentHeaderContainer]}
					onClick={() => handleTableStateChange('graph2')}
				>
					<p className={classes.contentHeader}>Monthly Graphs</p>
				</div>
				{tableState['graph2'] && (
					<div className={classes.datechat__charts}>
						<Grid
							container
							spacing={1}
							justify="flex-start"
							alignItems="center"
							direction="row"
							style={{ position: 'relative', maxWidth: 1900 }}
						>
							<Grid
								key={'grid-2'}
								item
								xs={12}
								sm={12}
								md={4}
								className={classes.container__chart}
							>
								<Chart
									dataT={chart3}
									nameLegend={`60M Monthly DF`}
									sizeLegend="18px"
									brushID={`Monthly Default`}
									value={`Monthly Default`}
									dataX={'timeline'}
									xDistance={380}
									format={'per'}
									maxY={0.6}
								/>
							</Grid>
							<Grid
								key={0}
								item
								xs={12}
								sm={12}
								md={4}
								className={classes.container__chart}
							>
								<Chart
									dataT={chart4}
									nameLegend={`60M Monthly EL`}
									sizeLegend="18px"
									brushID={`Monthly EL`}
									value={`Monthly EL`}
									dataX={'timeline'}
									xDistance={380}
									format={'per'}
									maxY={0.6}
								/>
							</Grid>
						</Grid>
					</div>
				)}
			</div>
		);
	};

	return (
		<div ref={creditSpecRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={creditSpecHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<div
							className={[classes.contentHeaderContainer]}
							onClick={() => handleTableStateChange('automl')}
						>
							<p className={classes.contentHeader}>AutoML</p>
						</div>
						{tableState['automl'] && <AutoMLTable width={200} />}

						{renderTable(tableHeaders, tables)}
						{renderCharts()}
						{renderCharts2()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default CreditSpec;
