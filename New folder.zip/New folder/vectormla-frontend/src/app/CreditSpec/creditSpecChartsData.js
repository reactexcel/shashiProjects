export const chart4 = [
	{
		timeline: 0,
		'Monthly EL': '0.09'
	},
	{
		timeline: 1,
		'Monthly EL': '0.11'
	},
	{
		timeline: 2,
		'Monthly EL': '0.14'
	},
	{
		timeline: 3,
		'Monthly EL': '0.18'
	},
	{
		timeline: 4,
		'Monthly EL': '0.22'
	},
	{
		timeline: 5,
		'Monthly EL': '0.24'
	},
	{
		timeline: 6,
		'Monthly EL': '0.26'
	},
	{
		timeline: 7,
		'Monthly EL': '0.29'
	},
	{
		timeline: 8,
		'Monthly EL': '0.31'
	},
	{
		timeline: 9,
		'Monthly EL': '0.32'
	},
	{
		timeline: 10,
		'Monthly EL': '0.34'
	},
	{
		timeline: 11,
		'Monthly EL': '0.33'
	},
	{
		timeline: 12,
		'Monthly EL': '0.31'
	},
	{
		timeline: 13,
		'Monthly EL': '0.27'
	},
	{
		timeline: 14,
		'Monthly EL': '0.26'
	},
	{
		timeline: 15,
		'Monthly EL': '0.22'
	},
	{
		timeline: 16,
		'Monthly EL': '0.21'
	},
	{
		timeline: 17,
		'Monthly EL': '0.18'
	},
	{
		timeline: 18,
		'Monthly EL': '0.17'
	},
	{
		timeline: 19,
		'Monthly EL': '0.17'
	},
	{
		timeline: 20,
		'Monthly EL': '0.14'
	},
	{
		timeline: 21,
		'Monthly EL': '0.14'
	},
	{
		timeline: 22,
		'Monthly EL': '0.13'
	},
	{
		timeline: 23,
		'Monthly EL': '0.11'
	},
	{
		timeline: 24,
		'Monthly EL': '0.10'
	},
	{
		timeline: 25,
		'Monthly EL': '0.08'
	},
	{
		timeline: 26,
		'Monthly EL': '0.08'
	},
	{
		timeline: 27,
		'Monthly EL': '0.06'
	},
	{
		timeline: 28,
		'Monthly EL': '0.06'
	},
	{
		timeline: 29,
		'Monthly EL': '0.05'
	},
	{
		timeline: 30,
		'Monthly EL': '0.04'
	},
	{
		timeline: 31,
		'Monthly EL': '0.04'
	},
	{
		timeline: 32,
		'Monthly EL': '0.04'
	},
	{
		timeline: 33,
		'Monthly EL': '0.04'
	},
	{
		timeline: 34,
		'Monthly EL': '0.03'
	},
	{
		timeline: 35,
		'Monthly EL': '0.02'
	},
	{
		timeline: 36,
		'Monthly EL': '0.02'
	},
	{
		timeline: 37,
		'Monthly EL': '0.02'
	},
	{
		timeline: 38,
		'Monthly EL': '0.02'
	},
	{
		timeline: 39,
		'Monthly EL': '0.02'
	},
	{
		timeline: 40,
		'Monthly EL': '0.01'
	},
	{
		timeline: 41,
		'Monthly EL': '0.02'
	},
	{
		timeline: 42,
		'Monthly EL': '0.01'
	},
	{
		timeline: 43,
		'Monthly EL': '0.01'
	},
	{
		timeline: 44,
		'Monthly EL': '0.01'
	},
	{
		timeline: 45,
		'Monthly EL': '0.01'
	},
	{
		timeline: 46,
		'Monthly EL': '0.01'
	},
	{
		timeline: 47,
		'Monthly EL': '0.01'
	},
	{
		timeline: 48,
		'Monthly EL': '0.01'
	},
	{
		timeline: 49,
		'Monthly EL': '0.01'
	},
	{
		timeline: 50,
		'Monthly EL': '0.01'
	},
	{
		timeline: 51,
		'Monthly EL': '0.00'
	},
	{
		timeline: 52,
		'Monthly EL': '0.00'
	},
	{
		timeline: 53,
		'Monthly EL': '0.00'
	},
	{
		timeline: 54,
		'Monthly EL': '0.00'
	},
	{
		timeline: 55,
		'Monthly EL': '0.00'
	},
	{
		timeline: 56,
		'Monthly EL': '0.00'
	},
	{
		timeline: 57,
		'Monthly EL': '0.00'
	},
	{
		timeline: 58,
		'Monthly EL': '0.00'
	},
	{
		timeline: 59,
		'Monthly EL': '0.00'
	},
	{
		timeline: 60,
		'Monthly EL': '0.00'
	}
];

export const chart3 = [
	{
		timeline: 0,
		'Monthly Default': ' 0.15 '
	},
	{
		timeline: 1,
		'Monthly Default': ' 0.18 '
	},
	{
		timeline: 2,
		'Monthly Default': ' 0.24 '
	},
	{
		timeline: 3,
		'Monthly Default': ' 0.30 '
	},
	{
		timeline: 4,
		'Monthly Default': ' 0.37 '
	},
	{
		timeline: 5,
		'Monthly Default': ' 0.40 '
	},
	{
		timeline: 6,
		'Monthly Default': ' 0.43 '
	},
	{
		timeline: 7,
		'Monthly Default': ' 0.49 '
	},
	{
		timeline: 8,
		'Monthly Default': 0.51
	},
	{
		timeline: 9,
		'Monthly Default': 0.53
	},
	{
		timeline: 10,
		'Monthly Default': ' 0.56 '
	},
	{
		timeline: 11,
		'Monthly Default': ' 0.55 '
	},
	{
		timeline: 12,
		'Monthly Default': ' 0.52 '
	},
	{
		timeline: 13,
		'Monthly Default': ' 0.45 '
	},
	{
		timeline: 14,
		'Monthly Default': ' 0.43 '
	},
	{
		timeline: 15,
		'Monthly Default': ' 0.37 '
	},
	{
		timeline: 16,
		'Monthly Default': ' 0.35 '
	},
	{
		timeline: 17,
		'Monthly Default': ' 0.30 '
	},
	{
		timeline: 18,
		'Monthly Default': 0.29
	},
	{
		timeline: 19,
		'Monthly Default': ' 0.29 '
	},
	{
		timeline: 20,
		'Monthly Default': ' 0.23 '
	},
	{
		timeline: 21,
		'Monthly Default': ' 0.23 '
	},
	{
		timeline: 22,
		'Monthly Default': ' 0.21 '
	},
	{
		timeline: 23,
		'Monthly Default': ' 0.19 '
	},
	{
		timeline: 24,
		'Monthly Default': ' 0.17 '
	},
	{
		timeline: 25,
		'Monthly Default': ' 0.14 '
	},
	{
		timeline: 26,
		'Monthly Default': ' 0.13 '
	},
	{
		timeline: 27,
		'Monthly Default': ' 0.10 '
	},
	{
		timeline: 28,
		'Monthly Default': ' 0.10 '
	},
	{
		timeline: 29,
		'Monthly Default': '0.09'
	},
	{
		timeline: 30,
		'Monthly Default': '0.07'
	},
	{
		timeline: 31,
		'Monthly Default': '0.06'
	},
	{
		timeline: 32,
		'Monthly Default': ' 0.06 '
	},
	{
		timeline: 33,
		'Monthly Default': ' 0.06 '
	},
	{
		timeline: 34,
		'Monthly Default': ' 0.05 '
	},
	{
		timeline: 35,
		'Monthly Default': ' 0.04 '
	},
	{
		timeline: 36,
		'Monthly Default': ' 0.04 '
	},
	{
		timeline: 37,
		'Monthly Default': ' 0.04 '
	},
	{
		timeline: 38,
		'Monthly Default': ' 0.03 '
	},
	{
		timeline: 39,
		'Monthly Default': ' 0.03 '
	},
	{
		timeline: 40,
		'Monthly Default': ' 0.02 '
	},
	{
		timeline: 41,
		'Monthly Default': ' 0.03 '
	},
	{
		timeline: 42,
		'Monthly Default': ' 0.02 '
	},
	{
		timeline: 43,
		'Monthly Default': ' 0.02 '
	},
	{
		timeline: 44,
		'Monthly Default': ' 0.02 '
	},
	{
		timeline: 45,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 46,
		'Monthly Default': ' 0.02 '
	},
	{
		timeline: 47,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 48,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 49,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 50,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 51,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 52,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 53,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 54,
		'Monthly Default': ' 0.01 '
	},
	{
		timeline: 55,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 56,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 57,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 58,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 59,
		'Monthly Default': ' 0.00 '
	},
	{
		timeline: 60,
		'Monthly Default': ' 0.00 '
	}
];

export const chart60 = [
	{
		timeline: 0,
		Cum_EL: ' 0.0'
	},
	{
		timeline: 1,
		Cum_EL: ' 0.09 '
	},
	{
		timeline: 2,
		Cum_EL: ' 0.20 '
	},
	{
		timeline: 3,
		Cum_EL: ' 0.34 '
	},
	{
		timeline: 4,
		Cum_EL: ' 0.52 '
	},
	{
		timeline: 5,
		Cum_EL: ' 0.74 '
	},
	{
		timeline: 6,
		Cum_EL: ' 0.99 '
	},
	{
		timeline: 7,
		Cum_EL: ' 1.25 '
	},
	{
		timeline: 8,
		Cum_EL: ' 1.54 '
	},
	{
		timeline: 9,
		Cum_EL: ' 1.84 '
	},
	{
		timeline: 10,
		Cum_EL: ' 2.16 '
	},
	{
		timeline: 11,
		Cum_EL: ' 2.50 '
	},
	{
		timeline: 12,
		Cum_EL: ' 2.82 '
	},
	{
		timeline: 13,
		Cum_EL: ' 3.13 '
	},
	{
		timeline: 14,
		Cum_EL: ' 3.40 '
	},
	{
		timeline: 15,
		Cum_EL: ' 3.66 '
	},
	{
		timeline: 16,
		Cum_EL: ' 3.88 '
	},
	{
		timeline: 17,
		Cum_EL: ' 4.10 '
	},
	{
		timeline: 18,
		Cum_EL: ' 4.28 '
	},
	{
		timeline: 19,
		Cum_EL: ' 4.45 '
	},
	{
		timeline: 20,
		Cum_EL: ' 4.62 '
	},
	{
		timeline: 21,
		Cum_EL: ' 4.76 '
	},
	{
		timeline: 22,
		Cum_EL: ' 4.90 '
	},
	{
		timeline: 23,
		Cum_EL: ' 5.02 '
	},
	{
		timeline: 24,
		Cum_EL: ' 5.13 '
	},
	{
		timeline: 25,
		Cum_EL: ' 5.24 '
	},
	{
		timeline: 26,
		Cum_EL: ' 5.32 '
	},
	{
		timeline: 27,
		Cum_EL: ' 5.40 '
	},
	{
		timeline: 28,
		Cum_EL: ' 5.46 '
	},
	{
		timeline: 29,
		Cum_EL: ' 5.52 '
	},
	{
		timeline: 30,
		Cum_EL: ' 5.57 '
	},
	{
		timeline: 31,
		Cum_EL: ' 5.62 '
	},
	{
		timeline: 32,
		Cum_EL: ' 5.65 '
	},
	{
		timeline: 33,
		Cum_EL: ' 5.69 '
	},
	{
		timeline: 34,
		Cum_EL: ' 5.73 '
	},
	{
		timeline: 35,
		Cum_EL: ' 5.76 '
	},
	{
		timeline: 36,
		Cum_EL: ' 5.78 '
	},
	{
		timeline: 37,
		Cum_EL: ' 5.80 '
	},
	{
		timeline: 38,
		Cum_EL: ' 5.83 '
	},
	{
		timeline: 39,
		Cum_EL: ' 5.85 '
	},
	{
		timeline: 40,
		Cum_EL: ' 5.86 '
	},
	{
		timeline: 41,
		Cum_EL: ' 5.88 '
	},
	{
		timeline: 42,
		Cum_EL: ' 5.89 '
	},
	{
		timeline: 43,
		Cum_EL: ' 5.91 '
	},
	{
		timeline: 44,
		Cum_EL: ' 5.92 '
	},
	{
		timeline: 45,
		Cum_EL: ' 5.93 '
	},
	{
		timeline: 46,
		Cum_EL: ' 5.94 '
	},
	{
		timeline: 47,
		Cum_EL: ' 5.95 '
	},
	{
		timeline: 48,
		Cum_EL: ' 5.95 '
	},
	{
		timeline: 49,
		Cum_EL: ' 5.96 '
	},
	{
		timeline: 50,
		Cum_EL: ' 5.97 '
	},
	{
		timeline: 51,
		Cum_EL: ' 5.98 '
	},
	{
		timeline: 52,
		Cum_EL: ' 5.98 '
	},
	{
		timeline: 53,
		Cum_EL: ' 5.99 '
	},
	{
		timeline: 54,
		Cum_EL: ' 5.99 '
	},
	{
		timeline: 55,
		Cum_EL: ' 5.99 '
	},
	{
		timeline: 56,
		Cum_EL: ' 6.00 '
	},
	{
		timeline: 57,
		Cum_EL: ' 6.00 '
	},
	{
		timeline: 58,
		Cum_EL: ' 6.00 '
	},
	{
		timeline: 59,
		Cum_EL: ' 6.00 '
	},
	{
		timeline: 60,
		Cum_EL: ' 6.00 '
	}
];

export const chartData = [
	{
		timeline: 0,
		'Cumulative Default': ' - '
	},
	{
		timeline: 1,
		'Cumulative Default': ' 0.15 '
	},
	{
		timeline: 2,
		'Cumulative Default': ' 0.33 '
	},
	{
		timeline: 3,
		'Cumulative Default': ' 0.57 '
	},
	{
		timeline: 4,
		'Cumulative Default': ' 0.87 '
	},
	{
		timeline: 5,
		'Cumulative Default': ' 1.24 '
	},
	{
		timeline: 6,
		'Cumulative Default': ' 1.64 '
	},
	{
		timeline: 7,
		'Cumulative Default': ' 2.08 '
	},
	{
		timeline: 8,
		'Cumulative Default': ' 2.56 '
	},
	{
		timeline: 9,
		'Cumulative Default': ' 3.07 '
	},
	{
		timeline: 10,
		'Cumulative Default': ' 3.60 '
	},
	{
		timeline: 11,
		'Cumulative Default': ' 4.16 '
	},
	{
		timeline: 12,
		'Cumulative Default': ' 4.71 '
	},
	{
		timeline: 13,
		'Cumulative Default': ' 5.22 '
	},
	{
		timeline: 14,
		'Cumulative Default': ' 5.67 '
	},
	{
		timeline: 15,
		'Cumulative Default': ' 6.10 '
	},
	{
		timeline: 16,
		'Cumulative Default': ' 6.47 '
	},
	{
		timeline: 17,
		'Cumulative Default': ' 6.83 '
	},
	{
		timeline: 18,
		'Cumulative Default': ' 7.13 '
	},
	{
		timeline: 19,
		'Cumulative Default': ' 7.42 '
	},
	{
		timeline: 20,
		'Cumulative Default': ' 7.71 '
	},
	{
		timeline: 21,
		'Cumulative Default': ' 7.93 '
	},
	{
		timeline: 22,
		'Cumulative Default': ' 8.16 '
	},
	{
		timeline: 23,
		'Cumulative Default': ' 8.37 '
	},
	{
		timeline: 24,
		'Cumulative Default': ' 8.56 '
	},
	{
		timeline: 25,
		'Cumulative Default': ' 8.73 '
	},
	{
		timeline: 26,
		'Cumulative Default': ' 8.87 '
	},
	{
		timeline: 27,
		'Cumulative Default': ' 9.00 '
	},
	{
		timeline: 28,
		'Cumulative Default': ' 9.10 '
	},
	{
		timeline: 29,
		'Cumulative Default': ' 9.20 '
	},
	{
		timeline: 30,
		'Cumulative Default': ' 9.29 '
	},
	{
		timeline: 31,
		'Cumulative Default': ' 9.36 '
	},
	{
		timeline: 32,
		'Cumulative Default': ' 9.42 '
	},
	{
		timeline: 33,
		'Cumulative Default': ' 9.48 '
	},
	{
		timeline: 34,
		'Cumulative Default': ' 9.54 '
	},
	{
		timeline: 35,
		'Cumulative Default': ' 9.60 '
	},
	{
		timeline: 36,
		'Cumulative Default': ' 9.64 '
	},
	{
		timeline: 37,
		'Cumulative Default': ' 9.67 '
	},
	{
		timeline: 38,
		'Cumulative Default': ' 9.71 '
	},
	{
		timeline: 39,
		'Cumulative Default': ' 9.75 '
	},
	{
		timeline: 40,
		'Cumulative Default': ' 9.77 '
	},
	{
		timeline: 41,
		'Cumulative Default': ' 9.80 '
	},
	{
		timeline: 42,
		'Cumulative Default': ' 9.82 '
	},
	{
		timeline: 43,
		'Cumulative Default': ' 9.84 '
	},
	{
		timeline: 44,
		'Cumulative Default': ' 9.86 '
	},
	{
		timeline: 45,
		'Cumulative Default': ' 9.88 '
	},
	{
		timeline: 46,
		'Cumulative Default': ' 9.90 '
	},
	{
		timeline: 47,
		'Cumulative Default': ' 9.91 '
	},
	{
		timeline: 48,
		'Cumulative Default': ' 9.92 '
	},
	{
		timeline: 49,
		'Cumulative Default': ' 9.93 '
	},
	{
		timeline: 50,
		'Cumulative Default': ' 9.95 '
	},
	{
		timeline: 51,
		'Cumulative Default': ' 9.96 '
	},
	{
		timeline: 52,
		'Cumulative Default': ' 9.97 '
	},
	{
		timeline: 53,
		'Cumulative Default': ' 9.98 '
	},
	{
		timeline: 54,
		'Cumulative Default': ' 9.98 '
	},
	{
		timeline: 55,
		'Cumulative Default': ' 9.99 '
	},
	{
		timeline: 56,
		'Cumulative Default': ' 9.99 '
	},
	{
		timeline: 57,
		'Cumulative Default': ' 9.99 '
	},
	{
		timeline: 58,
		'Cumulative Default': ' 10.00 '
	},
	{
		timeline: 59,
		'Cumulative Default': ' 10.00 '
	},
	{
		timeline: 60,
		'Cumulative Default': ' 10.00 '
	}
];
