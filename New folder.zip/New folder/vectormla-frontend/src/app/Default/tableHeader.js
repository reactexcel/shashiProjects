const dfWeightedAverageCurveHeader = [
	'Period',
	'Timing',
	'Cum Timing',
	'Adjusted WA Curve',
	'Weighted Avg Curve'
];
const dfWeightedAverageCurveAttributes = [
	'Period',
	'Timing',
	'Cum Timing',
	'Adjusted WA Curve',
	'Weighted Avg Curve'
];
const lossDistributionHeader = [
	'Date',
	'Loss % Taken',
	'Expected Loss',
	'Loss Sev. Taken',
	'Loss to be Dist'
];
const lossDistributionAttributes = [
	'Date',
	'Loss % Taken',
	'Expected Loss',
	'Loss Sev. Taken',
	'Loss to be Dist'
];
module.exports = {
	dfWeightedAverageCurveHeader,
	dfWeightedAverageCurveAttributes,
	lossDistributionHeader,
	lossDistributionAttributes
};
