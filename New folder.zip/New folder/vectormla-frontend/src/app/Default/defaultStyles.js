import { Checkbox, makeStyles, withStyles } from '@material-ui/core';
import React from 'react';
import {
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer,
	primaryColor
} from '../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	datechat__charts: {
		width: '100%',
		margin: '20px 0px auto'
	},
	container__chart: {
		maxWidth: 425,
		height: 425
	},
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
}));

export const DarkCheckbox = withStyles({
	root: {
		color: 'grey',
		'&$checked': {
			color: primaryColor
		}
	},
	checked: {}
})((props) => <Checkbox color="default" {...props} />);
