import React from 'react';
import { makeStyles } from '@material-ui/core';
import {
	primaryColor,
	cashflowHeader,
	collapsedDrawerWidth,
	emptyAlphaCellWidth,
	numberCellWidth,
	aplphaCellHeight,
	numTopPrefix,
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
} from '../../common/assets/layout';
import { withStyles } from '@material-ui/core/styles';
import { Checkbox } from '@material-ui/core';

const select = {
	display: 'flex !important',
	position: 'relative'
};

export const useStyles = makeStyles((theme) => ({
	container__header: {
		width: '100%'
	},

	toggle_layr_button_gray: {
		height: 32,
		marginTop: 24,
		marginBottom: 28,
		position: 'relative',
		color: '#2D2D2D !important',
		textAlign: 'center',
		borderRadius: 0,
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#e9eff5 !important',
		textTransform: 'capitalize',
		'&:hover': {
			backgroundColor: '#e9eff5 !important',
			opacity: 0.7
		}
	},
	toggle_layr_button_arrow: {
		position: 'absolute',
		top: 3,
		right: 20,
		color: '#fff !important'
	},
	toggle_layr_button_typography: {
		color: '#000 !important',
		textTransform: 'capitalize',
		fontSize: 14
	},
	container__menuBars: {
		position: 'absolute',
		zIndex: 10,
		right: 0,
		top: 1
	},
	header_select: {
		...select,
		top: 5,
		marginBottom: 40,
		justifyContent: 'center',
		flex: 'wrap !important',
		transition: 'all .5s',
		width: '100%'
	},
	datechat__charts: {
		width: '100%',
		margin: '90px auto 35px'
	},
	container__chart: {
		maxWidth: 425,
		width: 350,
		height: 425,
		position: 'relative'
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 999999999,
		color: '#fff !important'
	},
	check__layr: {
		color: '#000 !important',
		position: 'absolute',
		left: 30,
		top: 9
	},
	// Styles (Refactored)
	cashflow__container: {
		position: 'relative',
		width: `calc(100% - ${
			collapsedDrawerWidth + numberCellWidth + emptyAlphaCellWidth
		}px)`,
		minHeight: '100vh',
		marginLeft: collapsedDrawerWidth + numberCellWidth + emptyAlphaCellWidth,
		paddingTop: aplphaCellHeight + numTopPrefix
	},
	cashflow__header: {
		width: '100%',
		minHeight: cashflowHeader,
		display: 'flex',
		alignItems: 'center'
	},
	cashflow__body: {
		width: '100%',
		overflowX: 'hidden',
		backgroundColor: '#FFF !important',
		padding: '0px 0px 50px 0px ',
		boxSizing: 'border-box',
		[theme.breakpoints.down('lg')]: {
			width: '100%'
		},
		[theme.breakpoints.down('sm')]: {
			width: '100%'
		}
	},
	cashflow__section: {
		minHeight: 80,
		width: '100%'
	},
	cashflow__chart: {
		margin: '100px auto 25px'
	},
	appContainer,
	contentHeaderContainer,
	contentHeader,
	appContentContainer
}));

export const DarkCheckbox = withStyles({
	root: {
		color: 'grey',
		'&$checked': {
			color: primaryColor
		}
	},
	checked: {}
})((props) => <Checkbox color="default" {...props} />);
