import React from 'react';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';

export default function RadioButtonsGroup({
	name,
	meta: { touched, invalid, error },
	input,
	children
}) {
	return (
		<FormControl error={touched && invalid} component="fieldset">
			<RadioGroup name={name} {...input}>
				{children}
			</RadioGroup>

			<FormHelperText>{touched && error}</FormHelperText>
		</FormControl>
	);
}
