import React, { useState } from 'react';
import Select from '@material-ui/core/Select';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import down from '../../common/assets/images/down.png';
import { init, sendForm } from 'emailjs-com';
import HeaderRectangle from '../common/HeaderRectangle';
import { jobs } from '../data/requestDemoData';
init('user_dF2n1EehTk1typdZvVIHo');

const RequestDemo = () => {
	const [openModal, setOpenModal] = useState(false);
	const [submited, setSubmited] = useState(false);
	const sendMail = (e) => {
		setSubmited(true);
		e.preventDefault();
		sendForm(
			'service_e1xobkp',
			'template_t9oxhco',
			e.target,
			'user_dF2n1EehTk1typdZvVIHo'
		).then(
			function (response) {
				console.log('SUCCESS!', response.status, response.text);
			},
			function (error) {
				console.log('FAILED...', error);
			}
		);
	};
	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Request Demo</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<section className="request_form">
					<div className="subContainer2 container">
						<HeaderRectangle
							header="Request Demo"
							description="Thanks for your interest in Vector ML. Take a free trial and find out why more users are replacing their legacy spreadsheets with the platform."
						/>
					</div>
				</section>

				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col form_cont" style={{ marginTop: '20px' }}>
								<form onSubmit={sendMail}>
									<div className="line"></div>
									<h4>Help us connect you with the right person</h4>
									<div className="form_control">
										<label>
											Please explain the business situation or problem you are
											trying to manage.
										</label>
										<textarea name="message"></textarea>
									</div>
									<div className="line"></div>
									<h4>Tell us about yourself</h4>
									<div className="form_control">
										<label>First name</label>
										<input type="text" name="firstname" />
									</div>
									<div className="form_control">
										<label>Last name</label>
										<input type="text" name="lastname" />
									</div>
									<div className="form_control">
										<label>Email</label>
										<input type="email" name="email" />
									</div>
									<div className="form_control">
										<label>Phone</label>
										<input type="tel" name="phone" />
									</div>
									<div className="form_control">
										<label>
											What was your primary reason for visiting our site today?
										</label>
										<Select
											native
											variant="outlined"
											name="reason"
											style={{ height: 80, width: '100%' }}
											inputProps={{
												name: 'reason'
											}}
										>
											<option value={1}>Select one</option>
											<option value={2}>To place an order</option>
											<option value={3}>
												To learn more about a specific product or solution
											</option>
											<option value={4}>Other</option>
										</Select>
									</div>
									<div className="line"></div>
									<h4>Tell us about what you do</h4>
									<div className="form_control">
										<label>Company</label>
										<input type="text" name="company" />
									</div>
									<div className="form_control">
										<label>Country/Region</label>
										<Select
											native
											variant="outlined"
											name="country"
											style={{ height: 80, width: '100%' }}
											inputProps={{
												name: 'country'
											}}
										>
											<option value={0}>{''}</option>
										</Select>
									</div>
									<div className="form_control">
										<label>City</label>
										<input type="text" name="city" />
									</div>
									<div className="form_control">
										<label>Job Title</label>
										<Select
											native
											variant="outlined"
											name="job"
											style={{ height: 80, width: '100%' }}
											inputProps={{
												name: 'job'
											}}
										>
											{jobs.map((item, i) => (
												<option key={`${i}-option`} value={i}>
													{item}
												</option>
											))}
										</Select>
									</div>
									<br />
									<button>Submit</button>
									{submited && (
										<p style={{ marginTop: 20, textAlign: 'center' }}>
											We have received your request. A representative will be
											contacting you soon.
											<br />
											In the meantime, visit our insights blog to learn more
											about the product features.
										</p>
									)}
								</form>
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default RequestDemo;
