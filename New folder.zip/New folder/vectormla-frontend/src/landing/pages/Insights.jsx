import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderRectangle from '../common/HeaderRectangle';
import HeaderWithBlueLeft from '../common/HeaderWithPlusNBlueLeft';
import DescriptionArrow from '../common/DescriptionArrow';

const Insights = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Insights</h2>
							<h3>Vector ML Analytics Platform</h3>
						</div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<div className="subContainer2 container">
					<HeaderRectangle
						header="Insights"
						description="The platform offers ease of use and speed in the analysis of banking, lending, and structured finance portfolios
                      Our clients"
					/>
				</div>

				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<HeaderWithBlueLeft header="Our clients" />
							</div>
						</div>
						<div
							className="row"
							style={{ padding: '0px 50px', marginTop: '35px' }}
						>
							<div className="col">
								<DescriptionArrow header="Banks" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Credit Unions" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Fintech" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Issuers" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Originators" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Hedge Funds" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Asset Managers" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Other Non-Banks" descirption="" />
							</div>
						</div>
					</div>
				</section>

				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<HeaderWithBlueLeft header="Asset Classes" />
							</div>
						</div>
						<div
							className="row"
							style={{ padding: '0px 50px', marginTop: '35px' }}
						>
							<div className="col">
								<DescriptionArrow header="Auto Loans" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Consumer Loans" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow
									header="Residential Mortgages"
									descirption="Mortgages have been judged as one of the most complex securities. These complexities are due to many factors, some of which include: the repayment options available to homeowners, the ability to capture fully the behavior of mortgages in different states of the world, in-homogeneity of loan level behaviors, and the fact that single period analysis cannot be used for path-dependent instruments such as mortgages."
								/>
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow
									header="Commercial Mortgages"
									descirption="Vector ML Platform improves portfolio risk management by allowing managers to make real-time data-driven decisions. It provides fast and easy portfolio intelligence to management. With key data analytics, modeling, trending capability, and insight into various portfolio risk exposures, management can go beyond the time-consuming, basic data analysis performed at a single mortgage level."
								/>
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Credit Cards" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Small Businesses" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Student Loans" descirption="" />
							</div>
						</div>
					</div>
				</section>

				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<HeaderWithBlueLeft header="Credit Risk" />
							</div>
						</div>
						<div
							className="row"
							style={{ padding: '0px 50px', marginTop: '35px' }}
						>
							<div className="col">
								<DescriptionArrow header="AutoML" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="ML Algorithms" descirption="" />
							</div>
						</div>
						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Automation" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="Security" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="API" descirption="" />
							</div>
						</div>

						<div className="row" style={{ padding: '0px 50px' }}>
							<div className="col">
								<DescriptionArrow header="AWS Cloud Native" descirption="" />
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Insights;
