import React from 'react';
import empty_page from '../../common/assets/images/email_signature.png';
// import empty_page from '../../common/assets/images/Webinar_Oct.jpg';

const HiddenPage3 = () => {
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				height: '100vh',
				margin: 0,
				padding: 0
			}}
		>
			<img
				src={empty_page}
				alt="Beautiful Picture xd"
				style={{ maxWidth: '100%', height: 'auto' }}
			/>
		</div>
	);
};

export default HiddenPage3;
