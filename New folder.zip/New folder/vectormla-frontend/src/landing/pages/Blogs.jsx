import React, { useMemo, useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import PagesSubHeader from '../common/PagesSubHeader';
import blogsDetails from '../data/blogsDetails.json';
import blogs from '../data/blogs.json';
import BlogContent from '../common/BlogContent';
import blog1_1 from '../../common/assets/images/blogs/blog1-1.svg';
import blog1_2 from '../../common/assets/images/blogs/blog1-2.svg';
import blog1_3 from '../../common/assets/images/blogs/blog1-3.svg';
import blog1_4 from '../../common/assets/images/blogs/blog1-4.svg';
import blog3_1 from '../../common/assets/images/blogs/blog3-1.svg';
import blog3_2 from '../../common/assets/images/blogs/blog3-2.svg';
import blog3_3 from '../../common/assets/images/blogs/blog3-3.svg';
import blog3_4 from '../../common/assets/images/blogs/blog3-4.svg';
import blog4_1 from '../../common/assets/images/blogs/blog4-1.svg';
import blog4_2 from '../../common/assets/images/blogs/blog4-2.svg';
import blog4_3 from '../../common/assets/images/blogs/blog4-3.svg';
import blog4_4 from '../../common/assets/images/blogs/blog4-4.svg';
import blog4_5 from '../../common/assets/images/blogs/blog4-5.svg';
import blog5_1 from '../../common/assets/images/blogs/blog5-1.svg';
import blog5_2 from '../../common/assets/images/blogs/blog5-2.svg';
import blog5_3 from '../../common/assets/images/blogs/blog5-3.svg';
import blog5_4 from '../../common/assets/images/blogs/blog5-4.svg';
import blog6_1 from '../../common/assets/images/blogs/blog6-1.svg';
import blog6_2 from '../../common/assets/images/blogs/blog6-2.svg';
import blog6_3 from '../../common/assets/images/blogs/blog6-3.svg';
import blog6_4 from '../../common/assets/images/blogs/blog6-4.svg';
import blog7_1 from '../../common/assets/images/blogs/blog7-1.svg';
import blog7_2 from '../../common/assets/images/blogs/blog7-2.svg';
import buynowpaylater1 from '../../common/assets/images/blogs/buynowpaylater1.webp';

import ProductDocument from 'landing/common/ProductDocument';

const imgs = [
	blog1_1,
	blog1_2,
	blog1_3,
	blog1_4,
	blog3_1,
	blog3_2,
	blog3_3,
	blog3_4,
	blog4_1,
	blog4_5,
	blog4_2,
	blog4_3,
	blog4_4,
	blog5_1,
	blog5_2,
	blog5_3,
	blog5_4,
	blog6_1,
	blog6_2,
	blog6_3,
	blog6_4,
	blog7_1,
	blog7_2,
	buynowpaylater1
];

const Blogs = () => {
	const [openModal, setOpenModal] = useState(false);
	const itemKey = useMemo(() => {
		return window.location.href.split('blogs/')[1];
	}, [window.location.href]);

	function replaceAllSpaces(str) {
		return str?.split(' ')?.join('-')?.toLowerCase();
	}

	const itemKeyIndex = useMemo(() => {
		return blogs.findIndex((x) => itemKey === replaceAllSpaces(x.header));
	}, [itemKey, blogs]);

	const getBaseURL = () => {
		const hostname = window.location.hostname;
		if (hostname.includes('localhost')) {
			return 'http://localhost:3000'; // Adjust the port if necessary
		} else {
			return 'https://www.vmlanalytics.com';
		}
	};
	const baseURL = getBaseURL();

	if (openModal) {
		return (
			<Header
				openModal={openModal}
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<meta
				name="viewport"
				content="width=device-width, initial-scale=1.0"
			></meta>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section
				style={{
					display: 'flex',
					alignItems: 'center',
					height: '195px',
					background: 'linear-gradient(to bottom, #e8eae9 -40%, #6b7e8e 82%)',
					width: '100%'
				}}
			>
				<div className="container cont">
					<h3 className="chapterHeading">Resources</h3>
				</div>
			</section>
			<div className="toast-container" id="toastContainer"></div>
			{
				<ProductDocument
					header={blogs[itemKeyIndex]?.header}
					description={blogs[itemKeyIndex]?.p}
					shortDescription={blogs[itemKeyIndex]?.shortDescription}
					shortTitle={blogs[itemKeyIndex]?.shortTitle}
				/>
			}
			<div className="mainContainer" style={{ marginTop: '-20px' }}>
				<section className="request_form 	career_details">
					<div className="container subContainer2">
						{!itemKey && (
							<div style={{ marginTop: '20px' }}>
								<p
									style={{
										fontSize: '26px',
										marginLeft: '13px',
										color: '#0d3756',
										marginBottom: '3rem'
									}}
								>
									<b>Financial Modeling Methodology</b>
								</p>
								<div style={{ display: 'flex' }}>
									<ul className="asset_list2" style={{ marginLeft: '-8px' }}>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/buy-now-pay-later">
												<p className={'blogs-no-bullet-p'}>
													Buy Now, Pay Later (BNPL)
												</p>
											</a>
										</li>
										{/*<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/CECL-&-IFRS9">
												<p>CECL & IFRS9</p>
											</a>
								</li>*/}
									</ul>
								</div>
							</div>
						)}
						{!itemKey && (
							<div style={{ marginTop: '20px' }}>
								<p
									style={{
										fontSize: '26px',
										marginLeft: '13px',
										color: '#0d3756',
										marginBottom: '3rem'
									}}
								>
									<b>Publications</b>
								</p>
								<div style={{ display: 'flex' }}>
									<ul className="asset_list2" style={{ marginLeft: '-8px' }}>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/machine-learning-applications-in-lending">
												<p className={'blogs-no-bullet-p'}>
													Machine Learning Applications in Lending
												</p>
											</a>
										</li>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/automated-machine-learning">
												<p className={'blogs-no-bullet-p'}>
													Automated Machine Learning
												</p>
											</a>
										</li>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/what-is-credit-risk-and-why-is-it-important?">
												<p className={'blogs-no-bullet-p'}>
													What is Credit Risk and Why is it Important?
												</p>
											</a>
										</li>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/financial-and-regulatory-reporting">
												<p className={'blogs-no-bullet-p'}>
													Financial and Regulatory Reporting
												</p>
											</a>
										</li>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/scorecard---credit-engine">
												<p className={'blogs-no-bullet-p'}>
													Scorecard - Credit Engine
												</p>
											</a>
										</li>
										<li className="no-bullet2">
											<a href="https://www.vmlanalytics.com/blogs/prepayment-analytics">
												<p className={'blogs-no-bullet-p'}>
													Prepayment Analytics
												</p>
											</a>
										</li>
									</ul>
								</div>
							</div>
						)}
						<div style={{ marginTop: itemKey ? '20px' : 0 }}>
							<div className="col">
								{!itemKey ? (
									blogs.map((item, i) => (
										<PagesSubHeader
											key={i}
											style={{ marginBottom: 30, cursor: 'pointer' }}
											header={item.header}
											description={item.p}
											onClick={() =>
												window.open(
													`/blogs/${replaceAllSpaces(item.header)}`,
													'_self'
												)
											}
										/>
									))
								) : (
									<PagesSubHeader
										style={{ marginBottom: 30 }}
										header={blogs[itemKeyIndex].header}
										description={blogs[itemKeyIndex].p}
									/>
								)}
								{itemKey && (
									<BlogContent
										imgs={imgs}
										style={{}}
										data={blogsDetails[itemKeyIndex + 1]}
									/>
								)}
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Blogs;
