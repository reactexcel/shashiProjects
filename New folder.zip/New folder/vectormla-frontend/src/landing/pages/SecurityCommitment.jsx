import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderRectangle from '../common/HeaderRectangle';

const SecurityCommitment = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Security Commitment</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<div className="subContainer2 container">
					<HeaderRectangle
						header="Security Commitment"
						description="At Vector ML Analytics, we take website security seriously. We understand that trust is essential to our relationship with our customers and visitors, and we are committed to protecting the privacy and security of all the information that is exchanged through our website."
						p2="To that end, we commit to the following:"
						p3="1. We will keep our website secure: We will implement appropriate technical and organizational measures to protect against unauthorized access, alteration, disclosure, or destruction of the information you entrust to us."
						p4="2. We will protect your personal information: We will handle your personal information with the utmost care and respect for your privacy. We will not sell, rent, or disclose your personal information to third parties unless required by law or necessary to provide our services to you."
						p5="3. We will keep our systems up-to-date: We will regularly review and update our security protocols and technologies to ensure that we are using the latest and most effective methods to protect against security threats."
						p6="4. We will be transparent about our security practices: We will provide clear and understandable information about our security practices, so you know how your information is being protected."
						p7="5. We will respond promptly to security incidents: In the event of a security incident, we will promptly investigate and take appropriate measures to mitigate the impact of the incident and prevent future occurrences."
						p8="We understand that website security is an ongoing process, and we are committed to continuously improving our practices and staying up-to-date with the latest developments in the field.
						If you have any questions or concerns about our website security practices, please do not hesitate to contact us."
					/>
				</div>
			</div>
			<MainFooter />
		</>
	);
};

export default SecurityCommitment;
