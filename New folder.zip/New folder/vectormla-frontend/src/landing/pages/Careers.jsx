import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderWithBlueLeft from '../common/HeaderWithPlusNBlueLeft';
import PagesSubHeader from '../common/PagesSubHeader';
import CareerBlock from '../common/CareerBlock';

const Careers = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Careers</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>
			<div className="mainContainer">
				<div className="container subContainer2">
					<PagesSubHeader
						style={{ marginBottom: 30 }}
						header="Make an impact that matters"
						description={`The world is changing at an accelerating speed and\nbecoming more complex. This is your opportunity \nto explore a future with a professional fintech organization \nthat leads with purpose by solving complex issues for\nour clients and communities.`}
					/>
					<div className="breakline_sm" />
					<section className="careers_card_container">
						<div className="row">
							<div className="col-sm-12 col-lg-3">
								<div className="card">
									<div>
										<h2>Professionals</h2>
										<h5>
											{
												"As we redefine the future of banking and lending analytics, you’ll challenge the views placed before you by creating your path. Our support and training will equip you to make a growing contribution to projects that will reshape the industry's future."
											}
										</h5>
									</div>
								</div>
							</div>
							<div className="col-sm-12 col-lg-3">
								<div className="card">
									<div>
										<h2>Students & Interns</h2>
										<h5>
											We offer a wide range of career opportunities to help you
											think bigger and create more innovative solutions. You’ll
											find an overview of our internship roles below, so use our
											internship opportunities section to find the best and most
											suitable role for you.
										</h5>
									</div>
								</div>
							</div>
							<div className="col-sm-12 col-lg-3">
								<div className="card">
									<div>
										<h2>Finance</h2>
										<h5>
											Work on structured finance and fixed income models with
											engineered solutions to problems in capital markets. Apply
											valuation, pricing, and reporting methods to help
											management make critical financial decisions.
										</h5>
									</div>
								</div>
							</div>
							<div className="col-sm-12 col-lg-3">
								<div className="card">
									<div>
										<h2>Technology</h2>
										<h5>
											Join one of our three engineering divisions. Data Science:
											build, predict, forecast, and optimize data for the credit
											and prepayment decision and forecasting engines. Data
											Engineering: develop and maintain systems that allow data
											scientists to access and interpret data. Full Stack Web
											Development: build, create, and maintain our cloud-based
											web analytical platform.
										</h5>
									</div>
								</div>
							</div>
						</div>
					</section>
				</div>
				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<HeaderWithBlueLeft
									header="Full-time opportunities"
									description="At Vector ML Analytics, we offer a wide range of career opportunities to help you think bigger and learn to create more innovative solutions. You'll find an overview of all our full-time roles below, so choose the job role that suits you the best. Then, click to find out more."
								/>
							</div>
						</div>
						<div className="row careers" style={{ marginTop: 40 }}>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Lead Solution Architect"
									item="0"
								/>
							</div>

							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Full Stack Developer"
									item={1}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Frontend Web Developer"
									item={2}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Backend Developer"
									item={3}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="UI/UX Designer"
									item={4}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Scrum Master"
									item={5}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Data Science"
									subHeader="Data Scientist"
									item={6}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Data Science"
									subHeader="Senior Data Scientist"
									item={7}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Data Science"
									subHeader="VP Data Science"
									item={8}
								/>
							</div>
						</div>
					</div>
				</section>
				<section className="request_form">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<HeaderWithBlueLeft
									header="Internship Opportunities"
									description="To get a sense of what it’s like to work here, experience it for yourself. Our internships will immerse you in our work, culture, and business. You’ll learn from our people while working on live projects and real business challenges. You may also take a step towards securing a full-time opportunity with us."
								/>
								<div className="breakline_sm" />
							</div>

							<p style={{ padding: '40px', color: '#6E6F72' }}>
								We offer a wide range of career opportunities to help you think
								bigger and create more innovative solutions. You’ll find an
								overview of our internship roles below, so use the below section
								to find the roles that suit you best.
							</p>
						</div>

						<div className="row careers" style={{ marginTop: 40 }}>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Frontend Web Developer"
									item={9}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="Backend Developer"
									item={10}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Web Development"
									subHeader="UI/UX Designer"
									item={11}
								/>
							</div>
							<div className="col-sm-6 col-lg-3">
								<CareerBlock
									header="Data Science"
									subHeader="Data Scientist"
									item={12}
								/>
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Careers;
