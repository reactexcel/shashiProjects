import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import feras from '../../common/assets/images/Feras31.webp';
import phillip from '../../common/assets/images/Phillip32.webp';
import sadeq from '../../common/assets/images/Sadeq31.webp';
import thomas from '../../common/assets/images/Thomas31.webp';
import krishna from '../../common/assets/images/Krishna31.webp';
import brian from '../../common/assets/images/Brian32.webp';
import surendiran from '../../common/assets/images/surendiran01.jpg';
import siddharth from '../../common/assets/images/Siddharth31.webp';
import alano from '../../common/assets/images/Alano31.webp';
import kevin from '../../common/assets/images/Kevin31.webp';
import brandon from '../../common/assets/images/Brandon32.webp';
import aljan from '../../common/assets/images/Aljan31.webp';
import jade from '../../common/assets/images/Jade31.webp';
import eric from '../../common/assets/images/Eric31.webp';
import ali from '../../common/assets/images/Ali32.webp';
import mark from '../../common/assets/images/Mark31.webp';

import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import { Grid } from '@material-ui/core';
const Team = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}

	let SeniorManagement = [
		// {
		// 	name: 'Sadeq Safarini',
		// 	image: sadeq,
		// 	url: 'https://www.linkedin.com/in/sadeq-safarini-msc-fin-fmva-87a17b37/',
		// 	title: 'CEO & Founder',
		// 	sub_title: 'CEO'
		// },
		{
			name: 'Kevin McCarville',
			image: kevin,
			url: 'https://www.linkedin.com/in/kevin-mccarville-cfa-0494002b/',
			title: 'CFA, Co-Founder',
			sub_title: 'CFA, Co-Founder'
		},
		{
			name: 'Mark Vrdoljak',
			image: mark,
			url: 'https://www.linkedin.com/in/mark-vrdoljak-b710104a/',
			sub_title: 'VP of Financial Modelling'
		},
		{
			name: 'Phillip Morgia',
			image: phillip,
			url: 'https://www.linkedin.com/in/phillipmorgia/',
			sub_title: 'CTO'
		},
		{
			name: 'Brandon Center',
			image: brandon,
			url: 'https://www.linkedin.com/in/brandon-center-ctp-47a16b6b/',
			sub_title: 'CMO'
		},
		{
			name: '',
			image: '',
			url: '',
			title: '',
			sub_title: ''
		}
	];

	let advisoryBoard = [
		{
			name: 'Thomas Kuehn',
			image: thomas,
			url: 'https://www.linkedin.com/in/thomas-kuehn-9106b064/',
			title: 'Board of Advisory',
			sub_title: 'Analytics Expert'
		},
		{
			name: 'Krishna Gadhraju',
			image: krishna,
			url: 'https://www.linkedin.com/in/krishna-gadhraju-cfa-441081108/',
			title: 'Board of Advisory',
			sub_title: 'Analytics Expert'
		},
		{
			name: 'Eric Ries',
			image: eric,
			url: 'https://www.linkedin.com/in/eries/',
			sub_title: 'Executive Chairman, LTSE'
		},
		{
			name: 'Siddharth Kakkar',
			image: siddharth,
			url: 'https://www.linkedin.com/in/sid-kakkar/',
			title: 'Board of Advisory',
			sub_title: 'Senior Advisor'
		},
		{
			name: 'Brian Mauck',
			image: brian,
			url: 'https://www.linkedin.com/in/brianmmauck/',
			title: 'Board of Advisory',
			sub_title: 'Business Strategist'
		}
	];
	let operations = [
		// {
		// 	name: 'Surendiran Velu',
		// 	image: surendiran,
		// 	url: 'https://www.linkedin.com/in/surendiran/',
		// 	title: 'Board of Advisory',
		// 	sub_title: 'Business Strategist'
		// },
		{
			name: 'Aljan Balbuena',
			image: aljan,
			url: 'https://www.linkedin.com/in/aljanbalbuena/',
			sub_title: 'Senior Software Engineer'
		},
		{
			name: 'Feras Khalil',
			image: feras,
			url: 'https://www.linkedin.com/in/feras-khalil/',
			sub_title: 'Senior Software Engineer'
		},
		{
			name: 'Ali Saffarini',
			image: ali,
			url: 'https://www.linkedin.com/in/ali-saffarini-095580293/',
			sub_title: 'AI Engineer'
		},
		{
			name: 'Jade Clarke',
			image: jade,
			url: 'https://www.linkedin.com/in/jade-c-077890170/',
			sub_title: 'Head of Operations'
		},
		{
			name: 'Alano Smit',
			image: alano,
			url: 'https://www.linkedin.com/in/alano-smit',
			sub_title: 'Business Developer'
		}
	];
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section
				style={{
					display: 'flex',
					alignItems: 'center',
					height: '195px',
					background: 'linear-gradient(to bottom, #e8eae9 -40%, #6b7e8e 82%)',
					width: '100%'
				}}
			>
				<div className="container cont">
					<h3 className="chapterHeading">Team</h3>
				</div>
			</section>
			<div className="mainContainer2">
				<div
					style={{
						display: 'flex',
						justifyContent: 'center',
						marginBottom: '1rem'
					}}
				>
					<div className="subContainer3 teamsContainer" style={{ padding: 0 }}>
						<div>
							<div className="team-separator-5">
								<p>Senior Management</p>
							</div>
							<Grid
								container
								spacing={0}
								style={{ display: 'flex', justifyContent: 'center' }}
							>
								<div
									className="team_listing"
									style={{
										paddingBottom: '10rem', // Using relative units
										paddingTop: '10rem', // Using relative units
										display: 'flex',
										justifyContent: 'flex-start',
										gap: '2rem' // Using relative units
									}}
								>
									{SeniorManagement.map((it, index) => (
										<Grid item xs={6} sm={4} md={3} lg={2} key={index}>
											<div
												className="team_card"
												style={{
													width: '100%',
													position: 'relative',
													cursor: it.url === '' ? 'classic' : 'pointer'
												}}
												onClick={() => {
													it.url === '' ? '' : window.open(it.url, '_blank');
												}}
											>
												<Card
													style={{
														backgroundColor:
															it.name === ''
																? ''
																: it.name === ''
																? 'transparent'
																: '#e0e0e0',
														height: 330,
														width: '110%',
														boxShadow: 'none',
														maxWidth: '230px'
													}}
												>
													<CardMedia
														image={it.image === '' ? '' : it.image}
														component={'img'}
														style={{
															height: 'auto',
															width: it.image ? '100%' : 240,
															backgroundColor: 'transparent'
														}}
													/>
													<CardHeader
														title={
															<span
																style={{
																	fontSize: '15px',
																	fontWeight: 'bold',
																	textTransform: 'uppercase'
																}}
															>
																{it.name}
															</span>
														}
														subheader={it.sub_title}
														className="smaller-text"
														style={{
															textAlign: 'left',
															color: '#36383a',
															fontWeight: 'bold'
														}}
													/>
													<CardContent style={{ textAlign: 'left' }}>
														{/* Additional content here if needed */}
													</CardContent>
												</Card>
											</div>
										</Grid>
									))}
								</div>
							</Grid>
						</div>
						<div>
							<div className="team-separator-6">
								<p>Board of Advisory</p>
							</div>
							<Grid
								container
								spacing={0}
								style={{ display: 'flex', justifyContent: 'center' }}
							>
								<div
									className="team_listing"
									style={{
										paddingBottom: '10rem', // Using relative units
										paddingTop: '10rem', // Using relative units
										display: 'flex',
										justifyContent: 'flex-start',
										gap: '2rem' // Using relative units
									}}
								>
									{advisoryBoard.map((it, index) => (
										<Grid item xs={6} sm={4} md={3} lg={2} key={index}>
											<div
												className="team_card"
												style={{
													width: '100%',
													position: 'relative',
													cursor: it.url === '' ? 'classic' : 'pointer'
												}}
												onClick={() => {
													it.url === '' ? '' : window.open(it.url, '_blank');
												}}
											>
												<Card
													style={{
														backgroundColor: it.name === '' ? '' : '#e0e0e0',
														height: 330,
														width: '110%',
														boxShadow: 'none',
														maxWidth: '230px'
													}}
												>
													<CardMedia
														image={it.image}
														component={'img'}
														style={{
															height: 'auto',
															width: '100%'
														}}
													/>
													<CardHeader
														title={
															<span
																style={{
																	fontSize: '15px',
																	fontWeight: 'bold',
																	textTransform: 'uppercase'
																}}
															>
																{it.name}
															</span>
														}
														subheader={it.sub_title}
														className="smaller-text"
														style={{
															textAlign: 'left',
															color: '#36383a',
															fontWeight: 'bold'
														}}
													/>
													<CardContent style={{ textAlign: 'left' }}>
														{/* Additional content here if needed */}
													</CardContent>
												</Card>
											</div>
										</Grid>
									))}
								</div>
							</Grid>
						</div>
						<div>
							<div className="team-separator-6">
								<p>Operations</p>
							</div>
							<Grid
								container
								spacing={0}
								style={{ display: 'flex', justifyContent: 'center' }}
							>
								<div
									className="team_listing"
									style={{
										paddingBottom: '10rem', // Using relative units
										paddingTop: '10rem', // Using relative units
										display: 'flex',
										justifyContent: 'flex-start',
										gap: '2rem' // Using relative units
									}}
								>
									{operations.map((it, index) => (
										<Grid item xs={6} sm={4} md={3} lg={2} key={index}>
											<div
												className="team_card"
												style={{
													width: '100%',
													position: 'relative',
													cursor: it.url === '' ? 'classic' : 'pointer'
												}}
												onClick={() => {
													it.url === '' ? '' : window.open(it.url, '_blank');
												}}
											>
												<Card
													style={{
														backgroundColor: it.name === '' ? '' : '#e0e0e0',
														height: 330,
														width: '110%',
														boxShadow: 'none',
														maxWidth: '230px'
													}}
												>
													<CardMedia
														image={it.image}
														component={'img'}
														style={{
															height: 'auto',
															width: '100%'
														}}
													/>
													<CardHeader
														title={
															<span
																style={{
																	fontSize: '15px',
																	fontWeight: 'bold',
																	textTransform: 'uppercase'
																}}
															>
																{it.name}
															</span>
														}
														subheader={it.sub_title}
														className="smaller-text"
														style={{
															textAlign: 'left',
															color: '#36383a',
															fontWeight: 'bold'
														}}
													/>
													<CardContent style={{ textAlign: 'left' }}>
														{/* Additional content here if needed */}
													</CardContent>
												</Card>
											</div>
										</Grid>
									))}
								</div>
							</Grid>
						</div>
					</div>
				</div>
			</div>
			<MainFooter />
		</>
	);
};

export default Team;
