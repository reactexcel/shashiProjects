import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderWithBlueLeft from '../common/HeaderWithPlusNBlueLeft';
import DescriptionArrow from '../common/DescriptionArrow';
import platformFeatures from '../data/platformFeatures';
import solutionsFeaturesFpna from '../data/solutionsFeaturesFpna';
import solutionsFeaturesAlm from '../data/solutionsFeaturesAlm';
import solutionsFeaturesCreditRisk from '../data/solutionsFeaturesCreditRisk';
import solutionsFeaturesCapitalMarkets from '../data/solutionsFeaturesCapitalMarkets';
import arrow_right_blue from '../../common/assets/images/arrow_right_blue.svg';
import soltuionsloanpricing from '../../common/assets/images/solutionsLoanPricing.webp';
import solutions234 from '../../common/assets/images/solutions234.png';
import solutionsFSR from '../../common/assets/images/solutionsFSR.webp';
import FinancialSPSolutions from '../../common/assets/images/FinancialSPSolutions.png';
import capitalRequirementsSolutions from '../../common/assets/images/capitalRequirementsSolutions.png';
import SolutionsCashflowForecasting from '../../common/assets/images/SolutionsCashflowForecasting.webp';
import liquidityPlanningSolutions from '../../common/assets/images/liquidityPlanningSolutions.png';
import delinquencySolutions from '../../common/assets/images/delinquencySolutions.png';
import delinquencySolutions2 from '../../common/assets/images/delinquencySolutions2.png';
import vintageAnalysisSolutions from '../../common/assets/images/vintageAnalysisSolutions.png';
import prepaymentSolutions from '../../common/assets/images/prepaymentSolutions.png';
import almSolutions2 from '../../common/assets/images/almSolutions2.png';
import niiSolutions from '../../common/assets/images/niiSolutions.png';
import eveSolutions2 from '../../common/assets/images/eveSolutions2.png';
import eveSolutions from '../../common/assets/images/eveSolutions.png';
import almSolutions from '../../common/assets/images/almSolutions.png';
import profitabilitySolutions from '../../common/assets/images/profitabilitySolutions.png';
import solutionsLoanandLending from '../../common/assets/images/solutionsLoanandLending.webp';
import solutionsAssetLiability from '../../common/assets/images/solutionsAssetLiability.webp';
import PagesSubHeader from '../common/PagesSubHeader';
import ProductDocument from 'landing/common/ProductDocument';
import { template } from 'lodash';
import { Item } from 'devextreme-react/accordion';
const Solutions = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}

	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section
				style={{
					display: 'flex',
					alignItems: 'center',
					height: '195px',
					background: 'linear-gradient(to bottom, #e8eae9 -40%, #6b7e8e 82%)',
					width: '100%'
				}}
			>
				<div className="container cont">
					<h3 className="chapterHeading">Solutions</h3>
				</div>
			</section>
			<ProductDocument />
			<div className="mainContainer" style={{ marginTop: '-10px' }}>
				<section className="platform" style={{ marginBottom: 50 }}>
					<div
						className="container subContainer2"
						style={{ marginTop: '-30px' }}
					>
						<div className="list">
							{solutionsFeaturesFpna.map((content, i) => (
								<div className="row list_block" style={{ margin: 0 }} key={i}>
									<div className="container" style={{ padding: 0 }}>
										<div className="list_box">
											<div
												className={
													i === 0
														? 'list_content_first row'
														: 'list_content row'
												}
											>
												<h4
													style={{
														paddingLeft: 7,
														marginTop: -50,
														fontSize: '32px'
													}}
												>
													{content.header}
												</h4>
												{i === 0 && (
													<PagesSubHeader
														key={'i'}
														style={{
															marginBottom: 30,
															marginRight: 25,
															marginLeft: 9,
															marginTop: -40
														}}
														header={'Financial Planning and Analysis (FP&A)'}
														description={
															'Vector is an advanced FP&A tool designed to empower lending institutions by instantly generating 5-year projected balance sheets and income statements. This capability enhances decision-making related to profitability, capital, liquidity, and regulatory compliance, and helps set management goals for ROA, ROE, and leverage. Vector creates precise cash flow projections with loan-level amortization tables by asset class, based on user-defined stress scenarios. This ensures that interest income, fees, liquidity, and capital needs are accurately modeled alongside operational expenses and liabilities. The software formulates assumptions for loan prepayment and default using vintage curves, economic variables, and dynamic modeling assumptions. Additionally, Vector efficiently models loan portfolio growth and funding by proactively monitoring deposit maturity and cash flow mismatches. Overall, Vector ensures robust financial planning and analysis, driving better outcomes and strategic success.'
														}
														solutions={'solutions'}
													/>
												)}
											</div>

											<div className="col-lg-12 asset_list_container cont">
												<ul className="asset_list" style={{ marginLeft: -23 }}>
													{content?.description?.map((details, j) => (
														<li
															key={j}
															style={{
																listStyleType: 'none',
																paddingBottom: 20
															}}
														>
															<p style={{ listStyleType: 'none' }}>
																<span
																	style={{
																		listStyleType: 'none',
																		fontSize: '20px',
																		textAlign: 'justify'
																	}}
																	className={`solutionsDetailSpan ${
																		details.length > 60
																			? 'moreThan1LineDetailSpan'
																			: ''
																	}`}
																>
																	{details}
																</span>
															</p>
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Banks
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 1 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Cash Flow Projections: Vector enables
																				banks to accurately predict future cash
																				inflows and outflows, including detailed
																				loan-level amortization schedules.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Regulatory Compliance: Ensuring
																				adherence to ILAAP, LCR, and NSFR
																				requirements to maintain adequate
																				liquidity buffers.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stress Testing: Incorporating stress
																				testing to assess the bank’s resilience
																				under adverse conditions and ensure
																				comprehensive risk management.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Liquidity Planning: Maintaining adequate
																				reserves of high-quality liquid assets
																				(HQLA) to handle unexpected cash
																				outflows, such as large withdrawals or
																				market disruptions.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base Advance Rates:
																				Incorporating borrowing base advance
																				rates and reserve requirements to
																				support lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Excess Concentration and Eligibility
																				Criteria: Managing risks associated with
																				excess concentration and ensuring
																				adherence to eligibility criteria.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Support: Providing cash flow
																				forecasts that include the necessary
																				cash to support operations and capital
																				to maintain the advance rate on the
																				borrowing base.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stress Testing: Including stress testing
																				to evaluate the institution’s ability to
																				withstand financial challenges and
																				optimize their capital structure.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Behavioral Cash Flows: Converting
																				contractual cash flows into behavioral
																				cash flows by modeling prepayment,
																				delinquency, and default behaviors, as
																				well as loan recovery timing.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Banks
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Dynamic Pricing Model
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 1 ? (
																<img
																	src={profitabilitySolutions}
																	style={{
																		width: '50%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 4 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Risk-Based Pricing
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Continuous Monitoring
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Key reports include:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 1 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Regulatory Capital: Includes Common
																				Equity Tier 1 (CET1), Additional Tier 1
																				(AT1), and Tier 2 capital. These capital
																				buffers help absorb losses during
																				economic downturns.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Risk-Weighted Assets (RWA): Assets are
																				weighted by risk to determine the
																				minimum capital requirements, ensuring
																				banks hold sufficient capital relative
																				to their risk exposure.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Leverage Ratios: Non-risk-based ratios
																				that limit the amount of leverage a bank
																				can take on, providing an additional
																				layer of protection.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 2 ? (
																<img
																	src={capitalRequirementsSolutions}
																	style={{
																		width: '60%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Non-Bank Lending Institutions
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base: Capital is needed to
																				support the advance rates on the
																				borrowing base, ensuring sufficient
																				liquidity to fund lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Losses: Adequate capital
																				reserves help cover unexpected
																				operational losses, maintaining the
																				institution&apos;s stability.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Ineligible Loans and Excess
																				Concentration: Capital must be allocated
																				to manage risks associated with
																				ineligible loans and excessive exposure
																				to specific sectors or borrowers.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Delinquent Accounts: Institutions need
																				capital to cover the risk of delinquent
																				accounts, ensuring they can continue to
																				operate smoothly without relying on
																				external funding.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 5 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Risk Management: Predict and mitigate
																				interest rate risks.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Loan Pricing: Price loans accurately
																				based on prepayment risks.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Profitability: Forecast cash flows and
																				assess loan profitability.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Compliance: Ensure regulatory adherence
																				for risk management.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 6 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>Capital Adequacy Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Liquidity Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Interest Rate Risk Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Asset Liability Management (ALM)
																				Reporting
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Financial Planning and Analysis (FP&A)
																				Reporting
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Credit Risk Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive Capital Analysis and
																				Review (CCAR)
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Other Regulatory Filings</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 1 && j === 1 ? (
																<img
																	src={FinancialSPSolutions}
																	style={{
																		width: '55%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '20px'
																	}}
																/>
															) : (
																''
															)}
															{i === 2 && j === 2 ? (
																<img
																	src={liquidityPlanningSolutions}
																	style={{
																		width: '70%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 5 && j === 1 ? (
																<img
																	src={prepaymentSolutions}
																	style={{
																		width: '70%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 2 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Non-Bank Lending Institutions
																	</h5>
																</div>
															) : null}
															{/* Liquidity Planning code image i === 3 && j === 5 ? (
																<img
																	src={solutionsAssetLiability}
																	style={{
																		width: '55%',
																		height: '100%',
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '50px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 5 ? (
																<img
																	src={''}
																	style={{
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '70px',
																		marginBottom: '-60px',
																		width: '55%'
																	}}
																/>
															) : (
																''
															)}
														</li>
													))}
												</ul>
												<div style={{ marginBottom: '18px' }}></div>
											</div>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				</section>
				<section className="platform" style={{ marginBottom: 50 }}>
					<div
						className="container subContainer2"
						style={{ marginTop: '-30px' }}
					>
						<div className="list">
							{solutionsFeaturesAlm.map((content, i) => (
								<div className="row list_block" style={{ margin: 0 }} key={i}>
									<div className="container" style={{ padding: 0 }}>
										<div className="list_box">
											<div
												className={
													i === 0
														? 'list_content_first row'
														: 'list_content row'
												}
											>
												<h4
													style={{
														paddingLeft: 7,
														marginTop: -50,
														fontSize: '32px'
													}}
												>
													{content.header}
												</h4>
												{i === 0 && (
													<PagesSubHeader
														key={'i'}
														style={{
															marginBottom: 30,
															marginRight: 25,
															marginLeft: 9,
															marginTop: -40
														}}
														header={'Asset Liability Management (ALM)'}
														description={
															'Vector ML Analytics produces comprehensive ALCO reports, integrating critical financial metrics such as Net Interest Income (NII), Economic Value of Equity (EVE), Duration, Earnings at Risk (EAR), and analyses for rate shocks with both parallel and non-parallel shifts. The software conducts thorough Interest Gap Analysis and calculates and interprets the Hedge Ratio. Designed for precision and ease of use, Vector ML Analytics provides institutions with the tools to identify, assess, and mitigate financial risks effectively. It enables detailed examination of balance sheets, optimizes hedging strategies, and ensures compliance with regulatory requirements.'
														}
														solutions={'solutions'}
													/>
												)}
											</div>

											<div className="col-lg-12 asset_list_container cont">
												<ul className="asset_list" style={{ marginLeft: -23 }}>
													{content?.description?.map((details, j) => (
														<li
															key={j}
															style={{
																listStyleType: 'none',
																paddingBottom: 20
															}}
														>
															<p style={{ listStyleType: 'none' }}>
																<span
																	style={{
																		listStyleType: 'none',
																		fontSize: '20px',
																		textAlign: 'justify'
																	}}
																	className={`solutionsDetailSpan ${
																		details.length > 60
																			? 'moreThan1LineDetailSpan'
																			: ''
																	}`}
																>
																	{details}
																</span>
															</p>
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Segmentation by Origination Period:
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Earnings at Risk (EaR):
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base Advance Rates:
																				Incorporating borrowing base advance
																				rates and reserve requirements to
																				support lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Excess Concentration and Eligibility
																				Criteria: Managing risks associated with
																				excess concentration and ensuring
																				adherence to eligibility criteria.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Support: Providing cash flow
																				forecasts that include the necessary
																				cash to support operations and capital
																				to maintain the advance rate on the
																				borrowing base.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stress Testing: Including stress testing
																				to evaluate the institution’s ability to
																				withstand financial challenges and
																				optimize their capital structure.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Behavioral Cash Flows: Converting
																				contractual cash flows into behavioral
																				cash flows by modeling prepayment,
																				delinquency, and default behaviors, as
																				well as loan recovery timing.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Long-Term Impact Assessment:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 1 ? (
																<img
																	src={eveSolutions}
																	style={{
																		width: '90%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Scenario Analysis:
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Scenario Simulation and Comprehensive Risk
																		View:
																	</h5>
																</div>
															) : null}
															{/*i === 4 && j === 1 ? (
																<img
																	src={profitabilitySolutions}
																	style={{
																		width: '50%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Regulatory Compliance, Risk Management, and
																		Strategic Decision Making:
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Types of Interest Rate Risk
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Repricing Risk: Arises from differences
																				in the timing of interest rate changes
																				for assets and liabilities. It affects
																				Net Interest Income (NII) as interest
																				rates reset at different times.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Yield Curve Risk: Occurs when changes in
																				interest rates affect different
																				maturities differently, causing
																				non-parallel shifts in the yield curve.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Basis Risk: Results from imperfect
																				correlation between different interest
																				rate indices used to price assets and
																				liabilities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Optionality Risk: Stems from embedded
																				options in financial instruments, such
																				as loan prepayments or deposit
																				withdrawals, which can be exercised when
																				interest rates change.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 1 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Measurement Systems for Interest Rate Risk
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 2 ? (
																<img
																	src={eveSolutions2}
																	style={{
																		width: '60%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 1 && j === 1 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Net Interest Income (NII) and Earnings
																				at Risk (EaR): NII represents the
																				difference between interest earned on
																				assets and interest paid on liabilities.
																				EaR quantifies the potential impact of
																				interest rate changes on NII over a
																				specific future period, typically 12 or
																				24 months. Vector ML Analytics enables
																				detailed NII simulations under various
																				interest rate scenarios, helping banks
																				evaluate short-term and long-term
																				interest rate risk and adjust their
																				strategies accordingly.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Economic Value of Equity (EVE): Measures
																				the change in the net present value of a
																				bank&apos;s assets and liabilities due
																				to interest rate movements. EVE provides
																				a long-term view of interest rate risk,
																				highlighting potential changes in the
																				economic value of the bank&apos;s
																				equity.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Interest Rate Gap Analysis: Involves
																				comparing the timing of asset and
																				liability cash flows to identify periods
																				of mismatch. This analysis helps in
																				understanding the bank&apos;s exposure
																				to interest rate changes over different
																				time horizons.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 1 && j === 1 ? (
																<img
																	src={almSolutions2}
																	style={{
																		width: '100%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '40px'
																	}}
																/>
															) : (
																''
															)}
															{i === 1 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Rate Shock Analysis
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base: Capital is needed to
																				support the advance rates on the
																				borrowing base, ensuring sufficient
																				liquidity to fund lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Losses: Adequate capital
																				reserves help cover unexpected
																				operational losses, maintaining the
																				institution&apos;s stability.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Ineligible Loans and Excess
																				Concentration: Capital must be allocated
																				to manage risks associated with
																				ineligible loans and excessive exposure
																				to specific sectors or borrowers.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Delinquent Accounts: Institutions need
																				capital to cover the risk of delinquent
																				accounts, ensuring they can continue to
																				operate smoothly without relying on
																				external funding.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 5 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Risk Management: Predict and mitigate
																				interest rate risks.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Loan Pricing: Price loans accurately
																				based on prepayment risks.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Profitability: Forecast cash flows and
																				assess loan profitability.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Compliance: Ensure regulatory adherence
																				for risk management.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 6 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>Capital Adequacy Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Liquidity Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Interest Rate Risk Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Asset Liability Management (ALM)
																				Reporting
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Financial Planning and Analysis (FP&A)
																				Reporting
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Credit Risk Reporting</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive Capital Analysis and
																				Review (CCAR)
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Other Regulatory Filings</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 2 ? (
																<img
																	src={niiSolutions}
																	style={{
																		width: '75%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 5 && j === 1 ? (
																<img
																	src={prepaymentSolutions}
																	style={{
																		width: '70%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{/* Liquidity Planning code image i === 3 && j === 5 ? (
																<img
																	src={solutionsAssetLiability}
																	style={{
																		width: '55%',
																		height: '100%',
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '50px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 5 ? (
																<img
																	src={''}
																	style={{
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '70px',
																		marginBottom: '-60px',
																		width: '55%'
																	}}
																/>
															) : (
																''
															)}
														</li>
													))}
												</ul>
												<div style={{ marginBottom: '18px' }}></div>
											</div>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				</section>
				<section className="platform" style={{ marginBottom: 50 }}>
					<div
						className="container subContainer2"
						style={{ marginTop: '-30px' }}
					>
						<div className="list">
							{solutionsFeaturesCreditRisk.map((content, i) => (
								<div className="row list_block" style={{ margin: 0 }} key={i}>
									<div className="container" style={{ padding: 0 }}>
										<div className="list_box">
											<div
												className={
													i === 0
														? 'list_content_first row'
														: 'list_content row'
												}
											>
												<h4
													style={{
														paddingLeft: 7,
														marginTop: -50,
														fontSize: '32px'
													}}
												>
													{content.header}
												</h4>
												{i === 0 && (
													<PagesSubHeader
														key={'i'}
														style={{
															marginBottom: 30,
															marginRight: 25,
															marginLeft: 9,
															marginTop: -40
														}}
														header={'Credit Risk'}
														description={`Credit risk, the risk of borrower default, can impact a bank's financial health. Effective management is crucial. Vector ML Analytics provides tools to assess and manage credit risk, helping banks mitigate losses and make informed lending decisions. Compliance with CECL and IFRS 9 standards is essential, requiring banks to estimate expected credit losses. Vector ML Analytics offers robust solutions to model and report these losses, ensuring regulatory compliance and investor confidence. With advanced analytics, it enables detailed financial projections for loan portfolios, supporting data-driven decisions and optimized credit risk strategies.`}
														solutions={'solutions'}
													/>
												)}
											</div>
											<div className="col-lg-12 asset_list_container cont">
												<ul className="asset_list" style={{ marginLeft: -23 }}>
													{content?.description?.map((details, j) => (
														<li
															key={j}
															style={{
																listStyleType: 'none',
																paddingBottom: 20
															}}
														>
															<p style={{ listStyleType: 'none' }}>
																<span
																	style={{
																		listStyleType: 'none',
																		fontSize: '20px',
																		textAlign: 'justify'
																	}}
																	className={`solutionsDetailSpan ${
																		details.length > 60
																			? 'moreThan1LineDetailSpan'
																			: ''
																	}`}
																>
																	{details}
																</span>
															</p>
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Segmentation by Origination Period:
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		CECL
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Loans are grouped into vintages based on
																				the time period they were originated,
																				such as quarterly or yearly cohorts.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				This segmentation allows banks to
																				compare the performance of different
																				cohorts and identify specific periods
																				where loan performance may have been
																				better or worse.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<img
																	src={vintageAnalysisSolutions}
																	style={{
																		width: '65%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Performance Tracking:
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Vector ML Analytics tracks key
																				performance indicators (KPIs) for each
																				vintage, such as default rates,
																				delinquency rates, and prepayment rates.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Vintage analysis highlights trends and
																				patterns in loan performance, showing
																				how credit risk evolves across different
																				cohorts.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				This comparison can reveal insights into
																				the effectiveness of underwriting
																				standards, credit policies, and market
																				conditions at the time of origination.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Earnings at Risk (EaR):
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base Advance Rates:
																				Incorporating borrowing base advance
																				rates and reserve requirements to
																				support lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Excess Concentration and Eligibility
																				Criteria: Managing risks associated with
																				excess concentration and ensuring
																				adherence to eligibility criteria.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Support: Providing cash flow
																				forecasts that include the necessary
																				cash to support operations and capital
																				to maintain the advance rate on the
																				borrowing base.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stress Testing: Including stress testing
																				to evaluate the institution’s ability to
																				withstand financial challenges and
																				optimize their capital structure.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Behavioral Cash Flows: Converting
																				contractual cash flows into behavioral
																				cash flows by modeling prepayment,
																				delinquency, and default behaviors, as
																				well as loan recovery timing.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Delinquency Migration Analysis:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Tracking Loan Movements: Vector ML
																				Analytics examines the movement of loans
																				as they transition from one delinquency
																				stage to another, such as moving from
																				current to 30 days past due, 60 days
																				past due, and so on.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Identifying Patterns: By tracking these
																				transitions, banks can identify patterns
																				and trends in delinquency behavior, such
																				as periods of increased delinquency or
																				improvements in loan performance.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<img
																	src={delinquencySolutions2}
																	style={{
																		width: '75%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Roll Rate Matrices:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Forward Transitions: Roll rate matrices
																				show the likelihood of loans moving
																				forward into higher delinquency buckets.
																				For example, they track the probability
																				of a loan moving from 30 days past due
																				to 60 days past due.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Backward Transitions: These matrices
																				also account for backward transitions,
																				where loans recover and move back to
																				lower delinquency stages, indicating
																				improvements in borrower repayment
																				behavior.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive View: By providing a
																				detailed picture of both forward and
																				backward transitions, roll rate matrices
																				help banks understand the full spectrum
																				of delinquency dynamics.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<img
																	src={delinquencySolutions}
																	style={{
																		width: '90%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 1 ? (
																<img
																	src={eveSolutions}
																	style={{
																		width: '90%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Scenario Analysis:
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Probability of Default (PD):
																	</h5>
																</div>
															) : null}
															{/*i === 4 && j === 1 ? (
																<img
																	src={profitabilitySolutions}
																	style={{
																		width: '50%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Loss Given Default (LGD):
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Exposure at Default (EAD):
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 3 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Expected Loss (ECL):
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Static Loss Analysis:
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Dynamic Loss Analysis:
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		By combining static and dynamic loss
																		analysis, Vector ML Analytics enables banks
																		to:
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 2 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Assess Risk Under Various Conditions:
																				Understand how potential changes in the
																				economy or borrower behavior could
																				impact loan performance and overall
																				credit risk.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Improve Forecast Accuracy: Use
																				historical data and predictive modeling
																				to create more accurate forecasts of
																				future losses, enhancing decision-making
																				and strategic planning.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Enhance Stress Testing: Incorporate
																				dynamic loss projections into stress
																				testing frameworks to evaluate the
																				resilience of loan portfolios under
																				adverse scenarios.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Optimize Risk Management Strategies:
																				Develop more effective risk mitigation
																				strategies by understanding both current
																				and potential future loss exposures.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 6 && j === 1 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Forward-Looking Estimates: Vector ML
																				Analytics utilizes advanced predictive
																				models to generate forward-looking
																				estimates of credit losses, considering
																				economic forecasts and borrower
																				characteristics.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive Data Integration: The
																				platform integrates historical
																				performance data, current economic
																				indicators, and future projections to
																				ensure accurate CECL calculations.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Real-Time Updates: Continuous monitoring
																				and real-time updates allow banks to
																				adjust their loss estimates as new
																				information becomes available, ensuring
																				compliance and relevance.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 6 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		IFRS 9
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 2 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Stage 1: Assets with no significant
																				increase in credit risk since initial
																				recognition.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stage 2: Assets with a significant
																				increase in credit risk.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Stage 3: Credit-impaired assets.</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 2 ? (
																<img
																	src={niiSolutions}
																	style={{
																		width: '75%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 5 && j === 1 ? (
																<img
																	src={prepaymentSolutions}
																	style={{
																		width: '70%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{/* Liquidity Planning code image i === 3 && j === 5 ? (
																<img
																	src={solutionsAssetLiability}
																	style={{
																		width: '55%',
																		height: '100%',
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '50px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 5 ? (
																<img
																	src={''}
																	style={{
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '70px',
																		marginBottom: '-60px',
																		width: '55%'
																	}}
																/>
															) : (
																''
															)}
														</li>
													))}
												</ul>
												<div style={{ marginBottom: '18px' }}></div>
											</div>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				</section>
				<section className="platform" style={{ marginBottom: 50 }}>
					<div
						className="container subContainer2"
						style={{ marginTop: '-30px' }}
					>
						<div className="list">
							{solutionsFeaturesCapitalMarkets.map((content, i) => (
								<div className="row list_block" style={{ margin: 0 }} key={i}>
									<div className="container" style={{ padding: 0 }}>
										<div className="list_box">
											<div
												className={
													i === 0
														? 'list_content_first row'
														: 'list_content row'
												}
											>
												<h4
													style={{
														paddingLeft: 7,
														marginTop: -50,
														fontSize: '32px'
													}}
												>
													{content.header}
												</h4>
												{i === 0 && (
													<PagesSubHeader
														key={'i'}
														style={{
															marginBottom: 30,
															marginRight: 25,
															marginLeft: 9,
															marginTop: -40
														}}
														header={'Debt Capital Markets'}
														description={`Our Capital Markets Model for Warehouse Borrowing is expertly designed to optimize fintech lending strategies through advanced collateral assessments and asset valuation, maximizing borrowing capabilities. It provides detailed tranche analysis to effectively manage risk and visualize cash flow distributions within warehouse lending structures. The model ensures stringent compliance monitoring, maintaining alignment with regulatory and investment standards. Adaptable to the fast-paced changes typical in fintech asset portfolios, it supports strategic financial management and enhances the attractiveness of investments in the competitive capital markets landscape. Overall, this model transforms the approach to warehouse borrowing, streamlining operations and boosting financial performance.`}
														solutions={'solutions'}
													/>
												)}
											</div>
											<div className="col-lg-12 asset_list_container cont">
												<ul className="asset_list" style={{ marginLeft: -23 }}>
													{content?.description?.map((details, j) => (
														<li
															key={j}
															style={{
																listStyleType: 'none',
																paddingBottom: 20
															}}
														>
															{content.header ===
																'Warehouse Borrowing Base Reporting' &&
																j === 0 && (
																	<div>
																		<h5
																			style={{
																				marginTop: 40,
																				marginBottom: 30,
																				fontWeight: 'bold'
																			}}
																		>
																			Borrowing Bases
																		</h5>
																	</div>
																)}
															<p style={{ listStyleType: 'none' }}>
																<span
																	style={{ listStyleType: 'none' }}
																	className={`solutionsDetailSpan ${
																		details.length > 60
																			? 'moreThan1LineDetailSpan'
																			: ''
																	}`}
																>
																	{details}
																</span>
															</p>
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Segmentation by Origination Period:
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		CECL
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Loans are grouped into vintages based on
																				the time period they were originated,
																				such as quarterly or yearly cohorts.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				This segmentation allows banks to
																				compare the performance of different
																				cohorts and identify specific periods
																				where loan performance may have been
																				better or worse.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<img
																	src={vintageAnalysisSolutions}
																	style={{
																		width: '65%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 2 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Performance Tracking:
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Vector ML Analytics tracks key
																				performance indicators (KPIs) for each
																				vintage, such as default rates,
																				delinquency rates, and prepayment rates.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Vintage analysis highlights trends and
																				patterns in loan performance, showing
																				how credit risk evolves across different
																				cohorts.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				This comparison can reveal insights into
																				the effectiveness of underwriting
																				standards, credit policies, and market
																				conditions at the time of origination.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 40,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Earnings at Risk (EaR):
																	</h5>
																</div>
															) : null}
															{i === 2 && j === 3 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Borrowing Base Advance Rates:
																				Incorporating borrowing base advance
																				rates and reserve requirements to
																				support lending activities.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Excess Concentration and Eligibility
																				Criteria: Managing risks associated with
																				excess concentration and ensuring
																				adherence to eligibility criteria.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Operational Support: Providing cash flow
																				forecasts that include the necessary
																				cash to support operations and capital
																				to maintain the advance rate on the
																				borrowing base.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stress Testing: Including stress testing
																				to evaluate the institution’s ability to
																				withstand financial challenges and
																				optimize their capital structure.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Behavioral Cash Flows: Converting
																				contractual cash flows into behavioral
																				cash flows by modeling prepayment,
																				delinquency, and default behaviors, as
																				well as loan recovery timing.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Delinquency Migration Analysis:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Tracking Loan Movements: Vector ML
																				Analytics examines the movement of loans
																				as they transition from one delinquency
																				stage to another, such as moving from
																				current to 30 days past due, 60 days
																				past due, and so on.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Identifying Patterns: By tracking these
																				transitions, banks can identify patterns
																				and trends in delinquency behavior, such
																				as periods of increased delinquency or
																				improvements in loan performance.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<img
																	src={delinquencySolutions2}
																	style={{
																		width: '75%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Roll Rate Matrices:
																	</h5>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Forward Transitions: Roll rate matrices
																				show the likelihood of loans moving
																				forward into higher delinquency buckets.
																				For example, they track the probability
																				of a loan moving from 30 days past due
																				to 60 days past due.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Backward Transitions: These matrices
																				also account for backward transitions,
																				where loans recover and move back to
																				lower delinquency stages, indicating
																				improvements in borrower repayment
																				behavior.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive View: By providing a
																				detailed picture of both forward and
																				backward transitions, roll rate matrices
																				help banks understand the full spectrum
																				of delinquency dynamics.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 3 && j === 0 ? (
																<img
																	src={delinquencySolutions}
																	style={{
																		width: '90%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 1 ? (
																<img
																	src={eveSolutions}
																	style={{
																		width: '90%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 3 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Scenario Analysis:
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Probability of Default (PD):
																	</h5>
																</div>
															) : null}
															{/*i === 4 && j === 1 ? (
																<img
																	src={profitabilitySolutions}
																	style={{
																		width: '50%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Loss Given Default (LGD):
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Exposure at Default (EAD):
																	</h5>
																</div>
															) : null}
															{i === 4 && j === 3 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Expected Loss (ECL):
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 0 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Payment Waterfall and Risk Tranche Formation
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Ensuring Compliance and Enhancing Security
																	</h5>
																</div>
															) : null}
															{i === 1 && j === 2 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		Adaptive to Fintech Lending Dynamics
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 1 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Forward-Looking Estimates: Vector ML
																				Analytics utilizes advanced predictive
																				models to generate forward-looking
																				estimates of credit losses, considering
																				economic forecasts and borrower
																				characteristics.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Comprehensive Data Integration: The
																				platform integrates historical
																				performance data, current economic
																				indicators, and future projections to
																				ensure accurate CECL calculations.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Real-Time Updates: Continuous monitoring
																				and real-time updates allow banks to
																				adjust their loss estimates as new
																				information becomes available, ensuring
																				compliance and relevance.
																			</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 6 && j === 1 ? (
																<div>
																	<h5
																		style={{
																			marginTop: 30,
																			marginBottom: 10,
																			fontWeight: 'bold'
																		}}
																	>
																		IFRS 9
																	</h5>
																</div>
															) : null}
															{i === 6 && j === 2 ? (
																<div>
																	<ul
																		style={{
																			marginLeft: -20
																		}}
																		className="asset_list101"
																	>
																		<li style={{ marginTop: 20 }}>
																			<p>
																				Stage 1: Assets with no significant
																				increase in credit risk since initial
																				recognition.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>
																				Stage 2: Assets with a significant
																				increase in credit risk.
																			</p>
																		</li>
																		<li style={{ marginTop: 10 }}>
																			<p>Stage 3: Credit-impaired assets.</p>
																		</li>
																	</ul>
																</div>
															) : null}
															{i === 2 && j === 2 ? (
																<img
																	src={niiSolutions}
																	style={{
																		width: '75%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{i === 5 && j === 1 ? (
																<img
																	src={prepaymentSolutions}
																	style={{
																		width: '70%',
																		height: '100%',
																		alignItems: 'center',
																		justifyContent: 'center',
																		display: 'block',
																		margin: 'auto',
																		marginTop: '30px'
																	}}
																/>
															) : (
																''
															)}
															{/* Liquidity Planning code image i === 3 && j === 5 ? (
																<img
																	src={solutionsAssetLiability}
																	style={{
																		width: '55%',
																		height: '100%',
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '50px'
																	}}
																/>
															) : (
																''
															)*/}
															{i === 4 && j === 5 ? (
																<img
																	src={''}
																	style={{
																		textAlign: 'center',
																		display: 'block',
																		justifyContent: 'center',
																		alignItems: 'center',
																		margin: 'auto',
																		marginTop: '70px',
																		marginBottom: '-60px',
																		width: '55%'
																	}}
																/>
															) : (
																''
															)}
														</li>
													))}
												</ul>
												<div style={{ marginBottom: '18px' }}></div>
											</div>
										</div>
									</div>
								</div>
							))}
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Solutions;
