import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import PrivacyPolicyContent from '../common/PrivacyPolicyContent';

const PrivacyPolicy = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Privacy Policy</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<div className="subContainer2 container">
					<PrivacyPolicyContent
						header="Privacy Policy"
						last_update="Last updated: May 12, 2023"
						description="Welcome to Vector ML Analytics! Your privacy is of paramount importance to us. 
                        This privacy policy outlines the types of data we gather when you use our services, 
                        as well as some of the steps we take to safeguard it."
						p2={'1. INFORMATION WE COLLECT'}
						p3="Vector ML Analytics collects the following types of information:"
						p4="When you access the Website, the Company will learn certain information about you
                        both directly and indirectly. We may collect personal information which you provide 
                        such as name, email address, IP address, etc."
						p5="Each party (the “Receiving Party”) understands that the other party (the “Disclosing
                            Party”) has disclosed or may disclose confidential business, technical or financial 
                            information relating to the Disclosing Party’s business (hereinafter referred to as 
                            “Proprietary Information” of the Disclosing Party). Proprietary Information of 
                            Company includes non-public information regarding features, functionality, and 
                            performance of the Services. Proprietary Information of Client includes non-public 
                            Client Data"
						p6="2. HOW WE USE YOUR INFORMATION."
						p7="We use the information we collect from you to operate our website, improve our 
                        website, respond to your queries, for other customer service purposes."
						p8="The company may use Client Data according to provision of the Services and as 
                        necessary to provide the Services (including preventative and reactive technical 
                        support), or as permitted by Client, or as otherwise required by law."
						p9="3. HOW WE SHARE YOUR INFORMATION"
						p10="We do not sell, trade, or otherwise transfer your personally identifiable information 
                        to outside parties."
						p11="4. SECURITY OF YOUR INFORMATION"
						p12="The   company   takes   reasonable   precautions   to   protect   the   Client   proprietary
                        information   and   apply   appropriate   security   measures   to   protect   against
                        unauthorized access, alteration, disclosure, or destruction of your personal data that
                        we collect and store."
						p13="5. DATA RETENTION"
						p14="We will retain your information for as long as your account is active, as needed to 
                        provide you services, and as necessary to comply with our legal obligations, resolve 
                        disputes, and enforce our agreements."
						p15="6. YOUR RIGHTS AND CHOICES"
						p16="Depending on your location and subject to applicable law, you may have certain 
                        rights with respect to your personal information, including rights to access, correct, 
                        delete, or restrict the use of your personal information, and to receive a copy of 
                        your personal information in a structured and commonly used format."
						p17="7. CHANGES TO THIS POLICY"
						p18="From time to time, we may update this Privacy Policy to clarify our practices or to 
                        reflect new or different privacy practices. We encourage you to periodically review 
                        this page for the latest information about our privacy practices."
						p19="8. CONTACT US"
						p20="If you have any questions or concerns about this Privacy Policy or your privacy on 
                        our services, please contact us at info@vmlanalytics.com."
						p21="This Privacy Policy forms part of the Agreement between you and us. By using our 
                        services, you agree to be bound by this policy."
					/>
				</div>
			</div>
			<MainFooter />
		</>
	);
};

export default PrivacyPolicy;
