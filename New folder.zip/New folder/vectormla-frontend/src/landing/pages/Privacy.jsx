import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import PagesSubHeader from '../common/PagesSubHeader';
import BlogContent from '../common/BlogContent';
import privacy from '../data/privacy.json';

const headers = ['Privacy Policy', 'Terms and Conditions'];
const Privacy = () => {
	const [openModal, setOpenModal] = useState(false);
	const [itemKey, setItemKey] = useState(
		window.location.href.split('terms&conditions/')[1]
	);
	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>{headers[itemKey]}</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>
			<div className="mainContainer">
				<section className="request_form career_details">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<PagesSubHeader
									header={headers[itemKey]}
									updateDate={'Updated: 2022-12-01'}
									description={
										itemKey == 0 &&
										'Vector ML Analytics Inc and its affiliates (together “VMLA”) respects the privacy rights of our users and is strongly committed to protecting your privacy. This Privacy Policy applies to this Web site, any newsletters subscribed to via this website, digital subscriptions to www.vmlanalytics.com and VMLA Businessweek, information collected when you subscribe to the print edition of VMLA Businessweek and any other service or product of VMLA, including other websites, mobile applications, or other digital properties, as expressly indicated by VMLA such as through a link or other display of this Privacy Policy (collectively, “this Site”).'
									}
									list={
										itemKey == 1 && [
											'1. Services and Support',
											'2. Service Level Agreement',
											'3. Client Responsibilities; Restrictions',
											'4. Confidentiality; Proprietary Rights',
											'5. Payment of Fees',
											'6. Term and Termination',
											'7. Warranty and Disclaimer',
											'8. Indemnity',
											'9. Limitation of Liability',
											'10. Miscellaneous'
										]
									}
								/>
							</div>
						</div>
						<BlogContent data={privacy[itemKey]} />
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Privacy;
