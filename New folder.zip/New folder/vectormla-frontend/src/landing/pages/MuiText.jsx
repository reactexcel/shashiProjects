import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';

const useStyls = makeStyles(() => ({
	root: {
		margin: '10px auto',
		'& label.Mui-focused': {
			color: '#2E628D'
		},
		'& .MuiOutlinedInput-root': {
			'&.Mui-focused fieldset': {
				borderColor: '#2E628D'
			}
		}
	}
}));

const MuiTextField = ({
	label,
	type,
	name,
	input,
	disabled,
	multiline,
	required,
	placeholder,
	rows = 1,
	meta: { touched, invalid, error }
}) => {
	const classes = useStyls();

	return (
		<TextField
			name={name}
			placeholder={placeholder}
			className={classes.root}
			multiline={multiline}
			rows={rows}
			label={label}
			disabled={disabled}
			type={type}
			required={required}
			InputLabelProps={
				type === 'date' || type === 'time' || placeholder
					? {
							shrink: true
					  }
					: null
			}
			margin="normal"
			variant="outlined"
			fullWidth
			helperText={touched && error}
			error={touched && invalid}
			{...input}
		/>
	);
};

export default MuiTextField;
