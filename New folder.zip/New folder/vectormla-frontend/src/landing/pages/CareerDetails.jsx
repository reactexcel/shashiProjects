import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderWithBlueLeft from '../common/HeaderWithPlusNBlueLeft';
import BlogContent from '../common/BlogContent';
import careersHeader from '../data/careersHeader';
import careers from '../data/careersDetails';
import PagesSubHeader from '../common/PagesSubHeader';
import { Button } from '@material-ui/core';

const CareerDetials = () => {
	const [openModal, setOpenModal] = useState(false);
	const [itemKey, setItemKey] = useState(
		window.location.href.split('career_details/')[1]
	);
	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Career</h2>
							<h3>{careersHeader[itemKey].header}</h3>
						</div>
					</div>
				</div>
			</section>
			<div className="mainContainer">
				<section className="request_form career_details">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								<PagesSubHeader
									style={{ marginBottom: 30 }}
									header={careersHeader[itemKey].header}
									description={careersHeader[itemKey].p}
								/>
								<HeaderWithBlueLeft
									header={careersHeader[itemKey].header}
									description={careersHeader[itemKey].subP}
								/>
							</div>
						</div>
						<BlogContent style={{}} data={careers[itemKey]} />
						<div style={{ marginTop: 50 }}>
							<Button
								onClick={() =>
									window.open('mailto:hr@vmlanalytics.com', '_self')
								}
								className="button"
								style={{ backgroundColor: '#195881' }}
							>
								Apply
							</Button>
							<Button
								onClick={() => window.open('/careers', '_self')}
								className="button"
								style={{ backgroundColor: '#73AAC9' }}
							>
								Career Page
							</Button>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default CareerDetials;
