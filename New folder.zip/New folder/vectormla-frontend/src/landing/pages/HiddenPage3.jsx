import React from 'react';
import empty_page from '../../common/assets/images/LogoNew.png';
// import empty_page from '../../common/assets/images/Webinar_Oct.jpg';

const HiddenPage3 = () => {
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'center',
				alignItems: 'center',
				height: '100vh',
				margin: 10,
				padding: 110
			}}
		>
			<img
				src={empty_page}
				alt="Vector Logo"
				style={{ maxWidth: '100%', height: 'auto' }}
			/>
		</div>
	);
};

export default HiddenPage3;
