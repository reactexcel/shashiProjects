import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import HeaderRectangle from '../common/HeaderRectangle';
import HeaderWithBlueLeft from '../common/HeaderWithPlusNBlueLeft';
import DescriptionArrow from '../common/DescriptionArrow';

const Support = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="head_section">
				<div className="container cont">
					<div className="row no-gutters">
						<div className="col">
							<h2>Support</h2>
							<h3>
								Vector <span className="ind">ml</span> Analytics Platform
							</h3>
						</div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<div className="subContainer2 container">
					<HeaderRectangle
						header="Support Overview"
						description="Submit to the 24/7 support desk via live chat on the platform. Click on the HELP button in the command bar. You can find your account representative on your platform panel by going into settings, or you can call us at these numbers."
						other_lines={[
							'',
							'Support Numbers',
							'Americas +1 718 213 4961',
							'EMEA + 44 20 3239 9506'
						]}
					/>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="Platform Updates" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow
							header="Platform"
							descirption=""
							other_lines={[
								'Dec 2020 Release',
								'Jan 2021 Release',
								'Feb 2021 Release'
							]}
						/>
						<DescriptionArrow header="API" descirption="Data Dictionary" />
						<DescriptionArrow
							header="Excel Add-ins"
							descirption=""
							other_lines={[
								'Excel Add-in: Platform (36-Bit)',
								'Excel Add-in: Platform (64-Bit)'
							]}
						/>
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="Account Information" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow
							header="Platform Service"
							descirption=""
							other_lines={['Place order', 'Monitor order status']}
						/>
						<DescriptionArrow
							header="Contracts"
							descirption=""
							other_lines={[
								'Electronically sign contracts',
								'Access executed contracts'
							]}
						/>
						<DescriptionArrow
							header="Online Support Service"
							descirption=""
							other_lines={[
								'Access to notifications',
								'View platform documentation'
							]}
						/>
						<DescriptionArrow
							header="Billing Service"
							descirption=""
							other_lines={['View invoices', 'Update billing information']}
						/>
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="API Library" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow
							header="Excel Add-in"
							descirption="Vector ML Platform provides two-way integration with Excel, allowing clients to populate Excel spreadsheets with live production and market data. Clients can use the platform's built-in templates and customize them to their profile if needed. Clients can conduct portfolio analyses, simulate extreme events and their effect on prices, create graphs and indicators to improve the understanding of internal policies, market dynamics, and much more."
							desciprion2={[
								"Vector ML and related data can either be hosted using the company’s cloud servers or hosted via the client's data center. In both cases, users will access the platform through a web browser."
							]}
						/>

						<DescriptionArrow
							header="R and Python"
							descirption="Using the Vector ML Platform API for R and Python, you can conduct portfolio analyses, simulate extreme events and their effect on prices, create visualizations and indicators to improve the understanding of internal policies, market dynamics, and much more."
						/>
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="Documentation" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow
							header="Probability of Default Methodology"
							descirption=""
						/>
						<DescriptionArrow
							header="Prepayment Rate Methodology"
							descirption=""
						/>
						<DescriptionArrow
							header="Loan Book Valuation Methodology"
							descirption=""
						/>
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="Remote Access" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow header="Web Portal" descirption="" />
						<DescriptionArrow header="R and Python" descirption="" />
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="Security" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow header="Authentication" descirption="" />
					</div>
				</div>

				<div className="subContainer2 container">
					<HeaderWithBlueLeft header="FAQ" />
					<div style={{ padding: '20px 0px 0px 40px' }}>
						<DescriptionArrow header="How do I contact Vector ML Analytics for support?" />
					</div>
				</div>
			</div>
			<MainFooter />
		</>
	);
};

export default Support;
