import React, { useEffect, useState, useMemo } from 'react';
import { withRouter } from 'react-router-dom';
import pc from '../../common/assets/images/pc.svg';
import close from '../../common/assets/images/close.svg';
import logo from '../../common/assets/images/logo.svg';
import { Container, Row, Col, Navbar, Nav } from 'react-bootstrap';
import {
	support,
	innovations,
	assetClasses,
	clients,
	debtCapitalMarkets,
	alm,
	creditRisk,
	fpna
} from '../data/headerContent';

const Header = ({ clickHandler, history, openModal }) => {
	const [open, setOpen] = useState(false || openModal);
	const [activeTab, setActiveTab] = useState(null);
	const [hoverTab, setHoverTab] = useState(null);
	const [width, setWidth] = useState(window.innerWidth);

	useEffect(() => {
		const handleResize = () => setWidth(window.innerWidth);
		window.addEventListener('resize', handleResize);
		return () => window.removeEventListener('resize', handleResize);
	}, []);

	useEffect(() => {
		window.addEventListener('scroll', () => {
			clickHandler(false);
			setOpen(false);
			setHoverTab(null);
			setActiveTab(null);
		});

		return () => {
			window.removeEventListener('scroll', () => clickHandler(false));
		};
	}, []);

	const solutionTabPreview = () => (
		<>
			<div className="col-lg-4 left_part">
				<h3>
					<a href="/solutions">Solutions</a>
				</h3>
				<p>
					Vector ML Platform is a cloud-based treasury and credit risk system
					built for banks and lending institutions.
				</p>
			</div>
			<div className="col-lg-8 right_part">
				<div className="row list_rows">
					<div className="col-sm">
						<a href="/solutions">FP&A</a>
						<ul>
							{fpna.map((cat, i) => {
								return (
									<li key={i}>
										<a href="/solutions">{cat}</a>
									</li>
								);
							})}
						</ul>
					</div>
					<div className="col-sm">
						<a href="/solutions">Securitization and Debt Capital Markets</a>
						<ul>
							{debtCapitalMarkets.map((cat, i) => {
								return (
									<li key={i}>
										<a href="/solutions">{cat}</a>
									</li>
								);
							})}
						</ul>
					</div>
				</div>
				<div className="row list_rows">
					<div className="col-sm">
						<a href="/solutions">Treasury</a>
						<ul>
							{alm.map((cat, i) => {
								return (
									<li key={i}>
										<a href="/solutions">{cat}</a>
									</li>
								);
							})}
						</ul>
					</div>
					<div className="col-sm">
						<a href="/solutions">Credit Risk</a>
						<ul>
							{creditRisk.map((cat, i) => {
								return (
									<li key={i}>
										<a href="/solutions">{cat}</a>
									</li>
								);
							})}
						</ul>
					</div>
				</div>
			</div>
		</>
	);

	const insightsTabPreview = () => (
		<>
			<div className="col-lg-4 left_part">
				<h3>
					<a href="/blogs">Insights</a>
				</h3>
				<p>
					Our loan-level analytics platform will provide you with different ML
					techniques, which will help you dig deeper into prepayments and
					defaults behavior across various asset classes.
				</p>
				<p>
					Customizable inputs and assumptions will allow you to model different
					scenarios and test multiple outcomes that will enhance your
					profitability and mitigate risk.
				</p>
			</div>
			<div className="col-lg-8 right_part">
				<div className="row">
					<div className="col-sm">
						<a href="/blogs">Our Clients</a>
						<ul>
							{clients.map((client, i) => {
								return (
									<li key={i}>
										<a href="/blogs">{client}</a>
									</li>
								);
							})}
						</ul>
					</div>
					<div className="col-sm">
						<a href="/blogs">Asset Classes</a>
						<ul>
							{assetClasses.map((asset, i) => {
								return (
									<li key={i}>
										<a href="/blogs">{asset}</a>
									</li>
								);
							})}
						</ul>
					</div>

					{/*<div className="col-sm">
						<a href="/blogs">Innovation</a>
						<ul>
							{innovations.map((innovation, i) => {
								return (
									<li key={i}>
										<a href="/blogs">{innovation}</a>
									</li>
								);
							})}
						</ul>
						</div>*/}
				</div>
			</div>
		</>
	);

	const supportTabPreview = () => (
		<>
			<div className="col-lg-4 left_part">
				<h3>
					<a href="/support">Support</a>
				</h3>
				<p>
					Revolutionizing banking and lending analytics using ML and automation
				</p>
			</div>
			<div className="col-lg-8 right_part">
				<div className="row">
					<div className="col-sm">
						<a href="/support">Customer Support</a>
						<ul>
							{support.map((s, i) => {
								return (
									<li key={i}>
										<a href="/support">{s}</a>
									</li>
								);
							})}
						</ul>
					</div>
					<div className="col-sm">
						<a href="/support">Contact</a>
						<ul>
							<li>
								<p>
									<span>Americas</span>
									<span>+1 718 213-4961</span>
								</p>
							</li>
							<li>
								<p>
									<span>EMEA</span>
									<span>+ 44 20 3239 9506</span>
								</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</>
	);

	const searchTabPreview = () => (
		<>
			<div className="col-lg-4 left_part">
				<h3>Search</h3>
				<p>
					Forward looking analytics drive profitability through balance sheet
					optimization
				</p>
			</div>
			<div className="col-lg-8 right_part">
				<div className="row">
					<div className="col-sm">
						<h4 style={{ color: 'white', fontSize: '18px' }}>Quick links</h4>
						<ul>
							{support.map((s, i) => {
								return (
									<li key={i}>
										<a href="/support">{s}</a>
									</li>
								);
							})}
						</ul>
					</div>
					<div className="col-sm">
						<h4 style={{ color: 'white', fontSize: '18px' }}>Contact</h4>
						<ul>
							<li>
								<p>
									<span>Americas</span>
									<span>+1 718 213-4961</span>
								</p>
							</li>
							<li>
								<p>
									<span>EMEA</span>
									<span>+ 44 20 3239 9506</span>
								</p>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</>
	);

	const contentPreview = () =>
		activeTab === 'solution' || hoverTab === 'solution'
			? solutionTabPreview()
			: activeTab === 'insights' || hoverTab === 'insights'
			? insightsTabPreview()
			: activeTab === 'support' || hoverTab === 'support'
			? supportTabPreview()
			: activeTab === 'search' || hoverTab === 'search'
			? searchTabPreview()
			: null;

	const hasPopUp = useMemo(() => {
		const availablePopups = ['solution', 'insights', 'support', 'search'];
		return (
			availablePopups.includes(activeTab) || availablePopups.includes(hoverTab)
		);
	}, [activeTab, hoverTab]);

	const headerStlyes = useMemo(() => {
		if (hasPopUp) {
			return {
				zIndex: 10000000
			};
		}
		return {};
	}, [hasPopUp]);

	return (
		<>
			<header
				style={headerStlyes}
				onMouseLeave={() => {
					clickHandler(false);
					setOpen(false);
					setActiveTab(null);
					setHoverTab(null);
				}}
				className="sticky-header"
			>
				<Container className="cont headerContainer">
					<Row noGutters>
						<Col>
							<Navbar expand="xl">
								<Navbar.Brand
									href="#"
									onClick={() => history.push('/home')}
									aria-label="Home"
								>
									<img src={logo} height="40px" alt="" />
								</Navbar.Brand>
								{/*<Nav.Link href="#" className="search_mobile">
									<button
										onClick={() => setActiveTab('search')}
										className="search"
									>
										<i className="fas fa-search"></i>
									</button>
								</Nav.Link>*/}
								<button
									onClick={() => {
										clickHandler(!open);
										setOpen(!open);
									}}
									className="navbar-toggler"
									data-toggle="collapse"
									data-target="#navbarSupportedContent"
									aria-controls="navbarSupportedContent"
									aria-expanded="false"
									aria-label="Toggle navigation"
								>
									<i className="fas fa-bars"></i>
								</button>
								{(open || window.innerWidth > 1199) && (
									<Navbar.Collapse id="navbarSupportedContent">
										<div className="fixed_cont">
											<Navbar.Brand href="/home">
												<h1>
													Vector <span className="ind">ML</span> Analytics
												</h1>
												<span className="point"></span>
											</Navbar.Brand>
											<button
												className="navbar-toggler"
												data-toggle="collapse"
												data-target="#navbarSupportedContent"
												aria-controls="navbarSupportedContent"
												aria-expanded="false"
												aria-label="Toggle navigation"
											>
												<img
													onClick={() => {
														clickHandler(false);
														setOpen(false);
													}}
													src={close}
													alt=""
												/>
											</button>
											<Nav>
												<ul className="navbar-nav">
													<li>
														<Nav.Link href="/home#">
															<button
																onMouseEnter={() =>
																	window.innerWidth > 1199 &&
																	setHoverTab('home')
																}
																onClick={() => {
																	setActiveTab('home');
																	history.push('/home');
																}}
															>
																Home
															</button>
														</Nav.Link>
													</li>
													<li>
														<Nav.Link href="#">
															<button
																onMouseEnter={() =>
																	window.innerWidth > 1199 &&
																	setHoverTab('solution')
																}
																onClick={() => {
																	setActiveTab('solution');
																	history.push('/solutions');
																}}
															>
																Solutions
															</button>
														</Nav.Link>
													</li>
													<li>
														<Nav.Link href="#">
															<button
																onMouseEnter={() =>
																	window.innerWidth > 1199 &&
																	setHoverTab('insights')
																}
																onClick={() => {
																	setActiveTab('insights');
																	history.push('/blogs');
																}}
															>
																Resources
															</button>
														</Nav.Link>
													</li>
													{/*
														<li>
															<Nav.Link href="#">
																<button
																	onMouseEnter={() =>
																		window.innerWidth > 1199 &&
																		setHoverTab('team')
																	}
																	onClick={() => {
																		setActiveTab('team');
																		history.push('/team');
																	}}
																>
																	Team
																</button>
															</Nav.Link>
														</li>
																*/}
													{/*
														<li>
															<Nav.Link href="#">
																<button
																	onMouseEnter={() =>
																		window.innerWidth > 1199 &&
																		setHoverTab('investors')
																	}
																	onClick={() => {
																		setActiveTab('investors');
																		history.push('/investors');
																	}}
																>
																	Investors
																</button>
															</Nav.Link>
														</li>
																*/}
													{/*<li>
														<Nav.Link>
															<button
																onMouseEnter={() =>
																	window.innerWidth > 1199 &&
																	setHoverTab('support')
																}
																onClick={() => {
																	setActiveTab('support');
																	history.push('/support');
																}}
															>
																Support
															</button>
														</Nav.Link>
															</li>*/}
													{
														<li className="request_demo">
															<Nav.Link href="https://academy.vectormla.com/">
																Academy
															</Nav.Link>
														</li>
													}
													<li className="request_demo">
														<Nav.Link
															href="https://calendly.com/mvrdoljak/30min"
															target="_blank"
															rel="noreferrer"
														>
															Demo
														</Nav.Link>
													</li>
													<li
														className="login_to_li"
														onClick={() => history.push('/login')}
													>
														<Nav.Link href="#" className="login_to">
															<img src={pc} alt="" />
															Login to Vector{' '}
															{/*<span className="ind">ml</span>*/}
														</Nav.Link>
													</li>
												</ul>
											</Nav>
											{/*<Nav.Link href="#" className="search_desktop">
												<button
													onMouseEnter={() =>
														window.innerWidth > 1199 && setHoverTab('search')
													}
													onClick={() => setActiveTab('search')}
													className="search"
												>
													<i className="fas fa-search"></i>
													<span>Search</span>
												</button>
												</Nav.Link>*/}
										</div>
									</Navbar.Collapse>
								)}
							</Navbar>
						</Col>
					</Row>
				</Container>
				{(activeTab || hoverTab) && (
					<div
						style={{ display: 'block' }}
						className="modal full_modal full_modal_custom"
					>
						<div className="container cont modal_customBackground">
							<div className="modal-body modal-body-custom">
								<div
									style={{
										display: 'flex',
										flexWrap: 'wrap',
										marginLeft: '0px !important',
										marginRight: '0px !important',
										position: 'relative'
									}}
									onMouseLeave={() => {
										clickHandler(false);
										setOpen(false);
										setActiveTab(null);
										setHoverTab(null);
									}}
								>
									<div className="modal-header">
										<button className="close">
											{hasPopUp ? (
												<img
													onClick={() => {
														clickHandler(false);
														setOpen(false);
														setActiveTab(null);
														setHoverTab(null);
													}}
													src={close}
													alt=""
												/>
											) : null}
										</button>
									</div>
									{contentPreview()}
								</div>
							</div>
						</div>
					</div>
				)}
			</header>
		</>
	);
};

export default withRouter(Header);
