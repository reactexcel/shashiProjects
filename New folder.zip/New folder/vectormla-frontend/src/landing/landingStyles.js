import { makeStyles } from '@material-ui/core';

export const useStyles = makeStyles((theme) => ({
	appBar: {
		height: 100,
		backgroundColor: 'white',
		alignContent: 'flex-end'
	},
	box_text: {
		fontWeight: 'bold',
		color: 'white',
		fontSize: 10,
		fontFamily: 'Roboto',
		marginTop: 15,
		textAlign: 'center'
	},
	tab_text: {
		fontSize: 12,
		color: '#313132',
		fontFamily: 'Roboto',
		textTransform: 'none',
		borderBottomColor: '#000',
		borderBottomWidth: 1
	},
	indicator: {
		color: '#313132',
		borderBottomColor: '#000',
		borderBottomWidth: 2
	},
	button_typo: {
		fontSize: '13px',
		paddingBottom: 8,
		active: {
			backgroundColor: '#fff123'
		},
		'&:hover': {
			'&:not($selected)': {
				paddingBottom: 8,
				borderBottom: `5px solid #266696`
			}
		}
	},
	listItemBtn: {
		paddingLeft: 0,
		paddingRight: 0,
		marginRight: 35
	},
	text: {
		fontSize: 20
	},
	list: {
		listStyleImage: require('../../common/assets/vector/images/list_block.svg'),
		'&:before': {
			color: 'red'
		}
	}
}));
