import React from 'react';
import rightCarousel from '../../common/assets/images/rightCarousel.svg';
const Card = ({ title, items }) => (
	<div className="col-sm-6 col-lg-3" style={{ paddingInline: 8 }}>
		<div className="card" style={{ borderRadius: '20px' }}>
			<div className="triangle_career" />
			<div>
				<h2 style={{ textAlign: 'left' }}>{title}</h2>
				<ul className="cardList" style={{ paddingBottom: 40 }}>
					{items.map((item, index) => (
						<li key={index} style={{ textAlign: 'left' }}>
							<span>{item}</span>
						</li>
					))}
				</ul>
				<a href="/solutions" className="btn">
					Read More
					{/*<img src={rightCarousel} className="btn-arrow" alt="" />*/}
					<span className="searchEngineHidden">Solutions</span>
				</a>
			</div>
		</div>
	</div>
);
export default Card;
