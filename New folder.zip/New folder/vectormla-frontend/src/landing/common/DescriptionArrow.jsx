import React from 'react';

const DescriptionArrow = ({
	header,
	descirption,
	other_lines,
	desciprion2
}) => {
	return (
		<div className="solutions_header_descriptions">
			<a href="#" className="main_link accord">
				{header}
			</a>
			<p style={{ whiteSpace: 'pre-wrap' }}>{descirption}</p>
			{desciprion2
				? desciprion2.map((item, i) => <p key={`desc2-${i}`}>{item}</p>)
				: ''}
			{other_lines
				? other_lines.map((item, i) => (
						<p key={`other-${i}`} className="solutions_header_other_lines">
							{item}
						</p>
				  ))
				: ''}
		</div>
	);
};

export default DescriptionArrow;
