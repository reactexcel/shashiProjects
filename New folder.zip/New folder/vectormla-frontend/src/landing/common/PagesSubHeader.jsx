import React from 'react';
const PagesSubHeader = ({
	header,
	description,
	updateDate,
	list,
	style,
	onClick,
	solutions
}) => {
	return (
		<div onClick={onClick} className={'subHeaderContainer'} style={style}>
			<h2 style={{ fontSize: '32px' }}>{header}</h2>
			{updateDate && <p>{updateDate}</p>}
			{description && (
				<p
					style={{
						whiteSpace: 'pre-wrap',
						color: 'white',
						fontSize: '20px',
						textAlign: 'justify'
					}}
				>
					{description}
				</p>
			)}
			{list &&
				list.map((item, i) => (
					<p key={`${i}-subP`} style={{ margin: 0 }}>
						{item}
					</p>
				))}
		</div>
	);
};

export default PagesSubHeader;
