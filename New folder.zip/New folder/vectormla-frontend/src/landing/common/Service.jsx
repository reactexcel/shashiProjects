import React from 'react';

const Service = ({ src, hover, title, description, page }) => (
	<div
		className={
			page !== 'resources'
				? 'col-lg-3 col-sm-6 service'
				: 'col-lg-2 col-sm-6 service'
		}
	>
		<div
			className="platform_img"
			style={{
				marginLeft: page === 'resources' ? '1.9rem' : ''
			}}
		>
			<img src={src} data-hover={hover} alt="" />
		</div>
		<h4>{title}</h4>
		<p style={{ color: '#86898e' }}>{description}</p>
	</div>
);
export default Service;
