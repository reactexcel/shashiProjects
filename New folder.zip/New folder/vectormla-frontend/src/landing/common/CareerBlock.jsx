import React from 'react';
import career_code from '../../common/assets/images/career_code.svg';

const CareerBlock = ({ header, subHeader, descirption, item }) => {
	const handleRightClick = (e) => {
		// e.preventDefault();
	};
	const handleLeftClick = (e) => {
		window.open(`/career_details/${item}`, '_self');
	};
	return (
		<div className="professionCareer" onContextMenu={handleRightClick}>
			<div>
				<div className="cardHeaderCareer">
					<h2>{header}</h2>
				</div>
				<div className="cardImgCareer">
					<img src={career_code} height="50%" width="50%" alt="" />
				</div>

				<div className="careerCardContent">
					<h5 className="cardSubheader">{subHeader}</h5>
					<p>{descirption}</p>
					<a
						href={`/career_details/${item}`}
						onClick={handleLeftClick}
						className="more_btn_career"
					>
						More Details
					</a>
				</div>
			</div>
		</div>
	);
};

export default CareerBlock;
