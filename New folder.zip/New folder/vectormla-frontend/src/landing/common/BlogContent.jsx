import React from 'react';

const BlogContent = ({ data, style, imgs }) => {
	return (
		<div
			style={
				!style
					? { paddingTop: data[0].header ? 10 : 50, paddingBottom: 30 }
					: style
			}
		>
			{data?.map((list, index) => (
				<div key={index}>
					{list.header && (
						<h2
							style={{
								fontSize: '32px',
								fontFamily: 'Roboto',
								color: '#1c486e',
								marginTop: 45,
								fontWeight: 'bold',
								marginBottom: 20
							}}
						>
							{list.header}
						</h2>
					)}
					{list.blueHeader &&
						list.blueHeader.map((item, i) => (
							<p
								key={`blue-${i}`}
								style={{
									fontSize: '22px',
									fontFamily: 'Roboto',
									fontWeight: 'bold',
									color: '#36ACD6',
									lineHeight: '18px',
									whiteSpace: 'pre-wrap',
									margin: 0,
									textAlign: 'justify'
								}}
							>
								{item}
							</p>
						))}
					{list.p &&
						list.p.map((item, i) => (
							<p
								key={`p-${i}`}
								style={{
									fontSize: '20px',
									fontFamily: 'Roboto, Avenir, sans-serif',
									color: '#77797d',
									lineHeight: '26px',
									whiteSpace: 'pre-wrap',
									textAlign: 'justify'
								}}
							>
								{item}
							</p>
						))}
					{list.blackSubheader &&
						list.blackSubheader.map((item, i) => (
							<p
								key={`black-${i}`}
								style={{
									fontSize: '22px',
									fontFamily: 'Roboto',
									fontWeight: 'bold',
									color: '#6E6F72',
									lineHeight: '18px',
									whiteSpace: 'pre-wrap',
									margin: 0
								}}
							>
								{item}
							</p>
						))}
					{list.points && (
						<ul
							style={{
								fontSize: 18,
								fontFamily: 'Roboto',
								color: '#6E6F72',
								lineHeight: '25px',
								paddingLeft: 1,
								listStyleType: 'none' // Disables default bullets
							}}
						>
							{list.points.map((item, j) => (
								<li
									key={`points-${j}`}
									style={{
										margin: 0,
										whiteSpace: 'pre-wrap',
										position: 'relative', // Needed for positioning the pseudo-element
										paddingLeft: '20px' // Provides space for the custom bullet
									}}
								>
									<span
										style={{
											position: 'absolute',
											left: 0, // Aligns the custom bullet at the start of the text
											top: '50%', // Centers the bullet vertically
											transform: 'translateY(-50%)', // Ensures the bullet is perfectly centered
											height: '8px', // Diameter of the bullet
											width: '8px', // Diameter of the bullet
											backgroundColor: '#6E6F72', // Color of the bullet
											borderRadius: '50%' // Makes the span circular
										}}
									></span>
									{item}
								</li>
							))}
						</ul>
					)}

					{list.img && (
						<center>
							<h2
								style={{
									fontSize: 18,
									fontFamily: 'Roboto',
									fontWeight: 'bold',
									color: '#2E628D',
									marginTop: 45,
									marginBottom: 20
								}}
							>
								{list.img.header}
							</h2>
							<img
								src={imgs[list.img.src]}
								style={{
									width: list.img.width,
									height: list.img.height,
									marginBlock: 0,
									marginBottom: 20
								}}
								alt=""
							/>
						</center>
					)}
				</div>
			))}
		</div>
	);
};

export default BlogContent;
