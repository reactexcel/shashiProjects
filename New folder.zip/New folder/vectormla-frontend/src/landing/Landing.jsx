// React & Redux related imports
import React, { useState, useEffect, useMemo } from 'react';
import { useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';

// Component imports
import Carousel, { consts } from 'react-elastic-carousel';
import Header from './header/Header';
import MainFooter from './footer/MainFooter';
import InsightsBlock from './common/InsightsBlock';
import Service from './common/Service';
import Card from './common/Cards';

// Bootstrap & CSS imports
import { Row } from 'react-bootstrap';
import './List.css';
// Utility imports
import { isMobile } from 'react-device-detect';
import { retrieveUserInfo } from 'app/store/actions/auth.action';
import LazyLoad from 'react-lazyload';
// Image imports
import active_arrow_right from '../common/assets/images/active_arrow_right.svg';
import active_arrow_left from '../common/assets/images/active_arrow_left.svg';
import inactive_arrow_right from '../common/assets/images/inactive_arrow_right.svg';
import inactive_arrow_left from '../common/assets/images/inactive_arrow_left.svg';
import devices from '../common/assets/images/devices.avif';
import devices2 from '../common/assets/images/devices2.avif';
import devices3 from '../common/assets/images/devices3.avif';
import devices4 from '../common/assets/images/devices4.avif';
import devices_svg from '../common/assets/images/devices.svg';
import devices2_svg from '../common/assets/images/devices2.svg';
import devices3_svg from '../common/assets/images/devices3.svg';
import devices4_svg from '../common/assets/images/devices4.svg';
import desktop from '../common/assets/images/desktop.svg';
import accuracy from '../common/assets/images/accuracy.svg';
import transparency from '../common/assets/images/transparency.svg';
import flexibility from '../common/assets/images/flexibility.svg';
import speed from '../common/assets/images/speed.svg';
import accuracy_hover from '../common/assets/images/accuracy_hover.svg';
import transparency_hover from '../common/assets/images/transparency_hover.svg';
import flexibility_hover from '../common/assets/images/flexibility_hover.svg';
import speed_hover from '../common/assets/images/speed_hover.svg';
import rightSideCapitalM from '../common/assets/images/Union.svg';

// import screen_home_logo_avif from './images/home_screen_logo.avif';
import screen_home_logo_png from '../common/assets/images/home_screen_logo.png';
import vector_logo_avif from '../common/assets/images/vector_logo.avif';
import vector_logo_png from '../common/assets/images/vector_logo.png';
import snapPayLogo from '../common/assets/images/snapPayLogo.webp';

// Vendors logos
import claLogo from '../common/assets/images/vendor1.svg';
import nuulaLogo from '../common/assets/images/vendor2.svg';
import marsLogo from '../common/assets/images/vendor3.svg';
import aiPartnershipLogo from '../common/assets/images/vendor5.svg';
import ifcLogo from '../common/assets/images/vendor6.svg';
import sandbox from '../common/assets/images/sandbox.svg';
import plugnplay from '../common/assets/images/plugnplay.svg';
import wealthOneBankLogo from '../common/assets/images/vendor8.svg';
import caminoLogo from '../common/assets/images/camino.svg';
import strategic from '../common/assets/images/strategic.svg';
import greenboxLogo from '../common/assets/images/greenbox.svg';
import revTechLabs from '../common/assets/images/Vector.svg';
import EVPrivateInvestments from '../common/assets/images/EV Private Investments.svg';
import versara from '../common/assets/images/versara.svg';
import IBMMachinelab from '../common/assets/images/IBMMachinelab.webp';
import cfoProAnalytics from '../common/assets/images/cfo+.webp';
import AWS from '../common/assets/images/AWS2.webp';
import MicrosoftAzure from '../common/assets/images/MicrosoftAzure.webp';
import GoogleCloud from '../common/assets/images/GoogleCloud.webp';
import Carousel1 from '../common/assets/images/Carousel1.webp';
import Carousel2 from '../common/assets/images/Carousel2.webp';
import Carousel3 from '../common/assets/images/Carousel3.webp';
import Carousel4 from '../common/assets/images/Carousel4.webp';
import Carousel5 from '../common/assets/images/Carousel5.webp';
import Carousel6 from '../common/assets/images/Carousel6.webp';
import Carousel7 from '../common/assets/images/Carousel7.webp';
import AICPASOC2Compliant from '../common/assets/images/AICPASOC2Compliant.webp';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';

import financialInstitution1 from '../common/assets/images/financialInstitutionImg1.webp';
import financialInstitution2 from '../common/assets/images/financialInstitutionImg2.webp';
import financialInstitution3 from '../common/assets/images/financialInstitutionImg3.webp';
import financialInstitution4 from '../common/assets/images/financialInstitutionImg4.webp';
// JSON
import cardData from '../landing/data/featuresCards.json';
import { log } from 'async';

const Landing = ({ history }) => {
	const [loadingUser, setLoadingUser] = useState(false);
	const session = localStorage.getItem('user');
	const dispatch = useDispatch();

	useEffect(() => {
		session &&
			dispatch(
				retrieveUserInfo(
					() => {
						history.push('/app/homepage');
						setLoadingUser(true);
					},
					() => setLoadingUser(true)
				)
			);
		!session && setLoadingUser(true);
	}, []);

	// For vendors logos
	const logos = [
		wealthOneBankLogo,
		caminoLogo,
		greenboxLogo,
		aiPartnershipLogo,
		strategic,
		nuulaLogo,
		ifcLogo,
		sandbox,
		plugnplay,
		rightSideCapitalM,
		EVPrivateInvestments,
		versara,
		revTechLabs,
		claLogo,
		marsLogo,
		IBMMachinelab,
		AWS,
		MicrosoftAzure,
		GoogleCloud,
		cfoProAnalytics
	];

	const imageSources = [
		Carousel1,
		Carousel4,
		Carousel5,
		Carousel6,
		Carousel7,
		Carousel2,
		Carousel3
	];

	const allVendors = [
		// { src: wealthOneBankLogo, width: '175px', styleName: 'wealth-one-img' },
		{ src: greenboxLogo, width: '195px', styleName: 'greenbox-img' },
		{ src: caminoLogo, width: '165px', styleName: 'camino-img' },
		{ src: nuulaLogo, width: '140px', styleName: 'nuula-img' },
		{ src: versara, width: '170px', styleName: 'versara-img' },

		{ src: snapPayLogo, width: '225px', styleName: 'snap-pay-logo' },
		{ src: cfoProAnalytics, width: '240px', styleName: 'cfo-pro-img' },
		{ src: strategic, width: '190px', styleName: 'strategic-img' },
		{ src: claLogo, width: '120px', styleName: 'cla-img' },

		{ src: rightSideCapitalM, width: '185px', styleName: 'rscm-img' },
		{
			src: EVPrivateInvestments,
			width: '224px',
			styleName: 'evp-investment-img'
		},
		{ src: revTechLabs, width: '93px' },
		{ src: plugnplay, width: '170px', styleName: 'plug-Nplay-img' },

		{ src: marsLogo, width: '95px', styleName: 'mars-img' },
		{ src: aiPartnershipLogo, width: '165px', styleName: 'ai-partnership-img' },
		{ src: sandbox, width: '190px', styleName: 'sandbox-img' },
		{ src: ifcLogo, width: '170px', styleName: 'ifc-img' },

		{ src: IBMMachinelab, width: '230px', styleName: 'ibm-img' },
		{ src: AWS, width: '140px', styleName: 'aws-img' },
		{ src: GoogleCloud, width: '200px', styleName: 'google-cloud-img' },
		{ src: MicrosoftAzure, width: '180px', styleName: 'microsoft-azure-img' }
		// { src: AWS, width: '140px', styleName: 'aws-img' },
		// { src: strategic, width: '190px', styleName: 'strategic-img' },

		// { src: strategic, width: '190px', styleName: 'strategic-img' },

		// { src: MicrosoftAzure, width: '180px', styleName: 'microsoft-azure-img' },
		// { src: GoogleCloud, width: '200px', styleName: 'google-cloud-img' },
		// { src: cfoProAnalytics, width: '180px', styleName: 'cfo-pro-img' },
	];
	const financialInsitutionImages = [
		{
			src: financialInstitution1,
			width: '80%',
			caption: 'Fintech',
			styleName: 'financial-institution-img1'
		},
		{ src: financialInstitution2, width: '80%', caption: 'Non-bank lenders' },
		{
			src: financialInstitution3,
			width: '80%',
			styleName: 'financial-institution-img3',
			caption: 'Banks'
		},
		{
			src: financialInstitution4,
			width: '80%',
			caption: 'Credit Unions',
			styleName: 'financialInstitution4'
		}
	];

	// Splitting the allVendors array into chunks of 4 for each slide
	const slides = [];
	for (let i = 0; i < allVendors.length; i += 4) {
		slides.push(allVendors.slice(i, i + 4));
	}
	const arrowStyle = {
		display: 'block',
		background: 'transparent',
		height: '50px',
		width: 30,
		marginLeft: -95,
		marginRight: -60,
		cursor: 'default'
	};

	// Platform features
	const services = [
		{
			src: accuracy,
			hover: accuracy_hover,
			title: 'Accuracy',
			description: 'Calculate without simplification or approximation'
		},
		{
			src: transparency,
			hover: transparency_hover,
			title: 'Transparency',
			description: 'Uncover the black box and track at a granular level'
		},
		{
			src: flexibility,
			hover: flexibility_hover,
			title: 'Flexibility',
			description: 'Scale the functionalities to fit with the right solution'
		},
		{
			src: speed,
			hover: speed_hover,
			title: 'Speed',
			description: 'Leverage our cloud services to optimize speed-accuracy'
		}
	];

	const [openModal, setOpenModal] = useState(false);
	const CustomNextArrow = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_right}
				className={`${className} custom-next-arrow`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_right)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_right)}
				alt="Next"
				loading="lazy"
			/>
		);
	};

	const CustomPrevArrow = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_left}
				className={`${className} custom-prev-arrow`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_left)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_left)}
				alt="Previous"
				loading="lazy"
			/>
		);
	};
	const CustomNextArrowTestimonials = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_right}
				className={`${className} custom-next-arrow-testimonials`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_right)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_right)}
				alt="Next"
				loading="lazy"
			/>
		);
	};

	const CustomPrevArrowTestimonials = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_left}
				className={`${className} custom-prev-arrow-testimonials`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_left)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_left)}
				alt="Previous"
				loading="lazy"
			/>
		);
	};
	const CustomNextArrowPartners = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_right}
				className={`${className} custom-next-arrow-partners`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_right)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_right)}
				alt="Next"
				loading="lazy"
			/>
		);
	};

	const CustomPrevArrowPartners = (props) => {
		const { className, style, onClick } = props;
		return (
			<img
				src={inactive_arrow_left}
				className={`${className} custom-prev-arrow-partners`}
				onClick={onClick}
				onMouseOver={(e) => (e.currentTarget.src = active_arrow_left)}
				onMouseOut={(e) => (e.currentTarget.src = inactive_arrow_left)}
				alt="Previous"
				loading="lazy"
			/>
		);
	};

	if (openModal) {
		return (
			<Header
				openModal={openModal}
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}

	return loadingUser ? (
		<>
			<Header
				openModal={openModal}
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>

			<section className="homeSectionWrapper">
				<div className="homeSection">
					<div className="homeSection_buttons">
						<picture>
							<source srcSet={vector_logo_avif} type="image/avif" />
							<source srcSet={vector_logo_png} type="image/png" />
							<img
								src={vector_logo_avif}
								className="logo-img img-fluid"
								alt="Vector Logo"
								width="auto"
								height="auto"
							/>
						</picture>
						<h4 className="homeSection_subtitle">
							Financial Modeling for Banks and Lenders
						</h4>
						<div className="smallRemovableImage">
							<picture>
								<source
									srcSet="images/home_screen_logo.avif"
									type="image/avif"
								/>
								<source srcSet={screen_home_logo_png} type="image/png" />
								<img
									src="images/home_screen_logo.avif"
									className="img-fluid vectorImage"
									alt="Vector Image"
									width="auto"
									height="auto"
									loading="lazy"
								/>
							</picture>
						</div>
						<div className="homeButtons">
							<a
								href="https://calendly.com/mvrdoljak/30min"
								className="demoButton"
								target="_blank"
								rel="noreferrer"
							>
								Request Demo
							</a>
							<a
								href="/solutions"
								className="solutionsButton"
								style={{ marginLeft: 20 }}
							>
								Learn More
								<span className="searchEngineHidden">Solutions</span>
							</a>
						</div>
					</div>
					<div className="largeRemovableImage" style={{ zIndex: 0, flex: 1 }}>
						<picture>
							<source srcSet="images/home_screen_logo.avif" type="image/avif" />
							<source srcSet={screen_home_logo_png} type="image/png" />
							<img
								src="images/home_screen_logo.avif"
								className="img-fluid vectorImage"
								alt="Vector Image"
								width="675px"
								height="470px"
							/>
						</picture>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<section className="platform" style={{ marginTop: '-20px' }}>
					<div className="container subContainer2">
						<div
							className="row"
							style={{
								margin: '0px',
								justifyContent: 'space-between',
								columnGap: '0px',
								rowGap: '25px'
							}}
						>
							<div
								style={{
									display: 'block',
									paddingLeft: 20,
									paddingRight: -10,
									borderRight: !isMobile ? 'none' : 'none'
								}}
								className="col-lg-8 left_cont"
							>
								<h3>
									Vector <span className="ind">ML</span> Platform
								</h3>
								<p
									style={{
										paddingBottom: 10,
										paddingTop: 10,
										textAlign: 'justify'
									}}
								>
									Vector&apos;s financial modeling library supports over 300
									financial models across 40 asset classes for banks and lending
									institutions. It simplifies the modeling and reporting
									processes for assets and liabilities, including cash flow
									forecasting and profitability modeling. The Vector loan
									analytics tool accounts for the cost of funds, prepayment
									behaviors, and potential losses, significantly enhancing
									financial forecasting. It aids in loan pricing, liquidity
									management, and capital planning, while also ensuring robust
									compliance monitoring and interest rate risk simulation.
								</p>
							</div>
							<div className="col-lg-4 right_cont">
								<img src={desktop} alt="" loading="lazy" />
								<a
									href="https://calendly.com/mvrdoljak/30min"
									className="order-btn"
									target="_blank"
									rel="noreferrer"
								>
									Request Demo
								</a>
							</div>
						</div>

						<div
							className="custom-carousel-container"
							style={{ marginTop: 40 }}
						>
							<Slider
								dots={false}
								infinite={true}
								speed={500}
								slidesToShow={1}
								slidesToScroll={1}
								nextArrow={<CustomNextArrow />}
								prevArrow={<CustomPrevArrow />}
							>
								{imageSources?.map((src, index) => (
									<div key={index} className="custom-carousel-slide">
										<picture>
											<source srcSet={src.webp} type="image/webp" />
											<img
												src={src}
												className="custom-carousel-image"
												alt="Vector Devices"
												loading="lazy"
											/>
										</picture>
									</div>
								))}
							</Slider>
						</div>
					</div>
				</section>

				<section className="vector_platform">
					<div className="container subContainer2">
						<div>
							<div className="col-sm-12">
								<h1
									style={{
										fontSize: '32px',
										color: '#1C486E',
										marginBottom: '15px',
										marginTop: '15px',
										fontWeight: 'bold'
									}}
								>
									Financial Modeling Library
								</h1>
							</div>
						</div>
						<div className="col-sm-12 modeling-library">
							<p style={{ marginBottom: '-20px', textAlign: 'justify' }}>
								Vector integrates Financial Planning & Analysis (FP&A), Asset
								Liability Management (ALM), Credit Risk, and Debt Capital
								Markets into a unified platform, offering a comprehensive tool
								for managing an organization&apos;s strategic planning. This
								integration enhances decision-making by providing consolidated
								data access, real-time insights, and a complete 360-degree view
								of the balance sheet.
							</p>
						</div>
						<div className="cards">
							<div className="row">
								{cardData.map((data, index) => (
									<Card key={index} {...data} />
								))}
							</div>
						</div>
					</div>
				</section>

				<section className="vector_platform">
					<div className="container subContainer2">
						<div>
							<div className="col-sm-12">
								<h1
									style={{
										fontSize: '32px',
										color: '#1C486E',
										marginBottom: '15px',
										marginTop: '15px',
										fontWeight: 'bold'
									}}
								>
									Financial Institutions
								</h1>
							</div>
						</div>
						<div className="col-sm-12 modeling-library">
							<p style={{ marginBottom: '-20px', textAlign: 'justify' }}>
								Vector is specifically designed to cater to the diverse needs of
								financial institutions with an active loan or leasing portfolio.
								This includes a wide range of organizations from fintech
								startups and non-bank lenders to traditional banks and credit
								unions, providing them with comprehensive tools and insights to
								manage and optimize their financial operations effectively.
							</p>
						</div>
						<div>
							<div className="row justify-content-center">
								{financialInsitutionImages.map((data, index) => (
									<div
										className="col-sm-6 col-md-3 col-lg-3 image-column"
										key={index}
									>
										<div className="image-content">
											<img
												src={data.src}
												width={data.width}
												alt={`Image ${index}`}
												className={`img-fluid ${data.styleName} `}
											/>
											<p
												className={
													data.src === financialInstitution4
														? data.styleName
														: ''
												}
												style={{
													color: '#6c757d',
													fontSize: '20px',
													marginLeft: [financialInstitution3].includes(data.src)
														? -10
														: ''
												}}
											>
												{data.caption}
											</p>
										</div>
									</div>
								))}
							</div>
						</div>
					</div>
				</section>
				<section className="vector_platform">
					<div className="container subContainer2">
						<div>
							<div className="col-sm-12">
								<h1
									style={{
										fontSize: '32px',
										color: '#1C486E',
										marginBottom: '15px',
										marginTop: '15px',
										fontWeight: 'bold'
									}}
								>
									Value Proposition
								</h1>
							</div>
						</div>
						<div className="col-sm-12 modeling-library">
							<p style={{ marginBottom: '-20px', textAlign: 'justify' }}>
								Vector stands out in the market as the first platform to support
								over 300 financial models across more than 40 asset classes,
								revolutionizing the industry by cutting financial modeling costs
								by 90% while simultaneously increasing accuracy by an average of
								35%. This unique combination of extensive model support,
								significant cost savings, and enhanced accuracy makes Vector an
								unparalleled solution for financial institutions managing loan
								or leasing portfolios.
							</p>
						</div>
						<div>
							<div className="container stat-card-container">
								<div className="row justify-content-center">
									<div className="col-sm-6 col-md-3 my-3">
										<div className="stat-card">
											<div className="stat-number">300</div>
											<div className="stat-text">
												Financial Models Supported
											</div>
										</div>
									</div>
									<div className="col-sm-6 col-md-3 my-3">
										<div className="stat-card">
											<div className="stat-number">40</div>
											<div className="stat-text">Asset Classes Covered</div>
										</div>
									</div>
									<div className="col-sm-6 col-md-3 my-3">
										<div className="stat-card">
											<div className="stat-number">90%</div>
											<div className="stat-text">Time and Cost Saving</div>
										</div>
									</div>
									<div className="col-sm-6 col-md-3 my-3">
										<div className="stat-card">
											<div className="stat-number">+35%</div>
											<div className="stat-text">Increased Accuracy</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section className="vector_platform">
					<div className="container subContainer201">
						<div className="list">
							<div>
								<div className="col-sm-12">
									<h1
										style={{
											fontSize: '32px',
											color: '#1C486E',
											marginBottom: '15px',
											marginTop: '15px',
											fontWeight: 'bold'
										}}
									>
										Vector ML Platform
									</h1>
								</div>
								<div className="col-sm-12">
									<p style={{ marginBottom: '-20px', textAlign: 'justify' }}>
										Vector is the complete analytical package for profitability
										modeling designed to help lending and leasing institutions
										analyze the financial performance of their loan portfolios.
										The platform helps lending & leasing institutions make
										optimized decisions leading to higher return on investment.
										Vector ML is simple, intelligent, accurate, and affordable.
										The platform uses automation to replace countless Excel
										models used by CFOs and analysts, producing a 360-degree
										view of the institutions’ balance sheet.
									</p>
								</div>
							</div>
							<div className="video-responsive" style={{ marginTop: '50px' }}>
								<LazyLoad height={200}>
									<iframe
										src="https://www.youtube.com/embed/KmZwZ4bplx4"
										frameBorder="0"
										allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
										allowFullScreen
										title="Vector ML Analytics"
									/>
								</LazyLoad>
							</div>
						</div>
					</div>
				</section>

				<section className="vector_platform">
					<div className="container subContainer2">
						<div className="col-sm-12">
							<h1 className="vector_platform_header">
								Compliance and Security
							</h1>
						</div>
						<div className="content-wrapper">
							<img
								loading="lazy"
								src={AICPASOC2Compliant}
								alt=""
								className="compliance-image"
							/>
							<p className="compliance-text" style={{ textAlign: 'justify' }}>
								Vector ML Analytics prioritizes top-notch security and
								compliance, proven by our SOC 2 compliance. This means we
								strictly follow industry-best practices for data security,
								including using Amazon AWS&apos;s secure cloud setups to protect
								your financial information reliably. Trust us for secure and
								compliant data management.
							</p>
						</div>
					</div>
				</section>

				<section className="vector_platform">
					<div className="container subContainer2">
						<div>
							<div className="col-sm-12">
								<h1
									className="vector_platform_header"
									style={{ color: '#1C486E' }}
								>
									Our Clients and Partners
								</h1>
							</div>
							<div className="col-sm-12">
								<p>
									Executives and analysts at leading banks and lending
									institutions trust Vector ML Analytics.
								</p>
							</div>
						</div>
						<div>
							<div className="col-sm-11 clients-partners-slider">
								<Slider
									dots={false}
									infinite={true}
									speed={500}
									slidesToShow={1}
									slidesToScroll={1}
									nextArrow={<CustomNextArrowPartners />}
									prevArrow={<CustomPrevArrowPartners />}
									style={{
										marginLeft: !isMobile ? 120 : '40px',
										marginRight: !isMobile ? -5 : -20
									}}
								>
									{slides.map((slide, index) => (
										<div key={index}>
											<div className="row partners-logos">
												{slide.map((logo, logoIndex) => (
													<img
														key={logoIndex}
														src={logo.src}
														width={logo.width}
														// className="partners-img"
														className={`partners-img ${logo.styleName} `}
														style={{
															marginTop:
																logo.src === wealthOneBankLogo
																	? 25
																	: [IBMMachinelab].includes(logo.src)
																	? 10
																	: [
																			plugnplay,
																			rightSideCapitalM,
																			EVPrivateInvestments,
																			revTechLabs,
																			marsLogo,
																			aiPartnershipLogo
																	  ].includes(logo.src)
																	? 15
																	: [snapPayLogo].includes(logo.src)
																	? 40
																	: [claLogo].includes(logo.src)
																	? 10
																	: [versara].includes(logo.src)
																	? 37
																	: [GoogleCloud, MicrosoftAzure].includes(
																			logo.src
																	  )
																	? 37
																	: [nuulaLogo].includes(logo.src)
																	? 24
																	: [strategic].includes(logo.src)
																	? -15
																	: [cfoProAnalytics].includes(logo.src)
																	? 44
																	: [greenboxLogo].includes(logo.src)
																	? 40
																	: [caminoLogo].includes(logo.src)
																	? 35
																	: 30,
															height:
																logo.src === AWS
																	? '90px'
																	: logo.src === snapPayLogo
																	? '75px'
																	: [MicrosoftAzure, GoogleCloud].includes(
																			logo.src
																	  )
																	? '70px'
																	: [cfoProAnalytics].includes(logo.src)
																	? '70px'
																	: [greenboxLogo].includes(logo.src)
																	? '75px'
																	: ''
														}}
													/>
												))}
											</div>
										</div>
									))}
								</Slider>
							</div>
						</div>
					</div>
				</section>
				<section className="vector_platform">
					<div className="container subContainer2">
						<div>
							<div className="col-sm-12">
								<h1
									className="vector_platform_header"
									style={{ color: '#1C486E' }}
								>
									Client Testimonials
								</h1>
							</div>
							<div className="col-sm-11">
								<Slider
									dots={false}
									infinite={true}
									speed={500}
									slidesToShow={1}
									slidesToScroll={1}
									nextArrow={<CustomNextArrowTestimonials />}
									prevArrow={<CustomPrevArrowTestimonials />}
									style={{
										marginLeft: !isMobile ? 120 : '',
										marginRight: !isMobile ? -5 : -20,
										paddingRight: 20
									}}
								>
									<div>
										<div
											className="row justify-content-center"
											style={{
												paddingBottom: '25px',
												marginTop: -7,
												marginLeft: -50
											}}
										>
											<img src={nuulaLogo} width={'170px'} />
										</div>
										<div>
											<p style={{ textAlign: 'justify' }}>
												Forecasting capital adequacy, future cash flows and
												required return on assets for an SMB Line of Credit
												portfolio, with dynamic assumptions around utilization
												rates and unfunded commitments, is a challenging
												exercise under the most optimal circumstances. Vector ML
												does not only enhance this process, but also provides a
												level of simplicity and ease of use around an otherwise
												complex and time-consuming process. We highly recommend
												the Vector ML platform for portfolio management
												activities to any fintech in the alternative lending
												space.
											</p>
										</div>
										<div
											className="row justify-content-left"
											style={{ marginLeft: 1 }}
										>
											<p className="testimonial-author">
												Siddharth Kakkar, SVP, Finance Nuula
											</p>
										</div>
									</div>
									<div>
										<div
											className="row justify-content-center"
											style={{ paddingBottom: '30px', marginTop: 20 }}
										>
											<img src={cfoProAnalytics} width={'225px'} />
										</div>
										<div>
											<p style={{ textAlign: 'justify' }}>
												Partnering with Vector ML Analytics has transformed our
												asset and liability management, offering advanced
												insights and forecasting for our loan portfolio. Their
												customized cash flow engine and in-depth analysis have
												greatly improved our decision-making capabilities. Their
												automation of warehouse and securitization reporting has
												also enhanced our operational efficiency. Vector
												ML&apos;s innovative solutions have significantly
												contributed to our strategic planning and financial
												performance. I strongly endorse them for any financial
												institution aiming to upgrade their portfolio management
												and reporting systems.
											</p>
										</div>
										<div
											className="row justify-content-left"
											style={{ marginLeft: 1 }}
										>
											<p className="testimonial-author">
												Salvatore Tirabassi, CFO, Pro+Analytics
											</p>
										</div>
									</div>
									{/*<div>
										<div
											className="row justify-content-center"
											style={{ paddingBottom: '28px', marginTop: 20 }}
										>
											<img src={wealthOneBankLogo} width={'220px'} />
										</div>
										<div>
											<p style={{ textAlign: 'justify' }}>
												A powerful FP&A financial modeling and analysis tool
												like Vector ML can transform the banking industry,
												enabling banks to analyze individual-level loans and
												deposits with granular data and make informed decisions.
												With behavioral assumptions, this automated model can
												help banks adjust their deposit and lending strategies
												to stay ahead of customer behavior changes. The benefits
												include accurate cash flow forecasting, improved risk
												management, and informed decision-making on product
												offerings and pricing, driving success and growth in a
												constantly changing financial landscape.
											</p>
										</div>
										<div
											className="row justify-content-left"
											style={{ marginLeft: 1 }}
										>
											<p className="michael-author testimonial-author">
												Michael Koshan, CFO, Wealth One Bank of Canada
											</p>
										</div>
										</div>*/}
								</Slider>
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	) : (
		<>Loading.....</>
	);
};

export default withRouter(Landing);
