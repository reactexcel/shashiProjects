import { makeStyles } from '@material-ui/core';

export const useStyles = makeStyles((theme) => ({
	footer: {
		boxSizing: 'border-box',
		height: 70,
		width: '100%',
		margin: '70px auto 0px',
		padding: '0 50px',
		maxWidth: 1250,
		backgroundColor: '#0D425F',
		position: 'absolute',
		bottom: 0,
		zIndex: 99,
		left: '50%',
		transform: 'translate(-50%)',

		display: 'flex',
		justifyContent: 'space-around',
		alignItems: 'center'
	},
	footer__item: {
		fontSize: 15,
		transition: '.5s',
		margin: '0 5px',
		color: '#B3B3B3',
		cursor: 'pointer',
		'&:hover': {
			color: '#FFF'
		}
	}
}));
