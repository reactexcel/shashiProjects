import React, { useState } from 'react';
import mail from '../../common/assets/images/mail.svg';
import tel from '../../common/assets/images/tel.svg';
import vectorProductDoc from '../../common/assets/images/VectorProductDoc.pdf';

const MainFooter = () => {
	const [lnClass, setLnClass] = useState('linkedin');
	const [ytClass, setYtClass] = useState('youtube');
	const [fbClass, setFbClass] = useState('facebook');
	const [twitterClass, setTwitterClass] = useState('twitter');
	const [instagramClass, setInstagramClass] = useState('instagram');
	const [formData, setFormData] = useState({
		first_name: '',
		last_name: '',
		email: ''
	});
	const handleChange = (e) => {
		const { name, value } = e.target;
		setFormData((prev) => ({ ...prev, [name]: value }));
	};

	const showToast = (message) => {
		const toastContainer = document.getElementById('toastContainer');
		const toastMessage = document.createElement('div');
		toastMessage.classList.add('toast-message');
		toastMessage.textContent = message;
		toastContainer.appendChild(toastMessage);

		toastMessage.addEventListener('animationend', () => {
			setTimeout(() => {
				toastMessage.remove();
			}, 1000);
		});
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(formData.email)) {
			showToast('Please enter a valid email address.');
			return;
		}

		try {
			const response = await fetch(
				'https://vmlanalytics.com/api/dldocs/document1/',
				{
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(formData)
				}
			);

			if (response.ok) {
				showToast('Subscription successful. Thank you for subscribing!');
			} else {
				throw new Error(
					'Failed to subscribe. Please make sure all fields are correctly filled.'
				);
			}
		} catch (error) {
			showToast('Error: ' + error.message);
		}
	};

	return (
		<section className="request_form">
			<div id="toastContainer"></div>
			<div className="footer_container">
				<div className=" container">
					<div className="row">
						<div className="form_cont">
							<footer>
								<div>
									<div
										className="container footer-container"
										style={{ marginLeft: -30 }}
									>
										<div className="row contact_info">
											<div className="col-md-9 col-lg-3 footer-office">
												<h5>Office</h5>
												<p>Vector ML Analytics</p>
												<p>420 Lexington Avenue Suite 1402</p>
												<p>New York, NY 10170</p>
												<ul className="contacts">
													<li>
														<img src={mail} alt="" />
														<a
															href="mailto:info@vmlanalytics.com"
															style={{ marginLeft: '-7px' }}
														>
															info@vmlanalytics.com
														</a>
													</li>
													<li>
														<p className="simple">
															<img src={tel} alt="" />
															{'+1 718 213 4961'}
														</p>
													</li>
												</ul>
											</div>
											<div
												className="col-md-5 col-lg-2 footer-careers"
												style={{ marginLeft: 24 }}
											>
												<h5>Careers</h5>
												<ul className="footer_menus">
													<li>
														<a href="/careers">Professionals</a>
													</li>
													<li>
														<a href="/careers">Students & Interns</a>
													</li>
													<li>
														<a href="/careers">Hackathon</a>
													</li>
												</ul>
											</div>
											<div
												className="col-sm-5 col-lg-2 solutions-footer"
												style={{ marginLeft: 24 }}
											>
												<h5>Solutions</h5>
												<ul className="footer_menus">
													<li>
														<a href="/solutions">Treasury</a>
													</li>
													<li>
														<a href="/solutions">Credit Risk</a>
													</li>
													<li>
														<a href="/solutions">FP&A</a>
													</li>
													<li>
														<a href="/solutions">Capital Markets</a>
													</li>
												</ul>
											</div>
											<div
												className="col-sm-5 col-lg-2 resources-footer"
												style={{ marginLeft: 24 }}
											>
												<h5>Resources</h5>
												<ul className="footer_menus">
													<li>
														<a href="/blogs">Fintech Financing</a>
													</li>
													<li>
														<a href="/blogs">Non-bank Lenders</a>
													</li>
													<li>
														<a href="/blogs">Banks</a>
													</li>
												</ul>
											</div>
											<div
												className="col-sm-5 col-lg-2 news-letter-footer"
												style={{ marginLeft: 24 }}
											>
												<div className="row">
													<div className="col">
														<h5
															className="subscribe-title"
															style={{ whiteSpace: 'nowrap' }}
														>
															Subscribe to our Newsletter
														</h5>
													</div>
												</div>
												<form onSubmit={handleSubmit}>
													<input
														className="resources-first-name2"
														type="text"
														placeholder="First name*"
														name="first_name"
														required
														onChange={handleChange}
														value={formData.first_name}
													/>
													<input
														className="resources-last-name2"
														type="text"
														placeholder="Last name*"
														name="last_name"
														required
														onChange={handleChange}
														value={formData.last_name}
														style={{ marginTop: '0.5rem' }}
													/>
													<input
														type="text"
														placeholder="Enter your email*"
														className="resources-email2"
														name="email"
														required
														onChange={handleChange}
														value={formData.email}
													/>
													<button
														type="submit"
														className="resources-email-button2"
														style={{
															width: '125px',
															height: '39px',
															fontSize: '15px',
															borderRadius: '4px',
															marginTop: '0.8rem'
														}}
													>
														Subscribe
													</button>
												</form>
											</div>
										</div>
										<div className="footer_social_media">
											<div className="row">
												<div className="col-sm-2 col-md-1 linkedin-item">
													<div
														onClick={() =>
															window.open(
																'https://www.linkedin.com/company/vmlanalytics/?viewAsMember=true',
																'_blank'
															)
														}
														onMouseEnter={() => setLnClass('linkedinColor')}
														onMouseLeave={() => setLnClass('linkedin')}
														className="footer_item_box"
														style={{ display: 'flex', alignItems: 'center' }}
													>
														<img className={lnClass} alt="" />
													</div>
												</div>
												<div className="col-sm-2 col-md-1 instagram-item">
													<div
														onClick={() =>
															window.open(
																'https://www.instagram.com/vector_mlanalytics/',
																'_blank'
															)
														}
														onMouseEnter={() =>
															setInstagramClass('instagramColor')
														}
														onMouseLeave={() => setInstagramClass('instagram')}
														className="footer_item_box"
														style={{ display: 'flex', alignItems: 'center' }}
													>
														<img className={instagramClass} alt="" />
													</div>
												</div>
												<div className="col-sm-2 col-md-1 twitter-item">
													<div
														onMouseEnter={() => setTwitterClass('twitterColor')}
														onMouseLeave={() => setTwitterClass('twitter')}
														onClick={() =>
															window.open(
																'https://twitter.com/vectormla',
																'_blank'
															)
														}
														className="footer_item_box"
														style={{ display: 'flex', alignItems: 'center' }}
													>
														<img className={twitterClass} alt="" />
													</div>
												</div>
												<div className="col-sm-2 col-md-1 facebook-item">
													<div
														onClick={() =>
															window.open(
																'https://www.facebook.com/Vectormlanalytics2023',
																'_blank'
															)
														}
														onMouseEnter={() => setFbClass('facebookColor')}
														onMouseLeave={() => setFbClass('facebook')}
														className="footer_item_box"
														style={{ display: 'flex', alignItems: 'center' }}
													>
														<img className={fbClass} alt="" />
													</div>
												</div>
												<div className="col-sm-2 col-md-1">
													<div
														onMouseEnter={() => setYtClass('youtubeColor')}
														onMouseLeave={() => setYtClass('youtube')}
														className="footer_item_box youtube-item-box"
														style={{ display: 'flex', alignItems: 'center' }}
														onClick={() =>
															window.open(
																'https://www.youtube.com/@VectorMLAnalytics',
																'_blank'
															)
														}
													>
														<img className={ytClass} alt="" />
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</footer>
						</div>
					</div>
				</div>
			</div>
			<div className="footer_container2">
				<div className="container">
					<section className="request_form_footer">
						<footer>
							<div className="row copyright">
								<div className="col-lg-8">
									<ul style={{ marginLeft: '-30px' }}>
										<li>
											<a
												style={{ color: '#6e6f72' }}
												href="/terms&conditions/1"
											>
												Terms & Conditions
											</a>
										</li>
										<li>
											<a href="/home">Company</a>
										</li>
										<li>
											<a href="/careers">Careers</a>
										</li>
										<li>
											<a href="/securitycommitment">Commitments</a>
										</li>
										<li>
											<a href="/privacypolicy">Privacy Policy</a>
										</li>
									</ul>
								</div>
								<div className="col-lg-4 logo_dark">
									<a href="/">
										<h3 style={{ color: '#0d3756' }}>
											Vector <span className="ind">ML</span> Analytics
										</h3>
										<span className="point"></span>
									</a>
								</div>
								<h6 className="copyright_mobile">
									&#169; 2021 Vector ML Analytics Inc. All rights reserved.
								</h6>
							</div>
						</footer>
					</section>
				</div>
			</div>
		</section>
	);
};

export default MainFooter;
