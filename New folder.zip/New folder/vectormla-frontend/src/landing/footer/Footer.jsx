import React from 'react';
import { useStyles } from './footerStyles';

const Footer = () => {
	const classes = useStyles();

	return (
		<div className={classes.footer}>
			<span className={classes.footer__item}>Loan Valuation</span>
			<span className={classes.footer__item}>Loan Pricing</span>
			<span className={classes.footer__item}>Credit Risk Modelling</span>
			<span className={classes.footer__item}>Prepayment Modelling</span>
			<span className={classes.footer__item}>Asset Liability Management</span>
			<span className={classes.footer__item}>FP&A Reporting</span>
		</div>
	);
};

export default Footer;
