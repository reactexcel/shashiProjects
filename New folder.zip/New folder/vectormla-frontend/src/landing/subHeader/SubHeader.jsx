import React from 'react';
import { withRouter } from 'react-router-dom';

import pc from '../../common/assets/images/pc.svg';
import close from '../../common/assets/images/close.svg';

import { Container, Row, Col, Navbar, Nav } from 'react-bootstrap';

const SubHeader = () => {
	return (
		<div className="subheader">
			<header>
				<Container className="cont">
					<Row noGutters>
						<Col>
							<Navbar expand="xl">
								<Navbar.Brand href="/home">
									<h1>
										Vector <span className="ind">ML</span> Analytics
									</h1>
									<span className="point"></span>
								</Navbar.Brand>
								<Nav.Link href="#" className="search_mobile">
									<button
										data-toggle="modal"
										data-target="#search"
										className="search"
									>
										<i className="fas fa-search"></i>
									</button>
								</Nav.Link>
								<button
									className="navbar-toggler"
									data-toggle="collapse"
									data-target="#navbarSupportedContent"
									aria-controls="navbarSupportedContent"
									aria-expanded="false"
									aria-label="Toggle navigation"
								>
									<i className="fas fa-bars"></i>
								</button>
								<Navbar.Collapse id="navbarSupportedContent">
									<div className="fixed_cont">
										<Navbar.Brand href="/home">
											<h1>
												Vector <span className="ind">ML</span> Analytics
											</h1>
											<span className="point"></span>
										</Navbar.Brand>
										<button
											className="navbar-toggler"
											data-toggle="collapse"
											data-target="#navbarSupportedContent"
											aria-controls="navbarSupportedContent"
											aria-expanded="false"
											aria-label="Toggle navigation"
										>
											<img src={close} alt="" />
										</button>
										<Nav>
											<ul className="navbar-nav">
												<li>
													<Nav.Link href="#">
														<button
															data-toggle="modal"
															data-target="#solutions"
														>
															Solutions
														</button>
													</Nav.Link>
												</li>
												<li>
													<Nav.Link href="#">
														<button data-toggle="modal" data-target="#insight">
															Insights
														</button>
													</Nav.Link>
												</li>
												<li>
													<Nav.Link href="#">
														<button data-toggle="modal" data-target="#support">
															Support
														</button>
													</Nav.Link>
												</li>
												<li className="request_demo">
													<Nav.Link
														href="https://calendly.com/ssafarini"
														target="_blank"
														rel="noreferrer"
													>
														Request Demo
													</Nav.Link>
												</li>
												<li className="login_to_li">
													<Nav.Link href="/login" className="login_to">
														<img src={pc} alt="" />
														Login to Vector <span className="ind">ml</span>
													</Nav.Link>
												</li>
											</ul>
										</Nav>
										{/*<Nav.Link href="#" className="search_desktop">
											<button
												data-toggle="modal"
												data-target="#search"
												className="search"
											>
												<i className="fas fa-search"></i>
												<span>Search</span>
											</button>
										</Nav.Link>*/}
									</div>
								</Navbar.Collapse>
							</Navbar>
						</Col>
					</Row>
				</Container>
			</header>
		</div>
	);
};

export default withRouter(SubHeader);
