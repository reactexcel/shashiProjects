import { makeStyles } from '@material-ui/core';
import {
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader,
	header__save: {
		textTransform: 'capitalize',
		height: 25,
		width: 120,
		marginRight: 5,
		marginLeft: 0,
		color: 'black !important',
		borderRadius: 10,
		border: '12px solid #7991AA',
		backgroundColor: 'red',
		'&:hover': {
			backgroundColor: '#7991AA',
			border: '1px solid #53687E',
			color: 'red !important'
		},
		[theme.breakpoints.down('sm')]: {
			width: 65
		}
	}
}));
