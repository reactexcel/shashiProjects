import Select from '../../../common/components/fields/SelectField';
import TextField from '../../../common/components/fields/TextField';

export const companyFields = [
	{
		name: 'name',
		placeholder: 'Company Name',
		component: TextField,
		type: 'text'
	},
	{
		name: 'description',
		placeholder: 'Company Description',
		component: TextField,
		type: 'text'
	},
	{
		name: 'link',
		type: 'text',
		placeholder: 'Company Link',
		component: TextField
	},
	// {
	// 	name: 'allowed_pages',
	// 	placeholder: 'Select Allowed Pages',
	// 	type: 'multiselect'
	// },
	// {
	// 	name: 'allowed_section1',
	// 	placeholder: 'Select Allowed Treasury Sections',
	// 	type: 'multiselect'
	// },
	// {
	// 	name: 'allowed_section2',
	// 	placeholder: 'Select Allowed Credit Risk Sections',
	// 	type: 'multiselect'
	// },
	// {
	// 	name: 'allowed_section3',
	// 	placeholder: 'Select Allowed FP&A Sections',
	// 	type: 'multiselect'
	// },
	// {
	// 	name: 'allowed_section4',
	// 	placeholder: 'Select Allowed Capital Markets Sections',
	// 	type: 'multiselect'
	// },
	{
		name: 'isActive',
		type: 'select',
		placeholder: 'Status',
		items: [
			{ value: true, label: 'Active' },
			{ value: false, label: 'Inactive' }
		],
		component: Select
	},
	{
		type: 'date'
	}
];

export const adminFields = [
	{
		name: 'first_name',
		placeholder: 'Company Owner First Name',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'last_name',
		placeholder: 'Company Owner Last Name',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'username',
		placeholder: 'Company Owner Username',
		component: TextField,
		typeField: 'admin'
	},
	{
		name: 'email',
		placeholder: 'Company Owner Email',
		component: TextField,
		typeField: 'admin'
	}
];

export const sectionFields = [
	{
		id: 0,
		s_name: 'Home',
		typeList: 'allowed_section0',
		list: [{ id: 0, name: '0' }]
	},
	{
		id: 1,
		s_name: 'Treasury ALM',
		typeList: 'allowed_section1',
		list: [
			{ id: 1, name: '1.1 Loan Pricing' },
			{ id: 2, name: '1.2 Company Valuation' },
			{ id: 3, name: '1.3 Asset Liability Management (ALM)' },
			{ id: 4, name: '1.4 Duration Gap Analysis' },
			{ id: 5, name: '1.5 ALCO Reporting' }
		]
	},
	{
		id: 2,
		s_name: 'Credit Risk',
		typeList: 'allowed_section2',
		list: [
			{ id: 1, name: '2.1 Probability of Default (PD)' },
			{ id: 2, name: '2.2 Loss given default (LGD)' },
			{ id: 3, name: '2.3 Exposure at Default (EAD)' },
			{ id: 4, name: '2.4 Expected Loss (EL)' },
			{ id: 5, name: '2.5 Performance Data & Strats' },
			{ id: 6, name: '2.6 Credit Scorecard' },
			{ id: 7, name: '2.7 Risk-Based Pricing' }
		]
	},
	{
		id: 3,
		s_name: 'Financial Planning and Anlysis(FP&A)',
		typeList: 'allowed_section3',
		list: [
			{ id: 1, name: '3.1 Financial Projections' },
			{ id: 2, name: '3.2 Deposit Modeling' },
			{ id: 3, name: '3.3 Enterprise & Equity Valuation' },
			{ id: 4, name: '3.4 Cash Flow Projections & Analytics' },
			{ id: 5, name: '3.5 Balance Sheet Modeling' },
			{ id: 6, name: '3.6 Prepayment Analysis' }
			// { id: 3, name: '3.3 Loan Pricing' }
		]
	},
	{
		id: 4,
		s_name: 'Capital Markets',
		typeList: 'allowed_section4',
		list: [
			{ id: 1, name: '4.1 Securitization Reporting' },
			{ id: 2, name: '4.2 Data Set Tapes' },
			{ id: 3, name: '4.3 Portfolio Surveillance' }
		]
	}
];

export const tabsFields = [
	{
		id: 1,
		s_name: 'Treasury ALM',
		typeList: 'allowed_section1',
		list: [
			// { id: 101, name: '1.1.1', link: '/app/cashflow' },
			// { id: 102, name: '1.1.2 Cashflow', link: '/app/cashflow2' },
			// { id: 103, name: '1.1.3', link: '/app/default' },
			// { id: 104, name: '1.1.4', link: '/app/cashflow4' },
			// { id: 108, name: '1.1.8', link: '/app/prepayment' },
			{ id: 104, name: '1.1.8', link: '/app/1-1-8' },
			{ id: 111, name: '5.1.1.0', link: '/app/5-1-1-0' },
			{ id: 105, name: '5.1.1', link: '/app/5-1-1' },
			{ id: 109, name: '6.1.1', link: '/app/6-1-1' },
			{ id: 110, name: '9.1.1', link: '/app/9-1-1' }
		]
	},
	{
		id: 2,
		s_name: 'Credit Risk',
		typeList: 'allowed_section2',
		list: [
			{ id: 201, name: '1.2.1', link: '/app/crm' },
			{ id: 202, name: '1.2.2', link: '/app/crm2' },
			{ id: 206, name: '1.2.3', link: '/app/1-2-3' },
			// { id: 208, name: '1.2.8', link: '/app/1-2-8' },
			{ id: 207, name: '3.2.1', link: '/app/3-2-1' },
			{ id: 208, name: '5.2.1.0', link: '/app/5-2-1-0' },
			{ id: 203, name: '5.2.1', link: '/app/5-2-1' },
			{ id: 204, name: '6.2.1', link: '/app/6-2-1' },
			{ id: 205, name: '9.2.1', link: '/app/9-2-1' }
		]
	},
	{
		id: 3,
		s_name: 'Financial Planning and Analysis (FP&A)',
		typeList: 'allowed_section3',
		list: [
			{ id: 301, name: '1.3.1', link: '/app/fpna' },
			{ id: 313, name: '1.3.2', link: '/app/fpna-1-3-2' },
			{ id: 302, name: '2.3.1', link: '/app/fpna-2' },
			{ id: 303, name: '3.3.1', link: '/app/fpna-3' },
			{ id: 314, name: '3.3.2', link: '/app/fpna-3-3-2' },
			// { id: 308, name: '3.3.2', link: '/app/fpna-3-2' },
			{ id: 304, name: '4.3.1', link: '/app/fpna-4' },
			{ id: 315, name: '5.3.1.0', link: '/app/fpna-5-3-1-0' },
			{ id: 305, name: '5.3.1', link: '/app/fpna-5' },
			// { id: 310, name: '5.3.2', link: '/app/fpna-5-2' },
			{ id: 306, name: '6.3.1', link: '/app/fpna-6-3-1' },
			// { id: 309, name: '6.3.2', link: '/app/fpna-6-2' },
			{ id: 311, name: '9.3.1', link: '/app/fpna-9-3-1' },
			// { id: 312, name: '9.3.2', link: '/app/fpna-9-2' },
			{ id: 307, name: 'FP&A 0', link: '/app/fpna-0' }
		]
	},
	{
		id: 4,
		s_name: 'Capital Markets',
		typeList: 'allowed_section4',
		list: [
			{ id: 401, name: '1.4.1', link: '/app/securitization' },
			// { id: 402, name: '5.4.1', link: '/app/5-4-1' },
			{ id: 403, name: '6.4.1', link: '/app/6-4-1' },
			{ id: 404, name: '9.4.1', link: '/app/9-4-1' }
		]
	},
	{
		id: 5,
		s_name: 'Library',
		typeList: 'allowed_section5',
		list: [{ id: 501, name: 'Academy', link: '/app/academy' }]
	},
	{
		id: 6,
		s_name: 'DashBoard',
		typeList: 'allowed_section6',
		list: [{ id: 601, name: 'Dashboard', link: '/app/dashboard' }]
	}
];

export const AllowedModelsFields = [
	{
		id: 1,
		s_name: 'Treasury ALM',
		typeList: 'allowed_section1'
	},
	{
		id: 2,
		s_name: 'Credit Risk',
		typeList: 'allowed_section2'
	},
	{
		id: 3,
		s_name: 'Financial Planning and Anlysis(FP&A)',
		typeList: 'allowed_section3'
	},
	{
		id: 4,
		s_name: 'Capital Markets',
		typeList: 'allowed_section4'
	},
	{
		id: 5,
		s_name: 'Library',
		typeList: 'allowed_section5'
	},
	{
		id: 6,
		s_name: 'DashBoard',
		typeList: 'allowed_section6'
	}
];
