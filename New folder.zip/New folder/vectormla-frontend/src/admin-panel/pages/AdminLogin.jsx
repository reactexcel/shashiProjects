import React, { useState } from 'react';
import { withRouter } from 'react-router-dom';
import { adminLogin } from '../services';
// styles
import home from '../../common/assets/images/home-slider1.svg';
import desktop from '../../common/assets/images/desktop.svg';
const AdminLogin = ({ history }) => {
	document.body.classList.add('full');

	const [email, setEmail] = useState(null);
	const [password, setPassword] = useState(null);

	const submit = (e) => {
		e.preventDefault();

		adminLogin({ email, password }, () => {
			history.push({
				pathname: '/adminpanel/home'
			});
		});
	};

	return (
		<div className="login" style={{ marginTop: '8%' }}>
			<section className="sign_up">
				<div className="container cont">
					<div className="row cont_sign">
						<div className="col-md-6 col-lg-5 left">
							<div className="title_block">
								<h3>
									<span className="static">Log into </span>
									<span className="static blue">Vector Admin Panel</span>
									<span className="ind">ML</span>
								</h3>
								<img src={desktop} alt="" />
							</div>
							<p className="info">
								You will need your corporate credentials to log in
							</p>
							<form onSubmit={submit}>
								<div className="form_control">
									<label label="email">Login name</label>
									<input
										onChange={(e) => setEmail(e.target.value)}
										type="text"
										name="email"
										id="email"
									/>
								</div>
								<div className="form_control">
									<label label="password">Password</label>
									<input
										onChange={(e) => setPassword(e.target.value)}
										type="password"
										name="password"
										id="password"
									/>
								</div>
								<button type="submit">{'Login'}</button>
							</form>
							<a href="#">Forgot login name?</a>
							<a href="#">Forgot password?</a>
						</div>
						<div className="col-md-6 col-lg-7 right">
							<img src={home} className="img-fluid" alt="" />
							<div
								style={{
									width: 100,
									height: 100,
									marginLeft: 270,
									position: 'absolute'
								}}
								onClick={() =>
									history.push({
										pathname: '/login'
									})
								}
							/>
						</div>
					</div>
				</div>
				<div className="footer-access-text">
					<div className="container-fluid access_text">
						<div className="row">
							<div className="col">
								<p>
									Access the Vector <span className="ind">ML</span> Platform
									wherever you are. Vector <span className="ind">ML</span> keeps
									you connected from virtually anywhere, from any device
								</p>
							</div>
						</div>
					</div>
					<div className="container light_copyright">
						<div className="row">
							<div className="col">
								<h6>
									Copyright 2021 Vector <span className="ind">ML</span>Analytics
									Inc All rights reserved.
								</h6>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default withRouter(AdminLogin);
