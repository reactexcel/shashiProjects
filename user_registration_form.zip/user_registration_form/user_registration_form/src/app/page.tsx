export default function Home() {
  return <main><p>hello</p></main>;
}
