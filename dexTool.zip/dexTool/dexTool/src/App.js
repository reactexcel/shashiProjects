import React from 'react';
import './App.css';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import { Pages } from './Utils/Pages';
import Wallet from './Components/Pages/Wallet';
import MultiChart from './Components/Pages/MultiChart';
import NewPares from './Components/Pages/NewPares';
import { ChakraProvider } from '@chakra-ui/react';
import MainLayouts from './Layouts/MainLayouts';
import Dashboard from './Components/Pages/Dashboard';
const router = createBrowserRouter([
  {
    path: Pages.NEWPARSE,
    element: <MainLayouts />,
    children: [
      {
        path: Pages.DASHBOARD,
        element: <Dashboard />
      },
      {
        path: Pages.NEWPARSE,
        element: <NewPares />
      },
      {
        path: Pages.MULTICHART,
        element: <MultiChart />
      },
      {
        path: Pages.WALLET,
        element: <Wallet />,
        exact: true
      },
    
      
    ]
  },

]);

function App() {
  return (
    <React.Fragment>
      <ChakraProvider >
        <RouterProvider router={router} />
      </ChakraProvider>
    </React.Fragment>
  );
}

export default App;
