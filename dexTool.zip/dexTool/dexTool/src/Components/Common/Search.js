import React, { useState } from "react";
import { Input, IconButton, Stack, InputGroup, InputRightElement, useColorModeValue } from "@chakra-ui/react";
import { SearchIcon } from "@chakra-ui/icons";

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    console.log("Search Query:", searchQuery);
  };
  const searchIcon = useColorModeValue("#161A1E", "#fff")
  return (
    <Stack direction="row" px={5} width="100%">
      <InputGroup width="100%">
        <Input
          placeholder="Searh by token name, symbol or address"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          _focus={{ border: "none" }}
        />
        <InputRightElement width="3rem">
          <IconButton
            bg="none"
            _hover="none"
            _active="none"
            aria-label="Search"
            icon={<SearchIcon sx={{ _hover: { color: searchIcon } }} />}
            onClick={handleSearch}
          />
        </InputRightElement>
      </InputGroup>
    </Stack>
  );
};

export default SearchBar;
