import React from "react";
import { NavLink } from "react-router-dom";
import { IoMdMenu } from 'react-icons/io'
import { Box, Image, Link, ListItem, UnorderedList, useColorModeValue, useDisclosure } from "@chakra-ui/react";
import SearchBar from "../Search";
import { Slider } from "../Drawer/Slider";
import { Connect } from "../Wallet/Connect";

function NavBar() {

  const { isOpen, onOpen, onClose } = useDisclosure()
  const navBg = useColorModeValue("#fff", "#1D232E")
  const logoColor=useColorModeValue("#000","#fff")
  return (
    <>
      <Box height="10vh" bg={navBg} px={5} py={2} sx={{ display: "flex", alignItems: "center" }}>
        <Link sx={{color:logoColor,fontWeight:"bold",fontSize:"1.6rem",textDecoration:"none",_hover:{textDecoration:"none"}}}>
         <NavLink  to="/"> DEXTools</NavLink>
        </Link>
        <Box px={10} width={{ base: "100%", md: "50%" }}>
          <SearchBar />
        </Box>
        <Box>
          <UnorderedList gap={{sm:5, md:8,lg:10}} fontSize={{ sm: "sm" }} listStyleType="none" sx={{ display:{base:"none",md:"flex"}, alignItems: "center", fontWeight: "700" }} >
            <ListItem >
              <NavLink
                activeClassName="active"
              >
                Docs
              </NavLink>
            </ListItem>
            <ListItem >
              <NavLink
                activeClassName="active"
              >
                Advertise
              </NavLink>
            </ListItem>
            <ListItem >
              <NavLink
                to="/pairs"
                activeClassName="active"
              >
                NewPares
              </NavLink>
            </ListItem>
            <ListItem >
              <NavLink
                to="/multichart"
                activeClassName="active"
              >
                MultiChart
              </NavLink>
            </ListItem>
            <ListItem >
              <NavLink
                to="/wallet"
                activeClassName="active"
              >
                Wallet
              </NavLink>
            </ListItem>
            <ListItem>
              <Connect />
            </ListItem>
          </UnorderedList>
        </Box>
        <Box className="nav-icon" p={1} borderRadius={5} sx={{display:{base:"block",md:"none"},border:"3px solid darkgray",_hover:{border:"3px solid gray"},}}>
          <IoMdMenu onClick={onOpen} fontSize="1.6rem" />
          <Slider isOpen={isOpen} onClose={onClose} />
        </Box>
      </Box>
    </>
  );
}

export default NavBar;