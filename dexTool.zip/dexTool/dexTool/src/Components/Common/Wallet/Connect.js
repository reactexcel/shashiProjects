import { Button, Modal, ModalBody, ModalCloseButton, ModalOverlay, useDisclosure, ModalContent, ModalHeader, List, ListItem, useColorModeValue, } from "@chakra-ui/react"
import { BsWalletFill } from "react-icons/bs"
export const Connect = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const modalListbg = useColorModeValue("#E2E8F5", "#4f5765")
  return (
    <>
      <Button onClick={onOpen} sx={{ fontWeight:"700" }} width={{base:"100%"}}> <BsWalletFill /><span style={{paddingLeft:"5px"}}>Connect</span></Button>

      <Modal closeOnOverlayClick={false} isOpen={isOpen} onClose={onClose}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader fontWeight="500">Connect to wallet</ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <List sx={{ fontWeight: "bold" }} spacing={5}>
              <ListItem bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#7F8090" }, transition: ".5s" }}>
                Metamsk
              </ListItem>
              <ListItem bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#7F8090" }, transition: ".5s" }}>
                Coinbase Wallet
              </ListItem>
              <ListItem bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#7F8090" }, transition: ".5s" }}>
                Trust Wallet
              </ListItem>
              <ListItem bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#7F8090" }, transition: ".5s" }}>
                WalletConnect
              </ListItem>
              <ListItem bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#7F8090" }, transition: ".5s" }}>
                SafePal
              </ListItem>
            </List>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  )
}
