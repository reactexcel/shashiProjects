import React, {useState } from 'react'
import { NavLink } from 'react-router-dom'
import { Box, UnorderedList, ListItem, Text, useColorModeValue, useColorMode, OrderedList, Link } from '@chakra-ui/react'
import { BiWallet, BiSolidLeaf } from 'react-icons/bi'
import { RiAdvertisementFill } from 'react-icons/ri'
import { BsFiletypeDocx } from 'react-icons/bs'
import { AiOutlineMenuFold, AiOutlineMenuUnfold } from 'react-icons/ai'
import { HiInformationCircle, HiSun, HiMoon, } from 'react-icons/hi'
import { FaEthereum, FaTwitter, FaTelegramPlane } from 'react-icons/fa'



const SideBar = () => {
    const { toggleColorMode } = useColorMode();
    const sidebarbg = useColorModeValue('gray.100', 'gray.700');
    const [open, setOpen] = useState(false);
    const toggleMenu = () => {
        setOpen(!open);
    };

    const boxBg = useColorModeValue("gray.400", "gray.800")

    return (
        <Box bg={sidebarbg} w="100%" display={{ base: "none", md: "block" }}>
            <Box height="90vh">
                <UnorderedList className='container' pt={1} pr={3} listStyleType="none" fontSize={{ sm: "md" }} fontWeight="700" overflow="auto" >
                    <ListItem pb={2} onClick={toggleMenu} display="flex" justifyContent="center" alignItems="center" fontWeight="500" borderBottom="1px solid lightgray">
                        <Text display={open ? "block" : "none"} sx={{ transition: ".5s" }} pr={20}>Chains</Text>
                        {
                            open ? (
                                <AiOutlineMenuFold fontSize="1.3rem" />
                            ) : (
                                <AiOutlineMenuUnfold fontSize="1.3rem" />
                            )
                        }
                    </ListItem>
                    <ListItem mt={1} p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s", }}>
                        <NavLink style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BsFiletypeDocx fontSize="1.3rem" color='orange' /> <Text fontSize="14px" display={open ? "block" : "none"}> Docs</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <RiAdvertisementFill fontSize="1.3rem" color='blue' />  <Text fontSize="14px" display={open ? "block" : "none"}>Advertise</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/pairs" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiSolidLeaf fontSize="1.3rem" color='#0ecb81' /> <Text fontSize="14px" display={open ? "block" : "none"}>NewPairs</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Wallet</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <HiInformationCircle fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Last Updated</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <FaEthereum fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Ethereum Mainnet</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>BNB Chain</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Arbitrum One</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Polygon</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>PulseChain</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>BitRock</Text>
                        </NavLink>
                    </ListItem>
                    <ListItem p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                        <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <BiWallet fontSize="1.3rem" color='brown' /> <Text fontSize="14px" display={open ? "block" : "none"}>Shibarium</Text>
                        </NavLink>
                    </ListItem>
                </UnorderedList>
                <OrderedList pt={1} pr={3} listStyleType="none" borderTop="1px solid lightgray" fontWeight="500"  >
                    <ListItem px={2} py={1}>
                        <Link style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <FaTelegramPlane fontSize="1.3rem" color='#0088cc' /> <Text fontSize="12px" display={open ? "block" : "none"}>Telegram</Text>
                        </Link>
                    </ListItem>
                    <ListItem px={2} py={1} style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <Link style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                            <FaTwitter fontSize="1.3rem" color='#00acee' /> <Text fontSize="12px" display={open ? "block" : "none"}>Twitter</Text>
                        </Link>
                    </ListItem>
                    <ListItem px={2} mt={2}>
                        <HiSun onClick={toggleColorMode} color='lightgray' fontSize="1.5rem" />
                    </ListItem>
                    <ListItem px={2}>
                        <HiMoon onClick={toggleColorMode} color="#000" fontSize="1.5rem" />
                    </ListItem>
                </OrderedList>
            </Box>

        </Box>
    )
}

export default SideBar
