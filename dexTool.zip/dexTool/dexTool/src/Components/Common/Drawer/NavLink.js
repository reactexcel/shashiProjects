import React from 'react'
import { NavLink } from "react-router-dom";
import { Box, ListItem, Text, UnorderedList, useColorModeValue, } from "@chakra-ui/react";
import { Connect } from '../Wallet/Connect';
import { BiWallet, BiSolidLeaf } from 'react-icons/bi'
import { RiAdvertisementFill } from 'react-icons/ri'
import { BsFiletypeDocx } from 'react-icons/bs'

const NavLinks = ({ onClose }) => {

    const modalListbg = useColorModeValue("#fff", "#E2E8F5")
    return (
        <Box>
            <Box p={2} gap={2} sx={{ borderTop: "1px solid #e2e8f0", textAlign: "center", }}>
                <Connect />
            </Box>
            <UnorderedList pr={3} listStyleType="none" fontSize={{ sm: "md" }} fontWeight="700">
                <ListItem onClick={onClose} width="100%" mt={2} bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { color: "#7500ff" }, transition: ".5s", display: "flex", justifyContent: "center", borderBottom: "1px solid #e2e8f0" }}>
                    <NavLink to="/multichart" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <Text> MultiChart</Text>
                    </NavLink>
                </ListItem>
                <ListItem onClick={onClose} mt={1} bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s", }}>
                    <NavLink style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <BsFiletypeDocx fontSize="1.4rem" color='orange' /> <Text> Docs</Text>
                    </NavLink>
                </ListItem>
                <ListItem onClick={onClose} bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                    <NavLink style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <RiAdvertisementFill fontSize="1.4rem" color='blue' />  <Text>Advertise</Text>
                    </NavLink>
                </ListItem>
                <ListItem onClick={onClose} bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                    <NavLink to="/pairs" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <BiSolidLeaf fontSize="1.4rem" color='#0ecb81' /> <Text>New Pairs</Text>
                    </NavLink>
                </ListItem>
                <ListItem onClick={onClose} bg={modalListbg} p={2} borderRadius={5} sx={{ _hover: { background: "#E2E8F5" }, transition: ".5s" }}>
                    <NavLink to="/wallet" style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                        <BiWallet fontSize="1.4rem" color='brown' /> <Text>Wallet</Text>
                    </NavLink>
                </ListItem>
            </UnorderedList>
        </Box>
    )
}

export default NavLinks
