import React from "react"
import { Drawer, DrawerBody, DrawerOverlay, DrawerContent, DrawerCloseButton, DrawerHeader, Box } from "@chakra-ui/react"
import NavLinks from "./NavLink"

export const Slider = ({onClose,isOpen}) => {
   
    return (
        <>
        <Box>
            <Drawer  onClose={onClose} isOpen={isOpen} size="xs">
                <DrawerOverlay />
                <DrawerContent>
                    <DrawerCloseButton />
                    <DrawerHeader  sx={{color:"#000",fontWeight:"bold",fontSize:"1.6rem",}}>DEXView</DrawerHeader>
                    <DrawerBody p={0}>
                     <NavLinks onClose={onClose}/>
                    </DrawerBody>
                </DrawerContent>
            </Drawer>
            </Box>
        </>
    )
}