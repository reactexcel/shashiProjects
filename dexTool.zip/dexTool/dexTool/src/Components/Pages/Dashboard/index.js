import { Box } from '@chakra-ui/react';
import React from 'react'
import ChartTable from '../../Table/ChartTable';
import DashboardNav from '../../Common/DashboardNav';

const Dashboard = () => {
  return (
    <Box>
    <DashboardNav/>
      <ChartTable />
    </Box>
  )
}

export default Dashboard;
