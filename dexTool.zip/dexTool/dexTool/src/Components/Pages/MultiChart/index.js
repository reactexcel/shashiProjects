import React from 'react'

function MultiChart() {
  return (
    <div>
    MultiChart
    </div>
  )
}

export default MultiChart
