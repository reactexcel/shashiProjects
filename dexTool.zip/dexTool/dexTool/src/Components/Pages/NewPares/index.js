import React from 'react'

function NewPares() {
  return (
    <div>
    NewPares
    </div>
  )
}

export default NewPares
