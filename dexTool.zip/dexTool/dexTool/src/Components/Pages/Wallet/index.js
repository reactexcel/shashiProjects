import React from 'react'

function Wallet() {
  return (
    <div>
    Wallet
    </div>
  )
}

export default Wallet
