import React from 'react'
import {
    Box,
    Table,
    Thead,
    Tbody,
    Tr,
    Th,
    Td,
    TableContainer,
    useColorModeValue,
} from '@chakra-ui/react'

const ChartTable = () => {
    const tableTextColor=useColorModeValue("gray.600","gray.400")
    const tableBg=useColorModeValue("gray.100","gray.200")
    return (
        <Box mt={2}>
            <TableContainer  className='container'>
                <Table variant='simple'>
                    <Thead bg="#edf2f7">
                        <Tr  bg="#edf2f0">
                            <Th sx={{  position: "sticky", left: "0",zIndex:"1000", }}>TOKEN</Th>
                            <Th>PRICE</Th>
                            <Th>TXNS</Th>
                            <Th>VOLUME</Th>
                            <Th>5M</Th>
                            <Th>1H</Th>
                            <Th>6H</Th>
                            <Th>24H</Th>
                            <Th>LIQUIDITY</Th>
                            <Th>FDV</Th>
                        </Tr>
                    </Thead>
                    <Tbody bg={tableBg} color={tableTextColor}>
                        <Tr>
                            <Td sx={{  position: "sticky", left: "0",zIndex:"1000" }} bg="#fff">inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                        </Tr>
                        <Tr>
                        <Td sx={{position: "sticky", left: "0",zIndex:"1000" }} bg="#fff">inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                        </Tr>
                        <Tr>
                        <Td sx={{  flexDirection: "row", position: "sticky", left: "0",zIndex:"1000" }} bg="#fff">inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                        </Tr>
                        <Tr>
                        <Td sx={{ flexDirection: "row", position: "sticky", left: "0",zIndex:"1000" }} bg="#fff">inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                        </Tr>
                        <Tr>
                        <Td sx={{ flexDirection: "row", position: "sticky", left: "0",zIndex:"1000" }} bg="#fff">inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                            <Td>millimetres (mm)</Td>
                            <Td>25.4</Td>
                            <Td>inches</Td>
                        </Tr>
                    </Tbody>
                </Table>
            </TableContainer>
        </Box>
    )
}

export default ChartTable
