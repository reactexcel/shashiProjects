import React from 'react'
import { Box, Grid, GridItem, useColorModeValue, } from '@chakra-ui/react';
import { Outlet } from 'react-router-dom';
import NavBar from '../Components/Common/Navbar/NavBar';
import SideBar from '../Components/Common/Drawer/SideBar';
import Navbar2 from '../Components/Common/Navbar2';
function MainLayouts() {

    const Boxbg = useColorModeValue("gray.200", "");

    return (
        <Box
            sx={{
                height: "100vh",
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
                position: "relative",
            }}
        >
            <NavBar />
            <Navbar2 />
            <Grid sx={{ display: 'flex', flexWrap: "nowrap", overflow: 'hidden', height: "90vh", }} >
                <GridItem >
                    <SideBar/>
                </GridItem>
                <GridItem p={2} className='example' bg={Boxbg} sx={{ flexGrow: 1, overflow: "auto", height: "90vh" }}>
                    <Outlet />
                </GridItem>
            </Grid>


        </Box>
    )
}

export default MainLayouts
