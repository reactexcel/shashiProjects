# Server for cryptoEver


To run:
first, enter "npm install" on the terminal of the root.
 second, open "client" folder and enter "npm install" on the terminal there again.
 after installing node packages, enter "npm run dev" in the terminal of the root.
# cryptoever-api-express
