export const LOGIN_SUCCESS = 'LOGIN_SUCCESS';
export const LOGOUT_USER = 'LOGOUT_USER';
export const FETCH_PRICES = 'FETCH_PRICES';
export const GET_BALANCES = 'GET_BALANCES';
