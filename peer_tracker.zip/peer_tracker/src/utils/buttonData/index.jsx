export const buttonData = [
    { id: "1", value: "TSR File" },
    { id: "2", value: "Peer TSRs" },
    { id: "3", value: "Historical TSR" },]