export const footerNav = [
  [
    { id: "1", name: "Summary", link: "/" },
    { id: "2", name: "FY2023 Award", link: "/FY2023Award" },
    { id: "3", name: "FY2022 Award", link: "/FY2022Award" },
    { id: "4", name: "FY2021 Award", link: "/FY2021Award" },
    { id: "5", name: "Historical Awards", link: "/HistoricalAwards" },
  ],

  // [
  //   { id: "1", name: "First Link", link: "#" },
  //   { id: "2", name: "Second Link", link: "#" },
  //   { id: "3", name: "Third Link", link: "#" },
  //   { id: "4", name: "Fourth Link", link: "#" },
  // ],

  // [
  //   { id: "1", name: "First Link", link: "#" },
  //   { id: "2", name: "Second Link", link: "#" },
  //   { id: "3", name: "Third Link", link: "#" },
  //   { id: "4", name: "Fourth Link", link: "#" },
  // ],

  // [
  //   { id: "1", name: "First Link", link: "#" },
  //   { id: "2", name: "Second Link", link: "#" },
  //   { id: "3", name: "Third Link", link: "#" },
  //   { id: "4", name: "Fourth Link", link: "#" },
  // ],
];
