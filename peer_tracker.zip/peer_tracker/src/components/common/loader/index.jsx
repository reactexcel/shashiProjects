import styles from "../loader/loader.module.css"


const Loader = () => {
    return (
        <div className={styles.loader}></div>
    )
}

export default Loader

