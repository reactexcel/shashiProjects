import { useEffect, useState } from 'react';
import {jwtDecode} from 'jwt-decode';

export const account = {
  displayName: 'Jaydon Frankie',
  email: '', // Leave email empty initially
  photoURL: '/assets/images/avatars/avatar_25.jpg',
};

export default function AccountComponent() {
  const [userEmail, setUserEmail] = useState('');

  useEffect(() => {
    // Retrieve access token from localStorage
    const accessToken = localStorage.getItem('accessToken');

    if (accessToken) {
      try {
        // Decode the access token to extract user information
        const decodedToken = jwtDecode(accessToken);
        // Extract user email from decoded token
        const { email } = decodedToken;
        // Set the user email in state
        setUserEmail(email);
      } catch (error) {
        console.error('Error decoding access token:', error);
      }
    }
  }, []);

  // Update account object with fetched user email
  useEffect(() => {
    account.email = userEmail;
  }, [userEmail]);

  return null; // Since AccountComponent doesn't render anything, return null
}
