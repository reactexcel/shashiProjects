import React, { useState } from 'react';
import 'src/global.css';
import { useScrollToTop } from 'src/hooks/use-scroll-to-top';
import Router from 'src/routes/sections';
import ThemeProvider from 'src/theme';
import { PropertiesProvider } from './PropertiesContext'; // Import the PropertiesProvider context

// ----------------------------------------------------------------------

export default function App() {
  useScrollToTop();
  const [properties, setProperties] = useState([]); // Initialize properties state

  return (
    <ThemeProvider>
      <PropertiesProvider value={{ properties, setProperties }}> {/* Wrap the Router with PropertiesProvider */}
        <Router />
      </PropertiesProvider>
    </ThemeProvider>
  );
}
