import { useState } from 'react';
import axios from 'axios'; // Import Axios for making HTTP requests

import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import Stack from '@mui/material/Stack';
import Divider from '@mui/material/Divider';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import LoadingButton from '@mui/lab/LoadingButton';
import { alpha, useTheme } from '@mui/material/styles';
import InputAdornment from '@mui/material/InputAdornment';

import { useRouter } from 'src/routes/hooks'; // Ensure this is the correct path to your useRouter hook

import { bgGradient } from 'src/theme/css'; // Ensure this is the correct path to your bgGradient function

import Logo from 'src/components/logo'; // Ensure this is the correct path to your Logo component
import Iconify from 'src/components/iconify'; // Ensure this is the correct path to your Iconify component

export default function RegisterView() {
  const theme = useTheme();
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setErrorMsg(null);
  
    const formData = new FormData(event.target);
    const data = {
      uuid: formData.get('uuid'),
      first_name: formData.get('first_name'),
      last_name: formData.get('last_name'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      password: formData.get('password'),
      role: 'buyer' // Assuming 'seller' as the default role, change as needed
    };
  
    try {
      const response = await axios.post('http://155.138.160.153:5099/api/user/register', data);
      if (response && response.data && response.data.message) {
        // Assuming successful registration response includes a message
        sessionStorage.setItem('userInfo', JSON.stringify(response.data));
        router.push('/verif'); // Change to the appropriate route after successful registration
      } else {
        throw new Error('Registration failed without a server message.');
      }
    } catch (error) {
      // Improved error handling
      const errorMessage = error.response && error.response.data && error.response.data.error
        ? error.response.data.error
        : 'Registration failed due to an unexpected error.';
      setErrorMsg(errorMessage);
    } finally {
      setLoading(false);
    }
  };
  

  return (
    <Box
      sx={{
        ...bgGradient({
          color: alpha(theme.palette.background.default, 0.9),
          imgUrl: '/assets/background/overlay_4.jpg',
        }),
        height: 1,
      }}
    >
      <Logo
        sx={{
          position: 'fixed',
          top: { xs: 16, md: 24 },
          left: { xs: 16, md: 24 },
        }}
      />

      <Stack alignItems="center" justifyContent="center" sx={{ height: 1 }}>
        <Card
          sx={{
            p: 5,
            width: 1,
            maxWidth: 420,
          }}
        >
          <Typography variant="h4">Register to Minimal</Typography>

          <Typography variant="body2" sx={{ mt: 2, mb: 5 }}>
          Don&apos;t have an account?
            <Link variant="subtitle2" sx={{ ml: 0.5 }}>
              Register now
            </Link>
          </Typography>

          <Divider sx={{ my: 3 }}>
            <Typography variant="body2" sx={{ color: 'text.secondary' }}>
              AND
            </Typography>
          </Divider>

          <form onSubmit={handleSubmit}>
            <Stack spacing={3}>
            <TextField name="uuid" label="User ID" /> {/* Add this line for user_id */}

              <TextField name="first_name" label="First Name" />
              <TextField name="last_name" label="Last Name" />
              <TextField name="email" label="Email address" />
              <TextField name="phone" label="Phone" />
              <TextField
                name="password"
                label="Password"
                type={showPassword ? 'text' : 'password'}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => setShowPassword(!showPassword)} edge="end">
                        <Iconify icon={showPassword ? 'eva:eye-fill' : 'eva:eye-off-fill'} />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Stack>

            <LoadingButton
              fullWidth
              size="large"
              type="submit"
              variant="contained"
              color="inherit"
              loading={loading}
              sx={{ mt: 3 }}
            >
              Register
            </LoadingButton>
          </form>

          {errorMsg && (
            <Typography variant="body2" sx={{ mt: 2, color: 'error.main' }}>
              {errorMsg}
            </Typography>
          )}
        </Card>
      </Stack>
    </Box>
  );
}
