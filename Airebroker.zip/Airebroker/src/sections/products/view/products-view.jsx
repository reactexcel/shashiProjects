import React, { useState, useEffect } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import Stack from '@mui/material/Stack';
import Container from '@mui/material/Container';
import Grid from '@mui/material/Unstable_Grid2';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Link from '@mui/material/Link';
import Card from '@mui/material/Card';
import Modal from '@mui/material/Modal';
import { fCurrency } from 'src/utils/format-number';
import Iconify from 'src/components/iconify';
import ProductSort from '../product-sort';
import ProductFilters from '../product-filters';

export default function ProductsView() {
  const [openFilter, setOpenFilter] = useState(false);
  const [properties, setProperties] = useState([]);
  const [openNewPropertyModal, setOpenNewPropertyModal] = useState(false);
  const [formData, setFormData] = useState({
    address: '',
    baths: 0,
    beds: 0,
    city: '',
    description: '',
    images: [],
    kitchen: 0,
    latitude: 0,
    longitude: 0,
    name: '',
    owner_bio: '',
    owner_email: '',
    owner_name: '',
    owner_number: '',
    owner_profile: '',
    price: 0,
    property_id: '',
    property_type: 0,
    seller_id: '',
    size: 0,
    state: '',
    status: '',
  });

  const [currentPanel, setCurrentPanel] = useState(1);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserProperties = async () => {
      try {
        const accessToken = sessionStorage.getItem('accessToken');
        if (!accessToken) {
          console.error('Access token not found');
          return;
        }

        const profileResponse = await fetch('http://155.138.160.153:5099/api/user/profile', {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        if (!profileResponse.ok) {
          throw new Error('Failed to fetch user profile');
        }

        const profileData = await profileResponse.json();
        const role = profileData.role;

        let apiEndpoint = 'http://155.138.160.153:5099/api/user/properties/list';
        if (role === 'buyer') {
          apiEndpoint = 'http://155.138.160.153:5099/api/users/buyers/properties';
        }

        const response = await fetch(apiEndpoint, {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch properties');
        }

        const data = await response.json();
        setProperties(data);

        // Set property_id and seller_id from fetched data
        if (data.length > 0) {
          setFormData({
            ...formData,
            property_id: data[0].property_id,
            seller_id: data[0].seller_id,
          });
        }
      } catch (error) {
        console.error(error);
      }
    };

    fetchUserProperties();
  }, []);

  const handleOpenNewPropertyModal = () => {
    setOpenNewPropertyModal(true);
    setCurrentPanel(1);
  };

  const handleCloseNewPropertyModal = () => {
    setOpenNewPropertyModal(false);
  };

  const handleChange = (key, value) => {
    setFormData({
      ...formData,
      [key]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Submit logic here
  };

  const handleNextPanel = () => {
  
    
    setCurrentPanel(currentPanel + 1);
  };
  

  const handlePreviousPanel = () => {
    setCurrentPanel(currentPanel - 1);
  };

  const navigateToChatPage = async (seller_id, name, price, property_id) => {
    try {
      const accessToken = sessionStorage.getItem('accessToken');
      if (!accessToken) {
        throw new Error('Access token not found');
      }
  
      const addBuyerResponse = await fetch('http://155.138.160.153:5099/api/users/buyers/add', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          property_id,
          seller_id,
        }),
      });
  
      if (!addBuyerResponse.ok) {
        throw new Error('Failed to add buyer');
      }
  
      // If buyer is successfully added, log the success message
      console.log('Buyer added successfully to seller');
  
      // Navigate to the chat page
      navigate('/home/chat', {
        state: {
          seller_id,
          name,
          price,
          property_id,
        },
      });
    } catch (error) {
      console.error(error);
      // Handle error appropriately (e.g., show error message)
    }
  };
  
  
  const totalPanels = 2;

  return (
    <Container>
      <Stack direction="row" alignItems="center" justifyContent="space-between" mb={5}>
        <Typography variant="h4">Properties</Typography>
        <Button
          variant="contained"
          color="inherit"
          startIcon={<Iconify icon="eva:plus-fill" />}
          onClick={handleOpenNewPropertyModal}
        >
          New Property
        </Button>
      </Stack>

      <Modal
        open={openNewPropertyModal}
        onClose={handleCloseNewPropertyModal}
        aria-labelledby="new-property-modal-title"
      >
        <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 400, bgcolor: 'background.paper', boxShadow: 24, p: 4 }}>
          <Typography id="new-property-modal-title" variant="h6" component="h2" gutterBottom>
            Add New Property
          </Typography>
          <form onSubmit={handleSubmit}>
            {currentPanel === 1 && (
              <Box>
                <TextField
                  required
                  fullWidth
                  label="Address"
                  value={formData.address}
                  onChange={(e) => handleChange('address', e.target.value)}
                />
                {/* Add other fields for the first panel */}
              </Box>
            )}
            {currentPanel === 2 && (
              <Box>
                <TextField
                  required
                  fullWidth
                  label="City"
                  value={formData.city}
                  onChange={(e) => handleChange('city', e.target.value)}
                />
                {/* Add other fields for the second panel */}
              </Box>
            )}
            {currentPanel > 1 && (
              <Button onClick={handlePreviousPanel}>Previous</Button>
            )}
            {currentPanel < totalPanels && (
              <Button onClick={handleNextPanel}>Next</Button>
            )}
            {currentPanel === totalPanels && (
              <Box>
                <Button type="submit">Add</Button>
                <Button onClick={handleCloseNewPropertyModal}>Cancel</Button>
              </Box>
            )}
          </form>
        </Box>
      </Modal>

      <Stack direction="row" alignItems="center" flexWrap="wrap-reverse" justifyContent="flex-end" sx={{ mb: 5 }}>
        <Stack direction="row" spacing={1} flexShrink={0} sx={{ my: 1 }}>
          <ProductFilters openFilter={openFilter} onOpenFilter={() => setOpenFilter(true)} onCloseFilter={() => setOpenFilter(false)} />
          <ProductSort />
        </Stack>
      </Stack>

      <Grid container spacing={3}>
        {Array.isArray(properties) && properties.map((property) => (
          <Grid key={property.property_id} item xs={12} sm={6} md={3}>
            <Card>
              <Box sx={{ pt: '100%', position: 'relative' }}>
                {property.name}
              </Box>
              <Stack spacing={2} sx={{ p: 3 }}>
                <Link color="inherit" underline="hover" variant="subtitle2" noWrap>
                  {fCurrency(property.price)}
                </Link>
                <Button
  onClick={() => navigateToChatPage(property.seller_id, property.name, property.price, property.property_id)}
>
  Message Seller
</Button>

              </Stack>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}
