export { default as LoginView } from './verif-view';
