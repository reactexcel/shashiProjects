// PropertiesContext.js
import React, { createContext, useContext, useState, useMemo } from 'react';
import PropTypes from 'prop-types'; // Import PropTypes

const PropertiesContext = createContext();

export const PropertiesProvider = ({ children }) => {
  const [properties, setProperties] = useState([]); // Initialize properties state

  const value = useMemo(() => ({ properties, setProperties }), [properties, setProperties]);

  return (
    <PropertiesContext.Provider value={value}>
      {children}
    </PropertiesContext.Provider>
  );
};

PropertiesProvider.propTypes = {
  children: PropTypes.node.isRequired, // Add prop type validation for children
};

export const useProperties = () => useContext(PropertiesContext);
