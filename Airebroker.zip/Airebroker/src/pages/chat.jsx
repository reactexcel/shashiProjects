import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { makeStyles, Paper, List, TextField, IconButton, Typography, ListItem, ListItemText, ListItemAvatar, Avatar } from '@material-ui/core';
import SendIcon from '@mui/icons-material/Send';
import axios from 'axios';
import * as Paho from 'paho-mqtt';

import './chat.css';

const useStyles = makeStyles((theme) => ({
  chatContainer: {
    display: 'flex',
    flexDirection: 'column',
    maxHeight: '80vh',
    overflow: 'hidden',
    backgroundColor: '#fafafa',
    borderRadius: '15px',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    padding: '20px', // Added padding
  },
  chatHeader: {
    padding: '10px 20px', // Adjusted padding
    borderBottom: '1px solid #ddd',
    marginBottom: '20px', // Added margin-bottom
  },
  chatMessages: {
    flex: 1,
    overflowY: 'auto',
    padding: '20px',
  },
  chatInputContainer: {
    borderTop: '1px solid #ddd',
    padding: '20px',
    display: 'flex',
    alignItems: 'center',
  },
  chatInput: {
    flex: 1,
    marginRight: '10px', // Adjusted margin-right
  },
  avatar: {
    marginRight: '10px', // Adjusted margin-right
  },
  listItem: {
    marginBottom: '10px', // Adjusted margin-bottom
    borderRadius: '15px',
  },
  sendButton: {
    color: '#007bff', // Changed color
  },
  sellerMessage: {
    justifyContent: 'flex-start',
    backgroundColor: '#f0f0f0', // Light color for contrast
  },
  buyerMessage: {
    justifyContent: 'flex-end',
    backgroundColor: '#007bff', // Bright color for easy differentiation
    color: '#fff', // Text color for readability
  },
}));

const Chat = () => {
  const classes = useStyles();
  const location = useLocation();
  const { seller_id: passedSellerId } = location.state || {};
  const [currentMessage, setCurrentMessage] = useState('');
  const [chatMessages, setChatMessages] = useState([]);
  const [userRole, setUserRole] = useState('');
  const [sellerId, setSellerId] = useState('');
  const [buyerId, setBuyerId] = useState('');
  const [buyerName, setBuyerName] = useState(null);

  useEffect(() => {
    const fetchUserProfile = async () => {
      const accessToken = sessionStorage.getItem('accessToken');
      const profileResponse = await axios.get('http://155.138.160.153:5099/api/user/profile', {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      setUserRole(profileResponse.data.role);
      if (profileResponse.data.role === 'seller') {
        setSellerId(profileResponse.data.uuid);
      } else {
        setBuyerId(profileResponse.data.uuid);
        if (passedSellerId) {
          setSellerId(passedSellerId);
        }
      }
    };
    fetchUserProfile();
  }, [passedSellerId]);

  useEffect(() => {
    if (userRole === 'seller' && sellerId) {
      const brokerUrl = 'ws://155.138.160.153:8083/mqtt';
      const clientId = `chat-client_${Math.random().toString(16).substr(2, 8)}`;
      const client = new Paho.Client(brokerUrl, clientId);

      const onConnect = () => {
        client.subscribe(`chat/${sellerId}`, {
          onSuccess: () => console.log(`Subscribed to chat/${sellerId}`),
        });
      };

      const onMessageArrived = (message) => {
        const receivedMessage = JSON.parse(message.payloadString);
        setChatMessages(prevMessages => [...prevMessages, receivedMessage]);
      };

      client.onConnectionLost = responseObject => {
        console.error('Connection lost:', responseObject.errorMessage);
      };
      client.onMessageArrived = onMessageArrived;
      client.connect({ onSuccess: onConnect, useSSL: false });

      return () => client.disconnect();
    }
  }, [sellerId, userRole]);

  useEffect(() => {
    if (userRole === 'buyer' && buyerId && sellerId) {
      const fetchMessages = async () => {
        try {
          const accessToken = sessionStorage.getItem('accessToken');
          const response = await axios.get(`http://155.138.160.153:5099/api/users/buyer/sellers/chat/${buyerId}/${sellerId}`, {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          setChatMessages(response.data);
        } catch (error) {
          console.error('Failed to fetch messages:', error);
        }
      };
      fetchMessages();
    }
  }, [buyerId, sellerId, userRole]);
  useEffect(() => {
    const fetchBuyerName = async () => {
      try {
        const accessToken = sessionStorage.getItem('accessToken');
        const response = await axios.get('http://155.138.160.153:5099/api/admin/users', {
          headers: { Authorization: 'Bearer SDT5DVKA7E' },
        });
        const buyer = response.data.find(user => user.uuid === buyerId);
        if (buyer) {
          setBuyerName(buyer);
        }
      } catch (error) {
        console.error('Failed to fetch buyer name:', error);
      }
    };
    fetchBuyerName();
  }, [buyerId]);
  
  
  const handleSendMessage = async () => {
    if (!currentMessage.trim()) return;
    const accessToken = sessionStorage.getItem('accessToken');
    let receiverId = '';
    if (userRole === 'seller') {
      receiverId = buyerId;
    } else if (userRole === 'buyer') {
      receiverId = sellerId;
    }
    const payload = {
      receiver_id: receiverId,
      message_content: currentMessage,
    };
    try {
      const response = await axios.post('http://155.138.160.153:5099/api/users/buyer/sellers/chat', payload, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });

      if (response.data.message === 'Message sent successfully') {
        setChatMessages(prevMessages => [...prevMessages, {
          msg_id: userRole === 'seller' ? buyerId : sellerId,
          message: currentMessage,
        }]);
        setCurrentMessage('');
      } else {
        console.error('Message might not have been stored successfully.');
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const fetchMessagesForBuyer = async () => {
    try {
      const accessToken = sessionStorage.getItem('accessToken');
      const response = await axios.get(`http://155.138.160.153:5099/api/users/buyer/sellers/chat/${buyerId}/${sellerId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });
      setChatMessages(response.data);
    } catch (error) {
      console.error('Failed to fetch messages for buyer:', error);
    }
  };

  useEffect(() => {
    const fetchBuyerId = async () => {
      try {
        const accessToken = sessionStorage.getItem('accessToken');
        const response = await axios.get('http://155.138.160.153:5099/api/user/properties/buyers', {
          headers: { Authorization: `Bearer ${accessToken}` },
        });
        if (response.data && response.data.length > 0) {
          setBuyerId(response.data[0]); // Assuming there's only one buyer ID in the response array
        }
      } catch (error) {
        console.error('Failed to fetch buyer ID:', error);
      }
    };
    fetchBuyerId();
  }, []);

  return (
    <Paper className={classes.chatContainer}>
      {userRole === 'seller' && (
     <Typography variant="subtitle1" className={classes.chatHeader} onClick={fetchMessagesForBuyer}>
     Buyers: {buyerName ? `${buyerName.first_name} ${buyerName.last_name}` : ''}
     <br />
   
   </Typography>
   
      )}
      <Typography variant="h6" className={classes.chatHeader}>
        Chat with {passedSellerId ? 'Seller' : 'Buyer'}
      </Typography>
      <List className={classes.chatMessages}>
  {chatMessages.map((msg, index) => (
    <ListItem
  key={index}
  className={`${classes.listItem} ${
    msg.msg_id === buyerId ? classes.buyerMessage : classes.sellerMessage
  }`}
  alignItems="flex-start"
>
      <ListItemAvatar>
        <Avatar className={classes.avatar}>{msg.msg_id === buyerId ? 'B' : 'S'}</Avatar>
      </ListItemAvatar>
      <ListItemText primary={msg.message} />
    </ListItem>
  ))}
</List>

      <div className={classes.chatInputContainer}>
        <TextField
          className={classes.chatInput}
          variant="outlined"
          placeholder="Type something..."
          value={currentMessage}
          onChange={(e) => setCurrentMessage(e.target.value)}
          fullWidth
        />
        <IconButton className={classes.sendButton} onClick={handleSendMessage}>
          <SendIcon />
        </IconButton>
      </div>
    </Paper>
  );
};

export default Chat;
