import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import CloudUploadIcon from '@material-ui/icons/CloudUpload';
import LinearProgress from '@material-ui/core/LinearProgress';
import Snackbar from '@material-ui/core/Snackbar';
import Alert from '@material-ui/lab/Alert';
import axios from 'axios';

const useStyles = makeStyles((theme) => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: theme.spacing(4),
  },
  input: {
    display: 'none',
  },
  button: {
    margin: theme.spacing(1),
  },
  dropZone: {
    border: '2px dashed #aaaaaa',
    borderRadius: '5px',
    padding: theme.spacing(3),
    textAlign: 'center',
    cursor: 'pointer',
    marginTop: theme.spacing(2),
    width: '300px',
  },
  dropZoneText: {
    color: '#aaaaaa',
  },
}));

const FileUploader = () => {
  const classes = useStyles();
  const [selectedFile, setSelectedFile] = useState(null);
  const [mediaList, setMediaList] = useState([]);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadStatus, setUploadStatus] = useState({ open: false, message: '', severity: 'info' });

  useEffect(() => {
    const fetchMedia = async () => {
      try {
        const response = await axios.get('http://155.138.160.153:5099/api/user/media', {
          headers: {
            'Authorization': `Bearer ${sessionStorage.getItem('accessToken')}`,
          },
        });
        setMediaList(response.data);
      } catch (error) {
        const message = error.response ? error.response.data.message : 'Error fetching media';
        console.error('Error fetching media:', message);
        setUploadStatus({ open: true, message, severity: 'error' });
      }
    };

    fetchMedia();
  }, []);

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    setSelectedFile(file);
  };

  const handleUpload = () => {
    if (!selectedFile) {
      setUploadStatus({ open: true, message: 'No file selected', severity: 'error' });
      return;
    }

    const formData = new FormData();
    formData.append('file', selectedFile);
    const fileLabel = selectedFile.name.substr(0, selectedFile.name.lastIndexOf('.')) || selectedFile.name;
    formData.append('label', fileLabel);

    setUploadProgress(0); // Reset progress to zero before starting the upload
    axios.post('http://155.138.160.153:5099/api/receivemedia', formData, {
      headers: {
        'Authorization': `Bearer ${sessionStorage.getItem('accessToken')}`,
      },
      onUploadProgress: (progressEvent) => {
        const progress = Math.round((progressEvent.loaded / progressEvent.total) * 100);
        setUploadProgress(progress);
      },
    }).then(response => {
      // Check if the response status is 200 OK or other success status code if applicable
      if (response.status === 200 || response.status === 201) {
        setUploadStatus({ open: true, message: 'File uploaded successfully', severity: 'success' });
        setSelectedFile(null); // Reset the selected file
        fetchMedia(); // Fetch the updated media list
      } else {
        // Handle non-successful status codes as an error
        throw new Error('Upload not successful');
      }
    }).catch(error => {
      // If the file appears after reload, it might not be an actual error, log the response for debugging
      console.log('Upload response:', error.response);
      const errorMessage = error.response && error.response.data && error.response.data.message 
                          ? error.response.data.message 
                          : 'Upload failed due to an unknown error';
      setUploadStatus({ open: true, message: errorMessage, severity: 'error' });
    });
  };

  const handleDownload = async (filename) => {
    try {
      const response = await axios.post('http://155.138.160.153:5099/api/download-doc', { filename }, {
        responseType: 'blob', // important
        headers: {
          'Authorization': `Bearer ${sessionStorage.getItem('accessToken')}`,
        },
      });
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
    } catch (error) {
      console.error('Error downloading document:', error);
      const errorMessage = error.response ? error.response.data.message : 'Error downloading document';
      setUploadStatus({ open: true, message: errorMessage, severity: 'error' });
    }
  };

  const handleCloseSnackbar = () => {
    setUploadStatus({ ...uploadStatus, open: false });
  };

  return (
    <div className={classes.root}>
      <div className={classes.dropZone}>
        <CloudUploadIcon fontSize="large" />
        <p className={classes.dropZoneText}>Drag & Drop your file here or click to select a file</p>
        <input
          className={classes.input}
          id="contained-button-file"
          type="file"
          onChange={handleFileChange}
        />
        <label htmlFor="contained-button-file">
          <Button
            variant="contained"
            color="primary"
            component="span"
            className={classes.button}
          >
            Select File
          </Button>
        </label>
        {selectedFile && (
          <div>
            <p>Selected File: {selectedFile.name}</p>
            <Button
              variant="contained"
              color="primary"
              className={classes.button}
              onClick={handleUpload}
            >
              Upload
            </Button>
          </div>
        )}
        {uploadProgress > 0 && <LinearProgress variant="determinate" value={uploadProgress} />}
      </div>
      <Snackbar open={uploadStatus.open} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert onClose={handleCloseSnackbar} severity={uploadStatus.severity}>
          {uploadStatus.message}
        </Alert>
      </Snackbar>
      <div>
        <h3>Uploaded Media</h3>
        {mediaList.length > 0 ? (
          <ul>
            {mediaList.map((media, index) => (
              <li key={index}>
                {media.label}: <a href={media.file} target="_blank" rel="noopener noreferrer">View File</a>
                <Button
                  variant="contained"
                  color="primary"
                  className={classes.button}
                  onClick={() => handleDownload(media.label)}
                >
                  Download
                </Button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No media found.</p>
        )}
      </div>
    </div>
  );
};

export default FileUploader;
