import pancakeTokens from "./pancakeTokens"
import uniswapTokens from "./uniswapTokens"
import bnbTestNet from './bnbTestNet'
import { CHAINID } from '../config'

const getTokens = () => {
  if(CHAINID === 1){
    return uniswapTokens
  }
  else if(CHAINID === 56){
    return pancakeTokens
  }

  else if(CHAINID === 97){
    return bnbTestNet
  }

  else{
    return []
  }
}

export default getTokens