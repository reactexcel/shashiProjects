
const uniswapTokens = [
    {
      "chainId": 1,
      "address": "0x5B7533812759B45C2B44C19e320ba2cD2681b542",
      "name": "SingularityNET",
      "symbol": "AGIX",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/2138/large/singularitynet.png?1548609559"
    },
    {
      "chainId": 1,
      "address": "0x1a7e4e63778B4f12a199C062f3eFdD288afCBce8",
      "name": "agEUR",
      "symbol": "AGEUR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19479/large/agEUR.png?1635283566"
    },
    {
      "chainId": 1,
      "address": "0x8E870D67F660D95d5be530380D0eC0bd388289E1",
      "name": "Pax Dollar",
      "symbol": "USDP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/6013/large/Pax_Dollar.png?1629877204"
    },
    {
      "chainId": 1,
      "address": "0x9813037ee2218799597d83D4a5B6F3b6778218d9",
      "name": "Bone ShibaSwap",
      "symbol": "BONE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16916/large/bone_icon.png?1625625505"
    },
    {
      "chainId": 1,
      "address": "0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0",
      "name": "Wrapped stETH",
      "symbol": "WSTETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18834/large/wstETH.png?1633565443"
    },
    {
      "chainId": 1,
      "address": "0x95b3497bBcCcc46a8F45F5Cf54b0878b39f8D96C",
      "name": "UniDex",
      "symbol": "UNIDX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13178/large/unidx.png?1634888975"
    },
    {
      "chainId": 1,
      "address": "0x2e516BA5Bf3b7eE47fb99B09eaDb60BDE80a82e0",
      "name": "Eggs",
      "symbol": "EGGS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29024/large/egg200x200.png?1676016342"
    },
    {
      "chainId": 1,
      "address": "0xD33526068D116cE69F19A9ee46F0bd304F21A51f",
      "name": "Rocket Pool",
      "symbol": "RPL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2090/large/rocket_pool_%28RPL%29.png?1637662441"
    },
    {
      "chainId": 1,
      "address": "0xae78736Cd615f374D3085123A210448E74Fc6393",
      "name": "Rocket Pool ETH",
      "symbol": "RETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20764/large/reth.png?1637652366"
    },
    {
      "chainId": 1,
      "address": "0x17EF75AA22dD5f6C2763b8304Ab24f40eE54D48a",
      "name": "Revolution Populi",
      "symbol": "RVP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14772/large/vsd0Wnc2_400x400.png?1618369912"
    },
    {
      "chainId": 1,
      "address": "0x24dA31e7BB182cb2cABfEF1d88db19C2AE1f5572",
      "name": "Shikoku",
      "symbol": "SHIK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28560/large/shikoku_inu02.png?1671706822"
    },
    {
      "chainId": 1,
      "address": "0x3aaDA3e213aBf8529606924d8D1c55CbDc70Bf74",
      "name": "XMON",
      "symbol": "XMON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14008/large/xmon_logo.png?1613615094"
    },
    {
      "chainId": 1,
      "address": "0x8355DBE8B0e275ABAd27eB843F3eaF3FC855e525",
      "name": "Wolf Game Wool",
      "symbol": "WOOL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20760/large/KM3RwIVx_400x400.jpg?1637650093"
    },
    {
      "chainId": 1,
      "address": "0x70e8dE73cE538DA2bEEd35d14187F6959a8ecA96",
      "name": "XSGD",
      "symbol": "XSGD",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/12832/large/StraitsX_Singapore_Dollar_%28XSGD%29_Token_Logo.png?1633936813"
    },
    {
      "chainId": 1,
      "address": "0x2dE509bf0014ddF697b220bE628213034d320EcE",
      "name": "Don t Buy Inu",
      "symbol": "DBI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28058/large/1Artboard_1_%282%29.png?1667298091"
    },
    {
      "chainId": 1,
      "address": "0x419D0d8BdD9aF5e606Ae2232ed285Aff190E711b",
      "name": "FUNToken",
      "symbol": "FUN",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/761/large/FUN.png?1678773913"
    },
    {
      "chainId": 1,
      "address": "0xdD69DB25F6D620A7baD3023c5d32761D353D3De9",
      "name": "Goerli ETH",
      "symbol": "GETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29217/large/goerli-eth.png?1677429831"
    },
    {
      "chainId": 1,
      "address": "0xf4d2888d29D722226FafA5d9B24F9164c092421E",
      "name": "LooksRare",
      "symbol": "LOOKS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22173/large/circle-black-256.png?1641173160"
    },
    {
      "chainId": 1,
      "address": "0x562E362876c8Aee4744FC2c6aaC8394C312d215d",
      "name": "Optimus AI",
      "symbol": "OPTI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/29328/large/Optimus_AI_Logo.png?1678170818"
    },
    {
      "chainId": 1,
      "address": "0x06450dEe7FD2Fb8E39061434BAbCFC05599a6Fb8",
      "name": "XEN Crypto",
      "symbol": "XEN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27713/large/Xen.jpeg?1665453190"
    },
    {
      "chainId": 1,
      "address": "0x3819f64f282bf135d62168C1e513280dAF905e06",
      "name": "Hedron",
      "symbol": "HDRN",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/24208/large/hdrn.png?1647079428"
    },
    {
      "chainId": 1,
      "address": "0x6BC08509B36A98E829dFfAD49Fde5e412645d0a3",
      "name": "WoofWork io",
      "symbol": "WOOF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28903/large/WWlogoTransparent_200x200.png?1675241564"
    },
    {
      "chainId": 1,
      "address": "0xDc63269eA166b70d4780b3A11F5C825C2b761B01",
      "name": "PAWSWAP",
      "symbol": "PAW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28946/large/pawnewlogobig.png?1682498998"
    },
    {
      "chainId": 1,
      "address": "0xD5d86FC8d5C0Ea1aC1Ac5Dfab6E529c9967a45E9",
      "name": "NFT Worlds",
      "symbol": "WRLD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22112/large/ZyBrRgfO.jpg?1640842284"
    },
    {
      "chainId": 1,
      "address": "0xcf0C122c6b73ff809C693DB761e7BaeBe62b6a2E",
      "name": "FLOKI",
      "symbol": "FLOKI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/16746/large/PNG_image.png?1643184642"
    },
    {
      "chainId": 1,
      "address": "0x00D1793D7C3aAE506257Ba985b34C76AaF642557",
      "name": "Tacos",
      "symbol": "TACO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12108/large/photo_2020-08-12_05-50-46.jpg?1597217863"
    },
    {
      "chainId": 1,
      "address": "0xf21661D0D1d76d3ECb8e1B9F1c923DBfffAe4097",
      "name": "Realio",
      "symbol": "RIO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12206/large/0.jpg?1598083003"
    },
    {
      "chainId": 1,
      "address": "0x3B9BE07d622aCcAEd78f479BC0EDabFd6397E320",
      "name": "Lossless",
      "symbol": "LSS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15917/large/Group_57.png?1623046307"
    },
    {
      "chainId": 1,
      "address": "0xc5fB36dd2fb59d3B98dEfF88425a3F425Ee469eD",
      "name": "Dejitaru Tsuka",
      "symbol": "TSUKA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26405/large/Tsuka_200x200.png?1657923568"
    },
    {
      "chainId": 1,
      "address": "0xf1B99e3E573A1a9C5E6B2Ce818b617F0E664E86B",
      "name": "Opyn Squeeth",
      "symbol": "OSQTH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22806/large/DyVT5XPV_400x400.jpg?1642656239"
    },
    {
      "chainId": 1,
      "address": "0xA49d7499271aE71cd8aB9Ac515e6694C755d400c",
      "name": "Mute",
      "symbol": "MUTE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14331/large/MUTE.png?1617618967"
    },
    {
      "chainId": 1,
      "address": "0x0000000000085d4780B73119b644AE5ecd22b376",
      "name": "TrueUSD",
      "symbol": "TUSD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3449/large/tusd.png?1618395665"
    },
    {
      "chainId": 1,
      "address": "0xa1d6Df714F91DeBF4e0802A542E13067f31b8262",
      "name": "RFOX",
      "symbol": "RFOX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12956/large/rfox.png?1642926902"
    },
    {
      "chainId": 1,
      "address": "0x26c8AFBBFE1EBaca03C2bB082E69D0476Bffe099",
      "name": "Cellframe",
      "symbol": "CELL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14465/large/cellframe-coingecko.png?1644483414"
    },
    {
      "chainId": 1,
      "address": "0xeB953eDA0DC65e3246f43DC8fa13f35623bDd5eD",
      "name": "Raini",
      "symbol": "RAINI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14491/large/logo-200x200.png?1633314246"
    },
    {
      "chainId": 1,
      "address": "0x9D65fF81a3c488d585bBfb0Bfe3c7707c7917f54",
      "name": "SSV Network",
      "symbol": "SSV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19155/large/ssv.png?1638181902"
    },
    {
      "chainId": 1,
      "address": "0xA4Eb9C64eC359D093eAc7B65F51Ef933D6e5F7cd",
      "name": "Stablz",
      "symbol": "STABLZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28983/large/Frame_2869.png?1675760347"
    },
    {
      "chainId": 1,
      "address": "0xC0c293ce456fF0ED870ADd98a0828Dd4d2903DBF",
      "name": "Aura Finance",
      "symbol": "AURA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25942/large/logo.png?1654784187"
    },
    {
      "chainId": 1,
      "address": "0x1E4EDE388cbc9F4b5c79681B7f94d36a11ABEBC9",
      "name": "X2Y2",
      "symbol": "X2Y2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23633/large/logo-60b81ff87b40b11739105acf5ad1e075.png?1644903256"
    },
    {
      "chainId": 1,
      "address": "0xFcF8eda095e37A41e002E266DaAD7efC1579bc0A",
      "name": "FLEX Coin",
      "symbol": "FLEX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/9108/large/coinflex_logo.png?1628750583"
    },
    {
      "chainId": 1,
      "address": "0x375aBB85C329753b1Ba849a601438AE77eEc9893",
      "name": "ParagonsDAO",
      "symbol": "PDT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22642/large/PDT_LOGO_200.jpg?1674482648"
    },
    {
      "chainId": 1,
      "address": "0xa71d0588EAf47f12B13cF8eC750430d21DF04974",
      "name": "Shiba Predator",
      "symbol": "QOM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24430/large/l1KzMcL.png?1647660619"
    },
    {
      "chainId": 1,
      "address": "0xD13c7342e1ef687C5ad21b27c2b65D772cAb5C8c",
      "name": "Ultra",
      "symbol": "UOS",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/4480/large/Ultra.png?1563356418"
    },
    {
      "chainId": 1,
      "address": "0xfc05987bd2be489ACCF0f509E44B0145d68240f7",
      "name": "Essentia",
      "symbol": "ESS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2483/large/Essentia-token.jpg?1547036604"
    },
    {
      "chainId": 1,
      "address": "0x602f65BB8B8098Ad804E99DB6760Fd36208cD967",
      "name": "Mops",
      "symbol": "MOPS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26900/large/mops.png?1660724129"
    },
    {
      "chainId": 1,
      "address": "0xC91a71A1fFA3d8B22ba615BA1B9c01b2BBBf55ad",
      "name": "ZigZag",
      "symbol": "ZZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26141/large/zig_zag.?1656248564"
    },
    {
      "chainId": 1,
      "address": "0x03Be5C903c727Ee2C8C4e9bc0AcC860Cca4715e2",
      "name": "Ternoa",
      "symbol": "CAPS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15921/large/e55393fa-7b4d-40f5-9f36-9a8a6bdcb570.png?1622430581"
    },
    {
      "chainId": 1,
      "address": "0xA8b919680258d369114910511cc87595aec0be6D",
      "name": "LUKSO",
      "symbol": "LYXE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11423/large/1_QAHTciwVhD7SqVmfRW70Pw.png?1590110612"
    },
    {
      "chainId": 1,
      "address": "0xb6EE9668771a79be7967ee29a63D4184F8097143",
      "name": "CargoX",
      "symbol": "CXO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2580/large/cargox.png?1547738832"
    },
    {
      "chainId": 1,
      "address": "0x30D20208d987713f46DFD34EF128Bb16C404D10f",
      "name": "Stader",
      "symbol": "SD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20658/large/sd.png?1642927667"
    },
    {
      "chainId": 1,
      "address": "0x0f51bb10119727a7e5eA3538074fb341F56B09Ad",
      "name": "DAO Maker",
      "symbol": "DAO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13915/large/4.png?1612838831"
    },
    {
      "chainId": 1,
      "address": "0xf3dcbc6D72a4E1892f7917b7C43b74131Df8480e",
      "name": "Big Data Protocol",
      "symbol": "BDP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14222/large/logo_BDP_200.png?1615088501"
    },
    {
      "chainId": 1,
      "address": "0x2dA719DB753dFA10a62E140f436E1d67F2ddB0d6",
      "name": "Cere Network",
      "symbol": "CERE",
      "decimals": 10,
      "logoURI": "https://assets.coingecko.com/coins/images/20008/large/cere.png?1636366576"
    },
    {
      "chainId": 1,
      "address": "0xF411903cbC70a74d22900a5DE66A2dda66507255",
      "name": "Verasity",
      "symbol": "VRA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14025/large/VRA.jpg?1613797653"
    },
    {
      "chainId": 1,
      "address": "0x582d872A1B094FC48F5DE31D3B73F2D9bE47def1",
      "name": "Toncoin",
      "symbol": "TON",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/17980/large/ton_symbol.png?1670498136"
    },
    {
      "chainId": 1,
      "address": "0x64aa3364F17a4D01c6f1751Fd97C2BD3D7e7f1D5",
      "name": "Olympus",
      "symbol": "OHM",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/14483/large/token_OHM_%281%29.png?1628311611"
    },
    {
      "chainId": 1,
      "address": "0x243cACb4D5fF6814AD668C3e225246efA886AD5a",
      "name": "Shina Inu",
      "symbol": "SHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25208/large/coingecko-shina-purple-bg.png?1655266989"
    },
    {
      "chainId": 1,
      "address": "0x77E06c9eCCf2E797fd462A92B6D7642EF85b0A44",
      "name": "Wrapped TAO",
      "symbol": "WTAO",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/29087/large/wtao.png?1676519685"
    },
    {
      "chainId": 1,
      "address": "0x6f40d4A6237C257fff2dB00FA0510DeEECd303eb",
      "name": "Instadapp",
      "symbol": "INST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14688/large/30hFM0-n_400x400.jpg?1617786420"
    },
    {
      "chainId": 1,
      "address": "0x1BBf25e71EC48B84d773809B4bA55B6F4bE946Fb",
      "name": "Vow",
      "symbol": "VOW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18202/large/72Nd63R0_400x400.png?1630974351"
    },
    {
      "chainId": 1,
      "address": "0xC669928185DbCE49d2230CC9B0979BE6DC797957",
      "name": "BitTorrent",
      "symbol": "BTT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22457/large/btt_logo.png?1643857231"
    },
    {
      "chainId": 1,
      "address": "0x320623b8E4fF03373931769A31Fc52A4E78B5d70",
      "name": "Reserve Rights",
      "symbol": "RSR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/8365/large/rsr.png?1637983320"
    },
    {
      "chainId": 1,
      "address": "0x6243d8CEA23066d098a15582d81a598b4e8391F4",
      "name": "Reflexer Ungovernance",
      "symbol": "FLX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14123/large/EAfYdwgd_400x400.jpg?1614564508"
    },
    {
      "chainId": 1,
      "address": "0x6f3277ad0782a7DA3eb676b85a8346A100BF9C1c",
      "name": "DogPad Finance",
      "symbol": "DOGPAD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28845/large/DogPad.png?1674803782"
    },
    {
      "chainId": 1,
      "address": "0xFe2e637202056d30016725477c5da089Ab0A043A",
      "name": "sETH2",
      "symbol": "SETH2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16569/large/emerald256.png?1624494960"
    },
    {
      "chainId": 1,
      "address": "0x9F9c8ec3534c3cE16F928381372BfbFBFb9F4D24",
      "name": "GraphLinq Protocol",
      "symbol": "GLQ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14474/large/graphlinq_logo.jpg?1616397109"
    },
    {
      "chainId": 1,
      "address": "0xc5102fE9359FD9a28f877a67E36B0F050d81a3CC",
      "name": "Hop Protocol",
      "symbol": "HOP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25445/large/hop.png?1665541677",
      "extensions": {
        "bridgeInfo": {
          "10": {
            "tokenAddress": "0xc5102fE9359FD9a28f877a67E36B0F050d81a3CC"
          },
          "137": {
            "tokenAddress": "0xc5102fE9359FD9a28f877a67E36B0F050d81a3CC"
          },
          "42161": {
            "tokenAddress": "0xc5102fE9359FD9a28f877a67E36B0F050d81a3CC"
          }
        }
      }
    },
    {
      "chainId": 1,
      "address": "0x8FfE40A3D0f80C0CE6b203D5cDC1A6a86d9AcaeA",
      "name": "IG Gold",
      "symbol": "IGG",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/7697/large/N7aEdYrY_400x400.png?1561587437"
    },
    {
      "chainId": 1,
      "address": "0x5D843Fa9495d23dE997C394296ac7B4D721E841c",
      "name": "Relay Chain",
      "symbol": "RELAY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17816/large/relay-logo-200.png?1629339288"
    },
    {
      "chainId": 1,
      "address": "0x72F020f8f3E8fd9382705723Cd26380f8D0c66Bb",
      "name": "PlotX",
      "symbol": "PLOT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12795/large/PlotX.png?1611109969"
    },
    {
      "chainId": 1,
      "address": "0x993864E43Caa7F7F12953AD6fEb1d1Ca635B875F",
      "name": "SingularityDAO",
      "symbol": "SDAO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15385/large/200x200_logo.png?1665743635"
    },
    {
      "chainId": 1,
      "address": "0xf0f9D895aCa5c8678f706FB8216fa22957685A13",
      "name": "Cult DAO",
      "symbol": "CULT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23331/large/quxZPrbC_400x400.jpg?1643880172"
    },
    {
      "chainId": 1,
      "address": "0x4F08705FB8F33AffC231ed66e626B40E84A71870",
      "name": "Flute",
      "symbol": "FLUT",
      "decimals": 11,
      "logoURI": "https://assets.coingecko.com/coins/images/29148/large/TheFlute200x200.png?1676966950"
    },
    {
      "chainId": 1,
      "address": "0xae7ab96520DE3A18E5e111B5EaAb095312D7fE84",
      "name": "Lido Staked Ether",
      "symbol": "STETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13442/large/steth_logo.png?1608607546"
    },
    {
      "chainId": 1,
      "address": "0x48C3399719B582dD63eB5AADf12A40B4C3f52FA2",
      "name": "StakeWise",
      "symbol": "SWISE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15044/large/stakewise200.png?1619520721"
    },
    {
      "chainId": 1,
      "address": "0xF0d33BeDa4d734C72684b5f9abBEbf715D0a7935",
      "name": "NuNet",
      "symbol": "NTX",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/20950/large/8Zb2W2Wi_400x400.png?1638137477"
    },
    {
      "chainId": 1,
      "address": "0x6c6EE5e31d828De241282B9606C8e98Ea48526E2",
      "name": "Holo",
      "symbol": "HOT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3348/large/Holologo_Profile.png?1547037966"
    },
    {
      "chainId": 1,
      "address": "0xd4c435F5B09F855C3317c8524Cb1F586E42795fa",
      "name": "Cindicator",
      "symbol": "CND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1006/large/cindicator.png?1547034913"
    },
    {
      "chainId": 1,
      "address": "0x0d02755a5700414B26FF040e1dE35D337DF56218",
      "name": "BendDAO",
      "symbol": "BEND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22829/large/benddao.PNG?1642664553"
    },
    {
      "chainId": 1,
      "address": "0x4521C9aD6A3D4230803aB752Ed238BE11F8B342F",
      "name": "Sanin Inu",
      "symbol": "SANI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25222/large/B7r0ocfQ_400x400.jpg?1650892157"
    },
    {
      "chainId": 1,
      "address": "0xE66b3AA360bB78468c00Bebe163630269DB3324F",
      "name": "Merchant",
      "symbol": "MTO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17157/large/mto.PNG?1626672046"
    },
    {
      "chainId": 1,
      "address": "0xAa6E8127831c9DE45ae56bB1b0d4D4Da6e5665BD",
      "name": "Index Coop   ETH 2x Flexible Leverage I",
      "symbol": "ETH2X-FLI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14392/large/ETH2x-FLI_%281%29.png?1615875910"
    },
    {
      "chainId": 1,
      "address": "0x9DFAD1b7102D46b1b197b90095B5c4E9f5845BBA",
      "name": "Botto",
      "symbol": "BOTTO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18892/large/bottos_logo.jpg?1633791571"
    },
    {
      "chainId": 1,
      "address": "0x865377367054516e17014CcdED1e7d814EDC9ce4",
      "name": "DOLA",
      "symbol": "DOLA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14287/large/dola.png?1667738374"
    },
    {
      "chainId": 1,
      "address": "0x50DE6856358Cc35f3A9a57eAAA34BD4cB707d2cd",
      "name": "Razor Network",
      "symbol": "RAZOR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13797/large/icon.png?1611919354"
    },
    {
      "chainId": 1,
      "address": "0x1c7E83f8C581a967940DBfa7984744646AE46b29",
      "name": "The RandomDAO",
      "symbol": "RND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24256/large/rnd.png?1647160021"
    },
    {
      "chainId": 1,
      "address": "0x6b32022693210cD2Cfc466b9Ac0085DE8fC34eA6",
      "name": "Maximus DECI",
      "symbol": "DECI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/27693/large/Deci.png?1665222159"
    },
    {
      "chainId": 1,
      "address": "0x6468e79A80C0eaB0F9A2B574c8d5bC374Af59414",
      "name": "e Radix",
      "symbol": "EXRD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13145/large/exrd_logo.png?1605662677"
    },
    {
      "chainId": 1,
      "address": "0x4Dd942bAa75810a3C1E876e79d5cD35E09C97A76",
      "name": "Dash 2 Trade",
      "symbol": "D2T",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28707/large/logo.png?1675762068"
    },
    {
      "chainId": 1,
      "address": "0x7659CE147D0e714454073a5dd7003544234b6Aa0",
      "name": "XCAD Network",
      "symbol": "XCAD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15857/large/logoWhiteX.jpg?1666230966"
    },
    {
      "chainId": 1,
      "address": "0xD46bA6D942050d489DBd938a2C909A5d5039A161",
      "name": "Ampleforth",
      "symbol": "AMPL",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/4708/large/Ampleforth.png?1561684250"
    },
    {
      "chainId": 1,
      "address": "0xa58a4f5c4Bb043d2CC1E170613B74e767c94189B",
      "name": "UTU Coin",
      "symbol": "UTU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12831/large/Aa5nmbkJ_400x400.png?1602884636"
    },
    {
      "chainId": 1,
      "address": "0x7c8155909cd385F120A56eF90728dD50F9CcbE52",
      "name": "Nahmii",
      "symbol": "NII",
      "decimals": 15,
      "logoURI": "https://assets.coingecko.com/coins/images/9786/large/nahmii-sm_icon-full-color.png?1608513773"
    },
    {
      "chainId": 1,
      "address": "0xe9B076B476D8865cDF79D1Cf7DF420EE397a7f75",
      "name": "Unification",
      "symbol": "FUND",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/7845/large/DV80FOp.png?1554953278"
    },
    {
      "chainId": 1,
      "address": "0xD13cfD3133239a3c73a9E535A5c4DadEE36b395c",
      "name": "Vaiot",
      "symbol": "VAI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13981/large/VAIOT_logo.png?1613456546"
    },
    {
      "chainId": 1,
      "address": "0x73C69d24ad28e2d43D03CBf35F79fE26EBDE1011",
      "name": "Archimedes Finance",
      "symbol": "ARCH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28970/large/arch.png?1676361582"
    },
    {
      "chainId": 1,
      "address": "0x549020a9Cb845220D66d3E9c6D9F9eF61C981102",
      "name": "Sidus",
      "symbol": "SIDUS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21401/large/SIDUS_coin_logo.png?1639405031"
    },
    {
      "chainId": 1,
      "address": "0x668DbF100635f593A3847c0bDaF21f0a09380188",
      "name": "BNSD Finance",
      "symbol": "BNSD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12368/large/bnsd.png?1599358388"
    },
    {
      "chainId": 1,
      "address": "0x9AAb071B4129B083B01cB5A0Cb513Ce7ecA26fa5",
      "name": "Hunt",
      "symbol": "HUNT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7989/large/HUNT.png?1571024256"
    },
    {
      "chainId": 1,
      "address": "0xfc4913214444aF5c715cc9F7b52655e788A569ed",
      "name": "Icosa",
      "symbol": "ICSA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/27708/large/icsa.e2b79cbc.png?1665314034"
    },
    {
      "chainId": 1,
      "address": "0xd3E4Ba569045546D09CF021ECC5dFe42b1d7f6E4",
      "name": "Morpheus Network",
      "symbol": "MNW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2379/large/MRPH_CoinGecko.png?1635847791"
    },
    {
      "chainId": 1,
      "address": "0x2A8e1E676Ec238d8A992307B495b45B3fEAa5e86",
      "name": "Origin Dollar",
      "symbol": "OUSD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12589/large/ousd-logo-200x200.png?1600943287"
    },
    {
      "chainId": 1,
      "address": "0x0d438F3b5175Bebc262bF23753C1E53d03432bDE",
      "name": "Wrapped NXM",
      "symbol": "WNXM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11890/large/wNXM.png?1674799594"
    },
    {
      "chainId": 1,
      "address": "0xC4EE0aA2d993ca7C9263eCFa26c6f7e13009d2b6",
      "name": "Hoichi",
      "symbol": "HOICHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27227/large/3dBs4VvW_400x400.jpeg?1662711951"
    },
    {
      "chainId": 1,
      "address": "0x2F109021aFe75B949429fe30523Ee7C0D5B27207",
      "name": "OccamFi",
      "symbol": "OCC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14801/large/occfi.PNG?1618531140"
    },
    {
      "chainId": 1,
      "address": "0xf65B5C5104c4faFD4b709d9D60a185eAE063276c",
      "name": "Truebit Protocol",
      "symbol": "TRU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15053/large/Truebit.png?1623296246"
    },
    {
      "chainId": 1,
      "address": "0xA735A3AF76CC30791C61c10d585833829d36CBe0",
      "name": "Image Generation AI",
      "symbol": "IMGNAI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28666/large/200x200-Nai.png?1672990319"
    },
    {
      "chainId": 1,
      "address": "0xCC4304A31d09258b0029eA7FE63d032f52e44EFe",
      "name": "Trustswap",
      "symbol": "SWAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11795/large/Untitled_design-removebg-preview.png?1626926355"
    },
    {
      "chainId": 1,
      "address": "0x24C19F7101c1731b85F1127EaA0407732E36EcDD",
      "name": "SharedStake Governance v2",
      "symbol": "SGTV2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13948/large/sgt-png.png?1615189100"
    },
    {
      "chainId": 1,
      "address": "0x823556202e86763853b40e9cDE725f412e294689",
      "name": "Altered State Machine",
      "symbol": "ASTO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24893/large/ASTO.png?1649303806"
    },
    {
      "chainId": 1,
      "address": "0xC581b735A1688071A1746c968e0798D642EDE491",
      "name": "Euro Tether",
      "symbol": "EURT",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/17385/large/Tether_full_logo_dm.png?1627537298"
    },
    {
      "chainId": 1,
      "address": "0x584bC13c7D411c00c01A62e8019472dE68768430",
      "name": "Hegic",
      "symbol": "HEGIC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12454/large/new.png?1628668523"
    },
    {
      "chainId": 1,
      "address": "0x6368e1E18c4C419DDFC608A0BEd1ccb87b9250fc",
      "name": "Tap",
      "symbol": "XTP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10291/large/0_3SJYkk_400x400.jpg?1577229220"
    },
    {
      "chainId": 1,
      "address": "0x7db5af2B9624e1b3B4Bb69D6DeBd9aD1016A58Ac",
      "name": "Volt Inu",
      "symbol": "VOLT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/25201/large/logo200.png?1653635992"
    },
    {
      "chainId": 1,
      "address": "0x0ab87046fBb341D058F17CBC4c1133F25a20a52f",
      "name": "Governance OHM",
      "symbol": "GOHM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21129/large/token_wsOHM_logo.png?1638764900"
    },
    {
      "chainId": 1,
      "address": "0x0c572544a4Ee47904d54aaA6A970AF96B6f00E1b",
      "name": "Wasder",
      "symbol": "WAS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15374/large/wasderBoxedLogoWhite-200x200.png?1659095342"
    },
    {
      "chainId": 1,
      "address": "0x27C70Cd1946795B66be9d954418546998b546634",
      "name": "Doge Killer",
      "symbol": "LEASH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15802/large/Leash.png?1621931543"
    },
    {
      "chainId": 1,
      "address": "0xd794DD1CAda4cf79C9EebaAb8327a1B0507ef7d4",
      "name": "Hyve",
      "symbol": "HYVE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13072/large/bAe1G-lD_400x400.png?1654056255"
    },
    {
      "chainId": 1,
      "address": "0x5F64Ab1544D28732F0A24F4713c2C8ec0dA089f0",
      "name": "Domani Protocol",
      "symbol": "DEXTF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12634/large/0qgT0aMu_400x400.jpg?1639175406"
    },
    {
      "chainId": 1,
      "address": "0x2a3bFF78B79A009976EeA096a51A948a3dC00e34",
      "name": "Wilder World",
      "symbol": "WILD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15407/large/WWLogo_Gradient_Cirlce.png?1620743969"
    },
    {
      "chainId": 1,
      "address": "0x892A6f9dF0147e5f079b0993F486F9acA3c87881",
      "name": "xFUND",
      "symbol": "XFUND",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/13770/large/xfund.png?1611697744"
    },
    {
      "chainId": 1,
      "address": "0xb53ecF1345caBeE6eA1a65100Ebb153cEbcac40f",
      "name": "Childhoods End",
      "symbol": "O",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25670/large/photo_2022-05-27_12-45-29.jpg?1653626809"
    },
    {
      "chainId": 1,
      "address": "0x2d886570A0dA04885bfD6eb48eD8b8ff01A0eb7e",
      "name": "Blockchain Bets",
      "symbol": "BCB",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28694/large/200x200.jpg?1673412258"
    },
    {
      "chainId": 1,
      "address": "0x419E35E3515c2fDB652C898bF7A0B21FB20497dC",
      "name": "Ordinals Finance",
      "symbol": "OFI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/29226/large/symbol-bbg.png?1677485044"
    },
    {
      "chainId": 1,
      "address": "0xB62132e35a6c13ee1EE0f84dC5d40bad8d815206",
      "name": "NEXO",
      "symbol": "NEXO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3695/large/nexo.png?1548086057"
    },
    {
      "chainId": 1,
      "address": "0x6BeA7CFEF803D1e3d5f7C0103f7ded065644e197",
      "name": "Gamma Strategies",
      "symbol": "GAMMA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21975/large/gamma-token-200.png?1640566576"
    },
    {
      "chainId": 1,
      "address": "0x15b7c0c907e4C6b9AdaAaabC300C08991D6CEA05",
      "name": "Gelato",
      "symbol": "GEL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15026/large/Gelato_Icon_Logo_1024x1024.png?1619491717"
    },
    {
      "chainId": 1,
      "address": "0x0202Be363B8a4820f3F4DE7FaF5224fF05943AB1",
      "name": "UniLend Finance",
      "symbol": "UFT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12819/large/UniLend_Finance_logo_PNG.png?1602748658"
    },
    {
      "chainId": 1,
      "address": "0x89B69F2d1adffA9A253d40840B6Baa7fC903D697",
      "name": "Dione",
      "symbol": "DIONE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26931/large/dione_200x200.png?1660886063"
    },
    {
      "chainId": 1,
      "address": "0x0d86EB9f43C57f6FF3BC9E23D8F9d82503f0e84b",
      "name": "Maximus DAO",
      "symbol": "MAXI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/25126/large/maxilogo200.png?1650372648"
    },
    {
      "chainId": 1,
      "address": "0xEB4C2781e4ebA804CE9a9803C67d0893436bB27D",
      "name": "renBTC",
      "symbol": "RENBTC",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/11370/large/Bitcoin.jpg?1628072791"
    },
    {
      "chainId": 1,
      "address": "0x7B4328c127B85369D9f82ca0503B000D09CF9180",
      "name": "Dogechain",
      "symbol": "DC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26828/large/dogechain.jpeg?1660292741"
    },
    {
      "chainId": 1,
      "address": "0xbdab72602e9AD40FC6a6852CAf43258113B8F7a5",
      "name": "Sovryn",
      "symbol": "SOV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16248/large/sov.PNG?1623380748"
    },
    {
      "chainId": 1,
      "address": "0x8EE325AE3E54e83956eF2d5952d3C8Bc1fa6ec27",
      "name": "Fable Of The Dragon",
      "symbol": "TYRANT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/27911/large/image_%283%29.png?1674184985"
    },
    {
      "chainId": 1,
      "address": "0x30dcBa0405004cF124045793E1933C798Af9E66a",
      "name": "Yieldification",
      "symbol": "YDF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26699/large/logo.png?1659609811"
    },
    {
      "chainId": 1,
      "address": "0xd084944d3c05CD115C09d072B9F44bA3E0E45921",
      "name": "Manifold Finance",
      "symbol": "FOLD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15928/large/Manifold.png?1622439811"
    },
    {
      "chainId": 1,
      "address": "0x38A94e92A19E970c144DEd0B2DD47278CA11CC1F",
      "name": "Falcon Nine",
      "symbol": "F9",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/16858/large/logo-f9.png?1625465513"
    },
    {
      "chainId": 1,
      "address": "0x3af33bEF05C2dCb3C7288b77fe1C8d2AeBA4d789",
      "name": "Kromatika",
      "symbol": "KROM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20541/large/KROM_Transparent.png?1641398421"
    },
    {
      "chainId": 1,
      "address": "0x111111517e4929D3dcbdfa7CCe55d30d4B6BC4d6",
      "name": "ICHI",
      "symbol": "ICHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13119/large/ICHI_%28Round%29.jpg?1614308761"
    },
    {
      "chainId": 1,
      "address": "0x1e4746dC744503b53b4A082cB3607B169a289090",
      "name": "IPOR",
      "symbol": "IPOR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28373/large/IPOR-token-200x200.png?1670480793"
    },
    {
      "chainId": 1,
      "address": "0x940a2dB1B7008B6C776d4faaCa729d6d4A4AA551",
      "name": "DUSK Network",
      "symbol": "DUSK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5217/large/D_ticker_purple_on_circle_%282%29.png?1563781659"
    },
    {
      "chainId": 1,
      "address": "0x990f341946A3fdB507aE7e52d17851B87168017c",
      "name": "Strong",
      "symbol": "STRONG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12092/large/STRONG-Token-256x256.png?1597823573"
    },
    {
      "chainId": 1,
      "address": "0x249e38Ea4102D0cf8264d3701f1a0E39C4f2DC3B",
      "name": "UFO Gaming",
      "symbol": "UFO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16801/large/ufo.png?1644048038"
    },
    {
      "chainId": 1,
      "address": "0xB17548c7B510427baAc4e267BEa62e800b247173",
      "name": "Swarm Markets",
      "symbol": "SMT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17488/large/swarm-SMT-token-symbol_200x200.png?1655373659"
    },
    {
      "chainId": 1,
      "address": "0x6c3F90f043a72FA612cbac8115EE7e52BDe6E490",
      "name": "LP 3pool Curve",
      "symbol": "3CRV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12972/large/3pool_128.png?1603948039"
    },
    {
      "chainId": 1,
      "address": "0x6fC13EACE26590B80cCCAB1ba5d51890577D83B2",
      "name": "Umbrella Network",
      "symbol": "UMB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13913/large/Umbrella_Network_Logo-Vertical_Version.png?1612836176"
    },
    {
      "chainId": 1,
      "address": "0xd2877702675e6cEb975b4A1dFf9fb7BAF4C91ea9",
      "name": "Wrapped Terra Classic",
      "symbol": "LUNC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13628/large/wluna.png?1610448334"
    },
    {
      "chainId": 1,
      "address": "0x8E6cd950Ad6ba651F6DD608Dc70e5886B1AA6B24",
      "name": "StarLink",
      "symbol": "STARL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16824/large/ZxJbRWJ.png?1625177900"
    },
    {
      "chainId": 1,
      "address": "0xe4815AE53B124e7263F08dcDBBB757d41Ed658c6",
      "name": "ZKSpace",
      "symbol": "ZKS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13585/large/zkspace_logo.png?1644486208"
    },
    {
      "chainId": 1,
      "address": "0xf4CD3d3Fda8d7Fd6C5a500203e38640A70Bf9577",
      "name": "YfDAI finance",
      "symbol": "YF-DAI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12385/large/1619048513068.png?1622193581"
    },
    {
      "chainId": 1,
      "address": "0xD23Ac27148aF6A2f339BD82D0e3CFF380b5093de",
      "name": "Siren",
      "symbol": "SI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13955/large/siren_token_200x200.png?1672132332"
    },
    {
      "chainId": 1,
      "address": "0x6f259637dcD74C767781E37Bc6133cd6A68aa161",
      "name": "Huobi",
      "symbol": "HT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2822/large/huobi-token-logo.png?1547036992"
    },
    {
      "chainId": 1,
      "address": "0xf418588522d5dd018b425E472991E52EBBeEEEEE",
      "name": "Push Protocol",
      "symbol": "PUSH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14769/large/aiOxYOJI_400x400.jpeg?1664499790"
    },
    {
      "chainId": 1,
      "address": "0x9d71CE49ab8A0E6D2a1e7BFB89374C9392FD6804",
      "name": "NvirWorld",
      "symbol": "NVIR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21359/large/Nvir_symbol.png?1639013234"
    },
    {
      "chainId": 1,
      "address": "0x38e4adB44ef08F22F5B5b76A8f0c2d0dCbE7DcA1",
      "name": "PowerPool Concentrated Voting Power",
      "symbol": "CVP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12266/large/Powerpool.jpg?1598621373"
    },
    {
      "chainId": 1,
      "address": "0xfd0205066521550D7d7AB19DA8F72bb004b4C341",
      "name": "Timeless",
      "symbol": "LIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28714/large/timeless-logo_3x.png?1673575624"
    },
    {
      "chainId": 1,
      "address": "0x4c11249814f11b9346808179Cf06e71ac328c1b5",
      "name": "Oraichain",
      "symbol": "ORAI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12931/large/orai.png?1647077378"
    },
    {
      "chainId": 1,
      "address": "0xc2544A32872A91F4A553b404C6950e89De901fdb",
      "name": "Frax Price Index Share",
      "symbol": "FPIS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24944/large/FPIS_icon.png?1679886817"
    },
    {
      "chainId": 1,
      "address": "0xCE3f08e664693ca792caCE4af1364D5e220827B2",
      "name": "Saitama",
      "symbol": "SAITAMA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/16353/large/SOIKDUWf_400x400.jpeg?1661170022"
    },
    {
      "chainId": 1,
      "address": "0x120a3879da835A5aF037bB2d1456beBd6B54d4bA",
      "name": "Revest Finance",
      "symbol": "RVST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18622/large/Qma94n6waADECpde1ukBBS8iNiECcdVcxjfgubnWPE9ZT7.png?1632701737"
    },
    {
      "chainId": 1,
      "address": "0xFc979087305A826c2B2a0056cFAbA50aad3E6439",
      "name": "Dafi Protocol",
      "symbol": "DAFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14428/large/Dafi_Black_Icon.png?1616040406"
    },
    {
      "chainId": 1,
      "address": "0x7a2Bc711E19ba6aff6cE8246C546E8c4B4944DFD",
      "name": "WAXE",
      "symbol": "WAXE",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13508/large/waxe_logo.png?1609232755"
    },
    {
      "chainId": 1,
      "address": "0x53C8395465A84955c95159814461466053DedEDE",
      "name": "DeGate",
      "symbol": "DG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14415/large/DG_token_brand_web_rgb_blue.png?1669460087"
    },
    {
      "chainId": 1,
      "address": "0x04C17b9D3b29A78F7Bd062a57CF44FC633e71f85",
      "name": "IMPT",
      "symbol": "IMPT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28486/large/IMPT_logo.png?1677543087"
    },
    {
      "chainId": 1,
      "address": "0x67675239Fa58c84e75f947c14f566842Dccb69Ae",
      "name": "PixiaAI",
      "symbol": "PIXIA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28941/large/PixiaAi.png?1675568793"
    },
    {
      "chainId": 1,
      "address": "0x3301Ee63Fb29F863f2333Bd4466acb46CD8323E6",
      "name": "Akita Inu",
      "symbol": "AKITA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14115/large/akita.png?1661666578"
    },
    {
      "chainId": 1,
      "address": "0x08c32b0726C5684024ea6e141C50aDe9690bBdcc",
      "name": "Stratos",
      "symbol": "STOS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16213/large/token_512x512.png?1623313898"
    },
    {
      "chainId": 1,
      "address": "0x40FD72257597aA14C7231A7B1aaa29Fce868F677",
      "name": "Sora",
      "symbol": "XOR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11093/large/sora_logo_cg_white.png?1588284194"
    },
    {
      "chainId": 1,
      "address": "0x01BA67AAC7f75f647D94220Cc98FB30FCc5105Bf",
      "name": "Lyra Finance",
      "symbol": "LYRA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21490/large/Add-a-heading-26.png?1639364177"
    },
    {
      "chainId": 1,
      "address": "0x616ef40D55C0D2c506f4d6873Bda8090b79BF8fC",
      "name": "Kounotori",
      "symbol": "KTO",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/21251/large/KTO.png?1650528876"
    },
    {
      "chainId": 1,
      "address": "0xEC213F83defB583af3A000B1c0ada660b1902A0F",
      "name": "Presearch",
      "symbol": "PRE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1299/large/presearch.png?1548331942"
    },
    {
      "chainId": 1,
      "address": "0xFa14Fa6958401314851A17d6C5360cA29f74B57B",
      "name": "Saito",
      "symbol": "SAITO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14750/large/SAITO.png?1626857406"
    },
    {
      "chainId": 1,
      "address": "0x5c147e74D63B1D31AA3Fd78Eb229B65161983B2b",
      "name": "Wrapped Flow",
      "symbol": "WFLOW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24045/large/wrapped-flow.png?1646187143"
    },
    {
      "chainId": 1,
      "address": "0x9aE380F0272E2162340a5bB646c354271c0F5cFC",
      "name": "Conic",
      "symbol": "CNC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24747/large/cnc.png?1677911934"
    },
    {
      "chainId": 1,
      "address": "0x70401dFD142A16dC7031c56E862Fc88Cb9537Ce0",
      "name": "Bird Money",
      "symbol": "BIRD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13260/large/favicon-180x180.png?1611546646"
    },
    {
      "chainId": 1,
      "address": "0xA15C7Ebe1f07CaF6bFF097D8a589fb8AC49Ae5B3",
      "name": "Pundi X  OLD ",
      "symbol": "NPXS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2170/large/pundi-x.png?1548386366"
    },
    {
      "chainId": 1,
      "address": "0x34F0915a5f15a66Eba86F6a58bE1A471FB7836A7",
      "name": "PulseDogecoin",
      "symbol": "PLSD",
      "decimals": 12,
      "logoURI": "https://assets.coingecko.com/coins/images/25327/large/Final_Doge.png?1674461869"
    },
    {
      "chainId": 1,
      "address": "0xd6327ce1fb9D6020E8C2c0E124A1eC23DCAb7536",
      "name": "Cuminu",
      "symbol": "CUMINU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15832/large/CUMINU.png?1628849016"
    },
    {
      "chainId": 1,
      "address": "0x43A96962254855F16b925556f9e97BE436A43448",
      "name": "Hord",
      "symbol": "HORD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14972/large/Avatar_white.png?1619513849"
    },
    {
      "chainId": 1,
      "address": "0xAaEf88cEa01475125522e117BFe45cF32044E238",
      "name": "GuildFi",
      "symbol": "GF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20933/large/guildfi-logo-200.png?1638003537"
    },
    {
      "chainId": 1,
      "address": "0x7dE91B204C1C737bcEe6F000AAA6569Cf7061cb7",
      "name": "Robonomics Network",
      "symbol": "XRT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/7024/large/Robonomics-Network-logo.png?1547043451"
    },
    {
      "chainId": 1,
      "address": "0x12b6893cE26Ea6341919FE289212ef77e51688c8",
      "name": "Tamadoge",
      "symbol": "TAMA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27501/large/CaltNDWu_400x400.jpeg?1664329157"
    },
    {
      "chainId": 1,
      "address": "0xc3D088842DcF02C13699F936BB83DFBBc6f721Ab",
      "name": "Voucher ETH",
      "symbol": "VETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14484/large/veth_logo_uniswap_200x200.png?1616471309"
    },
    {
      "chainId": 1,
      "address": "0x9565c2036963697786705120Fc59310F747bCfD0",
      "name": "PoorPleb",
      "symbol": "PP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28063/large/PP_TOKEN_LOGO.png?1669366801"
    },
    {
      "chainId": 1,
      "address": "0xF1cA9cb74685755965c7458528A36934Df52A3EF",
      "name": "AVINOC",
      "symbol": "AVINOC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4659/large/qX7fh69Q_400x400-1.jpg?1636680685"
    },
    {
      "chainId": 1,
      "address": "0xe0bCEEF36F3a6eFDd5EEBFACD591423f8549B9D5",
      "name": "Defactor",
      "symbol": "FACTR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19201/large/jFLSu4U9_400x400.png?1650437050"
    },
    {
      "chainId": 1,
      "address": "0xe3818504c1B32bF1557b16C238B2E01Fd3149C17",
      "name": "Pillar",
      "symbol": "PLR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/809/large/v2logo-1.png?1624906282"
    },
    {
      "chainId": 1,
      "address": "0x9343e24716659A3551eB10Aff9472A2dcAD5Db2d",
      "name": "STFX",
      "symbol": "STFX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28631/large/stfx.png?1680832143"
    },
    {
      "chainId": 1,
      "address": "0x956F47F50A910163D8BF957Cf5846D573E7f87CA",
      "name": "Fei USD",
      "symbol": "FEI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14570/large/ZqsF51Re_400x400.png?1617082206"
    },
    {
      "chainId": 1,
      "address": "0xcAa9Ed6D7502595B555113D4517668aE24038C8a",
      "name": "Marvin Inu",
      "symbol": "MARVIN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22039/large/lVshyCp.png?1640669485"
    },
    {
      "chainId": 1,
      "address": "0xE95A203B1a91a908F9B9CE46459d101078c2c3cb",
      "name": "Ankr Staked ETH",
      "symbol": "ANKRETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13403/large/aETHc.png?1625756490"
    },
    {
      "chainId": 1,
      "address": "0xeD35af169aF46a02eE13b9d79Eb57d6D68C1749e",
      "name": "ECOMI",
      "symbol": "OMI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4428/large/ECOMI.png?1557928886"
    },
    {
      "chainId": 1,
      "address": "0x80D55c03180349Fff4a229102F62328220A96444",
      "name": "Opulous",
      "symbol": "OPUL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16548/large/opulous.PNG?1624418744"
    },
    {
      "chainId": 1,
      "address": "0x5EE84583f67D5EcEa5420dBb42b462896E7f8D06",
      "name": "PulseBitcoin",
      "symbol": "PLSB",
      "decimals": 12,
      "logoURI": "https://assets.coingecko.com/coins/images/28690/large/%E2%82%BF.png?1673404685"
    },
    {
      "chainId": 1,
      "address": "0x138C2F1123cF3f82E4596d097c118eAc6684940B",
      "name": "Alpha Coin",
      "symbol": "ALPHA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22199/large/cgicon.png?1677062484"
    },
    {
      "chainId": 1,
      "address": "0xDd1Ad9A21Ce722C151A836373baBe42c868cE9a4",
      "name": "Universal Basic Income",
      "symbol": "UBI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15269/large/ubi.png?1620287853"
    },
    {
      "chainId": 1,
      "address": "0xa8c8CfB141A3bB59FEA1E2ea6B79b5ECBCD7b6ca",
      "name": "Syntropy",
      "symbol": "NOIA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3269/large/Component_1.png?1608275724"
    },
    {
      "chainId": 1,
      "address": "0x89Ab32156e46F46D02ade3FEcbe5Fc4243B9AAeD",
      "name": "pNetwork",
      "symbol": "PNT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11659/large/pNetwork.png?1592411134"
    },
    {
      "chainId": 1,
      "address": "0x8400D94A5cb0fa0D041a3788e395285d61c9ee5e",
      "name": "Unibright",
      "symbol": "UBT",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/2707/large/UnibrightLogo_colorful_500x500_preview.png?1547036916"
    },
    {
      "chainId": 1,
      "address": "0x3Dd98C8A089dBCFF7e8FC8d4f532BD493501Ab7F",
      "name": "Town Star",
      "symbol": "TOWN",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/19581/large/town.png?1635840875"
    },
    {
      "chainId": 1,
      "address": "0x8Fc8f8269ebca376D046Ce292dC7eaC40c8D358A",
      "name": "DeFiChain",
      "symbol": "DFI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/11757/large/symbol-defi-blockchain_200.png?1597306538"
    },
    {
      "chainId": 1,
      "address": "0x32a7C02e79c4ea1008dD6564b35F131428673c41",
      "name": "Crust Network",
      "symbol": "CRU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12549/large/sAB3KVzD_400x400.jpg?1600680411"
    },
    {
      "chainId": 1,
      "address": "0x9506d37f70eB4C3d79C398d326C871aBBf10521d",
      "name": "Media Licensing Token",
      "symbol": "MLT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15659/large/milc_200x200.png?1621511031"
    },
    {
      "chainId": 1,
      "address": "0x1EA48B9965bb5086F3b468E50ED93888a661fc17",
      "name": "Moneta DAO",
      "symbol": "MON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27493/large/logo-moneta.png?1664268389"
    },
    {
      "chainId": 1,
      "address": "0xeEAA40B28A2d1b0B08f6f97bB1DD4B75316c6107",
      "name": "CVI",
      "symbol": "GOVI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13875/large/GOVI.png?1612451531"
    },
    {
      "chainId": 1,
      "address": "0x8Ab7404063Ec4DBcfd4598215992DC3F8EC853d7",
      "name": "Akropolis",
      "symbol": "AKRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3328/large/Akropolis.png?1547037929"
    },
    {
      "chainId": 1,
      "address": "0x4C6eC08CF3fc987c6C4BEB03184D335A2dFc4042",
      "name": "MurAll",
      "symbol": "PAINT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14103/large/paint_logo_200x200.png?1614325640"
    },
    {
      "chainId": 1,
      "address": "0xB1f1F47061A7Be15C69f378CB3f69423bD58F2F8",
      "name": "Flashstake",
      "symbol": "FLASH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13533/large/FLASH.png?1615182275"
    },
    {
      "chainId": 1,
      "address": "0xa41161AF8D4Ee421ba5fED4328F2B12034796A21",
      "name": "Artify",
      "symbol": "AFY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29219/large/200x200_trans.png?1680505514"
    },
    {
      "chainId": 1,
      "address": "0xeca82185adCE47f39c684352B0439f030f860318",
      "name": "PERL eco",
      "symbol": "PERL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4682/large/PERL.eco-Icon-green_6x.png?1624365340"
    },
    {
      "chainId": 1,
      "address": "0x69A95185ee2a045CDC4bCd1b1Df10710395e4e23",
      "name": "Poolz Finance  OLD ",
      "symbol": "POOLZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13679/large/poolz_logo.png?1610806091"
    },
    {
      "chainId": 1,
      "address": "0xf16e81dce15B08F326220742020379B855B87DF9",
      "name": "Popsicle Finance",
      "symbol": "ICE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14586/large/ice.png?1617188825"
    },
    {
      "chainId": 1,
      "address": "0x173E552Bf97BBD50b455514ac52991Ef639ba703",
      "name": "Shido",
      "symbol": "SHIDO",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26674/large/Shido.png?1667361249"
    },
    {
      "chainId": 1,
      "address": "0xc55126051B22eBb829D00368f4B12Bde432de5Da",
      "name": "Redacted",
      "symbol": "BTRFLY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26745/large/redacted_v2.jpg?1660011507"
    },
    {
      "chainId": 1,
      "address": "0x888ceA2BBDD5D47a4032cf63668D7525C74af57A",
      "name": "Poof Token",
      "symbol": "POOF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28885/large/C3AD4384-2AB9-4364-8DEA-AE32A091F182.jpeg?1675147686"
    },
    {
      "chainId": 1,
      "address": "0xC82E3dB60A52CF7529253b4eC688f631aad9e7c2",
      "name": "Arc",
      "symbol": "ARC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24235/large/arc.png?1647694270"
    },
    {
      "chainId": 1,
      "address": "0x49642110B712C1FD7261Bc074105E9E44676c68F",
      "name": "DinoLFG",
      "symbol": "DINO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28239/large/lufu2UF.jpeg?1675138985"
    },
    {
      "chainId": 1,
      "address": "0x686f2404e77Ab0d9070a46cdfb0B7feCDD2318b0",
      "name": "LORDS",
      "symbol": "LORDS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22171/large/Frame_1.png?1642334107"
    },
    {
      "chainId": 1,
      "address": "0x1C4853Ec0d55e420002c5eFaBc7Ed8e0bA7A4121",
      "name": "Kanagawa Nami",
      "symbol": "OKINAMI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26629/large/KANAGAWA_%284%29.png?1659324703"
    },
    {
      "chainId": 1,
      "address": "0x16ECCfDbb4eE1A85A33f3A9B21175Cd7Ae753dB4",
      "name": "Router Protocol",
      "symbol": "ROUTE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13709/large/route_token_200x200-19.png?1611057698"
    },
    {
      "chainId": 1,
      "address": "0xB9d99C33eA2d86EC5eC6b8A4dD816EBBA64404AF",
      "name": "K21",
      "symbol": "K21",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14466/large/k21-token.png?1616775801"
    },
    {
      "chainId": 1,
      "address": "0x7D29A64504629172a429e64183D6673b9dAcbFCe",
      "name": "Vectorspace AI",
      "symbol": "VXV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2063/large/vectorspace-ai-logo.jpeg?1547036362"
    },
    {
      "chainId": 1,
      "address": "0xF94b5C5651c888d928439aB6514B93944eEE6F48",
      "name": "Yield App",
      "symbol": "YLD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13365/large/Google_Play_Store_Icon.png?1657012535"
    },
    {
      "chainId": 1,
      "address": "0x93ED3FBe21207Ec2E8f2d3c3de6e058Cb73Bc04d",
      "name": "Kleros",
      "symbol": "PNK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3833/large/kleros.png?1547975322"
    },
    {
      "chainId": 1,
      "address": "0x4740735AA98Dc8aa232BD049f8F0210458E7fCa3",
      "name": "Ridotto",
      "symbol": "RDT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18671/large/200x200_%2832%29.png?1632875527"
    },
    {
      "chainId": 1,
      "address": "0x3aFfCCa64c2A6f4e3B6Bd9c64CD2C969EFd1ECBe",
      "name": "DSLA Protocol",
      "symbol": "DSLA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/6694/large/dsla_logo-squared_200x200.png?1569571063"
    },
    {
      "chainId": 1,
      "address": "0x66761Fa41377003622aEE3c7675Fc7b5c1C2FaC5",
      "name": "Clearpool",
      "symbol": "CPOOL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19252/large/photo_2022-08-31_12.45.02.jpeg?1662105063"
    },
    {
      "chainId": 1,
      "address": "0xEEF9f339514298C6A857EfCfC1A762aF84438dEE",
      "name": "Hermez Network",
      "symbol": "HEZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12826/large/hermez_logo.png?1602826556"
    },
    {
      "chainId": 1,
      "address": "0x8B3870Df408fF4D7C3A26DF852D41034eDa11d81",
      "name": "IOI",
      "symbol": "IOI",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/15952/large/IOI_new_logo.png?1636797701"
    },
    {
      "chainId": 1,
      "address": "0x1E0b2992079B620AA13A7c2E7c88D2e1E18E46E9",
      "name": "KOMPETE Token",
      "symbol": "KOMPETE",
      "decimals": 10,
      "logoURI": "https://assets.coingecko.com/coins/images/24298/large/KOMPETE_LOGO.?1669463130"
    },
    {
      "chainId": 1,
      "address": "0xaE697F994Fc5eBC000F8e22EbFfeE04612f98A0d",
      "name": "LGCY Network",
      "symbol": "LGCY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12181/large/LGCY_network.jpg?1597926587"
    },
    {
      "chainId": 1,
      "address": "0x12BB890508c125661E03b09EC06E404bc9289040",
      "name": "Radio Caca",
      "symbol": "RACA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17841/large/ez44_BSs_400x400.jpg?1629464170"
    },
    {
      "chainId": 1,
      "address": "0xe76C6c83af64e4C60245D8C7dE953DF673a7A33D",
      "name": "Railgun",
      "symbol": "RAIL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16840/large/railgun.jpeg?1625322775"
    },
    {
      "chainId": 1,
      "address": "0x9fa69536d1cda4A04cFB50688294de75B505a9aE",
      "name": "DeRace",
      "symbol": "DERC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17438/large/DERC_logo_coingecko.png?1665714278"
    },
    {
      "chainId": 1,
      "address": "0xac3211a5025414Af2866FF09c23FC18bc97e79b1",
      "name": "Dovu",
      "symbol": "DOV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1072/large/Dovu_Earth_72x72_leaf_blue.png?1615259361"
    },
    {
      "chainId": 1,
      "address": "0x430EF9263E76DAE63c84292C3409D61c598E9682",
      "name": "Vulcan Forged",
      "symbol": "PYR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14770/large/1617088937196.png?1619414736"
    },
    {
      "chainId": 1,
      "address": "0x43Ab765ee05075d78AD8aa79dcb1978CA3079258",
      "name": "POW",
      "symbol": "POW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22333/large/16963.png?1641515902"
    },
    {
      "chainId": 1,
      "address": "0x8B39B70E39Aa811b69365398e0aACe9bee238AEb",
      "name": "Red Kite",
      "symbol": "PKF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14422/large/red_kite.png?1679564335"
    },
    {
      "chainId": 1,
      "address": "0xa41F142b6eb2b164f8164CAE0716892Ce02f311f",
      "name": "Avocado DAO",
      "symbol": "AVG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21102/large/logo192_%281%29.png?1640567889"
    },
    {
      "chainId": 1,
      "address": "0x64Df3aAB3b21cC275bB76c4A581Cf8B726478ee0",
      "name": "Cramer Coin",
      "symbol": "CRAMER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27463/large/cramercoin.jpg?1664176668"
    },
    {
      "chainId": 1,
      "address": "0x0000000000095413afC295d19EDeb1Ad7B71c952",
      "name": "Tokenlon",
      "symbol": "LON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13454/large/lon_logo.png?1608701720"
    },
    {
      "chainId": 1,
      "address": "0x0cEC1A9154Ff802e7934Fc916Ed7Ca50bDE6844e",
      "name": "PoolTogether",
      "symbol": "POOL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14003/large/PoolTogether.png?1613585632"
    },
    {
      "chainId": 1,
      "address": "0xf0a163a26601D9dc8Aef26b388Eadb7B1c620d24",
      "name": "Tickr",
      "symbol": "TICKR",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28835/large/logo-t.png?1677061954"
    },
    {
      "chainId": 1,
      "address": "0xA2b4C0Af19cC16a6CfAcCe81F192B024d625817D",
      "name": "Kishu Inu",
      "symbol": "KISHU",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/14890/large/uVLzCoP.png?1622445866"
    },
    {
      "chainId": 1,
      "address": "0xe03B2642A5111aD0EFc0cbCe766498c2dd562Ae9",
      "name": "Old Bitcoin",
      "symbol": "BC",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28832/large/bitcoinlogo.png?1674790389"
    },
    {
      "chainId": 1,
      "address": "0xc98D64DA73a6616c42117b582e832812e7B8D57F",
      "name": "RSS3",
      "symbol": "RSS3",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23575/large/RSS3.png?1644494645"
    },
    {
      "chainId": 1,
      "address": "0x3B604747ad1720C01ded0455728b62c0d2F100F0",
      "name": "WAGMI Game",
      "symbol": "WAGMIGAMES",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25906/large/Eohd79rn_400x400.jpg?1654582966"
    },
    {
      "chainId": 1,
      "address": "0x5a666c7d92E5fA7Edcb6390E4efD6d0CDd69cF37",
      "name": "Unmarshal",
      "symbol": "MARSH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14554/large/img_circle_256x256.png?1616997706"
    },
    {
      "chainId": 1,
      "address": "0xEBd9D99A3982d547C5Bb4DB7E3b1F9F14b67Eb83",
      "name": "Everest",
      "symbol": "ID",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5209/large/Everest.jpg?1628042930"
    },
    {
      "chainId": 1,
      "address": "0x8a854288a5976036A725879164Ca3e91d30c6A1B",
      "name": "GET Protocol",
      "symbol": "GET",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1927/large/GET_Protocol.png?1552893230"
    },
    {
      "chainId": 1,
      "address": "0x0d88eD6E74bbFD96B831231638b66C05571e824F",
      "name": "Aventus",
      "symbol": "AVT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/901/large/1673958879448.jpeg?1676793873"
    },
    {
      "chainId": 1,
      "address": "0x9c354503C38481a7A7a51629142963F98eCC12D0",
      "name": "Origin Dollar Governance",
      "symbol": "OGV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26353/large/ogv-200x200.png?1657606918"
    },
    {
      "chainId": 1,
      "address": "0xFeeB4D0f5463B1b04351823C246bdB84c4320CC2",
      "name": "Gold Retriever",
      "symbol": "GLDN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27529/large/33406C30-2F50-45D8-9F75-5B7EAEB23038.jpeg?1664371749"
    },
    {
      "chainId": 1,
      "address": "0x0d8ca4b20b115D4DA5c13DC45Dd582A5de3e78BF",
      "name": "Generaitiv",
      "symbol": "GAI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29158/large/logo-200x200.png?1677039466"
    },
    {
      "chainId": 1,
      "address": "0x0B452278223D3954F4AC050949D7998e373e7E43",
      "name": "Shita kiri Suzume",
      "symbol": "SUZUME",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26813/large/shitakiri_cmc.png?1660275049"
    },
    {
      "chainId": 1,
      "address": "0x038a68FF68c393373eC894015816e33Ad41BD564",
      "name": "Glitch Protocol",
      "symbol": "GLCH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13712/large/glitch_logo.jpeg?1611100011"
    },
    {
      "chainId": 1,
      "address": "0xfb130d93E49DcA13264344966A611dc79a456Bc5",
      "name": "DogeGF",
      "symbol": "DOGEGF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18651/large/dogf.png?1632758659"
    },
    {
      "chainId": 1,
      "address": "0x1C9922314ED1415c95b9FD453c3818fd41867d0B",
      "name": "Tower",
      "symbol": "TOWER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14134/large/tower-circular-1000.png?1632195469"
    },
    {
      "chainId": 1,
      "address": "0x21BfBDa47A0B4B5b1248c767Ee49F7caA9B23697",
      "name": "Ovr",
      "symbol": "OVR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13429/large/ovr_logo.png?1608518911"
    },
    {
      "chainId": 1,
      "address": "0x4aa41bC1649C9C3177eD16CaaA11482295fC7441",
      "name": "XFai",
      "symbol": "XFIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14904/large/XFAI_Logo200x200.jpg?1678328437"
    },
    {
      "chainId": 1,
      "address": "0x77777FeDdddFfC19Ff86DB637967013e6C6A116C",
      "name": "Tornado Cash",
      "symbol": "TORN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13496/large/ZINt8NSB_400x400.jpg?1609193407"
    },
    {
      "chainId": 1,
      "address": "0xE80C0cd204D654CEbe8dd64A4857cAb6Be8345a3",
      "name": "JPEG d",
      "symbol": "JPEG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24025/large/et_43CNi_400x400.jpg?1646100264"
    },
    {
      "chainId": 1,
      "address": "0x817bbDbC3e8A1204f3691d14bB44992841e3dB35",
      "name": "Cudos",
      "symbol": "CUDOS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13651/large/CudosIconTransparent.png?1610631426"
    },
    {
      "chainId": 1,
      "address": "0x7A58c0Be72BE218B41C608b7Fe7C5bB630736C71",
      "name": "ConstitutionDAO",
      "symbol": "PEOPLE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20612/large/GN_UVm3d_400x400.jpg?1637294355"
    },
    {
      "chainId": 1,
      "address": "0xAC57De9C1A09FeC648E93EB98875B212DB0d460B",
      "name": "Baby Doge Coin",
      "symbol": "BABYDOGE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/16125/large/babydoge.jpg?1676303229"
    },
    {
      "chainId": 1,
      "address": "0xaA8330FB2B4D5D07ABFE7A72262752a8505C6B37",
      "name": "Polkacity",
      "symbol": "POLC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14066/large/vykih1Nq_400x400.png?1614130959"
    },
    {
      "chainId": 1,
      "address": "0xc6DdDB5bc6E61e0841C54f3e723Ae1f3A807260b",
      "name": "Aurox",
      "symbol": "URUS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14122/large/Aurox.png?1648524329"
    },
    {
      "chainId": 1,
      "address": "0x08ba718F288c3b12B01146816bef9FA03cC635bc",
      "name": "Centaurify",
      "symbol": "CENT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20512/large/Centaurify_Symbol_Black-01.png?1681802100"
    },
    {
      "chainId": 1,
      "address": "0x4a615bB7166210CCe20E6642a6f8Fb5d4D044496",
      "name": "NAOS Finance",
      "symbol": "NAOS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15144/large/bafybeibkztkshitabrf7yqqkqtbjqestjknpgv7lsjfzdsa3ufspagqs2e.ipfs.infura-ipfs.io.png?1622176770"
    },
    {
      "chainId": 1,
      "address": "0xf59257E961883636290411c11ec5Ae622d19455e",
      "name": "FloorDAO",
      "symbol": "FLOOR",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/24026/large/icon-floor_2x.png?1646102857"
    },
    {
      "chainId": 1,
      "address": "0x0aA7eFE4945Db24d95cA6E117BBa65Ed326e291A",
      "name": "Ojamu",
      "symbol": "OJA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18947/large/ojamu-icon-PNK.png?1634006741"
    },
    {
      "chainId": 1,
      "address": "0xd38BB40815d2B0c2d2c866e0c72c5728ffC76dd9",
      "name": "Symbiosis Finance",
      "symbol": "SIS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20805/large/SymbiosisFinance_logo-150x150.jpeg?1637707064"
    },
    {
      "chainId": 1,
      "address": "0xFc0d6Cf33e38bcE7CA7D89c0E292274031b7157A",
      "name": "Netvrk",
      "symbol": "NTVRK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15721/large/netvrk_icon.png?1627536091"
    },
    {
      "chainId": 1,
      "address": "0xaaAEBE6Fe48E54f431b0C390CfaF0b017d09D42d",
      "name": "Celsius Network",
      "symbol": "CEL",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/3263/large/CEL_logo.png?1609598753"
    },
    {
      "chainId": 1,
      "address": "0x71Fc1F555a39E0B698653AB0b475488EC3c34D57",
      "name": "Rainmaker Games",
      "symbol": "RAIN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21485/large/Final-Flip-Rain-Makers-44-1.png?1639362827"
    },
    {
      "chainId": 1,
      "address": "0xC52C326331E9Ce41F04484d3B5E5648158028804",
      "name": "Unizen",
      "symbol": "ZCX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14830/large/7xjpHaG.png?1618564961"
    },
    {
      "chainId": 1,
      "address": "0xB0c7a3Ba49C7a6EaBa6cD4a96C55a1391070Ac9A",
      "name": "Magic",
      "symbol": "MAGIC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18623/large/magic.png?1656052146"
    },
    {
      "chainId": 1,
      "address": "0x0cbA60Ca5eF4D42f92A5070A8fEDD13BE93E2861",
      "name": "The Protocol",
      "symbol": "THE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27849/large/cSar5sDM_400x400.jpg?1666085191"
    },
    {
      "chainId": 1,
      "address": "0xcAfE001067cDEF266AfB7Eb5A286dCFD277f3dE5",
      "name": "ParaSwap",
      "symbol": "PSP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20403/large/ep7GqM19_400x400.jpg?1636979120"
    },
    {
      "chainId": 1,
      "address": "0xBa3335588D9403515223F109EdC4eB7269a9Ab5D",
      "name": "Gearbox",
      "symbol": "GEAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21630/large/gear.png?1640330291"
    },
    {
      "chainId": 1,
      "address": "0x833850BE8858722Cfc5E5e75f2Fe6275E055d888",
      "name": "DecentraBNB",
      "symbol": "DBNB",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26544/large/Screenshot_2022-07-22_at_18.16.11.png?1658735503"
    },
    {
      "chainId": 1,
      "address": "0x4da0C48376C277cdBd7Fc6FdC6936DEE3e4AdF75",
      "name": "Epik Prime",
      "symbol": "EPIK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17907/large/EPIK_Prime_LOGO.jpg?1630738458"
    },
    {
      "chainId": 1,
      "address": "0xee573a945B01B788B9287CE062A0CFC15bE9fd86",
      "name": "Exeedme",
      "symbol": "XED",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13518/large/exeedme.png?1610669597"
    },
    {
      "chainId": 1,
      "address": "0x005D1123878Fc55fbd56b54C73963b234a64af3c",
      "name": "Kiba Inu",
      "symbol": "KIBA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19525/large/kiba.png?1648549322"
    },
    {
      "chainId": 1,
      "address": "0x8642A849D0dcb7a15a974794668ADcfbe4794B56",
      "name": "Prosper",
      "symbol": "PROS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13668/large/heD6cg22l3sF5VgPh4G1xC6lnKEWXJif-jbaqUpv8CDP6jbWaqn9UjBdkXWNrw1CewaQOxb8zXRdNeNJWWiUDjfsEl_d7E3bPLg4cFoilQF5TGKHfWyJlnpm3UYc9ytvRvOjxOevMuiu8-lusnNoOcwgsJpMkYWHqe322GAxLt0_30kFMVAcjEDUrOlkK6hUYi0m9P433mvNlOm.jpg?1610671732"
    },
    {
      "chainId": 1,
      "address": "0x6bB61215298F296C55b19Ad842D3Df69021DA2ef",
      "name": "Drops Ownership Power",
      "symbol": "DOP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15696/large/dop.png?1640325078"
    },
    {
      "chainId": 1,
      "address": "0xea3983Fc6D0fbbC41fb6F6091f68F3e08894dC06",
      "name": "Unido",
      "symbol": "UDO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14176/large/unido.jpg?1614792353"
    },
    {
      "chainId": 1,
      "address": "0x87d73E916D7057945c9BcD8cdd94e42A6F47f776",
      "name": "NFTX",
      "symbol": "NFTX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13574/large/NFTX_%28Real%29.jpg?1613449530"
    },
    {
      "chainId": 1,
      "address": "0x970B9bB2C0444F5E81e9d0eFb84C8ccdcdcAf84d",
      "name": "Fuse",
      "symbol": "FUSE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10347/large/fuse.png?1675703585"
    },
    {
      "chainId": 1,
      "address": "0xcB84d72e61e383767C4DFEb2d8ff7f4FB89abc6e",
      "name": "Vega Protocol",
      "symbol": "VEGA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15870/large/vega.PNG?1622178218"
    },
    {
      "chainId": 1,
      "address": "0xfFffFffF2ba8F66D4e51811C5190992176930278",
      "name": "Furucombo",
      "symbol": "COMBO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13629/large/COMBO_token_ol.png?1610701537"
    },
    {
      "chainId": 1,
      "address": "0x6100dd79fCAA88420750DceE3F735d168aBcB771",
      "name": "NONbeta",
      "symbol": "SOON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19592/large/soon.jpg?1681377764"
    },
    {
      "chainId": 1,
      "address": "0xEA1ea0972fa092dd463f2968F9bB51Cc4c981D71",
      "name": "Modefi",
      "symbol": "MOD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13980/large/modefi_logo.png?1613453111"
    },
    {
      "chainId": 1,
      "address": "0xDc0327D50E6C73db2F8117760592C8BBf1CDCF38",
      "name": "Stronger",
      "symbol": "STRNGR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24922/large/200x200_logo.png?1650609989"
    },
    {
      "chainId": 1,
      "address": "0x20d4DB1946859E2Adb0e5ACC2eac58047aD41395",
      "name": "Moon DAO",
      "symbol": "MOONEY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22905/large/cVWTHdA.png?1645690722"
    },
    {
      "chainId": 1,
      "address": "0xA0CF46eb152656C7090e769916eb44a138aaa406",
      "name": "Spheroid Universe",
      "symbol": "SPH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11968/large/spheroid-sph-icon-400x400.png?1597307957"
    },
    {
      "chainId": 1,
      "address": "0x656C00e1BcD96f256F224AD9112FF426Ef053733",
      "name": "Efinity",
      "symbol": "EFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16558/large/efi-200px_%281%29.png?1624439132"
    },
    {
      "chainId": 1,
      "address": "0x93C9175E26F57d2888c7Df8B470C9eeA5C0b0A93",
      "name": "B cube ai",
      "symbol": "BCUBE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15948/large/bcube.PNG?1622511353"
    },
    {
      "chainId": 1,
      "address": "0x96610186F3ab8d73EBEe1CF950C750f3B1Fb79C2",
      "name": "Enjinstarter",
      "symbol": "EJS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18732/large/l-R1nYA0_400x400.jpg?1633297242"
    },
    {
      "chainId": 1,
      "address": "0xaDB2437e6F65682B85F814fBc12FeC0508A7B1D0",
      "name": "UNCX Network",
      "symbol": "UNCX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12871/large/uncx.png?1676952157"
    },
    {
      "chainId": 1,
      "address": "0x2eDf094dB69d6Dcd487f1B3dB9febE2eeC0dd4c5",
      "name": "ZeroSwap",
      "symbol": "ZEE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12861/large/logo.?1666110579"
    },
    {
      "chainId": 1,
      "address": "0x44F5909E97E1CBf5FBbDF0FC92FD83cde5d5c58A",
      "name": "Acria AI",
      "symbol": "ACRIA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28598/large/image002.png?1675131968"
    },
    {
      "chainId": 1,
      "address": "0x41A3Dba3D677E573636BA691a70ff2D606c29666",
      "name": "BlockWallet",
      "symbol": "BLANK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14209/large/blank.png?1614940842"
    },
    {
      "chainId": 1,
      "address": "0x66a0f676479Cee1d7373f3DC2e2952778BfF5bd6",
      "name": "Wise",
      "symbol": "WISE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13552/large/Wise.jpg.jpg?1672204323"
    },
    {
      "chainId": 1,
      "address": "0x70008F18Fc58928dcE982b0A69C2c21ff80Dca54",
      "name": "X7R",
      "symbol": "X7R",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27710/large/X7R.png?1665314632"
    },
    {
      "chainId": 1,
      "address": "0x5b52bfB8062Ce664D74bbCd4Cd6DC7Df53Fd7233",
      "name": "ZENIQ",
      "symbol": "ZENIQ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29284/large/zeniq.png?1677754455"
    },
    {
      "chainId": 1,
      "address": "0x48C276e8d03813224bb1e55F953adB6d02FD3E02",
      "name": "Kuma Inu",
      "symbol": "KUMA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15526/large/kuma_inu.PNG?1621128824"
    },
    {
      "chainId": 1,
      "address": "0x9695e0114e12C0d3A3636fAb5A18e6b737529023",
      "name": "Dfyn Network",
      "symbol": "DFYN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15368/large/SgqhfWz4_400x400_%281%29.jpg?1620666919"
    },
    {
      "chainId": 1,
      "address": "0xcb86c6A22CB56B6cf40CaFEDb06BA0DF188a416E",
      "name": "inSure DeFi",
      "symbol": "SURE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10354/large/logo-grey-circle.png?1614910406"
    },
    {
      "chainId": 1,
      "address": "0x72B886d09C117654aB7dA13A14d603001dE0B777",
      "name": "XDEFI",
      "symbol": "XDEFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19524/large/xdefi.png?1637917251"
    },
    {
      "chainId": 1,
      "address": "0x5A9780Bfe63f3ec57f01b087cD65BD656C9034A8",
      "name": "Communis",
      "symbol": "COM",
      "decimals": 12,
      "logoURI": "https://assets.coingecko.com/coins/images/28723/large/strongestshapetransparent-200h.png?1673595687"
    },
    {
      "chainId": 1,
      "address": "0xd4Df22556e07148e591B4c7b4f555a17188CF5cF",
      "name": "Twitfi",
      "symbol": "TWT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28755/large/23251.png?1673949057"
    },
    {
      "chainId": 1,
      "address": "0xfe98C2B85cAaFE841ca7Fa8b3B912a178A3f68eD",
      "name": "Red Rabbit",
      "symbol": "RR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28976/large/rr1.png?1675750430"
    },
    {
      "chainId": 1,
      "address": "0x00C2999c8B2AdF4ABC835cc63209533973718eB1",
      "name": "New World Order",
      "symbol": "STATE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27387/large/icon.png?1663812357"
    },
    {
      "chainId": 1,
      "address": "0x72e364F2ABdC788b7E918bc238B21f109Cd634D7",
      "name": "Metaverse Index",
      "symbol": "MVI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14684/large/MVI_logo.png?1617776444"
    },
    {
      "chainId": 1,
      "address": "0xCF3C8Be2e2C42331Da80EF210e9B1b307C03d36A",
      "name": "BEPRO Network",
      "symbol": "BEPRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10251/large/logo.png?1610592699"
    },
    {
      "chainId": 1,
      "address": "0xD9c2D319Cd7e6177336b0a9c93c21cb48d84Fb54",
      "name": "HAPI",
      "symbol": "HAPI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14298/large/R9i2HjAL_400x400.jpg?1615332438"
    },
    {
      "chainId": 1,
      "address": "0x467Bccd9d29f223BcE8043b84E8C8B282827790F",
      "name": "Telcoin",
      "symbol": "TEL",
      "decimals": 2,
      "logoURI": "https://assets.coingecko.com/coins/images/1899/large/tel.png?1547036203"
    },
    {
      "chainId": 1,
      "address": "0x3496B523e5C00a4b4150D6721320CdDb234c3079",
      "name": "NUM Token",
      "symbol": "NUM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20495/large/NP_Social_media_profile_pic.png?1664026542"
    },
    {
      "chainId": 1,
      "address": "0x7a5ce6abD131EA6B148a022CB76fc180ae3315A6",
      "name": "bAlpha",
      "symbol": "BALPHA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14224/large/logo_bAlpha_200.png?1615089190"
    },
    {
      "chainId": 1,
      "address": "0x88aa4a6C5050b9A1b2Aa7e34D0582025cA6AB745",
      "name": "Vela Exchange",
      "symbol": "DXP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25114/large/1_0w4P8R5heRFwRomJ4vPCWQ.png?1650348942"
    },
    {
      "chainId": 1,
      "address": "0x785c34312dfA6B74F6f1829f79ADe39042222168",
      "name": "Bumper",
      "symbol": "BUMP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17822/large/Bumper-Icon-Inverse-200.png?1629344025"
    },
    {
      "chainId": 1,
      "address": "0x8013266cb5c9dd48bE3Ad7D1CE832874d64B3Ce1",
      "name": "Boop",
      "symbol": "BOOP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27918/large/boop.png?1666351418"
    },
    {
      "chainId": 1,
      "address": "0x2e2364966267B5D7D2cE6CD9A9B5bD19d9C7C6A9",
      "name": "Voice",
      "symbol": "VOICE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12926/large/OjCQtdL.png?1614780024"
    },
    {
      "chainId": 1,
      "address": "0xAaAAAA20D9E0e2461697782ef11675f668207961",
      "name": "Aurora",
      "symbol": "AURORA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20582/large/aurora.jpeg?1637250883"
    },
    {
      "chainId": 1,
      "address": "0x3Ea8ea4237344C9931214796d9417Af1A1180770",
      "name": "SEDA Protocol",
      "symbol": "FLX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21137/large/flx.png?1674306547"
    },
    {
      "chainId": 1,
      "address": "0x0ff5A8451A839f5F0BB3562689D9A44089738D11",
      "name": "Dopex Rebate",
      "symbol": "RDPX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16659/large/rDPX_200x200_Coingecko.png?1624614475"
    },
    {
      "chainId": 1,
      "address": "0x3D3D35bb9bEC23b06Ca00fe472b50E7A4c692C30",
      "name": "Vidya",
      "symbol": "VIDYA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12219/large/VIDYA_TOKEN.png?1598240425"
    },
    {
      "chainId": 1,
      "address": "0x62359Ed7505Efc61FF1D56fEF82158CcaffA23D7",
      "name": "cVault finance",
      "symbol": "CORE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12635/large/cvault.finance_logo.png?1601353499"
    },
    {
      "chainId": 1,
      "address": "0x6ADb2E268de2aA1aBF6578E4a8119b960E02928F",
      "name": "ShibaDoge",
      "symbol": "SHIBDOGE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/22018/large/5HMWoFW0_400x400.jpg?1640596392"
    },
    {
      "chainId": 1,
      "address": "0xDC349913d53b446485E98b76800b6254f43Df695",
      "name": "Bezoge Earth",
      "symbol": "BEZOGE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15639/large/token-logo.png?1621408212"
    },
    {
      "chainId": 1,
      "address": "0x38d9eb07A7b8Df7D86F440A4A5c4a4c1a27E1a08",
      "name": "bloXmove",
      "symbol": "BLXM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19310/large/blxm_200x200.png?1635238192"
    },
    {
      "chainId": 1,
      "address": "0x37C997B35C619C21323F3518B9357914E8B99525",
      "name": "Unipilot",
      "symbol": "PILOT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17235/large/QmSjCnb74Q88o9gcTMMYNggj6BDkFEPukAZ5nWrhPaRxoW.png?1626923517"
    },
    {
      "chainId": 1,
      "address": "0xE5CAeF4Af8780E59Df925470b050Fb23C43CA68C",
      "name": "Ferrum Network",
      "symbol": "FRM",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/8251/large/FRM.png?1658819429"
    },
    {
      "chainId": 1,
      "address": "0xEec2bE5c91ae7f8a338e1e5f3b5DE49d07AfdC81",
      "name": "Dopex",
      "symbol": "DPX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16652/large/DPX_%281%29.png?1624598630"
    },
    {
      "chainId": 1,
      "address": "0x8AF5FedC0f263841C18F31D9DbCC97A47e1aB462",
      "name": "MESSIER",
      "symbol": "M87",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25957/large/MESSIERlogonew_%281%29.png?1666773848"
    },
    {
      "chainId": 1,
      "address": "0xB6eD7644C69416d67B522e20bC294A9a9B405B31",
      "name": "0xBitcoin",
      "symbol": "0XBTC",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/4454/large/0xbtc.png?1561603765"
    },
    {
      "chainId": 1,
      "address": "0x3593D125a4f7849a1B059E64F4517A86Dd60c95d",
      "name": "MANTRA",
      "symbol": "OM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12151/large/OM_Token.png?1666056782"
    },
    {
      "chainId": 1,
      "address": "0x6Dca182ac5E3f99985bC4Ee0f726d6472aB1ec55",
      "name": "Ushi",
      "symbol": "USHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27865/large/photo_2022-10-17_22-21-01.jpg?1666151494"
    },
    {
      "chainId": 1,
      "address": "0x81f8f0bb1cB2A06649E51913A151F0E7Ef6FA321",
      "name": "VitaDAO",
      "symbol": "VITA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16580/large/QmRjwywiAfpzSfQTuWM3zCTghSHN7G6ohQaar7Ht6WANUp.png?1624506420"
    },
    {
      "chainId": 1,
      "address": "0xE23311294467654E0CaB14cD32A169A41be5ca8E",
      "name": "Chronoly",
      "symbol": "CRNO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27752/large/Chronoly.jpeg?1665651796"
    },
    {
      "chainId": 1,
      "address": "0x43Dfc4159D86F3A37A5A4B3D4580b888ad7d4DDd",
      "name": "DODO",
      "symbol": "DODO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12651/large/dodo_logo.png?1601433025"
    },
    {
      "chainId": 1,
      "address": "0x4a527d8fc13C5203AB24BA0944F4Cb14658D1Db6",
      "name": "Morpheus Labs",
      "symbol": "MITX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3164/large/mitx.png?1604888269"
    },
    {
      "chainId": 1,
      "name": "Armor NXM",
      "address": "0x1337DEF18C680aF1f9f45cBcab6309562975b1dD",
      "decimals": 18,
      "symbol": "arNXM",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/8328.png"
    },
    {
      "chainId": 1,
      "address": "0xeb986DA994E4a118d5956b02d8b7c3C7CE373674",
      "name": "Gather",
      "symbol": "GTH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12458/large/Gather-Logo-Working-File.png?1599981686"
    },
    {
      "chainId": 1,
      "name": "AmpliFi",
      "address": "0xD23367155B55d67492DFDC0FC7f8bB1dF7114fD9",
      "decimals": 18,
      "symbol": "AMPLIFI",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/21387.png"
    },
    {
      "chainId": 1,
      "address": "0xB4b9DC1C77bdbb135eA907fd5a08094d98883A35",
      "name": "Sweatcoin  Sweat Economy ",
      "symbol": "SWEAT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25057/large/fhD9Xs16_400x400.jpg?1649947000"
    },
    {
      "chainId": 1,
      "address": "0xADf86E75d8f0F57e0288D0970E7407eaA49b3CAb",
      "name": "Apollo Crypto",
      "symbol": "APOLLO",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/22606/large/apollo-icon-green-black-w3-200.png?1656312049"
    },
    {
      "chainId": 1,
      "address": "0x0B498ff89709d3838a063f1dFA463091F9801c2b",
      "name": "BTC 2x Flexible Leverage Index",
      "symbol": "BTC2X-FLI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15406/large/Copy_of_BTC2x-FLI_token_logo.png?1646749417"
    },
    {
      "chainId": 1,
      "address": "0xCd2828fc4D8E8a0eDe91bB38CF64B1a81De65Bf6",
      "name": "Oddz",
      "symbol": "ODDZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14421/large/NewLogo.png?1645171454"
    },
    {
      "chainId": 1,
      "address": "0x00a8b738E453fFd858a7edf03bcCfe20412f0Eb0",
      "name": "AllianceBlock",
      "symbol": "ALBT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12392/large/alliance_block_logo.jpg?1599546617"
    },
    {
      "chainId": 1,
      "address": "0x62B9c7356A2Dc64a1969e19C23e4f579F9810Aa7",
      "name": "Convex CRV",
      "symbol": "CVXCRV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15586/large/convex-crv.png?1621255952"
    },
    {
      "chainId": 1,
      "address": "0x464FdB8AFFC9bac185A7393fd4298137866DCFB8",
      "name": "Realm",
      "symbol": "REALM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18366/large/realm.PNG?1631665838"
    },
    {
      "chainId": 1,
      "address": "0x7aE0d42f23C33338dE15bFa89C7405c068d9dC0a",
      "name": "Shibaverse",
      "symbol": "VERSE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18407/large/logo_200.png?1631795328"
    },
    {
      "chainId": 1,
      "address": "0xF5cFBC74057C610c8EF151A439252680AC68c6DC",
      "name": "Octopus Network",
      "symbol": "OCT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18025/large/octopus_network.png?1630290273"
    },
    {
      "chainId": 1,
      "address": "0xC0bA369c8Db6eB3924965e5c4FD0b4C1B91e305F",
      "name": "DLP Duck",
      "symbol": "DUCK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13440/large/DLP_Duck_Token.png?1612840740"
    },
    {
      "chainId": 1,
      "address": "0x295B42684F90c77DA7ea46336001010F2791Ec8c",
      "name": "Xi",
      "symbol": "XI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18640/large/v5NMxPo.png?1632751046"
    },
    {
      "chainId": 1,
      "address": "0x4e352cF164E64ADCBad318C3a1e222E9EBa4Ce42",
      "name": "MUX Protocol",
      "symbol": "MCB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11796/large/mux.jpg?1660125796"
    },
    {
      "chainId": 1,
      "address": "0x7B32e70e8D73ac87c1B342e063528B2930b15ceB",
      "name": "Robo Inu Finance",
      "symbol": "RBIF",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/20821/large/O68Gs5SE_400x400.jpg?1654929220"
    },
    {
      "chainId": 1,
      "address": "0x954b890704693af242613edEf1B603825afcD708",
      "name": "Cardstack",
      "symbol": "CARD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3247/large/cardstack.png?1547037769"
    },
    {
      "chainId": 1,
      "address": "0x8dc89F4716E027394Bba225b82328C1ea2Ea58Bf",
      "name": "Galaxy Villains",
      "symbol": "GVC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28741/large/Villains.jpeg?1673840651"
    },
    {
      "chainId": 1,
      "address": "0x1fE24F25b1Cf609B9c4e7E12D802e3640dFA5e43",
      "name": "Chain Guardians",
      "symbol": "CGG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14326/large/cgg_logo.png?1615429976"
    },
    {
      "chainId": 1,
      "address": "0xbEa98c05eEAe2f3bC8c3565Db7551Eb738c8CCAb",
      "name": "Geyser",
      "symbol": "GYSR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12995/large/logo_padded_shifted.png?1636633987"
    },
    {
      "chainId": 1,
      "address": "0x7825e833D495F3d1c28872415a4aee339D26AC88",
      "name": "Wrapped Telos",
      "symbol": "WTLOS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23952/large/tL4cEmvt_400x400.png?1645772510"
    },
    {
      "chainId": 1,
      "address": "0x44108f0223A3C3028F5Fe7AEC7f9bb2E66beF82F",
      "name": "Across Protocol",
      "symbol": "ACX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28161/large/across-200x200.png?1668168201"
    },
    {
      "chainId": 1,
      "address": "0x155ff1A85F440EE0A382eA949f24CE4E0b751c65",
      "name": "Behodler",
      "symbol": "EYE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12804/large/etherscan-eye-2-1.png?1629881415"
    },
    {
      "chainId": 1,
      "address": "0x37fE0f067FA808fFBDd12891C0858532CFE7361d",
      "name": "Civilization",
      "symbol": "CIV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17626/large/civ-200x200.png?1628674350"
    },
    {
      "chainId": 1,
      "address": "0x50D1c9771902476076eCFc8B2A83Ad6b9355a4c9",
      "name": "FTX",
      "symbol": "FTT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/9026/large/F.png?1609051564"
    },
    {
      "chainId": 1,
      "address": "0x6B9f031D718dDed0d681c20cB754F97b3BB81b78",
      "name": "GEEQ",
      "symbol": "GEEQ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11953/large/GeeqLogoPNGTransparent-1.png?1596421769"
    },
    {
      "chainId": 1,
      "address": "0xaf9f549774ecEDbD0966C52f250aCc548D3F36E5",
      "name": "RioDeFi",
      "symbol": "RFUEL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12623/large/RFUEL_SQR.png?1602481093"
    },
    {
      "chainId": 1,
      "address": "0xFE3E6a25e6b192A42a44ecDDCd13796471735ACf",
      "name": "Reef",
      "symbol": "REEF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13504/large/Group_10572.png?1610534130"
    },
    {
      "chainId": 1,
      "address": "0x2a2550e0A75aCec6D811AE3930732F7f3ad67588",
      "name": "PathDAO",
      "symbol": "PATH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21146/large/thumbnail.png?1655283979"
    },
    {
      "chainId": 1,
      "address": "0x661Ab0Ed68000491d98C796146bcF28c20d7c559",
      "name": "Shadows",
      "symbol": "DOWS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14160/large/C3E49eZx_400x400.jpg?1614689301"
    },
    {
      "chainId": 1,
      "address": "0xDb298285FE4C5410B05390cA80e8Fbe9DE1F259B",
      "name": "handle fi",
      "symbol": "FOREX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18533/large/handle.fiFOREXLogoDark200x200.png?1632755675"
    },
    {
      "chainId": 1,
      "address": "0xa47c8bf37f92aBed4A126BDA807A7b7498661acD",
      "name": "Wrapped USTC",
      "symbol": "USTC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15462/large/ust.png?1620910058"
    },
    {
      "chainId": 1,
      "address": "0x4ABB9cC67BD3da9Eb966d1159A71a0e68BD15432",
      "name": "KelVPN",
      "symbol": "KEL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14851/large/logokelvpn200x200.png?1618797379"
    },
    {
      "chainId": 1,
      "address": "0xD9016A907Dc0ECfA3ca425ab20B6b785B42F2373",
      "name": "GAMEE",
      "symbol": "GMEE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14716/large/gmee-200x200.png?1621827468"
    },
    {
      "chainId": 1,
      "address": "0x5218E472cFCFE0b64A064F055B43b4cdC9EfD3A6",
      "name": "unFederalReserve",
      "symbol": "ERSDL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12975/large/logo_eRSDL.png?1625755665"
    },
    {
      "chainId": 1,
      "address": "0xb19189Fb36c816f3e0f16065057B07B790998fDC",
      "name": "Serum SER",
      "symbol": "SER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27757/large/Untitled_design_%2810%29.png?1665824038"
    },
    {
      "chainId": 1,
      "address": "0x5d3a536E4D6DbD6114cc1Ead35777bAB948E3643",
      "name": "cDAI",
      "symbol": "CDAI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/9281/large/cDAI.png?1576467585"
    },
    {
      "chainId": 1,
      "address": "0x474021845C4643113458ea4414bdb7fB74A01A77",
      "name": "Uno Re",
      "symbol": "UNO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15073/large/c0vbqVE.png?1632814516"
    },
    {
      "chainId": 1,
      "address": "0x10f44a834097469AC340592d28c479c442E99bFe",
      "name": "Alcazar",
      "symbol": "ALCAZAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28010/large/Alcazar.jpeg?1666943350"
    },
    {
      "chainId": 1,
      "address": "0x461B71cff4d4334BbA09489acE4b5Dc1A1813445",
      "name": "Hoard",
      "symbol": "HRD",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/27300/large/hoard.png?1663212320"
    },
    {
      "chainId": 1,
      "address": "0xD478161C952357F05f0292B56012Cd8457F1cfbF",
      "name": "Polkamarkets",
      "symbol": "POLK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14084/large/polkamarkets.jpg?1614179979"
    },
    {
      "chainId": 1,
      "address": "0x628eBC64A38269E031AFBDd3C5BA857483B5d048",
      "name": "Liquid Staked ETH Index",
      "symbol": "LSETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28856/large/LSETH_logo.png?1675166249"
    },
    {
      "chainId": 1,
      "address": "0x8686525d6627A25C68De82c228448f43c97999F2",
      "name": "Lilly Token",
      "symbol": "LY",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/23787/large/jQlMieu.png?1645437427"
    },
    {
      "chainId": 1,
      "address": "0xa393473d64d2F9F026B60b6Df7859A689715d092",
      "name": "Lattice",
      "symbol": "LTX",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13050/large/Lattice.jpg?1613976295"
    },
    {
      "chainId": 1,
      "address": "0x519C1001D550C0a1DaE7d1fC220f7d14c2A521BB",
      "name": "Polkaswap",
      "symbol": "PSWAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15475/large/pswap-token-logomark-ticker-icon-200px-transparent-optimized.png?1622447028"
    },
    {
      "chainId": 1,
      "address": "0x24EC2Ca132abf8F6f8a6E24A1B97943e31f256a7",
      "name": "dotmoovs",
      "symbol": "MOOV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15817/large/dotmoovs-symbol-gradient.png?1635332626"
    },
    {
      "chainId": 1,
      "address": "0xba9d4199faB4f26eFE3551D490E3821486f135Ba",
      "name": "SwissBorg",
      "symbol": "CHSB",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/2117/large/YJUrRy7r_400x400.png?1589794215"
    },
    {
      "chainId": 1,
      "address": "0x3f5dd1A1538a4F9f82E543098f01F22480B0A3a8",
      "name": "KumaDex Token",
      "symbol": "DKUMA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26693/large/dkumaOG02_CoinGecko.png?1660618296"
    },
    {
      "chainId": 1,
      "address": "0xF725f73CAEe250AE384ec38bB2C77C38ef2CcCeA",
      "name": "Ape In Records",
      "symbol": "AIR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24194/large/gCZZdeR.jpeg?1646830675"
    },
    {
      "chainId": 1,
      "address": "0xD8E3FB3b08eBA982F2754988d70D57eDc0055ae6",
      "name": "Zoracles",
      "symbol": "ZORA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/13255/large/zora.png?1606747018"
    },
    {
      "chainId": 1,
      "address": "0xE796d6ca1ceb1b022EcE5296226BF784110031Cd",
      "name": "Blind Boxes",
      "symbol": "BLES",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14537/large/BLES-Logo-BW.png?1637158078"
    },
    {
      "chainId": 1,
      "address": "0x1E2F15302B90EddE696593607b6bD444B64e8F02",
      "name": "Shiryo",
      "symbol": "SHIRYO-INU",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/19652/large/shiryo_inu.png?1648267828"
    },
    {
      "chainId": 1,
      "address": "0xaa0c5B3567fd1bac8a2a11EB16c3F81a49eea90F",
      "name": "MetamonkeyAi",
      "symbol": "MMAI",
      "decimals": 7,
      "logoURI": "https://assets.coingecko.com/coins/images/27208/large/mmai_new_logo.png?1675187587"
    },
    {
      "chainId": 1,
      "address": "0x25e1474170c4c0aA64fa98123bdc8dB49D7802fa",
      "name": "Bidao",
      "symbol": "BID",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12596/large/bidao.png?1600996485"
    },
    {
      "chainId": 1,
      "address": "0x87DE305311D5788e8da38D19bb427645b09CB4e5",
      "name": "Verox",
      "symbol": "VRX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13669/large/IMG-20210115-000024.png?1610675319"
    },
    {
      "chainId": 1,
      "address": "0xFbEEa1C75E4c4465CB2FCCc9c6d6afe984558E20",
      "name": "DuckDaoDime",
      "symbol": "DDIM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12146/large/token_DDIM-01.png?1606982032"
    },
    {
      "chainId": 1,
      "address": "0x8a3d77e9d6968b780564936d15B09805827C21fa",
      "name": "Archethic",
      "symbol": "UCO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12330/large/Archethic_logo.png?1665916980"
    },
    {
      "chainId": 1,
      "address": "0x4f640F2529ee0cF119A2881485845FA8e61A782A",
      "name": "ORE Network",
      "symbol": "ORE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18917/large/ORE_FullColor.png?1633921977"
    },
    {
      "chainId": 1,
      "address": "0x06A01a4d579479Dd5D884EBf61A31727A3d8D442",
      "name": "Skey Network",
      "symbol": "SKEY",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13425/large/SKEY_Network_logo_black.png?1633421778"
    },
    {
      "chainId": 1,
      "address": "0x298d492e8c1d909D3F63Bc4A36C66c64ACB3d695",
      "name": "PolkaBridge",
      "symbol": "PBR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13744/large/symbol-whitebg200x200.png?1611377553"
    },
    {
      "chainId": 1,
      "address": "0xf66Cd2f8755a21d3c8683a10269F795c0532Dd58",
      "name": "coreDAO",
      "symbol": "COREDAO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23745/large/coredao.png?1645273627"
    },
    {
      "chainId": 1,
      "address": "0x3E9BC21C9b189C09dF3eF1B824798658d5011937",
      "name": "Linear",
      "symbol": "LINA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12509/large/1649227343-linalogo200px.png?1649229117"
    },
    {
      "chainId": 1,
      "address": "0x1b40183EFB4Dd766f11bDa7A7c3AD8982e998421",
      "name": "Vesper Finance",
      "symbol": "VSP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13527/large/vesper_logo.jpg?1609399927"
    },
    {
      "chainId": 1,
      "address": "0x73968b9a57c6E53d41345FD57a6E6ae27d6CDB2F",
      "name": "Stake DAO",
      "symbol": "SDT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13724/large/stakedao_logo.jpg?1611195011"
    },
    {
      "chainId": 1,
      "address": "0x126c121f99e1E211dF2e5f8De2d96Fa36647c855",
      "name": "DEGEN Index",
      "symbol": "DEGEN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14143/large/alpha_logo.png?1614651244"
    },
    {
      "chainId": 1,
      "address": "0xEd40834A13129509A89be39a9bE9C0E96A0DDd71",
      "name": "Warp Finance",
      "symbol": "WARP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13910/large/601ed0ac35c687c6e07d17c2_warp_token.png?1612834360"
    },
    {
      "chainId": 1,
      "address": "0xA888D9616C2222788fa19f05F77221A290eEf704",
      "name": "Daruma",
      "symbol": "DARUMA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/27357/large/CGlogo.png?1663661942"
    },
    {
      "chainId": 1,
      "address": "0xaac41EC512808d64625576EDdd580e7Ea40ef8B2",
      "name": "Gameswap",
      "symbol": "GSWAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13026/large/gameswap.jpg?1604456704"
    },
    {
      "chainId": 1,
      "address": "0x39207D2E2fEEF178FBdA8083914554C59D9f8c00",
      "name": "MultiPlanetary Inus",
      "symbol": "INUS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22648/large/logo.png?1644479310"
    },
    {
      "chainId": 1,
      "address": "0x7BEF710a5759d197EC0Bf621c3Df802C2D60D848",
      "name": "SHOPX",
      "symbol": "SHOPX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14600/large/shopx_icon_.png?1646381164"
    },
    {
      "chainId": 1,
      "address": "0xd79F43113B22D1eA9F29cfcC7BB287489F8EE5e0",
      "name": "Protocol Zero",
      "symbol": "ZRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28557/large/photo_2022-08-16_02-50-00.jpg?1671705583"
    },
    {
      "chainId": 1,
      "address": "0x3758e00b100876C854636eF8Db61988931BB8025",
      "name": "Uniqly",
      "symbol": "UNIQ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14808/large/Hnet-com-image.png?1618538742"
    },
    {
      "chainId": 1,
      "address": "0x02D3A27Ac3f55d5D91Fb0f52759842696a864217",
      "name": "Charged Particles",
      "symbol": "IONX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15836/large/DrKjSQMH_400x400.png?1622080222"
    },
    {
      "chainId": 1,
      "address": "0x24E89bDf2f65326b94E36978A7EDeAc63623DAFA",
      "name": "Tiger King Coin",
      "symbol": "TKING",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15605/large/tigerking.png?1649149229"
    },
    {
      "chainId": 1,
      "address": "0xDaF88906aC1DE12bA2b1D2f7bfC94E9638Ac40c4",
      "name": "EpiK Protocol",
      "symbol": "EPK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15188/large/epk.PNG?1620078400"
    },
    {
      "chainId": 1,
      "address": "0x83E9F223e1edb3486F876EE888d76bFba26c475A",
      "name": "BlockchainSpace",
      "symbol": "GUILD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21271/large/BednjMw.png?1638857799"
    },
    {
      "chainId": 1,
      "address": "0x07150e919B4De5fD6a63DE1F9384828396f25fDC",
      "name": "Base Protocol",
      "symbol": "BASE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/13265/large/200x200green.png?1607650121"
    },
    {
      "chainId": 1,
      "address": "0xfAd45E47083e4607302aa43c65fB3106F1cd7607",
      "name": "Hoge Finance",
      "symbol": "HOGE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/14360/large/hoge.jpg?1615641604"
    },
    {
      "chainId": 1,
      "address": "0xa2881F7F441267042f9778fFA0d4F834693426be",
      "name": "The HUSL",
      "symbol": "HUSL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18619/large/W8ZIHKU.png?1650437671"
    },
    {
      "chainId": 1,
      "address": "0x3155BA85D5F96b2d030a4966AF206230e46849cb",
      "name": "THORChain  ERC20 ",
      "symbol": "RUNE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13677/large/IMG_20210123_132049_458.png?1612179252"
    },
    {
      "chainId": 1,
      "address": "0x6f8b23296394d20eC048FbDec8eBc0CA90f5c8f1",
      "name": "TUF Token",
      "symbol": "TUF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28410/large/2022-12-06_10.10.16.jpg?1670385344"
    },
    {
      "chainId": 1,
      "address": "0x429881672B9AE42b8EbA0E26cD9C73711b891Ca5",
      "name": "Pickle Finance",
      "symbol": "PICKLE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12435/large/0M4W6Yr6_400x400.jpg?1643006080"
    },
    {
      "chainId": 1,
      "address": "0xCbfef8fdd706cde6F208460f2Bf39Aa9c785F05D",
      "name": "Kine Protocol",
      "symbol": "KINE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14339/large/kine.jpg?1615474456"
    },
    {
      "chainId": 1,
      "address": "0x29127fE04ffa4c32AcAC0fFe17280ABD74eAC313",
      "name": "SIFU",
      "symbol": "SIFU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24692/large/token_%283%29.png?1648620836"
    },
    {
      "chainId": 1,
      "address": "0x0fF6ffcFDa92c53F615a4A75D982f399C989366b",
      "name": "UniLayer",
      "symbol": "LAYER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12164/large/logo-layer.jpg?1674822983"
    },
    {
      "chainId": 1,
      "address": "0xb9EF770B6A5e12E45983C5D80545258aA38F3B78",
      "name": "Zus",
      "symbol": "ZCN",
      "decimals": 10,
      "logoURI": "https://assets.coingecko.com/coins/images/4934/large/200x200_transparent.png?1669366739"
    },
    {
      "chainId": 1,
      "address": "0xc690F7C7FcfFA6a82b79faB7508c466FEfdfc8c5",
      "name": "Lympo",
      "symbol": "LYM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2620/large/lympo_token.png?1547036775"
    },
    {
      "chainId": 1,
      "name": "void.cash",
      "address": "0x37cd4E8875E3EDafFDFe9Be63958f07eFfBD0Bfd",
      "decimals": 18,
      "symbol": "VCASH",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/21530.png"
    },
    {
      "chainId": 1,
      "address": "0x15Ee120fD69BEc86C1d38502299af7366a41D1a6",
      "name": "BitANT",
      "symbol": "BITANT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19055/large/BitANT.png?1634264861"
    },
    {
      "chainId": 1,
      "address": "0xf8E9F10c22840b613cdA05A0c5Fdb59A4d6cd7eF",
      "name": "Dogs Of Elon",
      "symbol": "DOE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19942/large/doe.png?1636336026"
    },
    {
      "chainId": 1,
      "address": "0x6c5bA91642F10282b576d91922Ae6448C9d52f4E",
      "name": "Phala",
      "symbol": "PHA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12451/large/phala.png?1600061318"
    },
    {
      "chainId": 1,
      "address": "0x645C52CF6c5C58AA4064494f5b5FFE9C7EC0d7D4",
      "name": "Huckleberry Inu",
      "symbol": "HKBY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28495/large/IMG_20221214_073842_547_%283%29_%281%29.png?1671108300"
    },
    {
      "chainId": 1,
      "address": "0xb753428af26E81097e7fD17f40c88aaA3E04902c",
      "name": "saffron finance",
      "symbol": "SFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13117/large/sfi_red_250px.png?1606020144"
    },
    {
      "chainId": 1,
      "address": "0xb1f871Ae9462F1b2C6826E88A7827e76f86751d4",
      "name": "GNY",
      "symbol": "GNY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5300/large/GNY_LOGO_NEW_TRANS.png?1675592825"
    },
    {
      "chainId": 1,
      "address": "0x6Fbc20483b53CEa47839Bb8e171Abd6D67C3c696",
      "name": "EvolveAI",
      "symbol": "EVOAI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28964/large/EvolveAI.png?1675744023"
    },
    {
      "chainId": 1,
      "address": "0xF4b5470523cCD314C6B9dA041076e7D79E0Df267",
      "name": "blockbank",
      "symbol": "BBANK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15081/large/blockbank.jpg.png?1675767121"
    },
    {
      "chainId": 1,
      "address": "0xcbE771323587EA16dACB6016e269D7F08A7ACC4E",
      "name": "Spores Network",
      "symbol": "SPO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17431/large/SPO_token.png?1627619762"
    },
    {
      "chainId": 1,
      "address": "0x86ed939B500E121C0C5f493F399084Db596dAd20",
      "name": "SpaceChain  ERC 20 ",
      "symbol": "SPC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/6659/large/Spacechain.jpg?1547042861"
    },
    {
      "chainId": 1,
      "address": "0x9F52c8ecbEe10e00D9faaAc5Ee9Ba0fF6550F511",
      "name": "Sipher",
      "symbol": "SIPHER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21070/large/SipherToken.png?1638312272"
    },
    {
      "chainId": 1,
      "address": "0x431ad2ff6a9C365805eBaD47Ee021148d6f7DBe0",
      "name": "dForce",
      "symbol": "DF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/9709/large/xlGxxIjI_400x400.jpg?1571006794"
    },
    {
      "chainId": 1,
      "address": "0xf3AE5d769e153Ef72b4e3591aC004E89F48107a1",
      "name": "Deeper Network",
      "symbol": "DPR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14748/large/deeper.png?1618094356"
    },
    {
      "chainId": 1,
      "address": "0xB8c77482e45F1F44dE1745F52C74426C631bDD52",
      "name": "BNB",
      "symbol": "BNB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/825/large/bnb-icon2_2x.png?1644979850"
    },
    {
      "chainId": 1,
      "address": "0x903bEF1736CDdf2A537176cf3C64579C3867A881",
      "name": "Legacy ICHI",
      "symbol": "ICHI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26004/large/legacy.png?1655278844"
    },
    {
      "chainId": 1,
      "address": "0x340D2bdE5Eb28c1eed91B2f790723E3B160613B7",
      "name": "BLOCKv",
      "symbol": "VEE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1266/large/blockv.png?1547351380"
    },
    {
      "chainId": 1,
      "address": "0x444444444444C1a66F394025Ac839A535246FCc8",
      "name": "Genius",
      "symbol": "GENI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28621/large/GENI200x200.png?1672707726"
    },
    {
      "chainId": 1,
      "address": "0x9393fdc77090F31c7db989390D43F454B1A6E7F3",
      "name": "Dark Energy Crystals",
      "symbol": "DEC",
      "decimals": 3,
      "logoURI": "https://assets.coingecko.com/coins/images/12923/large/DEC_token.png?1603683753"
    },
    {
      "chainId": 1,
      "address": "0x90DE74265a416e1393A450752175AED98fe11517",
      "name": "Unlock Protocol",
      "symbol": "UDT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14545/large/unlock.jpg?1616948136"
    },
    {
      "chainId": 1,
      "address": "0xC4f6E93AEDdc11dc22268488465bAbcAF09399aC",
      "name": "hi Dollar",
      "symbol": "HI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17618/large/unnamed_%281%29.png?1628665739"
    },
    {
      "chainId": 1,
      "address": "0x6B4c7A5e3f0B99FCD83e9c089BDDD6c7FCe5c611",
      "name": "Million",
      "symbol": "MM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16825/large/logo200x200.png?1625834139"
    },
    {
      "chainId": 1,
      "address": "0x217ddEad61a42369A266F1Fb754EB5d3EBadc88a",
      "name": "Don key",
      "symbol": "DON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15482/large/donkey_logo.jpg?1621012824"
    },
    {
      "chainId": 1,
      "address": "0x73d7c860998CA3c01Ce8c808F5577d94d545d1b4",
      "name": "IX Swap",
      "symbol": "IXS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18069/large/ixswap.PNG?1630375152"
    },
    {
      "chainId": 1,
      "address": "0x0488401c3F535193Fa8Df029d9fFe615A06E74E6",
      "name": "SparkPoint",
      "symbol": "SRK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/8371/large/SRK.png?1614675526"
    },
    {
      "chainId": 1,
      "address": "0xC4C2614E694cF534D407Ee49F8E44D125E4681c4",
      "name": "Chain Games",
      "symbol": "CHAIN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12257/large/chain-pfp-logo.png?1671678582"
    },
    {
      "chainId": 1,
      "address": "0x3FA729B4548beCBAd4EaB6EF18413470e6D5324C",
      "name": "Mover",
      "symbol": "MOVE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13719/large/o0KIvs7T_400x400.jpg?1617672818"
    },
    {
      "chainId": 1,
      "address": "0xA01199c61841Fce3b3daFB83FeFC1899715c8756",
      "name": "Cirus",
      "symbol": "CIRUS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17798/large/8p0Bvi90_400x400.jpg?1629281912"
    },
    {
      "chainId": 1,
      "address": "0x2d94AA3e47d9D5024503Ca8491fcE9A2fB4DA198",
      "name": "Bankless DAO",
      "symbol": "BANK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15227/large/j4WEJrwU.png?1622615796"
    },
    {
      "chainId": 1,
      "address": "0x1614F18Fc94f47967A3Fbe5FfcD46d4e7Da3D787",
      "name": "PAID Network",
      "symbol": "PAID",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13761/large/512.png?1648630881"
    },
    {
      "chainId": 1,
      "address": "0x831091dA075665168E01898c6DAC004A867f1e1B",
      "name": "Gains Farm",
      "symbol": "GFARM2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13703/large/gfarm_v2.png?1611035398"
    },
    {
      "chainId": 1,
      "address": "0x94e496474F1725f1c1824cB5BDb92d7691A4F03a",
      "name": "Banana",
      "symbol": "BANANA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17521/large/banana-token-cg.png?1646285527"
    },
    {
      "chainId": 1,
      "address": "0xC28e931814725BbEB9e670676FaBBCb694Fe7DF2",
      "name": "Quadrant Protocol",
      "symbol": "EQUAD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4462/large/equad.png?1547039783"
    },
    {
      "chainId": 1,
      "address": "0x33D203FA03bb30b133De0fE2d6533C268bA286B6",
      "name": "MandoX",
      "symbol": "MANDOX",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/24968/large/NmqN8g7.png?1649917431"
    },
    {
      "chainId": 1,
      "address": "0x9469D013805bFfB7D3DEBe5E7839237e535ec483",
      "name": "Darwinia Network",
      "symbol": "RING",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/9443/large/RING.png?1615271827"
    },
    {
      "chainId": 1,
      "address": "0x234D51eE02be808A0160b19b689660Fb7BFA871b",
      "name": "CoinScan",
      "symbol": "SCAN",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/24254/large/scan.png?1647155535"
    },
    {
      "chainId": 1,
      "address": "0xB7Df0f42FAe30acf30C9A5BA147D6B792b5eB9d9",
      "name": "Ai Smart Chain",
      "symbol": "AISC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28916/large/logo.jpg?1675387522"
    },
    {
      "chainId": 1,
      "address": "0xDE5ed76E7c05eC5e4572CfC88d1ACEA165109E44",
      "name": "DEUS Finance",
      "symbol": "DEUS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18778/large/Black_Background_200x200.png?1681374184"
    },
    {
      "chainId": 1,
      "address": "0xc719d010B63E5bbF2C0551872CD5316ED26AcD83",
      "name": "Etherisc DIP",
      "symbol": "DIP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4586/large/dip.png?1547039863"
    },
    {
      "chainId": 1,
      "address": "0xD7EFB00d12C2c13131FD319336Fdf952525dA2af",
      "name": "Proton",
      "symbol": "XPR",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/10941/large/Proton-Icon.png?1588283737"
    },
    {
      "chainId": 1,
      "address": "0xe88f8313e61A97cEc1871EE37fBbe2a8bf3ed1E4",
      "name": "Sora Validator",
      "symbol": "VAL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13299/large/val-gold-256.png?1607242927"
    },
    {
      "chainId": 1,
      "address": "0x16980b3B4a3f9D89E33311B5aa8f80303E5ca4F8",
      "name": "KIRA Network",
      "symbol": "KEX",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/13232/large/avatar.png?1622601779"
    },
    {
      "chainId": 1,
      "address": "0x34950Ff2b487d9E5282c5aB342d08A2f712eb79F",
      "name": "Efforce",
      "symbol": "WOZX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13310/large/rZ6Oe3dm_400x400.jpg?1607331889"
    },
    {
      "chainId": 1,
      "address": "0x35bD01FC9d6D5D81CA9E055Db88Dc49aa2c699A8",
      "name": "Friends With Benefits Pro",
      "symbol": "FWB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14391/large/xRGEXmQN_400x400.png?1615868085"
    },
    {
      "chainId": 1,
      "address": "0x1F8A626883d7724DBd59eF51CBD4BF1Cf2016D13",
      "name": "Jigstack",
      "symbol": "STAK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14978/large/jigstack.PNG?1619216498"
    },
    {
      "chainId": 1,
      "address": "0xBd2949F67DcdC549c6Ebe98696449Fa79D988A9F",
      "name": "Meter Governance mapped by Meter io",
      "symbol": "EMTRG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12175/large/Dark-blue-icon-transparent-vector-white-icon200x200.png?1597819237"
    },
    {
      "chainId": 1,
      "address": "0xCAEaf8381D4B20b43AFA42061D6f80319A8881F6",
      "name": "R34P",
      "symbol": "R34P",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13393/large/r34p_logo.png?1608100330"
    },
    {
      "chainId": 1,
      "address": "0x544c42fBB96B39B21DF61cf322b5EDC285EE7429",
      "name": "InsurAce",
      "symbol": "INSUR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14226/large/insur.png?1615124622"
    },
    {
      "chainId": 1,
      "address": "0x2ba592F78dB6436527729929AAf6c908497cB200",
      "name": "Cream",
      "symbol": "CREAM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11976/large/Cream.png?1596593418"
    },
    {
      "chainId": 1,
      "address": "0x7aE1D57b58fA6411F32948314BadD83583eE0e8C",
      "name": "Dope Wars Paper",
      "symbol": "PAPER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18166/large/EQHGcBO__400x400.jpeg?1663726283"
    },
    {
      "chainId": 1,
      "address": "0xEABB8996eA1662cAd2f7fB715127852cd3262Ae9",
      "name": "Connect Financial",
      "symbol": "CNFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13592/large/cf-logo-iconic-black.png?1644479524"
    },
    {
      "chainId": 1,
      "address": "0xde4EE8057785A7e8e800Db58F9784845A5C2Cbd6",
      "name": "DeXe",
      "symbol": "DEXE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12713/large/logo_%2814%29.png?1601952779"
    },
    {
      "chainId": 1,
      "address": "0xC1D9B5A0776d7C8B98b8A838e5a0DD1Bc5Fdd53C",
      "name": "GridZone io",
      "symbol": "ZONE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18098/large/Gridzone_logo_V2.png?1630468285"
    },
    {
      "chainId": 1,
      "address": "0x7240aC91f01233BaAf8b064248E80feaA5912BA3",
      "name": "OctoFi",
      "symbol": "OCTO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12594/large/octofi-256x256-radius-22percent.png?1610679969"
    },
    {
      "chainId": 1,
      "address": "0x0CDF9acd87E940837ff21BB40c9fd55F68bba059",
      "name": "Public Mint",
      "symbol": "MINT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14106/large/Public_Mint_Icon_200x200.png?1614333027"
    },
    {
      "chainId": 1,
      "address": "0x050D94685c6B0477E1Fc555888AF6e2bB8dFBda5",
      "name": "Inu ",
      "symbol": "INU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26259/large/inulogo_200x200.png?1656941363"
    },
    {
      "chainId": 1,
      "address": "0x9355372396e3F6daF13359B7b607a3374cc638e0",
      "name": "WHALE",
      "symbol": "WHALE",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/11797/large/WHALE.png?1595004706"
    },
    {
      "chainId": 1,
      "address": "0x9c5476Af06590A9277C7706fe70c0a42A480F8A0",
      "name": "Chooky Inu",
      "symbol": "CHOO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28525/large/New-Inu.jpeg?1671350928"
    },
    {
      "chainId": 1,
      "address": "0x31c2415c946928e9FD1Af83cdFA38d3eDBD4326f",
      "name": "MADworld",
      "symbol": "UMAD",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/20939/large/UMAD_.png?1638238294"
    },
    {
      "chainId": 1,
      "address": "0xA36FDBBAE3c9d55a1d67EE5821d53B50B63A1aB9",
      "name": "Tempus",
      "symbol": "TEMP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20547/large/Tempus_CoinGecko_200x200.png?1657674634"
    },
    {
      "chainId": 1,
      "address": "0x0E192d382a36De7011F795Acc4391Cd302003606",
      "name": "Futureswap",
      "symbol": "FST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14520/large/futureswap_logo.png?1634122916"
    },
    {
      "chainId": 1,
      "address": "0x226f7b842E0F0120b7E194D05432b3fd14773a9D",
      "name": "UNION Protocol Governance",
      "symbol": "UNN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13408/large/unn_finance.png?1608262290"
    },
    {
      "chainId": 1,
      "address": "0xe0a189C975e4928222978A74517442239a0b86ff",
      "name": "Keys",
      "symbol": "KEYS",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/20604/large/200x200_%2843%29.png?1637289427"
    },
    {
      "chainId": 1,
      "address": "0x4Cf89ca06ad997bC732Dc876ed2A7F26a9E7f361",
      "name": "Mysterium",
      "symbol": "MYST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/757/large/mysterium.png?1547034503"
    },
    {
      "chainId": 1,
      "address": "0x14b40AD2EBA6c1B31db2bA817b07578AFB414415",
      "name": "colR Coin",
      "symbol": "COLR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26701/large/colverse.jpeg?1659662193"
    },
    {
      "chainId": 1,
      "address": "0x6a6c2adA3Ce053561C2FbC3eE211F23d9b8C520a",
      "name": "TON Community",
      "symbol": "TON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12334/large/ton.jpg?1599128436"
    },
    {
      "chainId": 1,
      "address": "0x916c5DE09cF63f6602d1e1793FB41F6437814A62",
      "name": "JACY",
      "symbol": "JACY",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/19740/large/tBwbvjZK_400x400.jpg?1641803022"
    },
    {
      "chainId": 1,
      "address": "0xE4CFE9eAa8Cdb0942A80B7bC68fD8Ab0F6D44903",
      "name": "Xend Finance",
      "symbol": "XEND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14496/large/WeChat_Image_20210325163206.png?1616661216"
    },
    {
      "chainId": 1,
      "address": "0x2B89bF8ba858cd2FCee1faDa378D5cd6936968Be",
      "name": "Secret  ERC20 ",
      "symbol": "WSCRT",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/13767/large/Secret_S_Black_Coingecko.png?1611667298"
    },
    {
      "chainId": 1,
      "address": "0x7cA4408137eb639570F8E647d9bD7B7E8717514A",
      "name": "Alpaca City",
      "symbol": "ALPA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13070/large/alpaca_logo.png?1604895862"
    },
    {
      "chainId": 1,
      "address": "0x4156D3342D5c385a87D264F90653733592000581",
      "name": "SALT",
      "symbol": "SALT",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/962/large/salt.png?1548608746"
    },
    {
      "chainId": 1,
      "address": "0xe0B9a2C3E9f40CF74B2C7F591B2b0CCa055c3112",
      "name": "Genesis Shards",
      "symbol": "GS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14784/large/gs.png?1618408218"
    },
    {
      "chainId": 1,
      "address": "0xFEb6d5238Ed8F1d59DCaB2db381AA948e625966D",
      "name": "Doge TV",
      "symbol": "DGTV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28050/large/532a5b9e-8294-4be1-be18-f04a2cf5f0a9.png?1667280533"
    },
    {
      "chainId": 1,
      "address": "0x56A86d648c435DC707c8405B78e2Ae8eB4E60Ba4",
      "name": "StackOS",
      "symbol": "STACK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14989/large/stackos.jpg?1661420187"
    },
    {
      "chainId": 1,
      "address": "0xEE06A81a695750E71a662B51066F2c74CF4478a0",
      "name": "Decentral Games  Old ",
      "symbol": "DG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13267/large/%28Old%29_DG.png?1639209538"
    },
    {
      "chainId": 1,
      "address": "0xA91ac63D040dEB1b7A5E4d4134aD23eb0ba07e14",
      "name": "Bella Protocol",
      "symbol": "BEL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12478/large/Bella.png?1602230054"
    },
    {
      "chainId": 1,
      "address": "0x88A9A52F944315D5B4e917b9689e65445C401E83",
      "name": "FEAR",
      "symbol": "FEAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15825/large/fear-logo-400-400.png?1625552865"
    },
    {
      "chainId": 1,
      "address": "0xF970b8E36e23F7fC3FD752EeA86f8Be8D83375A6",
      "name": "Ripio Credit Network",
      "symbol": "RCN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1057/large/ripio-credit-network.png?1548608361"
    },
    {
      "chainId": 1,
      "address": "0xE7f58A92476056627f9FdB92286778aBd83b285F",
      "name": "DecentraWeb",
      "symbol": "DWEB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18971/large/dweb-logo-transparent.png?1634082358"
    },
    {
      "chainId": 1,
      "address": "0x8888801aF4d980682e47f1A9036e589479e835C5",
      "name": "88mph",
      "symbol": "MPH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13137/large/yfU-_Tcj_400x400.png?1605581509"
    },
    {
      "chainId": 1,
      "address": "0x505a84a03e382331A1Be487b632Cf357748b65d6",
      "name": "SHIBGF",
      "symbol": "SHIBGF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19699/large/shibgf_logo.png?1637293051"
    },
    {
      "chainId": 1,
      "address": "0xBAac2B4491727D78D2b78815144570b9f2Fe8899",
      "name": "The Doge NFT",
      "symbol": "DOG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18111/large/Doge.png?1630696110"
    },
    {
      "chainId": 1,
      "address": "0x5cAf454Ba92e6F2c929DF14667Ee360eD9fD5b26",
      "name": "Dev Protocol",
      "symbol": "DEV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11560/large/Dev_Protocol__CoinGecko_Logo___Jan.18.2021_.png?1611021474"
    },
    {
      "chainId": 1,
      "address": "0x841FB148863454A3b3570f515414759BE9091465",
      "name": "Shih Tzu",
      "symbol": "SHIH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15309/large/shit.PNG?1620374274"
    },
    {
      "chainId": 1,
      "address": "0x74bE64B45D394FA57816c1950E94dBB8d7A7B306",
      "name": "Givewell Inu",
      "symbol": "GINU",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28323/large/5FADC518-3EE8-4914-A627-602B9C3FAFB4.jpeg?1669445878"
    },
    {
      "chainId": 1,
      "address": "0x16756EC1DEb89A2106C35E0B586a799D0A61837D",
      "name": "Chedda",
      "symbol": "CHEDDA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22654/large/cMckil70_400x400.jpg?1642400459"
    },
    {
      "chainId": 1,
      "address": "0xa9f9aCB92E4E2f16410511D56839A5Bd1d630a60",
      "name": "BLOCK E",
      "symbol": "BLOCK-E",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/26905/large/photo_2022-09-07_10.17.08.jpeg?1664065816"
    },
    {
      "chainId": 1,
      "address": "0xd9b312D77Bc7BEd9B9CecB56636300bED4Fe5Ce9",
      "name": "Gains",
      "symbol": "GAINS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14681/large/200x200.png?1677061798"
    },
    {
      "chainId": 1,
      "address": "0x56015BBE3C01fE05bc30A8a9a9Fd9A88917e7dB3",
      "name": "Mooncat CAT",
      "symbol": "CAT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12177/large/happy2-2.jpg?1619593488"
    },
    {
      "chainId": 1,
      "address": "0x4bD70556ae3F8a6eC6C4080A0C327B24325438f3",
      "name": "Hxro",
      "symbol": "HXRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7805/large/Hxro_Profile_Transparent.png?1622443308"
    },
    {
      "chainId": 1,
      "address": "0x7DbbCaE15d4DB168e01673400D7844870cc1e36f",
      "name": "WOLFY",
      "symbol": "WOLFY",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15742/large/Wofly.png?1621761884"
    },
    {
      "chainId": 1,
      "address": "0xDDD6A0ECc3c6F6C102E5eA3d8Af7B801d1a77aC8",
      "name": "UniX",
      "symbol": "UNIX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20674/large/unix.png?1663499268"
    },
    {
      "chainId": 1,
      "address": "0xC57d533c50bC22247d49a368880fb49a1caA39F7",
      "name": "PowerTrade Fuel",
      "symbol": "PTF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12590/large/powertrade_logo.jpg?1600944549"
    },
    {
      "chainId": 1,
      "address": "0x2e1E15C44Ffe4Df6a0cb7371CD00d5028e571d14",
      "name": "Mettalex",
      "symbol": "MTLX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12730/large/nrEqFTEW_400x400.jpg?1602063980"
    },
    {
      "chainId": 1,
      "address": "0xd98F75b1A3261dab9eEd4956c93F33749027a964",
      "name": "Share",
      "symbol": "SHR",
      "decimals": 2,
      "logoURI": "https://assets.coingecko.com/coins/images/3609/large/74586729_2443914875881351_2785018663453851648_n.png?1574898410"
    },
    {
      "chainId": 1,
      "address": "0x7865af71cf0b288b4E7F654f4F7851EB46a2B7F8",
      "name": "Sentivate",
      "symbol": "SNTVT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7383/large/2x9veCp.png?1598409975"
    },
    {
      "chainId": 1,
      "address": "0xbf2179859fc6D5BEE9Bf9158632Dc51678a4100e",
      "name": "aelf",
      "symbol": "ELF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1371/large/aelf-logo.png?1547035397"
    },
    {
      "chainId": 1,
      "address": "0x3449FC1Cd036255BA1EB19d65fF4BA2b8903A69a",
      "name": "Basis Cash",
      "symbol": "BAC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13246/large/BAC.png?1613231642"
    },
    {
      "chainId": 1,
      "address": "0x850aAB69f0e0171A9a49dB8BE3E71351c8247Df4",
      "name": "Konomi Network",
      "symbol": "KONO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14406/large/konomi.jpg?1615907763"
    },
    {
      "chainId": 1,
      "address": "0x29CbD0510EEc0327992CD6006e63F9Fa8E7f33B7",
      "name": "Tidal Finance",
      "symbol": "TIDAL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14460/large/Tidal-mono.png?1616233894"
    },
    {
      "chainId": 1,
      "address": "0xBd3de9a069648c84d27d74d701C9fa3253098B15",
      "name": "EQIFi",
      "symbol": "EQX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17490/large/EQIFI_Logo_Color.png?1627968404"
    },
    {
      "chainId": 1,
      "address": "0x97b65710D03E12775189F0D113202cc1443b0aa2",
      "name": "AstroElon",
      "symbol": "ELONONE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/16082/large/AstroElon.png?1622791921"
    },
    {
      "chainId": 1,
      "address": "0xE61F6e39711cEc14f8D6c637c2f4568bAA9FF7Ee",
      "name": "Hey",
      "symbol": "HEY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/28092/large/LogoCG.png?1671178992"
    },
    {
      "chainId": 1,
      "address": "0x6e9730EcFfBed43fD876A264C982e254ef05a0DE",
      "name": "Nord Finance",
      "symbol": "NORD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13630/large/nord.jpg?1610465136"
    },
    {
      "chainId": 1,
      "address": "0x875773784Af8135eA0ef43b5a374AaD105c5D39e",
      "name": "IDLE",
      "symbol": "IDLE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13286/large/image.png?1655284075"
    },
    {
      "chainId": 1,
      "address": "0x3Ec8798B81485A254928B70CDA1cf0A2BB0B74D7",
      "name": "Gro DAO",
      "symbol": "GRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18673/large/613f171979749061aaa1edf9_Icon-GRO-256x256-Square.png?1632876204"
    },
    {
      "chainId": 1,
      "address": "0xCd1fAFf6e578Fa5cAC469d2418C95671bA1a62Fe",
      "name": "Torum",
      "symbol": "XTM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18393/large/torum-transparent-cmc.png?1631760805"
    },
    {
      "chainId": 1,
      "address": "0xB1191F691A355b43542Bea9B8847bc73e7Abb137",
      "name": "KIRO",
      "symbol": "KIRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12688/large/logo_kirobo-04.png?1668683315"
    },
    {
      "chainId": 1,
      "address": "0xF5B5eFc906513b4344EbAbCF47A04901f99F09f3",
      "name": "UBIX Network",
      "symbol": "UBX",
      "decimals": 0,
      "logoURI": "https://assets.coingecko.com/coins/images/13000/large/1.png?1674822617"
    },
    {
      "chainId": 1,
      "address": "0x0Cf0Ee63788A0849fE5297F3407f701E122cC023",
      "name": "Streamr XDATA",
      "symbol": "XDATA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1115/large/streamr.png?1547035101"
    },
    {
      "chainId": 1,
      "address": "0x19062190B1925b5b6689D7073fDfC8c2976EF8Cb",
      "name": "Swarm",
      "symbol": "BZZ",
      "decimals": 16,
      "logoURI": "https://assets.coingecko.com/coins/images/16509/large/Circle_Orange_onWhite.png?1675184920"
    },
    {
      "chainId": 1,
      "address": "0x7C5A0CE9267ED19B22F8cae653F198e3E8daf098",
      "name": "Santiment Network",
      "symbol": "SAN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/797/large/santiment-network-token.png?1547034571"
    },
    {
      "chainId": 1,
      "address": "0x51FE2E572e97BFEB1D719809d743Ec2675924EDc",
      "name": "VLaunch",
      "symbol": "VPAD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20838/large/vlaunch_22.png?1637738535"
    },
    {
      "chainId": 1,
      "address": "0x6710c63432A2De02954fc0f851db07146a6c0312",
      "name": "Smart MFG",
      "symbol": "MFG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1842/large/Smart_MFG_Cropped_Logo.png?1621422155"
    },
    {
      "chainId": 1,
      "address": "0x1d2d542e6D9d85A712deB4D1a7D96a16CE00B8cE",
      "name": "Proof Of Apes",
      "symbol": "POA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27896/large/POA.png?1666318268"
    },
    {
      "chainId": 1,
      "address": "0x446C9033E7516D820cc9a2ce2d0B7328b579406F",
      "name": "SOLVE",
      "symbol": "SOLVE",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/1768/large/Solve.Token_logo_200_200_wiyhout_BG.png?1575869846"
    },
    {
      "chainId": 1,
      "address": "0x725C263e32c72dDC3A19bEa12C5a0479a81eE688",
      "name": "Bridge Mutual",
      "symbol": "BMI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13808/large/bmi_logo.png?1612009598"
    },
    {
      "chainId": 1,
      "address": "0x9F284E1337A815fe77D2Ff4aE46544645B20c5ff",
      "name": "Darwinia Commitment",
      "symbol": "KTON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11895/large/KTON.png?1615271813"
    },
    {
      "chainId": 1,
      "address": "0xb31eF9e52d94D4120eb44Fe1ddfDe5B4654A6515",
      "name": "DOSE",
      "symbol": "DOSE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18847/large/dose.PNG?1633590548"
    },
    {
      "chainId": 1,
      "address": "0x4Ddc2D193948926D02f9B1fE9e1daa0718270ED5",
      "name": "cETH",
      "symbol": "CETH",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/10643/large/ceth2.JPG?1581389598"
    },
    {
      "chainId": 1,
      "address": "0xd031edafac6a6ae5425e77F936022E506444C242",
      "name": "HERUKA TSANGNYON",
      "symbol": "TSANGNYON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27611/large/81b3e527-f8a9-47f7-8d4d-10f754f501c2.png?1664853112"
    },
    {
      "chainId": 1,
      "address": "0xdbDD6F355A37b94e6C7D32fef548e98A280B8Df5",
      "name": "UniWhales",
      "symbol": "UWL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13166/large/uniwhale.png?1611967645"
    },
    {
      "chainId": 1,
      "address": "0x9A0aBA393aac4dFbFf4333B06c407458002C6183",
      "name": "ACoconut",
      "symbol": "AC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12779/large/ac_logo.png?1602500084"
    },
    {
      "chainId": 1,
      "address": "0xA67E9F021B9d208F7e3365B2A155E3C55B27de71",
      "name": "KleeKai",
      "symbol": "KLEE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15548/large/Klee-Kai-Logo.png?1628258448"
    },
    {
      "chainId": 1,
      "address": "0xB56A1f3310578f23120182Fb2e58c087EFE6e147",
      "name": "All Coins Yield Capital",
      "symbol": "ACYC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21109/large/acyc.png?1639990309"
    },
    {
      "chainId": 1,
      "address": "0xAa4e3edb11AFa93c41db59842b29de64b72E355B",
      "name": "Marginswap",
      "symbol": "MFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13899/large/marginswap_logo.png?1612756590"
    },
    {
      "chainId": 1,
      "address": "0x33D0568941C0C64ff7e0FB4fbA0B11BD37deEd9f",
      "name": "RAMP  OLD ",
      "symbol": "RAMP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12837/large/RAMP-Logo-v2-1000pxsq.png?1617952606"
    },
    {
      "chainId": 1,
      "address": "0x6069c9223e8a5DA1ec49ac5525d4BB757Af72Cd8",
      "name": "MUSK Gold",
      "symbol": "MUSK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21696/large/musk-icon-200x200.png?1649329802"
    },
    {
      "chainId": 1,
      "address": "0x62A8C2818BD7034DC24CD22368C3E53E8eB47c18",
      "name": "InnitForTheTECH",
      "symbol": "INNIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26724/large/INNITlogo.jpg?1659876626"
    },
    {
      "chainId": 1,
      "address": "0xdacD69347dE42baBfAEcD09dC88958378780FB62",
      "name": "Atari",
      "symbol": "ATRI",
      "decimals": 0,
      "logoURI": "https://assets.coingecko.com/coins/images/12992/large/AtariLogoPS_200x200_%281%29.png?1643189483"
    },
    {
      "chainId": 1,
      "address": "0x1796ae0b0fa4862485106a0de9b654eFE301D0b2",
      "name": "Polychain Monsters",
      "symbol": "PMON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14604/large/polkamon.png?1617238350"
    },
    {
      "chainId": 1,
      "address": "0x1cBb83EbcD552D5EBf8131eF8c9CD9d9BAB342bC",
      "name": "Non Fungible Yearn",
      "symbol": "NFY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12766/large/NFY_logo.png?1602686886"
    },
    {
      "chainId": 1,
      "address": "0xB14eBF566511B9e6002bB286016AB2497B9b9c9D",
      "name": "Hypersign Identity",
      "symbol": "HID",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16158/large/hypersign_ONLYlogo_Yellow.png?1623140987"
    },
    {
      "chainId": 1,
      "address": "0x77f9CF0bd8C500CfFdF420e72343893aeCC2EC0b",
      "name": "Laika",
      "symbol": "LAIKA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26717/large/Laikacmcfinal.png?1659857807"
    },
    {
      "chainId": 1,
      "address": "0xdf1A2f85F3af80E85d14DdAAB2933C8caA09294a",
      "name": "Dwagon",
      "symbol": "DWAGON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27480/large/logoblk.png?1672476960"
    },
    {
      "chainId": 1,
      "address": "0x6595b8fD9C920C81500dCa94e53Cdc712513Fb1f",
      "name": "Olyverse",
      "symbol": "OLY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13983/large/oly-logo.png?1613461530"
    },
    {
      "chainId": 1,
      "address": "0xCdeee767beD58c5325f68500115d4B722b3724EE",
      "name": "Carbon",
      "symbol": "CRBN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13262/large/carbon.png?1662693418"
    },
    {
      "chainId": 1,
      "address": "0x054D64b73d3D8A21Af3D764eFd76bCaA774f3Bb2",
      "name": "Plasma Finance",
      "symbol": "PPAY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13340/large/Hi9sEGAD.png?1607586849"
    },
    {
      "chainId": 1,
      "address": "0x2620638EDA99F9e7E902Ea24a285456EE9438861",
      "name": "Crust Shadow",
      "symbol": "CSM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16037/large/2_mnCYZfHmLg2bFrjM3vKtPw.png?1622680217"
    },
    {
      "chainId": 1,
      "address": "0xcB8d1260F9c92A3A545d409466280fFdD7AF7042",
      "name": "NFT Protocol",
      "symbol": "NFT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12174/large/nftprotocol_32.png?1597818115"
    },
    {
      "chainId": 1,
      "address": "0xAcfa209Fb73bF3Dd5bBfb1101B9Bc999C49062a5",
      "name": "EvidenZ",
      "symbol": "BCDT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2014/large/evidenz-512.png?1594871754"
    },
    {
      "chainId": 1,
      "address": "0x0f71B8De197A1C84d31de0F1fA7926c365F052B3",
      "name": "Arcona",
      "symbol": "ARCONA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4312/large/icon_ARCONA_%281%29.png?1651823900"
    },
    {
      "chainId": 1,
      "address": "0x948c70Dc6169Bfb10028FdBE96cbC72E9562b2Ac",
      "name": "PolkaFantasy",
      "symbol": "XP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18299/large/XP_Token_Icon.png?1631498467"
    },
    {
      "chainId": 1,
      "address": "0x3ebb4A4e91Ad83BE51F8d596533818b246F4bEe1",
      "name": "Signata",
      "symbol": "SATA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14704/large/logo.png?1617853256"
    },
    {
      "chainId": 1,
      "address": "0x4e4a47cAC6A28A62dcC20990ed2cdA9BC659469F",
      "name": "I will poop it NFT",
      "symbol": "SHIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25945/large/PCNoOl8.png?1654833800"
    },
    {
      "chainId": 1,
      "address": "0xCd7492db29E2ab436e819b249452EE1bbDf52214",
      "name": "SafeMoon Inu",
      "symbol": "SMI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/16091/large/SMI.png?1622801787"
    },
    {
      "chainId": 1,
      "address": "0x7eaF9C89037e4814DC0d9952Ac7F888C784548DB",
      "name": "Royale",
      "symbol": "ROYA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13602/large/roya.png?1636031771"
    },
    {
      "chainId": 1,
      "address": "0xC477D038d5420C6A9e0b031712f61c5120090de9",
      "name": "Boson Protocol",
      "symbol": "BOSON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14710/large/boson_logo.png?1617882472"
    },
    {
      "chainId": 1,
      "address": "0xaC0104Cca91D167873B8601d2e71EB3D4D8c33e0",
      "name": "Seascape Crowns",
      "symbol": "CWS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13835/large/crowns_logo.png?1612176905"
    },
    {
      "chainId": 1,
      "address": "0xE1c7E30C42C24582888C758984f6e382096786bd",
      "name": "Curate",
      "symbol": "XCUR",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13327/large/400x400_%281%29_%283%29_%282%29.png?1613998208"
    },
    {
      "chainId": 1,
      "address": "0xbb1EE07d6c7BAeB702949904080eb61f5D5e7732",
      "name": "Dogey Inu",
      "symbol": "DINU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16374/large/512x512_dinu_logo.jpg?1623919813"
    },
    {
      "chainId": 1,
      "address": "0x9196E18Bc349B1F64Bc08784eaE259525329a1ad",
      "name": "Pussy Financial",
      "symbol": "PUSSY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15213/large/pussytoken.png?1620110339"
    },
    {
      "chainId": 1,
      "address": "0x220B71671b649c03714dA9c621285943f3cbcDC6",
      "name": "TosDis",
      "symbol": "DIS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13745/large/Tosdis-black.png?1611379744"
    },
    {
      "chainId": 1,
      "address": "0xa3BeD4E1c75D00fa6f4E5E6922DB7261B5E9AcD2",
      "name": "mStable Governance  Meta",
      "symbol": "MTA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11846/large/mStable.png?1594950533"
    },
    {
      "chainId": 1,
      "address": "0x4946Fcea7C692606e8908002e55A582af44AC121",
      "name": "FOAM",
      "symbol": "FOAM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3345/large/K51lJQc.png?1547037959"
    },
    {
      "chainId": 1,
      "address": "0x419c4dB4B9e25d6Db2AD9691ccb832C8D9fDA05E",
      "name": "Dragonchain",
      "symbol": "DRGN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1289/large/dragonchain.png?1547957761"
    },
    {
      "chainId": 1,
      "address": "0xB045f7f363fE4949954811b113bd56d208c67B23",
      "name": "Spider Tanks",
      "symbol": "SILK",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/28057/large/SILK_Logo.png?1667295996"
    },
    {
      "chainId": 1,
      "address": "0x7697B462A7c4Ff5F8b55BDBC2F4076c2aF9cF51A",
      "name": "Sarcophagus",
      "symbol": "SARCO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15091/large/E2S2-CcUcAAyNxD.jpeg?1622519884"
    },
    {
      "chainId": 1,
      "address": "0xca1207647Ff814039530D7d35df0e1Dd2e91Fa84",
      "name": "dHEDGE DAO",
      "symbol": "DHT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12508/large/dht.png?1600752201"
    },
    {
      "chainId": 1,
      "address": "0x63b4f3e3fa4e438698CE330e365E831F7cCD1eF4",
      "name": "CyberFi",
      "symbol": "CFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13112/large/cyberfi_logo.jpeg?1605283367"
    },
    {
      "chainId": 1,
      "address": "0xEC681F28f4561c2a9534799AA38E0d36A83Cf478",
      "name": "YVS Finance",
      "symbol": "YVS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13471/large/cu0LSzE.png?1608852718"
    },
    {
      "chainId": 1,
      "address": "0xa8B61CfF52564758A204F841E636265bEBC8db9B",
      "name": "Yield Protocol",
      "symbol": "YIELD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14220/large/yield.png?1615030969"
    },
    {
      "chainId": 1,
      "address": "0x107c4504cd79C5d2696Ea0030a8dD4e92601B82e",
      "name": "Bloom",
      "symbol": "BLT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2662/large/bloom.png?1547036854"
    },
    {
      "chainId": 1,
      "address": "0x9e5BD9D9fAd182ff0A93bA8085b664bcab00fA68",
      "name": "Dinger",
      "symbol": "DINGER",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/19443/large/dinger.png?1661498131"
    },
    {
      "chainId": 1,
      "address": "0xbbBBBBB5AA847A2003fbC6b5C16DF0Bd1E725f61",
      "name": "B Protocol",
      "symbol": "BPRO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15110/large/66428641.jpg?1619749844"
    },
    {
      "chainId": 1,
      "address": "0x05Fb86775Fd5c16290f1E838F5caaa7342bD9a63",
      "name": "Hacken",
      "symbol": "HAI",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/11081/large/hacken-symbol-with-bg.png?1676512641"
    },
    {
      "chainId": 1,
      "address": "0x798D1bE841a82a273720CE31c822C61a67a601C3",
      "name": "DIGG",
      "symbol": "DIGG",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/13737/large/digg.PNG?1611292196"
    },
    {
      "chainId": 1,
      "address": "0x668C50B1c7f46EFFBE3f242687071d7908AAB00A",
      "name": "CoShi Inu",
      "symbol": "COSHI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15219/large/200.jpg?1620119215"
    },
    {
      "chainId": 1,
      "address": "0x8EF47555856f6Ce2E0cd7C36AeF4FAb317d2e2E2",
      "name": "PayAccept",
      "symbol": "PAYT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12513/large/logo.png?1603801944"
    },
    {
      "chainId": 1,
      "address": "0x21381e026Ad6d8266244f2A583b35F9E4413FA2a",
      "name": "Formation FI",
      "symbol": "FORM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16145/large/FORM.png?1623119824"
    },
    {
      "chainId": 1,
      "address": "0x491E136FF7FF03E6aB097E54734697Bb5802FC1C",
      "name": "Kattana",
      "symbol": "KTN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14739/large/256-256-1.png?1638363577"
    },
    {
      "chainId": 1,
      "address": "0x20945cA1df56D237fD40036d47E866C7DcCD2114",
      "name": "Nsure Network",
      "symbol": "NSURE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12948/large/Nsure_token.png?1603778876"
    },
    {
      "chainId": 1,
      "address": "0xDEf1CA1fb7FBcDC777520aa7f396b4E015F497aB",
      "name": "CoW Protocol",
      "symbol": "COW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24384/large/cow.png?1660960589"
    },
    {
      "chainId": 1,
      "address": "0x2f4eb47A1b1F4488C71fc10e39a4aa56AF33Dd49",
      "name": "UNCL",
      "symbol": "UNCL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13102/large/uncl_logo.png?1605230945"
    },
    {
      "chainId": 1,
      "address": "0x89d24A6b4CcB1B6fAA2625fE562bDD9a23260359",
      "name": "Sai",
      "symbol": "SAI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1442/large/dai.png?1547035520"
    },
    {
      "chainId": 1,
      "address": "0x4Fb721eF3Bf99e0f2c193847afA296b9257d3C30",
      "name": "Tokenplace",
      "symbol": "TOK",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/15779/large/output-onlinepngtools_%283%29.png?1621837855"
    },
    {
      "chainId": 1,
      "name": "Degenerator Meme",
      "address": "0xD5525D397898e5502075Ea5E830d8914f6F0affe",
      "decimals": 8,
      "symbol": "MEME",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/6597.png"
    },
    {
      "chainId": 1,
      "address": "0xc73C167E7a4Ba109e4052f70D5466D0C312A344D",
      "name": "Sanshu Inu",
      "symbol": "SANSHU",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15370/large/m9DgRlXY.jpg?1623177779"
    },
    {
      "chainId": 1,
      "address": "0x3cBb7f5d7499Af626026E96a2f05df806F2200DC",
      "name": "PandaDAO",
      "symbol": "PANDA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24926/large/PandaDAO_logo_512.png?1649388983"
    },
    {
      "chainId": 1,
      "address": "0xdc9Ac3C20D1ed0B540dF9b1feDC10039Df13F99c",
      "name": "Utrust",
      "symbol": "UTK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1824/large/300x300_logo.png?1570520533"
    },
    {
      "chainId": 1,
      "address": "0xF4d861575ecC9493420A3f5a14F85B13f0b50EB3",
      "name": "Fractal",
      "symbol": "FCL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14096/large/fractal_logo.png?1614264502"
    },
    {
      "chainId": 1,
      "address": "0x75231F58b43240C9718Dd58B4967c5114342a86c",
      "name": "OKB",
      "symbol": "OKB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4463/large/WeChat_Image_20220118095654.png?1642471050"
    },
    {
      "chainId": 1,
      "address": "0x0f7F961648aE6Db43C75663aC7E5414Eb79b5704",
      "name": "Blockzero Labs",
      "symbol": "XIO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10029/large/blockzero.jpg?1611110205"
    },
    {
      "chainId": 1,
      "address": "0x0c7D5ae016f806603CB1782bEa29AC69471CAb9c",
      "name": "Bifrost",
      "symbol": "BFC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4639/large/bifrost_32.png?1608520677"
    },
    {
      "chainId": 1,
      "address": "0x155040625D7ae3e9caDA9a73E3E44f76D3Ed1409",
      "name": "Revomon",
      "symbol": "REVO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14759/large/revomon.jpeg?1618243538"
    },
    {
      "chainId": 1,
      "address": "0xDF2C7238198Ad8B389666574f2d8bc411A4b7428",
      "name": "Hifi Finance  OLD ",
      "symbol": "MFT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3293/large/hft.png?1673534781"
    },
    {
      "chainId": 1,
      "address": "0x4eE438be38F8682ABB089F2BFeA48851C5E71EAF",
      "name": "Cryptonovae",
      "symbol": "YAE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14693/large/yae.png?1640337904"
    },
    {
      "chainId": 1,
      "address": "0x80CE3027a70e0A928d9268994e9B85d03Bd4CDcf",
      "name": "Lokr",
      "symbol": "LKR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14692/large/lokr.png?1648886932"
    },
    {
      "chainId": 1,
      "address": "0x03042482d64577A7bdb282260e2eA4c8a89C064B",
      "name": "Centaur",
      "symbol": "CNTR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12743/large/logo_%2898%29.png?1602630445"
    },
    {
      "chainId": 1,
      "address": "0x6781a0F84c7E9e846DCb84A9a5bd49333067b104",
      "name": "Zap",
      "symbol": "ZAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2180/large/zap.png?1547036476"
    },
    {
      "chainId": 1,
      "address": "0x15B543e986b8c34074DFc9901136d9355a537e7E",
      "name": "Student Coin",
      "symbol": "STC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/6260/large/logo_in_circle_%281%29.png?1667725082"
    },
    {
      "chainId": 1,
      "address": "0x95a4492F028aa1fd432Ea71146b433E7B4446611",
      "name": "APY Finance",
      "symbol": "APY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13041/large/1*AvkD-OLocausbxqUzezZ0A.png?1604577922"
    },
    {
      "chainId": 1,
      "address": "0x9C2dc0c3CC2BADdE84B0025Cf4df1c5aF288D835",
      "name": "COR Token",
      "symbol": "COR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12856/large/COR.png?1620210966"
    },
    {
      "chainId": 1,
      "address": "0x3b484b82567a09e2588A13D54D032153f0c0aEe0",
      "name": "OpenDAO",
      "symbol": "SOS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21956/large/fo42wXI6_400x400.jpg?1640373810"
    },
    {
      "chainId": 1,
      "address": "0xF406F7A9046793267bc276908778B29563323996",
      "name": "APY vision",
      "symbol": "VISION",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13288/large/apyvisionlogo200circle.png?1607059042"
    },
    {
      "chainId": 1,
      "address": "0x44709a920fCcF795fbC57BAA433cc3dd53C44DbE",
      "name": "DappRadar",
      "symbol": "RADAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20894/large/radar.png?1640306268"
    },
    {
      "chainId": 1,
      "address": "0x88ACDd2a6425c3FaAE4Bc9650Fd7E27e0Bebb7aB",
      "name": "Alchemist",
      "symbol": "MIST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14655/large/79158662.png?1617589045"
    },
    {
      "chainId": 1,
      "address": "0xbEEf3bB9dA340EbdF0f5bae2E85368140d7D85D0",
      "name": "BuyMORE",
      "symbol": "MORE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26769/large/0BD4687E-6C18-43D2-87C7-C5BC144B49D0_200x200.jpeg?1660040979"
    },
    {
      "chainId": 1,
      "address": "0xa1d65E8fB6e87b60FECCBc582F7f97804B725521",
      "name": "DXdao",
      "symbol": "DXD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11148/large/dxdao.png?1607999331"
    },
    {
      "chainId": 1,
      "address": "0xA8b12Cc90AbF65191532a12bb5394A714A46d358",
      "name": "pBTC35A",
      "symbol": "PBTC35A",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13653/large/pBTC35A.png?1610574940"
    },
    {
      "chainId": 1,
      "address": "0x71a28feAEe902966DC8D355e7B8Aa427D421e7e0",
      "name": "LunchDAO",
      "symbol": "LUNCH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25808/large/200x200.png?1653979480"
    },
    {
      "chainId": 1,
      "address": "0x0e8D2EB7D6bDF28393c25a1966385Ad32Ff0259a",
      "name": "Streamer Inu",
      "symbol": "STREAMERINU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27994/large/logo.png?1666922914"
    },
    {
      "chainId": 1,
      "address": "0x6149C26Cd2f7b5CCdb32029aF817123F6E37Df5B",
      "name": "Launchpool",
      "symbol": "LPOOL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14041/large/dGUvV0HQ_400x400.jpg?1613976219"
    },
    {
      "chainId": 1,
      "address": "0x08AD83D779BDf2BBE1ad9cc0f78aa0D24AB97802",
      "name": "Robonomics Web Services",
      "symbol": "RWS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11885/large/rws_logo.png?1595745253"
    },
    {
      "chainId": 1,
      "address": "0x777E2ae845272a2F540ebf6a3D03734A5a8f618e",
      "name": "Ryoshis Vision",
      "symbol": "RYOSHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17614/large/OFFICIAL_RYOSHI_LOGO-removebg-preview_2_200x200.png?1629794604"
    },
    {
      "chainId": 1,
      "address": "0x8a6D4C8735371EBAF8874fBd518b56Edd66024eB",
      "name": "BLOCKS",
      "symbol": "BLOCKS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/19666/large/blocks_logo_200200.png?1681972436"
    },
    {
      "chainId": 1,
      "address": "0x072987D5B36aD8d45552aEd98879a7101cCdd749",
      "name": "BunnyVerse",
      "symbol": "BNV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21846/large/Screenshot-2021-12-21-at-11-11-46.png?1640130263"
    },
    {
      "chainId": 1,
      "address": "0x0E8d6b471e332F140e7d9dbB99E5E3822F728DA6",
      "name": "Abyss",
      "symbol": "ABYSS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2105/large/NrFmpxs.png?1600318377"
    },
    {
      "chainId": 1,
      "address": "0xFbbE9b1142C699512545f47937Ee6fae0e4B0aA9",
      "name": "EDDASwap",
      "symbol": "EDDA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14368/large/edda.png?1615732928"
    },
    {
      "chainId": 1,
      "address": "0x72e9D9038cE484EE986FEa183f8d8Df93f9aDA13",
      "name": "SmartCredit",
      "symbol": "SMARTCREDIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13036/large/smartcredit_logo_02_white_a-1.png?1604545479"
    },
    {
      "chainId": 1,
      "address": "0x8A9C67fee641579dEbA04928c4BC45F66e26343A",
      "name": "Jarvis Reward",
      "symbol": "JRT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10390/large/cfeii0y.png?1578868949"
    },
    {
      "chainId": 1,
      "address": "0x69bBC3F8787d573F1BBDd0a5f40C7bA0Aee9BCC9",
      "name": "Yup",
      "symbol": "YUP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12322/large/photo_2021-10-26_00-47-35.jpg?1635227479"
    },
    {
      "chainId": 1,
      "address": "0x525A8F6F3Ba4752868cde25164382BfbaE3990e1",
      "name": "Nym",
      "symbol": "NYM",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/24488/large/NYM_Token.png?1649926353"
    },
    {
      "chainId": 1,
      "address": "0xaAAf91D9b90dF800Df4F55c205fd6989c977E73a",
      "name": "Monolith",
      "symbol": "TKN",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/675/large/Monolith.png?1566296607"
    },
    {
      "chainId": 1,
      "address": "0xeEEE2a622330E6d2036691e983DEe87330588603",
      "name": "Asko",
      "symbol": "ASKO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11773/large/ASKO.png?1662435680"
    },
    {
      "chainId": 1,
      "address": "0x8798249c2E607446EfB7Ad49eC89dD1865Ff4272",
      "name": "xSUSHI",
      "symbol": "XSUSHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13725/large/xsushi.png?1612538526"
    },
    {
      "chainId": 1,
      "address": "0x3C03b4EC9477809072FF9CC9292C9B25d4A8e6c6",
      "name": "CoverCompared",
      "symbol": "CVR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13720/large/cvr.png?1635416411"
    },
    {
      "chainId": 1,
      "address": "0xEe9801669C6138E84bD50dEB500827b776777d28",
      "name": "O3 Swap",
      "symbol": "O3",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15460/large/o3.png?1620904316"
    },
    {
      "chainId": 1,
      "address": "0xf9FBE825BFB2bF3E387af0Dc18caC8d87F29DEa8",
      "name": "Radar",
      "symbol": "RADAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13909/large/RADAR.png?1634183461"
    },
    {
      "chainId": 1,
      "address": "0x6e8908cfa881C9f6f2C64d3436E7b80b1bf0093F",
      "name": "Bistroo",
      "symbol": "BIST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15645/large/bistroo.png?1659342030"
    },
    {
      "chainId": 1,
      "address": "0x476c5E26a75bd202a9683ffD34359C0CC15be0fF",
      "name": "Serum",
      "symbol": "SRM",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/11970/large/serum-logo.png?1597121577"
    },
    {
      "chainId": 1,
      "address": "0xe87e15B9c7d989474Cb6d8c56b3DB4eFAD5b21E8",
      "name": "HOKK Finance",
      "symbol": "HOKK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14985/large/hokk.png?1662706232"
    },
    {
      "chainId": 1,
      "address": "0x3abF2A4f8452cCC2CF7b4C1e4663147600646f66",
      "name": "Juicebox",
      "symbol": "JBX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21120/large/CCeIEmvE_400x400.jpg?1638341224"
    },
    {
      "chainId": 1,
      "address": "0x59d1e836F7b7210A978b25a855085cc46fd090B5",
      "name": "AssangeDAO",
      "symbol": "JUSTICE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23555/large/JUSTICE_token_logo.png?1644532689"
    },
    {
      "chainId": 1,
      "address": "0xEd0439EACf4c4965AE4613D77a5C2Efe10e5f183",
      "name": "Niftyx Protocol",
      "symbol": "SHROOM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12341/large/niftyx_logo.jpg?1617784430"
    },
    {
      "chainId": 1,
      "address": "0x1F3f9D3068568F8040775be2e8C03C103C61f3aF",
      "name": "Archer DAO Governance",
      "symbol": "ARCH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13188/large/archer_logo.png?1606097487"
    },
    {
      "chainId": 1,
      "address": "0x15874d65e649880c2614e7a480cb7c9A55787FF6",
      "name": "EthereumMax",
      "symbol": "EMAX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15540/large/EMAX-Coin-Final2000x.png?1639402630"
    },
    {
      "chainId": 1,
      "address": "0x6006FC2a849fEdABa8330ce36F5133DE01F96189",
      "name": "Spaceswap SHAKE",
      "symbol": "SHAKE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12765/large/shake.png?1633423725"
    },
    {
      "chainId": 1,
      "address": "0xC0F9bD5Fa5698B6505F643900FFA515Ea5dF54A9",
      "name": "Donut",
      "symbol": "DONUT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7538/large/Donut.png?1548234345"
    },
    {
      "chainId": 1,
      "address": "0xbD0a4bf098261673d5E6e600Fd87ddcd756e6764",
      "name": "Hina Inu",
      "symbol": "HINA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15993/large/download.png?1622549919"
    },
    {
      "chainId": 1,
      "address": "0x67B6D479c7bB412C54e03dCA8E1Bc6740ce6b99C",
      "name": "Kylin Network",
      "symbol": "KYL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14164/large/kyl_logo.jpg?1647507720"
    },
    {
      "chainId": 1,
      "address": "0x04969cD041C0cafB6AC462Bd65B536A5bDB3A670",
      "name": "Wrapped ECOMI",
      "symbol": "WOMI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14675/large/ecomi.jpg?1617689100"
    },
    {
      "chainId": 1,
      "address": "0x5F0E628B693018f639D10e4A4F59BD4d8B2B6B44",
      "name": "Whiteheart",
      "symbol": "WHITE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13484/large/whiteheart.png?1609076548"
    },
    {
      "chainId": 1,
      "address": "0x4da08a1Bff50BE96bdeD5C7019227164b49C2bFc",
      "name": "Mononoke Inu",
      "symbol": "MONONOKE-INU",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/18769/large/z9YDK0f.png?1633357322"
    },
    {
      "chainId": 1,
      "address": "0x8f3470A7388c05eE4e7AF3d01D8C722b0FF52374",
      "name": "Veritaseum",
      "symbol": "VERI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/695/large/veritaseum.png?1547034460"
    },
    {
      "chainId": 1,
      "address": "0xc8D3DCb63C38607Cb0c9d3F55E8eccE628A01C36",
      "name": "Matrix Labs",
      "symbol": "MATRIX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18297/large/matrixlabs.png?1643277367"
    },
    {
      "chainId": 1,
      "address": "0xb26C4B3Ca601136Daf98593feAeff9E0CA702a8D",
      "name": "Aladdin DAO",
      "symbol": "ALD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18277/large/78200839.png?1631234134"
    },
    {
      "chainId": 1,
      "address": "0xFD957F21bd95E723645C07C48a2d8ACB8Ffb3794",
      "name": "Ethereum Meta",
      "symbol": "ETHM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/6586/large/ethereum-meta.png?1548125409"
    },
    {
      "chainId": 1,
      "address": "0x80fB784B7eD66730e8b1DBd9820aFD29931aab03",
      "name": "Aave  OLD ",
      "symbol": "LEND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1365/large/ethlend.png?1547394586"
    },
    {
      "chainId": 1,
      "address": "0xf34B1Db61ACa1a371fE97BAd2606c9f534fb9D7D",
      "name": "ArbiSmart",
      "symbol": "RBIS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21906/large/imgonline-com-ua-Resize-cMjOYOwg12bLazt.png?1640235509"
    },
    {
      "chainId": 1,
      "address": "0x77777777772cf0455fB38eE0e75f38034dFa50DE",
      "name": "XY Finance",
      "symbol": "XY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21541/large/xy.png?1639913622"
    },
    {
      "chainId": 1,
      "address": "0xc4C75F2A0cB1a9ACc33929512dc9733EA1Fd6fde",
      "name": "Martin Shkreli Inu",
      "symbol": "MSI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26365/large/jEYEUxUI_400x400.jpeg?1657600080"
    },
    {
      "chainId": 1,
      "address": "0x5F474906637bdCDA05f29C74653F6962bb0f8eDa",
      "name": "DeFinity",
      "symbol": "DEFX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15875/large/definity-listing-logo.png?1622414896"
    },
    {
      "chainId": 1,
      "address": "0xB620Be8a1949AA9532e6a3510132864EF9Bc3F82",
      "name": "Lend Flare Dao",
      "symbol": "LFT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/24846/large/e5x55-kU_400x400.jpg?1649116244"
    },
    {
      "chainId": 1,
      "address": "0xad32A8e6220741182940c5aBF610bDE99E737b2D",
      "name": "PieDAO DOUGH v2",
      "symbol": "DOUGH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12693/large/DOUGH2v.png?1602655308"
    },
    {
      "chainId": 1,
      "address": "0x630d98424eFe0Ea27fB1b3Ab7741907DFFEaAd78",
      "name": "PEAKDEFI",
      "symbol": "PEAK",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/9626/large/PEAKDEFI_Logo_250x250.png?1603094772"
    },
    {
      "chainId": 1,
      "address": "0x1E9D0bB190Ac34492aa11B80D28c1C86487a341F",
      "name": "The Neko",
      "symbol": "NEKO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22692/large/FL6SU9b5_400x400.jpg?1642409749"
    },
    {
      "chainId": 1,
      "address": "0x383518188C0C6d7730D91b2c03a03C837814a899",
      "name": "Olympus v1",
      "symbol": "OHM",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/21496/large/OHM.jpg?1639620224"
    },
    {
      "chainId": 1,
      "address": "0xAC8E13ecC30Da7Ff04b842f21A62a1fb0f10eBd5",
      "name": "BabyDoge ETH",
      "symbol": "BABYDOGE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/17166/large/logo_256px_%281%29.png?1626684127"
    },
    {
      "chainId": 1,
      "address": "0x2aF1dF3AB0ab157e1E2Ad8F88A7D04fbea0c7dc6",
      "name": "Bankless BED Index",
      "symbol": "BED",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17175/large/BED_Logo_-_No_border.png?1626833695"
    },
    {
      "chainId": 1,
      "address": "0xE0aD1806Fd3E7edF6FF52Fdb822432e847411033",
      "name": "OnX Finance",
      "symbol": "ONX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13445/large/onxlogo-1.png?1608629659"
    },
    {
      "chainId": 1,
      "address": "0xF063fE1aB7a291c5d06a86e14730b00BF24cB589",
      "name": "DxSale Network",
      "symbol": "SALE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12250/large/dx-light.png?1613965390"
    },
    {
      "chainId": 1,
      "address": "0xe516D78d784C77D479977BE58905B3f2b1111126",
      "name": "Bitspawn",
      "symbol": "SPWN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16513/large/token_logo.png?1631603192"
    },
    {
      "chainId": 1,
      "address": "0x5dD57Da40e6866C9FcC34F4b6DDC89F1BA740DfE",
      "name": "BrightID",
      "symbol": "BRIGHT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18415/large/bright.PNG?1631841211"
    },
    {
      "chainId": 1,
      "address": "0x22B6C31c2bEB8f2d0d5373146Eed41Ab9eDe3caf",
      "name": "cocktailbar finance",
      "symbol": "COC",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13121/large/coc.png?1647079316"
    },
    {
      "chainId": 1,
      "address": "0x469eDA64aEd3A3Ad6f868c44564291aA415cB1d9",
      "name": "Datamine FLUX",
      "symbol": "FLUX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11756/large/fluxres.png?1593748917"
    },
    {
      "chainId": 1,
      "address": "0xBEaB712832112bd7664226db7CD025B153D3af55",
      "name": "Bright Union",
      "symbol": "BRIGHT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17552/large/BrightToken_Token-only_200x200-1.png?1628227007"
    },
    {
      "chainId": 1,
      "address": "0x66C0DDEd8433c9EA86C8cf91237B14e10b4d70B7",
      "name": "Mars",
      "symbol": "MARS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13654/large/MARS.png?1610575403"
    },
    {
      "chainId": 1,
      "address": "0xc813EA5e3b48BEbeedb796ab42A30C5599b01740",
      "name": "Autonio",
      "symbol": "NIOX",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/1122/large/NewLogo.png?1597298450"
    },
    {
      "chainId": 1,
      "address": "0x71ba91dC68C6a206Db0A6A92B4b1De3f9271432d",
      "name": "MobieCoin",
      "symbol": "MBX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12874/large/MBX_token.jpg?1603186697"
    },
    {
      "chainId": 1,
      "address": "0x666d875C600AA06AC1cf15641361dEC3b00432Ef",
      "name": "BTSE Token",
      "symbol": "BTSE",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/10807/large/BTSE_logo_Square.jpeg?1583965964"
    },
    {
      "chainId": 1,
      "name": "Dripto",
      "address": "0xBE1fa1303e2979Ab4d4e5dF3D1c6e3656ACAb027",
      "decimals": 18,
      "symbol": "DRYP",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/19023.png"
    },
    {
      "chainId": 1,
      "address": "0x65F9A292f1AEED5D755Aa2fD2Fb17AB2E9431447",
      "name": "SoMee Social",
      "symbol": "SOMEE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16406/large/SoMeeBallLogo200x200.png?1623920285"
    },
    {
      "chainId": 1,
      "address": "0xd83AE04c9eD29d6D3E6Bf720C71bc7BeB424393E",
      "name": "InsureDAO",
      "symbol": "INSURE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23913/large/InsureDAO_-_Final_Logo_%28solo%29.png?1645682885"
    },
    {
      "chainId": 1,
      "address": "0x45080a6531d671DDFf20DB42f93792a489685e32",
      "name": "Finance Vote",
      "symbol": "FVT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13181/large/finance.png?1606015010"
    },
    {
      "chainId": 1,
      "address": "0xFE5F69dfa2d4501E78078266F6d430c079098f90",
      "name": "Archie Neko",
      "symbol": "ARCHIE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28234/large/photo1667927837.jpeg?1668575767"
    },
    {
      "chainId": 1,
      "address": "0x6Ef6610d24593805144d73b13d4405E00A4E4aC7",
      "name": "Die Protocol",
      "symbol": "DIE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27903/large/newlogo.jpg?1666334549"
    },
    {
      "chainId": 1,
      "address": "0x42d6622deCe394b54999Fbd73D108123806f6a18",
      "name": "SpankChain",
      "symbol": "SPANK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1226/large/spankchain.png?1548610811"
    },
    {
      "chainId": 1,
      "address": "0x3d6F0DEa3AC3C607B3998e6Ce14b6350721752d9",
      "name": "Cardstarter",
      "symbol": "CARDS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14612/large/CARDSx200.png?1617252006"
    },
    {
      "chainId": 1,
      "address": "0x3505F494c3f0fed0B594E01Fa41Dd3967645ca39",
      "name": "Swarm Network",
      "symbol": "SWM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/197/large/swarm.jpg?1547033949"
    },
    {
      "chainId": 1,
      "address": "0xD567B5F02b9073aD3a982a099a23Bf019FF11d1c",
      "name": "Gamestarter",
      "symbol": "GAME",
      "decimals": 5,
      "logoURI": "https://assets.coingecko.com/coins/images/17604/large/gpMi14-r_400x400.jpg?1628647205"
    },
    {
      "chainId": 1,
      "address": "0x418D75f65a02b3D53B2418FB8E1fe493759c7605",
      "name": "Binance Coin Wormhole ",
      "symbol": "BNB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22884/large/BNB_wh_small.png?1644224553"
    },
    {
      "chainId": 1,
      "address": "0x1337DEF16F9B486fAEd0293eb623Dc8395dFE46a",
      "name": "ARMOR",
      "symbol": "ARMOR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13748/large/armor.png?1611425846"
    },
    {
      "chainId": 1,
      "address": "0x0E29e5AbbB5FD88e28b2d355774e73BD47dE3bcd",
      "name": "Hakka Finance",
      "symbol": "HAKKA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12163/large/Hakka-icon.png?1597746776"
    },
    {
      "chainId": 1,
      "address": "0xDb05EA0877A2622883941b939f0bb11d1ac7c400",
      "name": "Opacity",
      "symbol": "OPCT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7237/large/Opacity.jpg?1551843524"
    },
    {
      "chainId": 1,
      "address": "0x68a3637bA6E75c0f66B61A42639c4e9fCD3D4824",
      "name": "MoonSwap",
      "symbol": "MOON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12441/large/moon.jpg?1599880968"
    },
    {
      "chainId": 1,
      "address": "0x43044f861ec040DB59A7e324c40507adDb673142",
      "name": "Cap",
      "symbol": "CAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11775/large/cap.png?1673549056"
    },
    {
      "chainId": 1,
      "address": "0xbd1848e1491d4308Ad18287A745DD4DB2A4BD55B",
      "name": "Mochi Market",
      "symbol": "MOMA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14993/large/mochi.PNG?1619390399"
    },
    {
      "chainId": 1,
      "address": "0x923b83c26B3809d960fF80332Ed00aA46D7Ed375",
      "name": "Creator Platform",
      "symbol": "CTR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18252/large/logo_%281%29.png?1631137441"
    },
    {
      "chainId": 1,
      "address": "0x89bD2E7e388fAB44AE88BEf4e1AD12b4F1E0911c",
      "name": "Peanut",
      "symbol": "NUX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13958/large/2sAMZXpO_400x400.jpg?1613353972"
    },
    {
      "chainId": 1,
      "address": "0xD69F306549e9d96f183B1AecA30B8f4353c2ECC3",
      "name": "MCH Coin",
      "symbol": "MCHC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15399/large/MCHC.jpg?1620721307"
    },
    {
      "chainId": 1,
      "address": "0x8eEF5a82E6Aa222a60F009ac18c24EE12dBf4b41",
      "name": "Autobahn Network",
      "symbol": "TXL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12432/large/txl.png?1646463631"
    },
    {
      "chainId": 1,
      "address": "0x343c6de13833bc7d9890eb6B1cd3FBeBC730EBec",
      "name": "Decentralized Activism",
      "symbol": "DACT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/27700/large/logodact200x200.png?1665305210"
    },
    {
      "chainId": 1,
      "address": "0xF80D589b3Dbe130c270a69F1a69D050f268786Df",
      "name": "Datamine",
      "symbol": "DAM",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11695/large/qxsFH8W.png?1592880463"
    },
    {
      "chainId": 1,
      "address": "0x9Ed8e7C9604790F7Ec589F99b94361d8AAB64E5E",
      "name": "Unistake",
      "symbol": "UNISTAKE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12813/large/unistake.png?1612346684"
    },
    {
      "chainId": 1,
      "address": "0x1d37986F252d0e349522EA6C3B98Cb935495E63E",
      "name": "ChartEx",
      "symbol": "CHART",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12523/large/chartex.png?1600499406"
    },
    {
      "chainId": 1,
      "address": "0x5aaEFe84E0fB3DD1f0fCfF6fA7468124986B91bd",
      "name": "Evedo",
      "symbol": "EVED",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7721/large/Variations-09.png?1549979992"
    },
    {
      "chainId": 1,
      "address": "0x72630B1e3B42874bf335020Ba0249e3E9e47Bafc",
      "name": "Paypolitan",
      "symbol": "EPAN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13192/large/ava3.png?1606102032"
    },
    {
      "chainId": 1,
      "address": "0x56d811088235F11C8920698a204A5010a788f4b3",
      "name": "bZx Protocol",
      "symbol": "BZRX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11811/large/bzrx.png?1594563172"
    },
    {
      "chainId": 1,
      "address": "0xBC19712FEB3a26080eBf6f2F7849b417FdD792CA",
      "name": "BoringDAO",
      "symbol": "BORING",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16429/large/Tjq3pXEH_400x400.jpg?1623997009"
    },
    {
      "chainId": 1,
      "address": "0x30f271C9E86D2B7d00a6376Cd96A1cFBD5F0b9b3",
      "name": "Decentr",
      "symbol": "DEC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11816/large/Decentr.png?1594637985"
    },
    {
      "chainId": 1,
      "address": "0x85f6eB2BD5a062f5F8560BE93FB7147e16c81472",
      "name": "Franklin",
      "symbol": "FLY",
      "decimals": 4,
      "logoURI": "https://assets.coingecko.com/coins/images/14810/large/fly_logo_sq_bArtboard_4.png?1626420796"
    },
    {
      "chainId": 1,
      "address": "0x758B4684BE769E92eeFeA93f60DDA0181eA303Ec",
      "name": "Phonon DAO",
      "symbol": "PHONON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22308/large/ezgif-2-e7fb84364d.png?1641449852"
    },
    {
      "chainId": 1,
      "address": "0x2602278EE1882889B946eb11DC0E810075650983",
      "name": "Vader Protocol",
      "symbol": "VADER",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20497/large/AcF08Jk1_400x400.jpg?1637131991"
    },
    {
      "chainId": 1,
      "address": "0xc55c2175E90A46602fD42e931f62B3Acc1A013Ca",
      "name": "Mogul Productions",
      "symbol": "STARS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14975/large/STARS_LOGO_PNG.png?1619214520"
    },
    {
      "chainId": 1,
      "name": "Toshimon",
      "address": "0xF136D7b0B7AE5b86D21E7B78DFA95375a7360f19",
      "decimals": 18,
      "symbol": "TOSHI",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/8744.png"
    },
    {
      "chainId": 1,
      "address": "0xc834Fa996fA3BeC7aAD3693af486ae53D8aA8B50",
      "name": "Convergence",
      "symbol": "CONV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14519/large/Convergence_Logo_%28Final%29.png?1616667041"
    },
    {
      "chainId": 1,
      "address": "0xeDF6568618A00C6F0908Bf7758A16F76B6E04aF9",
      "name": "Arianee",
      "symbol": "ARIA20",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5054/large/Aria_Logo_256.png?1610097866"
    },
    {
      "chainId": 1,
      "address": "0x0Ae055097C6d159879521C384F1D2123D1f195e6",
      "name": "STAKE",
      "symbol": "STAKE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11061/large/xdai.png?1587714165"
    },
    {
      "chainId": 1,
      "address": "0x5228a22e72ccC52d415EcFd199F99D0665E7733b",
      "name": "pTokens BTC  OLD ",
      "symbol": "PBTC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/10805/large/J51iIea.png?1583891599"
    },
    {
      "chainId": 1,
      "name": "FRMx Token",
      "address": "0xf6832EA221ebFDc2363729721A146E6745354b14",
      "decimals": 18,
      "symbol": "FRMX",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/7631.png"
    },
    {
      "chainId": 1,
      "address": "0xf8C3527CC04340b208C854E985240c02F7B7793f",
      "name": "Frontier",
      "symbol": "FRONT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12479/large/frontier_logo.png?1600145472"
    },
    {
      "chainId": 1,
      "address": "0x6be61833FC4381990e82D7D4a9F4c9B3F67eA941",
      "name": "Hotbit",
      "symbol": "HTB",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5990/large/hotbit-token.png?1547041932"
    },
    {
      "chainId": 1,
      "address": "0xC0Eb85285d83217CD7c891702bcbC0FC401E2D9D",
      "name": "Hiveterminal",
      "symbol": "HVN",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/899/large/Hiveterminal_token.jpg?1547034726"
    },
    {
      "chainId": 1,
      "address": "0x28cb7e841ee97947a86B06fA4090C8451f64c0be",
      "name": "YF Link",
      "symbol": "YFL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12081/large/YFLink.png?1596987945"
    },
    {
      "chainId": 1,
      "address": "0x1Da87b114f35E1DC91F72bF57fc07A768Ad40Bb0",
      "name": "Equalizer",
      "symbol": "EQZ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14741/large/X2p5mb2f_400x400.png?1618005664"
    },
    {
      "chainId": 1,
      "address": "0x1735Db6AB5BAa19eA55d0AdcEeD7bcDc008B3136",
      "name": "UREEQA",
      "symbol": "URQA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14605/large/R_O2enOX_400x400.png?1617243310"
    },
    {
      "chainId": 1,
      "address": "0xAEcc217a749c2405b5ebC9857a16d58Bdc1c367F",
      "name": "Pawthereum",
      "symbol": "PAWTH",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/19275/large/pawth.png?1635127429"
    },
    {
      "chainId": 1,
      "address": "0x7F3EDcdD180Dbe4819Bd98FeE8929b5cEdB3AdEB",
      "name": "xToken",
      "symbol": "XTK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14089/large/xtk.png?1659278233"
    },
    {
      "chainId": 1,
      "address": "0x3C6ff50c9Ec362efa359317009428d52115fe643",
      "name": "PeerEx Network",
      "symbol": "PERX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12091/large/2AyoUJyQ_400x400.jpg?1597273390"
    },
    {
      "chainId": 1,
      "address": "0xBe1a001FE942f96Eea22bA08783140B9Dcc09D28",
      "name": "Beta Finance",
      "symbol": "BETA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18715/large/beta_finance.jpg?1633087053"
    },
    {
      "chainId": 1,
      "address": "0xC5b3D3231001a776123194Cf1290068e8b0C783b",
      "name": "LIT",
      "symbol": "LIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21344/large/LitLogo_CG.png?1639990605"
    },
    {
      "chainId": 1,
      "address": "0x36E43065e977bC72CB86Dbd8405fae7057CDC7fD",
      "name": "ArchAngel",
      "symbol": "ARCHA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/18814/large/Archa_200_x_200_PNG.png?1674811033"
    },
    {
      "chainId": 1,
      "address": "0x7E9D8f07A64e363e97A648904a89fb4cd5fB94CD",
      "name": "Forefront",
      "symbol": "FF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14659/large/N2kir6jx_400x400.jpg?1617608020"
    },
    {
      "chainId": 1,
      "address": "0x515d7E9D75E2b76DB60F8a051Cd890eBa23286Bc",
      "name": "Governor DAO",
      "symbol": "GDAO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13140/large/GDAOlogo2-bird.png?1605591842"
    },
    {
      "chainId": 1,
      "address": "0x0C37Bcf456bC661C14D596683325623076D7e283",
      "name": "Aeron",
      "symbol": "ARNX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1124/large/ARNX-token-logo-256x256.png?1602652111"
    },
    {
      "chainId": 1,
      "address": "0x6f80310CA7F2C654691D1383149Fa1A57d8AB1f8",
      "name": "Silo Finance",
      "symbol": "SILO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21454/large/y0iYKZOv_400x400.png?1639269432"
    },
    {
      "chainId": 1,
      "address": "0xBbff34E47E559ef680067a6B1c980639EEb64D24",
      "name": "Leverj Gluon",
      "symbol": "L2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12950/large/Gluon256x256.png?1604048379"
    },
    {
      "chainId": 1,
      "address": "0x12f649A9E821F90BB143089a6e56846945892ffB",
      "name": "Hyprr",
      "symbol": "UDOO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3078/large/HYPRR-WIDGET-CIRCLE-ONBLACK-1.jpg?1646752306"
    },
    {
      "chainId": 1,
      "address": "0x741b0428Efdf4372A8DF6FB54B018dB5e5aB7710",
      "name": "ARTX",
      "symbol": "ARTX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14652/large/logo_black_cmc.png?1617556500"
    },
    {
      "chainId": 1,
      "address": "0x2370f9d504c7a6E775bf6E14B3F12846b594cD53",
      "name": "JPY Coin v1",
      "symbol": "JPYC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17277/large/WoZ8rruL_400x400.png?1627016492"
    },
    {
      "chainId": 1,
      "address": "0x7968bc6a03017eA2de509AAA816F163Db0f35148",
      "name": "Hedget",
      "symbol": "HGET",
      "decimals": 6,
      "logoURI": "https://assets.coingecko.com/coins/images/12453/large/Hedget.png?1599944809"
    },
    {
      "chainId": 1,
      "address": "0x01fF50f8b7f74E4f00580d9596cd3D0d6d6E326f",
      "name": "BnkToTheFuture",
      "symbol": "BFT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3468/large/bnktothefuture.png?1547351865"
    },
    {
      "chainId": 1,
      "address": "0x8793Fb615Eb92822F482f88B3137B00aad4C00D2",
      "name": "revoAI",
      "symbol": "REVOAI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28952/large/roveAI1_%283%29.png?1675582353"
    },
    {
      "chainId": 1,
      "address": "0x255Aa6DF07540Cb5d3d297f0D0D4D84cb52bc8e6",
      "name": "Raiden Network",
      "symbol": "RDN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1132/large/raiden-logo.jpg?1547035131"
    },
    {
      "chainId": 1,
      "address": "0xB893A8049f250b57eFA8C62D51527a22404D7c9A",
      "name": "American Shiba",
      "symbol": "USHIBA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15650/large/american_shiba.PNG?1621476610"
    },
    {
      "chainId": 1,
      "address": "0x05079687D35b93538cbd59fe5596380cae9054A9",
      "name": "BitSong",
      "symbol": "BTSG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5041/large/logo_-_2021-01-10T210801.390.png?1610284134"
    },
    {
      "chainId": 1,
      "address": "0xa456b515303B2Ce344E9d2601f91270f8c2Fea5E",
      "name": "Cornichon",
      "symbol": "CORN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13235/large/cornichon.png?1606629943"
    },
    {
      "chainId": 1,
      "address": "0x20a8CEC5fffea65Be7122BCaB2FFe32ED4Ebf03a",
      "name": "DinoX",
      "symbol": "DNXC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17321/large/asset_icon_dnxc_200.png?1627292452"
    },
    {
      "chainId": 1,
      "address": "0xe8Ff5C9c75dEb346acAc493C463C8950Be03Dfba",
      "name": "VIBE",
      "symbol": "VIBE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/948/large/vibe.png?1547034809"
    },
    {
      "chainId": 1,
      "address": "0x6524B87960c2d573AE514fd4181777E7842435d4",
      "name": "Benzene",
      "symbol": "BZN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17368/large/bzn-logo-200.png?1627437320"
    },
    {
      "chainId": 1,
      "address": "0x579CEa1889991f68aCc35Ff5c3dd0621fF29b0C9",
      "name": "IQ",
      "symbol": "IQ",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5010/large/YAIS3fUh.png?1626267646"
    },
    {
      "chainId": 1,
      "address": "0x39Fa206c1648944f92E8F7B626e1CBdf78d7E9dB",
      "name": "DXY Finance",
      "symbol": "DXY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12839/large/dxy_finance.png?1602903489"
    },
    {
      "chainId": 1,
      "address": "0x6769D86f9C430f5AC6d9c861a0173613F1C5544C",
      "name": "KoaCombat",
      "symbol": "KOACOMBAT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/23827/large/jGYAi2LB_400x400.jpg?1645515278"
    },
    {
      "chainId": 1,
      "address": "0x56de8BC61346321D4F2211e3aC3c0A7F00dB9b76",
      "name": "RENA Finance",
      "symbol": "RENA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15667/large/photo_2021-05-21_17-31-35.png?1621825861"
    },
    {
      "chainId": 1,
      "address": "0x91a5de30e57831529a3c1aF636A78a7E4E83f3aa",
      "name": "Hulk Inu",
      "symbol": "HULK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/26358/large/HULKINU_LOGO.png?1657593698"
    },
    {
      "chainId": 1,
      "address": "0x035dF12E0F3ac6671126525f1015E47D79dFEDDF",
      "name": "0xMonero",
      "symbol": "0XMR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11035/large/0xmnr.PNG?1587357680"
    },
    {
      "chainId": 1,
      "address": "0x9d93692E826A4bd9e903e2A27D7FbD1e116efdad",
      "name": "POLY Maximus",
      "symbol": "POLY",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28236/large/photo_2022-11-09_12-53-56.jpg?1668576107"
    },
    {
      "chainId": 1,
      "address": "0xa4bBE66f151B22B167127c770016b15fF97Dd35C",
      "name": "Umbria Network",
      "symbol": "UMBR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14712/large/RX7VJg6.png?1617891954"
    },
    {
      "chainId": 1,
      "address": "0x147faF8De9d8D8DAAE129B187F0D02D819126750",
      "name": "GeoDB",
      "symbol": "GEO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11130/large/geodb.png?1588941704"
    },
    {
      "chainId": 1,
      "address": "0x80c8C3dCfB854f9542567c8Dac3f44D709eBc1de",
      "name": "Spaceswap MILK2",
      "symbol": "MILK2",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12771/large/milk.png?1633423719"
    },
    {
      "chainId": 1,
      "address": "0xaB37e1358b639Fd877f015027Bb62d3ddAa7557E",
      "name": "Lien",
      "symbol": "LIEN",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/12224/large/Lien.png?1598262819"
    },
    {
      "chainId": 1,
      "address": "0xbcD4b7dE6fde81025f74426D43165a5b0D790Fdd",
      "name": "SpiderDAO",
      "symbol": "SPDR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13378/large/spiderdao_logo.png?1608029180"
    },
    {
      "chainId": 1,
      "address": "0xA130E3a33a4d84b04c3918c4E5762223Ae252F80",
      "name": "Swash",
      "symbol": "SWASH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18774/large/swash.png?1634089759"
    },
    {
      "chainId": 1,
      "address": "0x33E07f5055173cF8FeBedE8B21B12D1e2b523205",
      "name": "Etherland",
      "symbol": "ELAND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14432/large/eland_logo.png?1678003898"
    },
    {
      "chainId": 1,
      "address": "0x20a68F9e34076b2dc15ce726d7eEbB83b694702d",
      "name": "DefiVille Island",
      "symbol": "ISLA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14471/large/256.png?1616384288"
    },
    {
      "chainId": 1,
      "address": "0x9aF15D7B8776fa296019979E70a5BE53c714A7ec",
      "name": "Evolution Finance",
      "symbol": "EVN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13932/large/Frame_63_2.png?1612936435"
    },
    {
      "chainId": 1,
      "address": "0x9f4909Cc95FB870BF48C128C1Fdbb5F482797632",
      "name": "Guzzler",
      "symbol": "GZLR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/20970/large/Screenshot-2021-11-27-at-22-57-22.png?1638153729"
    },
    {
      "chainId": 1,
      "address": "0xB5FE099475d3030DDe498c3BB6F3854F762A48Ad",
      "name": "Fnk com",
      "symbol": "FNK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13483/large/fnk.png?1609039834"
    },
    {
      "chainId": 1,
      "address": "0xc4De189Abf94c57f396bD4c52ab13b954FebEfD8",
      "name": "B20",
      "symbol": "B20",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13803/large/b20.png?1611996305"
    },
    {
      "chainId": 1,
      "address": "0x9AB7bb7FdC60f4357ECFef43986818A2A3569c62",
      "name": "Guild of Guardians",
      "symbol": "GOG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17362/large/V2QDNoLg_400x400.jpg?1640054187"
    },
    {
      "chainId": 1,
      "address": "0x5EeAA2DCb23056F4E8654a349E57eBE5e76b5e6e",
      "name": "Virtue Poker Points",
      "symbol": "VPP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3386/large/vp-logo-200x200.png?1622068750"
    },
    {
      "chainId": 1,
      "address": "0x9b6dB7597a74602a5A806E33408e7E2DAFa58193",
      "name": "Spice DAO",
      "symbol": "SPICE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21086/large/KfMQkToD_400x400.jpg?1638312662"
    },
    {
      "chainId": 1,
      "address": "0x0913dDAE242839f8995c0375493f9a1A3Bddc977",
      "name": "Marshall Inu",
      "symbol": "MRI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23784/large/mri.png?1647693409"
    },
    {
      "chainId": 1,
      "address": "0x34d31446a522252270b89b09016296ec4c98e23d",
      "name": "SAUDI SHIBA INU",
      "symbol": "SAUDISHIB",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/26708/large/FvmN7Wa.png?1659666550"
    },
    {
      "chainId": 1,
      "address": "0xCae72A7A0Fd9046cf6b165CA54c9e3a3872109E0",
      "name": "AnRKey X",
      "symbol": "ANRX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13415/large/anrkey.jpg?1608311301"
    },
    {
      "chainId": 1,
      "name": "Stater",
      "address": "0x84Bb947fcEdba6B9C7DCEad42dF07e113bb03007",
      "decimals": 18,
      "symbol": "STR",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/8909.png"
    },
    {
      "chainId": 1,
      "address": "0xb24cd494faE4C180A89975F1328Eab2a7D5d8f11",
      "name": "Developer DAO",
      "symbol": "CODE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/27011/large/CHWxD9GV_400x400.jpeg?1661421133"
    },
    {
      "chainId": 1,
      "address": "0xf680429328caaaCabee69b7A9FdB21a71419c063",
      "name": "Butterfly Protocol",
      "symbol": "BFLY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13882/large/ButterflyProtocolNoText_sm.png?1612492535"
    },
    {
      "chainId": 1,
      "address": "0xE0e05c43c097B0982Db6c9d626c4eb9e95C3b9ce",
      "name": "Unslashed Finance",
      "symbol": "USF",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14177/large/Unslashed.jpeg?1614793365"
    },
    {
      "chainId": 1,
      "address": "0x852e5427c86A3b46DD25e5FE027bb15f53c4BCb8",
      "name": "NiiFi",
      "symbol": "NIIFI",
      "decimals": 15,
      "logoURI": "https://assets.coingecko.com/coins/images/16033/large/niifi.PNG?1622674467"
    },
    {
      "chainId": 1,
      "address": "0x73374Ea518De7adDD4c2B624C0e8B113955ee041",
      "name": "Juggernaut",
      "symbol": "JGN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12761/large/juggernaut_logo.png?1602428976"
    },
    {
      "chainId": 1,
      "address": "0x38A2fDc11f526Ddd5a607C1F251C065f40fBF2f7",
      "name": "PhoenixDAO",
      "symbol": "PHNX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11523/large/Token_Icon.png?1618447147"
    },
    {
      "chainId": 1,
      "address": "0xF59ae934f6fe444afC309586cC60a84a0F89Aaea",
      "name": "Polkadex",
      "symbol": "PDEX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14833/large/dIze5Ztl_400x400.jpg?1618610724"
    },
    {
      "chainId": 1,
      "address": "0xE5B826Ca2Ca02F09c1725e9bd98d9a8874C30532",
      "name": "ZEON Network",
      "symbol": "ZEON",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/4247/large/XZqXYc2j_400x400.jpg?1547039580"
    },
    {
      "chainId": 1,
      "address": "0x558EC3152e2eb2174905cd19AeA4e34A23DE9aD6",
      "name": "Bread",
      "symbol": "BRD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/1440/large/bread.png?1547563238"
    },
    {
      "chainId": 1,
      "address": "0x6369c3DadfC00054A42BA8B2c09c48131dd4Aa38",
      "name": "Morpher",
      "symbol": "MPH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12619/large/morpher_200_200.png?1601524084"
    },
    {
      "chainId": 1,
      "address": "0xe5feeaC09D36B18b3FA757E5Cf3F8dA6B8e27F4C",
      "name": "NFT Index",
      "symbol": "NFTI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14215/large/nfti.png?1614992905"
    },
    {
      "chainId": 1,
      "address": "0x6e0daDE58D2d89eBBe7aFc384e3E4f15b70b14D8",
      "name": "QuiverX",
      "symbol": "QRX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12916/large/qrx_logo.png?1603550478"
    },
    {
      "chainId": 1,
      "address": "0x187Eff9690E1F1A61d578C7c492296eaAB82701a",
      "name": "Moar Finance",
      "symbol": "MOAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15057/large/moar.PNG?1619589388"
    },
    {
      "chainId": 1,
      "address": "0x1BeEF31946fbbb40B877a72E4ae04a8D1A5Cee06",
      "name": "Parachute",
      "symbol": "PAR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/7590/large/Parachute_Logo.png?1560918207"
    },
    {
      "chainId": 1,
      "address": "0x24A6A37576377F63f194Caa5F518a60f45b42921",
      "name": "Float Protocol",
      "symbol": "BANK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14116/large/FLOAT-Bank_LOGO-reduced_01.png?1616573606"
    },
    {
      "chainId": 1,
      "address": "0x543Ff227F64Aa17eA132Bf9886cAb5DB55DCAddf",
      "name": "DAOstack",
      "symbol": "GEN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3479/large/gen.png?1547038215"
    },
    {
      "chainId": 1,
      "address": "0x76c5449F4950f6338A393F53CdA8b53B0cd3Ca3a",
      "name": "BT Finance",
      "symbol": "BT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13824/large/BT-logo.324f553c.png?1612152632"
    },
    {
      "chainId": 1,
      "address": "0x06677Dc4fE12d3ba3C7CCfD0dF8Cd45e4D4095bF",
      "name": "Work Quest",
      "symbol": "WQT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/30040/large/JVAkGtGs_400x400.jpg?1682667670"
    },
    {
      "chainId": 1,
      "address": "0xEb57Bf569Ad976974C1F861a5923A59F40222451",
      "name": "Loomi",
      "symbol": "LOOMI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22919/large/C8miy1Qi_400x400.jpg?1643000828"
    },
    {
      "chainId": 1,
      "address": "0xa7DE087329BFcda5639247F96140f9DAbe3DeED1",
      "name": "Statera",
      "symbol": "STA",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11472/large/Statera.png?1590415353"
    },
    {
      "chainId": 1,
      "address": "0x358AA737e033F34df7c54306960a38d09AaBd523",
      "name": "Ares Protocol",
      "symbol": "ARES",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15153/large/Ares-logo.png?1620638611"
    },
    {
      "chainId": 1,
      "address": "0x159751323A9E0415DD3d6D42a1212fe9F4a0848C",
      "name": "Insured Finance",
      "symbol": "INFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13727/large/logo_%287%29.png?1611210296"
    },
    {
      "chainId": 1,
      "address": "0x10Be9a8dAe441d276a5027936c3aADEd2d82bC15",
      "name": "UniMex Network",
      "symbol": "UMX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13615/large/sloYxHx.jpeg?1633154340"
    },
    {
      "chainId": 1,
      "address": "0xBD2F0Cd039E0BFcf88901C98c0bFAc5ab27566e3",
      "name": "Dynamic Set Dollar",
      "symbol": "DSD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13249/large/DSD.jpg?1606713628"
    },
    {
      "chainId": 1,
      "address": "0x9E78b8274e1D6a76a0dBbf90418894DF27cBCEb5",
      "name": "Covenants",
      "symbol": "UNIFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12258/large/Unifi.png?1598548933"
    },
    {
      "chainId": 1,
      "address": "0xE6F1966d04CfcB9cd1B1dC4E8256D8b501b11CbA",
      "name": "SafeEarth",
      "symbol": "SAFEEARTH",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/15449/large/SafeEarthLogo2000.png?1620833647"
    },
    {
      "chainId": 1,
      "address": "0x4eED0fa8dE12D5a86517f214C2f11586Ba2ED88D",
      "name": "DragonBite",
      "symbol": "BITE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/16386/large/dragonbite.PNG?1623893567"
    },
    {
      "chainId": 1,
      "address": "0x6D0F5149c502faf215C89ab306ec3E50b15e2892",
      "name": "Portion",
      "symbol": "PRT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13617/large/OKeO2FI.png?1610327038"
    },
    {
      "chainId": 1,
      "address": "0xa150Db9b1Fa65b44799d4dD949D922c0a33Ee606",
      "name": "Digital Reserve Currency",
      "symbol": "DRC",
      "decimals": 0,
      "logoURI": "https://assets.coingecko.com/coins/images/12802/large/DRC_Logo.jpg?1654229818"
    },
    {
      "chainId": 1,
      "address": "0xFF75CEd57419bcaEBe5F05254983b013B0646eF5",
      "name": "Cook",
      "symbol": "COOK",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14603/large/logo-200x200.jpg?1622448330"
    },
    {
      "chainId": 1,
      "address": "0xB6ff96B8A8d214544Ca0dBc9B33f7AD6503eFD32",
      "name": "Sync Network",
      "symbol": "SYNC",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13231/large/sync_network.png?1629777103"
    },
    {
      "chainId": 1,
      "address": "0x4674a4F24C5f63D53F22490Fb3A08eAAAD739ff8",
      "name": "Brokoli",
      "symbol": "BRKL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18763/large/brkl.png?1633356263"
    },
    {
      "chainId": 1,
      "address": "0x7e794eD35788b698AE60cefC98eE48015C4876dA",
      "name": "Shintama",
      "symbol": "SHINTAMA",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/23405/large/shintama.png?1644145782"
    },
    {
      "chainId": 1,
      "address": "0x2F141Ce366a2462f02cEA3D12CF93E4DCa49e4Fd",
      "name": "FREEdom coin",
      "symbol": "FREE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/5585/large/free.png?1639547764"
    },
    {
      "chainId": 1,
      "address": "0x39795344CBCc76cC3Fb94B9D1b15C23c2070C66D",
      "name": "Seigniorage Shares",
      "symbol": "SHARE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/12306/large/logo_%281%29.png?1607658707"
    },
    {
      "chainId": 1,
      "address": "0xb6c4267C4877BB0D6b1685Cfd85b0FBe82F105ec",
      "name": "Relevant",
      "symbol": "REL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11586/large/Relevant.png?1591390081"
    },
    {
      "chainId": 1,
      "address": "0xb59490aB09A0f526Cc7305822aC65f2Ab12f9723",
      "name": "Litentry",
      "symbol": "LIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13825/large/logo_200x200.png?1612153317"
    },
    {
      "chainId": 1,
      "name": "Protectors of the Realm",
      "address": "0x2e6a8306286600E564c16Aa0b7A93fcED09D586A",
      "decimals": 9,
      "symbol": "WER1",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/22732.png"
    },
    {
      "chainId": 1,
      "address": "0x706f280Cdb92260fe2D50EDA545F834ff1fbFd35",
      "name": "Rabbit2023",
      "symbol": "RABBIT",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28476/large/200.png?1671003986"
    },
    {
      "chainId": 1,
      "address": "0x8185Bc4757572Da2a610f887561c32298f1A5748",
      "name": "Aluna",
      "symbol": "ALN",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14379/large/uaLoLU8c_400x400_%281%29.png?1627873106"
    },
    {
      "chainId": 1,
      "address": "0xa1817B6d8D890F3943b61648992730373B71f156",
      "name": "Mongoose",
      "symbol": "MONGOOSE",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/21456/large/61b142508fba4235f29d57eb_Frame_24_%281%29.png?1639291023"
    },
    {
      "chainId": 1,
      "name": "Flow Protocol",
      "address": "0xC6e64729931f60D2c8Bc70A27D66D9E0c28D1BF9",
      "decimals": 9,
      "symbol": "FLOW",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/6768.png"
    },
    {
      "chainId": 1,
      "address": "0x3E5D9D8a63CC8a88748f229999CF59487e90721e",
      "name": "MetalSwap",
      "symbol": "XMT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/22075/large/Logo_COIN_-_Gradiente.png?1670579810"
    },
    {
      "chainId": 1,
      "address": "0x67B66C99D3Eb37Fa76Aa3Ed1ff33E8e39F0b9c7A",
      "name": "Interest Bearing ETH",
      "symbol": "IBETH",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13131/large/7675.png?1605535879"
    },
    {
      "chainId": 1,
      "name": "hybrix",
      "address": "0x9b53E429B0baDd98ef7F01F03702986c516a5715",
      "decimals": 18,
      "symbol": "HY",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/6261.png"
    },
    {
      "chainId": 1,
      "name": "BlockSwap Network",
      "address": "0x7d4B1d793239707445305D8d2456D2c735F6B25B",
      "decimals": 18,
      "symbol": "CBSN",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/9418.png"
    },
    {
      "chainId": 1,
      "address": "0xAF691508BA57d416f895e32a1616dA1024e882D2",
      "name": "Pinknode",
      "symbol": "PNODE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15469/large/icon-Logo-pink.png?1644476523"
    },
    {
      "chainId": 1,
      "address": "0xC32cC5b70BEe4bd54Aa62B9Aefb91346d18821C4",
      "name": "Iteration Syndicate",
      "symbol": "ITS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13297/large/1_LOssD4ENHv72I5e9PAsndA_%281%29.png?1607223580"
    },
    {
      "chainId": 1,
      "address": "0xF921ae2DAC5fa128DC0F6168Bf153ea0943d2D43",
      "name": "Fire Protocol",
      "symbol": "FIRE",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/13495/large/fire.jpg?1609165121"
    },
    {
      "chainId": 1,
      "address": "0x62Dc4817588d53a056cBbD18231d91ffCcd34b2A",
      "name": "DeHive",
      "symbol": "DHV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14926/large/logo_200x200.png?1626181831"
    },
    {
      "chainId": 1,
      "address": "0x4730fB1463A6F1F44AEB45F6c5c422427f37F4D0",
      "name": "4thpillar technologies",
      "symbol": "FOUR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/3434/large/four-ticker-2021-256x256.png?1617702287"
    },
    {
      "chainId": 1,
      "address": "0x24E3794605C84E580EEA4972738D633E8a7127c8",
      "name": "Katalyo",
      "symbol": "KTLYO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13347/large/katalyo_logo_aqua_256.png?1607762430"
    },
    {
      "chainId": 1,
      "address": "0xB2dbF14D0b47ED3Ba02bDb7C954e05A72deB7544",
      "name": "MobiFi",
      "symbol": "MOFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14697/large/MOFI_Coin_Green_200x200.png?1634024056"
    },
    {
      "chainId": 1,
      "address": "0x2AF5D2aD76741191D15Dfe7bF6aC92d4Bd912Ca3",
      "name": "LEO Token",
      "symbol": "LEO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/8418/large/leo-token.png?1558326215"
    },
    {
      "chainId": 1,
      "address": "0xE74dC43867E0cbEB208F1a012fc60DcBbF0E3044",
      "name": "DeFIRE",
      "symbol": "CWAP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15722/large/defire.PNG?1621635373"
    },
    {
      "chainId": 1,
      "address": "0xAc0C8dA4A4748d8d821A0973d00b157aA78C473D",
      "name": "YFIONE",
      "symbol": "YFO",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13670/large/256.png?1610676054"
    },
    {
      "chainId": 1,
      "address": "0x14Da7b27b2E0FedEfe0a664118b0c9bc68e2E9AF",
      "name": "Blockchain Cuties Universe Governance",
      "symbol": "BCUG",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14425/large/bcug_logo.png?1616022820"
    },
    {
      "chainId": 1,
      "address": "0x2F4404C4012476929b6503E1397707480bf23B7f",
      "name": "AITravis",
      "symbol": "TAI",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/28933/large/ava_%283%29.png?1675500690"
    },
    {
      "chainId": 1,
      "address": "0xa0bEd124a09ac2Bd941b10349d8d224fe3c955eb",
      "name": "DePay",
      "symbol": "DEPAY",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13183/large/DEPAY.png?1650615816"
    },
    {
      "chainId": 1,
      "address": "0x9040e237C3bF18347bb00957Dc22167D0f2b999d",
      "name": "Standard Protocol",
      "symbol": "STND",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15100/large/STND_logo_black_bg.png?1677657688"
    },
    {
      "chainId": 1,
      "address": "0xB8BAa0e4287890a5F79863aB62b7F175ceCbD433",
      "name": "Swerve",
      "symbol": "SWRV",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12361/large/swerve.png?1599278316"
    },
    {
      "chainId": 1,
      "address": "0x35156b404C3f9bdaf45ab65Ba315419bcDe3775c",
      "name": "Chihiro Inu",
      "symbol": "CHIRO",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/19721/large/chiro200x200.png?1642166355"
    },
    {
      "chainId": 1,
      "address": "0xfe9A29aB92522D14Fc65880d817214261D8479AE",
      "name": "Snowswap",
      "symbol": "SNOW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12751/large/uQBJL3A.png?1602237225"
    },
    {
      "chainId": 1,
      "address": "0x5Eaa69B29f99C84Fe5dE8200340b4e9b4Ab38EaC",
      "name": "Raze Network",
      "symbol": "RAZE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14767/large/logo-2.png?1623867120"
    },
    {
      "chainId": 1,
      "address": "0x4CD0c43B0D53bc318cc5342b77EB6f124E47f526",
      "name": "FreeRossDAO",
      "symbol": "FREE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/21648/large/free.jpg?1639639586"
    },
    {
      "chainId": 1,
      "address": "0xB1e9157c2Fdcc5a856C8DA8b2d89b6C32b3c1229",
      "name": "Zenfuse",
      "symbol": "ZEFU",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12796/large/zenfuse.jpg?1602640333"
    },
    {
      "chainId": 1,
      "address": "0xdF5e0e81Dff6FAF3A7e52BA697820c5e32D806A8",
      "name": "LP yCurve",
      "symbol": "YCURVE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11858/large/yCrv.png?1595203628"
    },
    {
      "chainId": 1,
      "address": "0xf91AC30E9b517f6D57e99446ee44894e6C22C032",
      "name": "LOL",
      "symbol": "LOL",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/20354/large/lollogo.png?1648442855"
    },
    {
      "chainId": 1,
      "address": "0x0275E1001e293C46CFe158B3702AADe0B99f88a5",
      "name": "Oiler",
      "symbol": "OIL",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15249/large/oiler.png?1620237607"
    },
    {
      "chainId": 1,
      "address": "0x39AA39c021dfbaE8faC545936693aC917d5E7563",
      "name": "cUSDC",
      "symbol": "CUSDC",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/9442/large/Compound_USDC.png?1567581577"
    },
    {
      "chainId": 1,
      "address": "0x6F87D756DAf0503d08Eb8993686c7Fc01Dc44fB1",
      "name": "Unitrade",
      "symbol": "TRADE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/11982/large/unitrade.PNG?1597009487"
    },
    {
      "chainId": 1,
      "address": "0x939A7A577D93ad29B64C1595B1284ce660A479B9",
      "name": "Jejudoge",
      "symbol": "JEJUDOGE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/15983/large/jejudoge.png?1634782252"
    },
    {
      "chainId": 1,
      "name": "McDoge",
      "address": "0x5FDFE5ee55AE0fB7E0dba3481EA46f22fC92cBbB",
      "decimals": 9,
      "symbol": "MCDOGE",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/17646.png"
    },
    {
      "chainId": 1,
      "address": "0xc666081073E8DfF8D3d1c2292A29aE1A2153eC09",
      "name": "Digitex",
      "symbol": "DGTX",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/2188/large/DGTX.png?1616385887"
    },
    {
      "chainId": 1,
      "address": "0x79126d32a86e6663F3aAac4527732d0701c1AE6c",
      "name": "Dark Matter",
      "symbol": "DMT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14223/large/dmt.jpg?1615089067"
    },
    {
      "chainId": 1,
      "address": "0x67c597624B17b16fb77959217360B7cD18284253",
      "name": "Benchmark Protocol",
      "symbol": "MARK",
      "decimals": 9,
      "logoURI": "https://assets.coingecko.com/coins/images/13212/large/benchmark_protocol.jpg?1606267583"
    },
    {
      "chainId": 1,
      "address": "0x1712Aad2C773ee04bdC9114b32163c058321CD85",
      "name": "LimitSwap",
      "symbol": "LIMIT",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12760/large/limit_swap_logo.png?1602347106"
    },
    {
      "chainId": 1,
      "address": "0x4332f8A38f14BD3D8D1553aF27D7c7Ac6C27278D",
      "name": "Ape Finance",
      "symbol": "APEFI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/25625/large/APEFI.png?1652857977"
    },
    {
      "chainId": 1,
      "address": "0x8eB1779A32678452eB273A22d413207299904d90",
      "name": "Pochi Inu",
      "symbol": "POCHI",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/23816/large/logo-gold.png?1645513711"
    },
    {
      "chainId": 1,
      "address": "0x9C78EE466D6Cb57A4d01Fd887D2b5dFb2D46288f",
      "name": "Must",
      "symbol": "MUST",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/13688/large/must_logo.png?1610949645"
    },
    {
      "chainId": 1,
      "address": "0xC237868a9c5729bdF3173dDDacaa336a0a5BB6e0",
      "name": "Wagerr",
      "symbol": "WGR",
      "decimals": 8,
      "logoURI": "https://assets.coingecko.com/coins/images/759/large/syGKmAT.png?1619597241"
    },
    {
      "chainId": 1,
      "name": "Grain",
      "address": "0x6589fe1271A0F29346796C6bAf0cdF619e25e58e",
      "decimals": 18,
      "symbol": "GRAIN",
      "logoURI": "https://s2.coinmarketcap.com/static/img/coins/64x64/7940.png"
    },
    {
      "chainId": 1,
      "address": "0xfffffffFf15AbF397dA76f1dcc1A1604F45126DB",
      "name": "Falconswap",
      "symbol": "FSW",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12256/large/falconswap.png?1598534184"
    },
    {
      "chainId": 1,
      "address": "0x9C4A4204B79dd291D6b6571C5BE8BbcD0622F050",
      "name": "Tracer DAO",
      "symbol": "TCR",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18271/large/tracer_logo.png?1631176676"
    },
    {
      "chainId": 1,
      "address": "0x05D3606d5c81EB9b7B18530995eC9B29da05FaBa",
      "name": "TomoChain ERC 20",
      "symbol": "TOMOE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/12646/large/tomoe_logo.png?1601377449"
    },
    {
      "chainId": 1,
      "address": "0x65a8fbA02F641a13Bb7B01d5E1129b0521004f52",
      "name": "Amasa",
      "symbol": "AMAS",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18799/large/agmqWjv8_400x400.png?1633473272"
    },
    {
      "chainId": 1,
      "address": "0x727f064A78DC734D33eEc18d5370aef32Ffd46e4",
      "name": "Orion Money",
      "symbol": "ORION",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/18630/large/YtrqPIWc.png?1632710781"
    },
    {
      "chainId": 1,
      "address": "0x84bA4aEcfDe39D69686a841BAb434C32d179a169",
      "name": "Method Finance",
      "symbol": "MTHD",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/14619/large/mthd.PNG?1617262620"
    },
    {
      "chainId": 1,
      "address": "0x6911F552842236bd9E8ea8DDBB3fb414e2C5FA9d",
      "name": "Synapse Network",
      "symbol": "SNP",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/17962/large/Webp-net-resizeimage_%282%29.png?1629943450"
    },
    {
      "chainId": 1,
      "address": "0x6982508145454Ce325dDbE47a25d4ec3d2311933",
      "name": "Pepe",
      "symbol": "PEPE",
      "decimals": 18,
      "logoURI": "https://assets.coingecko.com/coins/images/29850/large/pepe-token.jpeg?1682922725"
    },
    {
        "chainId": 1,
        "address": "0x1c4ed1f3d87e5a6100cffd37b2a4e739f5b6bdd9",
        "name": "ETH",
        "symbol": "ETH",
        "decimals": 18,
        "logoURI": ""
    }
  ]

  export default uniswapTokens
