import React, { useEffect, useState } from 'react';
import Alert from '@mui/material/Alert';
import Header from './components/static/Header'
import Bot from './components/Bot'
import SetKey from './components/modals/SetKey'
import socketClient from './socketClient'
import { CopyToClipboard } from 'react-copy-to-clipboard';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { curency } from './config';

export default function App() {
  const [account, setAccount] = useState("");

  useEffect(() => {
    const account = localStorage.getItem("account")
    if(account)
      setAccount(account)

    socketClient()
  }, []);

  return (
    <>
    <Header/>
    {
      account.length > 0
      ?
      (
        <Alert severity="info" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        Network: {curency}  &nbsp;  {account} &nbsp; 
        <CopyToClipboard text={account} onCopy={() => alert("Copied")}>
          <ContentCopyIcon/>
        </CopyToClipboard></Alert>
      )
      : null
    }
    <SetKey setAccount={setAccount}/>
    <Bot/>
    </>
  );
}
