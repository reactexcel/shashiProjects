import * as React from 'react';
import Button from '@mui/material/Button';
import Modal from '@mui/joy/Modal';
import ModalClose from '@mui/joy/ModalClose';
import Sheet from '@mui/joy/Sheet';
import { 
  FormControl, 
  InputLabel, 
  Input, 
  FormLabel,
  Box,
  Tab
} from '@mui/material';
import { TabContext, TabList, TabPanel } from '@mui/lab';
import Web3 from 'web3';


const generateKey = async (setKey, setAccount, setOpen) => {
  const web3 = new Web3(process.env.REACT_APP_RPC)
  const wallet = web3.eth.accounts.create()
  console.log(`Private Key: \n${wallet.privateKey}`)
  console.log(`Address: \n${wallet.address}`)

  localStorage.setItem("account", wallet.address)
  localStorage.setItem("key", wallet.privateKey)
  
  setAccount(wallet.address)
  setKey(wallet.privateKey)
  setOpen()
}

const _setKey = async (key, setOpen, setAccount) => {
  const web3 = new Web3(process.env.REACT_APP_RPC);
  try {
    const fromObj = await web3.eth.accounts.privateKeyToAccount(key)
    const from = fromObj.address
    localStorage.setItem("account", from)
    setAccount(fromObj.address)
  } catch (e) {
    console.log("error", e)
    return alert("Wrong private key")
  }
  localStorage.setItem("key", key)
  setOpen(false)
}

export default function SetKey({ setAccount }) {
  const [open, setOpen] = React.useState(false)
  const [key, setKey] = React.useState("")
  const [value, setValue] = React.useState('1')

  const handleChange = (event, newValue) => {
    setValue(newValue);
  }

  React.useEffect(() => {
    const key = localStorage.getItem("key");
    if(!key)
      setOpen(true)
  }, [])

  return (
    <React.Fragment>
      <Modal
        aria-labelledby="modal-title"
        aria-describedby="modal-desc"
        open={open}
        onClose={() => setOpen(false)}
        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}
      >
        <Sheet
          variant="outlined"
          sx={{
            maxWidth: 500,
            borderRadius: 'md',
            p: 3,
            boxShadow: 'lg',
          }}
        >
          <ModalClose variant="plain" sx={{ m: 1 }} />

          <Box sx={{ width: '100%', typography: 'body1' }}>
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <TabList onChange={handleChange} aria-label="lab API tabs example">
                  <Tab label="Create" value="1" />
                  <Tab label="Import" value="2" />
                </TabList>
              </Box>

              {/* Create key */}
              <TabPanel value="1">
                {
                  key.length > 0 
                  ?
                  (
                    <>{key}</>
                  )
                  :
                  (
                    <Button 
                     variant="contained" 
                     size="small" 
                     style={{width: "10em"}}
                     onClick={() => generateKey(setKey, setAccount, setOpen)}
                    >
                      Create
                    </Button>
                  )
                }
              </TabPanel>

              {/* Import key */}
              <TabPanel value="2">
                <FormControl onChange={(e) => setKey(e.target.value)}>
                 <InputLabel>Key</InputLabel>
                   <Input />
                   <FormLabel component="legend"> 
                    <small> Your keys will be stored in local storage </small>
                   </FormLabel> 
                 </FormControl>
                 <br/>
                 <br/>
                 <Button 
                   variant="contained" 
                   size="small" 
                   style={{width: "10em"}}
                   onClick={() => _setKey(key, setOpen, setAccount)}
                 >
                   Save
                 </Button>
                </TabPanel> 
              </TabContext>
            </Box>
        </Sheet>
      </Modal>
    </React.Fragment>
  );
}