import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import Swap from './modals/Swap';
import Snipe from './modals/Snipe';
import Signals from './modals/Signals';
import Settings from './modals/Settings';
import Names from './modals/Names';
import Send from './modals/Send';
import { scanURI } from '../config';

export default function Bot() {
  const [account, setAccount] = useState("");

  useEffect(() => {
    const account = localStorage.getItem("account")
    if(account)
      setAccount(account)
  }, []);

  return (
    <>
    <Container maxWidth="sm" style={{ marginTop: "20px" }}>
    <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={1}>
        <Grid item xs={4}>
         <Swap/>
        </Grid>
        <Grid item xs={4}>
         <Send/>
        </Grid>
        <Grid item xs={4}>
          <Button 
            variant="contained" 
            size="small" 
            style={{width: "10em"}} 
            onClick={() => {
              window.open(`${scanURI}/address/${account}`, "_blank")
            }}
           >
            Scan
          </Button>
        </Grid>
      </Grid>
      </Box>

      <br/>

      <Box sx={{ flexGrow: 1 }}>
      <Grid container spacing={1}>
        <Grid item xs={4}>
          <Signals/>
        </Grid>
        <Grid item xs={4}>
          <Names/>
        </Grid>
        <Grid item xs={4}>
          <Snipe/>
        </Grid>
      </Grid>

      <br/>

      <Grid container spacing={1}>
        <Grid item xs={4}>
         <Button variant="contained" size="small" style={{width: "10em"}} disabled>Buy limit</Button>
        </Grid>
        <Grid item xs={4}>
         <Button variant="contained" size="small" style={{width: "10em"}} disabled>Sell limit</Button>
        </Grid>
        <Grid item xs={4}>
         <Settings/>
        </Grid>
      </Grid>
    </Box>
    </Container>
    </>
  );
}
