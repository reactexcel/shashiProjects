import { CHAINID } from '../config'
import signTx from "./signTx"
import Web3 from 'web3'
import ERC20_ABI from '../abi/ERC20_ABI'

const web3 = new Web3(process.env.REACT_APP_RPC);
const gas = 500000

const createTx = async (from, value, gasPrice, token, to) => {
  const contract = new web3.eth.Contract(ERC20_ABI, token)

  const data = contract.methods.transfer(to, value).encodeABI({from})

  const nonce = await web3.eth.getTransactionCount(from)
  const tx = {
    from,
    to,
    value:0,
    gasPrice,
    data,
    gas,
    "chainId": CHAINID,
    nonce: nonce
  }

  return tx
}


const sendERC20 = async (key, value, gasPrice, token, to) => {
  const accountObj = await web3.eth.accounts.privateKeyToAccount(key)
  const account = accountObj.address
  console.log("account", account)
  const tx = await createTx(account, value, gasPrice, token, to)
  const hash = await signTx(tx, key)
  console.log("send ETH hash : ", hash)
  return hash
}

export default sendERC20 
