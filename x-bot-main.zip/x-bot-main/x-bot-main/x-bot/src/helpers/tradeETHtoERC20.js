import UNISWAP_V2_ROUTER_ABI from '../abi/UNISWAP_V2_ROUTER_ABI'
import { 
    UNISWAP_V2_ROUTER, 
    CHAINID,
    WETH 
} from '../config'
import signTx from "./signTx"
import Web3 from 'web3'

const web3 = new Web3(process.env.REACT_APP_RPC);
const gas = 500000

// create buy transaction
// params: from - user account, value - bnb amount
// return prepared for sign transaction
const createTx = async (from, value, minReturn, gasPrice, token) => {
  const contract = new web3.eth.Contract(UNISWAP_V2_ROUTER_ABI, UNISWAP_V2_ROUTER)
  const data = contract.methods.swapExactETHForTokens(
    minReturn,
    [WETH, token],
    from,
    "111111111111111111"
  ).encodeABI({from})

  const nonce = await web3.eth.getTransactionCount(from)

  const tx = {
    from,
    to: UNISWAP_V2_ROUTER,
    value,
    data,
    gasPrice,
    gas,
    "chainId": CHAINID,
    nonce: nonce
  }

  return tx
}

// bot buy token by eth(bnb) amount
// params: private key index, eth(bnb) amount
const tradeETHtoERC20 = async (key, value, minReturn, gasPrice, token) => {
  const accountObj = await web3.eth.accounts.privateKeyToAccount(key)
  const account = accountObj.address
  console.log("account", account)
  const tx = await createTx(account, value, minReturn, gasPrice, token)
  const hash = await signTx(tx, key)
  console.log("ETH to ERC20 hash : ", hash)
  return hash
}

export default tradeETHtoERC20
