# VectorML Frontend (React App - Django backend - Postgres Database)

## Frontend Features

- React 17
- Prettier
- Airbnb Coding style Guide
- React Router
- Redux
- Styled Component
- Material UI
- ES2017

## Requirements

- [Node v14.14](https://nodejs.org/en/download/current/)
- [yarn](https://www.yarnpkg.com/)

## Getting Started

Install Dependencies

```bash
yarn
```

## Running Project

```bash
yarn start
```
