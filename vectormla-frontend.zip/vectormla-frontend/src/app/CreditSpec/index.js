import CreditSpec from './CreditSpec';

export default CreditSpec;
