import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Grid, Divider, CircularProgress } from '@material-ui/core';
import { useStyles } from './creditSpecStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import MainTable from '../components/Table/MainTable';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import Portfolio from '../components/portfolio/Portfolio';
import Chart from '../components/Chart/PrePaymentChart';
import { startTimer } from '../store/actions/timer.action';
import { useComponentSize } from 'react-use-size';
import {
	createPortfolio,
	getPortfolios,
	getPortfolioDetails,
	deletePortfolio,
	updatePortfolio,
	downloadCredit2Template,
	downloadCredit2Data
} from '../store/actions/credit.action';
import { GET_CREDIT_RISK_2_TABLES_CLEAN } from '../store/types/credit.type';

const CreditRiskV2 = ({ collapsed }) => {
	const dispatch = useDispatch();
	const classes = useStyles();
	const [chartVisible, setChartVisible] = useState({
		'Charts Table 36': false,
		'Charts Table 60': false
	});
	const { tables2, portfolios2, seconds, minutes, status } = useSelector(
		(state) => state.credit
	);

	const user = useSelector((state) => state.auth.user);
	const { ref: creditSpecRef, height: creditSpecHeight } = useComponentSize();

	const [selectedPortfolio, setSelectedPortfolio] = useState(null);
	const tableHeaders = [
		// { 'ML Model': 'ml_model' },
		// { Scorecard: 'scorecard' },
		{ 'Table Default 36': 'table_default_36' },
		{ 'Table El 36': 'table_el_36' },
		{ 'Table Default 60': 'table_default_60' },
		{ 'Table El 60': 'table_el_60' }
	];
	const [state, setState] = useState({
		openChartsCash36: [
			'Cumulativing Timing Curve',
			'Default Curve',
			'Expected Loss Curve',
			'Timing Curve',
			'Timing Curve with Recovery'
		],
		openChartsCash60: [
			'Cumulativing Timing Curve',
			'Default Curve',
			'Expected Loss Curve',
			'Timing Curve',
			'Timing Curve with Recovery'
		]
	});
	const [chartsData, setChartsData] = useState([
		{
			ch: [],
			xIndex: 'Period',
			yIndex: 'Cumulativing Timing Curve',
			xDistance: 390,
			format: 'com'
		}
	]);

	const [chartsData2, setChartsData2] = useState([
		{
			ch: [],
			xIndex: 'Period',
			yIndex: 'Cumulativing Timing Curve',
			xDistance: 390,
			format: 'com'
		}
	]);

	useEffect(() => {
		if (!portfolios2 && user?.allowed_pages?.includes(1)) fetchPortfolio();
		if (portfolios2 && !selectedPortfolio) setSelectedPortfolio(portfolios2[0]);
		return () => {
			portfolios2 && dispatch({ type: GET_CREDIT_RISK_2_TABLES_CLEAN });
		};
	}, [portfolios2, user]);

	useEffect(() => {
		if (status === 'SUCCESS') {
			updateTables(selectedPortfolio[0]?.id);
		}
	}, [status]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible({
				'Charts Table 36': true,
				'Charts Table 60': true
			});
		} else if (
			collapsed === 0 &&
			chartVisible['Charts Table 36'] &&
			chartVisible['Charts Table 60']
		) {
			setChartVisible({
				'Charts Table 36': false,
				'Charts Table 60': false
			});
		} else if (collapsed === 0 && chartVisible['Charts Table 36']) {
			setChartVisible({ ...chartVisible, ['Charts Table 36']: false });
		} else if (collapsed === 0 && chartVisible['Charts Table 60']) {
			setChartVisible({ ...chartVisible, ['Charts Table 60']: false });
		}
	}, [collapsed]);

	useEffect(() => {
		return () => {
			dispatch({ type: GET_CREDIT_RISK_2_TABLES_CLEAN });
		};
	}, []);

	const fetchPortfolio = () => {
		dispatch(
			getPortfolios((res) => {
				res[0].id && setSelectedPortfolio(res[0]);
				res[0]?.id &&
					dispatch(
						getPortfolioDetails(res[0]?.id, 'charts', (data) => {
							handleCharts36(data);
							handleCharts60(data);
						})
					);
			})
		);
	};

	const handleCharts36 = (res) => {
		let chart1Credit2_1 =
			Object.keys(res).length > 0
				? res['chart_36']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Cumulativing Timing Curve':
							res['chart_36']['Cumulativing Timing Curve'][i]
				  }))
				: [];
		let chart1Credit2_2 =
			Object.keys(res).length > 0
				? res['chart_36']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Default Curve': res['chart_36']['Default Curve'][i]
				  }))
				: [];
		let chart1Credit2_3 =
			Object.keys(res).length > 0
				? res['chart_36']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Expected Loss Curve': res['chart_36']['Expected Loss Curve'][i]
				  }))
				: [];
		let chart1Credit2_4 =
			Object.keys(res).length > 0
				? res['chart_36']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Timing Curve': res['chart_36']['Timing Curve'][i]
				  }))
				: [];
		let chart1Credit2_5 =
			Object.keys(res).length > 0
				? res['chart_36']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Timing Curve with Recovery':
							res['chart_36']['Timing Curve with Recovery'][i]
				  }))
				: [];
		let chartsCredit2 = [
			{
				ch: chart1Credit2_1,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_2,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_3,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_4,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_5,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			}
		];
		setChartsData(chartsCredit2);
	};

	const handleCharts60 = (res) => {
		let chart1Credit2_1 =
			Object.keys(res).length > 0
				? res['chart_60']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Cumulativing Timing Curve':
							res['chart_60']['Cumulativing Timing Curve'][i]
				  }))
				: [];
		let chart1Credit2_2 =
			Object.keys(res).length > 0
				? res['chart_60']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Default Curve': res['chart_60']['Default Curve'][i]
				  }))
				: [];
		let chart1Credit2_3 =
			Object.keys(res).length > 0
				? res['chart_60']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Expected Loss Curve': res['chart_60']['Expected Loss Curve'][i]
				  }))
				: [];
		let chart1Credit2_4 =
			Object.keys(res).length > 0
				? res['chart_60']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Timing Curve': res['chart_60']['Timing Curve'][i]
				  }))
				: [];
		let chart1Credit2_5 =
			Object.keys(res).length > 0
				? res['chart_60']?.Period.map((val1, i) => ({
						['Period']: val1,
						'Timing Curve with Recovery':
							res['chart_60']['Timing Curve with Recovery'][i]
				  }))
				: [];
		let chartsCredit2 = [
			{
				ch: chart1Credit2_1,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_2,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_3,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_4,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			},
			{
				ch: chart1Credit2_5,
				xIndex: 'Period',
				xDistance: 380,
				format: 'per'
			}
		];
		setChartsData2(chartsCredit2);
	};

	const fetchPortfolioDetails = (model, type) => {
		if (!model) return;
		dispatch(getPortfolioDetails(model, type));
		model &&
			dispatch(
				getPortfolioDetails(model, 'charts', (data) => {
					handleCharts36(data);
					handleCharts60(data);
				})
			);
	};

	const updateTables = (id) => {
		// if (!tables2) return;
		fetchPortfolioDetails(id, 'scorecard');
		fetchPortfolioDetails(id, 'mlmodel');
		fetchPortfolioDetails(id, 'tables');
	};
	const fetchSecondParams = (tableName) => {
		if (tableName === 'ml_model') return 'mlmodel';
		else if (tableName === 'scorecard') return 'scorecard';
		else return 'tables';
	};
	const renderTable = (tableHeaders, tableData) => {
		return tableHeaders.map((tableName, index) => {
			let ObKey = Object.keys(tableName)[0];
			let ObValue = Object.values(tableName)[0];
			return (
				<>
					{['ML Model'].includes(tableName) ? (
						<>
							<div
								style={{
									marginTop: tableName === 'Balance Sheet ' ? 20 : 30
								}}
							></div>
							<hr />
							<div style={{ marginTop: 20 }}></div>
						</>
					) : (
						''
					)}
					<MainTable
						header={tableData && tableData[ObValue]?.columns}
						data={tableData && tableData[ObValue]?.data}
						attributes={
							tableData &&
							tableData[ObValue] &&
							Object.keys(tableData[ObValue]?.data[0])
						}
						tableId={index}
						key={index}
						tableName={ObKey}
						fetchData={() => {
							fetchPortfolioDetails(
								selectedPortfolio?.id,
								fetchSecondParams(ObValue)
							);
						}}
						collapsed={collapsed}
						download
					/>
				</>
			);
		});
	};

	const renderChart = (dataMap, chartName, periodType) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() =>
						setChartVisible({
							...chartVisible,
							[`${chartName}`]: !chartVisible[chartName]
						})
					}
				>
					<p className={classes.contentHeader}>{chartName}</p>
				</div>
				{chartVisible[chartName] &&
					(chartsData[0]?.ch && chartsData[0]?.ch.length > 0 ? (
						<div className={classes.cashflow__chart}>
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
								style={{ position: 'relative', maxWidth: 1900 }}
							>
								{dataMap.map((item, index) => {
									return (
										<Grid
											key={index}
											item
											xs={12}
											sm={12}
											md={4}
											className={classes.container__chart}
										>
											{periodType === 'chart36'
												? chartsData[index]?.ch &&
												  chartsData[index]?.ch.length > 0 && (
														<Chart
															dataT={chartsData[index].ch}
															nameLegend={`${item}`}
															sizeLegend="14px"
															brushID={`${item}`}
															value={`${item}`}
															dataX={chartsData[index].xIndex}
															xDistance={chartsData[index].xDistance}
															format={chartsData[index].format}
															interval={3}
														/>
												  )
												: chartsData2[index]?.ch &&
												  chartsData2[index]?.ch.length > 0 && (
														<Chart
															dataT={chartsData2[index].ch}
															nameLegend={`${item}`}
															sizeLegend="14px"
															brushID={`${item}`}
															value={`${item}`}
															dataX={chartsData2[index].xIndex}
															xDistance={chartsData2[index].xDistance}
															format={chartsData2[index].format}
															interval={3}
														/>
												  )}
										</Grid>
									);
								})}
							</Grid>
						</div>
					) : (
						<div style={{ width: '100%', textAlign: 'center' }}>
							<CircularProgress style={{ color: '#266696' }} size={26} />
						</div>
					))}
			</div>
		);
	};
	if (
		!user?.allowed_pages?.includes(2) ||
		!user?.allowed_section2.includes(202)
	)
		return <div></div>;
	return (
		<div ref={creditSpecRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={creditSpecHeight} />
			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'credit2'}
							port={selectedPortfolio?.id}
							loading={status === 'pending'}
							key={174}
							portfolioList={portfolios2 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios2.filter((item) => item.id == val)[0]
								);
								updateTables(val);
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(
										name,
										user?.company_id,
										file,
										(res) => {
											dispatch(startTimer('credit2', res.data.id));
											fetchPortfolio();
										},
										'CREDIT_RISK_2'
									)
								);
							}}
							update={(name, callback) => {
								dispatch(
									updatePortfolio(selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										callback();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio(selectedPortfolio?.id, () => {
										fetchPortfolio();
										dispatch({ type: GET_CREDIT_RISK_2_TABLES_CLEAN });
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('credit2', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(
										selectedPortfolio?.id,
										formData,
										() => {
											updateTables();
										},
										'CREDIT_RISK_2'
									)
								);
							}}
							downloadFile={() => {
								downloadCredit2Data(selectedPortfolio?.id);
							}}
							downloadTemplate={() => {
								dispatch(downloadCredit2Template());
							}}
							seconds={seconds}
							status={status}
							minutes={minutes}
							collapsed={collapsed}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{renderTable(tableHeaders, tables2)}
						{renderChart(state.openChartsCash36, 'Charts Table 36', 'chart36')}
						{renderChart(state.openChartsCash60, 'Charts Table 60', 'chart60')}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default CreditRiskV2;
