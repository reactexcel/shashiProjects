import React, { useEffect, useState } from 'react';
import moment from 'moment';
import { useComponentSize } from 'react-use-size';
import { Grid, Button } from '@material-ui/core';
import SweetAlert from '../components/SweetAlert/SweetAlert';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import ContentTable from '../../common/components/table/ContentTable';
import PanelModal from '../../common/components/fields/PanelModal';
import { fields } from './createFields';
import { useStyles } from './companySettingStyles';
import {
	getUsers,
	getTwoFactorList,
	createUser,
	updateUserData,
	deleteUser,
	resetUserPass
} from '../services/adminService';

const CompanySetting = () => {
	const { ref: adminRef, height: adminHeight } = useComponentSize();

	const classes = useStyles();
	const [open, setOpen] = useState(false);
	const [confirm, setConfirm] = useState(false);
	const [selectedUser, setSelectedUser] = useState({});
	const [modalState, setModalState] = useState('new');
	const [users, setUsers] = useState(null);
	const [factorList, setFactorList] = useState(null);
	const handleClickOpen = () => {
		setModalState('new');
		setOpen(true);
	};

	const handleClose = () => {
		getUsers((res) => {
			setUsers(res);
		});
		setOpen(false);
	};

	const openSweetAlert = (clickedUserID) => {
		setSelectedUser(users.filter((user) => user.id === clickedUserID)[0]);
		setConfirm(true);
	};

	const handleDelete = () => {
		deleteUser(selectedUser.id, () => {
			setConfirm(false);
			getUsers((res) => setUsers(res));
		});
	};

	const handleResetPass = (clickedUserID) => {
		resetUserPass(clickedUserID);
	};

	const handleEdit = (clickedUserID) => {
		setModalState('edit');
		setSelectedUser(users.filter((user) => user.id === clickedUserID)[0]);
		setOpen(true);
	};

	useEffect(() => {
		if (!users) getUsers((res) => setUsers(res));
	}, [users]);

	useEffect(() => {
		if (!factorList) {
			getTwoFactorList((res) => {
				setFactorList(res);
			});
		}
	}, [factorList]);

	return (
		<div ref={adminRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={adminHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<ContentTable
							data={users}
							title={'Users'}
							handleDelete={openSweetAlert}
							handleEdit={handleEdit}
							handleResetPass={handleResetPass}
							editable
							header={[
								{ label: 'First Name', name: 'first_name' },
								{ label: 'Last Name', name: 'last_name' },
								{ label: 'Email', name: 'email' },
								{ label: 'Username', name: 'username' },
								{ label: 'Start Date', name: 'date_joined' },
								{ label: 'End Date', name: 'date_expired' },
								{ label: 'Job Name', name: 'job_name' },
								{ label: 'Reset Password', name: 'reset_pass' },
								{ label: 'Actions', name: 'actions' }
							]}
						/>
						<SweetAlert
							open={confirm}
							msg={`Are you sure you want to end ${selectedUser.first_name} ${selectedUser.last_name} membership`}
							confirm={handleDelete}
							cancel={() => setConfirm(false)}
						/>
						<PanelModal
							selectedUser={selectedUser}
							open={open}
							fields={fields}
							handleClose={handleClose}
							initialValues={
								modalState === 'edit' && {
									...selectedUser,
									date_expired: moment(
										selectedUser?.date_expired
											?.replace(' PM', '')
											.replace(' AM', '')
									).format('YYYY-MM-DDTHH:mm:ss')
								}
							}
							create={createUser}
							update={updateUserData}
						/>
						<Grid>
							<Button
								style={{ float: 'right', marginTop: 30 }}
								className={classes.header__save}
								onClick={handleClickOpen}
							>
								Create User
							</Button>
						</Grid>
						<br></br> <br></br>
						{factorList && (
							<ContentTable
								data={factorList}
								title={'Multi Factor Authentication'}
								handleDelete={openSweetAlert}
								handleEdit={handleEdit}
								handleResetPass={handleResetPass}
								editable
								refreshData={() => {
									getTwoFactorList((res) => {
										setFactorList(res);
									});
								}}
								header={[
									{ label: 'Email', name: 'email' },
									{ label: 'MFA Status', name: 'status_verbose' },
									{ label: 'MFA Toggle', name: 'mfa_toggle' }
								]}
							/>
						)}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default CompanySetting;
