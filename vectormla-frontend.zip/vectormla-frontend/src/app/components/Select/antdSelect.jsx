import React from 'react';
import { makeStyles } from '@material-ui/core';
import { Typography } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import { primaryColor } from '../../../common/assets/layout';
import { Select } from 'antd';

const root = {
	width: 175,
	margin: '10px 0px',
	'& label.Mui-focused': {
		color: primaryColor
	},
	'& .MuiOutlinedInput-root': {
		'&.Mui-focused fieldset': {
			borderColor: primaryColor
		}
	},
	'& .MuiInputLabel-outlined': {
		zIndex: 1,
		transform: 'translate(14px, 12px) scale(1)'
	},
	'& .MuiInputLabel-outlined.MuiInputLabel-shrink': {
		transform: 'translate(14px, -6px) scale(0.75)',
		fontWeight: 600
	},
	'& .MuiOutlinedInput-input': {
		padding: '5px 14px'
	},
	'& svg': {
		color: '#202020 !important',
		height: '10px !important',
		weight: '10px !important'
	}
};

const useStyles = makeStyles((theme) => ({
	sidemenu__select__Field: {
		paddingTop: 20,
		color: primaryColor
	},
	sidemenu__select__Field_layr: {
		color: primaryColor
	},
	root: {
		...root
	},
	root_layr: {
		...root,
		backgroundColor: '#f7f8fa'
	},
	header_select_input: {
		color: 'grey',
		marginTop: 0
	},
	header_select: {
		height: 25,
		fontSize: '11px',
		fontFamily: 'Roboto',
		fontWeight: 500,
		borderColor: 'rgb(0 0 0 / 23%)',
		borderRadius: 0,
		'& .ant-select-selector': {
			height: '25px !important',
			backgroundColor: '#f7f8fa !important',
			borderRadius: '4px !important',
			borderColor: '#bebfc0 !important'
		},
		'& .ant-select-selection-item': {
			fontSize: '11px',
			fontFamily: 'Roboto',
			fontWeight: 500,
			lineHeight: '25px !important'
		}
	}
}));

const AntdSelect = (props) => {
	let {
		label,
		input,
		children,
		value,
		view,
		disabled,
		change,
		onChange,
		defaultValue
	} = props;
	const classes = useStyles();

	return (
		<div
			className={
				view === 'sbs'
					? classes.sidemenu__select__Field
					: classes.sidemenu__select__Field_layr
			}
		>
			{view === 'sbs' && (
				<Typography
					style={{ float: 'left', fontSize: '12px', fontFamily: 'Roboto' }}
				>
					{label}
				</Typography>
			)}
			<FormControl
				disabled={disabled}
				className={view === 'sbs' ? classes.root : classes.root_layr}
			>
				<Select
					{...input}
					onChange={change || onChange}
					value={value || defaultValue}
					defaultValue={defaultValue}
					className={classes.header_select}
					listHeight={150}
				>
					{children}
				</Select>
			</FormControl>
		</div>
	);
};

export default AntdSelect;
