import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { useComponentSize } from 'react-use-size';
import {
	Toolbar,
	AppBar,
	Hidden,
	IconButton,
	Grid,
	Typography,
	Divider,
	Box,
	Drawer
} from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu';
import { OverlayTrigger, Popover } from 'react-bootstrap';
import { useStyles } from './headerStyles';
import BarTabs from '../Tabs';
import SubTabs from '../SubTabs';
// import Excel from '../../../common/assets/vector/images/excel3.svg';
// import File from '../../../common/assets/vector/images/file.svg';
import downArrow from '../../../common/assets/vector/images/arrow.svg';
// import api from '../../../common/assets/vector/images/api.svg';
import circIcon from '../../../common/assets/vector/images/circleIcon.svg';
import plusSign from '../../../common/assets/vector/images/plus_sign.svg';
import minusSign from '../../../common/assets/vector/images/minus_sign.svg';
import { logout } from '../../store/actions/auth.action';
import { ContextMenu, MenuItem } from 'react-contextmenu';
import './contextMenuStyles.css';
import { tabs } from './Tabs';

class MyPopover extends React.Component {
	render() {
		return (
			<div
				style={{
					position: 'fixed',
					right: 9,
					top: 25,
					width: 150,
					zIndex: 5000
				}}
			>
				<Popover {...this.props} style={{ zIndex: 1500 }}>
					{this.props.children}
				</Popover>
			</div>
		);
	}
}

const Header = ({ setCollapsed, collapsed, history }) => {
	const user = useSelector((state) => state.auth.user);
	const dispatch = useDispatch();
	const upperHeader = [
		...tabs.map(({ label, link, links }) => ({ label, link, links }))
	];
	const extractedUrl = window.location.href.split('app')[1];
	let defaultTab = 0;
	let defaultSubtab = 0;
	upperHeader.forEach((t, i) => {
		if (t.links?.includes(`/app${extractedUrl}`)) {
			defaultTab = i;
			defaultSubtab = t.links.indexOf(`/app${extractedUrl}`);
		}
	});

	const classes = useStyles();
	const { ref: headerRef, width: headerWidth } = useComponentSize();

	const [open, setOpen] = useState(false);
	const [index, setIndex] = useState(defaultTab);
	const [subTab, setSubTab] = useState(0);
	const [openAlm, setOpenAlm] = useState(false);
	const [openCredit, setOpenCredit] = useState(false);
	const [openPrepayment, setOpenPrepayment] = useState(false);
	const [openSecure, setOpenSecure] = useState(false);
	const [openFP, setOpenFP] = useState(false);
	const [openDashboard, setOpenDashboard] = useState(false);
	const [subTabs, setSubTabs] = useState(
		tabs[defaultTab].content[
			Object.keys(tabs[defaultTab].content)[defaultSubtab]
		]?.subtabs
	);
	useEffect(() => {
		let idTabs = tabs.find(
			(t) => t.links && t.links.includes(history.location.pathname)
		)?.id;

		if (idTabs > 0) {
			let subTabsItems =
				Object.keys(tabs[idTabs]?.content).length > 0
					? tabs[idTabs]?.content[Object.keys(tabs[idTabs]?.content)[0]].subtabs
					: [];
			setSubTabs(subTabsItems);
			let idSubTabs = subTabsItems
				.filter((subTabsItem) =>
					user?.[`allowed_section${index}`]?.includes(subTabsItem.id)
				)
				.findIndex((t) => t?.link && t.link === history.location.pathname);
			setSubTab(idSubTabs === -1 ? 0 : idSubTabs);
		} else {
			setSubTabs([]);
			setSubTab(0);
		}
	}, [history.location.pathname, user]);

	// Alpha bar
	const renderAlphaBar = () => {
		let cols = [];
		for (
			let i = 0;
			i < Math.floor((headerWidth ? headerWidth : 76 - 75) / 100);
			i++
		) {
			cols.push('bcdefghijklmnopqrstuvwxyz'.split('')[i]);
		}

		return cols.map((char, index) => (
			<div key={index} className={`${classes.alpha_cell} alpha_cell`}>
				{char}
			</div>
		));
	};

	const signOut = () => {
		dispatch(
			logout(() => {
				history.push({
					pathname: '/login'
				});
				setOverlayTrigger(false);
			})
		);
	};

	const [overlayTrigger, setOverlayTrigger] = useState(false);

	return (
		<>
			<div style={{ justify: 'center' }}>
				<Box
					bgcolor="#334152"
					style={{
						position: 'fixed',
						display: !open ? 'none' : 'block',
						height: '100%',
						width: 31,
						top: 55,
						zIndex: 999
					}}
				>
					<Grid style={{ paddingLeft: 7 }}>
						<svg
							style={{ marginTop: 27 }}
							onClick={() => setOpen(!open)}
							width="15"
							height="10"
							viewBox="0 0 15 10"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M14.5982 1.48936C14.7991 1.48936 15 1.35638 15 1.17021V0.319149C15 0.159574 14.7991 0 14.5982 0H0.401786C0.167411 0 0 0.159574 0 0.319149V1.17021C0 1.35638 0.167411 1.48936 0.401786 1.48936H14.5982ZM14.5982 5.74468C14.7991 5.74468 15 5.6117 15 5.42553V4.57447C15 4.41489 14.7991 4.25532 14.5982 4.25532H0.401786C0.167411 4.25532 0 4.41489 0 4.57447V5.42553C0 5.6117 0.167411 5.74468 0.401786 5.74468H14.5982ZM14.5982 10C14.7991 10 15 9.86702 15 9.68085V8.82979C15 8.67021 14.7991 8.51064 14.5982 8.51064H0.401786C0.167411 8.51064 0 8.67021 0 8.82979V9.68085C0 9.86702 0.167411 10 0.401786 10H14.5982Z"
								fill="#C4C4C4"
							/>
						</svg>
						<svg
							style={{ marginTop: 40 }}
							width="15"
							height="15"
							viewBox="0 0 12 13"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M11.7422 2.67969L6.25781 0.570312C6.1875 0.523438 6.07031 0.5 6 0.5C5.90625 0.5 5.78906 0.523438 5.71875 0.570312L0.234375 2.67969C0.09375 2.72656 0 2.86719 0 3.03125V3.875C0 4.08594 0.164062 4.25 0.375 4.25H11.625C11.8125 4.25 12 4.08594 12 3.875V3.03125C12 2.86719 11.8828 2.72656 11.7422 2.67969ZM1.5 5V8.75H1.125C0.914062 8.75 0.75 8.9375 0.75 9.125V10.25H11.25V9.125C11.25 8.9375 11.0625 8.75 10.875 8.75H10.5V5H9V8.75H6.75V5H5.25V8.75H3V5H1.5ZM11.625 11H0.375C0.164062 11 0 11.1875 0 11.375V12.125C0 12.3359 0.164062 12.5 0.375 12.5H11.625C11.8125 12.5 12 12.3359 12 12.125V11.375C12 11.1875 11.8125 11 11.625 11Z"
								fill="#C4C4C4"
							/>
						</svg>
						<svg
							style={{ marginTop: 27 }}
							width="15"
							height="15"
							viewBox="0 0 12 13"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M11.7422 2.67969L6.25781 0.570312C6.1875 0.523438 6.07031 0.5 6 0.5C5.90625 0.5 5.78906 0.523438 5.71875 0.570312L0.234375 2.67969C0.09375 2.72656 0 2.86719 0 3.03125V3.875C0 4.08594 0.164062 4.25 0.375 4.25H11.625C11.8125 4.25 12 4.08594 12 3.875V3.03125C12 2.86719 11.8828 2.72656 11.7422 2.67969ZM1.5 5V8.75H1.125C0.914062 8.75 0.75 8.9375 0.75 9.125V10.25H11.25V9.125C11.25 8.9375 11.0625 8.75 10.875 8.75H10.5V5H9V8.75H6.75V5H5.25V8.75H3V5H1.5ZM11.625 11H0.375C0.164062 11 0 11.1875 0 11.375V12.125C0 12.3359 0.164062 12.5 0.375 12.5H11.625C11.8125 12.5 12 12.3359 12 12.125V11.375C12 11.1875 11.8125 11 11.625 11Z"
								fill="#C4C4C4"
							/>
						</svg>
						<svg
							style={{ marginTop: 27 }}
							width="15"
							height="15"
							viewBox="0 0 12 13"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								d="M11.7422 2.67969L6.25781 0.570312C6.1875 0.523438 6.07031 0.5 6 0.5C5.90625 0.5 5.78906 0.523438 5.71875 0.570312L0.234375 2.67969C0.09375 2.72656 0 2.86719 0 3.03125V3.875C0 4.08594 0.164062 4.25 0.375 4.25H11.625C11.8125 4.25 12 4.08594 12 3.875V3.03125C12 2.86719 11.8828 2.72656 11.7422 2.67969ZM1.5 5V8.75H1.125C0.914062 8.75 0.75 8.9375 0.75 9.125V10.25H11.25V9.125C11.25 8.9375 11.0625 8.75 10.875 8.75H10.5V5H9V8.75H6.75V5H5.25V8.75H3V5H1.5ZM11.625 11H0.375C0.164062 11 0 11.1875 0 11.375V12.125C0 12.3359 0.164062 12.5 0.375 12.5H11.625C11.8125 12.5 12 12.3359 12 12.125V11.375C12 11.1875 11.8125 11 11.625 11Z"
								fill="#C4C4C4"
							/>
						</svg>
						<svg
							style={{ marginTop: 27 }}
							width="15"
							height="15"
							viewBox="0 0 13 13"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<rect
								y="3.15796"
								width="3.15789"
								height="9.47368"
								fill="#C4C4C4"
							/>
							<rect
								x="4.42188"
								width="3.15789"
								height="12.6316"
								fill="#C4C4C4"
							/>
							<rect
								x="8.84375"
								y="6.94727"
								width="3.15789"
								height="5.68421"
								fill="#C4C4C4"
							/>
						</svg>
					</Grid>
				</Box>
				<Drawer variant="persistent" anchor="left" open={open}>
					<div className={classes.sidebarContainer}>
						<Grid
							container
							onClick={() => setOpenAlm(!openAlm)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.6992 2.63281L7.30078 0.171875C7.21875 0.117188 7.08203 0.0898438 7 0.0898438C6.89062 0.0898438 6.75391 0.117188 6.67188 0.171875L0.273438 2.63281C0.109375 2.6875 0 2.85156 0 3.04297V4.02734C0 4.27344 0.191406 4.46484 0.4375 4.46484H13.5625C13.7812 4.46484 14 4.27344 14 4.02734V3.04297C14 2.85156 13.8633 2.6875 13.6992 2.63281ZM1.75 5.33984V9.71484H1.3125C1.06641 9.71484 0.875 9.93359 0.875 10.1523V11.4648H13.125V10.1523C13.125 9.93359 12.9062 9.71484 12.6875 9.71484H12.25V5.33984H10.5V9.71484H7.875V5.33984H6.125V9.71484H3.5V5.33984H1.75ZM13.5625 12.3398H0.4375C0.191406 12.3398 0 12.5586 0 12.7773V13.6523C0 13.8984 0.191406 14.0898 0.4375 14.0898H13.5625C13.7812 14.0898 14 13.8984 14 13.6523V12.7773C14 12.5586 13.7812 12.3398 13.5625 12.3398Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>ALM</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="ALM"
							/>
						</Grid>
						{openAlm && (
							<div>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/cashflow')
												window.location = '/app/cashflow';
										}}
									>
										Asset Model
									</p>
								</Grid>
								<Grid container>
									<p
										onClick={() => {
											if (window.location.pathname !== '/app/cashflow')
												window.location = '/app/cashflow';
										}}
										className={classes.ps_with_hover}
									>
										Liability Model
									</p>
								</Grid>
							</div>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid
							container
							onClick={() => setOpenCredit(!openCredit)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.6992 2.63281L7.30078 0.171875C7.21875 0.117188 7.08203 0.0898438 7 0.0898438C6.89062 0.0898438 6.75391 0.117188 6.67188 0.171875L0.273438 2.63281C0.109375 2.6875 0 2.85156 0 3.04297V4.02734C0 4.27344 0.191406 4.46484 0.4375 4.46484H13.5625C13.7812 4.46484 14 4.27344 14 4.02734V3.04297C14 2.85156 13.8633 2.6875 13.6992 2.63281ZM1.75 5.33984V9.71484H1.3125C1.06641 9.71484 0.875 9.93359 0.875 10.1523V11.4648H13.125V10.1523C13.125 9.93359 12.9062 9.71484 12.6875 9.71484H12.25V5.33984H10.5V9.71484H7.875V5.33984H6.125V9.71484H3.5V5.33984H1.75ZM13.5625 12.3398H0.4375C0.191406 12.3398 0 12.5586 0 12.7773V13.6523C0 13.8984 0.191406 14.0898 0.4375 14.0898H13.5625C13.7812 14.0898 14 13.8984 14 13.6523V12.7773C14 12.5586 13.7812 12.3398 13.5625 12.3398Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>Credit risk</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="Credit risk"
							/>
						</Grid>
						{openCredit && (
							<div>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/crm')
												window.location = '/app/crm';
										}}
									>
										PD-LGD-EAD-EL
									</p>
								</Grid>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/crm')
												window.location = '/app/crm';
										}}
									>
										Machine Learning
									</p>
								</Grid>
							</div>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid
							container
							onClick={() => setOpenPrepayment(!openPrepayment)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.6992 2.63281L7.30078 0.171875C7.21875 0.117188 7.08203 0.0898438 7 0.0898438C6.89062 0.0898438 6.75391 0.117188 6.67188 0.171875L0.273438 2.63281C0.109375 2.6875 0 2.85156 0 3.04297V4.02734C0 4.27344 0.191406 4.46484 0.4375 4.46484H13.5625C13.7812 4.46484 14 4.27344 14 4.02734V3.04297C14 2.85156 13.8633 2.6875 13.6992 2.63281ZM1.75 5.33984V9.71484H1.3125C1.06641 9.71484 0.875 9.93359 0.875 10.1523V11.4648H13.125V10.1523C13.125 9.93359 12.9062 9.71484 12.6875 9.71484H12.25V5.33984H10.5V9.71484H7.875V5.33984H6.125V9.71484H3.5V5.33984H1.75ZM13.5625 12.3398H0.4375C0.191406 12.3398 0 12.5586 0 12.7773V13.6523C0 13.8984 0.191406 14.0898 0.4375 14.0898H13.5625C13.7812 14.0898 14 13.8984 14 13.6523V12.7773C14 12.5586 13.7812 12.3398 13.5625 12.3398Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>Prepayment</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="Prepayment"
							/>
						</Grid>
						{openPrepayment && (
							<>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/prepayment')
												window.location = '/app/prepayment';
										}}
									>
										SMM/CPR
									</p>
								</Grid>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/prepayment')
												window.location = '/app/prepayment';
										}}
									>
										Machine Learning
									</p>
								</Grid>
							</>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid
							container
							onClick={() => setOpenSecure(!openSecure)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.6992 2.63281L7.30078 0.171875C7.21875 0.117188 7.08203 0.0898438 7 0.0898438C6.89062 0.0898438 6.75391 0.117188 6.67188 0.171875L0.273438 2.63281C0.109375 2.6875 0 2.85156 0 3.04297V4.02734C0 4.27344 0.191406 4.46484 0.4375 4.46484H13.5625C13.7812 4.46484 14 4.27344 14 4.02734V3.04297C14 2.85156 13.8633 2.6875 13.6992 2.63281ZM1.75 5.33984V9.71484H1.3125C1.06641 9.71484 0.875 9.93359 0.875 10.1523V11.4648H13.125V10.1523C13.125 9.93359 12.9062 9.71484 12.6875 9.71484H12.25V5.33984H10.5V9.71484H7.875V5.33984H6.125V9.71484H3.5V5.33984H1.75ZM13.5625 12.3398H0.4375C0.191406 12.3398 0 12.5586 0 12.7773V13.6523C0 13.8984 0.191406 14.0898 0.4375 14.0898H13.5625C13.7812 14.0898 14 13.8984 14 13.6523V12.7773C14 12.5586 13.7812 12.3398 13.5625 12.3398Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>Securitization</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="Securitization"
							/>
						</Grid>
						{openSecure && (
							<>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/securitization')
												window.location = '/app/securitization';
										}}
									>
										NHA MBS - CMHC
									</p>
								</Grid>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/securitization')
												window.location = '/app/securitization';
										}}
									>
										RMBS Reporting
									</p>
								</Grid>
							</>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid
							container
							onClick={() => setOpenFP(!openFP)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.6992 2.63281L7.30078 0.171875C7.21875 0.117188 7.08203 0.0898438 7 0.0898438C6.89062 0.0898438 6.75391 0.117188 6.67188 0.171875L0.273438 2.63281C0.109375 2.6875 0 2.85156 0 3.04297V4.02734C0 4.27344 0.191406 4.46484 0.4375 4.46484H13.5625C13.7812 4.46484 14 4.27344 14 4.02734V3.04297C14 2.85156 13.8633 2.6875 13.6992 2.63281ZM1.75 5.33984V9.71484H1.3125C1.06641 9.71484 0.875 9.93359 0.875 10.1523V11.4648H13.125V10.1523C13.125 9.93359 12.9062 9.71484 12.6875 9.71484H12.25V5.33984H10.5V9.71484H7.875V5.33984H6.125V9.71484H3.5V5.33984H1.75ZM13.5625 12.3398H0.4375C0.191406 12.3398 0 12.5586 0 12.7773V13.6523C0 13.8984 0.191406 14.0898 0.4375 14.0898H13.5625C13.7812 14.0898 14 13.8984 14 13.6523V12.7773C14 12.5586 13.7812 12.3398 13.5625 12.3398Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>FP&amp;A</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="FPNA"
							/>
						</Grid>
						{openFP && (
							<>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/fpna')
												window.location = '/app/fpna';
										}}
									>
										Originations
									</p>
								</Grid>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/fpna')
												window.location = '/app/fpna';
										}}
									>
										Pro forma
									</p>
								</Grid>
							</>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid
							container
							onClick={() => setOpenDashboard(!openDashboard)}
							style={{ cursor: 'pointer' }}
						>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="12"
								viewBox="0 0 17 12"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<rect y="4.25" width="3.68421" height="12.75" fill="#C4C4C4" />
								<rect x="5.16016" width="3.68421" height="17" fill="#C4C4C4" />
								<rect
									x="10.3164"
									y="9.34985"
									width="3.68421"
									height="7.65"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>Dashboard</p>
							<img
								src={downArrow}
								style={{ position: 'absolute', right: 20, marginTop: 20 }}
								alt="dashboard"
							/>
						</Grid>
						{openDashboard && (
							<>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/dashboard')
												window.location = '/app/dashboard';
										}}
									>
										Management KPIs
									</p>
								</Grid>
								<Grid container>
									<p
										className={classes.ps_with_hover}
										onClick={() => {
											if (window.location.pathname !== '/app/dashboard')
												window.location = '/app/dashboard';
										}}
									>
										Portfolio Analytics
									</p>
								</Grid>
							</>
						)}
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="17"
								height="15"
								viewBox="0 0 11 15"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M7.875 7.61719C7.875 7.45312 7.71094 7.28906 7.54688 7.28906H2.95312C2.76172 7.28906 2.625 7.45312 2.625 7.61719V8.38281C2.625 8.57422 2.76172 8.71094 2.95312 8.71094H7.54688C7.71094 8.71094 7.875 8.57422 7.875 8.38281V7.61719ZM7.54688 9.58594H2.95312C2.76172 9.58594 2.625 9.75 2.625 9.91406V10.6797C2.625 10.8711 2.76172 11.0078 2.95312 11.0078H7.54688C7.71094 11.0078 7.875 10.8711 7.875 10.6797V9.91406C7.875 9.75 7.71094 9.58594 7.54688 9.58594ZM10.5 4.44531C10.5 4.11719 10.3359 3.76172 10.0898 3.51562L7.82031 1.24609C7.57422 1 7.21875 0.835938 6.89062 0.835938H1.3125C0.574219 0.835938 0 1.4375 0 2.14844V13.5234C0 14.2617 0.574219 14.8359 1.3125 14.8359H9.1875C9.89844 14.8359 10.5 14.2617 10.5 13.5234V4.44531ZM7 2.25781L9.07812 4.33594H7V2.25781ZM9.1875 13.5234H1.3125V2.14844H5.6875V4.99219C5.6875 5.375 5.96094 5.64844 6.34375 5.64844H9.1875V13.5234Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.sidebar_header}>Library</p>
						</Grid>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: -10 }}
								width="17"
								height="15"
								viewBox="0 0 11 15"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M7.875 7.61719C7.875 7.45312 7.71094 7.28906 7.54688 7.28906H2.95312C2.76172 7.28906 2.625 7.45312 2.625 7.61719V8.38281C2.625 8.57422 2.76172 8.71094 2.95312 8.71094H7.54688C7.71094 8.71094 7.875 8.57422 7.875 8.38281V7.61719ZM7.54688 9.58594H2.95312C2.76172 9.58594 2.625 9.75 2.625 9.91406V10.6797C2.625 10.8711 2.76172 11.0078 2.95312 11.0078H7.54688C7.71094 11.0078 7.875 10.8711 7.875 10.6797V9.91406C7.875 9.75 7.71094 9.58594 7.54688 9.58594ZM10.5 4.44531C10.5 4.11719 10.3359 3.76172 10.0898 3.51562L7.82031 1.24609C7.57422 1 7.21875 0.835938 6.89062 0.835938H1.3125C0.574219 0.835938 0 1.4375 0 2.14844V13.5234C0 14.2617 0.574219 14.8359 1.3125 14.8359H9.1875C9.89844 14.8359 10.5 14.2617 10.5 13.5234V4.44531ZM7 2.25781L9.07812 4.33594H7V2.25781ZM9.1875 13.5234H1.3125V2.14844H5.6875V4.99219C5.6875 5.375 5.96094 5.64844 6.34375 5.64844H9.1875V13.5234Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.ps_library_hover}>Save</p>
						</Grid>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: -10 }}
								width="17"
								height="15"
								viewBox="0 0 11 15"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M7.875 7.61719C7.875 7.45312 7.71094 7.28906 7.54688 7.28906H2.95312C2.76172 7.28906 2.625 7.45312 2.625 7.61719V8.38281C2.625 8.57422 2.76172 8.71094 2.95312 8.71094H7.54688C7.71094 8.71094 7.875 8.57422 7.875 8.38281V7.61719ZM7.54688 9.58594H2.95312C2.76172 9.58594 2.625 9.75 2.625 9.91406V10.6797C2.625 10.8711 2.76172 11.0078 2.95312 11.0078H7.54688C7.71094 11.0078 7.875 10.8711 7.875 10.6797V9.91406C7.875 9.75 7.71094 9.58594 7.54688 9.58594ZM10.5 4.44531C10.5 4.11719 10.3359 3.76172 10.0898 3.51562L7.82031 1.24609C7.57422 1 7.21875 0.835938 6.89062 0.835938H1.3125C0.574219 0.835938 0 1.4375 0 2.14844V13.5234C0 14.2617 0.574219 14.8359 1.3125 14.8359H9.1875C9.89844 14.8359 10.5 14.2617 10.5 13.5234V4.44531ZM7 2.25781L9.07812 4.33594H7V2.25781ZM9.1875 13.5234H1.3125V2.14844H5.6875V4.99219C5.6875 5.375 5.96094 5.64844 6.34375 5.64844H9.1875V13.5234Z"
									fill="#C4C4C4"
								/>
							</svg>

							<p className={classes.ps_library_hover}>Save As</p>
						</Grid>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: -10 }}
								width="14"
								height="14"
								viewBox="0 0 14 14"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M13.7812 7.06494C13.7539 3.31885 10.7188 0.283691 7 0.283691C5.16797 0.283691 3.52734 1.02197 2.29688 2.17041L0.957031 0.830566C0.683594 0.557129 0.21875 0.748535 0.21875 1.13135V5.09619C0.21875 5.34229 0.410156 5.53369 0.65625 5.53369H4.62109C5.00391 5.53369 5.19531 5.06885 4.92188 4.79541L3.52734 3.40088C4.42969 2.55322 5.66016 2.03369 7 2.03369C9.76172 2.03369 12.0312 4.30322 12.0312 7.06494C12.0312 9.854 9.76172 12.0962 7 12.0962C5.79688 12.0962 4.73047 11.7134 3.85547 11.0298C3.60938 10.811 3.22656 10.8384 2.98047 11.0845L2.67969 11.3853C2.40625 11.6587 2.43359 12.1235 2.73438 12.3696C3.88281 13.2993 5.38672 13.8735 7 13.8462C10.7188 13.8462 13.7812 10.811 13.7812 7.06494ZM8.83203 9.2251L9.07812 8.86963C9.32422 8.59619 9.26953 8.18604 8.96875 7.96729L7.875 7.09229V4.22119C7.875 3.86572 7.57422 3.56494 7.21875 3.56494H6.78125C6.39844 3.56494 6.125 3.86572 6.125 4.22119V7.93994L7.90234 9.33447C8.17578 9.55322 8.58594 9.49854 8.83203 9.2251Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.ps_library_hover}>History</p>
						</Grid>
						<Grid container>
							<p
								className={classes.ps_library_hover}
								style={{
									marginLeft: 37
								}}
							>
								Export
							</p>
						</Grid>
						<Grid container>
							<p
								className={classes.ps_library_hover}
								style={{
									marginLeft: 37
								}}
							>
								Publish
							</p>
						</Grid>
						<Grid
							container
							onClick={() => setOpen(!open)}
							style={{ cursor: 'pointer' }}
						>
							<p
								className={classes.ps_library_hover}
								style={{
									marginLeft: 37
								}}
							>
								Close
							</p>
						</Grid>
						<Divider
							style={{
								backgroundColor: '#C4C4C4',
								marginRight: 10,
								marginLeft: 10
							}}
						/>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: 17 }}
								width="14"
								height="14"
								viewBox="0 0 14 14"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M7 0.323242C3.25391 0.323242 0.21875 3.38574 0.21875 7.10449C0.21875 10.8506 3.25391 13.8857 7 13.8857C10.7188 13.8857 13.7812 10.8506 13.7812 7.10449C13.7812 3.38574 10.7188 0.323242 7 0.323242ZM7 12.5732C3.96484 12.5732 1.53125 10.1396 1.53125 7.10449C1.53125 4.09668 3.96484 1.63574 7 1.63574C10.0078 1.63574 12.4688 4.09668 12.4688 7.10449C12.4688 10.1396 10.0078 12.5732 7 12.5732ZM9.92578 5.60059C9.92578 4.2334 8.47656 3.16699 7.13672 3.16699C5.85156 3.16699 5.03125 3.71387 4.40234 4.6709C4.29297 4.80762 4.32031 4.99902 4.45703 5.1084L5.22266 5.68262C5.35938 5.79199 5.57812 5.76465 5.6875 5.62793C6.09766 5.1084 6.39844 4.80762 7.02734 4.80762C7.51953 4.80762 8.12109 5.1084 8.12109 5.60059C8.12109 5.95605 7.82031 6.12012 7.32812 6.39355C6.78125 6.72168 6.04297 7.10449 6.04297 8.08887V8.30762C6.04297 8.49902 6.17969 8.63574 6.37109 8.63574H7.60156C7.79297 8.63574 7.92969 8.49902 7.92969 8.30762V8.14355C7.92969 7.45996 9.92578 7.43262 9.92578 5.60059ZM8.14844 10.167C8.14844 9.53809 7.62891 9.01855 7 9.01855C6.34375 9.01855 5.85156 9.53809 5.85156 10.167C5.85156 10.8232 6.34375 11.3154 7 11.3154C7.62891 11.3154 8.14844 10.8232 8.14844 10.167Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.ps_library_hover}>Help Center</p>
						</Grid>
						<Grid container>
							<svg
								style={{ margin: 5, marginTop: -10 }}
								width="14"
								height="15"
								viewBox="0 0 14 15"
								fill="none"
								xmlns="http://www.w3.org/2000/svg"
							>
								<path
									d="M7.05469 0.519043C3.30859 0.519043 0.273438 3.5542 0.273438 7.30029C0.273438 11.0464 3.30859 14.0815 7.05469 14.0815C10.8008 14.0815 13.8359 11.0464 13.8359 7.30029C13.8359 3.5542 10.8008 0.519043 7.05469 0.519043ZM7.05469 3.14404C8.36719 3.14404 9.46094 4.23779 9.46094 5.55029C9.46094 6.89014 8.36719 7.95654 7.05469 7.95654C5.71484 7.95654 4.64844 6.89014 4.64844 5.55029C4.64844 4.23779 5.71484 3.14404 7.05469 3.14404ZM7.05469 12.5503C5.44141 12.5503 3.99219 11.8394 3.03516 10.6909C3.55469 9.73389 4.56641 9.05029 5.74219 9.05029C5.79688 9.05029 5.85156 9.07764 5.93359 9.10498C6.28906 9.21436 6.64453 9.26904 7.05469 9.26904C7.4375 9.26904 7.82031 9.21436 8.14844 9.10498C8.23047 9.07764 8.28516 9.05029 8.36719 9.05029C9.51562 9.05029 10.5273 9.73389 11.0469 10.6909C10.0898 11.8394 8.64062 12.5503 7.05469 12.5503Z"
									fill="#C4C4C4"
								/>
							</svg>
							<p className={classes.ps_library_hover}>My Profile</p>
						</Grid>
						<Grid container>
							<p
								className={classes.ps_library_hover}
								style={{
									marginLeft: 37
								}}
							>
								Feedback
							</p>
						</Grid>
					</div>
				</Drawer>
				<div
					ref={headerRef}
					style={{ borderBottom: '0px solid rgb(0,0,0,0.2)' }}
				>
					<AppBar className={classes.root1}>
						<Toolbar className={classes.upperHeader}>
							<Hidden mdUp>
								<IconButton
									onClick={() => setOpen(!open)}
									className={classes.menuBars}
									aria-label="open side menu"
								>
									<MenuIcon />
								</IconButton>
							</Hidden>
							<Hidden smDown>
								<div
									style={{
										marginTop: '17px',
										marginRight: 10,
										marginLeft: '-2px',
										display: 'flex',
										flexDirection: 'row'
									}}
								>
									<svg
										style={{ marginTop: 12, marginLeft: 8 }}
										// onClick={() => setOpen(!open)}
										width="15"
										height="10"
										viewBox="0 0 15 10"
										fill="none"
										xmlns="http://www.w3.org/2000/svg"
									>
										<path
											d="M14.5982 1.48936C14.7991 1.48936 15 1.35638 15 1.17021V0.319149C15 0.159574 14.7991 0 14.5982 0H0.401786C0.167411 0 0 0.159574 0 0.319149V1.17021C0 1.35638 0.167411 1.48936 0.401786 1.48936H14.5982ZM14.5982 5.74468C14.7991 5.74468 15 5.6117 15 5.42553V4.57447C15 4.41489 14.7991 4.25532 14.5982 4.25532H0.401786C0.167411 4.25532 0 4.41489 0 4.57447V5.42553C0 5.6117 0.167411 5.74468 0.401786 5.74468H14.5982ZM14.5982 10C14.7991 10 15 9.86702 15 9.68085V8.82979C15 8.67021 14.7991 8.51064 14.5982 8.51064H0.401786C0.167411 8.51064 0 8.67021 0 8.82979V9.68085C0 9.86702 0.167411 10 0.401786 10H14.5982Z"
											fill="#1D4261"
										/>
									</svg>
								</div>
								<BarTabs
									tabs={upperHeader}
									subTabs={subTabs}
									originalTabs={tabs}
									tabProps={{ disableRipple: true }}
									value={index}
									setValue={setIndex}
									onChange={(i) => {
										setIndex(i);
										setSubTab(0);
										setSubTabs(
											Object.keys(tabs[i].content).length > 0
												? tabs[i].content[Object.keys(tabs[i].content)[0]]
														.subtabs
												: []
										);
										if (collapsed !== 0) setCollapsed(0);
									}}
									style={{ marginLeft: 8 }}
								/>
							</Hidden>
							{/* Subtabs (sheets)*/}
							<Hidden smDown>
								<div className={`MuiTabs-root ${classes.header_right}`}>
									{/* <Typography
										className={` ${classes.header_text}`}
										style={{ marginRight: 20, cursor: 'pointer' }}
										onClick={() => history.push({ pathname: '/app/academy' })}
									>
										Help Center
									</Typography> */}
									<img
										src={circIcon}
										style={{ marginRight: 10, marginTop: 4, cursor: 'pointer' }}
										alt="circle"
									/>
									<OverlayTrigger
										containerPadding={40}
										trigger="click"
										placement="bottom"
										rootClose={true}
										show={overlayTrigger}
										overlay={
											<MyPopover>
												<div style={{ zIndex: 6000 }}>
													<div
														onClick={() => {
															history.push({
																pathname: '/app/account'
															});
															setOverlayTrigger(false);
														}}
														className={classes.popover_user}
													>
														<a className={classes.popover_link}>
															Account Settings
														</a>
													</div>
													{user?.status && (
														<div className={classes.popover_user}>
															<a
																onClick={() => {
																	history.push({
																		pathname: '/app/setting'
																	});
																	setOverlayTrigger(false);
																}}
																className={classes.popover_link}
															>
																Company Setting
															</a>
														</div>
													)}
													<div
														onClick={signOut}
														className={classes.popover_user}
													>
														<a className={classes.popover_link}>Logout</a>
													</div>
												</div>
											</MyPopover>
										}
									>
										<div
											style={{
												fontFamily: 'Roboto',
												width: 70,
												marginRight: 30,
												fontWeight: 400,
												cursor: 'pointer',
												marginTop: 18,
												verticalAlign: 'middle',
												display: 'grid',
												gridAutoFlow: 'column'
											}}
											onClick={() => setOverlayTrigger(!overlayTrigger)}
										>
											<Typography
												className={` ${classes.header_text_user}`}
												style={{ cursor: 'pointer' }}
											>
												{`${user?.first_name}`}
											</Typography>
											<img
												src={downArrow}
												style={{
													cursor: 'pointer',
													marginTop: 5,
													marginLeft:
														user?.first_name === 'Jessica'
															? '3px'
															: user?.first_name === 'Brian'
															? // ? '16px'
															  '16px'
															: '0.8rem'
												}}
												alt="arrow"
											/>
										</div>
									</OverlayTrigger>
								</div>
							</Hidden>
						</Toolbar>
					</AppBar>
				</div>

				<div className={classes.topHeader}>
					<div className={classes.topSubHeaderContainer}>
						{/*<div
							style={{
								marginLeft: 7,
								marginTop: 3,
								width: 12,
								display: 'flex',
								flexDirection: 'column',
								cursor: 'pointer'
							}}
						>
							<img
								src={plusSign}
								alt="plusSign"
								onClick={() => {
									if (collapsed === 0) setCollapsed(1);
									else if (collapsed >= 1) setCollapsed(++collapsed);
								}}
							/>
							<img
								src={minusSign}
								alt="minusSign"
								onClick={() => {
									setCollapsed(0);
								}}
							/>
							</div>*/}
						{/*subtabs (sheets)*/}
						<Hidden smDown>
							<div className={classes.sheetContainer}>
								<SubTabs
									tabs={subTabs}
									tabProps={{ disableRipple: true }}
									value={subTab}
									setValue={setSubTab}
									onChange={() => {
										if (collapsed !== 0) setCollapsed(0);
									}}
									style={{ marginLeft: 8 }}
									parentID={index}
								/>
							</div>

							{/* <div className={`MuiTabs-root ${classes.header_right_bottom}`}>
								<div
									style={{
										verticalAlign: 'center',
										marginTop: 5,
										cursor: 'pointer',
										marginRight: 15
									}}
								>
									<Typography style={{ fontSize: 12 }}>
										<img style={{ marginRight: 8 }} src={Excel} alt="excel" />{' '}
										Excel Portal
									</Typography>
								</div>
								<div
									style={{
										verticalAlign: 'center',
										marginTop: 5,
										marginLeft: 20,
										cursor: 'pointer'
									}}
								>
									<Typography style={{ fontSize: 12 }}>
										<img style={{ marginRight: 8 }} src={File} alt="notes" />{' '}
										Notes
									</Typography>
								</div>
								<div
									style={{
										verticalAlign: 'center',
										marginTop: 5,
										marginLeft: 20,
										cursor: 'pointer'
									}}
								>
									<Typography style={{ fontSize: 12 }}>
										<img
											style={{ marginRight: 8, width: 16 }}
											src={api}
											alt="api"
										/>{' '}
										API
									</Typography>
								</div>
							</div> */}
						</Hidden>
						{tabs.map(
							(data, tabIndex) =>
								Object.keys(data.content).length > 0 && (
									<ContextMenu
										key={tabIndex}
										hideOnLeave
										id={`context-menu-${tabIndex}`}
									>
										{Object.keys(data.content).map(
											(tab, i) =>
												//to show only allowed pages
												(tabIndex == 0 ||
													tabIndex > 4 ||
													(tabIndex == 1 &&
														user?.allowed_section1.includes(i + 1)) ||
													(tabIndex == 2 &&
														user?.allowed_section2.includes(i + 1)) ||
													(tabIndex == 3 &&
														user?.allowed_section3.includes(i + 1)) ||
													(tabIndex == 4 &&
														user?.allowed_section4.includes(i + 1))) && (
													<MenuItem
														key={i}
														onClick={() => {
															if (data.content[tab].link) {
																history.push(`${data.content[tab].link}`);
																setIndex(tabIndex);
																setSubTabs(data.content[tab].subtabs);
															}
														}}
													>
														<span>{tab}</span>
													</MenuItem>
												)
										)}
									</ContextMenu>
								)
						)}
					</div>
				</div>
				<div className={classes.alpha}>
					<div className={classes.alpha_cell_tri}>
						<svg
							style={{ position: 'relative', bottom: 0.5, right: -1.5 }}
							width="20"
							height="19"
							viewBox="0 0 17 16"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path d="M17 0V16H0L17 0Z" fill="#BDBDBD" />
						</svg>
					</div>
					<div
						key={index}
						style={{ width: 114 }}
						className={`${classes.alpha_cell} alpha_cell`}
					>
						{'A'}
					</div>
					{renderAlphaBar()}
				</div>
			</div>
		</>
	);
};
export default withRouter(Header);
