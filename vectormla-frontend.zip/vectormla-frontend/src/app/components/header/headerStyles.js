import { makeStyles } from '@material-ui/core';
import { upperHeader } from '../../../common/assets/layout';

const alphaCell = {
	backgroundColor: '#fff',
	height: 21,
	textAlign: 'center',
	borderLeft: '0px',
	boxSizing: 'border-box',
	textTransform: 'capitalize',
	fontSize: 11,
	display: 'flex',
	justifyContent: 'center',
	alignItems: 'end',
	border: '1px solid #8C96A3',
	color: '#8C96A3'
};

export const useStyles = makeStyles((theme) => ({
	root1: {
		backgroundColor: '#1D4261',
		height: upperHeader,
		boxShadow: 'none',
		zIndex: 1300,
		'& .MuiToolbar-regular': {
			minHeight: 9
		},
		'&.MuiAppBar-root': {
			width: '100%',
			position: 'fixed'
		}
	},
	ps_with_hover: {
		color: '#C4C4C4',
		fontFamily: 'Roboto',
		fontSize: 12,
		fontWeight: 500,
		marginLeft: 37,
		marginTop: -10,
		'&:hover': {
			boxShadow: 'inset 0 -1px 0 0 #fff',
			cursor: 'default'
		}
	},
	ps_library_hover: {
		color: '#C4C4C4',
		fontFamily: 'Roboto',
		fontSize: 12,
		fontWeight: 500,
		marginLeft: 10,
		marginTop: -10,

		'&:hover': {
			boxShadow: 'inset 0 -1px 0 0 #fff',
			cursor: 'default'
		}
	},
	header_text: {
		fontSize: '12px',
		marginTop: '20px',
		lineHeight: '16px',
		/* identical to box height */
		color: '#C0C8CC'
	},
	header_text_user: {
		fontSize: '12px',
		/* identical to box height */
		color: '#C0C8CC'
	},
	header_right: {
		marginTop: 20,
		position: 'absolute',
		right: 20
	},
	header_right_bottom: {
		marginTop: 0,
		position: 'absolute',
		right: 0,
		width: 310
	},
	popover_user: {
		textAlign: 'center',
		padding: 6,
		paddingRight: 32,
		paddingLeft: 20,
		'&:hover': {
			backgroundColor: '#2888D1 !important',
			color: '#ffffff',
			cursor: 'pointer',
			'& a': {
				color: '#fff'
			}
		}
	},
	popover_link: {
		fontSize: 10,
		color: '#0D3756',
		textDecoration: 'none'
	},
	upperHeader: {
		height: 0,
		justifyContent: 'flex-start',
		'& a': {
			fontSize: 14
		},
		'&.MuiToolbar-gutters': {
			paddingLeft: 0,
			paddingRight: 0
		},
		[theme.breakpoints.down('xs')]: {
			'& a': {
				padding: 5
			}
		}
	},
	menuBars: {
		color: '#fff',
		position: 'absolute',
		top: -6,
		left: 8
	},
	alpha: {
		width: '200%',
		height: 21,
		display: 'flex',
		position: 'fixed',
		top: 64,
		zIndex: 1104
	},
	alpha_cell: {
		...alphaCell,
		height: 21,
		width: 110.8,
		backgroundColor: '#E6E6E6'
	},
	alpha_cell_start: {
		...alphaCell,
		height: 21,
		backgroundColor: '#E6E6E6'
	},
	alpha_cell_tri: {
		...alphaCell,
		minWidth: 25,
		fontSize: 25,
		color: '#8C96A3',
		backgroundColor: '#E6E6E6'
	},
	sidebar_header: {
		color: '#C4C4C4',
		fontFamily: 'Roboto',
		fontSize: 12,
		fontWeight: 500,
		marginLeft: 10,
		marginTop: 15
	},
	sidebarContainer: {
		width: 175,
		height: '130%',
		backgroundColor: '#334152',
		padding: 5,
		marginTop: 63
	},
	topHeader: {
		width: '100%',
		backgroundColor: '#134D77',
		marginTop: 34,
		position: 'fixed',
		zIndex: 1300
	},
	topSubHeaderContainer: {
		color: '#8C96A3',
		backgroundColor: '#DEDEDE',
		height: 30,
		display: 'flex',
		whiteSpace: 'nowrap'
	},
	sheetContainer: {
		display: 'flex',
		marginLeft: 10.5,
		width: '45.95%'
	},
	sheet: {
		fontSize: 12,
		width: '20%',
		borderRight: '1px solid #8C96A3',
		marginBlock: 7,
		cursor: 'pointer',
		textAlign: 'center',
		color: 'rgb(110, 111, 114)',
		'& a': {
			color: 'rgb(110, 111, 114)'
		}
	}
}));
