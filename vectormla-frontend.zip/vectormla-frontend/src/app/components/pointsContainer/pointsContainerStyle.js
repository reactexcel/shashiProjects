import { makeStyles } from '@material-ui/core';
import {
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';
export const useStyles = makeStyles((theme) => ({
	contentHeaderContainer,
	contentHeader,
	divider: {
		marginBottom: 20
	},
	pointsContainer: {
		background: '#FFFFFF',
		border: '1px solid #DCE0E6',
		boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
		display: 'flex',
		paddingInline: 40,
		paddingBlock: 40
	},
	containerUpperContent: {
		background: '#266696',
		height: 30,
		width: '100%',
		'& p': {
			color: '#fff',
			paddingTop: 5,
			verticalAligin: 'center',
			paddingLeft: 10,
			fontSize: 13,
			fontFamily: 'Roboto',
			fontWeight: 'bold'
		}
	},
	pointsList: {
		listStyle: 'none',
		listStyleType: 'none',
		marginLeft: -42
	},
	liItem: {
		color: '#9C9A9A',
		lineHeight: '1.1rem'
	},
	liSpan: {
		fontSize: 10,
		color: '#313132',
		marginRight: 10,
		marginLeft: 10
	}
}));
