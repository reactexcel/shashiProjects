import React from 'react';
import { Grid } from '@material-ui/core';
import { useStyles } from './pointsContainerStyle';
import LockIcon from '@material-ui/icons/Lock';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import { tabsFields } from 'admin-panel/pages/AdminHome/fields';
import { useSelector } from 'react-redux';

const PointsContainer = ({ header, data, id }) => {
	const user = useSelector((state) => state.auth.user);
	const classes = useStyles();
	return (
		<div key={id}>
			<div>
				<div
					className={classes.containerUpperContent}
					style={{ borderTopLeftRadius: 5, borderTopRightRadius: 5 }}
				>
					<p>{header}</p>
				</div>
				<Grid
					className={classes.pointsContainer}
					container
					style={{ borderBottomLeftRadius: 5, borderBottomRightRadius: 5 }}
				>
					{data.map((column, i) => (
						<Grid
							style={{ width: `${100 / data.length}%`, paddingRight: 0 }}
							item
							xs={12}
							key={i}
							md={3}
						>
							<div
								style={{
									marginBottom: 30
								}}
							>
								<p
									style={{
										width: '85%',
										paddingBottom: 3,
										color: '#266696',
										cursor: 'pointer'
									}}
									className={classes.contentHeader}
									key={`li-${i}`}
								>
									{/*<a href={`${column?.link}`}>{column.header}</a>*/}
									<a
										style={{ color: '#266696' }}
										href={
											column?.pointsAllowed?.includes(i + 1) &&
											column?.pointsAllowed.includes(
												tabsFields
													?.find((itemm) => itemm?.s_name === column.header)
													?.list?.find(
														(itemFind) =>
															itemFind?.link === column.points?.singleLink
													)?.id
											)
												? column.points?.singleLink
												: tabsFields
														?.find((itemm) => itemm?.s_name === column.header)
														?.list?.find(
															(itemFind) =>
																itemFind?.id ===
																column?.pointsAllowed?.find(
																	(item) => `${item}`.length === 3
																)
														)?.link
										}
									>
										{column.header}
									</a>
								</p>
							</div>
							<Grid container justify="flex-start" alignItems="flex-start">
								<ul className={classes.pointsList}>
									{column.points.map((item, i) => (
										<li key={`li-${i}`} className={classes.liItem}>
											<a
												key={`a-${i}`}
												href={
													column?.pointsAllowed?.includes(i + 1) &&
													column?.pointsAllowed.includes(
														tabsFields
															?.find((itemm) => itemm?.s_name === column.header)
															?.list?.find(
																(itemFind) =>
																	itemFind?.link === item?.singleLink
															)?.id
													)
														? item?.singleLink
														: column?.pointsAllowed?.includes(i + 1) &&
														  tabsFields
																?.find(
																	(itemm) => itemm?.s_name === column.header
																)
																?.list?.find(
																	(itemFind) =>
																		itemFind?.id ===
																		column?.pointsAllowed?.find(
																			(item) => `${item}`.length === 3
																		)
																)?.link
												}
												style={{ cursor: 'pointer' }}
											>
												{(user?.email === 'test@stratf.com' &&
													item.title === 'Financial Projections' &&
													column?.pointsAllowed?.includes(i + 1)) ||
												(user?.email !== 'test@stratf.com' &&
													column?.pointsAllowed?.includes(i + 1)) ? (
													<LockOpenIcon
														fontSize="small"
														style={{ color: '#266696', height: 15, width: 15 }}
													/>
												) : user?.email === 'test@stratf.com' &&
												  item.title !== 'Financial Projections' ? (
													''
												) : (
													<LockIcon
														fontSize="small"
														style={{
															color: '#266696',
															height: 15,
															width: 15
														}}
													/>
												)}
												<span key={`span-${i}`} className={classes.liSpan}>
													{user?.email === 'test@stratf.com' &&
													item.title !== 'Financial Projections'
														? ''
														: item.title
														? item.title
														: item}
												</span>
											</a>
										</li>
									))}
								</ul>
							</Grid>
						</Grid>
					))}
				</Grid>
			</div>
		</div>
	);
};
export default PointsContainer;
