import { makeStyles } from '@material-ui/core';
import { upperHeader } from '../../../common/assets/layout';

const borderWhite = {
	content: '" "',
	position: 'absolute',
	height: upperHeader,
	width: 1,
	zIndex: 1
};

export const useStyles = makeStyles(({ breakpoints }) => ({
	button_typo: {
		fontSize: '14px'
	},
	button_icon: {
		fontSize: '12px'
	},
	popper: {
		border: '1px solid rgba(27,31,35,.15)',
		boxShadow: '0 3px 12px rgba(27,31,35,.15)',
		borderRadius: 0,
		[breakpoints.up('lg')]: {
			minWidth: 100
		},
		[breakpoints.down('lg')]: {
			minWidth: 85
		},
		zIndex: 99999,
		fontSize: '14px',
		color: '#000',
		backgroundColor: '#DEDEDE'
	}
}));

export const useTabsStyles = makeStyles(() => ({
	indicator: {
		display: 'none'
	}
}));

export const useTabStyles = makeStyles(({ breakpoints }) => {
	return {
		root: () => ({
			height: 28,
			marginTop: 30,
			opacity: 1,
			width: 104,
			borderRadius: '3px 3px 0 0',
			fontSize: '14px',
			overflow: 'initial',
			marginRight: 4,
			color: '#6E6F72',
			backgroundColor: '#DEDEDE',
			transition: '0.2s',
			minHeight: 28,
			[breakpoints.up('lg')]: {
				minWidth: 100
			},
			[breakpoints.down('lg')]: {
				minWidth: 85
			},
			'&:before': {
				transition: '0.2s'
			},
			'&:not(:first-of-type)': {
				'&:before': {
					...borderWhite,
					left: 0
				}
			},
			'&:first-of-type': {
				'&:before': {
					...borderWhite,
					left: 0
				}
			},
			'&:last-of-type': {
				'&:after': {
					...borderWhite,
					right: 0
				}
			},
			'&:hover': {
				color: '#ffffff',
				'&:not($selected)': {
					backgroundColor: '#1C79BE',
					color: '#ffffff'
				}
			}
		}),
		selected: () => ({
			backgroundColor: '#1C79BE',
			color: '#ffffff',
			'& + $root': {
				zIndex: 1
			}
		}),
		wrapper: {
			zIndex: 2,
			textTransform: 'initial'
		}
	};
});
