import React from 'react';
import { Tabs, Tab, Zoom } from '@material-ui/core';
import { useTabsStyles, useTabStyles } from './tabsStyles';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';
import { Link } from 'react-router-dom';
import { ContextMenuTrigger } from 'react-contextmenu';
import { useSelector } from 'react-redux';

function CloneProps(props) {
	const { children, ...other } = props;
	return children(other);
}

const a11yProps = (index) => {
	return {
		id: `full-width-tab-${index}`,
		'aria-controls': `full-width-tabpanel-${index}`
	};
};

const BarTabs = ({
	// tabs,
	originalTabs,
	// subTabs,
	tabStyle,
	tabProps,
	history,
	// match,
	// location,
	// children,
	// subHeader,
	onChange,
	value,
	setValue,
	...props
}) => {
	const tabsClasses = useTabsStyles(props);
	const tabClasses = useTabStyles({ ...tabProps, ...tabStyle });
	const user = useSelector((state) => state.auth.user);

	const handleChange = (event, newValue) => {
		setValue(newValue);
		onChange(newValue);
	};

	return (
		<div style={{ marginLeft: 0, marginTop: 3 }}>
			<Zoom in>
				<Tabs classes={tabsClasses} value={value} onChange={handleChange}>
					{originalTabs.map((tab, index) => {
						const firstActiveLink = originalTabs[index]?.content[
							Object.keys(originalTabs[index]?.content)[0]
						]?.subtabs
							.map((itemTab) => ({
								...itemTab,
								active:
									user && user[`allowed_section${index}`]?.includes(itemTab.id)
							}))
							.sort((a, b) => b.active - a.active)[0]?.link;
						return (
							<CloneProps key={index}>
								{(tabProps) => (
									<ContextMenuTrigger id={`context-menu-${index}`}>
										<Tab
											component={Link}
											to={firstActiveLink}
											index={index}
											key={index}
											{...tabProps}
											{...tab}
											classes={tabClasses}
											style={{
												fontSize: '12px',
												paddingInline: 0,
												width: 106.7,
												display:
													user?.allowed_pages?.includes(tabProps.value) ||
													tabProps.value === 0
														? 'block'
														: 'none'
											}}
											onClick={() => history.push(firstActiveLink)}
											{...a11yProps(index)}
										/>
									</ContextMenuTrigger>
								)}
							</CloneProps>
						);
					})}
				</Tabs>
			</Zoom>
		</div>
	);
};

BarTabs.propTypes = {
	tabs: PropTypes.arrayOf(
		PropTypes.shape({
			label: PropTypes.node.isRequired
		})
	),
	tabStyle: PropTypes.shape({
		bgColor: PropTypes.string,
		minWidth: PropTypes.shape({})
	}),
	tabProps: PropTypes.shape({})
};

BarTabs.defaultProps = {
	tabs: [],
	tabStyle: {},
	tabProps: {}
};

export default withRouter(BarTabs);
