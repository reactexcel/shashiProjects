import React, { useState } from 'react';
import { useStyles } from './autoMLTableStyle';
import { reduxForm } from 'redux-form';
import { Button } from '@material-ui/core';
import { Typography } from '@material-ui/core';
import InfoIcon from '@material-ui/icons/Info';
import { Field } from 'redux-form';
import MuiSelectField from '../../components/Select/Select';
import fullImage from '../../../common/assets/vector/images/automl_full.svg';

const AutoMLTable = () => {
	const classes = useStyles();
	const [port, setPort] = useState(false);
	const handlePortfolio = (e) => setPort(e.target.value);

	let portfolioData = [{ name: 'Portfolio 1' }];
	let keyData = [{ name: 'Key 1' }];
	let targetData = [{ name: 'Target 1' }];
	let minTimeData = [{ name: '30 sec' }];
	let maxTimeData = [{ name: '90 sec' }];
	return (
		<div className={classes.tableHeader}>
			<div
				style={{
					display: 'flex'
				}}
			>
				<Button className={classes.btn}>Train</Button>
				<Button className={classes.btn}>Test</Button>
			</div>
			<div style={{ display: 'flex' }}>
				<div className={classes.dropdownContainer}>
					<Typography
						variant="subtitle2"
						align="left"
						className={classes.dropdown}
					>
						Portfolio
					</Typography>

					<InfoIcon className={classes.selectIcon} />
					<Field
						name="Portfolio"
						label="Portfolio"
						required
						native={true}
						value={port}
						view={'lyar'}
						component={MuiSelectField}
						onChange={handlePortfolio}
					>
						{portfolioData &&
							portfolioData.map((op, index) => {
								return (
									<option key={index} value={op.id}>
										{op.name}
									</option>
								);
							})}
					</Field>
				</div>
				<div className={classes.dropdownContainer}>
					<Typography
						variant="subtitle2"
						align="left"
						className={classes.dropdown}
					>
						Minimum Time
					</Typography>

					<InfoIcon className={classes.selectIcon} />
					<Field
						name="minTime"
						label="Minimum Time"
						required
						native={true}
						value={port}
						view={'lyar'}
						component={MuiSelectField}
						onChange={handlePortfolio}
					>
						{minTimeData &&
							minTimeData.map((op, index) => {
								return (
									<option key={index} value={op.id}>
										{op.name}
									</option>
								);
							})}
					</Field>
				</div>
			</div>
			<div style={{ display: 'flex' }}>
				<div className={classes.dropdownContainer}>
					<Typography
						variant="subtitle2"
						align="left"
						className={classes.dropdown}
					>
						Primary Key
					</Typography>

					<InfoIcon className={classes.selectIcon} />
					<Field
						name="key"
						label="Primary Key"
						required
						native={true}
						value={port}
						view={'lyar'}
						component={MuiSelectField}
						onChange={handlePortfolio}
					>
						{keyData &&
							keyData.map((op, index) => {
								return (
									<option key={index} value={op.id}>
										{op.name}
									</option>
								);
							})}
					</Field>
				</div>
				<div className={classes.dropdownContainer}>
					<Typography
						variant="subtitle2"
						align="left"
						className={classes.dropdown}
					>
						Maximum Time
					</Typography>

					<InfoIcon className={classes.selectIcon} />
					<Field
						name="maxTime"
						label="Maximum Time"
						required
						native={true}
						value={port}
						view={'lyar'}
						component={MuiSelectField}
						onChange={handlePortfolio}
					>
						{maxTimeData &&
							maxTimeData.map((op, index) => {
								return (
									<option key={index} value={op.id}>
										{op.name}
									</option>
								);
							})}
					</Field>
				</div>
			</div>
			<div style={{ display: 'flex' }}>
				<div className={classes.dropdownContainer}>
					<Typography
						variant="subtitle2"
						align="left"
						className={classes.dropdown}
					>
						Target
					</Typography>

					<InfoIcon className={classes.selectIcon} />
					<Field
						name="target"
						label="target"
						required
						native={true}
						value={port}
						view={'lyar'}
						component={MuiSelectField}
						onChange={handlePortfolio}
					>
						{targetData &&
							targetData.map((op, index) => {
								return (
									<option key={index} value={op.id}>
										{op.name}
									</option>
								);
							})}
					</Field>
				</div>
			</div>

			<div style={{ display: 'flex' }}>
				<img src={fullImage} alt="" style={{ marginTop: 35, width: '70%' }} />
			</div>
		</div>
	);
};
export default reduxForm({ form: 'demo' })(AutoMLTable);
