import { Button } from '@material-ui/core';
import React from 'react';
import { useStyles } from '../portfolio/portfolioStyles';

const Timer = ({
	seconds,
	minutes,
	model,
	taskProgressPercent = null,
	status = null,
	timerOnSuccess
}) => {
	const classes = useStyles();
	if (
		['pending'].includes(('' + status).toLowerCase()) ||
		(['success'].includes(('' + status).toLowerCase()) && timerOnSuccess)
	)
		return (
			<Button
				style={{
					marginLeft: ['fpna1'].includes(model) ? '453px' : '373px',
					marginTop:
						model === 'prepayment'
							? 45
							: ['fpna2'].includes(model)
							? 10
							: [
									'fpna4',
									'fpna5',
									'fpna5-3-1-0',
									'fpna5-2-1-0',
									'fpna5-1-1-0',
									'fpna6',
									'fpna6-1-1',
									'fpna9',
									'fpna9-1-1',
									'fpna6-4-1',
									'fpna9-2-1',
									'fpna9-3-1',
									'fpna6-3-1',
									'fpna0',
									'fpna6-2-1'
							  ].includes(model)
							? -2
							: ['cashflow'].includes(model)
							? -102
							: ['fpna1'].includes(model)
							? -120
							: ['securitization', 'default', 'credit2'].includes(model)
							? 20
							: -54
				}}
				className={classes.header__save}
			>
				{taskProgressPercent != null && (
					<span style={{ fontSize: '12px' }}>
						{status === 'FAILURE' //&& showMessage(7000)
							? 'Failed'
							: status === 'SUCCESS' // && showMessage(7000)
							? 'Complete'
							: status === 'stopped' //&& showMessage(2000)
							? taskProgressPercent
							: taskProgressPercent}
					</span>
				)}
				{taskProgressPercent === null && (
					<>
						<span>0</span>
						<span>{minutes}</span>
						<span>:</span>
						{seconds < 10 && <span>0</span>}
						<span>{seconds}</span>
					</>
				)}
			</Button>
		);
	else return <></>;
};

export default Timer;
