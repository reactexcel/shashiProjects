import React, { PureComponent } from 'react';
import {
	AreaChart,
	Area,
	XAxis,
	YAxis,
	CartesianGrid,
	Tooltip,
	ResponsiveContainer,
	Legend,
	Brush
} from 'recharts';
import { primaryColor } from '../../../common/assets/layout';

const LineChart = ({
	dataT,
	nameLegend,
	sizeLegend = '14px',
	brushID,
	value,
	dataX,
	xDistance,
	format
}) => {
	const formatYAxis = (tickItem) => {
		if (format) return +tickItem;
		else return +tickItem;
	};

	// const formatXAxis = (tickItem) => {
	//     return (
	//         <>
	//         </>
	//     )
	// }

	class CustomizedXAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			let dateStr = ('' + payload.value).split('-');
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={-10}
						y={0}
						dy={16}
						textAnchor="center"
						fontSize={14}
						fill="#666"
					>
						{dateStr[0]}
					</text>
					<text
						x={-10}
						y={15}
						dy={16}
						textAnchor="center"
						fontSize={14}
						fill="#666"
					>
						{dateStr[1]}
					</text>
				</g>
			);
		}
	}

	class CustomizedYAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={-10}
						dy={16}
						textAnchor="end"
						fontSize={14}
						fill="#666"
					>
						{format === 'com'
							? Number(payload.value).toLocaleString()
							: `${payload.value} %`}
					</text>
				</g>
			);
		}
	}

	const renderTooltipContent = (o) => {
		const { payload, label } = o;
		return (
			<div style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
				<div style={{ fontSize: 14 }}>{`${label}`}</div>{' '}
				{payload.map((entry, index) => (
					<div
						key={`item-${index}1`}
						style={{ color: entry.color, fontSize: 14, padding: 5 }}
					>
						{`${entry.name} : ( ${Number(entry.value).toLocaleString()} )  `}
					</div>
				))}
			</div>
		);
	};

	return (
		<ResponsiveContainer width="100%" height="100%">
			<AreaChart
				data={dataT}
				syncId={brushID}
				margin={{ top: 0, right: 0, left: 0, bottom: 30 }}
			>
				{/* <Brush dataKey={`${dataX}`} height={16} y={xDistance} fill="#fff" /> */}
				{/* <Brush dataKey={`${dataX}`} height={20} y={xDistance} stroke="#000" tick={true}>
          <AreaChart data={dataT}
          >
            <Area
              type="monotone"
              dataKey={`${value}`}
              fill={"grey"}
              opacity={0.5}
              name={nameLegend}
              animationDuration={2000}
              dot
            />
          </AreaChart>
        </Brush> */}
				{/* <CartesianGrid /> */}
				{/* <XAxis dataKey={`${dataX}`} type='category' label={{ value: `${dataX}`, position: "insideBottomRight", dy: 0, dx: 10, angle: 90, }} textAnchor="end" angle={-30} style={{ fontSize: 12 }} /> */}
				<XAxis
					tickLine={true}
					dataKey={`${dataX}`}
					type="category"
					textAnchor="end"
					tickSize={6}
					tick={<CustomizedXAxisTick />}
				/>
				{/* <YAxis dataKey={`${value}`} type='number' label={{ value: "Value", position: "insideTopLeft", dy: -40, dx: 0, angle: 0, }} textAnchor="end" style={{ fontSize: 12 }} tickFormatter={formatYAxis}/> */}
				<YAxis
					tickLine={true}
					tickCount={7}
					dataKey={`${value}`}
					type="number"
					textAnchor="end"
					tickFormatter={formatYAxis}
					tick={<CustomizedYAxisTick />}
				/>
				<Tooltip content={renderTooltipContent} />
				<Area
					type="monotone"
					dataKey={`${value}`}
					stroke={'#1e76a9'}
					fill={'#e1eef7'}
					opacity={1}
					name={nameLegend}
					animationDuration={2000}
					strokeWidth={3}
					// dot
				/>
				<Legend
					verticalAlign="top"
					height={50}
					align="center"
					iconSize={0}
					wrapperStyle={{
						color: primaryColor,
						fontSize: sizeLegend,
						fontWeight: 600,
						letterSpacing: 1
					}}
				/>
			</AreaChart>
		</ResponsiveContainer>
	);
};

export default LineChart;
