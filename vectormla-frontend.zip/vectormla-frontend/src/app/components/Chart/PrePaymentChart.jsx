import React, { PureComponent } from 'react';
import {
	AreaChart,
	Area,
	XAxis,
	YAxis,
	Tooltip,
	ResponsiveContainer,
	Legend
	//Brush
} from 'recharts';
import { primaryColor } from '../../../common/assets/layout';

const Chart = ({
	dataT,
	nameLegend,
	sizeLegend = '18px',
	brushID,
	value,
	dataX,
	xDistance,
	interval = 1,
	format
}) => {
	const formatYAxis = (tickItem) => {
		if (format) return +tickItem;
		else return +tickItem;
	};

	class CustomizedXAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			let dateStr = ('' + payload.value).split('-');
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={0}
						dy={12}
						textAnchor="center"
						fontSize={12}
						fill="#666"
					>
						{dateStr[0]}
					</text>
					<text
						x={0}
						y={15}
						dy={12}
						textAnchor="center"
						fontSize={12}
						fill="#666"
					>
						{dateStr[1]}
					</text>
				</g>
			);
		}
	}

	class CustomizedYAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={-10}
						dy={16}
						textAnchor="end"
						fontSize={12}
						fill="#666"
					>
						{format === 'com'
							? Number(payload.value).toLocaleString()
							: `${payload.value} %`}
					</text>
				</g>
			);
		}
	}

	const renderTooltipContent = (o) => {
		const { payload, label } = o;
		return (
			<div style={{ backgroundColor: '#fff', border: '1px solid #000' }}>
				<div style={{ fontSize: 14 }}>{`${label}`}</div>{' '}
				{payload &&
					payload.map((entry, index) => (
						<div
							key={`item-${index}1`}
							style={{ color: entry.color, fontSize: 14, padding: 5 }}
						>
							{`${entry.name} : ( ${Number(entry.value).toLocaleString()} )  `}
						</div>
					))}
			</div>
		);
	};

	return (
		<ResponsiveContainer width="100%" height="100%">
			<AreaChart
				data={dataT}
				syncId={brushID}
				margin={{ top: 0, right: 30, left: 30, bottom: 30 }}
			>
				<XAxis
					tickLine={true}
					dataKey={`${dataX}`}
					type="category"
					textAnchor="end"
					tickSize={6}
					// tickCount={24}
					interval={interval}
					tick={<CustomizedXAxisTick />}
				/>
				<YAxis
					tickLine={true}
					tickCount={7}
					dataKey={`${value}`}
					type="number"
					textAnchor="end"
					tickFormatter={formatYAxis}
					tick={<CustomizedYAxisTick />}
				/>
				<Tooltip content={renderTooltipContent} />
				<Area
					type="monotone"
					dataKey={`${value}`}
					stroke={'#1e76a9'}
					fill={'#e1eef7'}
					opacity={1}
					name={nameLegend}
					animationDuration={2000}
					strokeWidth={3}
					// dot
				/>
				<Legend
					verticalAlign="top"
					height={50}
					align="center"
					iconSize={0}
					wrapperStyle={{
						color: primaryColor,
						fontSize: sizeLegend,
						fontWeight: 600,
						letterSpacing: 1,
						marginLeft: 25
					}}
				/>
				{/*<Brush dataKey={brushID} height={30} stroke="#8884d8" />*/}
			</AreaChart>
		</ResponsiveContainer>
	);
};

export default Chart;
