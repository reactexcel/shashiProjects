import React, { PureComponent } from 'react';
import {
	AreaChart,
	Area,
	XAxis,
	YAxis,
	Tooltip,
	ResponsiveContainer,
	Legend
} from 'recharts';
import { primaryColor } from '../../../common/assets/layout';

const LineChart = ({
	dataT,
	nameLegend,
	sizeLegend = '14px',
	brushID,
	value,
	dataX,
	xDistance,
	format,
	maxY,
	minX = 0
}) => {
	const formatYAxis = (tickItem) => {
		if (format) return +tickItem;
		else return +tickItem;
	};

	class CustomizedXAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			let dateStr = ('' + payload.value).split('-');
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={-10}
						y={0}
						dy={16}
						textAnchor="center"
						fontSize={14}
						fill="#666"
					>
						{dateStr[0]}
					</text>
					<text
						x={-10}
						y={15}
						dy={16}
						textAnchor="center"
						fontSize={14}
						fill="#666"
					>
						{dateStr[1]}
					</text>
				</g>
			);
		}
	}

	class CustomizedYAxisTick extends PureComponent {
		render() {
			const { x, y, payload } = this.props;
			return (
				<g transform={`translate(${x},${y})`}>
					<text
						x={0}
						y={-10}
						dy={16}
						textAnchor="end"
						fontSize={14}
						fill="#666"
					>
						{format === 'com'
							? Number(payload.value).toLocaleString()
							: `${payload.value} %`}
					</text>
				</g>
			);
		}
	}

	return (
		<ResponsiveContainer width="100%" height="100%">
			<AreaChart
				data={dataT}
				syncId={brushID}
				margin={{ top: 0, right: 0, left: 0, bottom: 30 }}
			>
				<XAxis
					tickLine={true}
					dataKey={`${dataX}`}
					type="number"
					domain={[0, 10]}
					textAnchor="end"
					tickSize={6}
					tick={<CustomizedXAxisTick />}
				/>
				<YAxis
					tickLine={true}
					tickCount={7}
					dataKey={`${value}`}
					domain={[0, maxY]}
					type="number"
					textAnchor="end"
					tickFormatter={formatYAxis}
					tick={<CustomizedYAxisTick />}
				/>
				<Tooltip />
				<Area
					type="monotone"
					dataKey={`${value}`}
					stroke={'#1e76a9'}
					fill={'#e1eef7'}
					opacity={1}
					name={nameLegend}
					animationDuration={2000}
					strokeWidth={3}
				/>
				<Legend
					verticalAlign="top"
					height={50}
					align="center"
					iconSize={0}
					wrapperStyle={{
						color: primaryColor,
						fontSize: 13,
						fontWeight: 600,
						letterSpacing: 1,
						marginLeft: 25
					}}
				/>
			</AreaChart>
		</ResponsiveContainer>
	);
};

export default LineChart;
