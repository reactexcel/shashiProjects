import React from 'react';

function NumberOfLoans() {
	const sampleData = [
		[
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			}
		],
		[
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			}
		],

		[
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			}
		],
		[
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			}
		],
		[
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			},
			{
				title: 'Total Number of Loans',
				amount: '$59.213.431'
			}
		]
	];

	return (
		<div className="numberOfLoansContainer">
			{sampleData.map((column, columnIndex) => {
				return (
					<div className="numberOfLoansColumn leftBorderBlue" key={columnIndex}>
						{column.map((row, rowIndex) => {
							return (
								<div className="numberOfLoansRow" key={rowIndex}>
									<p className="numberLoanTitle">{row.title}</p>
									<p className="numberLoanAmount">{row.amount}</p>
								</div>
							);
						})}
					</div>
				);
			})}
		</div>
	);
}

export default NumberOfLoans;
