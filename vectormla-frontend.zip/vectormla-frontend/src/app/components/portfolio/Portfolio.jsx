import React, { useState, useEffect } from 'react';
import {
	Button,
	OutlinedInput,
	Typography,
	Divider,
	CircularProgress,
	ClickAwayListener
} from '@material-ui/core';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import InfoIcon from '@material-ui/icons/Info';
import { withRouter } from 'react-router-dom';
import { Field, reduxForm } from 'redux-form';
import { useStyles } from './portfolioStyles';
import AddPortfolioDialog from './AddPortfolioDialog';
import downArrow from '../../../common/assets/vector/images/arrow.svg';
import pen_logo from '../../../common/assets/images/Pen4.png';
import Timer from '../timer/Timer';
import Stopwatch from '../counter/Stopwatch';
import KillTask from '../killTask/KillTask';
import KillTaskDialog from './KillTaskDialog';
import { DarkCheckbox } from 'app/CashFlow/cashFlowStyles';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { useSelector } from 'react-redux';
import { Select } from 'antd';
import AntdSelect from '../Select/antdSelect';
import NumberOfLoans from './NumberOfLoans';
const { Option } = Select;

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

export const CheckField = ({ item, updateSegment }) => {
	const classes = useStyles();
	const [checked, setChecked] = useState(item?.is_included);
	return (
		<div
			style={{
				display: 'flex',
				justifyContent: 'flex-start',
				gap: 10,
				alignItems: 'center'
			}}
		>
			<DarkCheckbox
				icon={icon}
				checkedIcon={checkedIcon}
				checked={checked}
				onChange={() => {
					updateSegment(item?.id, {
						is_included: !checked
					});
					setChecked(!checked);
				}}
			/>
			<Typography className={classes.segment_checkLabel}>
				{item?.field_value_str}
			</Typography>
		</div>
	);
};
export const PopoverPopupState = ({ name, data, updateSegment }) => {
	const classes = useStyles();
	const [open, setOpen] = useState(false);
	const handleClick = () => setOpen((prev) => !prev);
	const handleClickAway = () => setOpen(false);

	return (
		<ClickAwayListener
			mouseEvent="onMouseDown"
			touchEvent="onTouchStart"
			onClickAway={handleClickAway}
		>
			<div className={classes.segmentRoot}>
				<div className={classes.segmentSelect} onClick={handleClick}>
					{name}
					<ExpandMoreIcon />
				</div>
				{open && data.length > 0 ? (
					<div className={classes.segmentDropdown}>
						{data.map((item) => {
							return (
								<CheckField
									key={item?.id}
									item={item}
									updateSegment={updateSegment}
								/>
							);
						})}
					</div>
				) : null}
			</div>
		</ClickAwayListener>
	);
};

const RenderInputField = ({
	meta: { touched, invalid, error },
	input,
	name,
	type,
	disabled,
	placeholder
}) => {
	const classes = useStyles();

	return (
		<>
			<div style={{ fontSize: '11px', marginBottom: 8 }}>{placeholder}</div>
			<OutlinedInput
				disabled={disabled}
				required
				className={classes.login__input}
				name={name}
				type={type}
				helpertext={touched ? error : ''}
				error={touched && invalid}
				{...input}
			/>
		</>
	);
};

const Portfolio = ({
	senarioData,
	portfolioList,
	port,
	id,
	scenario,
	setScenario,
	setSelectedSubPorofolio,
	setPortfolio,
	fetchTableData,
	subPotofoliosData,
	segmentData,
	handleSave,
	create,
	upload,
	update,
	deleteObj,
	data,
	setData,
	selectedData,
	onScenarioRun,
	collapsed,
	scenarioField,
	downloadFile,
	downloadCustomReports,
	downloadTemplate,
	scenarioName,
	fileUrl,
	loading,
	fileName,
	seconds,
	minutes,
	status,
	key,
	version,
	model,
	taskProgressPercent,
	killTaskFunction,
	updateSegment,
	runningTaskId,
	runCalculateFunction,
	timerStarted,
	dispatchClean
}) => {
	const classes = useStyles();
	const user = useSelector((state) => state.auth.user);
	const [visible, setVisible] = useState(false);
	const [taskDialogVisible, setTaskDialogVisible] = useState(false);
	const [openPortfolio, setOpenPortfolio] = useState(false);
	const [openSubPortfolio, setOpenSubPortfolio] = useState(false);
	const [timerOnSuccess, setTimerOnSuccess] = useState(false);
	const [customSelect, seCustomSelect] = useState('report_loandata');
	const [customSelect2, seCustomSelect2] = useState('report_multiple');
	const [customSelect3, seCustomSelect3] = useState('bb_report_xlsx');
	const [customSelect6_3_1, seCustomSelect6_3_1] = useState('report_multiple');
	const [customSelect6_1_1, seCustomSelect6_1_1] = useState('report_sofr');
	const [customSelect6_2_1, setCustomSelect6_2_1] =
		useState('static_pool_loss');
	let timer = null;

	useEffect(() => {
		if (collapsed >= 1) {
			setOpenPortfolio(true);
			setOpenSubPortfolio(true);
		} else if (collapsed === 0 && openPortfolio) {
			setOpenPortfolio(false);
			setOpenSubPortfolio(false);
		}
	}, [collapsed]);

	useEffect(() => {
		timerStarted && setOpenPortfolio(true);
	}, [timerStarted]);

	useEffect(() => {
		!(
			[
				'fpna3',
				'fpna4',
				'fpna5',
				'fpna5-3-1',
				'fpna5-1-1',
				'fpna5-2-1-0',
				'fpna6',
				'fpna6-1-1',
				'fpna6-2-1',
				'fpna6-3-1',
				'fpna5-3-1-0',
				'fpna5-2-1-0',
				'fpna5-1-1-0',
				'fpna9',
				'fpna9-1-1',
				'fpna6-4-1',
				'fpna9-2-1',
				'fpna9-3-1',
				'fpna0',
				'fpna6-3'
			].includes(model) &&
			['pending', 'success'].includes(('' + status).toLowerCase())
		) &&
			runningTaskId &&
			localStorage.removeItem(`fbna5/${user?.id}/${runningTaskId}`);
	}, [
		[
			'fpna3',
			'fpna4',
			'fpna5',
			'fpna5-3-1',
			'fpna5-1-1',
			'fpna6',
			'fpna6-1-1',
			'fpna9',
			'fpna9-1-1',
			'fpna6-4-1',
			'fpna9-2-1',
			'fpna9-3-1',
			'fpna0',
			'fpna6-3',
			'fpna5-3-1-0',
			'fpna5-2-1-0',
			'fpna5-1-1-0',
			'fpna6-3-1',
			'fpna6-2-1'
		].includes(model) &&
			['pending', 'success'].includes(('' + status).toLowerCase())
	]);

	useEffect(() => {
		if (status === 'SUCCESS') {
			let start = new Date();
			setTimerOnSuccess(true);
			let initTimer = 0;
			timer = setInterval(() => {
				if (initTimer === 5) {
					setTimerOnSuccess(false);
					clearInterval(timer);
				}
				let current = new Date();
				initTimer = Math.floor((+current - +start) / 1000) % 60;
			}, 1000);
		}
		return () => {
			clearInterval(timer);
		};
	}, [status]);

	const handleRun = () => {
		const selectedScenario = senarioData.find(
			(se) => se[scenarioField] === scenario
		);

		fetchTableData(selectedScenario.id, selectedScenario.assumption);
	};

	const prepareFile = (file) => {
		let formData = new FormData();
		formData.append('file', file);
		return formData;
	};
	const uploadFile = (e) => {
		const formData = prepareFile(e.target?.files[0]);
		upload(formData);
		e.target.value = '';
	};

	const downloadTemplateFE = () => {
		let a = document.createElement('a');
		a.href = fileUrl;
		a.download = fileName;
		a.click();
		a.remove();
	};

	return (
		<div>
			{loading && (
				<div className={classes.progressContainer}>
					<CircularProgress
						style={{ color: '#266696', marginTop: version ? 15 : 0 }}
						size={26}
					/>
				</div>
			)}
			{version && (
				<div style={{ fontSize: '12px' }}>Release Date: {version} </div>
			)}
			<div
				className={classes.contentHeaderContainer}
				onClick={() => setOpenPortfolio(!openPortfolio)}
			>
				{/* This here is for Portfolio Collapsable (Commented out <p className={classes.contentHeader}>Portfolio</p>
				<img src={downArrow} style={{ justifyContent: 'flex-end' }} alt="" />*/}
			</div>
			{/*<Divider style={{ marginBottom: 20 }} />*/}
			<div style={{ marginBottom: 20 }}></div>
			{!openPortfolio && (
				<div
					className={`${classes.root2} leftBorderBlue`}
					style={{ border: '10x solid blue', marginLeft: '-20px' }}
				>
					{visible && (
						<AddPortfolioDialog
							open={visible}
							handleClose={() => setVisible(false)}
							deleteObj={() => deleteObj()}
							create={(name, file) => {
								const formData = prepareFile(file);
								create(name, formData);
							}}
							update={(name, callback) => {
								update(name, callback);
							}}
						/>
					)}
					{taskDialogVisible && (
						<KillTaskDialog
							open={taskDialogVisible}
							handleClose={() => setTaskDialogVisible(false)}
							kill={() => killTaskFunction(() => setTaskDialogVisible(false))}
						/>
					)}
					<div
						style={{ display: 'flex', alignItems: 'center', marginBottom: -10 }}
					>
						<Typography
							variant="subtitle2"
							align="left"
							className={classes.label}
							style={
								downloadCustomReports
									? {
											width: 100,
											fontSize: '13px',
											color: '#2e628d',
											fontWeight: 'bold'
									  }
									: {
											minWidth: 100,
											fontSize: '13px',
											color: '#2e628d',
											fontWeight: 'bold'
									  }
							}
						>
							Portfolio
						</Typography>
						{/*<InfoIcon className={classes.selectIcon} />*/}
						<AntdSelect
							native={false}
							defaultValue={+port}
							change={(e) => {
								dispatchClean && dispatchClean();
								setPortfolio(e?.target?.value || e);
							}}
						>
							{portfolioList &&
								portfolioList.map((op, index) => (
									<Option key={index} value={+op.id} title={op.name}>
										<div
											style={{
												display: 'flex',
												alignItems: 'center',
												justifyContent: 'space-between',
												width: '100%'
											}}
										>
											{/* Option Text */}
											<div
												style={{
													flexGrow: 1,
													overflow: 'hidden',
													whiteSpace: 'nowrap',
													textOverflow: 'ellipsis'
												}}
											>
												{op.name}
											</div>

											{/* Edit Icon */}

											<img
												src={pen_logo}
												alt="Edit"
												title="Edit Portfolio Name"
												style={{
													cursor: 'pointer',
													width: '12px',
													height: '12px'
												}}
												onClick={() => setVisible('edit')}
											/>
										</div>
									</Option>
								))}
						</AntdSelect>
						{create && (
							<div
								style={{
									display: 'flex'
								}}
							>
								<Button
									className={classes.header__save}
									onClick={() => setVisible('create')}
									style={{
										marginLeft: 57,
										fontSize: '11px',
										marginTop:
											model === 'fpna6' ||
											model === 'fpna6-1-1' ||
											model === 'fpna6-2-1' ||
											model === 'fpna6-3-1' ||
											model === 'fpna5-3-1-0' ||
											model === 'fpna5-3-1' ||
											model === 'fpna5-2-1-0' ||
											model === 'fpna5-1-1-0' ||
											model === 'fpna6-3' ||
											model === 'fpna9-2-1' ||
											model === 'fpna9-1-1' ||
											model === 'fpna6-4-1' ||
											model === 'fpna5' ||
											model === 'fpna5-1-1' ||
											model === 'fpna9-3-1' ||
											model === 'fpna9'
												? 10
												: 0
									}}
								>
									Create
								</Button>
								{model !== 'fpna5' &&
									model !== 'fpna5-3-1' &&
									model !== 'fpna5-1-1' &&
									model !== 'fpna6' &&
									model !== 'fpna6-1-1' &&
									model !== 'fpna6-2-1' &&
									model !== 'fpna6-3-1' &&
									model !== 'fpna6-3' &&
									model !== 'fpna5-3-1-0' &&
									model !== 'fpna5-2-1-0' &&
									model !== 'fpna5-1-1-0' &&
									model !== 'fpna9' &&
									model !== 'fpna9-1-1' &&
									model !== 'fpna6-4-1' &&
									model !== 'fpna9-2-1' &&
									model !== 'fpna9-3-1' &&
									model !== 'fpna0' && (
										<Button
											className={classes.header__save}
											onClick={() => setVisible('edit')}
											disabled={portfolioList.length === 0 || !portfolioList}
											style={{ fontSize: '11px' }}
										>
											Edit
										</Button>
									)}
								{model !== 'fpna6' &&
								model !== 'fpna6-1-1' &&
								model !== 'fpna6-2-1' &&
								model !== 'fpna6-3-1' &&
								model !== 'fpna5-3-1-0' &&
								model !== 'fpna5-2-1-0' &&
								model !== 'fpna5-1-1-0' &&
								model !== 'fpna9' &&
								model !== 'fpna9-1-1' &&
								model !== 'fpna6-4-1' &&
								model !== 'fpna5' &&
								model !== 'fpna5-3-1' &&
								model !== 'fpna5-1-1' &&
								model !== 'fpna9-2-1' &&
								model !== 'fpna9-3-1' &&
								model !== 'fpna6-3' ? (
									<Button
										className={classes.header__save}
										onClick={() => setVisible('delete')}
										disabled={portfolioList.length === 0 || !portfolioList}
										style={{ fontSize: '11px' }}
									>
										Delete
									</Button>
								) : (
									<label htmlFor="xlsx-upload">
										<Button
											className={classes.header__save}
											style={{
												fontSize: '11px',
												marginTop: '10px'
											}}
											component="span"
											disabled={portfolioList?.length === 0 || !portfolioList}
										>
											Upload
										</Button>
									</label>
								)}
							</div>
						)}
					</div>
					{upload && (
						<div
							style={{
								display: 'flex',
								alignItems: 'center',
								flexWrap: 'wrap',
								marginBottom:
									model === 'prepayment'
										? -37
										: ['cashflow', 'fpna0'].includes(model)
										? -34
										: [
												'fpna6',
												'fpna6-1-1',
												'fpna9',
												'fpna9-1-1',
												'fpna6-4-1',
												'fpna5',
												'fpna5-3-1',
												'fpna5-1-1',
												'fpna9-2-1',
												'fpna9-3-1',
												'fpna6-3',
												'fpna5-3-1-0',
												'fpna5-2-1-0',
												'fpna5-1-1-0',
												'fpna6-2-1',
												'fpna6-3-1'
										  ].includes(model)
										? 10
										: -10,
								marginLeft: ['fpna1', 'fpna2', 'fpna3', 'fpna4'].includes(model)
									? 0
									: model === 'fpna5-1-1-0'
									? -9
									: model === 'fpna0'
									? 592
									: model === 'fpna6' ||
									  model === 'fpna6-1-1' ||
									  model === 'fpna6-2-1' ||
									  model === 'fpna6-3-1' ||
									  model === 'fpna5-3-1' ||
									  model === 'fpna5-3-1-0' ||
									  model === 'fpna5-2-1-0' ||
									  model === 'fpna9' ||
									  model === 'fpna9-1-1' ||
									  model === 'fpna6-4-1' ||
									  model === 'fpna5' ||
									  model === 'fpna5-1-1' ||
									  model === 'fpna9-2-1' ||
									  model === 'fpna9-3-1' ||
									  model === 'fpna6-3'
									? 33
									: 52
							}}
						>
							{[
								'prepayment',
								'cashflow',
								'securitization',
								'default',
								'credit2',
								'fpna5',
								'fpna5-3-1',
								'fpna5-1-1',
								'fpna6',
								'fpna6-1-1',
								'fpna6-2-1',
								'fpna6-3-1',
								'fpna5-3-1-0',
								'fpna5-2-1-0',
								'fpna5-1-1-0',
								'fpna6-3',
								'fpna9',
								'fpna9-1-1',
								'fpna6-4-1',
								'fpna9-2-1',
								'fpna9-3-1',
								'fpna0'
							].includes(model) ? (
								<></>
							) : (
								<>
									<Typography
										variant="subtitle2"
										align="left"
										className={classes.label}
										style={
											downloadCustomReports
												? {
														width: 100
												  }
												: { minWidth: 100 }
										}
									>
										Data
									</Typography>
									{/*<InfoIcon className={classes.selectIcon} />*/}
									<AntdSelect
										defaultValue={selectedData}
										change={(e) => setData && setData(e?.target?.value || e)}
									>
										{data?.map((item) => (
											<Option key={item.key} value={item.key}>
												{item.value}
											</Option>
										))}
									</AntdSelect>
								</>
							)}
							{portfolioList && portfolioList.length > 0 && (
								<input
									accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
									id="xlsx-upload"
									type="file"
									hidden
									onChange={(e) => uploadFile(e)}
								/>
							)}
							<label
								htmlFor="xlsx-upload"
								style={{
									margin: 0,
									marginLeft: [
										'fpna6',
										'fpna6-1-1',
										'fpna9',
										'fpna9-1-1',
										'fpna6-4-1',
										'fpna5',
										'fpna5-3-1',
										'fpna5-1-1',
										'fpna9-2-1',
										'fpna9-3-1',
										'fpna6-3',
										'fpna5-3-1-0',
										'fpna5-2-1-0',
										'fpna5-1-1-0',
										'fpna6-2-1',
										'fpna6-3-1'
									].includes(model)
										? 501
										: [
												'prepayment',
												'credit2',
												'fpna0',
												'default',
												'cashflow',
												'securitization'
										  ].includes(model)
										? '-262px'
										: 57,
									marginTop: [
										'prepayment',
										'cashflow',
										'securitization',
										'default',
										'credit2',
										'fpna0'
									].includes(model)
										? 10
										: [
												'fpna6',
												'fpna6-1-1',
												'fpna9',
												'fpna9-1-1',
												'fpna6-4-1',
												'fpna5',
												'fpna5-3-1',
												'fpna5-1-1',
												'fpna9-2-1',
												'fpna9-3-1',
												'fpna6-3',
												'fpna5-3-1-0',
												'fpna5-2-1-0',
												'fpna5-1-1-0',
												'fpna6-2-1',
												'fpna6-3-1'
										  ].includes(model)
										? -26
										: 0
								}}
							>
								{model !== 'fpna6' &&
								model !== 'fpna6-1-1' &&
								model !== 'fpna6-2-1' &&
								model !== 'fpna6-3-1' &&
								model !== 'fpna5-3-1-0' &&
								model !== 'fpna5-2-1-0' &&
								model !== 'fpna5-1-1-0' &&
								model !== 'fpna9' &&
								model !== 'fpna9-1-1' &&
								model !== 'fpna6-4-1' &&
								model !== 'fpna5' &&
								model !== 'fpna5-3-1' &&
								model !== 'fpna5-1-1' &&
								model !== 'fpna9-2-1' &&
								model !== 'fpna9-3-1' &&
								model !== 'fpna6-3' ? (
									<Button
										className={classes.header__save}
										style={{
											fontSize: '11px',
											marginLeft:
												model === 'fpna0'
													? '2px'
													: [
															'fpna',
															'fpna1',
															'fpna2',
															'fpna3',
															'fpna4'
													  ].includes(model)
													? '0px'
													: '542px'
										}}
										component="span"
										disabled={portfolioList.length === 0 || !portfolioList}
									>
										Upload
									</Button>
								) : (
									model !== 'fpna9' &&
									model !== 'fpna9-1-1' &&
									model !== 'fpna6-4-1' &&
									model !== 'fpna6-1-1' &&
									model !== 'fpna6-2-1' &&
									model !== 'fpna6-3-1' &&
									model !== 'fpna9-2-1' &&
									model !== 'fpna5-3-1-0' &&
									model !== 'fpna5-2-1-0' &&
									model !== 'fpna5-1-1-0' &&
									model !== 'fpna9-3-1' && (
										<Button
											className={classes.header__save}
											onClick={() => setVisible('delete')}
											disabled={portfolioList.length === 0 || !portfolioList}
											style={{ fontSize: '11px', marginTop: 2 }}
										>
											Delete
										</Button>
									)
								)}
							</label>
							<Button
								style={{
									fontSize: '11px',
									marginLeft:
										model === 'fpna9' ||
										model === 'fpna9-1-1' ||
										model === 'fpna6-4-1' ||
										model === 'fpna6-1-1' ||
										model === 'fpna6-2-1' ||
										model === 'fpna6-3-1' ||
										model === 'fpna9-2-1' ||
										model === 'fpna5-3-1-0' ||
										model === 'fpna5-2-1-0' ||
										model === 'fpna5-1-1-0' ||
										model === 'fpna9-3-1'
											? -160
											: '',
									marginTop: [
										'prepayment',
										'cashflow',
										'securitization',
										'default',
										'credit2',
										'fpna0'
									].includes(model)
										? 10
										: [
												'fpna6',
												'fpna6-1-1',
												'fpna9',
												'fpna9-1-1',
												'fpna6-4-1',
												'fpna5',
												'fpna5-3-1',
												'fpna5-1-1',
												'fpna9-2-1',
												'fpna9-3-1',
												'fpna6-3',
												'fpna5-3-1-0',
												'fpna5-2-1-0',
												'fpna5-1-1-0',
												'fpna6-2-1',
												'fpna6-3-1'
										  ].includes(model)
										? -24
										: 0
								}}
								disabled={['PENDING', 'pending'].includes(status)}
								className={classes.header__save}
								onClick={() => downloadFile()}
							>
								{model !== 'fpna6' &&
								model !== 'fpna6-1-1' &&
								model !== 'fpna9' &&
								model !== 'fpna9-1-1' &&
								model !== 'fpna6-4-1' &&
								model !== 'fpna5' &&
								model !== 'fpna5-3-1' &&
								model !== 'fpna5-1-1' &&
								model !== 'fpna9-2-1' &&
								model !== 'fpna9-3-1' &&
								model !== 'fpna6-3' &&
								model !== 'fpna5-3-1-0' &&
								model !== 'fpna5-2-1-0' &&
								model !== 'fpna5-1-1-0' &&
								model !== 'fpna6-3-1' &&
								model !== 'fpna6-2-1'
									? 'download'
									: 'Template'}
							</Button>
							{model !== 'fpna5' &&
								model !== 'fpna5-3-1' &&
								model !== 'fpna5-1-1' &&
								model !== 'fpna6' &&
								model !== 'fpna6-1-1' &&
								model !== 'fpna6-3' &&
								model !== 'fpna5-3-1-0' &&
								model !== 'fpna5-2-1-0' &&
								model !== 'fpna5-1-1-0' &&
								model !== 'fpna6-3-1' &&
								model !== 'fpna6-2-1' &&
								model !== 'fpna9' &&
								model !== 'fpna9-1-1' &&
								model !== 'fpna6-4-1' &&
								model !== 'fpna9-2-1' &&
								model !== 'fpna9-3-1' &&
								model !== 'fpna0' && (
									<Button
										style={{
											fontSize: '11px',
											marginTop: [
												'prepayment',
												'cashflow',
												'securitization',
												'default',
												'credit2',
												'fpna6',
												'fpna6-1-1',
												'fpna6-2-1',
												'fpna6-3-1',
												'fpna5-3-1-0',
												'fpna5-2-1-0',
												'fpna5-1-1-0',
												'fpna6-3',
												'fpna9',
												'fpna9-1-1',
												'fpna6-4-1',
												'fpna5',
												'fpna5-3-1',
												'fpna5-1-1',
												'fpna9-2-1',
												'fpna9-3-1',
												'fpna0'
											].includes(model)
												? 10
												: 0
										}}
										className={classes.header__save}
										onClick={() =>
											downloadTemplate
												? downloadTemplate()
												: downloadTemplateFE()
										}
									>
										template
									</Button>
								)}
						</div>
					)}
					{model !== 'fpna5' &&
						model !== 'fpna5-3-1' &&
						model !== 'fpna5-1-1' &&
						model !== 'fpna6' &&
						model !== 'fpna6-1-1' &&
						model !== 'fpna6-2-1' &&
						model !== 'fpna6-3-1' &&
						model !== 'fpna5-3-1-0' &&
						model !== 'fpna5-2-1-0' &&
						model !== 'fpna5-1-1-0' &&
						model !== 'fpna6-3' &&
						model !== 'fpna9' &&
						model !== 'fpna9-1-1' &&
						model !== 'fpna6-4-1' &&
						model !== 'fpna9-2-1' &&
						model !== 'fpna9-3-1' &&
						model !== 'fpna0' &&
						downloadCustomReports && (
							<div
								style={{
									display: 'flex',
									alignItems: 'center',
									flexWrap: 'wrap',
									marginBottom: -10
								}}
							>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
									style={{
										width: 100,
										minWidth: 100
									}}
								>
									Custom Reports
								</Typography>
								{/*<InfoIcon className={classes.selectIcon} />*/}
								<AntdSelect
									defaultValue={selectedData}
									change={(e) => setData && setData(e?.target?.value || e)}
								>
									<Option value={selectedData}>
										{/*model.includes('fpna3') ? 'Reports' : 'Asset and Pipeline'*/}
										{model.includes('fpna3') ? '1' : 'Asset and Pipeline'}
									</Option>
								</AntdSelect>

								<label htmlFor="xlsx-upload" style={{ margin: 0 }}>
									<Button
										style={{
											marginLeft: 57,
											fontSize: '11px'
										}}
										className={classes.header__save}
										onClick={() => downloadCustomReports()}
										disabled={portfolioList.length === 0 || !portfolioList}
									>
										download
									</Button>
								</label>
							</div>
						)}
					{!segmentData && (
						<div>
							{model !== 'fpna6' &&
								model !== 'fpna6-1-1' &&
								model !== 'fpna6-2-1' &&
								model !== 'fpna6-3-1' &&
								model !== 'fpna9' &&
								model !== 'fpna9-1-1' &&
								model !== 'fpna6-4-1' &&
								model !== 'fpna5' &&
								model !== 'fpna5-3-1' &&
								model !== 'fpna5-1-1' &&
								model !== 'fpna9-2-1' &&
								model !== 'fpna9-3-1' &&
								model !== 'fpna6-3' &&
								model !== 'fpna5-3-1-0' &&
								model !== 'fpna5-2-1-0' &&
								model !== 'fpna5-1-1-0' &&
								scenario && (
									<div
										style={{
											display: 'flex',
											alignItems: 'center',
											flexWrap: 'wrap',
											marginBottom: downloadCustomReports ? -10 : 50
										}}
									>
										<Typography
											variant="subtitle2"
											align="left"
											className={classes.label}
											style={
												downloadCustomReports
													? {
															width: 100
													  }
													: { minWidth: 100 }
											}
										>
											{scenarioName}
										</Typography>
										{/*<InfoIcon className={classes.selectIcon} />*/}
										<AntdSelect
											defaultValue={+id}
											change={(e) =>
												setScenario(
													senarioData.filter(
														(s) => s.id == (e?.target?.value || e)
													)[0]
												)
											}
										>
											{(senarioData || []).map((op, index) => {
												return (
													<Option key={index} value={+op.id}>
														{op.displayName
															? op.displayName
															: op[scenarioField]}
													</Option>
												);
											})}
										</AntdSelect>
										{onScenarioRun && (
											<Button
												className={classes.header__save}
												style={{ marginLeft: 57 }}
												onClick={() => {
													onScenarioRun();
												}}
											>
												run
											</Button>
										)}
									</div>
								)}
						</div>
					)}
					{(model === 'fpna5' ||
						model === 'fpna5-3-1' ||
						model === 'fpna5-1-1' ||
						model === 'fpna6' ||
						model === 'fpna6-1-1' ||
						model === 'fpna6-2-1' ||
						model === 'fpna6-3-1' ||
						model === 'fpna5-3-1-0' ||
						model === 'fpna5-2-1-0' ||
						model === 'fpna5-1-1-0' ||
						model === 'fpna6-3' ||
						model === 'fpna9' ||
						model === 'fpna9-1-1' ||
						model === 'fpna6-4-1' ||
						model === 'fpna9-2-1' ||
						model === 'fpna9-3-1' ||
						model === 'fpna0') &&
						downloadCustomReports && (
							<div
								style={{
									display: 'flex',
									alignItems: 'center',
									flexWrap: 'wrap',
									marginBottom: -10,
									marginTop:
										model === 'fpna6' ||
										model === 'fpna6-1-1' ||
										model === 'fpna6-2-1' ||
										model === 'fpna6-3-1' ||
										model === 'fpna6-3' ||
										model === 'fpna5-3-1-0' ||
										model === 'fpna5-2-1-0' ||
										model === 'fpna5-1-1-0' ||
										model === 'fpna9-1-1' ||
										model === 'fpna6-4-1' ||
										model === 'fpna5' ||
										model === 'fpna5-3-1' ||
										model === 'fpna5-1-1' ||
										model === 'fpna9-2-1' ||
										model === 'fpna9-3-1' ||
										model === 'fpna9'
											? -10
											: 0
								}}
							>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
									style={{
										width: 100,
										minWidth: 100,
										color: '#2e628d',
										fontWeight: 'bold',
										fontSize: '13px'
									}}
								>
									Reports
								</Typography>
								{/*<InfoIcon className={classes.selectIcon} />*/}
								{model === 'fpna0' && (
									<AntdSelect
										defaultValue={customSelect}
										change={(e) => seCustomSelect(e?.target?.value || e)}
									>
										<Option value="report_loandata">Mortgage Book Data</Option>
										<Option value="report_termschedule">
											Term Deposit Data
										</Option>
										<Option value="report_randomloandaily">
											Daily Loan Amortization
										</Option>
										<Option value="report_multiple">Summary Report</Option>
									</AntdSelect>
								)}

								{(model === 'fpna5-1-1-0' ||
									model === 'fpna5-3-1-0' ||
									model === 'fpna5-2-1-0' ||
									model === 'fpna5') && (
									<AntdSelect
										defaultValue={customSelect2}
										change={(e) => seCustomSelect2(e?.target?.value || e)}
									>
										<Option value="report_multiple">Summary Report</Option>
									</AntdSelect>
								)}
								{model === 'fpna5-3-1' && (
									<AntdSelect
										defaultValue={customSelect2}
										change={(e) => seCustomSelect2(e?.target?.value || e)}
									>
										<Option value="report_multiple">Summary Report</Option>
										<Option value="report_loandata">Mortgage Book Data</Option>
										<Option value="report_termschedule">
											Term Deposit Data
										</Option>
									</AntdSelect>
								)}

								{(model === 'fpna6' || model === 'fpna9') && (
									<AntdSelect
										defaultValue={customSelect2}
										change={(e) => seCustomSelect2(e?.target?.value || e)}
									>
										<Option value="report_multiple">Summary Report</Option>
										<Option value="report_optimized_scenario">
											Optimization Report
										</Option>
										<Option value="static_pool_loss">
											Static Pool Loss - Disbursement Date
										</Option>
										<Option value="static_pool_loss2">
											Static Pool Loss - Created Date
										</Option>
										<Option value="static_pool_cash_collection">
											Static Pool Cash Collection
										</Option>
										<Option value="report_rollrate">
											Roll Rate Report - Disbursement Date
										</Option>
										<Option value="report_rollrate2">
											Roll Rate Report - Created Date
										</Option>
										<Option value="report_sofr">SOFR Rates</Option>
									</AntdSelect>
								)}
								{model === 'fpna9-2-1' && (
									<AntdSelect
										defaultValue={customSelect6_3_1}
										change={(e) => seCustomSelect6_3_1(e?.target?.value || e)}
									>
										<Option value="report_multiple">Summary Report</Option>
										<Option value="report_optimized_scenario">
											Optimization Report
										</Option>
										<Option value="report_sofr">SOFR Rates</Option>
									</AntdSelect>
								)}
								{(model === 'fpna6-3-1' || model === 'fpna9-3-1') && (
									<AntdSelect
										defaultValue={customSelect6_3_1}
										change={(e) => seCustomSelect6_3_1(e?.target?.value || e)}
									>
										<Option value="report_multiple">Summary Report</Option>
										<Option value="report_optimized_scenario">
											Optimization Report
										</Option>
									</AntdSelect>
								)}
								{model === 'fpna6-2-1' && (
									<AntdSelect
										defaultValue={customSelect6_2_1}
										change={(e) => setCustomSelect6_2_1(e?.target?.value || e)}
									>
										<Option value="static_pool_loss">
											Static Pool Loss - Disbursement Date
										</Option>
										<Option value="static_pool_loss2">
											Static Pool Loss - Created Date
										</Option>
										<Option value="static_pool_cash_collection">
											Static Pool Cash Collection
										</Option>
										<Option value="report_rollrate">
											Roll Rate Report - Disbursement Date
										</Option>
										<Option value="report_rollrate2">
											Roll Rate Report - Created Date
										</Option>
									</AntdSelect>
								)}
								{(model === 'fpna6-3' || model === 'fpna6-4-1') && (
									<AntdSelect
										defaultValue={'Borrowing Base Report'}
										change={(e) => seCustomSelect3(e?.target?.value || e)}
									>
										<Option value="bb_report_xlsx">
											Borrowing Base Report
										</Option>
									</AntdSelect>
								)}
								{(model === 'fpna6-1-1' || model === 'fpna9-1-1') && (
									<AntdSelect
										defaultValue={customSelect6_1_1}
										change={(e) => seCustomSelect6_1_1(e?.target?.value || e)}
									>
										<Option value="report_sofr">SOFR Rates</Option>
									</AntdSelect>
								)}

								<label
									htmlFor="xlsx-upload"
									style={{ margin: 0, marginLeft: 57 }}
								>
									<Button
										style={{ fontSize: '11px' }}
										className={classes.header__save}
										onClick={() =>
											downloadCustomReports(
												model === 'fpna6' ||
													model === 'fpna9' ||
													model === 'fpna5-3-1-0' ||
													model === 'fpna5-2-1-0' ||
													model === 'fpna5-1-1-0' ||
													model === 'fpna5-3-1' ||
													model === 'fpna5'
													? customSelect2
													: model === 'fpna6-3' || model === 'fpna6-4-1'
													? customSelect3
													: model === 'fpna6-1-1' || model === 'fpna9-1-1'
													? customSelect6_1_1
													: model === 'fpna6-2-1'
													? customSelect6_2_1
													: model === 'fpna6-3-1' ||
													  model === 'fpna9-2-1' ||
													  model === 'fpna9-3-1'
													? customSelect6_3_1
													: customSelect
											)
										}
										disabled={portfolioList.length === 0 || !portfolioList}
									>
										download
									</Button>
								</label>
							</div>
						)}
					{![
						'fpna3',
						'fpna4',
						'fpna5',
						'fpna5-3-1',
						'fpna6',
						'fpna6-1-1',
						'fpna6-2-1',
						'fpna6-3-1',
						'fpna9',
						'fpna9-1-1',
						'fpna6-4-1',
						'fpna9-2-1',
						'fpna9-3-1',
						'fpna0',
						'fpna5-3-1-0',
						'fpna5-2-1-0',
						'fpna5-1-1-0',
						'fpna6-3'
					].includes(model) &&
						['pending', 'success'].includes(('' + status).toLowerCase()) && (
							<Timer
								key={`TIMER${key}`}
								model={model}
								seconds={seconds}
								minutes={minutes}
								status={status}
								timerOnSuccess={timerOnSuccess}
								taskProgressPercent={taskProgressPercent}
							/>
						)}
					{[
						'fpna3',
						'fpna4',
						'fpna5',
						'fpna5-3-1',
						'fpna6',
						'fpna6-1-1',
						'fpna6-2-1',
						'fpna6-3-1',
						'fpna5-3-1-0',
						'fpna5-2-1-0',
						'fpna5-1-1-0',
						'fpna9',
						'fpna9-1-1',
						'fpna6-4-1',
						'fpna9-2-1',
						'fpna9-3-1',
						'fpna0',
						'fpna6-3'
					].includes(model) &&
						['pending', 'success'].includes(('' + status).toLowerCase()) && (
							<Stopwatch
								model={model}
								status={status}
								timerOnSuccess={timerOnSuccess}
								runningTaskId={runningTaskId}
							/>
						)}
					{runningTaskId &&
						!['success', 'failure'].includes(('' + status).toLowerCase()) &&
						timerStarted && (
							<KillTask
								model={model}
								killTaskFunction={() => setTaskDialogVisible(true)}
							/>
						)}
					{handleSave && (
						<div
							style={{
								display: 'flex',
								marginRight: 50,
								marginBottom: -10,
								flexWrap: 'wrap'
							}}
						>
							<Typography
								variant="subtitle2"
								align="left"
								className={classes.label}
							>
								Date
							</Typography>
							{/*<InfoIcon className={classes.selectIcon} />*/}
							<Field
								name="date"
								label="Date"
								type="date"
								required
								component={RenderInputField}
							/>
							<div style={{ marginLeft: 57 }}>
								<Button
									className={classes.header__save}
									onClick={() => handleSave()}
								>
									Save
								</Button>

								<Button className={classes.header__save} onClick={handleRun}>
									Run
								</Button>
							</div>
						</div>
					)}
				</div>
			)}
			<div style={{ marginTop: '50px', marginBottom: 80, marginLeft: -20 }}>
				<NumberOfLoans />
			</div>
			{segmentData && (
				<>
					<div
						className={classes.contentHeaderContainer}
						onClick={() => setOpenSubPortfolio(!openSubPortfolio)}
					>
						<p className={classes.contentHeader}>Sub Portfolio</p>
						<img
							src={downArrow}
							style={{ justifyContent: 'flex-end' }}
							alt=""
						/>
					</div>
					<Divider style={{ marginBottom: 20 }} />
					{openSubPortfolio && (
						<div className={classes.root3}>
							{Object.keys(segmentData)
								.sort()
								.map((item) => (
									<div
										key={item}
										style={{
											display: 'flex',
											alignItems: 'flex-start',
											marginBottom: '10px'
										}}
									>
										<Typography
											variant="subtitle2"
											align="left"
											className={classes.label}
											style={
												downloadCustomReports
													? { minWidth: 100 }
													: { minWidth: 100 }
											}
										>
											{item}
										</Typography>
										{/*<InfoIcon className={classes.selectIcon} />*/}
										<div
											style={{
												display: 'flex',
												alignItems: 'center',
												justifyContent: 'flex-start',
												flexWrap: 'wrap',
												columnGap: 57,
												rowGap: 10,
												width: '100%'
											}}
										>
											{['partner_bank_sc', 'ownership', 'customer_type_su'].map(
												(itemkeys) => {
													return (
														<PopoverPopupState
															key={itemkeys}
															name={itemkeys}
															data={segmentData?.[item].filter(
																(itemfiltered) =>
																	itemfiltered?.field_name === itemkeys &&
																	(itemfiltered?.field_name ===
																	'partner_bank_sc'
																		? itemfiltered?.segment_type === 'A'
																		: itemfiltered?.segment_type === 'B')
															)}
															updateSegment={updateSegment}
														/>
													);
												}
											)}
											<Button
												className={classes.header__save}
												onClick={() => {
													runCalculateFunction(
														subPotofoliosData.filter(
															(itemFiltered) => itemFiltered.name === item
														)
													);
												}}
											>
												run
											</Button>
										</div>
									</div>
								))}
							<div style={{ display: 'flex', alignItems: 'center' }}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
									style={
										downloadCustomReports ? { width: 100 } : { minWidth: 100 }
									}
								>
									Sub Portfolio
								</Typography>
								{/*<InfoIcon className={classes.selectIcon} />*/}
								<AntdSelect
									native={false}
									change={(e) => setSelectedSubPorofolio(e?.target?.value || e)}
								>
									{subPotofoliosData &&
										subPotofoliosData.map((op, index) => {
											return (
												<Option key={index} value={+op.id}>
													{op.name}
												</Option>
											);
										})}
								</AntdSelect>
							</div>

							<div>
								{scenario && (
									<div
										style={
											downloadCustomReports
												? {
														display: 'flex',
														alignItems: 'center',
														marginBottom: -10
												  }
												: {
														display: 'flex',
														alignItems: 'center',
														marginRight: 50
												  }
										}
									>
										<Typography
											variant="subtitle2"
											align="left"
											className={classes.label}
											style={
												downloadCustomReports
													? { width: 100 }
													: { minWidth: 100 }
											}
										>
											{scenarioName}
										</Typography>
										{/*<InfoIcon className={classes.selectIcon} />*/}
										<AntdSelect
											native={false}
											change={(e) =>
												setScenario(
													senarioData.filter(
														(s) => s.id == (e?.target?.value || e)
													)[0]
												)
											}
										>
											{senarioData &&
												senarioData.map((op, index) => {
													return (
														<Option key={index} value={+op.id}>
															{op.displayName
																? op.displayName
																: op[scenarioField]}
														</Option>
													);
												})}
										</AntdSelect>
										{onScenarioRun && (
											<Button
												className={classes.header__save}
												style={{ marginLeft: 57 }}
												onClick={() => {
													onScenarioRun();
												}}
											>
												run
											</Button>
										)}
									</div>
								)}
							</div>
						</div>
					)}
				</>
			)}
		</div>
	);
};

export default reduxForm({ form: 'HeaderSelect', destroyOnUnmount: true })(
	withRouter(Portfolio)
);
