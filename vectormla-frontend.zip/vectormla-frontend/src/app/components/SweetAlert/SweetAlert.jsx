import React from 'react';
import { Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core';
import SweetAlert from 'react-bootstrap-sweetalert';

const useStyles = makeStyles(() => ({
	// sweet alert
	cancel: {
		backgroundColor: 'red',
		margin: 15,
		textTransform: 'capitalize',
		color: '#fff',
		'&:hover': {
			backgroundColor: '#911e15'
		}
	},
	confirm: {
		margin: 15,
		textTransform: 'capitalize'
	}
}));

const ConfirmAction = ({ open, msg, confirm, cancel }) => {
	const classes = useStyles();

	return (
		<SweetAlert
			show={open}
			info
			showCancel
			confirmBtnBsStyle="danger"
			title="Remove User"
			onConfirm={confirm}
			onCancel={cancel}
			customButtons={
				<React.Fragment>
					<Button
						className={classes.cancel}
						variant="contained"
						onClick={cancel}
					>
						Cancel
					</Button>
					<Button
						className={classes.confirm}
						color="primary"
						variant="contained"
						onClick={confirm}
					>
						Confirm
					</Button>
				</React.Fragment>
			}
		>
			{msg}
		</SweetAlert>
	);
};

export default ConfirmAction;
