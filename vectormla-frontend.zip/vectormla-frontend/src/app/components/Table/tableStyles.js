import { makeStyles, Tooltip, withStyles } from '@material-ui/core';
import {
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';

const lightGray = '#f7f8fa';
const darkGray = '#D8DDE3';
const lightBlue = '#d6ecff';
const darkBlue = '#6faede';

const fontColor = '#334152';

const headerColor = '#266696';
const headerHoverColor = '#1D4261';
const cellBackground = '#f7f8fa';

const cell = {
	color: fontColor,
	// boxSizing: 'border-box',
	fontSize: 11,
	letterSpacing: '.4px',
	border: `1px solid ${darkGray}`,
	borderBottom: '0px',
	borderLeft: '0px',
	fontWeight: 'normal',
	padding: 0,
	paddingRight: 6,
	lineHeight: 1.3,
	paddingTop: 4,
	'& div': {
		width: '100%',
		height: 'unset'
	}
};

const text = {
	fontSize: 12,
	fontFamily: 'Roboto',
	whiteSpace: 'pre-wrap'
};

const cellHead = {
	...cell,
	color: fontColor,
	textAlign: 'left',
	width: 170,
	minWidth: 170,
	height: 20,
	// textTransform: 'capitalize',
	position: 'absolute',
	zIndex: 10,
	borderRight: `1px solid ${darkGray}`,
	padding: '2px 5px'
};

const tableCell = {
	fontSize: 11,
	paddingBlock: 1,
	paddingInline: 5,
	minWidth: 110,
	textAlign: 'right',
	border: '1px solid #D8DDE3',
	borderBottom: '0px',
	color: fontColor
};

export const useStyles = makeStyles({
	table__container: {
		marginBlock: 25
	},
	tableRow: {
		'&:first-child': {
			'& td': {
				color: '#fff',
				backgroundColor: `${headerColor}!important`,
				'&:hover': {
					backgroundColor: `${headerHoverColor}!important`
				}
			}
		},
		'&:not(:first-child)': {
			'&:nth-of-type(odd)': {
				backgroundColor: `${cellBackground}!important`
			}
		}
	},
	tableRowCustom: {
		'&:first-child': {
			'& td': {
				color: '#fff',
				backgroundColor: `${headerColor}!important`,
				'&:hover': {
					backgroundColor: `${headerHoverColor}!important`
				}
			}
		}
	},
	stickyCell: {
		left: 0,
		position: 'sticky',
		...tableCell,
		minWidth: 170,
		textAlign: 'left',
		borderTopLeftRadius: 0
	},
	bodyCell: {
		...tableCell,
		borderLeft: '0px',
		'&:hover': {
			cursor: 'default',
			color: '#c97513',
			backgroundColor: '#d6ecff'
		}
	},
	table: {
		marginBottom: 10,
		borderSpacing: 0,
		fontFamily: 'Roboto',
		border: `1px solid ${darkGray}`,
		borderLeft: '0px',
		borderTop: '0px',
		borderBottom: 'none',
		borderCollapse: 'separate',
		'& tr:first-child': {
			'& :hover': {
				backgroundColor: `${headerHoverColor} !important`
			},
			'& td': {
				backgroundColor: '#266696 !important',
				color: '#fff',
				'& :hover': {
					backgroundColor: `${headerHoverColor} !important`
				}
			}
		},
		'& tr:last-child': {
			borderBottom: 'none',
			'& td': {
				borderBottom: `1px solid ${darkGray}`
			}
		},
		'& tr:not(:first-child)': {
			'& td': {
				color: fontColor,
				cursor: 'default',
				'&:hover': {
					color: '#c97513',
					backgroundColor: lightBlue
				}
			},
			'& td:first-child': {
				borderLeft: `1px solid ${darkGray}`
			},
			'& td:not(:first-child)': {
				'&:hover': {
					// border: `1px solid ${darkBlue}`
				}
			}
		},
		'& tr': {
			'& td:first-child': {
				// position: 'fixed',
			}
		}
	},
	table__row_white: {
		height: 20,
		position: 'relative',
		backgroundColor: '#FFF'
	},
	table__row_lightGray: {
		height: 20,
		position: 'relative',
		backgroundColor: lightGray
	},
	table__row_darkGray: {
		height: 20,
		position: 'relative',
		backgroundColor: '#E1EBF2'
		// borderLeft: "10px solid #3ea8a0",
	},
	table__cell_head_white: {
		...cellHead,
		backgroundColor: '#FFF'
	},
	table__cell_head_light: {
		...cellHead,
		backgroundColor: lightGray
	},
	table__cell_static_2: {
		color: fontColor,
		boxSizing: 'border-box',
		padding: '0px 5px',
		fontSize: 11,
		borderBottom: `1px solid #e3e3e3`,
		borderRight: `1px solid ${darkGray}`,
		textAlign: 'right',
		width: 110,
		minWidth: 110,
		height: 20,
		position: 'relative',
		left: 170,
		'&:hover': {
			backgroundColor: `${darkGray} !important`,
			border: '1px solid #e3e3e3 !important'
		}
	},
	table__cell_head_dark_static: {
		color: fontColor,
		boxSizing: 'border-box',
		padding: '0px 5px',
		fontSize: 11,
		textAlign: 'left',
		width: 170,
		minWidth: 170,
		height: 20,
		// textTransform: 'capitalize',
		position: 'absolute',
		zIndex: 10,
		borderRight: `2px solid ${darkGray}`,
		backgroundColor: '#E1EBF2',
		display: 'flex',
		alignItems: 'baseline'
	},
	table__cell_lightBlue_static: {
		color: fontColor,
		boxSizing: 'border-box',
		padding: '0px 5px',
		fontSize: 11,
		textAlign: 'left',
		width: 170,
		minWidth: 170,
		height: 20,
		// textTransform: 'capitalize',
		position: 'absolute',
		zIndex: 10,
		borderRight: `2px solid ${darkGray}`,
		backgroundColor: '#CDE0ED',
		display: 'flex',
		alignItems: 'baseline'
	},
	table__cell_head_active: {
		...cellHead,
		backgroundColor: lightBlue,
		borderRight: `1px solid ${darkBlue}`
	},
	table__cell: {
		...cell,
		color: fontColor,
		minWidth: 110,
		position: 'relative',
		left: 170,
		textAlign: 'right',
		'&:hover': {
			cursor: 'default',
			color: '#c97513',
			backgroundColor: '#d6ecff !important'
		},
		paddingInline: 7
	},
	contentHeaderContainer,
	contentHeader,
	tableDivider: {
		marginBottom: 20
	},
	// will refactor
	table__cell_static: {
		color: fontColor,
		boxSizing: 'border-box',
		padding: '0px 5px',
		fontSize: 11,
		borderBottom: `1px solid #e3e3e3`,
		textAlign: 'right',
		width: 110,
		minWidth: 110,
		height: 20,
		position: 'relative',
		left: 170,
		'&:hover': {
			backgroundColor: `${darkGray} !important`,
			border: '1px solid #e3e3e3 !important'
		}
	},
	icon: {
		marginRight: 10,
		color: 'gray',
		cursor: 'pointer',
		position: 'relative',
		top: 2,
		zIndex: 99999
	},
	assumTable_select: {
		height: 20,
		borderRadius: 0,
		fontSize: 11,
		width: '100%',
		boxSizing: 'border-box',
		textAlign: 'right',
		'& .MuiInputBase-input': {
			padding: 0,
			backgroundColor: 'transparent',
			paddingLeft: 6
		},
		'&.MuiInput-underline:before': {
			borderBottom: 'none',
			content: 'none'
		},
		'&::before': {
			content: 'none'
		}
	},
	popupContainer: {
		// position: 'absolute !important',
		display: 'flex',
		background: '#fff !important',
		borderRadius: 10,
		border: '1px solid #0000003b',
		zIndex: 999,
		minWidth: 147,
		minHeight: 35,
		textAlign: 'center',
		alignItems: 'center',
		justifyContent: 'center',
		padding: '5px',
		width: '100%',
		height: 'auto',
		maxWidth: '200px'
	},
	popupText: {
		fontSize: '11px !important',
		fontWeight: '500 !important',
		color: 'black',
		margin: '0px !important'
	},
	selectIcon: {
		width: 16,
		marginLeft: 10,
		color: '#dbdcde',
		opacity: 0.7,
		'&:hover': {
			cursor: 'pointer',
			opacity: 1
		}
	},
	headerIcon: {
		marginRight: 10,
		color: 'gray',
		cursor: 'pointer',
		position: 'relative',
		top: 2
	},
	header: {
		...text,
		fontWeight: 'bold'
	},
	tableContainer: {
		overflowX: 'hidden'
	}
});

export const HtmlTooltip = withStyles((theme) => ({
	tooltip: {
		backgroundColor: 'transparent',
		color: 'rgba(0, 0, 0, 0.87)',
		maxWidth: 220,
		fontSize: theme.typography.pxToRem(12),
		border: '0px solid #dadde9'
	}
}))(Tooltip);
