import React, { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
	TableContainer,
	TableBody,
	TableCell,
	TableRow,
	Table,
	Divider,
	CircularProgress,
	IconButton
} from '@material-ui/core';
import InfoIcon from '@material-ui/icons/Info';
import _ from 'lodash';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import { HtmlTooltip, useStyles } from './tableStyles';
import GetAppIcon from '@material-ui/icons/GetApp';
import downArrow from '../../../common/assets/vector/images/arrow.svg';
import {
	MinusSquare,
	PlusSquare,
	PlusSquareTotal,
	MinusSquareTotal
} from '../AssestFunctions/assestFun';
import {
	getPipelineGrowthAssumptionData,
	getCustomisedDownloadData
} from '../../store/actions/fpna.action';
import { CustomisedDownloadDataFields } from './helpers';

function generateSectionState(tableSecions) {
	let tableSectionsObj = {};
	if (tableSecions)
		for (let i = 1; i < tableSecions.length; i++) {
			tableSectionsObj[tableSecions[i]] = false;
		}
	return tableSectionsObj;
}

function generateSectionStateTrue(tableSecions) {
	let tableSectionsObj = {};
	if (tableSecions)
		for (let i = 1; i < tableSecions.length; i++) {
			tableSectionsObj[tableSecions[i]] = true;
		}
	return tableSectionsObj;
}

const MainTable = ({
	tableName,
	tableDataName,
	desc,
	header,
	data,
	attributes,
	status,
	fetchData,
	collapsed,
	separator,
	multiSeparator,
	extraMultiSeparator,
	download,
	disableHeader,
	onLeft,
	fullwidth,
	formatType = 'records',
	multiple = false,
	multipleArray = [],
	stateMultipleArray = {},
	setStateMultipleArray,
	stateGradeTrue = {},
	tableSign,
	model,
	modelName,
	id,
	customArrangeExcel,
	nestedSeparator,
	statusScenarioId
}) => {
	const classes = useStyles();
	const dispatch = useDispatch();
	let separatorState = generateSectionState(
		separator && Object.keys(separator)
	);
	let separatorStateTrue = generateSectionStateTrue(
		separator && Object.keys(separator)
	);

	const [tableState, setTableState] = useState(
		separator && {
			...separatorState,
			untitled: true,
			root: true
		}
	);

	const [tableVisible, setTableVisible] = useState(null);

	const customTableSeparators = (separator, separatorNo) => {
		let obj = {
			untitled: separator.untitled,
			root: separator.root,
			[`General Info_${separatorNo}`]: separator['General Info'],
			[`Interest Rate_${separatorNo}`]: separator['Interest Rate'],
			[`FTP - Cost of Funds_${separatorNo}`]: separator['FTP - Cost of Funds'],
			[`Commercial Margin_${separatorNo}`]: separator['Commercial Margin'],
			[`Liability Structure_${separatorNo}`]: separator['Liability Structure'],
			[`Price and Duration_${separatorNo}`]: separator['Price and Duration']
		};
		return Object?.fromEntries(
			Object.entries(obj).filter(([_, v]) => v != null)
		);
	};
	const handleTableStateChange = (tableName) =>
		setTableState({
			...tableState,
			[`${tableName}`]: !tableState[`${tableName}`]
		});

	const transpose = (array) => {
		return array[0].map((_, c) => {
			return array.map((r) => {
				return r[c];
			});
		});
	};

	const exportToCSV = (csvData, header, fileName, formatType) => {
		if (
			([
				'Pipeline Growth Assumptions',
				'Loan Data',
				'Origination Pipeline',
				'Historical Portfolio',
				'Asset Amortization - Current',
				'Asset Amortization - Delinquent',
				'Asset Amortization - Forecast',
				'Asset Amortization - Consolidated',
				'Equity Requirement - Current',
				'Equity Requirement - Forecast',
				'Equity Requirement - Consolidated',
				'Income Statement - Current',
				'Income Statement - Forecast',
				'Income Statement - Consolidated',
				'Current Portfolio - Income Statement Support Schedule',
				'Forecast Portfolio - Income Statement Support Schedule',
				'Consolidated Portfolio - Income Statement Support Schedule',
				'Roll Rates Schedule 1',
				'Roll Rates Schedule 2',
				'Roll Rates Schedule 3',
				'12 Month Average Roll Rate',
				'Equity Requirement - Delinquent',
				'Income Statement - Delinquent',
				'Income Statement - Consolidated - Actual',
				'Outstanding Portfolio as % of Origination',
				'Cumulative Charge-off',
				'Cumulative Charge-off - Net of Recovery',
				'Monthly Charge-off',
				'Monthly Charge-off Net of Recovery',
				'Vintage'
			].includes(tableName) &&
				modelName === 'fpna3') ||
			([
				'Balance Sheet',
				'Demand Deposits',
				'Term Deposits Current Book',
				'Term Deposits New',
				'Term Deposits Consolidated',
				'Asset Amortization Consolidated',
				'Asset Amortization Pipeline',
				'Asset Amortization Current',
				'Other Liability - Accrued Interest',
				'Interest Rate Changes',
				'Funding Pipeline'
			].includes(tableName) &&
				(modelName === 'fpna5' ||
					model === 'fpna5-1-1-0' ||
					model === 'fpna5-3-1-0'))
		)
			return;
		let selectedHeader = [];
		let selectedData = [];
		if (formatType === 'records') {
			header.forEach((head, headIndex) => {
				if (
					csvData &&
					csvData[0] &&
					Object.keys(csvData[0]).includes(attributes[headIndex])
				)
					selectedHeader.push(head);
			});
			csvData?.forEach((item) => {
				selectedData?.push(Object.values(_.pick(item, attributes)));
			});
		} else if (formatType === 'split1') {
			csvData?.table?.headers?.forEach((head) => {
				if (csvData?.table?.rows && csvData?.table?.rows[0])
					selectedHeader.push(head);
			});
			csvData.table.rows.forEach((row) => {
				selectedData.push(row);
			});
		} else {
			(customArrangeExcel ? header : csvData.columns).forEach((head) => {
				if (csvData?.data && csvData?.data[0]) selectedHeader?.push(head);
			});
			csvData?.data?.forEach((row) => {
				selectedData?.push(row);
			});
		}
		let excelData = JSON.parse(
			JSON.stringify(
				selectedData?.table
					? selectedData?.table.rows || selectedData?.data
					: selectedData
			)
		);
		excelData.unshift(selectedHeader);

		excelData = excelData?.map((e) =>
			e.map((i) => {
				return !isNaN(i)
					? +i
					: !isNaN(i.replace(',', ''))
					? +i.replace(',', '')
					: !isNaN(i.replace('%', ''))
					? { v: +i.replace('%', '') / 100, t: 'n', z: '0.00%' }
					: i;
			})
		);
		excelData = transpose(excelData);
		const ws = XLSX.utils.json_to_sheet(excelData, {
			skipHeader: true
		});
		const wb = { Sheets: { data: ws }, SheetNames: ['data'] };
		const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
		const data = new Blob([excelBuffer], {
			type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8'
		});
		FileSaver.saveAs(data, fileName + '.xlsx');
	};

	const renderNormalBody = () => {
		let i = -1;
		return (
			<TableBody>
				{header &&
					header.map((head, headIndex) => {
						if (
							data &&
							data[0] &&
							!Object.keys(data[0]).includes(attributes[headIndex])
						)
							return <></>;

						i++;
						return (
							<>
								<TableRow className={classes.tableRow} key={headIndex}>
									<HtmlTooltip
										key={headIndex}
										// This right here is for the popup for the tables, it's currently not activated and commented out
										// title={
										// 	<div className={classes.popupContainer}>
										// 		<p className={classes.popupText}>
										// 			{head?.length > 30
										// 				? `${head.substring(0, 28)}..`
										// 				: head}
										// 		</p>
										// 	</div>
										// }
									>
										<TableCell
											style={{
												backgroundColor: i % 2 === 0 ? '#f7f8fa' : '#fff',
												borderTopLeftRadius: i === 0 ? '4px' : ''
											}}
											className={classes.stickyCell}
										>
											{head?.length > 30 ? `${head.substring(0, 28)}..` : head}
										</TableCell>
									</HtmlTooltip>
									{data &&
										data?.map((row, colIndex) => {
											return (
												<HtmlTooltip
													key={`${headIndex}-${colIndex}`}
													// This right here is for the popup for the tables, it's currently not activated and commented out
													// title={
													// 	<div className={classes.popupContainer}>
													// 		<p className={classes.popupText}>
													// 			{row[attributes[headIndex]]}
													// 		</p>
													// 	</div>
													// }
												>
													<TableCell
														style={{
															textAlign: onLeft ? 'left' : 'right',
															borderTopRightRadius: colIndex === 60 ? '4px' : ''
														}}
														className={classes.bodyCell}
													>
														{row[attributes[headIndex]]}
													</TableCell>
												</HtmlTooltip>
											);
										})}
								</TableRow>
							</>
						);
					})}
			</TableBody>
		);
	};

	const renderSeparatedBody = (
		multipleEnable = false,
		multipleIndex = false
	) => {
		let filteredData = multipleEnable
			? tableName === 'default Vintage'
				? Object.assign(
						{},
						...data?.map((item) => ({ [`${item?.tablename}`]: item?.table }))
				  )
				: Object.keys(data)
						.filter((key) => key.includes('loanmodel_g'))
						.reduce((cur, key) => {
							return Object.assign(cur, { [key]: data[key] });
						}, {})
			: data;
		return (
			tableState && (
				<TableContainer
					className="renderSeparatedBody"
					style={{
						width: '90vw',
						overflowX: 'auto'
					}}
				>
					{(
						Object.keys(
							multipleEnable && tableName !== 'default Vintage'
								? customTableSeparators(separator, multipleIndex)
								: separator
						) || []
					)?.map((sectionName, index) => (
						<React.Fragment key={index}>
							{index !== 0 && (
								<>
									<TableRow className={classes.tableRow}>
										{/*For tables names headers */}
										<HtmlTooltip
										// This right here is for the popup for the tables, it's currently not activated and commented out
										// title={
										// 	<div className={classes.popupContainer}>
										// 		<p className={classes.popupText}>
										// 			{sectionName?.split('_')[0]}
										// 		</p>
										// 	</div>
										// }
										>
											<TableCell
												className={
													[
														'Ownership - [CIM SPV,CIM Colorado]',
														'Ownership - [Camino Financial,Camino Financial Solopreneur Loan,CReal]'
													].includes(sectionName)
														? classes.table__cell_lightBlue_static
														: classes.table__cell_head_dark_static
												}
												key={`${index}11`}
											>
												{/*For tables plus sign and minus sign*/}
												{tableState[sectionName]
													? sectionName !==
															'Ownership - [CIM SPV,CIM Colorado]' &&
													  sectionName !==
															'Ownership - [Camino Financial,Camino Financial Solopreneur Loan,CReal]' && (
															<MinusSquare
																className={classes.icon}
																onClick={() =>
																	handleTableStateChange(sectionName)
																}
															/>
													  )
													: sectionName !==
															'Ownership - [CIM SPV,CIM Colorado]' &&
													  sectionName !==
															'Ownership - [Camino Financial,Camino Financial Solopreneur Loan,CReal]' && (
															<PlusSquare
																className={classes.icon}
																onClick={() =>
																	handleTableStateChange(sectionName)
																}
															/>
													  )}

												<span>
													{sectionName?.split('_')[0]?.length > 21
														? `${sectionName?.split('_')[0].substring(0, 21)}..`
														: sectionName?.split('_')[0]}
												</span>
											</TableCell>
										</HtmlTooltip>
										{(
											(multipleEnable
												? filteredData &&
												  filteredData[
														Object.keys(filteredData).sort()[multipleIndex]
												  ]?.data
												: filteredData?.table?.rows || filteredData?.data) || []
										)?.map((row, colIndex) => (
											// for Tables data cells
											// Second one for the cells of the data
											<TableCell
												key={colIndex + 1}
												className={classes.table__cell_static}
												style={{
													backgroundColor: [
														'Ownership - [CIM SPV,CIM Colorado]',
														'Ownership - [Camino Financial,Camino Financial Solopreneur Loan,CReal]'
													].includes(sectionName)
														? '#CDE0ED'
														: '#E1EBF2'
												}}
											></TableCell>
										))}
									</TableRow>
								</>
							)}
							{tableState[sectionName] &&
								(multipleEnable
									? customTableSeparators(separator, multipleIndex)
									: separator)?.[sectionName]?.map((index, headIndex) => {
									let rowsName = multipleEnable
										? filteredData &&
										  filteredData[
												Object.keys(filteredData).sort()[multipleIndex]
										  ]?.columns[index]
										: filteredData?.table?.headers[index] ||
										  filteredData?.columns[index];

									return (
										<TableRow
											key={index}
											className={classes.tableRowCustom}
											style={
												headIndex % 2 === 0 ? {} : { backgroundColor: '#FFF' }
											}
										>
											<HtmlTooltip
											// This right here is for the popup for the tables, it's currently not activated and commented out
											// title={
											// 	<div className={classes.popupContainer}>
											// 		<p className={classes.popupText}>{rowsName}</p>
											// 	</div>
											// }
											>
												<TableCell
													className={
														headIndex % 2 === 0
															? classes.table__cell_head_white
															: classes.table__cell_head_light
													}
													style={
														(
															(multipleEnable
																? filteredData &&
																  filteredData[
																		Object.keys(filteredData).sort()[
																			multipleIndex
																		]
																  ]?.data
																: filteredData?.table?.rows ||
																  filteredData?.data) || []
														).some(
															(itemMapped) => itemMapped[index] === '--'
														) &&
														rowsName !== 'Loans' &&
														rowsName !== 'Allowance for credit loss' &&
														rowsName !== 'Other Assets'
															? {
																	backgroundColor: '#f7f8fa'
															  }
															: [
																	'Total Assets',
																	'Cash and Securities',
																	'Total Net Loans',
																	'Demand Deposit',
																	'Term Deposit Total',
																	'Total Deposits',
																	'Other Liabilties',
																	'Total Liabilities',
																	'Net Income Loss',
																	'Common Equity Tier 1 Capital',
																	'Liabilities and Equity',
																	'Total Loans',
																	'Cash and Securities %',
																	'Net Loan to Total Asset %',
																	'Total Other Assets',
																	'Total Other Assets %',
																	'Total Assets %',
																	'Allowance for credit losses'
															  ].includes(rowsName) &&
															  (modelName === 'fpna5' ||
																	modelName === 'fpna5-3-1-0' ||
																	modelName === 'fpna5-1-1-0' ||
																	modelName === 'fpna6' ||
																	modelName === 'fpna6-1-1' ||
																	modelName === 'fpna6-2-1' ||
																	modelName === 'fpna6-3-1' ||
																	modelName === 'fpna9-1-1' ||
																	modelName === 'fpna6-4-1' ||
																	modelName === 'fpna9-2-1' ||
																	modelName === 'fpna9-3-1' ||
																	modelName === 'fpna9') &&
															  tableName === 'Balance Sheet'
															? { backgroundColor: '#F7F8FA' }
															: {
																	backgroundColor: '#FFF'
															  }
													}
													key={`${index}12`}
												>
													{rowsName?.length > 21
														? `${rowsName?.substring(0, 21)}..`
														: rowsName}
												</TableCell>
											</HtmlTooltip>
											{(
												(multipleEnable
													? filteredData &&
													  filteredData[
															Object.keys(filteredData).sort()[multipleIndex]
													  ]?.data
													: filteredData?.table?.rows || filteredData?.data) ||
												[]
											)?.map((row, colIndex) => (
												<>
													<HtmlTooltip
													// This right here is for the popup for the tables, it's currently not activated and commented out
													// title={
													// 	<div className={classes.popupContainer}>
													// 		<p className={classes.popupText}>
													// 			{row[index]}
													// 		</p>
													// 	</div>
													// }
													>
														<TableCell
															style={
																row[index] === '--' &&
																rowsName !== 'Loans' &&
																rowsName !== 'Allowance for credit loss' &&
																rowsName !== 'Other Assets'
																	? {
																			color: 'transparent',
																			backgroundColor: '#f7f8fa'
																	  }
																	: [
																			'Total Assets',
																			'Cash and Securities',
																			'Total Net Loans',
																			'Demand Deposit',
																			'Term Deposit Total',
																			'Total Deposits',
																			'Other Liabilties',
																			'Total Liabilities',
																			'Net Income Loss',
																			'Common Equity Tier 1 Capital',
																			'Liabilities and Equity',
																			'Total Loans',
																			'Cash and Securities %',
																			'Net Loan to Total Asset %',
																			'Total Other Assets',
																			'Total Other Assets %',
																			'Total Assets %',
																			'Allowance for credit losses'
																	  ].includes(rowsName) &&
																	  tableName === 'Balance Sheet' &&
																	  (modelName === 'fpna5' ||
																			modelName === 'fpna5-3-1-0' ||
																			modelName === 'fpna5-1-1-0' ||
																			modelName === 'fpna6' ||
																			modelName === 'fpna6-1-1' ||
																			modelName === 'fpna6-2-1' ||
																			modelName === 'fpna6-3-1' ||
																			modelName === 'fpna9-1-1' ||
																			modelName === 'fpna6-4-1' ||
																			modelName === 'fpna9-2-1' ||
																			modelName === 'fpna9-3-1' ||
																			modelName === 'fpna9')
																	? { backgroundColor: '#F7F8FA' }
																	: {
																			color:
																				rowsName === 'Loans' ||
																				rowsName ===
																					'Allowance for credit loss' ||
																				(rowsName === 'Other Assets' &&
																					(modelName === 'fpna5' ||
																						modelName === 'fpna5-3-1-0' ||
																						modelName === 'fpna5-1-1-0' ||
																						modelName === 'fpna6' ||
																						modelName === 'fpna6-1-1' ||
																						modelName === 'fpna6-2-1' ||
																						modelName === 'fpna6-3-1' ||
																						modelName === 'fpna9-1-1' ||
																						modelName === 'fpna6-4-1' ||
																						modelName === 'fpna9-2-1' ||
																						modelName === 'fpna9-3-1' ||
																						modelName === 'fpna9') &&
																					tableName === 'Balance Sheet')
																					? '#FFF'
																					: ''
																	  }
															}
															key={colIndex}
															className={classes.table__cell}
														>
															{/* row values */}
															{row[index]?.length > 13
																? `${row[index].substring(0, 13)}..`
																: row[index]}
														</TableCell>
													</HtmlTooltip>
												</>
											))}
										</TableRow>
									);
								})}
						</React.Fragment>
					))}
				</TableContainer>
			)
		);
	};

	function onlyNumbers(array) {
		return array.every((element) => {
			return typeof element === 'number';
		});
	}

	const NestedRow = ({
		headIndex,
		parent,
		index,
		sectionNameee,
		filteredData,
		isRoot,
		key,
		rootKey
	}) => {
		return (
			<React.Fragment key={key}>
				<TableRow className={classes.tableRow}>
					{/*For tables names headers (Category inside category (plus inside plus)) (sub category(Category2) first cell(header with plus sign) */}
					<HtmlTooltip
					// This right here is for the popup for the tables, it's currently not activated and commented out
					// title={
					// 	<div className={classes.popupContainer}>
					// 		<p className={classes.popupText}>{index}</p>
					// 	</div>
					// }
					>
						<TableCell
							className={classes.table__cell_head_dark_static}
							style={{
								padding: `0px ${
									isRoot ? (rootKey === 1 ? 5 : (rootKey - 1) * 10) : 10
								}px`,
								backgroundColor:
									['Total', 'Total Portfolio'].includes(index) || rootKey === 1
										? '#CDE0ED'
										: '#E1EBF2'
							}}
						>
							{/*For tables plus sign and minus sign (Category2)*/}
							{tableState[`${tableName}-${parent}-${index}`] ? (
								['Total', 'Total Portfolio'].includes(index) ? (
									<MinusSquareTotal
										className={classes.icon}
										onClick={() =>
											handleTableStateChange(`${tableName}-${parent}-${index}`)
										}
									/>
								) : (
									<MinusSquare
										className={classes.icon}
										onClick={() =>
											handleTableStateChange(`${tableName}-${parent}-${index}`)
										}
									/>
								)
							) : ['Total', 'Total Portfolio'].includes(index) ? (
								<PlusSquareTotal
									className={classes.icon}
									onClick={() =>
										handleTableStateChange(`${tableName}-${parent}-${index}`)
									}
								/>
							) : (
								<PlusSquare
									className={classes.icon}
									onClick={() =>
										handleTableStateChange(`${tableName}-${parent}-${index}`)
									}
								/>
							)}
							<span>
								{index?.length > 20 ? `${index?.substring(0, 20)}..` : index}
							</span>
						</TableCell>
					</HtmlTooltip>

					{(filteredData?.table?.rows || filteredData?.data || [])?.map(
						(row, colIndex) => (
							// for Tables data cells (sub categories(Category2) plus inside plus (all row cells except the first one))
							<TableCell
								key={colIndex + 1}
								className={classes.table__cell_static}
								style={{
									backgroundColor:
										['Total', 'Total Portfolio'].includes(index) ||
										rootKey === 1
											? '#CDE0ED'
											: '#E1EBF2'
								}}
							></TableCell>
						)
					)}
				</TableRow>
				{/* loop from here*/}
				{tableState[`${tableName}-${parent}-${index}`] &&
					((isRoot ? !onlyNumbers(nestedSeparator[index]) : false)
						? nestedSeparator?.[index]?.map((indexx, headIndexx) => {
								return (
									<NestedRow
										key={headIndexx}
										rootKey={rootKey + 1}
										headIndex={headIndexx}
										index={indexx}
										parent={index}
										sectionNameee={sectionNameee}
										filteredData={filteredData}
										isRoot={isRoot}
									/>
								);
						  })
						: nestedSeparator?.[index]?.map((indexx, headIndexx) => {
								let rowsName =
									filteredData?.table?.headers[indexx] ||
									filteredData?.columns[indexx];
								return (
									<NormalRow
										index={indexx}
										headIndex={headIndexx}
										rowsName={rowsName}
										filteredData={filteredData}
										key={headIndexx}
									/>
								);
						  }))}
			</React.Fragment>
		);
	};

	const NormalRow = ({ index, filteredData, headIndex, rowsName, key }) => {
		let indexx = index;
		let headIndexx = headIndex;
		return (
			<React.Fragment key={key}>
				<TableRow
					className={classes.tableRowCustom}
					style={headIndexx % 2 === 0 ? {} : { backgroundColor: '#FFF' }}
				>
					<HtmlTooltip
					// This right here is for the popup for the tables, it's currently not activated and commented out
					// title={
					// 	<div className={classes.popupContainer}>
					// 		<p className={classes.popupText}>{rowsName}</p>
					// 	</div>
					// }
					>
						<TableCell
							className={
								headIndexx % 2 === 0
									? classes.table__cell_head_white
									: classes.table__cell_head_light
							}
							style={
								[
									'Portfolio Amortization',
									'Portfolio Delinquency',
									'Portfolio Expected Loss [Charge-Off]- Over 120',
									'Total Cash Flow',
									'Total Discounted Cash Flow',
									'Portfolio Expected Loss [Charge-off]'
								].includes(rowsName)
									? { backgroundColor: '#f7f8fa' }
									: headIndexx % 2 === 0
									? {}
									: { backgroundColor: '#FFF' }
							}
							key={`${indexx}12`}
						>
							{/* headers of rows */}
							{rowsName?.length > 21
								? `${rowsName?.substring(0, 21)}..`
								: rowsName}
						</TableCell>
					</HtmlTooltip>
					{(filteredData?.table?.rows || filteredData?.data || [])?.map(
						(roww, colIndexx) => (
							<>
								<HtmlTooltip
								// This right here is for the popup for the tables, it's currently not activated and commented out
								// title={
								// 	<div className={classes.popupContainer}>
								// 		<p className={classes.popupText}>{roww[indexx]}</p>
								// 	</div>
								// }
								>
									<TableCell
										key={colIndexx}
										className={classes.table__cell}
										style={
											roww[indexx] === '--'
												? {
														backgroundColor: '#f7f8fa',
														color: '#f7f8fa'
												  }
												: {}
										}
									>
										{/* row values */}
										{roww[index]?.length > 14
											? `${roww[indexx].substring(0, 14)}..`
											: roww[indexx]}
									</TableCell>
								</HtmlTooltip>
							</>
						)
					)}
				</TableRow>
			</React.Fragment>
		);
	};

	const renderMultiSeparatedBody = () => {
		let filteredData = data;
		return (
			tableState && (
				<TableContainer
					style={{
						width: 'calc(99vw - 160px)',
						overflowX: 'auto'
					}}
				>
					{(Object.keys(separator).includes('root')
						? ['root']
						: Object.keys(separator) || []
					)?.map((sectionNameee, indexxx) => {
						return (
							<React.Fragment key={indexxx}>
								{!['untitled', 'root'].includes(sectionNameee) && (
									<>
										<TableRow className={classes.tableRow}>
											{/*For tables names headers (category2) (Plus contains a plus inside) */}
											<HtmlTooltip
											// This right here is for the popup for the tables, it's currently not activated and commented out
											// title={
											// 	<div className={classes.popupContainer}>
											// 		<p className={classes.popupText}>{sectionNameee}</p>
											// 	</div>
											// }
											>
												<TableCell
													className={classes.table__cell_lightBlue_static}
												>
													{/*For tables plus sign and minus sign*/}
													{tableState[`${sectionNameee}`] ? (
														<MinusSquare
															className={classes.icon}
															onClick={() =>
																handleTableStateChange(`${sectionNameee}`)
															}
														/>
													) : (
														<PlusSquare
															className={classes.icon}
															onClick={() =>
																handleTableStateChange(`${sectionNameee}`)
															}
														/>
													)}
													<span>
														{sectionNameee?.split('_')[0]?.length > 21
															? `${sectionNameee
																	.split('_')[0]
																	.substring(0, 21)}..`
															: sectionNameee.split('_')[0]}
													</span>
												</TableCell>
											</HtmlTooltip>
											{(
												filteredData?.table?.rows ||
												filteredData?.data ||
												[]
											)?.map((row, colIndex) => (
												// for Tables data cells (categories rows EXCEPT the first one (normal does NOT contain a plus inside it)))
												<TableCell
													key={colIndex + 1}
													className={classes.table__cell_static}
													style={{
														backgroundColor: '#CDE0ED'
													}}
												></TableCell>
											))}
										</TableRow>
									</>
								)}
								{tableState[`${sectionNameee}`] &&
									separator[sectionNameee]?.map((index, headIndex) => {
										if (
											!['root'].includes(sectionNameee)
												? !['untitled'].includes(index)
												: !onlyNumbers(nestedSeparator[index])
										)
											return (
												// Table Row With signs (+ or -)
												<NestedRow
													key={headIndex}
													rootKey={1}
													headIndex={headIndex}
													index={index}
													parent={sectionNameee}
													isRoot={Object.keys(separator).includes('root')}
													sectionNameee={sectionNameee}
													filteredData={filteredData}
												/>
											);
										else {
											return (
												tableState[`${sectionNameee}`] &&
												nestedSeparator[
													['root'].includes(sectionNameee)
														? index
														: sectionNameee
												]?.map((indexx, headIndexx) => {
													let rowsName =
														filteredData?.table?.headers[indexx] ||
														filteredData?.columns[indexx];
													return (
														// Table Row Flat With out signs (+ or -)
														<NormalRow
															key={indexx}
															headIndexx={headIndexx}
															rowsName={rowsName}
															index={indexx}
															filteredData={filteredData}
														/>
													);
												})
											);
										}
									})}
							</React.Fragment>
						);
					})}
				</TableContainer>
			)
		);
	};

	const generateHeaderGrid = () => {
		let result = [0, 1, 2, 3, 4, 5, 6].map((arr) => ({
			[`General Info_${arr}`]: true,
			[`Interest Rate_${arr}`]: true,
			[`FTP - Cost of Funds_${arr}`]: true,
			[`Commercial Margin_${arr}`]: true,
			[`Liability Structure_${arr}`]: true,
			[`Price and Duration_${arr}`]: true
		}));
		return {
			...result[0],
			...result[1],
			...result[2],
			...result[3],
			...result[4],
			...result[5],
			...result[6]
		};
	};

	useEffect(() => {
		if (id !== statusScenarioId && tableVisible) fetchData();
	}, [id, statusScenarioId]);

	useEffect(() => {
		if (!status) {
			if (collapsed > 2) {
				setTableState(
					separator && {
						...separatorStateTrue,
						untitled: true,
						root: true,
						...generateHeaderGrid()
					}
				);
				setTableVisible(true);
				multiple &&
					setStateMultipleArray({
						...setStateMultipleArray,
						...{
							'Grade 1': true,
							'Grade 2': true,
							'Grade 3': true,
							'Grade 4': true,
							'Grade 5': true,
							'Grade 6': true,
							'Grade 7': true
						},
						...stateGradeTrue
					});
				fetchData && fetchData();
			}
			if (collapsed === 2) {
				setTableState(
					separator && {
						...separatorStateTrue,
						untitled: true,
						root: true
					}
				);
				setTableVisible(true);
				multiple &&
					setStateMultipleArray({
						...setStateMultipleArray,
						...{
							'Grade 1': true,
							'Grade 2': true,
							'Grade 3': true,
							'Grade 4': true,
							'Grade 5': true,
							'Grade 6': true,
							'Grade 7': true
						},
						...stateGradeTrue
					});
				fetchData && fetchData();
			} else if (collapsed === 1) {
				setTableVisible(true);
				fetchData && fetchData();
			} else if (collapsed === 0 && tableVisible) {
				setTableVisible(false);
				setTableState(
					separator && {
						...separatorState,
						untitled: true,
						root: true
					}
				);
			}
		} else if (status === 'success') {
			setTableVisible(false);
		}
	}, [collapsed, status]);

	return (
		<div>
			{!disableHeader && (
				<>
					<div
						className={[classes.contentHeaderContainer]}
						onClick={() => {
							setTableVisible(!tableVisible);
							fetchData && fetchData();
						}}
					>
						<p className={classes.contentHeader}>{tableName}</p>
						{/* This here is for Info Icon and down arrow next to table name
						<HtmlTooltip
						// This right here is for the popup for the tables, it's currently not activated and commented out
						// title={
						// 	<div className={classes.popupContainer}>
						// 		<p className={classes.popupText}>
						// 			{desc || tableSign || tableName}
						// 		</p>
						// 	</div>
						// }
						>
							<InfoIcon className={classes.selectIcon} />
					</HtmlTooltip>
					
					<img src={downArrow} alt="down-arrow" />
				*/}
						{/*						<HtmlTooltip
							title={
								<div className={classes.popupContainer}>
									<p className={classes.popupText}>
										{desc || tableSign || tableName}
									</p>
								</div>
							}
						>
							<IconButton
								style={{
									opacity: 0.5,
									marginTop: -10
								}}
							>
								<GetAppIcon style={{ width: 20, height: 20 }} />
							</IconButton>
							</HtmlTooltip>*/}
						{/* here here*/}
						{/*download && (
							<IconButton
								style={{
									opacity: 0.5,
									marginTop: -27
								}}
								onClick={() => {
									if (
										['fpna3', 'fpna5', 'fpna5-3-1-0', 'fpna5-1-1-0', 'fpna6', 'fpna9', 'fpna6-2-1', 'fpna6-3-1', 'fpna9-2-1', 'fpna9-3-1', 'fpna6-1-1', 'fpna9-1-1', 'fpna6-4-1'].includes(modelName)
									) {
										if (tableName === 'Pipeline Growth Assumptions') {
											dispatch(getPipelineGrowthAssumptionData(model, id));
										} else
											dispatch(
												getCustomisedDownloadData(
													modelName === 'fpna6' || modelName === 'fpna6-2-1' || model === 'fpna6-3-1' || model === 'fpna6-1-1'
														? '6'
														: modelName === 'fpna9' || model === 'fpna9-2-1' || model === 'fpna9-3-1' || model === 'fpna9-1-1' || model === 'fpna6-4-1'
														? '9'
														: CustomisedDownloadDataFields?.[tableName]?.[0],
													id,
													CustomisedDownloadDataFields?.[tableName]?.[2],
													CustomisedDownloadDataFields?.[tableName]?.[3],
													CustomisedDownloadDataFields?.[tableName]?.[4]
												)
											);
									} else {
										data && exportToCSV(data, header, tableName, formatType);
									}
								}}
								onMouseEnter={(e) => {
									e.currentTarget.style.boxShadow = 'none'; // Remove shadow on hover
								}}
								onMouseLeave={(e) => {
									e.currentTarget.style.boxShadow = 'none'; // Remove shadow when not hovering
								}}
							>
								{
									<GetAppIcon
										style={{
											width: 20,
											height: 20,
											marginTop: 30,
											position: 'absolute',
											marginLeft: 20
										}}
									/>
								}
							</IconButton>
							)*/}
					</div>
					{download && (
						<IconButton
							style={{
								opacity: 1.5,
								position: 'absolute',
								right: '3.6%',
								marginTop: -37
							}}
							onClick={() => {
								if (
									[
										'fpna3',
										'fpna5',
										'fpna5-3-1-0',
										'fpna5-1-1-0',
										'fpna6',
										'fpna6-1-1',
										'fpna9',
										'fpna9-1-1',
										'fpna6-4-1',
										'fpna9-2-1',
										'fpna9-3-1',
										'fpna6-2-1',
										'fpna6-3-1'
									].includes(modelName)
								) {
									if (tableName === 'Pipeline Growth Assumptions') {
										dispatch(getPipelineGrowthAssumptionData(model, id));
									} else
										dispatch(
											getCustomisedDownloadData(
												modelName === 'fpna6' ||
													modelName === 'fpna6-1-1' ||
													modelName === 'fpna6-2-1' ||
													modelName === 'fpna6-3-1'
													? '6'
													: modelName === 'fpna9' ||
													  model === 'fpna9-1-1' ||
													  model === 'fpna6-4-1' ||
													  model === 'fpna9-2-1' ||
													  model === 'fpna9-3-1'
													? '9'
													: CustomisedDownloadDataFields?.[tableName]?.[0],
												id,
												CustomisedDownloadDataFields?.[tableName]?.[2],
												CustomisedDownloadDataFields?.[tableName]?.[3],
												CustomisedDownloadDataFields?.[tableName]?.[4]
											)
										);
								} else {
									data && exportToCSV(data, header, tableName, formatType);
								}
							}}
						>
							{<GetAppIcon style={{ width: 20, height: 20 }} />}
						</IconButton>
					)}
					{/*Line next to table name*/}
					{/*<Divider className={classes.tableDivider} />*/}
					<div style={{ marginBottom: 20 }}></div>
				</>
			)}
			{tableVisible &&
				((data?.table?.headers.length > 0 && separator) ||
				(data && data.length > 0 && !separator) ||
				(tableName === 'Data Tape' && data && data.length > 0) ||
				(data && data?.data && data.data.length > 0) ||
				(data && multiple && Object.keys(data.length > 0)) ? (
					<div>
						<TableContainer
							className={multiple || separator ? classes.tableContainer : ''}
						>
							<Table
								stickyHeader
								style={{
									borderBottom: '1px solid #D8DDE3',
									// marginBottom: 10,
									width: fullwidth ? '100%' : 'fit-content'
								}}
							>
								{multiple
									? multipleArray?.map((headItem, index) => {
											return (
												<div key={headItem} style={{ marginBottom: '20px' }}>
													<div style={{ display: 'flex' }}>
														{stateMultipleArray[headItem] ? (
															<MinusSquare
																className={classes.headerIcon}
																onClick={() =>
																	setStateMultipleArray({
																		...stateMultipleArray,
																		[`${headItem}`]: false
																	})
																}
															/>
														) : (
															<PlusSquare
																className={classes.headerIcon}
																onClick={() =>
																	setStateMultipleArray({
																		...stateMultipleArray,
																		[`${headItem}`]: true
																	})
																}
															/>
														)}
														<p className={classes.header}>{headItem}</p>
													</div>
													{stateMultipleArray[headItem] &&
														(!separator
															? renderNormalBody()
															: renderSeparatedBody(multiple, index))}
												</div>
											);
									  })
									: !separator
									? renderNormalBody()
									: multiSeparator || extraMultiSeparator
									? renderMultiSeparatedBody()
									: renderSeparatedBody()}
							</Table>
						</TableContainer>
					</div>
				) : (
					<center>
						<CircularProgress style={{ color: '#266696' }} size={26} />
					</center>
				))}
		</div>
	);
};

export default MainTable;
