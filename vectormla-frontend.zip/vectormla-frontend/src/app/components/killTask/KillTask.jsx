import React from 'react';
import { useStyles } from '../portfolio/portfolioStyles';

const KillTask = ({ model, killTaskFunction }) => {
	const classes = useStyles();
	return (
		<div
			style={{
				marginTop:
					model === 'fpna0'
						? '-25px'
						: model === 'fpna3'
						? '-60px'
						: [
								'fpna5',
								'fpna5-3-1',
								'fpna5-1-1-0',
								'fpna5-2-1-0',
								'fpna5-3-1-0',
								'fpna6',
								'fpna6-1-1',
								'fpna6-4-1',
								'fpna9',
								'fpna9-1-1',
								'fpna9-3-1',
								'fpna6-2-1',
								'fpna6-3-1',
								'fpna9-2-1'
						  ].includes(model)
						? '-25px'
						: ['default'].includes(model)
						? '18px'
						: ['prepayment'].includes(model)
						? '46px'
						: ['fpna4'].includes(model)
						? '-85px'
						: ['cashflow'].includes(model)
						? '-53px'
						: ['credit2', 'securitization'].includes(model)
						? '18px'
						: ['fpna2'].includes(model)
						? '10px'
						: '-60px',
				position: 'absolute',
				marginLeft: [
					'fpna3',
					'fpna5',
					'fpna5-3-1',
					'fpna5-1-1-0',
					'fpna5-2-1-0',
					'fpna5-3-1-0',
					'fpna1',
					'fpna6',
					'fpna6-1-1',
					'fpna6-2-1',
					'fpna6-3-1',
					'fpna6-4-1',
					'fpna9',
					'fpna9-1-1',
					'fpna0',
					'fpna2'
				].includes(model)
					? '534px'
					: [
							'fpna4',
							'fpna2',
							'fpna1',
							'credit2',
							'cashflow',
							'default',
							'prepayment'
					  ].includes(model)
					? '453px'
					: ['securitization'].includes(model)
					? '453px'
					: '481px',
				fontSize: '12px',
				color: 'black'
			}}
		>
			<button
				onClick={() => killTaskFunction()}
				className={classes.header__save}
			>
				Stop
			</button>
			<span style={{ color: '#53687E', margin: '0px 10px' }}>
				Estimated time of completion is 10 minutes
			</span>
		</div>
	);
};
export default KillTask;
