import { makeStyles } from '@material-ui/core';

const root = {
	marginTop: 2,
	opacity: 1,
	fontSize: '12px',
	overflow: 'initial',
	color: '#6E6F72',
	backgroundColor: '#DEDEDE',
	transition: '0.2s',
	minHeight: 28,
	paddingInline: 0,
	textTransform: 'initial',
	marginLeft: 19,
	marginRight: -14.9,

	width: 106.7,
	'& span': {
		borderRight: '1px solid #8C96A3',
		height: 16,
		color: '#6E6F72'
	},
	'&:last-of-type': {
		'& span:last-of-type': {
			borderRight: 'none'
		}
	},
	'&:hover': {
		'& span': {
			color: '#1C79BE'
		}
	}
};
export const useTabsStyles = makeStyles(() => ({
	indicator: {
		display: 'none'
	}
}));

export const useTabStyles = makeStyles(({ breakpoints }) => {
	return {
		root: () => ({
			[breakpoints.up('lg')]: {
				minWidth: 100
			},
			[breakpoints.down('lg')]: {
				minWidth: 85
			},
			...root
		})
	};
});
export const useHoveredTabStyles = makeStyles(({ breakpoints }) => {
	return {
		root: () => ({
			[breakpoints.up('lg')]: {
				minWidth: 100
			},
			[breakpoints.down('lg')]: {
				minWidth: 85
			},
			...root,
			'& span': {
				borderRight: '1px solid #8C96A3',
				height: 16,
				color: '#1C79BE'
			}
		})
	};
});
