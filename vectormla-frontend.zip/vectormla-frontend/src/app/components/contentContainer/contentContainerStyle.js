import { makeStyles } from '@material-ui/core';
import {
	contentHeaderContainer,
	contentHeader
} from '../../../common/assets/layout';

const text = {
	fontSize: 12,
	fontFamily: 'Roboto',
	whiteSpace: 'pre-wrap'
};

export const useStyles = makeStyles((theme) => ({
	headerIcon: {
		marginRight: 10,
		color: 'gray',
		cursor: 'pointer',
		position: 'relative',
		top: 2
	},
	header: {
		...text,
		fontWeight: 'bold'
	},
	text: {
		...text
	},
	hoveredText: {
		...text,
		cursor: 'pointer',
		'&:hover': {
			color: '#266696!important'
		}
	},
	contentHeaderContainer,
	contentHeader
}));
