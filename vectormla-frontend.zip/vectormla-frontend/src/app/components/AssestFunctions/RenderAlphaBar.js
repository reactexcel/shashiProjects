import React from 'react';
import { makeStyles } from '@material-ui/core';
import {
	numberCellWidth,
	collapsedDrawerWidth,
	aplphaCellHeight,
	numLeftPrefix,
	numTopPrefix
} from '../../../common/assets/layout';

const useStyles = makeStyles(() => ({
	alphabar: {
		position: 'absolute',
		zIndex: 99,
		left: -(collapsedDrawerWidth + numberCellWidth) + numLeftPrefix - 1,
		top: aplphaCellHeight + numTopPrefix
	},
	alphaCell: {
		width: numberCellWidth,
		height: 20,
		border: '1px solid #8C96A3',
		color: '#8C96A3',
		borderTop: 0,
		fontSize: 11,
		boxSizing: 'border-box',
		backgroundColor: '#E6E6E6',
		textAlign: 'center',
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'end'
	}
}));

const RenderAlphaBar = ({ containerHeight }) => {
	const classes = useStyles();

	let height = Math.floor(containerHeight / 20);
	let nums = [];

	for (let i = 0; i < height; i++) {
		nums.push(i + 1);
	}

	return (
		<div className={classes.alphabar}>
			{nums.map((num, index) => (
				<div
					key={index}
					className={`${classes.alphaCell} num_cell num_cell_${index}`}
				>
					{num}
				</div>
			))}
		</div>
	);
};

export default RenderAlphaBar;
