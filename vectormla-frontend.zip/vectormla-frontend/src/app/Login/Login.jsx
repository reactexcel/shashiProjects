import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import home from '../../common/assets/images/home-slider1.svg';
import desktop from '../../common/assets/images/desktop.svg';
import Header from '../../landing/header/Header';
import { loginMFA } from '../store/actions/auth.action';
import MainFooter from '../../landing/footer/MainFooter';
import { BorderAllRounded } from '@material-ui/icons';
const Login = ({ history }) => {
	document.body.classList.add('full');

	const dispatch = useDispatch();
	const [email, setEmail] = useState(null);
	const [password, setPassword] = useState(null);

	const submit = (e) => {
		e.preventDefault();

		dispatch(loginMFA({ email, password }, history));
	};
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				openModal={openModal}
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			{' '}
			<div className="login">
				<Header
					openModal={openModal}
					clickHandler={(value) => {
						setOpenModal(value);
					}}
				/>
				<section className="sign_up">
					<div className="container cont">
						<div className="row cont_sign">
							<div className="col-md-6 col-lg-5 left">
								<div className="title_block">
									<h3>
										<span className="static">Log into </span>
										<span className="static blue">Vector</span>
										<span className="ind">ML</span>
									</h3>
									<img src={desktop} alt="" />
								</div>
								<p className="info">
									You will need your corporate credentials to log in
								</p>
								<form onSubmit={submit}>
									<div className="form_control">
										<label label="email">Login name</label>
										<input
											onChange={(e) => setEmail(e.target.value)}
											type="text"
											name="email"
											id="email"
										/>
									</div>
									<div className="form_control">
										<label label="password">Password</label>
										<input
											onChange={(e) => setPassword(e.target.value)}
											type="password"
											name="password"
											id="password"
										/>
									</div>
									<button type="submit" style={{ borderRadius: 4 }}>
										{'Login'}
									</button>
								</form>
								<a href="#">Forgot login name?</a>
								<a href="#">Forgot password?</a>
							</div>
							<div className="col-md-6 col-lg-7 right">
								<img src={home} className="img-fluid" alt="" />
								<div
									style={{
										width: 100,
										height: 100,
										marginLeft: 250,
										position: 'absolute'
									}}
									onClick={() =>
										history.push({
											pathname: '/adminpanel/login'
										})
									}
								/>
							</div>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default withRouter(Login);
