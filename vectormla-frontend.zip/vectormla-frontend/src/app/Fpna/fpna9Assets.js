const requiredTablesFpnaV9 = ['assetamort_table'];
const requiredTablesFpnaV9_3_1 = ['assetamort_table'];

const tableDataFpnaV9 = [
	{
		id: '20',
		name: 'balance_sheet',
		title: 'Balance Sheet ',
		isExpanded: true
	},
	{
		id: '21',
		name: 'income_statement',
		title: 'Income Statement ',
		isExpanded: true
	},
	{
		id: '19',
		name: 'cashflow_statement',
		title: 'Cashflow Statement',
		isExpanded: true
	},
	{
		id: '25',
		name: 'loan_pricing',
		title: 'Loan Pricing',
		isExpanded: true
	},
	{
		id: '1',
		name: 'historical_daily_assetamort_table',
		title: 'Historical Portfolio Daily',
		isExpanded: true
	},
	{
		id: '2',
		name: 'historical_weekly_assetamort_table',
		title: 'Historical Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '3',
		name: 'historical_monthly_assetamort_table',
		title: 'Historical Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '4',
		name: 'daily_assetamort_table',
		title: 'Projected Portfolio Daily',
		isExpanded: true
	},
	{
		id: '5',
		name: 'weekly_assetamort_table',
		title: 'Projected Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '6',
		name: 'assetamort_table',
		title: 'Projected Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '23',
		name: 'assetamort_table_current',
		title: 'Projected Portfolio Run-off',
		isExpanded: true
	},
	{
		id: '24',
		name: 'assetamort_table_pipeline',
		title: 'Projected Portfolio Run-on',
		isExpanded: true
	},
	{
		id: '7',
		name: 'borrowing_base_daily',
		title: 'Borrowing Base Daily',
		isExpanded: true
	},
	{
		id: '8',
		name: 'borrowing_base_weekly',
		title: 'Borrowing Base Weekly',
		isExpanded: true
	},
	{
		id: '9',
		name: 'borrowing_base',
		title: 'Borrowing Base Monthly',
		isExpanded: true
	},
	{
		id: '10',
		name: 'wh_ineligible_daily',
		title: 'Ineligible Receivables Daily',
		isExpanded: true
	},
	{
		id: '11',
		name: 'wh_ineligible_weekly',
		title: 'Ineligible Receivables Weekly',
		isExpanded: true
	},
	{
		id: '12',
		name: 'wh_ineligible',
		title: 'Ineligible Receivables Monthly',
		isExpanded: true
	},
	{
		id: '16',
		name: 'excess_concentration_limits',
		title: 'Excess Concentration Limits',
		isExpanded: true
	},
	{
		id: '13',
		name: 'interest_paid_by_borrower_daily',
		title: 'Interest Paid by Borrower Daily',
		isExpanded: true
	},
	{
		id: '14',
		name: 'interest_paid_by_borrower_weekly',
		title: 'Interest Paid by Borrower Weekly',
		isExpanded: true
	},
	{
		id: '15',
		name: 'interest_paid_by_borrower',
		title: 'Interest Paid by Borrower Monthly',
		isExpanded: true
	},
	{
		id: '17',
		name: 'daily_available_cash',
		title: 'Available Cash Daily',
		isExpanded: true
	},
	{
		id: '18',
		name: 'available_cash',
		title: 'Available Cash Monthly',
		isExpanded: true
	},
	{
		id: '22',
		name: 'baddebt_expense',
		title: 'Bad Debt Support Schedule',
		isExpanded: true
	}
];
const tableDataFpnaV9_3_1 = [
	{
		id: '20',
		name: 'balance_sheet',
		title: 'Balance Sheet ',
		isExpanded: true
	},
	{
		id: '21',
		name: 'income_statement',
		title: 'Income Statement ',
		isExpanded: true
	},
	{
		id: '19',
		name: 'cashflow_statement',
		title: 'Cashflow Statement',
		isExpanded: true
	},
	{
		id: '25',
		name: 'loan_pricing',
		title: 'Loan Pricing  ',
		isExpanded: true
	},
	{
		id: '1',
		name: 'historical_daily_assetamort_table',
		title: 'Historical Portfolio Daily',
		isExpanded: true
	},
	{
		id: '2',
		name: 'historical_weekly_assetamort_table',
		title: 'Historical Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '3',
		name: 'historical_monthly_assetamort_table',
		title: 'Historical Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '4',
		name: 'daily_assetamort_table',
		title: 'Projected Portfolio Daily',
		isExpanded: true
	},
	{
		id: '5',
		name: 'weekly_assetamort_table',
		title: 'Projected Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '6',
		name: 'assetamort_table',
		title: 'Projected Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '23',
		name: 'assetamort_table_current',
		title: 'Projected Portfolio Run-off',
		isExpanded: true
	},
	{
		id: '24',
		name: 'assetamort_table_pipeline',
		title: 'Projected Portfolio Run-on',
		isExpanded: true
	},
	{
		id: '7',
		name: 'borrowing_base_daily',
		title: 'Borrowing Base Daily',
		isExpanded: true
	},
	{
		id: '8',
		name: 'borrowing_base_weekly',
		title: 'Borrowing Base Weekly',
		isExpanded: true
	},
	{
		id: '9',
		name: 'borrowing_base',
		title: 'Borrowing Base Monthly',
		isExpanded: true
	},
	{
		id: '10',
		name: 'wh_ineligible_daily',
		title: 'Ineligible Receivables Daily',
		isExpanded: true
	},
	{
		id: '11',
		name: 'wh_ineligible_weekly',
		title: 'Ineligible Receivables Weekly',
		isExpanded: true
	},
	{
		id: '12',
		name: 'wh_ineligible',
		title: 'Ineligible Receivables Monthly',
		isExpanded: true
	},
	{
		id: '16',
		name: 'excess_concentration_limits',
		title: 'Excess Concentration Limits',
		isExpanded: true
	},
	{
		id: '13',
		name: 'interest_paid_by_borrower_daily',
		title: 'Interest Paid by Borrower Daily',
		isExpanded: true
	},
	{
		id: '14',
		name: 'interest_paid_by_borrower_weekly',
		title: 'Interest Paid by Borrower Weekly',
		isExpanded: true
	},
	{
		id: '15',
		name: 'interest_paid_by_borrower',
		title: 'Interest Paid by Borrower Monthly',
		isExpanded: true
	},
	{
		id: '17',
		name: 'daily_available_cash',
		title: 'Available Cash Daily',
		isExpanded: true
	},
	{
		id: '18',
		name: 'available_cash',
		title: 'Available Cash Monthly',
		isExpanded: true
	},
	{
		id: '22',
		name: 'baddebt_expense',
		title: 'Bad Debt Support Schedule',
		isExpanded: true
	}
];
const tableDataFpnaV9_2_1 = [];
const tableDataFpnaV9_1_1 = [
	{
		id: '25',
		name: 'historical_sofr_rate',
		title: 'Historical SOFR Rate',
		isExpanded: true
	},
	{
		id: '26',
		name: 'forward_rates',
		title: 'Forward Rates ',
		isExpanded: true
	}
];
const requiredTablesFpnaV9_2_1 = [];
const requiredTablesFpnaV9_1_1 = [];
export {
	requiredTablesFpnaV9,
	tableDataFpnaV9,
	tableDataFpnaV9_2_1,
	requiredTablesFpnaV9_2_1,
	tableDataFpnaV9_3_1,
	requiredTablesFpnaV9_3_1,
	tableDataFpnaV9_1_1,
	requiredTablesFpnaV9_1_1
};
