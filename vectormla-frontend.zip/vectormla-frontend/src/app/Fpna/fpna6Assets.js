const requiredTablesFpnaV6_3_1 = ['assetamort_table'];
const tableDataFpnaV6_3_1 = [
	{
		id: '20',
		name: 'balance_sheet',
		title: 'Balance Sheet ',
		isExpanded: true
	},
	{
		id: '21',
		name: 'income_statement',
		title: 'Income Statement ',
		isExpanded: true
	},
	{
		id: '19',
		name: 'cashflow_statement',
		title: 'Cashflow Statement',
		isExpanded: true
	},
	{
		id: '25',
		name: 'loan_pricing',
		title: 'Loan Pricing ',
		isExpanded: true
	},
	{
		id: '1',
		name: 'historical_daily_assetamort_table',
		title: 'Historical Portfolio Daily',
		isExpanded: true
	},
	{
		id: '2',
		name: 'historical_weekly_assetamort_table',
		title: 'Historical Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '3',
		name: 'historical_monthly_assetamort_table',
		title: 'Historical Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '4',
		name: 'daily_assetamort_table',
		title: 'Projected Portfolio Daily',
		isExpanded: true
	},
	{
		id: '5',
		name: 'weekly_assetamort_table',
		title: 'Projected Portfolio Weekly',
		isExpanded: true
	},
	{
		id: '6',
		name: 'assetamort_table',
		title: 'Projected Portfolio Monthly',
		isExpanded: true
	},
	{
		id: '23',
		name: 'assetamort_table_current',
		title: 'Projected Portfolio Run-off',
		isExpanded: true
	},
	{
		id: '24',
		name: 'assetamort_table_pipeline',
		title: 'Projected Portfolio Run-on',
		isExpanded: true
	},
	{
		id: '7',
		name: 'borrowing_base_daily',
		title: 'Borrowing Base Daily',
		isExpanded: true
	},
	{
		id: '8',
		name: 'borrowing_base_weekly',
		title: 'Borrowing Base Weekly',
		isExpanded: true
	},
	{
		id: '9',
		name: 'borrowing_base',
		title: 'Borrowing Base Monthly',
		isExpanded: true
	},
	{
		id: '10',
		name: 'wh_ineligible_daily',
		title: 'Ineligible Receivables Daily',
		isExpanded: true
	},
	{
		id: '11',
		name: 'wh_ineligible_weekly',
		title: 'Ineligible Receivables Weekly',
		isExpanded: true
	},
	{
		id: '12',
		name: 'wh_ineligible',
		title: 'Ineligible Receivables Monthly',
		isExpanded: true
	},
	{
		id: '16',
		name: 'excess_concentration_limits',
		title: 'Excess Concentration Limits',
		isExpanded: true
	},
	{
		id: '13',
		name: 'interest_paid_by_borrower_daily',
		title: 'Interest Paid by Borrower Daily',
		isExpanded: true
	},
	{
		id: '14',
		name: 'interest_paid_by_borrower_weekly',
		title: 'Interest Paid by Borrower Weekly',
		isExpanded: true
	},
	{
		id: '15',
		name: 'interest_paid_by_borrower',
		title: 'Interest Paid by Borrower Monthly',
		isExpanded: true
	},
	{
		id: '17',
		name: 'daily_available_cash',
		title: 'Available Cash Daily',
		isExpanded: true
	},
	{
		id: '18',
		name: 'available_cash',
		title: 'Available Cash Monthly',
		isExpanded: true
	},
	{
		id: '22',
		name: 'baddebt_expense',
		title: 'Bad Debt Support Schedule',
		isExpanded: true
	}
];

const requiredTablesFpnaV6_1_1 = ['historical_sofr_rate', 'forward_rates'];
const requiredTablesFpnaV6_1_1_second = [];
const tableDataFpnaV6_1_1 = [
	{
		id: '25',
		name: 'historical_sofr_rate',
		title: 'Historical SOFR Rates',
		isExpanded: true
	},
	{
		id: '26',
		name: 'forward_rates',
		title: 'SOFR Forward Rates',
		isExpanded: true
	},
	{
		id: '27',
		name: 'projected_rates_table',
		title: 'SOFR Projected Rates'
	}
];
const tableDataFpnaV6_1_1_second = [
	{
		id: '28',
		name: 'shock_net_income',
		title: 'NI - Scenario Shocks'
	},
	{
		id: '29',
		name: 'duration_consolidated_table',
		title: 'PV and Duration'
	},
	{
		id: '30',
		name: 'summary_table_prcnt',
		title: 'Prepayment Curve Percent'
	},
	{
		id: '31',
		name: 'summary_output',
		title: 'Prepayment Curve Summary'
	}
];
const requiredTablesFpnaV6_2_1 = [];
const tableDataFpnaV6_2_1 = [
	{
		id: '6',
		name: 'vintage_df',
		title: 'Credit Historical Analysis'
	},
	{
		id: '1',
		name: 'outstanding_df',
		title: 'Outstanding Portfolio as % of Origination '
	},
	{
		id: '11',
		name: 'weighted_average_curve',
		title: 'Weighted Average Curve'
	},
	{
		id: '12',
		name: 'loss_distribution',
		title: 'Loss Distribution'
	},
	{
		id: '2',
		name: 'cumulative_chargeoff_df',
		title: 'Cumulative Charge-off '
	},
	{
		id: '4',
		name: 'monthly_chargeoff_df',
		title: 'Monthly Charge-off '
	},
	{
		id: '3',
		name: 'cumulative_chargeoff_netrecovery_df',
		title: 'Cumulative Charge-off - Net of Recovery '
	},
	{
		id: '5',
		name: 'monthly_chargeoff_netrecovery_df',
		title: 'Monthly Charge-off Net of Recovery '
	},
	{
		id: '7',
		name: 'roll_rate_ave',
		title: '12-Month Average Roll Rate'
	},
	{
		id: '8',
		name: 'bucket_analysis',
		title: 'Roll Rates Schedule 1 '
	},
	{
		id: '9',
		name: 'bucket_analysis1',
		title: 'Roll Rates Schedule 2 '
	},
	{
		id: '10',
		name: 'roll_rate',
		title: 'Roll Rates Schedule 3 ',
		isExpanded: true
	}
];

export {
	requiredTablesFpnaV6_3_1,
	tableDataFpnaV6_3_1,
	requiredTablesFpnaV6_1_1,
	requiredTablesFpnaV6_1_1_second,
	tableDataFpnaV6_1_1,
	tableDataFpnaV6_1_1_second,
	requiredTablesFpnaV6_2_1,
	tableDataFpnaV6_2_1
};
