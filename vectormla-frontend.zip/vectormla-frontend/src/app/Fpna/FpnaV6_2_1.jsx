//Credit Risk 6.2.1
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid, CircularProgress } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolioFPNA,
	downloadFPNATemplate,
	deletePortfolio,
	updatePortfolio,
	getScenarioFPNADetails,
	getPortfolioScenarios,
	getCalcStatus,
	runCalculate,
	downloadDataFile,
	downloadFpnaCustomReports,
	getSubPortofolios,
	getSegment,
	getCreditRisk6_2_1Charts
} from '../store/actions/fpna.action';
import Portfolio from '../components/portfolio/Portfolio';
import Chart from 'app/components/Chart/Chart';
import {
	GET_FPNA6_TABLES_CLEAN,
	GET_CHARTS6_CLEAN,
	TASK_PROGRESS_FPNA6,
	STOP_FPNA6_TIMER
} from '../store/types/fpna.type';
import { dynamicHeaders } from './liabilityTableFileds';
import { killTaskFunc } from 'app/store/actions/taskKill.action';
import MainTable from 'app/components/Table/MainTable';
import { requiredTablesFpnaV6_2_1, tableDataFpnaV6_2_1 } from './fpna6Assets';
const FpnaV6_2_1 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios6,
		tables6,
		status6,
		scenarios6,
		staus6ScenarioID,
		subPortofolio6,
		charts6_2_1
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [runningTaskId, setRunningTaskId] = useState();
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);
	// state to check first time status if success
	const [timerStarted, setTimerStarted] = useState(false);
	const [chartVisible, setChartVisible] = useState(false);
	const [chartVisible2, setChartVisible2] = useState(false);
	const [chartVisible3, setChartVisible3] = useState(false);
	const [chartVisible4, setChartVisible4] = useState(false);
	const [chartsData, setChartsData] = useState([]);
	const [chartsData2, setChartsData2] = useState([]);

	useEffect(() => {
		if (selectedSubPorofolio?.[0]?.id) {
			dispatch(getCreditRisk6_2_1Charts(selectedSubPorofolio?.[0]?.id));
		}
	}, [selectedSubPorofolio]);

	useEffect(() => {
		let chart1 = [];
		let chart2 = [];
		let chart3 = [];
		let chart4 = [];
		let chart5 = [];
		let chart6 = [];
		let tempChart1 = [];
		let tempChart2 = [];
		let tempChart3 = [];
		let tempChart4 = [];
		let tempChart5 = [];
		let tempChart6 = [];
		subPortofolio6?.chart_delinquency?.['date'].forEach((val1, i) => {
			tempChart1.push({
				date: val1,
				status_1a_del_prcnt:
					subPortofolio6?.chart_delinquency?.['status_1a_del_prcnt'][i],
				status_1b_del_prcnt:
					subPortofolio6?.chart_delinquency?.['status_1b_del_prcnt'][i],
				status_2_del_prcnt:
					subPortofolio6?.chart_delinquency?.['status_2_del_prcnt'][i],
				status_3_del_prcnt:
					subPortofolio6?.chart_delinquency?.['status_3_del_prcnt'][i],
				status_4_del_prcnt:
					subPortofolio6?.chart_delinquency?.['status_4_del_prcnt'][i]
			});
			chart1.push(tempChart1);
		});

		if (subPortofolio6?.chart_default) {
			subPortofolio6?.chart_default?.['x-axis'].forEach((val1, i) => {
				let tempObj = { date: val1 };

				// Loop through keys of chart_default and exclude x-label
				for (let key in subPortofolio6?.chart_default) {
					if (key !== 'x-label') {
						tempObj[key] = subPortofolio6?.chart_default[key][i];
					}
				}

				tempChart2.push(tempObj);
			});
		}
		chart2.push(tempChart2);

		if (subPortofolio6?.chart_closing_balance_cpr_scenarios) {
			subPortofolio6?.chart_closing_balance_cpr_scenarios?.['Date'].forEach(
				(val1, i) => {
					let tempObj = { Date: val1 };

					// Loop through keys of chart_closing_balance_cpr_scenarios and exclude x-label
					for (let key in subPortofolio6?.chart_closing_balance_cpr_scenarios) {
						if (key !== 'Date') {
							tempObj[key] =
								subPortofolio6?.chart_closing_balance_cpr_scenarios[key][i];
						}
					}

					tempChart6.push(tempObj);
				}
			);
		}
		chart6.push(tempChart6);

		subPortofolio6?.chart_closing_balance?.['date'].forEach((val1, i) => {
			tempChart3.push({
				date: val1,
				closing_balance:
					subPortofolio6?.chart_closing_balance?.['closing_balance'][i]
			});
			chart3.push(tempChart3);
		});

		subPortofolio6?.timing_curve?.['period'].forEach((val1, i) => {
			tempChart4.push({
				period: val1,
				cumulative_curve: subPortofolio6?.timing_curve?.['cumulative_curve'][i]
			});
			chart4.push(tempChart4);
		});

		subPortofolio6?.timing_curve?.['period'].forEach((val1, i) => {
			tempChart5.push({
				period: val1,
				timing_curve: subPortofolio6?.timing_curve?.['timing_curve'][i]
			});
			chart5.push(tempChart5);
		});

		let updatedCharts = [
			{
				ch: chart1,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart2,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart3,
				xIndex: 'date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart4,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart5,
				xIndex: 'period',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			},
			{
				ch: chart6,
				xIndex: 'Date',
				yIndex: 'YAxis',
				xDistance: 390,
				format: 'com'
			}
		];
		setChartsData(updatedCharts);
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [chartVisible, chartVisible2, chartVisible3, chartVisible4]);

	useEffect(() => {
		if (charts6_2_1) {
			let chart1 = [];
			let chart2 = [];
			let chart3 = [];
			let chart4 = [];
			let chart5 = [];
			let chart6 = [];
			let chart7 = [];
			let chart8 = [];
			let chart9 = [];
			let chart10 = [];
			let tempChart1 = [];
			let tempChart2 = [];
			let tempChart3 = [];
			let tempChart4 = [];
			let tempChart5 = [];
			let tempChart6 = [];
			let tempChart7 = [];
			let tempChart8 = [];
			let tempChart9 = [];
			let tempChart10 = [];
			charts6_2_1?.chart1?.['date'].forEach((val1, i) => {
				tempChart1.push({
					date: val1,
					status_1_del_prcnt: charts6_2_1?.chart1?.['status_1_del_prcnt'][i],
					status_2_del_prcnt: charts6_2_1?.chart1?.['status_2_del_prcnt'][i],
					status_3_del_prcnt: charts6_2_1?.chart1?.['status_3_del_prcnt'][i],
					status_4_del_prcnt: charts6_2_1?.chart1?.['status_4_del_prcnt'][i],
					total_del_prcnt: charts6_2_1?.chart1?.['total_del_prcnt'][i]
				});
				chart1.push(tempChart1);
			});

			charts6_2_1?.chart2?.['date'].forEach((val1, i) => {
				tempChart2.push({
					date: val1,
					new_origination_a: charts6_2_1?.chart2?.['new_origination_a'][i]
				});
				chart2.push(tempChart2);
			});

			charts6_2_1?.chart3?.['date'].forEach((val1, i) => {
				tempChart3.push({
					date: val1,
					monthly_chargeoff: charts6_2_1?.chart3?.['monthly_chargeoff'][i]
				});
				chart3.push(tempChart3);
			});
			charts6_2_1?.chart4?.['date'].forEach((val1, i) => {
				tempChart4.push({
					date: val1,
					recovery: charts6_2_1?.chart4?.['recovery'][i]
				});
				chart4.push(tempChart4);
			});
			charts6_2_1?.chart5?.['period'].forEach((val1, i) => {
				tempChart5.push({
					date: val1,
					2018: charts6_2_1?.chart5?.['2018'][i],
					2019: charts6_2_1?.chart5?.['2019'][i],
					2020: charts6_2_1?.chart5?.['2020'][i],
					2021: charts6_2_1?.chart5?.['2021'][i],
					2022: charts6_2_1?.chart5?.['2022'][i],
					Average: charts6_2_1?.chart5?.['Average'][i]
				});
				chart5.push(tempChart5);
			});
			charts6_2_1?.chart6?.['period'].forEach((val1, i) => {
				tempChart6.push({
					date: val1,
					2018: charts6_2_1?.chart6?.['2018'][i],
					2019: charts6_2_1?.chart6?.['2019'][i],
					2020: charts6_2_1?.chart6?.['2020'][i],
					2021: charts6_2_1?.chart6?.['2021'][i],
					2022: charts6_2_1?.chart6?.['2022'][i],
					Average: charts6_2_1?.chart6?.['Average'][i]
				});
				chart6.push(tempChart6);
			});
			charts6_2_1?.chart7?.['period'].forEach((val1, i) => {
				tempChart9.push({
					date: val1,
					2018: charts6_2_1?.chart7?.['2018'][i],
					2019: charts6_2_1?.chart7?.['2019'][i],
					2020: charts6_2_1?.chart7?.['2020'][i],
					2021: charts6_2_1?.chart7?.['2021'][i],
					2022: charts6_2_1?.chart7?.['2022'][i],
					Average: charts6_2_1?.chart7?.['Average'][i]
				});
				chart9.push(tempChart9);
			});
			charts6_2_1?.chart8?.['period'].forEach((val1, i) => {
				tempChart10.push({
					date: val1,
					2018: charts6_2_1?.chart8?.['2018'][i],
					2019: charts6_2_1?.chart8?.['2019'][i],
					2020: charts6_2_1?.chart8?.['2020'][i],
					2021: charts6_2_1?.chart8?.['2021'][i],
					2022: charts6_2_1?.chart8?.['2022'][i],
					Average: charts6_2_1?.chart8?.['Average'][i]
				});
				chart10.push(tempChart10);
			});
			charts6_2_1?.chart3?.['date'].forEach((val1, i) => {
				tempChart7.push({
					date: val1,
					monthly_chargeoff_prcnt:
						charts6_2_1?.chart3?.['monthly_chargeoff_prcnt'][i]
				});
				chart7.push(tempChart7);
			});
			charts6_2_1?.chart4?.['date'].forEach((val1, i) => {
				tempChart8.push({
					date: val1,
					recovery_prcnt: charts6_2_1?.chart4?.['recovery_prcnt'][i]
				});
				chart8.push(tempChart8);
			});

			let updatedCharts = [
				{
					ch: chart1,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart2,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart3,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart4,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart5,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart6,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart7,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart8,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart9,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart10,
					xIndex: 'date',
					yIndex: 'YAxis',
					xDistance: 390,
					format: 'com'
				}
			];
			setChartsData2(updatedCharts);
		}
	}, [chartVisible4, charts6_2_1]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios4(selectedScenario[0]);
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [selectedScenario]);

	useEffect(() => {
		if (!portfolios6 && user?.allowed_pages?.includes(3)) fetchPortfolio();
		else setSelectedPortfolio(portfolios6?.[0]);
		if (staus6ScenarioID) {
			setRunningTaskId();
			stopTimerFunction();
			dispatch(stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false)));
		}
	}, [portfolios6]);

	useEffect(() => {
		selectedScenario[0]?.id && calculateStatus(selectedScenario[0]?.id, true);
		// fetch table data if it is opened
		if (Object.keys(tables6 || {}).length > 0)
			fetchScenariosDetails(Object.keys(tables6));
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
		selectedScenario[0]?.id && fetchSubPorofolios4(selectedScenario[0]);
		// for charts data
	}, [selectedScenario]);

	const dispatchClean = (/*unmount*/ callBack) => {
		dispatch({
			type: GET_FPNA6_TABLES_CLEAN
			// payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS6_CLEAN });
		stopTimerFunction();
		dispatch(
			stopTimer('cfm6', 'change', () => {
				setTimerStarted(false);
				callBack && callBack();
			})
		);
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (selectedScenario[0] && status6 === 'SUCCESS') {
			fetchScenariosDetails();
			setTimerStarted(false);
		}
		selectedScenario[0] &&
			(status6 === 'STOPPED' ||
				status6 === 'FAILURE' ||
				status6 === 'stopped') &&
			calculateStatus(selectedScenario[0]?.id, true);
	}, [status6]);

	const fetchSubPorofolios = () => {
		dispatch(
			getSubPortofolios(
				'6',
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};
	const fetchSubPorofolios4 = () => {
		dispatch(
			getCreditRisk6_2_1Charts(
				selectedScenario[0]?.id,
				(scenriosSubPortofolios) => {
					setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
					scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
				}
			)
		);
	};
	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('6', supPorofolioId));
	};

	const fetchScenarioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getScenarioFPNADetails('6', selectedScenario[0]?.id, type, (data) => {
				if (type === 'default-vintage') {
					const finalObject = {};
					Object.keys(data?.vintage_df?.category).forEach((item) => {
						finalObject[item] = data?.vintage_df?.category[item];
					});
				}
			})
		);
	};

	const fetchScenariosDetails = async (openedTables) => {
		const fetchPromises = (openedTables || requiredTablesFpnaV6_2_1).map(
			(table) => fetchScenarioDetails(selectedScenario[0]?.id, table + '/')
		);
		// this line is to wait for all the promises to resolve
		await Promise.all(fetchPromises);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('6', selectedPortfolio?.id, () => {
				dispatchClean();
				setSelectedScenario([]);
				setSelectedSubPorofolio([]);
				fetchPortfolio();
			})
		);
	};
	const uploadFunction = (formData) => {
		dispatchClean(() => {
			dispatch(
				updatePortfolio(
					'6',
					selectedPortfolio?.id,
					formData,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchScenarios(selectedPortfolio?.id, 'create');
					},
					'fpna6'
				)
			);
			dispatch({
				type: TASK_PROGRESS_FPNA6,
				payload: '0.0 %'
			});
		});
	};
	const setDataFunction = (val) => {
		setDataType(val);
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id);
		if (tables6) fetchScenarioDetails(selectedScenario[0]?.id, val);
	};
	const updateFunction = (name) => {
		dispatchClean(() =>
			dispatch(
				updatePortfolio('6', selectedPortfolio?.id, { name }, () => {
					fetchPortfolio();
				})
			)
		);
	};
	const createFunction = (name, file) => {
		dispatchClean(() =>
			dispatch(
				createPortfolioFPNA(
					'6',
					name,
					user?.company_id,
					file,
					(res) => {
						setRunningTaskId(res.data.id);
						fetchPortfolio('create');
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: '0.0 %'
						});
					},
					'fpna6'
				)
			)
		);
	};
	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('6', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, create);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, create) => {
		dispatch(
			getPortfolioScenarios('6', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm6', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const calculateStatus = (supPorofolioId, checkInStart) => {
		getCalcStatus(
			'cfm6/portfolio',
			selectedSubPorofolio[0]?.id || selectedScenario?.[0]?.id,
			(res) => {
				if (checkInStart && res?.task_state === 'SUCCESS') {
					setTimerStarted(false);
					return;
				} else {
					dispatch(startTimer('cfm6', supPorofolioId, ''));
					setRunningTaskId(selectedPortfolio?.id);
					setTimerStarted(true);
					if (res.task_state !== 'SUCCESS' && res.task_state !== 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: res.task_progress
						});
					}
					if (res.task_state === 'FAILURE') {
						dispatch({
							type: TASK_PROGRESS_FPNA6,
							payload: 'Failed'
						});
						dispatch(
							killTaskFunc('cfm6', selectedPortfolio?.id, () => {
								deleteFunction();
								setRunningTaskId();
								stopTimerFunction();
								dispatch(
									stopTimer('cfm6', 'STOPPED', () => setTimerStarted(false))
								);
							})
						);
					}
				}
			}
		);
	};
	const runCalculateFunction = (supPorofolioId) => {
		dispatch(
			runCalculate('6', supPorofolioId?.[0]?.id, () =>
				calculateStatus(supPorofolioId?.[0]?.id)
			)
		);
	};
	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA6_TIMER,
			payload: { status6: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog, callBack) => {
		let id = selectedPortfolio?.id;
		if (('' + status6)?.toLowerCase() === 'pending') {
			let modelName = 'cfm6';
			dispatch(
				killTaskFunc(modelName, id, () => {
					deleteFunction();
					closeKillTaskDialog && closeKillTaskDialog();
					setRunningTaskId();
					stopTimerFunction();
					dispatch(
						stopTimer(modelName, 'STOPPED', () => {
							setTimerStarted(false);
							callBack && callBack();
						})
					);
				})
			);
		} else {
			setTimerStarted(false);
			callBack && callBack();
		}
	};

	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);

	useEffect(() => {
		if (collapsed >= 1) setChartVisible4(true);
		else if (collapsed === 0 && chartVisible4) setChartVisible4(false);
	}, [collapsed]);

	const typeHeaders = (tableName, category) => {
		if (tableName) return dynamicHeaders(category);
		else return null;
	};
	const renderChart = () => {
		return (
			subPortofolio6 && (
				<div>
					<div style={{ marginTop: 30 }}></div>
					<hr />
					<div style={{ marginTop: 20 }}></div>

					<div
						className={classes.contentHeaderContainer}
						onClick={() => setChartVisible(!chartVisible)}
					>
						<p className={classes.contentHeader}>{'Charts'}</p>
					</div>
					{chartVisible &&
						subPortofolio6 &&
						Object.keys(subPortofolio6).length > 0 && (
							<div className={classes.datechat__charts}>
								<br />
								{chartsData?.length > 0 && (
									<Grid
										container
										spacing={1}
										justify="flex-start"
										alignItems="center"
										direction="row"
									>
										{subPortofolio6?.chart_default && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[1]?.ch}
													nameLegend={`Default`}
													brushID={`Default`}
													sizeLegend="14px"
													dataX={`x-axis`}
													xDistance={400}
													format={'per'}
													noCharts={Object.keys(
														subPortofolio6?.chart_default || {}
													).filter((key) => key !== 'x-axis')}
													customTooltip
												/>
											</Grid>
										)}
										{subPortofolio6?.chart_delinquency && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[0]?.ch}
													nameLegend={`Delinquency`}
													brushID={`delinquency`}
													sizeLegend="14px"
													dataX={`date`}
													xDistance={400}
													format={'per'}
													noCharts={[
														'status_1a_del_prcnt',
														'status_1b_del_prcnt',
														'status_2_del_prcnt',
														'status_3_del_prcnt',
														'status_4_del_prcnt'
													]}
												/>
											</Grid>
										)}
										{subPortofolio6?.timing_curve?.cumulative_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[3]?.ch}
													nameLegend={`Cumulative Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['cumulative_curve']}
												/>
											</Grid>
										)}
										{subPortofolio6?.timing_curve?.timing_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6}
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[4]?.ch}
													nameLegend={`Timing Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['timing_curve']}
												/>
											</Grid>
										)}
									</Grid>
								)}
							</div>
						)}
					{chartVisible &&
						!subPortofolio6?.chart_closing_balance &&
						!subPortofolio6.chart_default &&
						!subPortofolio6.chart_delinquency && (
							<div className={classes.progressContainer}>
								<CircularProgress
									style={{
										color: '#266696',
										marginTop: 0,
										marginLeft: '49%'
									}}
									size={26}
								/>
							</div>
						)}
				</div>
			)
		);
	};

	const renderChart2 = () => {
		return (
			subPortofolio6 && (
				<div>
					<div style={{ marginTop: 30 }}></div>
					<hr />
					<div style={{ marginTop: 20 }}></div>
					<div
						className={classes.contentHeaderContainer}
						onClick={() => setChartVisible2(!chartVisible2)}
					>
						<p className={classes.contentHeader}>{'Credit Charts'}</p>
					</div>
					{chartVisible2 &&
						subPortofolio6 &&
						Object.keys(subPortofolio6).length > 0 && (
							<div className={classes.datechat__charts}>
								<br />
								{chartsData?.length > 0 && (
									<Grid
										container
										spacing={1}
										justify="flex-start"
										alignItems="center"
										direction="row"
									>
										{subPortofolio6?.chart_default && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[1]?.ch}
													nameLegend={`Default`}
													brushID={`Default`}
													sizeLegend="14px"
													dataX={`x-axis`}
													xDistance={400}
													format={'per'}
													noCharts={Object.keys(
														subPortofolio6?.chart_default || {}
													).filter((key) => key !== 'x-axis')}
													customTooltip
												/>
											</Grid>
										)}
										{subPortofolio6?.chart_delinquency && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[0]?.ch}
													nameLegend={`Delinquency`}
													brushID={`delinquency`}
													sizeLegend="14px"
													dataX={`date`}
													xDistance={400}
													format={'per'}
													noCharts={[
														'status_1a_del_prcnt',
														'status_1b_del_prcnt',
														'status_2_del_prcnt',
														'status_3_del_prcnt',
														'status_4_del_prcnt'
													]}
												/>
											</Grid>
										)}
									</Grid>
								)}
							</div>
						)}
					{chartVisible2 &&
						!subPortofolio6?.chart_closing_balance &&
						!subPortofolio6.chart_default &&
						!subPortofolio6.chart_delinquency && (
							<div className={classes.progressContainer}>
								<CircularProgress
									style={{
										color: '#266696',
										marginTop: 0,
										marginLeft: '49%'
									}}
									size={26}
								/>
							</div>
						)}
				</div>
			)
		);
	};
	const renderChart3 = () => {
		return (
			subPortofolio6 && (
				<div>
					<div
						className={classes.contentHeaderContainer}
						onClick={() => setChartVisible3(!chartVisible3)}
					>
						<p className={classes.contentHeader}>{'Timing Charts'}</p>
					</div>
					{chartVisible3 &&
						subPortofolio6 &&
						Object.keys(subPortofolio6).length > 0 && (
							<div className={classes.datechat__charts}>
								<br />
								{chartsData?.length > 0 && (
									<Grid
										container
										spacing={1}
										justify="flex-start"
										alignItems="center"
										direction="row"
									>
										{subPortofolio6?.timing_curve?.cumulative_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[3]?.ch}
													nameLegend={`Cumulative Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['cumulative_curve']}
												/>
											</Grid>
										)}
										{subPortofolio6?.timing_curve?.timing_curve && (
											<Grid
												item
												xs={12}
												sm={12}
												md={6} // Changed from 4 to 6
												className={classes.container__chart}
											>
												<Chart
													dataT={chartsData?.[4]?.ch}
													nameLegend={`Timing Curve`}
													sizeLegend="14px"
													dataX={`period`}
													xDistance={400}
													format={'per'}
													noCharts={['timing_curve']}
												/>
											</Grid>
										)}
									</Grid>
								)}
							</div>
						)}
					{chartVisible3 &&
						!subPortofolio6?.chart_closing_balance &&
						!subPortofolio6.chart_default &&
						!subPortofolio6.chart_delinquency && (
							<div className={classes.progressContainer}>
								<CircularProgress
									style={{
										color: '#266696',
										marginTop: 0,
										marginLeft: '49%'
									}}
									size={26}
								/>
							</div>
						)}
				</div>
			)
		);
	};
	const [dataReady, setDataReady] = useState(false);

	useEffect(() => {
		if (charts6_2_1 && subPortofolio6) {
			setDataReady(true); // Data is ready, update the state to reflect this
		} else {
			setDataReady(false); // Data is not ready, continue showing loading
		}
	}, [charts6_2_1, subPortofolio6, chartVisible4, dataReady]);

	const renderChart4 = () => {
		return (
			<div>
				<div style={{ marginTop: 30 }}></div>
				<hr />
				<div style={{ marginTop: 20 }}></div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible4(!chartVisible4)}
					style={{ paddingBottom: !chartVisible4 ? 150 : 0 }}
				>
					<p className={classes.contentHeader}>{'Vintage Charts'}</p>
				</div>
				{chartVisible4 &&
					(dataReady ? (
						<div className={classes.datechat__charts}>
							<br />
							{chartsData2?.length > 0 && (
								<Grid
									container
									spacing={1}
									justify="flex-start"
									alignItems="center"
									direction="row"
								>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[1]?.ch}
											nameLegend={`Origination`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'com'}
											noCharts={['new_origination_a']}
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[0]?.ch}
											nameLegend={`Delinquency`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={[
												'status_1_del_prcnt',
												'status_2_del_prcnt',
												'status_3_del_prcnt',
												'status_4_del_prcnt',
												'total_del_prcnt'
											]}
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[4]?.ch}
											nameLegend={`Cumulative Charge-off Vintage`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={[
												'2018',
												'2019',
												'2020',
												'2021',
												'2022',
												'Average'
											]}
											customTooltip
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[5]?.ch}
											nameLegend={`Cumulative Charge-off - Net of Recovery`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={[
												'2018',
												'2019',
												'2020',
												'2021',
												'2022',
												'Average'
											]}
											customTooltip
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[2]?.ch}
											nameLegend={`Charge Off $`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'com'}
											noCharts={['monthly_chargeoff']}
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[6]?.ch}
											nameLegend={`Charge Off %`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={['monthly_chargeoff_prcnt']}
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[3]?.ch}
											nameLegend={`Recovery $`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'com'}
											noCharts={['recovery']}
										/>
									</Grid>
									<Grid
										item
										xs={12}
										sm={12}
										md={6}
										className={classes.container__chart}
									>
										<Chart
											dataT={chartsData2?.[7]?.ch}
											nameLegend={`Recovery %`}
											sizeLegend="14px"
											dataX={`date`}
											xDistance={400}
											format={'per'}
											noCharts={['recovery_prcnt']}
										/>
									</Grid>
								</Grid>
							)}
						</div>
					) : (
						<div
							className={classes.progressContainer}
							style={{ marginBottom: 150 }}
						>
							<CircularProgress
								style={{
									color: '#266696',
									marginTop: 0,
									marginLeft: '49%'
								}}
								size={26}
							/>
						</div>
					))}
			</div>
		);
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		multiSeparator,
		extraMultiSeparator
	) => {
		let finalTableName =
			tableName === 'specialtable2' ? 'assetamort_table' : tableName;

		if (['Vintage', 'Portfolio'].includes(verboseTableName)) return null;

		const fetchData = () => {
			const tableKeys = Object.keys(tables6 || {});
			const isTableDataMissing = !tableKeys.includes(tableName);

			if (
				(['stopped', 'SUCCESS'].includes(('' + status6).toLowerCase()) &&
					isTableDataMissing) ||
				staus6ScenarioID !== selectedScenario?.[0]?.id
			) {
				fetchScenarioDetails(selectedScenario[0]?.id, tableName + '/');
			}
		};

		return (
			<div>
				{[
					'Credit Historical Analysis',
					'Weighted Average Curve',
					'12-Month Average Roll Rate'
				].includes(verboseTableName) ? (
					<>
						<div
							style={{
								marginTop: verboseTableName === 'Balance Sheet ' ? 20 : 30
							}}
						></div>
						<hr />
						<div style={{ marginTop: 20 }}></div>
					</>
				) : (
					''
				)}
				<MainTable
					statusScenarioId={staus6ScenarioID}
					status={('' + status6).toLowerCase()}
					header={tableData && tableData[finalTableName]?.columns}
					data={tableData && tableData[finalTableName]}
					attributes={
						tableData &&
						tableData[finalTableName]?.data &&
						Object.keys(tableData[finalTableName]?.columns)
					}
					tableData={tableData}
					multiSeparator={multiSeparator}
					extraMultiSeparator={extraMultiSeparator}
					tableId={tableId}
					tableName={verboseTableName}
					tableDataName={finalTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					collapsed={collapsed}
					separator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								multiSeparator ? 'category' : 'category2'
							]
					)}
					nestedSeparator={typeHeaders(
						finalTableName,
						tableData?.[finalTableName]?.[
							!multiSeparator ? 'category2' : 'category'
						] ||
							tableData?.[finalTableName]?.[
								!multiSeparator ? 'category' : 'category2'
							]
					)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model="6"
					id={selectedScenario[0]?.id}
					modelName="fpna6"
					fetchData={fetchData}
				/>
			</div>
		);
	};

	const renderTables = () => {
		return tableDataFpnaV6_2_1.map((table) => {
			const { id, name, title, isExpanded, hasSecondValue } = table;
			return renderTable(
				id,
				name,
				tables6,
				title,
				'',
				'',
				isExpanded,
				hasSecondValue
			);
		});
	};

	if (
		!user?.allowed_pages?.includes(2) ||
		!user?.allowed_section2.includes(204)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />
			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							dispatchClean={() => dispatchClean()}
							model={'fpna6-2-1'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							timerStarted={timerStarted}
							loading={('' + status6).toLowerCase() === 'pending'}
							key={1006}
							portfolioList={portfolios6 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios6.filter((item) => item.id == val)[0]
								);
							}}
							// create={(name, file) => createFunction(name, file)}
							// update={(name) => updateFunction(name)}
							// deleteObj={() => deleteFunction()}
							upload={(formData) => uploadFunction(formData)}
							downloadFile={() => {
								dispatch(downloadDataFile('6', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNATemplate('6'));
							}}
							data={[]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={scenarios6?.results}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => setSelectedScenario([item])}
							setData={(val) => setDataFunction(val)}
							downloadCustomReports={(type) => {
								dispatch(
									downloadFpnaCustomReports('6', selectedScenario[0]?.id, type)
								);
							}}
							collapsed={collapsed}
							runCalculateFunction={runCalculateFunction}
							selectedData={dataType}
							seconds={0}
							status={status6}
							minutes={0}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<>{renderTables()}</>
						{/*renderChart()*/}
						{/* Credit charts renderChart2() */}
						{/* Timing charts renderChart3() */}
						{renderChart4()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default FpnaV6_2_1;
