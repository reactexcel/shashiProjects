const requiredTables_FpnaV5 = [
	'balancesheet',
	'ol_accrued_interest',
	'demand_deposits_currentbook',
	'assetamort_table_brokermix',
	'oa_accrued_interest',
	'loanorigination_supportschedule',
	'mtgcommission_supportschedule',
	'giccommission_supportschedule',
	'term_deposits_currentbook',
	'term_deposits_new',
	'deposit_matrix',
	'rate_analysis',
	'rate_analysis_pipeline',
	'rate_new_values',
	'rate_analysis_current',
	'assetamort_table',
	'assetamort_table_current',
	'assetamort_table_pipeline',
	'pipelinevectors',
	'pipeline_supportschedule',
	'rwa',
	'ecl',
	'income_statement',
	'nii_table',
	'nii_schedule',
	'product_cost_schedule',
	'derivative_swap',
	'term_deposits_consolidated'
];
const requiredTables_FpnaV5_2 = [
	'historical_swap_table',
	'swap_table',
	'duration_consolidated_table',
	'duration_pipeline_table',
	'duration_current_table'
];
const requiredTables_FpnaV5_1_1 = [
	'historical_swap_table',
	'swap_table',
	'duration_consolidated_table',
	'duration_pipeline_table',
	'duration_current_table'
];
const requiredTables_FpnaV5_4_1 = [
	'historical_swap_table',
	'swap_table',
	'duration_consolidated_table',
	'duration_pipeline_table',
	'duration_current_table'
];
const requiredTables_FpnaV5_2_1 = [
	'historical_swap_table',
	'swap_table',
	'duration_consolidated_table',
	'duration_pipeline_table',
	'duration_current_table'
];
const requiredTables_FpnaV5_3_2 = [];

const tableData_FpnaV5 = [
	{
		id: '199',
		name: 'balancesheet',
		title: 'Balance Sheet'
	},
	{
		id: '200',
		name: 'income_statement',
		title: 'Income Statement'
	},
	{
		id: '201',
		name: 'nii_schedule',
		title: 'NII Schedule'
	},
	{
		id: '4012',
		name: 'rwa',
		title: 'Risk Weighted Asset'
	},
	{
		id: '40002321',
		name: 'amort_continuity_compact',
		title: 'Amort Continuity Consolidated'
		// isExpanded: true
	},
	{
		id: '400023221',
		name: 'amort_continuity_current_compact',
		title: 'Amort Continuity Current'
		// isExpanded: true
	},
	{
		id: '40023221',
		name: 'amort_continuity_pipeline_compact',
		title: 'Amort Continuity Pipeline'
		// isExpanded: true
	},
	{
		id: '4007',
		name: 'assetamort_table',
		title: 'Asset Amortization Consolidated'
		// isExpanded: true
	},
	{
		id: '4008',
		name: 'assetamort_table_current',
		title: 'Asset Amortization Current'
		// isExpanded: true
	},
	{
		id: '4009',
		name: 'assetamort_table_pipeline',
		title: 'Asset Amortization Pipeline'
		// isExpanded: true
	},
	{
		id: '35003',
		name: 'term_deposits_consolidated',
		title: 'Term Deposits Consolidated',
		isExpanded: true
	},
	{
		id: '3133',
		name: 'term_deposits_currentbook',
		title: 'Term Deposits Current Book',
		isExpanded: true
	},
	{
		id: '353',
		name: 'term_deposits_new',
		title: 'Term Deposits New',
		isExpanded: true
	},
	{
		id: '1119',
		name: 'demand_deposits_currentbook',
		title: 'Demand Deposits'
	},
	{
		id: '500003',
		name: 'deposit_matrix',
		title: 'Deposit Matrix'
	},
	{
		id: '196',
		name: 'loanorigination_supportschedule',
		title: 'Loan Origination Fee'
	},
	{
		id: '195',
		name: 'mtgcommission_supportschedule',
		title: 'Mortgage Broker Commission'
	},
	{
		id: '196',
		name: 'giccommission_supportschedule',
		title: 'Deposits Broker Commission'
	},
	{
		id: '40001',
		name: 'rate_analysis',
		title: 'Rate Analysis - Consolidated'
		// isExpanded: true
	},
	{
		id: '40002',
		name: 'rate_analysis_current',
		title: 'Rate Analysis - Current'
		// isExpanded: true
	},
	{
		id: '40003',
		name: 'rate_analysis_pipeline',
		title: 'Rate Analysis - Pipeline'
		// isExpanded: true
	},
	{
		id: '4003221',
		name: 'investment_supportschedule',
		title: 'Investment Support Schedule'
	},
	{
		id: '2042',
		name: 'derivative_swap',
		title: 'Derivative Swap'
	},
	{
		id: '40004',
		name: 'rate_new_values',
		title: 'Interest Rate Vectors'
	},
	{
		id: '203',
		name: 'product_cost_schedule',
		title: 'Product Cost Schedule'
	},
	{
		id: '198',
		name: 'assetamort_table_brokermix',
		title: 'Asset Amortization Pipeline Broker Mix',
		isExpanded: true
	},
	{
		id: '197',
		name: 'oa_accrued_interest',
		title: 'Other Asset - Accrued Interest Support Schedule'
	},
	{
		id: '35002',
		name: 'ol_accrued_interest',
		title: 'Other Liability - Accrued Interest'
	},
	{
		id: '4010',
		name: 'pipelinevectors',
		title: 'Funding Pipeline',
		isExpanded: true
	},
	{
		id: '4011',
		name: 'pipeline_supportschedule',
		title: 'Pipeline Support Schedule',
		isExpanded: true
	}
	// {
	// 	id: '202',
	// 	name: 'nii_table',
	// 	title: 'NII Table'
	// },
	// {
	// 	id: '500004',
	// 	name: 'specialtable2',
	// 	title: 'any name',
	// 	hasSecondValue: true
	// }
];
const tableData_FpnaV5_2 = [
	{
		id: '900',
		name: 'eve_table',
		title: ' Balance Sheet ',
		isExpanded: true
	},
	{
		id: '901',
		name: 'historical_swap_table',
		title: 'Historical Swaps'
	},
	{
		id: '902',
		name: 'swap_table',
		title: 'Rates'
	},
	{
		id: '906',
		name: 'projected_rates_table',
		title: 'Projected Rates '
	},
	{
		/*
		id: '903',
		name: 'duration_consolidated_table',
		title: 'PV Duration Convexity - Consolidated',
		isExpanded: true
	},
	{
		id: '904',
		name: 'duration_pipeline_table',
		title: 'PV Duration Convexity - Pipeline',
		isExpanded: true
	},
	{
		id: '905',
		name: 'duration_current_table',
		title: 'PV Duration Convexity - Current',
		isExpanded: true
	*/
	}
];
const tableData_FpnaV5_1_1 = [];
const tableData_FpnaV5_3_2 = [];
const tableData_FpnaV5_2_1 = [
	{
		id: '40123',
		name: 'ecl',
		title: 'ECL',
		isExpanded: true
	}
];
const tableData_FpnaV5_4_1 = [];

export {
	requiredTables_FpnaV5,
	tableData_FpnaV5,
	tableData_FpnaV5_3_2,
	requiredTables_FpnaV5_2,
	requiredTables_FpnaV5_3_2,
	requiredTables_FpnaV5_1_1,
	requiredTables_FpnaV5_2_1,
	requiredTables_FpnaV5_4_1,
	tableData_FpnaV5_2,
	tableData_FpnaV5_1_1,
	tableData_FpnaV5_2_1,
	tableData_FpnaV5_4_1
};
