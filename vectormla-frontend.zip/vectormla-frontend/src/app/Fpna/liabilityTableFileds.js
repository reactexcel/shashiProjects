function range(start, end) {
	return Array.from({ length: end - start }, (_, i) => i + start + 1);
}
// FPNA
export const loanHeaders = {
	untitled: [2, 5],
	'General Info': range(1, 15),
	'Interest Rate': range(15, 21),
	'FTP - Cost of Funds': range(21, 30),
	'Commercial Margin': range(30, 55),
	'Liability Structure': range(55, 59),
	'Price and Duration': range(59, 73)
};
export const incomeStatementHeaders = {
	untitled: [3, 4, 5],
	'Interest & Fee ': [6, 7, 8, 9],
	'Interest Expense': [10, 11, 12, 13],
	'Period NIM': [14, 15, 16, 17],
	'Contingent Liquidity Reserve': [18, 19, 20, 21],
	'Customer Acquisition': [22, 23, 24, 25],
	Servicing: [26, 27, 28, 29],
	Overhead: [30, 31, 32, 33],
	Hedging: [34, 35, 36, 37],
	'Expected Loss $': [38, 39, 40, 41],
	'ROA Before Tax': [42, 43, 44, 45],
	Tax: [46, 47, 48, 49, 50],
	'ROA After Tax': [51, 52, 53, 54],
	Leverage: [55, 56, 57]
};
//fpna 4
export const pipelineVectorsHeaders = {
	untitled: [0, 1],
	Applications: [
		2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
		23, 24, 25, 26
	],
	Approvals: [
		27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 45, 46,
		47, 48, 49, 50, 51
	],
	Originations: [
		52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
		71, 72, 73, 74, 75, 76
	]
};
export const loanPipelineHeaders = {
	untitled: [2, 5],
	'General Info': range(1, 15),
	'Interest Rate': range(15, 21),
	'FTP - Cost of Funds': range(21, 30),
	'Commercial Margin': range(30, 55),
	'Liability Structure': range(55, 59),
	'Price and Duration': range(59, 73)
};

export const section1 = {
	untitled: [0, 1],
	'1. Cash and cash equivalent': [...range(2, 5)],
	'2. Securities': [...range(6, 15)],
	'3. Loans': [...range(16, 40)],
	'4. Customers...': [42],
	'5. Land, building...': [43, 44],
	'6. Other assets': [...range(45, 59)],
	'Total Assets': [60]
};
export const section2 = {
	untitled: [0, 61],
	'1. Demand and notice deposits': range(62, 70),
	'2. Fixed-term deposits': range(71, 79),
	'3. Cheques and ..': [80],
	'4. Advances from the Bank of Canada': [81],
	'5. Acceptances': [82],
	'6. Other liabilities': range(83, 99),
	'7. Subordinated debt': [100, 101],
	'8. Shareholders equity': range(102, 109),
	Total: [110]
};
export const section3 = {
	untitled: [0],
	'Interest and dividends income': range(1, 14),
	'Interest expense': range(15, 20),
	'Net interest income': range(20, 22),
	'Net interest income after charge for impairment': range(22, 25),
	'Other Income': range(25, 36),
	'Net interest and other income': [37],
	'Non-interest expense': range(37, 49),
	'Net income before provision for income taxes': range(51, 53),
	'Net income before discontinued operations': [54, 55],
	'Net income attributable to equity holders and non-controlling interest': [
		56, 57, 58
	]
};
export const section4 = {
	untitled: [0],
	'Tier 1 Capital': range(0, 20),
	'Tier 2 Capital': range(20, 30),
	'Risk Weighted Assets': range(30, 38),
	'Capital Ratios': range(38, 42),
	'Leverage Ratio': range(42, 46)
};
export const section5 = {
	untitled: [0, 1],
	'Q1 - 2022': range(2, 16),
	'Q4 - 2021': range(17, 31),
	'Q3 - 2021': range(32, 46),
	'Q1 - 2021': range(47, 61),
	'Q4 - 2020': range(62, 76),
	'Q3 - 2020': range(77, 91),
	'Q2 - 2020': range(92, 106),
	'Q1 - 2020': range(107, 121),
	'Q4 - 2019': range(122, 136),
	'Q3 - 2019': range(137, 151),
	'Q2 - 2019': range(152, 166),
	'Q1 - 2019': range(167, 181)
};
export const section6 = {
	untitled: [59],
	'SCHEDULE 1': range(59, 86),
	'SCHEDULE 2': range(86, 102)
};
export const section7 = {
	untitled: range(102, 111)
};
export const specialTableHeaders = (data) => {
	return {
		untitled: [0],
		'Loan Number': range(1, data?.index?.length - 2),
		total: [data?.index?.length - 1]
	};
};

export const section8 = {
	untitled: [0, 1, 2]
};
// make this depending on the length of the data index
export const portfolioBalancesHeaders = {
	untitled: range(-1, 8)
};
// cashflow 1.1.2
export const loanHeaders2 = {
	untitled: [4, 8],
	'General Info': range(1, 18),
	'Interest Rate': range(18, 25),
	'FTP - Cost of Funds': range(25, 33),
	'Commercial Margin': range(33, 50),
	'Liability Structure': range(50, 52),
	Prepayment: [53, 54],
	'Price and Duration': range(54, 60)
};
// Cashflow 1.1.2
export const loanPipelineHeaders2 = {
	untitled: [4, 8],
	'General Info': range(1, 18),
	'Interest Rate': range(18, 25),
	'FTP - Cost of Funds': range(25, 33),
	'Commercial Margin': range(33, 50),
	'Liability Structure': range(50, 52),
	Prepayment: [53, 54],
	'Price and Duration': range(54, 60)
};
// cashflow 1.1.2
export const pipelineVectorsHeaders2 = {
	untitled: [0, 1],
	Applications: range(1, 23),
	Approvals: range(23, 45),
	Originations: range(45, 67)
};

export const dynamicHeaders = (data) => {
	if (data && Object.keys(data).length > 0) {
		let keys = Object.keys(data);
		let finalObject = {};
		keys.map((item) => (finalObject[item] = data?.[`${item}`]));
		return finalObject;
	} else {
		return {};
	}
};
