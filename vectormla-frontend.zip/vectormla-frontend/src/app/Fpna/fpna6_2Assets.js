const requiredTablesFpnaV6_2 = [];

const tableDataFpnaV6_2 = [];

export { requiredTablesFpnaV6_2, tableDataFpnaV6_2 };
