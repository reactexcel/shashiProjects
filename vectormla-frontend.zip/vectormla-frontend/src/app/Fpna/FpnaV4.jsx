// FPNA 3.1.4
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider, CircularProgress } from '@material-ui/core';
import Checkboxes from '../CashFlow/SelectScenarioChart/SelectScenarioChart';
import SelectChart from '../CashFlow/SelectCharts/SelectCharts';
import { useStyles } from './fpnaStyles';
import Chart from '../components/Chart/Chart';
import PrePaymentChart from '../components/Chart/PrePaymentChart';
import MainTable from '../components/Table/MainTable';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer, stopTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	createPortfolio,
	downloadFPNA4Template,
	deletePortfolio,
	getPortfolioDetails,
	getCharts4,
	updatePortfolio,
	downloadDataFile,
	getScenarioDetails,
	getPortfolioScenarios,
	getPortfolioSampleV4,
	getPortfolioCharts,
	getCalcStatus
} from '../store/actions/fpna.action';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import headers from './tableHeader';
import Portfolio from '../components/portfolio/Portfolio';
import {
	incomeStatementHeaders,
	loanHeaders,
	pipelineVectorsHeaders,
	loanPipelineHeaders,
	section1,
	section2,
	section3,
	section4,
	section5,
	section6,
	section7,
	section8
} from './liabilityTableFileds';
import {
	GET_FPNA4_TABLES_CLEAN,
	GET_FPNA4_CHARTS_CLEAN,
	TASK_PROGRESS_FPNA4,
	STOP_FPNA4_TIMER
} from '../store/types/fpna.type';
import { killTaskFunc } from 'app/store/actions/taskKill.action';

const FpnaV4 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios4,
		charts4,
		// loading,
		tables4,
		status4,
		seconds,
		minutes,
		scenarios4,
		secondCharts4
		// taskProgress4
	} = useSelector((state) => state.fpna);

	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [runningTaskId, setRunningTaskId] = useState();
	const [chartVisible, setChartVisible] = useState(false);
	const [chartVisible2, setChartVisible2] = useState(false);
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const defaultChartsCashCheck = ['Closing Balance', 'Principal', 'Interest'];
	const defaultChartsCash = ['Closing Balance', 'Principal', 'Interest'];
	const [state, setState] = useState({
		openChart: false,
		portfolio: false,
		openChartsCash: defaultChartsCashCheck,
		openChartsCash2: [
			'Total Assets',
			'Total Loans',
			'Total Cash and cash equivalent',
			'Total Liabilities',
			"Total Shareholders' equity"
		]
	});
	const [chartsData, setChartsData] = useState([]);
	const [chartsData2, setChartsData2] = useState([]);
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);

	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA4_TIMER,
			payload: { status4: 'stopped' }
		});
	};

	const killTaskFunction = (closeKillTaskDialog) => {
		dispatch(
			killTaskFunc('cfm4', runningTaskId, () => {
				deleteFunction();
				closeKillTaskDialog();
				setRunningTaskId();
				stopTimerFunction();
				dispatch(stopTimer('cfm4', 'STOPPED'));
			})
		);
	};

	const deleteFunction = () => {
		dispatch(
			deletePortfolio('4', selectedPortfolio?.id, () => {
				dispatch({ type: GET_FPNA4_TABLES_CLEAN });
				dispatch({ type: GET_FPNA4_CHARTS_CLEAN });
				setSelectedScenario([]);
			})
		);
	};

	useEffect(() => {
		if (!portfolios4 && user?.allowed_pages?.includes(1)) {
			fetchPortfolio();
		}
		if (portfolios4 && !selectedPortfolio) setSelectedPortfolio(portfolios4[0]);
		if (scenarios4 && !selectedScenario[0])
			setSelectedScenario([scenarios4[0]]);
	}, [portfolios4, user]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible2(true);
		} else if (collapsed === 0 && chartVisible2) {
			setChartVisible2(false);
		}
	}, [collapsed]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible(true);
		} else if (collapsed === 0 && chartVisible) {
			setChartVisible(false);
		}
	}, [collapsed]);

	useEffect(() => {
		if (selectedScenario[0] && status4 === 'SUCCESS') {
			updateTables(selectedScenario[0]?.id);
			fetchSecondCharts(selectedPortfolio);
			dispatch(
				getCharts4(
					selectedPortfolio?.id,
					handleTypeConditions('output/?incomestatement_orient=split')
				)
			);
		}
	}, [status4]);

	useEffect(() => {
		if (selectedPortfolio && selectedScenario[0]?.id) {
			getCalcStatus('cfm4/portfolio', selectedScenario[0]?.id, (res) => {
				if (res.task_state === 'SUCCESS') {
					updateTables(selectedScenario[0]?.id);
				}
				if (res.task_state !== 'SUCCESS')
					dispatch({
						type: TASK_PROGRESS_FPNA4,
						payload: res.task_progress
					});
				else if (res.task_state === 'FAILURE')
					dispatch({
						type: TASK_PROGRESS_FPNA4,
						payload: 'Failed'
					});
			});
		}
	}, [selectedScenario]);

	useEffect(() => {
		if (selectedPortfolio && selectedPortfolio?.id) {
			getCalcStatus('cfm4/portfolio-scenario', selectedPortfolio?.id, (res) => {
				if (res.task_state === 'SUCCESS') {
					fetchSecondCharts(selectedPortfolio);
					fetchPortfolioDetails(selectedPortfolio?.id);
				}
			});
		}
	}, [selectedPortfolio]);
	useEffect(() => {
		return () => {
			dispatch({ type: GET_FPNA4_TABLES_CLEAN });
			stopTimerFunction();
		};
	}, []);

	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('4', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && fetchScenarios(res[0].id, dataType, create);
			})
		);
	};

	const fetchScenarioDetails = (model, type, query = '') => {
		if (!model) return;
		dispatch(getScenarioDetails('4', model, type ? type : dataType, query));
	};

	const handleTypeConditions = (dataTypeVal) => {
		if (dataTypeVal === 'output/?incomestatement_orient=split') return '';
		else if (dataTypeVal === 'output/pipeline/?incomestatement_orient=split')
			return 'pipeline/';
		else return 'loandata/';
	};
	const fetchScenarios = (scenarioGroupId, dataTypeVal, create) => {
		dispatch(
			getPortfolioScenarios('4', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				!create &&
					dispatch(
						getCharts4(scenarioGroupId, handleTypeConditions(dataTypeVal))
					);
				create &&
					dispatch(startTimer('cfm4', portflioScenrios.results[0].id, ''));
			})
		);
	};
	const fetchSecondCharts = (portfolioId) => {
		portfolioId?.id &&
			dispatch(
				getPortfolioCharts(portfolioId?.id, (res) => {
					let chart1FBNA4 =
						Object.keys(res?.charts).length > 0
							? res?.charts.Date.map((val1, i) => ({
									['Date']: val1,
									'Total Assets': parseFloat(
										res?.charts['Total Assets'][i].replace(/,/g, '')
									)
							  }))
							: [];
					let chart2FBNA4 =
						Object.keys(res?.charts).length > 0
							? res?.charts.Date.map((val1, i) => ({
									['Date']: val1,
									'Total Loans': parseFloat(
										res?.charts['Total Loans'][i].replace(/,/g, '')
									)
							  }))
							: [];
					let chart3FBNA4 =
						Object.keys(res?.charts).length > 0
							? res?.charts.Date.map((val1, i) => ({
									['Date']: val1,
									'Total Cash and cash equivalent': parseFloat(
										res?.charts['Total Cash and cash equivalent'][i].replace(
											/,/g,
											''
										)
									)
							  }))
							: [];
					let chart4FBNA4 =
						Object.keys(res?.charts).length > 0
							? res?.charts.Date.map((val1, i) => ({
									['Date']: val1,
									'Total Liabilities': parseFloat(
										res?.charts['Total Liabilities'][i].replace(/,/g, '')
									)
							  }))
							: [];
					let chart5FBNA4 =
						Object.keys(res?.charts).length > 0
							? res?.charts.Date.map((val1, i) => ({
									['Date']: val1,
									"Total Shareholders' equity": parseFloat(
										res?.charts["Total Shareholders' equity"][i].replace(
											/,/g,
											''
										)
									)
							  }))
							: [];
					let chartsFBNAV4 = [
						{
							ch: chart1FBNA4,
							xIndex: 'Date',
							xDistance: 380,
							format: 'com'
						},
						{
							ch: chart2FBNA4,
							xIndex: 'Date',
							xDistance: 380,
							format: 'com'
						},
						{
							ch: chart3FBNA4,
							xIndex: 'Date',
							xDistance: 380,
							format: 'com'
						},
						{
							ch: chart4FBNA4,
							xIndex: 'Date',
							xDistance: 380,
							format: 'com'
						},
						{
							ch: chart5FBNA4,
							xIndex: 'Date',
							xDistance: 380,
							format: 'com'
						}
					];
					setChartsData2(chartsFBNAV4);
				})
			);
	};
	const renderChart2 = (dataMap) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible2(!chartVisible2)}
					style={{ paddingBottom: !chartVisible2 ? 150 : 0 }}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>

				{chartVisible2 && (
					<div className={classes.cashflow__chart}>
						<Grid
							container
							direction="row"
							alignItems="flex-start"
							justifyContent="flex-start"
							style={{ position: 'relative', maxWidth: 1900 }}
						>
							{chartsData2 && secondCharts4 ? (
								dataMap.map((item, index) => {
									return (
										<Grid
											key={index}
											item
											xs={12}
											sm={12}
											md={4}
											className={classes.container__chart}
										>
											<PrePaymentChart
												dataT={chartsData2[index]?.ch}
												nameLegend={`${item}`}
												sizeLegend="14px"
												brushID={`${item}`}
												value={`${item}`}
												dataX={chartsData2[index]?.xIndex}
												xDistance={chartsData2[index]?.xDistance}
												format={chartsData2[index]?.format}
												interval={chartsData2[index]?.xIndex === 'Date' ? 5 : 3}
											/>
										</Grid>
									);
								})
							) : (
								<div
									style={{
										width: '100%',
										textAlign: 'center',
										paddingBottom: 150
									}}
								>
									<CircularProgress style={{ color: '#266696' }} size={26} />
								</div>
							)}
						</Grid>
					</div>
				)}
			</div>
		);
	};
	const updateTables = (id) => {
		if (!tables4 && !id) return;
		if (tables4?.loanmodel || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split');
		if (tables4?.loanmodel_g1 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=1');
		if (tables4?.loanmodel_g2 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=2');
		if (tables4?.loanmodel_g3 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=3');
		if (tables4?.loanmodel_g4 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=4');
		if (tables4?.loanmodel_g5 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=5');
		if (tables4?.loanmodel_g6 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=6');
		if (tables4?.loanmodel_g7 || id)
			fetchScenarioDetails(id, 'loanmodel', '?orient=split&grade_number=7');
		if (tables4?.fixedintrate || id) fetchScenarioDetails(id, 'fixedintrate');
		if (tables4?.pipeline || id) fetchScenarioDetails(id, 'pipeline');
		if (tables4?.pipelinevectors || id)
			fetchScenarioDetails(id, 'pipelinevectors', '?orient=split');
		if (tables4?.vectors || id) fetchScenarioDetails(id, 'vectors');
		if (
			tables4?.assetamort ||
			tables4?.balancesheet ||
			tables4?.cashflowstatement ||
			tables4?.incomestatement ||
			tables4?.liability ||
			tables4?.loanmodel ||
			tables4?.structure ||
			tables4?.assetamort_noextra ||
			tables4?.equity_requirement ||
			id
		)
			fetchScenarioDetails(id);
		if (
			tables4?.sample1 ||
			tables4?.sample2 ||
			tables4?.capital_and_leverage ||
			tables4?.expected_credit_losses
		)
			fetchPortfolioDetails(selectedPortfolio?.id);
	};

	useEffect(() => {
		if (charts4) {
			let chart1 = [];
			let chart2 = [];
			let chart3 = [];
			charts4?.forEach((chart) => {
				if (chart.charts) {
					let tempChart1 = [];
					let tempChart2 = [];
					let tempChart3 = [];
					chart.charts['Date'].forEach((val1, i) => {
						tempChart1.push({
							Date: val1,
							[`${chart.scenario.replace(/\s/g, '_')}`]: parseFloat(
								chart.charts['Closing Balance'][i].replace(/,/g, '')
							)
						});
						tempChart2.push({
							Date: val1,
							[`${chart.scenario.replace(/\s/g, '_')}`]: parseFloat(
								chart.charts['Principal'][i].replace(/,/g, '')
							)
						});
						tempChart3.push({
							Date: val1,
							[`${chart.scenario.replace(/\s/g, '_')}`]: parseFloat(
								chart.charts['Interest'][i].replace(/,/g, '')
							)
						});
						chart1.push(tempChart1);
						chart2.push(tempChart2);
						chart3.push(tempChart3);
					});
				}
			});
			let updatedCharts = [
				{
					ch: chart1,
					xIndex: 'Date',
					yIndex: 'Closing Balance',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart2,
					xIndex: 'Date',
					yIndex: 'Principal',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart3,
					xIndex: 'Date',
					yIndex: 'Interest',
					xDistance: 390,
					format: 'com'
				}
			];
			setChartsData(updatedCharts);
		}
	}, [charts4]);
	const typeHeaders = (tableName) => {
		if (tableName === 'loanmodel') return loanHeaders;
		else if (tableName === 'incomestatement') return incomeStatementHeaders;
		else if (tableName === 'pipelinevectors') return pipelineVectorsHeaders;
		else if (tableName.includes('loanmodel_g')) return loanPipelineHeaders;
		else if (tableName === 'OSFI Balance Sheet - Assets') return section1;
		else if (tableName === 'OSFI Balance Sheet - Liabilities') return section2;
		else if (tableName === 'OSFI Income Statement') return section3;
		else if (tableName === 'OSFI Capital and Leverage') return section4;
		else if (tableName === 'OSFI Expected Credit Losses') return section5;
		else if (tableName === 'OSFI Schedule') return section6;
		else if (tableName === 'OSFI Summary') return section7;
		else if (tableName === 'OSFI GIC Maturity Report') return section8;
		else return null;
	};

	const fetchSecondParams = (tableName) => {
		if (tableName === 'loanmodel') return 'loanmodel';
		else if (tableName === 'pipelinevectors') return 'pipelinevectors';
		else if (tableName.includes('loanmodel_g')) return 'loanmodel';
		else if (tableName === 'OSFI Balance Sheet - Assets') return 'sample1';
		else if (tableName === 'OSFI Balance Sheet - Liabilities') return 'sample1';
		else if (tableName === 'OSFI Income Statement') return 'sample2';
		else if (tableName === 'OSFI Capital and Leverage')
			return 'capital_and_leverage';
		else if (tableName === 'OSFI Expected Credit Losses')
			return 'expected_credit_losses';
		else if (tableName === 'OSFI Schedule') return 'sample2';
		else if (tableName === 'OSFI Summary') return 'sample2';
		else if (tableName === 'OSFI GIC Maturity Report')
			return 'gic_maturity_report';
		else return '';
	};

	const fetchThirdParams = (tableName) => {
		if (tableName === 'loanmodel') return '?orient=split';
		else if (tableName === 'pipelinevectors') return '?orient=split';
		else if (tableName.includes('loanmodel_g'))
			return `?orient=split&grade_number=${tableName.slice(-1)}`;
		else return '?incomestatement_orient=split';
	};
	const handleTableBoxChange = (e) => {
		if (e.length > 0) {
			let arr;
			// compare between two array and return element
			if (e.length > state.openChartsCash.length) {
				arr = e.filter((val) => !state.openChartsCash.includes(val))[0];
				return setState({
					...state,
					openChartsCash: [...state.openChartsCash, arr]
				});
			} else {
				arr = state.openChartsCash.filter((val) => e.includes(val));
				return setState({ ...state, openChartsCash: arr });
			}
		}
	};
	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = []
	) => {
		return (
			<div>
				<MainTable
					header={tableData && tableData[tableName]?.columns}
					data={tableData && tableData[tableName]}
					attributes={
						tableData &&
						tableData[tableName]?.data &&
						Object.keys(tableData[tableName]?.columns)
					}
					tableId={tableId}
					tableName={verboseTableName}
					tableSign={
						verboseTableName === 'Loan Model Summary'
							? 'Loan Model Summary first and last 10 loans'
							: verboseTableName
					}
					fetchData={() => {
						if (
							!tables4 ||
							!tables4.loanmodel ||
							!tables4.pipelinevectors ||
							!tables4.incomestatement ||
							!tables4.loanmodel_g1 ||
							!tables4.loanmodel_g2 ||
							!tables4.loanmodel_g3 ||
							!tables4.loanmodel_g4 ||
							!tables4.loanmodel_g5 ||
							!tables4.loanmodel_g6 ||
							!tables4.loanmodel_g7
						)
							fetchScenarioDetails(
								selectedScenario[0]?.id,
								fetchSecondParams(tableName),
								fetchThirdParams(tableName)
							);
					}}
					collapsed={collapsed}
					separator={typeHeaders(tableName)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model={'4'}
					id={selectedScenario[0]?.id}
				/>
			</div>
		);
	};
	const fetchPortfolioDetails = (model) => {
		if (!model) return;
		dispatch(getPortfolioSampleV4(model));
	};
	const renderTable2 = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = []
	) => {
		return (
			<div>
				<MainTable
					header={tableData && tableData[tableName]?.columns}
					data={tableData && tableData[tableName]}
					attributes={
						tableData &&
						tableData[tableName]?.data &&
						Object.keys(tableData[tableName]?.columns)
					}
					tableId={tableId}
					tableName={verboseTableName}
					fetchData={() => {
						if (
							!tables4 ||
							!tables4.sample1 ||
							!tables4.sample2 ||
							!tables4.capital_and_leverage ||
							!tables4.expected_credit_losses
						)
							fetchPortfolioDetails(selectedPortfolio?.id);
					}}
					collapsed={collapsed}
					separator={typeHeaders(verboseTableName)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
				/>
			</div>
		);
	};
	const renderChart = (dataMap, conditionReq) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>
				{chartVisible && scenarios4 && (
					<div
						className={classes.cashflow__chart}
						style={{ marginTop: '95px' }}
					>
						<Grid
							container
							spacing={1}
							justify="flex-start"
							alignItems="center"
							direction="row"
							style={{ position: 'relative', maxWidth: 1900 }}
						>
							<div
								className={classes.cashflow__chart_check}
								style={{
									position: 'absolute',
									top: -70,
									left: 5,
									zIndex: 999
								}}
							>
								<Checkboxes
									senarioData={scenarios4?.results}
									selectedScenario={selectedScenario}
									setSelectedScenario={setSelectedScenario}
								/>
							</div>
							<div
								className={classes.cashflow__chart_select}
								style={{
									position: 'absolute',
									top: -70,
									left: 157,
									zIndex: 999
								}}
							>
								<SelectChart
									senarioData={defaultChartsCash}
									selectedScenario={state.openChartsCash}
									setSelectedScenario={handleTableBoxChange}
								/>
							</div>
							{chartsData.length > 0 &&
								dataMap.map((item, index) => {
									return (
										conditionReq.includes(`${item}`) && (
											<Grid
												key={index}
												item
												xs={12}
												sm={12}
												md={4}
												className={classes.container__chart}
											>
												<Chart
													dataT={
														chartsData.find(
															(element) => element.yIndex === item
														)?.ch
													}
													nameLegend={`${item}`}
													sizeLegend="14px"
													brushID={`${item}`}
													dataX={
														chartsData.find(
															(element) => element.yIndex === item
														)?.xIndex
													}
													// xDistance={charts.find(element => element.yIndex === item).xDistance}
													format={
														chartsData.find(
															(element) => element.yIndex === item
														)?.format
													}
													defaultSelect={
														scenarios4 && scenarios4.results[0]?.scenario
													}
													selectedScenario={selectedScenario}
												/>
											</Grid>
										)
									);
								})}
						</Grid>
					</div>
				)}
			</div>
		);
	};
	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(304)
	)
		return <div></div>;
	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />
			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'fpna4'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							loading={status4 === 'pending'}
							key={1004}
							portfolioList={portfolios4 || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios4.filter((item) => item.id == val)[0]
								);
								fetchScenarios(val, 'output/?incomestatement_orient=split');
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(
										'4',
										name,
										user?.company_id,
										file,
										(res) => {
											setRunningTaskId(res.data.id);
											fetchPortfolio('create');
											dispatch({
												type: TASK_PROGRESS_FPNA4,
												payload: '0.0 %'
											});
											// fetchSecondCharts();
										},
										'fpna4'
									)
								);
							}}
							update={(name) => {
								dispatch(
									updatePortfolio('4', selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										// fetchSecondCharts();
									})
								);
							}}
							deleteObj={() => deleteFunction()}
							upload={(formData) => {
								dispatch(
									updatePortfolio(
										'4',
										selectedPortfolio?.id,
										formData,
										(res) => {
											setRunningTaskId(res.data.id);
											fetchScenarios(selectedPortfolio?.id, '', 'create');
										},
										'fpna4'
									)
								);
								dispatch({
									type: TASK_PROGRESS_FPNA4,
									payload: '0.0 %'
								});
							}}
							downloadFile={() => {
								dispatch(downloadDataFile('4', selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadFPNA4Template());
							}}
							data={[
								{
									key: 'output/?incomestatement_orient=split',
									value: 'Consolidated'
								},
								{
									key: 'output/pipeline/?incomestatement_orient=split',
									value: 'Forecast'
								},
								{
									key: 'output/loandata/?incomestatement_orient=split',
									value: 'Origination'
								}
							]}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							senarioData={
								scenarios4
									? scenarios4?.results?.map((item) => {
											return item;
									  })
									: []
							}
							scenario={selectedScenario[0]?.scenario || {}}
							setScenario={(item) => {
								setSelectedScenario([item]);
								if (portfolios4.length === 0) return;
								updateTables(item?.id);
							}}
							setData={(val) => {
								setDataType(val);
								selectedPortfolio?.id &&
									fetchScenarios(selectedPortfolio?.id, val);
								if (
									tables4 &&
									(tables4.assetamort ||
										tables4.balancesheet ||
										tables4.cashflowstatement ||
										tables4.incomestatement ||
										tables4.liability ||
										tables4.structure ||
										tables4.assetamort_noextra ||
										tables4?.equity_requirement)
								)
									fetchScenarioDetails(selectedScenario[0]?.id, val);
							}}
							collapsed={collapsed}
							selectedData={dataType}
							seconds={seconds}
							status={status4}
							minutes={minutes}
							// taskProgressPercent={taskProgress4}
							killTaskFunction={killTaskFunction}
							runningTaskId={runningTaskId}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{dataType != 'output/loandata/?incomestatement_orient=split' &&
							renderTable('1', 'pipelinevectors', tables4, 'Pipeline Vectors')}
						{dataType != 'output/pipeline/?incomestatement_orient=split' &&
							renderTable('9', 'loanmodel', tables4, 'Loan Model Summary')}
						{dataType != 'output/loandata/?incomestatement_orient=split' && (
							<MainTable
								header={headers.pipelineAssumptionHeader}
								data={tables4}
								attributes={headers.pipelineAssumptionAttributes}
								tableId={12}
								tableName="Pipeline Growth Assumptions"
								fetchData={() => {
									if (
										!tables4 ||
										!tables4.loanmodel_g1 ||
										!tables4.loanmodel_g2 ||
										!tables4.loanmodel_g3 ||
										!tables4.loanmodel_g4 ||
										!tables4.loanmodel_g5 ||
										!tables4.loanmodel_g6 ||
										!tables4.loanmodel_g7
									)
										[1, 2, 3, 4, 5, 6, 7].map((arr) =>
											fetchScenarioDetails(
												selectedScenario[0]?.id,
												fetchSecondParams('loanmodel'),
												fetchThirdParams(`loanmodel_g${arr}`)
											)
										);
								}}
								collapsed={collapsed}
								download
								separator={typeHeaders('loanmodel_g')}
								multiple={true}
								multipleArray={[
									'Grade 1',
									'Grade 2',
									'Grade 3',
									'Grade 4',
									'Grade 5',
									'Grade 6',
									'Grade 7'
								]}
								stateGradeTrue={{
									'Grade 1': true,
									'Grade 2': true,
									'Grade 3': true,
									'Grade 4': true,
									'Grade 5': true,
									'Grade 6': true,
									'Grade 7': true
								}}
								stateMultipleArray={stateMultipleArray}
								setStateMultipleArray={setStateMultipleArray}
								model={'4'}
								id={selectedScenario[0]?.id}
							/>
						)}
						<MainTable
							header={headers.amort3Header}
							data={tables4?.assetamort}
							attributes={headers.amort3Attributes}
							tableId={230}
							tableName="Asset Amortization Table"
							fetchData={() => {
								if (!tables4?.assetamort)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.amortNoextraHeader}
							data={tables4?.assetamort_noextra}
							attributes={headers.amortNoextraAttributes}
							tableId={231}
							tableName="Asset Amortization No Extra Payment"
							fetchData={() => {
								if (!tables4?.assetamort_noextra)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.structure3Header}
							data={tables4?.structure}
							attributes={headers.structure3Attributes}
							tableId={233}
							tableName="Structure"
							fetchData={() => {
								if (!tables4?.structure)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.equityRequirementHeaders}
							data={tables4?.equity_requirement}
							attributes={headers.equityRequirementAttributes}
							tableId={233}
							tableName="Equity Requirement"
							fetchData={() => {
								if (!tables4?.equity_requirement)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.liability3Header}
							data={tables4?.liability}
							attributes={headers.liability3Attributes}
							tableId={234}
							tableName="Liability"
							fetchData={() => {
								if (!tables4?.liability)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						{renderTable('235', 'incomestatement', tables4, 'Income Statement')}
						<MainTable
							header={headers.balanceSheetHeader}
							data={tables4?.balancesheet}
							attributes={headers.balanceSheetAttributes}
							tableId={236}
							tableName="Balance Sheet"
							fetchData={() => {
								if (!tables4?.balancesheet)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.cashflowStatementHeader}
							data={tables4?.cashflowstatement}
							attributes={headers.cashflowStatementAttributes}
							tableId={237}
							tableName="Cashflow Statement"
							fetchData={() => {
								if (!tables4?.cashflowstatement)
									fetchScenarioDetails(selectedScenario[0]?.id);
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.fixedIntRateHeaders}
							data={tables4?.fixedintrate}
							attributes={headers.fixedIntRateAttributes}
							tableId={20}
							tableName="US Treasury"
							fetchData={() => {
								if (!tables4?.fixedintrate)
									fetchScenarioDetails(selectedScenario[0]?.id, 'fixedintrate');
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						<MainTable
							header={headers.vectorsHeaders}
							data={tables4?.vectors}
							attributes={headers.vectorsAttributes}
							tableId={20}
							tableName="Vectors"
							fetchData={() => {
								if (!tables4?.vectors)
									fetchScenarioDetails(selectedScenario[0]?.id, 'vectors');
							}}
							collapsed={collapsed}
							download
							stateMultipleArray={stateMultipleArray}
							setStateMultipleArray={setStateMultipleArray}
						/>
						{renderChart(state.openChartsCash, defaultChartsCash)}
						{renderTable2(
							'11',
							'sample1',
							tables4,
							'OSFI Balance Sheet - Assets'
						)}
						{renderTable2(
							'20',
							'sample1',
							tables4,
							'OSFI Balance Sheet - Liabilities'
						)}
						{renderTable2('19', 'sample2', tables4, 'OSFI Income Statement')}
						{renderTable2(
							'21',
							'capital_and_leverage',
							tables4,
							'OSFI Capital and Leverage'
						)}
						{renderTable2(
							'22',
							'expected_credit_losses',
							tables4,
							'OSFI Expected Credit Losses'
						)}
						{renderTable2('23', 'sample2', tables4, 'OSFI Schedule')}
						{renderTable2('24', 'sample2', tables4, 'OSFI Summary')}
						{renderTable2(
							'25',
							'gic_maturity_report',
							tables4,
							'OSFI GIC Maturity Report'
						)}
						{renderChart2(state.openChartsCash2)}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default FpnaV4;
