import Securitization from './Securitization';

export default Securitization;
