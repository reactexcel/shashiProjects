import { makeStyles } from '@material-ui/core';
import {
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader
} from '../../common/assets/layout';
export const useStyles = makeStyles((theme) => ({
	appContainer,
	appContentContainer,
	contentHeaderContainer,
	contentHeader,
	selectLabel: {
		color: '#000',
		fontSize: 12,
		marginRight: 10,
		fontFamily: 'Roboto'
	},
	selectContainer: {
		display: 'flex',
		flexDirection: 'row',
		alignItems: 'center'
	}
}));
