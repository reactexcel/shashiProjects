import React, { useState, useEffect } from 'react';
import { Grid, Typography } from '@material-ui/core';
import { useStyles } from './securitizationStyles';
import { useSelector, useDispatch } from 'react-redux';
import MainTable from '../components/Table/MainTable';
import ContentContainer from '../components/contentContainer/ContentContainer';
import {
	getPools,
	getPoolDetails,
	getPortfolios,
	getGocRate,
	createPortfolio,
	deletePortfolio,
	updatePortfolio,
	downloadFile,
	downloadTemplate
} from '../store/actions/securitization.action';
import { GET_SECURITIZATION_TABLES_CLEAN } from '../store/types/securitization.type';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import Portfolio from '../components/portfolio/Portfolio';
import MuiSelectField from '../components/Select/Select';
import {
	poolHeader,
	poolAttributes,
	gocRateHeader,
	gocRateAttributes,
	trancheSumHeader,
	trancheSumAttributes,
	poolPriceHeader,
	poolPriceAttributes,
	trancheHeader,
	trancheAttributes
} from './tableHeader';
import { useComponentSize } from 'react-use-size';

const Securitization = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const { portfolios, tables, loading } = useSelector(
		(state) => state.securitization
	);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: securitRef, height: securitHeight } = useComponentSize();

	const [selectedPortfolio, setSelectePortfolio] = useState(null);
	const [selectedPool, setSelectedPool] = useState(null);

	const fetchPortfolios = () => {
		dispatch(
			getPortfolios((res) => {
				setSelectePortfolio(res[0]);
				res[0]?.id && fetchTablesData(res[0]?.id);
			})
		);
	};
	useEffect(() => {
		if (!portfolios && user?.allowed_pages?.includes(4)) fetchPortfolios();
		if (portfolios && !selectedPortfolio) setSelectePortfolio(portfolios[0]);
		if (tables?.pools && !selectedPool) setSelectedPool(tables.pools[0].id);
	}, [portfolios, user]);

	if (
		!user?.allowed_pages?.includes(4) ||
		!user?.allowed_section4.includes(401)
	)
		return <div></div>;

	const fetchTablesData = (model, all = false) => {
		model &&
			dispatch(
				getPools(model, (res) => {
					res?.pools[0]?.id && setSelectedPool(res?.pools[0]?.id);
					res?.pools[0]?.id && fetchTranche(res?.pools[0]?.id);
				})
			);
		if (!all) return;
		if (tables?.gocrate) {
			dispatch(getGocRate(model));
		}
		if (tables?.tranche) fetchPoolDetails(selectedPool);
	};

	const fetchGocRate = (model) => {
		if (!model) return;
		dispatch(getGocRate(model));
	};

	const fetchPoolDetails = (id) => {
		if (!id) return;
		dispatch(getPoolDetails(id, 'pool-details'));
	};

	const fetchTranche = (poolID) => {
		if (!poolID) return;
		dispatch(getPoolDetails(poolID, 'tranche-data'));
	};
	return (
		<div ref={securitRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={securitHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'securitization'}
							port={selectedPortfolio?.id}
							portfolioList={portfolios || []}
							loading={loading}
							setPortfolio={(val) => {
								setSelectePortfolio(
									portfolios.filter((item) => item.id == val)[0]
								);
								fetchTablesData(val, true);
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(name, user?.company_id, file, () => {
										fetchPortfolios();
									})
								);
							}}
							update={(name) => {
								selectedPortfolio?.id &&
									dispatch(
										updatePortfolio(selectedPortfolio?.id, { name }, () => {
											fetchPortfolios();
										})
									);
							}}
							deleteObj={() => {
								selectedPortfolio?.id &&
									dispatch(
										deletePortfolio(selectedPortfolio?.id, () => {
											fetchPortfolios();
											dispatch({ type: GET_SECURITIZATION_TABLES_CLEAN });
										})
									);
							}}
							upload={(formData) => {
								dispatch(
									updatePortfolio(selectedPortfolio.id, formData, () => {
										fetchGocRate(selectedPortfolio?.id);
										fetchTablesData(selectedPortfolio.id, true);
									})
								);
							}}
							downloadFile={() => {
								dispatch(downloadFile(selectedPortfolio?.id));
							}}
							downloadTemplate={() => {
								dispatch(downloadTemplate());
							}}
							collapsed={collapsed}
						/>
						<ContentContainer
							header={'Methodology'}
							onClick={() => window.open('/app/academy', '_self')}
							content={[
								{
									hoveredText: 'NHA MBS Indemnity Calculation Methodology'
								}
							]}
							collapsed={collapsed}
						/>
						<MainTable
							header={gocRateHeader}
							data={tables?.gocrate}
							attributes={gocRateAttributes}
							tableId={1}
							tableName="GOC Rate"
							fetchData={() => {
								if (!tables?.gocrate) fetchGocRate(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={poolHeader}
							data={tables?.pools}
							attributes={poolAttributes}
							tableId={2}
							tableName="Pools Data"
							fetchData={() => {
								if (!tables?.pools) fetchTablesData(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={poolPriceHeader}
							data={tables?.poolsPrices}
							attributes={poolPriceAttributes}
							tableId={3}
							tableName="Indemnity Prices"
							fetchData={() => {
								if (!tables?.poolsPrices)
									fetchTablesData(selectedPortfolio?.id);
							}}
							collapsed={collapsed}
							download
						/>
						<Grid className={classes.selectContainer}>
							<Typography className={classes.selectLabel}>
								Pool Number:
							</Typography>
							<MuiSelectField
								value={selectedPool || ''}
								onChange={(e) => {
									setSelectedPool(e.target.value);
									if (tables?.tranche) fetchPoolDetails(e.target.value);
									if (tables?.['1']) fetchTranche(e.target.value);
								}}
							>
								{tables?.pools?.map((item, i) => (
									<option key={item.id} value={item.id}>
										{item.pool_number}
									</option>
								))}
							</MuiSelectField>
						</Grid>

						<MainTable
							header={trancheSumHeader}
							data={tables?.tranche}
							attributes={trancheSumAttributes}
							tableId={4}
							tableName="Summary Tranche Data"
							fetchData={() => {
								if (!tables?.tranche) fetchPoolDetails(selectedPool);
							}}
							collapsed={collapsed}
							download
						/>
						{[1, 2, 3, 4, 5, 6].map((key) => (
							<MainTable
								header={trancheHeader}
								data={tables && tables[key]}
								attributes={trancheAttributes}
								tableId={key + 100}
								key={`sec-${key}`}
								tableName={`Tranche ${key}`}
								download
								collapsed={collapsed}
							/>
						))}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default Securitization;
