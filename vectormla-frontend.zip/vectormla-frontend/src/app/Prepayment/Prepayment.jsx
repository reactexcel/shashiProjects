// Credit Risk 1.2.8
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider } from '@material-ui/core';
import Chart from '../components/Chart/PrePaymentChart';
import { useStyles } from './prepaymentStyles';
import MainTable from '../components/Table/MainTable';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import Portfolio from '../components/portfolio/Portfolio';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import {
	createPortfolio,
	downloadPrepaymentTemplate,
	getPortfolios,
	deletePortfolio,
	getPrepayments,
	updatePortfolio,
	downloadPrepaymentData
} from '../store/actions/prepayment.action';
import {
	GET_PREPAYMENT_TABLES_CLEAN,
	GET_PREPAYMENT_CHARTS_CLEAN
} from '../store/types/prepayment.type';
import { startTimer } from '../store/actions/timer.action';
// import { update } from 'lodash';
const PrePayment = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);

	const { tables, portfolios } = useSelector((state) => state.prepayment);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: prePaymentRef, height: prePaymentHeight } = useComponentSize();
	const [selectedPortfolio, setSelectedPortfolio] = useState(null);
	const existTables = ['Prepay Curve Percent', 'Prepay Curve Summary'];
	const [dataType, setDataType] = useState('output');

	const [chartVisible, setChartVisible] = useState(false);
	const [state, setState] = useState({ openChartsCash: ['CPR', 'SMM'] });
	const [chartsData, setChartsData] = useState(false);

	useEffect(() => {
		if (!portfolios && user?.allowed_pages?.includes(1)) fetchPortfolio();
		fetchPortfolioDetails(selectedPortfolio?.id);
		if (portfolios && !selectedPortfolio) setSelectedPortfolio(portfolios[0]);
	}, [selectedPortfolio, user]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible(true);
		} else if (collapsed === 0 && chartVisible) {
			setChartVisible(false);
		}
	}, [collapsed]);

	useEffect(() => {
		return () => {
			dispatch({ type: GET_PREPAYMENT_TABLES_CLEAN });
			setChartsData(false);
			dispatch({ type: GET_PREPAYMENT_CHARTS_CLEAN });
		};
	}, []);

	const fetchPortfolioDetails = (model, type) => {
		if (!model) return;
		dispatch(
			getPrepayments(model, type ? type : dataType, (res) => {
				/* Charts For Page Prepayment */
				let chart1Prepayment =
					Object.keys(res).length > 0
						? res['Prepay Curve Summary']?.chart.Period.map((val1, i) => ({
								['Period']: val1,
								CPR: parseFloat(
									res['Prepay Curve Summary']?.chart['CPR'][i].replace(/,/g, '')
								)
						  }))
						: [];
				let chart2Prepayment =
					Object.keys(res).length > 0
						? res['Prepay Curve Summary']?.chart.Period.map((val1, i) => ({
								['Period']: val1,
								SMM: parseFloat(
									res['Prepay Curve Summary']?.chart['SMM'][i].replace(/,/g, '')
								)
						  }))
						: [];
				let chartsPrepayment = [
					{
						ch: chart1Prepayment,
						xIndex: 'Period',
						xDistance: 380,
						format: 'per'
					},
					{
						ch: chart2Prepayment,
						xIndex: 'Period',
						xDistance: 380,
						format: 'per'
					}
				];
				setChartsData(chartsPrepayment);
			})
		);
	};

	const fetchPortfolio = () => {
		dispatch(
			getPortfolios((res) => {
				setSelectedPortfolio(res[0]);
			})
		);
	};

	const renderChart = (dataMap) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>
				{chartVisible && (
					<div className={classes.cashflow__chart}>
						<Grid
							container
							spacing={1}
							justify="flex-start"
							alignItems="center"
							direction="row"
							style={{ position: 'relative', maxWidth: 1900 }}
						>
							{chartsData &&
								dataMap.map((item, index) => {
									return (
										<Grid
											key={index}
											item
											xs={12}
											sm={12}
											md={4}
											className={classes.container__chart}
										>
											<Chart
												dataT={chartsData[index].ch}
												nameLegend={`${item}`}
												sizeLegend="14px"
												brushID={`${item}`}
												value={`${item}`}
												dataX={chartsData[index].xIndex}
												xDistance={chartsData[index].xDistance}
												format={chartsData[index].format}
											/>
										</Grid>
									);
								})}
						</Grid>
					</div>
				)}
			</div>
		);
	};

	const renderTable = (existTables, tableData) => {
		return (
			<div>
				{existTables.map((tableName, index) => (
					<MainTable
						header={tableData && tableData[tableName]?.table?.headers}
						data={tableData && tableData[tableName]?.table?.rows}
						attributes={
							tableData && Object.keys(tableData[tableName]?.table?.rows)
						}
						tableId={index}
						key={index}
						tableName={tableName}
						fetchData={() => {
							if (!tables)
								fetchPortfolioDetails(selectedPortfolio?.id, 'output');
						}}
						collapsed={collapsed}
						download
					/>
				))}
			</div>
		);
	};
	const updateTables = (id = selectedPortfolio.id) => {
		if (!tables) return;
		if (tables.output) fetchPortfolioDetails(id, 'output');
	};
	if (
		!user?.allowed_pages?.includes(1) ||
		!user?.allowed_section1.includes(104)
	)
		return <div></div>;
	return (
		<div ref={prePaymentRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={prePaymentHeight} />
			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'prepayment'}
							port={selectedPortfolio?.id}
							loading={status === 'pending'}
							key={1010}
							portfolioList={portfolios || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios.filter((item) => item.id == val)[0]
								);
								updateTables(val);
							}}
							senarioData={[]}
							create={(name, file) => {
								dispatch(
									createPortfolio(
										name,
										user?.company_id,
										file,
										(res) => {
											dispatch(startTimer('prepayment', res.data.id));
											fetchPortfolio();
										},
										'prepayment'
									)
								);
							}}
							update={(name, callback) => {
								dispatch(
									updatePortfolio(selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										callback();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio(selectedPortfolio?.id, () => {
										fetchPortfolio();
										dispatch({ type: GET_PREPAYMENT_TABLES_CLEAN });
										setChartsData(false);
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('prepayment', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(
										selectedPortfolio?.id,
										formData,
										() => {
											updateTables();
										},
										'prepayment'
									)
								);
							}}
							downloadFile={() => {
								downloadPrepaymentData(selectedPortfolio?.id);
							}}
							downloadTemplate={() => {
								dispatch(downloadPrepaymentTemplate());
							}}
							collapsed={collapsed}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{renderTable(existTables, tables)}
						{renderChart(state.openChartsCash)}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default withRouter(PrePayment);
