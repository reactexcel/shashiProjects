import React from 'react';
import {
	Chart,
	CommonSeriesSettings,
	Label,
	Format,
	Legend,
	Tooltip,
	SeriesTemplate,
	LoadingIndicator,
	ArgumentAxis,
	Tick,
	MinorTick,
	Font
} from 'devextreme-react/chart';
import { IconButton, Typography } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import service from '../Data/data.js';

const BarMultiColor = ({ classes, no }) => {
	const BarRef = React.createRef();

	const titles = ['Purpose: # of Loans', 'Average Amount'];

	const yAxis = ['pur_loans', 'pur_amount'];

	const exportChart = () => {
		BarRef.current.instance.exportTo('Example', 'png');
	};

	const onLegendClick = ({ target: series }) => {
		if (series.isVisible()) {
			series.hide();
		} else {
			series.show();
		}
	};

	const customizeLabel = (e) => {
		return `${e.valueText}`;
	};

	const customizeTooltip = (arg) => {
		return {
			text: `${arg.seriesName} : ${arg.valueText}`
		};
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>{titles[no - 1]}</div>
			<Chart
				id="chart"
				ref={BarRef}
				dataSource={service.getData()}
				palette={[
					//"#26509E",
					'#26649E'
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
					// "#2CC9B7",
				]}
				onLegendClick={onLegendClick}
			>
				<ArgumentAxis tickInterval={10} minorTickInterval={10} type="discrete">
					{/* or ValueAxis, or CommonAxisSettings */}
					<Tick visible={true} />
					<MinorTick visible={true} />
					{/* <Label staggeringSpacing={0} displayMode="stagger" /> */}
					<Label rotationAngle={30} overlappingBehavior="rotate" />
				</ArgumentAxis>
				<CommonSeriesSettings
					hoverMode="allArgumentPoints"
					selectionMode="allArgumentPoints"
					argumentField="purpose"
					valueField={yAxis[no - 1]}
					type="bar"
					ignoreEmptyPoints={true}
				>
					{/* <Label visible={true}>
            <Format type="fixedPoint" precision={0} />
            <Font color="#FFF" size={10} />
          </Label> */}
					<Label
						visible={true}
						backgroundColor="none"
						customizeText={customizeLabel}
					>
						<Font color="#000" size={10} />
						<Format type="fixedPoint" precision={0} />
					</Label>
				</CommonSeriesSettings>
				<SeriesTemplate nameField="purpose" />
				<Legend
					visible={false}
					verticalAlignment="bottom"
					horizontalAlignment="center"
					orientation="horizontal"
					itemTextPosition="left"
				/>
				<Tooltip
					enabled={true}
					location="edge"
					customizeTooltip={customizeTooltip}
				/>
			</Chart>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default BarMultiColor;
