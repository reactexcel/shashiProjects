import React from 'react';
import {
	Chart,
	CommonSeriesSettings,
	Label,
	Format,
	Legend,
	Tooltip,
	SeriesTemplate,
	LoadingIndicator,
	ArgumentAxis,
	Series,
	ValueAxis,
	Font
} from 'devextreme-react/chart';
import { IconButton, Typography } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import service from '../Data/data.js';

const MainBarLine = ({ classes, no }) => {
	const BarRef = React.createRef();

	const exportChart = () => {
		BarRef.current.instance.exportTo('Example', 'png');
	};

	//   const onPointClick = ({ target: point }) => {
	//     point.select();
	//   };

	const titles = [
		'Loan Amount: Average Monthly Payments / Interest Rate',
		'Term: Loan Amount ($000) / Int %',
		'By Grade: Avg Loan Amount ($000) / Interest Rate',
		'Loan Purpose: Loan Amount vs Interest Rate',
		'Total Number of Loans vs Growth Rate %',
		'Loan Statuses & Average Interest Rates By State'
	];

	const Axis = [
		{
			Y1: 'mont_payment',
			X1: 'mont_payment_bar',
			X1NA: 'Monthly Payment',
			X2: 'mont_payment_line',
			X2NA: 'Interest Rate'
		},
		{
			Y1: 'no_months',
			X1: 'term_loan_amt_avg',
			X1NA: 'Average Loan',
			X2: 'term_loan_amt_int',
			X2NA: 'Interest Rate'
		},
		{
			Y1: 'by_grade_alpha',
			X1: 'by_grade_alpha_avg',
			X1NA: 'Avg Loan',
			X2: 'by_grade_alpha_int',
			X2NA: 'Interest Rate'
		},
		{
			Y1: 'purpose_loan',
			X1: 'purpose_loan_avg',
			X1NA: 'Avg Loan',
			X2: 'purpose_loan_int',
			X2NA: 'Interest Rate'
		},
		{
			Y1: 'year',
			X1: 'Total Loans',
			X1NA: 'Total Loans',
			X2: 'Growth',
			X2NA: 'Growth'
		},
		{
			Y1: 'name'
		}
	];

	const continentSources = [
		{ value: 'Charged Off', name: 'Charged Off', color: '#2CC9B7' },
		{ value: 'Current', name: 'Current', color: '#2888D1' },
		{ value: 'Fully Paid', name: 'Fully Paid', color: '#26649e' }
	];

	const onLegendClick = ({ target: series }) => {
		if (series.isVisible()) {
			series.hide();
		} else {
			series.show();
		}
	};

	const customizeLabelLine = (e) => {
		if (no == 1)
			return (
				+e.valueText !== 943 &&
				`${formatNumberWithPeriod(((e.valueText / 6000) * 100).toFixed(1))}%`
			);
		else if (no == 2)
			return (
				+e.valueText !== 21 &&
				`${formatNumberWithPeriod(((e.valueText / 130) * 100).toFixed(1))}%`
			);
		else if (no == 3) return;
		else if (no == 4) return;
		else if (no == 5)
			return (
				+e.valueText != '236629' &&
				`${formatNumberWithPeriod(
					((parseInt(e.valueText.replace(/\D/g, '')) / 600000) * 100).toFixed(1)
				)}%`
			);
		else return formatNumberWithPeriod(+e.valueText); // Format general case numbers
	};

	function formatNumberWithPeriod(num) {
		// Convert number to string using English locale, do not replace commas
		return num.toLocaleString('en-US');
	}

	// const customizeLabelBar = (e) => {
	// 	return `${e.valueText}`;
	// };
	const customizeLabelBar = (e) => {
		return `${parseInt(e.valueText).toLocaleString()}`; // Convert string to number and format
	};

	// const customizeTooltip = (arg) => {
	// 	return {
	// 		text: `${arg.seriesName} : ${arg.valueText} for (${arg.argumentText})`
	// 	};
	// };
	const customizeTooltip = (arg) => {
		return {
			text: `${arg.seriesName} : ${parseInt(
				arg.valueText
			).toLocaleString()} for (${arg.argumentText})`
		};
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>{titles[no - 1]}</div>
			<Chart
				id="chart"
				ref={BarRef}
				// title="Gross State Product within the Great Lakes Region"
				dataSource={service.getData()}
				// onPointClick={onPointClick}
				// onPointClick={pointClickHandler}
				onLegendClick={onLegendClick}
			>
				<Tooltip
					enabled={true}
					location="edge"
					customizeTooltip={customizeTooltip}
				/>
				<ArgumentAxis type="discrete" />
				<CommonSeriesSettings
					argumentField={no !== 6 ? Axis[no - 1].Y1 : 'name'}
					ignoreEmptyPoints={true}
					type={no !== 6 ? 'bar' : 'stackedbar'}
				/>
				{no !== 6 ? (
					<Series
						name={Axis[no - 1].X1NA}
						valueField={Axis[no - 1].X1}
						axis={Axis[no - 1].Y1}
						type="bar"
						color="#26649e"
					>
						<Label
							visible={true}
							backgroundColor="none"
							customizeText={customizeLabelBar}
						>
							<Font color="#000" size={10} />
						</Label>
					</Series>
				) : (
					continentSources.map((item, index) => {
						return (
							<Series
								key={index}
								valueField={item.value}
								name={item.name}
								axis="name"
								color={item.color}
							>
								<Label visible={false}></Label>
							</Series>
						);
					})
				)}
				{no !== 6 ? (
					<Series
						name={Axis[no - 1].X2NA}
						valueField={Axis[no - 1].X2}
						axis={Axis[no - 1].Y1}
						type={no == 5 ? 'line' : 'spline'}
						color="#2CC9B7"
					>
						<Label
							visible={true}
							backgroundColor="none"
							customizeText={customizeLabelLine}
						>
							<Font color="#000" size={10} />
						</Label>
					</Series>
				) : (
					<Series
						name="Average Interest Rate"
						valueField="Average Interest Rate"
						axis="name"
						type={'line'}
						color="#2CC9B7"
					>
						<Label
							visible={true}
							backgroundColor="none"
							customizeText={customizeLabelLine}
						>
							<Font color="#000" />
						</Label>
					</Series>
				)}
				<Legend
					verticalAlignment="bottom"
					horizontalAlignment="center"
					itemTextPosition="left"
				/>
				<ValueAxis name={Axis[no - 1].Y1} valueField={Axis[no - 1].Y1} />
			</Chart>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={exportChart}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default MainBarLine;
