import React, { useState, useRef } from 'react';
import service from '../Data/data.js';
import { ResponsiveContainer, Treemap, Tooltip, Legend } from 'recharts';
import { IconButton, Typography } from '@material-ui/core';
import GetAppIcon from '@material-ui/icons/GetApp';
import domtoimage from 'dom-to-image';
import fileDownload from 'js-file-download';

const TreeComponent = ({ dataD, classes }) => {
	const handleSaveClick = () => {
		domtoimage.toBlob(document.getElementById('Tree')).then(function (blob) {
			fileDownload(blob, 'dom-to-image.png');
		});
	};

	const CustomizedContent = (props) => {
		const {
			root,
			depth,
			x,
			y,
			width,
			height,
			index,
			payload,
			colors,
			rank,
			value,
			name
		} = props;
		return (
			<g>
				<rect
					x={x}
					y={y}
					width={width}
					height={height}
					style={{
						fill: colors[index],
						stroke: '#fff',
						strokeWidth: 1,
						cursor: 'pointer',
						opacity: Number(
							barProps.hover ===
								service.getDataTree().find((element) => element.name === name)
									?.name
						)
							? 0.4
							: 1
					}}
				/>
				{depth === 1 ? (
					<>
						<text
							x={x + 12}
							y={y + 18}
							textAnchor="middle"
							fill="#fff"
							fontSize={11}
						>
							{name}
						</text>
						{barProps.hover ===
							service.getDataTree().find((element) => element.name === name)
								?.name && (
							<text
								x={x + width / 2}
								y={y + height / 2 + 7}
								textAnchor="middle"
								fill="#fff"
								fontSize={11}
							>
								{value} %
							</text>
						)}
					</>
				) : null}
			</g>
		);
	};

	// const dataSource = Object.keys(dataD).map((ar) => ({
	//   name: ar,
	//   size: parseFloat(dataD[ar]),
	// }));

	const [barProps, setBarProps] = useState(
		service.getDataTree().reduce(
			(a, { name }) => {
				a[name] = false;
				return a;
			},
			{ hover: null }
		)
	);

	const handleMouseEnter = (e) => {
		if (!barProps[e.name]) {
			setBarProps({ ...barProps, hover: e?.name });
		}
	};

	const handleMouseLeave = (e) => {
		setBarProps({ ...barProps, hover: null });
	};

	const renderTooltipContent = (o) => {
		const { payload } = o;
		return (
			<div style={{ backgroundColor: '#fff' }}>
				<div
					style={{
						color: service
							.getDataTree()
							.find((element) => element.name === payload[0]?.payload?.name)
							?.color,
						fontSize: 14,
						padding: 5,
						zIndex: 999
					}}
				>
					{`${payload[0]?.payload.name} : ${Number(
						payload[0]?.payload.value
					).toLocaleString()} % `}
				</div>
			</div>
		);
	};

	return (
		<div style={{ position: 'relative', width: '90%', height: '100%' }}>
			<div className={classes.values_title}>Top 10 States By Origination</div>
			<ResponsiveContainer width="100%" height="85%" id="Tree">
				<Treemap
					data={service.getDataTree()}
					dataKey="value"
					// ratio={4 / 3}
					isAnimationActive={true}
					animationEasing="ease-in-out"
					content={<CustomizedContent colors={service.colorArray} />}
					onMouseEnter={handleMouseEnter}
					onMouseLeave={handleMouseLeave}
				>
					{/* <Tooltip content={renderTooltipContent} /> */}
					<Tooltip content={renderTooltipContent}></Tooltip>
					<Legend />
				</Treemap>
			</ResponsiveContainer>
			<span style={{ float: 'left', position: 'absolute', top: -40, right: 5 }}>
				<IconButton
					color="inherit"
					style={{ opacity: 0.5 }}
					aria-label="open drawer"
					onClick={handleSaveClick}
					edge="start"
				>
					<GetAppIcon size="small" style={{ width: 20, height: 20 }} />
				</IconButton>
			</span>
		</div>
	);
};

export default TreeComponent;
