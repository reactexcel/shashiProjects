import { makeStyles } from '@material-ui/core/styles';
import { appContainer, appContentContainer } from '../../common/assets/layout';
export const useStyles = makeStyles((theme) => ({
	main__div: {
		height: '85px',
		position: 'relative',
		cursor: 'pointer',
		transition: 'background .2s ease',
		color: '#334152',
		'&:before': {
			transition: '0.2s',
			content: '" "',
			position: 'absolute',
			display: 'block',
			height: '100%',
			width: 1,
			zIndex: 1,
			backgroundColor: '#d8dde3'
		},
		'&:hover': {
			'&:before': {
				opacity: 0
			},
			backgroundColor: '#d8dde3'
		}
	},
	title: {
		width: '100%',
		marginTop: 50,
		marginBottom: 100,
		position: 'relative'
	},
	title__typo: {
		marginTop: 70,
		marginLeft: 500,
		fontWeight: 400,
		fontSize: 24,
		color: '#334152',
		opacity: 0.8
	},
	header__typo: {
		fontWeight: 600,
		fontSize: 12,
		position: 'absolute',
		left: 10,
		top: 5
	},
	values_title: {
		fontWeight: 600,
		fontSize: 18,
		position: 'absolute',
		top: -50,
		marginBottom: 30,
		left: 0,
		color: '#334152'
	},
	header__value: {
		fontWeight: 600,
		fontSize: 18,
		position: 'absolute',
		left: 10,
		top: 25
	},
	header__sub: {
		fontWeight: 400,
		fontSize: 10,
		position: 'absolute',
		left: 10,
		bottom: 10
	},
	backdrop: {
		zIndex: theme.zIndex.drawer + 9999,
		color: '#fff'
	},
	selectIcon: {
		width: 16,
		color: '#7991aa',
		margin: 5
	},
	header__run: {
		textTransform: 'capitalize',
		height: 31,
		width: 65,
		marginRight: 10,
		marginLeft: 5,
		color: 'white',
		borderRadius: 0,
		backgroundColor: '#7991aa',
		'&:hover': {
			backgroundColor: '#99a8b7'
		}
	},
	appContainer,
	appContentContainer
}));
