function generateData(start, end, step) {
	const data = [];
	for (let i = start; i < end; i += step) {
		const originalValue = Math.sin(i) / i;
		data.push({
			value: originalValue + (0.5 - Math.random()) / 10,
			originalValue: originalValue,
			argument: 2007 + i
		});
	}
	return data;
}

export const dataSource = generateData(2.5, 12, 0.1);

export const colorArray = [
	'#26649E',
	'#26509E',
	'#2CC9B7',
	'#71BAEB',
	'#1F7E76',
	'#8bdcbe',
	// "#f05a71",
	// "#371ea3",
	'#46bac2',
	// "#ae2c87",
	// "#ffa58c",
	'#4378bf',
	'#2CC9B7',
	'#279E94'
];

export const grossProductData = [
	{
		state: 'Non Defauled Loans',
		GradeB: 30,
		GradeC: 27,
		GradeD: 16,
		GradeE: 8,
		GradeG: 1,
		GradeF: 3
	},
	{
		state: 'Defauled Loans',
		GradeB: 19,
		GradeC: 26,
		GradeD: 14,
		GradeE: 13,
		GradeG: 2,
		GradeF: 18
	}
];

const Data = [
	{
		name: 'CA',
		'Charged Off': 2000,
		Current: 7000,
		'Fully Paid': 7000,
		'Charged Off1': 0,
		Current1: 0,
		'Fully Paid1': 1,
		'Average Interest Rate': 13000,
		'Total Loans': 603,
		year: 2007,
		employ: 'Teacher',
		employVal: 9187,
		purpose: 'Debt Consolidation',
		pur_loans: 245355,
		pur_amount: 16309,
		pur_anuual: 84136,
		mont_payment: '0-5K',
		mont_payment_line: 750.0,
		mont_payment_bar: 111.54,
		no_months: '36 months',
		term_loan_amt_avg: 13,
		term_loan_amt_int: 15,
		by_grade_alpha: 'A',
		by_grade_alpha_avg: 14,
		by_grade_alpha_int: 5,
		purpose_loan: 'Education',
		purpose_loan_int: 20,
		empLengPre: 'Non Defauled Loans',
		empLengPre_bar: 5.71,
		DTIPreLoa: 'Non Defauled Loans',
		DTIPreLoa_bar: 17.3,
		MonCred: 'Non Defauled Loans',
		MonCred_bar: 267.93
	},
	{
		name: 'NY',
		'Charged Off': 1500,
		Current: 5000,
		'Fully Paid': 5000,
		'Charged Off1': 0,
		Current1: 0,
		'Fully Paid1': 2,
		'Average Interest Rate': 14000,
		'Total Loans': 2393,
		Growth: 443579,
		year: 2008,
		employ: 'Manager',
		employVal: 8752,
		purpose: 'Credit Card',
		pur_loans: 85034,
		pur_amount: 15337,
		pur_anuual: 82981,
		mont_payment: '10-15K',
		mont_payment_line: 890.0,
		mont_payment_bar: 365.77,
		no_months: '60 months',
		term_loan_amt_avg: 21,
		term_loan_amt_int: 21,
		by_grade_alpha: 'B',
		by_grade_alpha_avg: 14,
		by_grade_alpha_int: 7,
		purpose_loan: 'wedding',

		purpose_loan_int: 15,
		empLengPre: 'Defauled Loans',
		empLengPre_bar: 4.57,
		DTIPreLoa: 'Defauled Loans',
		DTIPreLoa_bar: 15.8,
		MonCred: 'Defauled Loans',
		MonCred_bar: 228.75
	},
	{
		name: 'TX',
		'Charged Off': 1300,
		Current: 4000,
		'Fully Paid': 4000,
		'Charged Off1': 0,
		Current1: 0.5,
		'Fully Paid1': 3,
		'Average Interest Rate': 12000,
		'Total Loans': 5281,
		Growth: 335000,
		year: 2009,
		employ: 'Owner',
		employVal: 7134,
		purpose: 'Other',
		pur_loans: 36888,
		pur_amount: 10861,
		pur_anuual: 75541,
		mont_payment: '15K-20K',
		mont_payment_line: 940.4,
		mont_payment_bar: 498.69,
		by_grade_alpha: 'C',
		by_grade_alpha_avg: 16,
		by_grade_alpha_int: 11,
		purpose_loan: 'ex1',

		purpose_loan_int: 13
	},
	{
		name: 'FL',
		'Charged Off': 1450,
		Current: 3500,
		'Fully Paid': 3500,
		'Charged Off1': 0,
		Current1: 2,
		'Fully Paid1': 5,
		'Average Interest Rate': 13000,
		'Total Loans': 12537,
		Growth: 335555,
		year: 2010,
		employ: 'Driver',
		employVal: 4323,
		purpose: 'Home Improvement',
		pur_loans: 35654,
		pur_amount: 15028,
		pur_anuual: 87814,
		mont_payment: '20K-25K',
		mont_payment_line: 944.0,
		mont_payment_bar: 640.66,
		by_grade_alpha: 'D',
		by_grade_alpha_avg: 16,
		by_grade_alpha_int: 14,
		purpose_loan: 'ex2',

		purpose_loan_int: 13
	},
	{
		name: 'NJ',
		'Charged Off': 1000,
		Current: 2500,
		'Fully Paid': 3000,
		'Charged Off1': 4,
		Current1: 4,
		'Fully Paid1': 11,
		'Average Interest Rate': 14000,
		'Total Loans': 21721,
		Growth: 300955,
		year: 2011,
		employ: 'Supervisor',
		employVal: 4143,
		purpose: 'Major Purpose',
		pur_loans: 12185,
		pur_amount: 13820,
		pur_anuual: 82900,
		mont_payment: '25K+',
		mont_payment_line: 943,
		mont_payment_bar: 943,
		by_grade_alpha: 'E',
		by_grade_alpha_avg: 17,
		by_grade_alpha_int: 17,
		purpose_loan: 'moving',
		purpose_loan_int: 13
	},
	{
		name: 'PA',
		'Charged Off': 1000,
		Current: 2000,
		'Fully Paid': 3000,
		'Charged Off1': 6,
		Current1: 19,
		'Fully Paid1': 25,
		'Average Interest Rate': 13500,
		'Total Loans': 53367,
		Growth: 335955,
		year: 2012,
		employ: 'Registered Nurse',
		employVal: 3726,
		purpose: 'Medical',
		pur_loans: 7207,
		pur_amount: 9748,
		pur_anuual: 75151,
		mont_payment: '5K-10K',
		mont_payment_line: 740,
		mont_payment_bar: 248.0,
		by_grade_alpha: 'F',
		by_grade_alpha_avg: 19,
		by_grade_alpha_int: 21,
		purpose_loan: 'Debt Consolidation',

		purpose_loan_int: 13
	},
	{
		name: 'OH',
		'Charged Off': 500,
		Current: 1000,
		'Fully Paid': 1200,
		'Charged Off1': 6,
		Current1: 40,
		'Fully Paid1': 55,
		'Average Interest Rate': 15000,
		'Total Loans': 134814,
		Growth: 338555,
		year: 2013,
		employ: 'Sales',
		employVal: 3425,
		purpose: 'Car',
		pur_loans: 5600,
		pur_amount: 8751,
		pur_anuual: 72061,
		by_grade_alpha: 'G',
		by_grade_alpha_avg: 21,
		by_grade_alpha_int: 21,
		purpose_loan: 'Other',

		purpose_loan_int: 13
	},
	{
		// name: "PA",
		// "Charged Off": 3490,
		// Current: 4300,
		// "Fully Paid": 2100,
		'Charged Off1': 6,
		Current1: 50,
		'Fully Paid1': 70,
		'Average Interest Rate': 16000,
		'Total Loans': 230629,
		Growth: 236629,
		year: 2014,
		employ: 'RN',
		employVal: 3193,
		purpose: 'Small Business',
		pur_loans: 5100,
		pur_amount: 17900,
		pur_anuual: 59725,
		purpose_loan: 'House',

		purpose_loan_int: 12
	},
	{
		// name: "PA",
		// "Charged Off": 3490,
		// Current: 4300,
		// "Fully Paid": 2100,
		// "Average Interest Rate": 16000,
		'Charged Off1': 7,
		Current1: 60,
		'Fully Paid1': 80,
		'Total Loans': 421095,
		Growth: 246629,
		year: 2015,
		employ: 'Project Manager',
		employVal: 2472,
		purpose: 'House',
		pur_loans: 4100,
		pur_amount: 16261,
		pur_anuual: 87275,
		purpose_loan: 'Medical',

		purpose_loan_int: 13
	},
	{
		// name: "PA",
		// "Charged Off": 3490,
		// Current: 4300,
		// "Fully Paid": 2100,
		// "Average Interest Rate": 16000,
		'Charged Off1': 6,
		Current1: 65,
		'Fully Paid1': 85,
		'Total Loans': 434407,
		Growth: 21721,
		year: 2016,
		employ: 'Office Manager',
		employVal: 2275,
		purpose: 'Vacation',
		pur_loans: 2000,
		pur_amount: 6355,
		pur_anuual: 72001,
		purpose_loan: 'Major',

		purpose_loan_int: 13
	},
	{
		// name: "PA",
		// "Charged Off": 3490,
		// Current: 4300,
		// "Fully Paid": 2100,
		// "Average Interest Rate": 16000,
		'Charged Off1': 7,
		Current1: 70,
		'Fully Paid1': 90,
		'Total Loans': 443597,
		Growth: 12532,
		year: 2017,
		purpose_loan: 'Vacation',
		purpose_loan_int: 13
	},
	{
		purpose_loan: 'Home',

		purpose_loan_int: 12
	},
	{
		purpose_loan: 'Car',

		purpose_loan_int: 12
	},
	{
		purpose_loan: 'Credit',

		purpose_loan_int: 13
	}
];

const dataTree = [
	{
		value: 20.5,
		name: 'PA'
	},
	{
		value: 6.81,
		name: 'NJ'
	},
	{
		value: 5.68,
		name: 'IL'
	},
	{
		value: 13.0,
		name: 'FL'
	},
	{
		value: 11.05,
		name: 'TX'
	},
	{
		value: 15.16,
		name: 'NY'
	},
	{
		value: 16.99,
		name: 'CA'
	},
	{
		value: 4.99,
		name: 'GA'
	},
	{
		value: 5.37,
		name: 'OH'
	},
	{
		value: 5.2,
		name: 'VA'
	}
];

const dataArea = [
	{
		name: 'CA',
		A: 4000,
		B: 2400,
		C: 2400,
		D: 4000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'NY',
		A: 3000,
		B: 1398,
		C: 2210,
		D: 4000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'TX',
		A: 2000,
		B: 9800,
		C: 2290,
		D: 15000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'FL',
		A: 2780,
		B: 3908,
		C: 2000,
		D: 15000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'IL',
		A: 1890,
		B: 4800,
		C: 2181,
		D: 15000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'NJ',
		A: 2390,
		B: 3800,
		C: 2500,
		D: 15000,
		E: 6000,
		F: 8000,
		G: 9000
	},
	{
		name: 'PA',
		A: 3490,
		B: 4300,
		C: 2100,
		D: 15000,
		E: 6000,
		F: 8000,
		G: 9000
	}
];

export default {
	getData() {
		return Data;
	},
	getDataTree() {
		return dataTree;
	},
	getDataArea() {
		return dataArea;
	},
	colorArray
};
