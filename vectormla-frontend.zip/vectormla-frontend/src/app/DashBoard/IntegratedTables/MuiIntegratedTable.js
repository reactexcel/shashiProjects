import React, { useState } from 'react';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';
import {
	GroupingState,
	IntegratedFiltering,
	IntegratedGrouping,
	IntegratedPaging,
	IntegratedSelection,
	IntegratedSorting,
	PagingState,
	SelectionState,
	SortingState,
	SearchState
} from '@devexpress/dx-react-grid';
import {
	DragDropProvider,
	Grid,
	GroupingPanel,
	PagingPanel,
	Table,
	TableGroupRow,
	TableHeaderRow,
	SearchPanel,
	TableColumnVisibility,
	TableColumnReordering,
	Toolbar
} from '@devexpress/dx-react-grid-material-ui';
import { generateRows, globalSalesValues } from '../Data/generator';

const sales = generateRows({ columnValues: globalSalesValues, length: 1000 });

const styles = (theme) => ({
	tableStriped: {
		'& thead tr th div:first-child': {
			minWidth: '100%',
			'& span': {
				minWidth: '100%'
			},
			color: '#fff'
		},
		'& tbody tr': {
			'& td': {
				textOverflow: 'unset'
			}
		},
		'& tbody tr:nth-of-type(odd)': {
			backgroundColor: '#f7f8fa',
			'& div': {
				backgroundColor: 'inherit',
				width: '100%',
				'&:hover': {
					backgroundColor: 'rgba(33, 150, 243, 0.5)'
				}
			}
		},

		'& .MuiTableHead-root': {
			backgroundColor: '#266696',
			'& div': {
				backgroundColor: 'inherit',
				width: '100%',
				'&:hover': {
					color: '#fff'
				}
			},
			'&:hover': {
				color: '#fff'
			},
			'& span': {
				fontSize: 14,
				fontWeight: 'bolder',
				'& span': {
					textOverflow: 'unset'
				}
			}
		},
		'& .MuiTableCell-root': {
			padding: '2px 24px 2px 16px',
			border: '1px solid #e9eff5',
			'&:hover': {
				backgroundColor: '#d6ecff',
				color: '#c97513'
			}
		},
		'& .MuiTableRow-head': {
			'& th': {
				backgroundColor: '#266696',
				'&:hover': {
					backgroundColor: '#266696'
				},
				'& .Title-title-92': {
					color: '#fff'
				}
			},
			color: '#ff1234'
		}
	}
});

const TableComponentBase = ({ classes, ...restProps }) => (
	<Table.Table {...restProps} className={classes.tableStriped} />
);

export const TableComponent = withStyles(styles, { name: 'TableComponent' })(
	TableComponentBase
);

function MuiIntegratedTable() {
	const [columns] = useState([
		{ name: 'product', title: 'Member ID' },
		{ name: 'state', title: 'State' },
		{ name: 'amount', title: 'Loan Amount' },
		{ name: 'saleDate', title: 'Interest Rate' },
		{ name: 'customer', title: 'Installment' },
		{ name: 'term', title: 'Term' },
		{ name: 'DTI', title: 'DTI' },
		{ name: 'Home_Ownership', title: 'Home Ownership' },
		{ name: 'grade', title: 'Grade' },
		{ name: 'loan_status', title: 'Loan Status' }
	]);
	const [rows] = useState(sales);
	const [pageSizes] = useState([15, 20]);
	const [currentPage, setCurrentPage] = useState(0);
	const [pageSize, setPageSize] = useState(15);
	//   const [currencyColumns] = useState(["amount"]);
	const [defaultColumnWidths] = useState([
		{ columnName: 'product', width: 100 },
		{ columnName: 'state', width: 100 },
		{ columnName: 'amount', width: 100 },
		{ columnName: 'saleDate', width: 100 },
		{ columnName: 'customer', width: 100 },
		{ columnName: 'term', width: 100 },
		{ columnName: 'DTI', width: 100 },
		{ columnName: 'Home_Ownership', width: 100 },
		{ columnName: 'grade', width: 100 },
		{ columnName: 'loan_status', width: 100 }
	]);
	const [defaultHiddenColumnNames] = useState([]);
	const [columnOrder, setColumnOrder] = useState(
		defaultColumnWidths.map((m) => m.columnName)
	);

	return (
		<Paper elevation={0}>
			<Grid
				rows={rows}
				columns={columns}
				style={{ height: 400, overflow: 'scroll' }}
			>
				<SearchState />
				<SortingState />
				<SelectionState />
				<GroupingState />
				<PagingState
					currentPage={currentPage}
					onCurrentPageChange={setCurrentPage}
					pageSize={pageSize}
					onPageSizeChange={setPageSize}
				/>
				<IntegratedGrouping />
				<IntegratedFiltering />
				<IntegratedSorting />
				<IntegratedPaging />
				<IntegratedSelection />
				<DragDropProvider />
				<Table tableComponent={TableComponent} />
				<TableColumnVisibility
					defaultHiddenColumnNames={defaultHiddenColumnNames}
				/>
				<TableColumnReordering
					order={columnOrder}
					onOrderChange={setColumnOrder}
				/>
				<TableHeaderRow showSortingControls={true} />
				<PagingPanel pageSizes={pageSizes} />
				<TableGroupRow />
				<Toolbar />
				<SearchPanel />
				<GroupingPanel showSortingControls={true} />
			</Grid>
		</Paper>
	);
}

export default MuiIntegratedTable;
