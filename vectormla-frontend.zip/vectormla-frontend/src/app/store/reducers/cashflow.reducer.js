import {
	GET_CASHFLOW_PORTFOLIOS_SUCCESS,
	GET_CASHFLOW_PORTFOLIOS_FAILED,
	UPDATE_CASHFLOW_PORTFOLIOS,
	GET_CASHFLOW_SENARIOS_SUCCESS,
	GET_CASHFLOW_TABLES_CLEAN,
	GET_CASHFLOW_SENARIOS_FAILED,
	GET_CASHFLOW_TABLES_SUCCESS,
	GET_CASHFLOW_TABLES_FAILED,
	STOP_CASHFLOW_TIMER,
	START_CASHFLOW_TIMER,
	STOP_LOADING,
	TICK_CASHFLOW_TIMER
} from '../types/cashflow.type';

const initialState = {
	portfolios: null,
	scenarios: null,
	tables: null,
	loading: false,
	error: null,
	minutes: 4,
	seconds: 30,
	status: 'stopped'
};

const cashflowReducer = (state = initialState, action) => {
	switch (action.type) {
		case GET_CASHFLOW_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios: action.payload,
				loading: false
			};
		case GET_CASHFLOW_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CASHFLOW_SENARIOS_SUCCESS:
			return {
				...state,
				scenarios: action.payload,
				loading: false
			};
		case UPDATE_CASHFLOW_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_CASHFLOW_SENARIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CASHFLOW_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload }
			};
		case GET_CASHFLOW_TABLES_CLEAN:
			return {
				...state,
				tables: null,
				loading: false,
				error: null,
				portfolios: null
			};
		case GET_CASHFLOW_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case START_CASHFLOW_TIMER:
			return {
				...state,
				status: 'start',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_CASHFLOW_TIMER:
			if (state.minutes !== 0 && state.seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes !== 0 && state.seconds === 0) {
				return {
					...state,
					status: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes === 0 && state.seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return {
					...state,
					minutes: 4,
					seconds: 30,
					status: 'stopped'
				};
			}
		case STOP_CASHFLOW_TIMER:
			return {
				...state,
				minutes: 4,
				seconds: 30,
				status: action.payload
			};
		case STOP_LOADING:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		default:
			return state;
	}
};

export default cashflowReducer;
