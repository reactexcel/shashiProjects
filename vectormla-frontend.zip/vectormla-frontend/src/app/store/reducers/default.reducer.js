import {
	GET_DEFAULT_PORTFOLIOS_SUCCESS,
	GET_DEFAULT_PORTFOLIOS_FAILED,
	GET_DEFAULT_TABLES_FAILED,
	GET_DEFAULT_TABLES_SUCCESS,
	GET_DEFAULT_TABLES_CLEAN,
	START_DEFAULT_TIMER,
	STOP_DEFAULT_TIMER,
	TICK_DEFAULT_TIMER
} from '../types/default.type';

const initialState = {
	portfolios: null,
	loading: false,
	status: 'stopped',
	taskProgress: '0.0 %'
};

const defaultReducer = (state = initialState, action) => {
	const { minutes, seconds } = state;
	switch (action.type) {
		case GET_DEFAULT_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios: action.payload,
				loading: false
			};
		case GET_DEFAULT_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_DEFAULT_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload }
			};
		case GET_DEFAULT_TABLES_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_DEFAULT_TABLES_CLEAN:
			return {
				...state,
				tables: null,
				loading: false,
				error: null,
				portfolios: null
			};
		case START_DEFAULT_TIMER:
			return {
				...state,
				status: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_DEFAULT_TIMER:
			if (minutes !== 0 && seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: seconds - 5,
					minutes
				};
			} else if (minutes !== 0 && seconds === 0) {
				return {
					...state,
					status: 'pending',
					seconds: 55,
					minutes: minutes - 1
				};
			} else if (minutes === 0 && seconds !== 0) {
				return {
					...state,
					status: 'pending',
					seconds: seconds - 5,
					minutes
				};
			} else {
				return {
					...state,
					minutes: 4,
					seconds: 30,
					status: 'stopped'
				};
			}
		case STOP_DEFAULT_TIMER:
			return { ...state, minutes: 4, seconds: 30, status: action.payload };
		default:
			return state;
	}
};

export default defaultReducer;
