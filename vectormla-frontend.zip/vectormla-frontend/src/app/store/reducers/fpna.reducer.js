import {
	GET_FPNA_PORTFOLIOS_SUCCESS,
	GET_FPNA_PORTFOLIOS_FAILED,
	UPDATE_FPNA_PORTFOLIOS,
	GET_FPNA_SCENARIOS_SUCCESS,
	GET_FPNA_SCENARIOS_FAILED,
	GET_FPNA_TABLES_SUCCESS,
	GET_FPNA_TABLES_FAILED,
	START_FPNA_TIMER,
	STOP_FPNA_TIMER,
	TICK_FPNA_TIMER,
	GET_FPNA_TABLES_CLEAN,
	GET_FPNA2_PORTFOLIOS_SUCCESS,
	GET_FPNA2_PORTFOLIOS_FAILED,
	UPDATE_FPNA2_PORTFOLIOS,
	GET_FPNA2_TABLES_SUCCESS,
	GET_FPNA2_TABLES_FAILED,
	GET_FPNA2_TABLES_CLEAN,
	GET_FPNA3_PORTFOLIOS_SUCCESS,
	GET_FPNA3_PORTFOLIOS_FAILED,
	UPDATE_FPNA3_PORTFOLIOS,
	GET_FPNA3_TABLES_SUCCESS,
	GET_FPNA3_TABLES_FAILED,
	GET_FPNA6_CHARTS_FAILED,
	GET_FPNA9_CHARTS_FAILED,
	GET_FPNA3_TABLES_CLEAN,
	START_FPNA3_TIMER,
	STOP_FPNA3_TIMER,
	TICK_FPNA3_TIMER,
	GET_CHARTS3_SUCCESS,
	GET_CHARTS3_FAILED,
	GET_CHARTS3_CLEAN,
	GET_CHARTS6_CLEAN,
	GET_PREPAYMENT6_1_1_CHARTS_CLEAN,
	GET_CHARTS9_CLEAN,
	GET_CHARTS3_3_SUCCESS,
	GET_CHARTS6_2_1_SUCCESS,
	GET_CHARTS6_2_1_FAILED,
	GET_CHARTS6_2_1_CLEAN,
	GET_CHARTS3_3_FAILED,
	GET_CHARTS3_3_CLEAN,
	TASK_PROGRESS_FPNA3,
	GET_FPNA6_CHARTS_SUCCESS,
	GET_PREPAYMENT6_1_1_CHARTS_SUCCESS,
	GET_FPNA6_SEGMENT_SUCCESS,
	GET_FPNA9_CHARTS_SUCCESS,
	GET_FPNA9_SEGMENT_SUCCESS,
	GET_FPNA5_SEGMENT_SUCCESS,
	GET_FPNA3_SUBPORTOFOLIOS_SUCCESS,
	GET_FPNA3_SUBPORTOFOLIOS_FAILED,
	GET_FPNA3_SEGMENT_SUCCESS,
	GET_FPNA3_SEGMENT_FAILED,
	GET_FPNA3_SCENARIOS_SUCCESS,
	GET_FPNA4_PORTFOLIOS_SUCCESS,
	GET_FPNA4_PORTFOLIOS_FAILED,
	UPDATE_FPNA4_PORTFOLIOS,
	GET_FPNA4_TABLES_SUCCESS,
	GET_FPNA4_TABLES_CLEAN,
	GET_FPNA4_TABLES_FAILED,
	GET_FPNA4_CHARTS_SUCCESS,
	GET_FPNA5_CHARTS_SUCCESS,
	GET_FPNA4_CHARTS_FAILED,
	GET_FPNA4_CHARTS_CLEAN,
	GET_FPNA5_CHARTS_CLEAN,
	GET_CHASHFLOW2CHARTS_SUCCESS,
	GET_CHASHFLOW2CHARTS_FAILED,
	GET_CHASHFLOW2CHARTS_CLEAN,
	START_FPNA4_TIMER,
	STOP_FPNA4_TIMER,
	TICK_FPNA4_TIMER,
	GET_FPNA4_SCENARIOS_SUCCESS,
	STOP_LOADING,
	GET_FPNA4_SECOND_CHARTS_SUCCESS,
	GET_FPNA4_SECOND_CHARTS_FAILED,
	GET_FPNA4_SECOND_CHARTS_CLEAN,
	TASK_PROGRESS_FPNA4,
	GET_FPNA5_PORTFOLIOS_SUCCESS,
	GET_FPNA5_PORTFOLIOS_FAILED,
	UPDATE_FPNA5_PORTFOLIOS,
	GET_FPNA5_TABLES_SUCCESS,
	GET_FPNA5_TABLES_FAILED,
	GET_FPNA5_TABLES_CLEAN,
	START_FPNA5_TIMER,
	STOP_FPNA5_TIMER,
	TICK_FPNA5_TIMER,
	TASK_PROGRESS_FPNA5,
	GET_FPNA5_SCENARIOS_SUCCESS,
	GET_FPNA6_PORTFOLIOS_SUCCESS,
	GET_FPNA9_PORTFOLIOS_SUCCESS,
	GET_FPNA0_PORTFOLIOS_SUCCESS,
	GET_FPNA6_PORTFOLIOS_FAILED,
	GET_FPNA9_PORTFOLIOS_FAILED,
	GET_FPNA0_PORTFOLIOS_FAILED,
	UPDATE_FPNA6_PORTFOLIOS,
	UPDATE_FPNA9_PORTFOLIOS,
	UPDATE_FPNA0_PORTFOLIOS,
	GET_FPNA6_TABLES_SUCCESS,
	GET_FPNA9_TABLES_SUCCESS,
	GET_FPNA0_TABLES_SUCCESS,
	GET_FPNA6_TABLES_FAILED,
	GET_FPNA9_TABLES_FAILED,
	GET_FPNA0_TABLES_FAILED,
	GET_FPNA6_TABLES_CLEAN,
	GET_FPNA9_TABLES_CLEAN,
	GET_FPNA0_TABLES_CLEAN,
	START_FPNA6_TIMER,
	START_FPNA9_TIMER,
	START_FPNA0_TIMER,
	STOP_FPNA6_TIMER,
	STOP_FPNA9_TIMER,
	STOP_FPNA0_TIMER,
	TICK_FPNA6_TIMER,
	TICK_FPNA9_TIMER,
	TICK_FPNA0_TIMER,
	TASK_PROGRESS_FPNA6,
	TASK_PROGRESS_FPNA9,
	TASK_PROGRESS_FPNA0,
	GET_FPNA6_SCENARIOS_SUCCESS,
	GET_FPNA9_SCENARIOS_SUCCESS,
	GET_FPNA0_SCENARIOS_SUCCESS
} from '../types/fpna.type';

const INITIAL_STATE = {
	portfolios: null,
	scenarios: null,
	scenarios3: null,
	subPortofolio3: null,
	segment3: {},
	scenarios4: null,
	tables: null,
	portfolios0: null,
	portfolios2: null,
	portfolios3: null,
	portfolios4: null,
	portfolios5: null,
	portfolios6: null,
	tables0: null,
	tables2: null,
	tables3: null,
	tables4: null,
	tables5: null,
	tables6: null,
	newTable: null,
	loading: false,
	charts3: null,
	charts6: null,
	prepayment_6_1_1_charts: null,
	charts3_3: null,
	charts6_2_1: null,
	charts4: null,
	charts5: null,
	chashflow2charts: null,
	secondCharts4: null,
	error: null,
	minutes: 4,
	seconds: 30,
	status0: 'stopped',
	status1: 'stopped',
	taskProgress1: '0.0 %',
	status2: 'stopped',
	taskProgress2: '0.0 %',
	status3: 'stopped',
	taskProgress3: '0.0 %',
	status4: 'stopped',
	taskProgress4: '0.0 %',
	status5: 'stopped',
	status6: 'stopped',
	staus5ScenarioID: null,
	staus0ScenarioID: null,
	status5PortfolioID: null,
	status0PortfolioID: null,
	staus6ScenarioID: null,
	status6PortfolioID: null,
	taskProgress0: '0.0 %',
	taskProgress5: '0.0 %',
	taskProgress6: '0.0 %',
	calc_time_seconds5: undefined,
	calc_time_seconds0: undefined,
	calc_time_seconds6: undefined
};
const fpnaReducer = (state = INITIAL_STATE, action) => {
	switch (action.type) {
		case GET_FPNA_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios: action.payload,
				loading: false
			};
		case GET_FPNA_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios: action.payload,
				loading: false
			};
		case GET_FPNA3_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios3: action.payload,
				loading: false
			};
		case GET_FPNA3_SUBPORTOFOLIOS_SUCCESS:
			return {
				...state,
				subPortofolio3: action.payload,
				segment3: {},
				loading: false
			};
		case GET_FPNA3_SEGMENT_SUCCESS:
			return {
				...state,
				segment3: { ...state?.segment3, ...action.payload },
				loading: false
			};
		case GET_FPNA6_CHARTS_SUCCESS:
			return {
				...state,
				subPortofolio6: action.payload,
				charts6: action.payload,
				segment6: {},
				loading: false
			};
		case GET_PREPAYMENT6_1_1_CHARTS_SUCCESS:
			return {
				...state,
				prepayment_6_1_1_charts: action.payload,
				loading: false
			};
		case GET_FPNA9_CHARTS_SUCCESS:
			return {
				...state,
				subPortofolio9: action.payload,
				charts9: action.payload,
				segment9: {},
				loading: false
			};
		case GET_FPNA5_CHARTS_SUCCESS:
			return {
				...state,
				subPortofolio5: action.payload,
				charts5: action.payload,
				segment5: {},
				loading: false
			};
		case GET_FPNA6_SEGMENT_SUCCESS:
			return {
				...state,
				segment6: { ...state?.segment6, ...action.payload },
				loading: false
			};
		case GET_FPNA9_SEGMENT_SUCCESS:
			return {
				...state,
				segment9: { ...state?.segment9, ...action.payload },
				loading: false
			};
		case GET_FPNA5_SEGMENT_SUCCESS:
			return {
				...state,
				segment5: { ...state?.segment5, ...action.payload },
				loading: false
			};
		case UPDATE_FPNA_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_FPNA_TABLES_SUCCESS:
			return {
				...state,
				tables: { ...state.tables, ...action.payload }
			};
		case GET_FPNA_TABLES_CLEAN:
			return {
				...state,
				tables: null,
				loading: false,
				error: null,
				portfolios: null
			};
		case STOP_LOADING:
			return {
				error: action.payload,
				loading: false
			};
		case GET_FPNA2_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios2: action.payload
			};
		case UPDATE_FPNA2_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_FPNA2_TABLES_SUCCESS:
			return {
				...state,
				tables2: { ...state.tables2, ...action.payload },
				loading: false
			};
		case GET_FPNA2_TABLES_CLEAN:
			return {
				...state,
				tables2: null,
				loading: false,
				error: null,
				portfolios2: null
			};
		case TASK_PROGRESS_FPNA3:
			return {
				...state,
				taskProgress3: action.payload
			};
		case GET_FPNA3_TABLES_SUCCESS:
			return {
				...state,
				tables3: { ...state.tables3, ...action.payload },
				loading: false
			};
		case GET_FPNA3_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios3: action.payload
			};
		case UPDATE_FPNA3_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case GET_FPNA3_TABLES_CLEAN:
			return {
				...state,
				tables3: null,
				segment3: {},
				subPortofolio3: null,
				loading: false,
				error: null,
				portfolios3: action.payload
					? state?.portfolios3?.filter((item) => action.payload.id === item.id)
					: null,
				scenarios3: null
			};
		case GET_FPNA4_TABLES_SUCCESS:
			return {
				...state,
				tables4: { ...state.tables4, ...action.payload },
				loading: false
			};
		case GET_FPNA4_TABLES_CLEAN:
			return {
				...state,
				tables4: null,
				portfolios4: null,
				error: null,
				loading: false,
				scenarios4: null
			};
		case GET_FPNA4_CHARTS_SUCCESS:
			return {
				...state,
				charts4: action.payload,
				loading: false
			};
		case GET_FPNA4_CHARTS_CLEAN:
			return {
				...state,
				charts4: null,
				portfolios4: null,
				error: null,
				loading: false
			};
		case GET_FPNA5_CHARTS_CLEAN:
			return {
				...state,
				charts5: null,
				portfolios5: null,
				error: null,
				loading: false
			};
		case GET_FPNA4_SECOND_CHARTS_SUCCESS:
			return {
				...state,
				secondCharts4: action.payload,
				loading: false
			};
		case GET_FPNA4_SECOND_CHARTS_CLEAN:
			return {
				...state,
				secondCharts4: null,
				portfolios4: null,
				error: null,
				loading: false
			};
		case GET_FPNA4_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios4: action.payload,
				loading: false
			};
		case GET_CHARTS3_SUCCESS:
			return {
				...state,
				charts3: action.payload,
				loading: false
			};
		// same case
		case GET_FPNA_SCENARIOS_FAILED:
		case GET_FPNA3_SUBPORTOFOLIOS_FAILED:
		case GET_FPNA3_SEGMENT_FAILED:
		case GET_FPNA_TABLES_FAILED:
		case GET_FPNA2_PORTFOLIOS_FAILED:
		case GET_FPNA2_TABLES_FAILED:
		case GET_FPNA3_TABLES_FAILED:
		case GET_FPNA3_PORTFOLIOS_FAILED:
		case GET_FPNA_PORTFOLIOS_FAILED:
		case GET_FPNA4_TABLES_FAILED:
		case GET_FPNA4_CHARTS_FAILED:
		case GET_FPNA4_SECOND_CHARTS_FAILED:
		case GET_CHASHFLOW2CHARTS_FAILED:
		case GET_FPNA6_CHARTS_FAILED:
		case GET_FPNA9_CHARTS_FAILED:
		case GET_CHARTS3_FAILED:
		case GET_FPNA4_PORTFOLIOS_FAILED:
		case GET_FPNA5_TABLES_FAILED:
		case GET_FPNA5_PORTFOLIOS_FAILED:
		case GET_FPNA6_TABLES_FAILED:
		case GET_FPNA9_TABLES_FAILED:
		case GET_FPNA0_TABLES_FAILED:
		case GET_FPNA6_PORTFOLIOS_FAILED:
		case GET_FPNA9_PORTFOLIOS_FAILED:
		case GET_FPNA0_PORTFOLIOS_FAILED:
			return {
				...state,
				error: action.payload,
				loading: false
			};
		case GET_CHARTS3_CLEAN:
			return {
				...state,
				charts3: null,
				error: null,
				loading: false
			};
		case GET_CHARTS6_CLEAN:
			return {
				...state,
				charts6: null,
				error: null,
				loading: false
			};
		case GET_PREPAYMENT6_1_1_CHARTS_CLEAN:
			return {
				...state,
				prepayment_6_1_1_charts: null,
				error: null,
				loading: false
			};
		case GET_CHARTS9_CLEAN:
			return {
				...state,
				charts9: null,
				error: null,
				loading: false
			};
		case GET_CHASHFLOW2CHARTS_SUCCESS:
			return {
				...state,
				chashflow2charts: action.payload,
				loading: false
			};
		case GET_CHASHFLOW2CHARTS_CLEAN:
			return {
				...state,
				chashflow2charts: null,
				error: null,
				loading: false
			};
		case GET_CHARTS3_3_SUCCESS:
			return {
				...state,
				charts3_3: action.payload,
				loading: false
			};
		case GET_CHARTS6_2_1_SUCCESS:
			return {
				...state,
				charts6_2_1: action.payload,
				loading: false,
				segment6: {}
			};
		case GET_CHARTS3_3_CLEAN:
			return {
				...state,
				charts3_3: null,
				error: null,
				loading: false
			};
		case GET_CHARTS6_2_1_CLEAN:
			return {
				...state,
				charts6_2_1: null,
				error: null,
				loading: false
			};
		case GET_FPNA4_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios4: action.payload
			};
		case UPDATE_FPNA4_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case START_FPNA_TIMER:
			return {
				...state,
				status1: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_FPNA_TIMER:
			if (state.minutes != 0 && state.seconds != 0) {
				return {
					...state,
					status1: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes != 0 && state.seconds == 0) {
				return {
					...state,
					status1: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes == 0 && state.seconds != 0) {
				return {
					...state,
					status1: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return {
					...state,
					minutes: 100,
					seconds: 0,
					status1: 'stopped'
				};
			}
		case START_FPNA3_TIMER:
			return {
				...state,
				status3: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TICK_FPNA3_TIMER:
			if (state.minutes != 0 && state.seconds != 0) {
				return {
					...state,
					status3: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes != 0 && state.seconds == 0) {
				return {
					...state,
					status3: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes == 0 && state.seconds != 0) {
				return {
					...state,
					status3: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return {
					...state,
					minutes: 100,
					seconds: 0,
					status3: 'stopped'
				};
			}
		case START_FPNA4_TIMER:
			return {
				...state,
				status4: 'pending',
				seconds: state.seconds,
				minutes: state.minutes
			};
		case TASK_PROGRESS_FPNA4:
			return {
				...state,
				taskProgress4: action.payload
			};
		case TICK_FPNA4_TIMER:
			if (state.minutes != 0 && state.seconds != 0) {
				return {
					...state,
					status4: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else if (state.minutes != 0 && state.seconds == 0) {
				return {
					...state,
					status4: 'pending',
					seconds: 55,
					minutes: state.minutes - 1
				};
			} else if (state.minutes == 0 && state.seconds != 0) {
				return {
					...state,
					status4: 'pending',
					seconds: state.seconds - 5,
					minutes: state.minutes
				};
			} else {
				return {
					...state,
					minutes: 100,
					seconds: 0,
					status4: 'stopped'
				};
			}
		case TASK_PROGRESS_FPNA5:
			return {
				...state,
				taskProgress5: action.payload
			};
		case TASK_PROGRESS_FPNA6:
			return {
				...state,
				taskProgress6: action.payload
			};
		case TASK_PROGRESS_FPNA9:
			return {
				...state,
				taskProgress9: action.payload
			};
		case TASK_PROGRESS_FPNA0:
			return {
				...state,
				taskProgress0: action.payload
			};

		case GET_FPNA5_TABLES_SUCCESS:
			return {
				...state,
				tables5: { ...state.tables5, ...action.payload },
				loading: false
			};
		case GET_FPNA6_TABLES_SUCCESS:
			return {
				...state,
				tables6: { ...state.tables6, ...action.payload },
				loading: false
			};
		case GET_FPNA9_TABLES_SUCCESS:
			return {
				...state,
				tables9: { ...state.tables9, ...action.payload },
				loading: false
			};
		case GET_FPNA0_TABLES_SUCCESS:
			return {
				...state,
				tables0: { ...state.tables0, ...action.payload },
				loading: false
			};
		case GET_FPNA5_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios5: action.payload
			};
		case GET_FPNA6_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios6: action.payload
			};
		case GET_FPNA9_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios9: action.payload
			};
		case GET_FPNA0_PORTFOLIOS_SUCCESS:
			return {
				...state,
				portfolios0: action.payload
			};
		case UPDATE_FPNA5_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case UPDATE_FPNA6_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case UPDATE_FPNA9_PORTFOLIOS:
			return {
				...state,
				loading: true
			};
		case UPDATE_FPNA0_PORTFOLIOS:
			return {
				...state,
				loading: true,
				portfolios0: action.payload
			};
		case GET_FPNA5_TABLES_CLEAN:
			return {
				...state,
				tables5: null,
				loading: false,
				error: null,
				calc_time_seconds5: undefined,
				status5: 'STOPPED'
				// portfolios5: action.payload
				// 	? state?.portfolios5?.filter((item) => action.payload.id === item.id)
				// 	: null,
				// scenarios5: null
			};
		case GET_FPNA6_TABLES_CLEAN:
			return {
				...state,
				tables6: null,
				loading: false,
				error: null,
				calc_time_seconds6: undefined,
				status6: 'STOPPED'
			};
		case GET_FPNA9_TABLES_CLEAN:
			return {
				...state,
				tables9: null,
				loading: false,
				error: null,
				calc_time_seconds9: undefined,
				status9: 'STOPPED'
			};
		case GET_FPNA0_TABLES_CLEAN:
			return {
				...state,
				tables0: null,
				loading: false,
				error: null,
				calc_time_seconds0: undefined,
				status0: 'STOPPED'
				// portfolios0: action.payload
				// 	? state?.portfolios0?.filter((item) => action.payload.id === item.id)
				// 	: null,
				// scenarios0: null
			};
		case GET_FPNA5_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios5: action.payload,
				loading: false
			};
		case GET_FPNA6_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios6: action.payload,
				loading: false
			};
		case GET_FPNA9_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios9: action.payload,
				loading: false
			};
		case GET_FPNA0_SCENARIOS_SUCCESS:
			return {
				...state,
				scenarios0: action.payload,
				loading: false
			};
		//asdasdasdasdasd
		case START_FPNA5_TIMER:
			return {
				...state,
				status5: action.payload || 'pending',
				staus5ScenarioID: action.portfolioId,
				status5PortfolioID: state?.portfolios5?.[0]?.id,
				calc_time_seconds5: undefined
			};
		case START_FPNA6_TIMER:
			return {
				...state,
				status6: action.payload || 'pending',
				staus6ScenarioID: action.portfolioId,
				status6PortfolioID: state?.portfolios6?.[0]?.id,
				calc_time_seconds6: undefined
			};
		case START_FPNA9_TIMER:
			return {
				...state,
				status9: action.payload || 'pending',
				staus9ScenarioID: action.portfolioId,
				status9PortfolioID: state?.portfolios9?.[0]?.id,
				calc_time_seconds9: undefined
			};
		case START_FPNA0_TIMER:
			return {
				...state,
				status0: action.payload || 'pending',
				staus0ScenarioID: action.portfolioId,
				status0PortfolioID: state?.portfolios0?.[0]?.id,
				calc_time_seconds0: undefined
			};
		case TICK_FPNA5_TIMER:
			if (action?.payload === undefined) {
				return {
					...state,
					status5: 'pending',
					calc_time_seconds5: undefined
				};
			} else if (
				(state.minutes == 0 && state.seconds == 0) ||
				action?.payload === 'change' ||
				state.status5 === 'change'
			)
				return {
					...state,
					status5: action?.payload
						? ['stopped', 'STOPPED', 'pending', 'PENDING'].includes(
								action?.payload
						  )
							? 'STOPPED'
							: action?.payload
						: 'stopped',
					calc_time_seconds5: undefined
				};
			else
				return {
					...state,
					status5: action?.payload || 'pending',
					calc_time_seconds5: action?.calc_time_seconds
				};
		case TICK_FPNA6_TIMER:
			if (action?.payload === undefined) {
				return {
					...state,
					status6: 'pending',
					calc_time_seconds6: undefined
				};
			} else if (
				(state.minutes == 0 && state.seconds == 0) ||
				action?.payload === 'change' ||
				state.status6 === 'change'
			)
				return {
					...state,
					status6: action?.payload
						? ['stopped', 'STOPPED', 'pending', 'PENDING'].includes(
								action?.payload
						  )
							? 'STOPPED'
							: action?.payload
						: 'stopped',
					calc_time_seconds6: undefined
				};
			else
				return {
					...state,
					status6: action?.payload || 'pending',
					calc_time_seconds6: action?.calc_time_seconds
				};
		case TICK_FPNA9_TIMER:
			if (action?.payload === undefined) {
				return {
					...state,
					status9: 'pending',
					calc_time_seconds9: undefined
				};
			} else if (
				(state.minutes == 0 && state.seconds == 0) ||
				action?.payload === 'change' ||
				state.status9 === 'change'
			)
				return {
					...state,
					status9: action?.payload
						? ['stopped', 'STOPPED', 'pending', 'PENDING'].includes(
								action?.payload
						  )
							? 'STOPPED'
							: action?.payload
						: 'stopped',
					calc_time_seconds9: undefined
				};
			else
				return {
					...state,
					status9: action?.payload || 'pending',
					calc_time_seconds9: action?.calc_time_seconds
				};
		case TICK_FPNA0_TIMER:
			if (action?.payload === undefined) {
				return {
					...state,
					status0: 'pending',
					calc_time_seconds0: undefined
				};
			} else if (
				(state.minutes == 0 && state.seconds == 0) ||
				action?.payload === 'change' ||
				state.status0 === 'change'
			)
				return {
					...state,
					status0: action?.payload
						? ['stopped', 'STOPPED', 'pending', 'PENDING'].includes(
								action?.payload
						  )
							? 'STOPPED'
							: action?.payload
						: 'stopped',
					calc_time_seconds0: undefined
				};
			else
				return {
					...state,
					status0: action?.payload || 'pending',
					calc_time_seconds0: action?.calc_time_seconds
				};
		case STOP_FPNA_TIMER:
			return { ...state, minutes: 4, seconds: 30, status1: action.payload };
		case STOP_FPNA3_TIMER:
			return { ...state, minutes: 4, seconds: 30, status3: action.payload };
		case STOP_FPNA4_TIMER:
			return { ...state, minutes: 4, seconds: 30, status4: action.payload };
		case STOP_FPNA5_TIMER:
			return {
				...state,
				status5: action.payload,
				staus5ScenarioID: null,
				status5PortfolioID: null,
				calc_time_seconds5: undefined
			};
		case STOP_FPNA6_TIMER:
			return {
				...state,
				status6: action.payload,
				staus6ScenarioID: null,
				status6PortfolioID: null,
				calc_time_seconds6: undefined
			};
		case STOP_FPNA9_TIMER:
			return {
				...state,
				status9: action.payload,
				staus9ScenarioID: null,
				status9PortfolioID: null,
				calc_time_seconds9: undefined
			};
		case STOP_FPNA0_TIMER:
			return {
				...state,
				status0: action.payload,
				staus0ScenarioID: null,
				status0PortfolioID: null,
				calc_time_seconds0: undefined
			};
		default:
			return state;
	}
};
export default fpnaReducer;
