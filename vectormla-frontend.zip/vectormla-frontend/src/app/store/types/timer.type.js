export const START_TIMER = 'START_TIMER';
export const TICK_TIMER = 'TICK_TIMER';
export const STOP_TIMER = 'STOP_TIMER';
