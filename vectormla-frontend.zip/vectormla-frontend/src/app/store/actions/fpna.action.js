import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import * as Types from '../types/fpna.type';
import { handleError, notifyUser, downloadFile } from './utils';
import { stopTimer } from './timer.action';

export const getPortfolios = (version, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm${version}/portfolio${
		version.includes('0') ||
		version.includes('2') ||
		version.includes('3') ||
		version.includes('4') ||
		version.includes('5') ||
		version.includes('6') ||
		version.includes('9')
			? '-scenario'
			: ''
	}/`;
	const type =
		version === '0'
			? Types.GET_FPNA0_PORTFOLIOS_SUCCESS
			: version === '2'
			? Types.GET_FPNA3_PORTFOLIOS_SUCCESS
			: version === '3'
			? Types.GET_FPNA_PORTFOLIOS_SUCCESS
			: version === '4'
			? Types.GET_FPNA4_PORTFOLIOS_SUCCESS
			: version === '5'
			? Types.GET_FPNA5_PORTFOLIOS_SUCCESS
			: version === '6'
			? Types.GET_FPNA6_PORTFOLIOS_SUCCESS
			: version === '9'
			? Types.GET_FPNA9_PORTFOLIOS_SUCCESS
			: Types.GET_FPNA2_PORTFOLIOS_SUCCESS;

	try {
		const response = await axios.get(url, {
			headers: {
				Authorization: `Token ${session}`
			}
		});
		const portfolios = response.data?.results;
		dispatch({
			type,
			payload: portfolios
		});
		callback(portfolios);
	} catch (error) {
		const errorType =
			version === '0'
				? Types.GET_FPNA0_PORTFOLIOS_FAILED
				: version === '2'
				? Types.GET_FPNA3_PORTFOLIOS_FAILED
				: version === '3'
				? Types.GET_FPNA_PORTFOLIOS_FAILED
				: version === '4'
				? Types.GET_FPNA4_PORTFOLIOS_FAILED
				: version === '5'
				? Types.GET_FPNA5_PORTFOLIOS_FAILED
				: version === '6'
				? Types.GET_FPNA6_PORTFOLIOS_FAILED
				: version === '9'
				? Types.GET_FPNA9_PORTFOLIOS_FAILED
				: Types.GET_FPNA2_PORTFOLIOS_FAILED;
		handleError(error, errorType, dispatch);
	}
};

export const getPortfolioDetails =
	(version, model, type, query = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm${version}/portfolio/${model}/${type}/${query}`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type:
						version === '0'
							? Types.GET_FPNA0_TABLES_SUCCESS
							: version === '2'
							? Types.GET_FPNA3_TABLES_SUCCESS
							: version === '3'
							? Types.GET_FPNA_TABLES_SUCCESS
							: version === '4'
							? Types.GET_FPNA4_TABLES_SUCCESS
							: version === '5'
							? Types.GET_FPNA5_TABLES_SUCCESS
							: version === '6'
							? Types.GET_FPNA6_TABLES_SUCCESS
							: version === '9'
							? Types.GET_FPNA9_TABLES_SUCCESS
							: Types.GET_FPNA2_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					err,
					version === '0'
						? Types.GET_FPNA0_TABLES_FAILED
						: version === '2'
						? Types.GET_FPNA3_TABLES_FAILED
						: version === '3'
						? Types.GET_FPNA_TABLES_FAILED
						: version === '5'
						? Types.GET_FPNA5_TABLES_FAILED
						: version === '6'
						? Types.GET_FPNA6_TABLES_FAILED
						: version === '9'
						? Types.GET_FPNA9_TABLES_FAILED
						: Types.GET_FPNA2_TABLES_FAILED,
					dispatch
				);
			});
	};

export const createPortfolio =
	(version, name, company_id, data, callback, modelName) =>
	async (dispatch) => {
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		dispatch({
			type:
				version === '0'
					? Types.UPDATE_FPNA0_PORTFOLIOS
					: version === '2'
					? Types.UPDATE_FPNA3_PORTFOLIOS
					: version === '3'
					? Types.UPDATE_FPNA_PORTFOLIOS
					: version === '4'
					? Types.UPDATE_FPNA4_PORTFOLIOS
					: version === '5'
					? Types.UPDATE_FPNA5_PORTFOLIOS
					: version === '6'
					? Types.UPDATE_FPNA6_PORTFOLIOS
					: version === '9'
					? Types.UPDATE_FPNA9_PORTFOLIOS
					: Types.UPDATE_FPNA2_PORTFOLIOS
		});
		const session = localStorage.getItem('user');
		return axios
			.post(
				`${API}cfm${version}/portfolio${
					version.includes('0') ||
					version.includes('2') ||
					version.includes('3') ||
					version.includes('4') ||
					version.includes('5') ||
					version.includes('6') ||
					version.includes('9')
						? '-scenario'
						: ''
				}/?name=${name}&company_id=${company_id}`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				if (version === '') notifyUser('Portfolio is created successfully!');
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				if (version === '0') {
					dispatch(stopTimer('cfm0'));
				} else if (version === '2') {
					dispatch(stopTimer('cfm2'));
				} else if (version === '3') {
					dispatch(stopTimer('cfm3'));
				} else if (version === '4') {
					dispatch(stopTimer('cfm4'));
				} else if (version === '5') {
					dispatch(stopTimer('cfm5'));
				} else if (version === '6') {
					dispatch(stopTimer('cfm6'));
				} else if (version === '9') {
					dispatch(stopTimer('cfm9'));
				} else {
					dispatch(stopTimer('cfm'));
				}
				handleError(err, null, dispatch);
			});
	};

export const updatePortfolio =
	(version, model, data, callback, modelName) => async (dispatch) => {
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		dispatch({
			type:
				version === '0'
					? Types.UPDATE_FPNA0_PORTFOLIOS
					: version === '2'
					? Types.UPDATE_FPNA3_PORTFOLIOS
					: version === '3'
					? Types.UPDATE_FPNA_PORTFOLIOS
					: version === '4'
					? Types.UPDATE_FPNA4_PORTFOLIOS
					: version === '5'
					? Types.UPDATE_FPNA5_PORTFOLIOS
					: version === '6'
					? Types.UPDATE_FPNA6_PORTFOLIOS
					: version === '9'
					? Types.UPDATE_FPNA9_PORTFOLIOS
					: Types.UPDATE_FPNA2_PORTFOLIOS
		});
		const session = localStorage.getItem('user');
		return axios
			.put(
				`${API}cfm${version}/portfolio${
					version.includes('0') ||
					version.includes('2') ||
					version.includes('3') ||
					version.includes('4') ||
					version.includes('5') ||
					version.includes('6') ||
					version.includes('9')
						? '-scenario'
						: ''
				}/${model}/`,
				data,
				{
					headers: {
						Authorization: `Token ${session}`
					}
				}
			)
			.then((res) => {
				if (version === '' || version === '2')
					notifyUser('Portfolio is edited successfully!');
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				if (version === '0') {
					dispatch(stopTimer('cfm0'));
				}
				if (version === '2') {
					dispatch(stopTimer('cfm2'));
				}
				if (version === '3') {
					dispatch(stopTimer('cfm3'));
				}
				if (version === '4') {
					dispatch(stopTimer('cfm4'));
				}
				if (version === '5') {
					dispatch(stopTimer('cfm5'));
				}
				if (version === '6') {
					dispatch(stopTimer('cfm6'));
				}
				if (version === '6') {
					dispatch(stopTimer('cfm6'));
				}
				if (version === '9') {
					dispatch(stopTimer('cfm9'));
				} else {
					dispatch(stopTimer('cfm'));
				}
				handleError(err);
			});
	};

export const deletePortfolio =
	(version, model, callback) => async (dispatch) => {
		dispatch({
			type:
				version === '0'
					? Types.UPDATE_FPNA0_PORTFOLIOS
					: version === '2'
					? Types.UPDATE_FPNA3_PORTFOLIOS
					: version === '3'
					? Types.UPDATE_FPNA_PORTFOLIOS
					: version === '4'
					? Types.UPDATE_FPNA4_PORTFOLIOS
					: version === '5'
					? Types.UPDATE_FPNA5_PORTFOLIOS
					: version === '6'
					? Types.UPDATE_FPNA6_PORTFOLIOS
					: version === '9'
					? Types.UPDATE_FPNA9_PORTFOLIOS
					: Types.UPDATE_FPNA2_PORTFOLIOS
		});
		const session = localStorage.getItem('user');
		let url = `${API}cfm${version}/portfolio${
			version.includes('0') ||
			version.includes('2') ||
			version.includes('3') ||
			version.includes('4') ||
			version.includes('5') ||
			version.includes('6') ||
			version.includes('9')
				? '-scenario'
				: ''
		}/${model}/`;
		return axios
			.delete(url, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				handleError(err);
			});
	};

export const getPortfolioScenarios =
	(version, model, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		let url = `${API}cfm${version}/portfolio-scenario/${model}/portfolio/`;
		return axios
			.get(url, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type:
						version === '0'
							? Types.GET_FPNA0_SCENARIOS_SUCCESS
							: version === '2'
							? Types.GET_FPNA3_SCENARIOS_SUCCESS
							: version === '3'
							? Types.GET_FPNA_SCENARIOS_SUCCESS
							: version === '4'
							? Types.GET_FPNA4_SCENARIOS_SUCCESS
							: version === '5'
							? Types.GET_FPNA5_SCENARIOS_SUCCESS
							: version === '6'
							? Types.GET_FPNA6_SCENARIOS_SUCCESS
							: version === '9'
							? Types.GET_FPNA9_SCENARIOS_SUCCESS
							: Types.GET_FPNA2_SCENARIOS_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					err,
					version === '0'
						? Types.GET_FPNA0_SCENARIOS_FAILED
						: version === '2'
						? Types.GET_FPNA3_SCENARIOS_FAILED
						: version === '3'
						? Types.GET_FPNA_SCENARIOS_FAILED
						: version === '4'
						? Types.GET_FPNA4_SCENARIOS_FAILED
						: version === '5'
						? Types.GET_FPNA5_SCENARIOS_FAILED
						: version === '6'
						? Types.GET_FPNA6_SCENARIOS_FAILED
						: version === '9'
						? Types.GET_FPNA9_SCENARIOS_FAILED
						: Types.GET_FPNA2_SCENARIOS_FAILED,
					dispatch
				);
			});
	};

export const getSubPortofolios =
	(version, model, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		let url = `${API}cfm${version}/portfolio/${model}/${
			['5', '6', '9'].includes(version) ? 'chart_all' : 'subportfolio'
		}/`;
		return axios
			.get(url, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type:
						version === '2'
							? Types.GET_FPNA3_SUBPORTOFOLIOS_SUCCESS
							: version === '4'
							? Types.GET_FPNA4_SUBPORTOFOLIOS_SUCCESS
							: version === '6'
							? Types.GET_FPNA6_CHARTS_SUCCESS
							: version === '9'
							? Types.GET_FPNA9_CHARTS_SUCCESS
							: version === '5'
							? Types.GET_FPNA5_CHARTS_SUCCESS
							: Types.GET_FPNA_SUBPORTOFOLIOS_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					// err,
					version !== '6' && version !== '9' ? err : '',
					version === '2'
						? Types.GET_FPNA3_SUBPORTOFOLIOS_FAILED
						: version === '4'
						? Types.GET_FPNA4_SUBPORTOFOLIOS_FAILED
						: version === '6'
						? Types.GET_FPNA6_CHARTS_FAILED
						: version === '9'
						? Types.GET_FPNA9_CHARTS_FAILED
						: version === '5'
						? Types.GET_FPNA5_CHARTS_FAILED
						: Types.GET_FPNA_SUBPORTOFOLIOS_FAILED,
					dispatch
				);
			});
	};

export const getSegment = (version, model, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm${version}/portfolio/${model?.id}/segment/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type:
					version === '2'
						? Types.GET_FPNA3_SEGMENT_SUCCESS
						: version === '4'
						? Types.GET_FPNA4_SEGMENT_SUCCESS
						: version === '6'
						? Types.GET_FPNA6_SEGMENT_SUCCESS
						: version === '9'
						? Types.GET_FPNA9_SEGMENT_SUCCESS
						: version === '5'
						? Types.GET_FPNA5_SEGMENT_SUCCESS
						: Types.GET_FPNA_SEGMENT_SUCCESS,
				payload: {
					[model?.name]: res.data?.results
				}
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(
				err,
				version === '2'
					? Types.GET_FPNA3_SEGMENT_FAILED
					: version === '4'
					? Types.GET_FPNA4_SEGMENT_FAILED
					: version === '6'
					? Types.GET_FPNA6_SEGMENT_FAILED
					: version === '9'
					? Types.GET_FPNA9_SEGMENT_FAILED
					: version === '5'
					? Types.GET_FPNA5_SEGMENT_FAILED
					: Types.GET_FPNA_SEGMENT_FAILED,
				dispatch
			);
		});
};

export const updateSegmentReq =
	(version, segmendID, data, callback) => async () => {
		const session = localStorage.getItem('user');
		return axios
			.put(`${API}cfm${version}/portfolio-segment/${segmendID}/`, data, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				handleError(err);
			});
	};

export const runCalculate = (version, subportfolioID, callback) => async () => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm${version}/portfolio/${subportfolioID}/consolidate_sub/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			callback(res.data);
		})
		.catch((err) => {
			handleError(err);
		});
};

export const getPdfUrl = async (version, file, setPdfUrl) => {
	const session = localStorage.getItem('user');
	try {
		const response = await axios.get(
			`${API}cfm${version}/report_files/?file=${file}`,
			{
				headers: { Authorization: `Token ${session}` },
				responseType: 'blob' // If the server sends the PDF file directly
			}
		);
		const pdfBlob = response.data;
		const pdfUrl = URL.createObjectURL(pdfBlob);
		setPdfUrl(pdfUrl);
	} catch (err) {
		console.error('Error fetching PDF', err);
	}
};
export const downloadDataFile = (version, porfolioId) => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm${version}/portfolio${
		version.includes('0') ||
		version.includes('2') ||
		version.includes('3') ||
		version.includes('4') ||
		version.includes('5') ||
		version.includes('6') ||
		version.includes('9')
			? '-scenario'
			: ''
	}/${porfolioId || 0}/download-inputfile?token=${session}`;
	downloadFile(url);
};

export const downloadCustomReports = (version, porfolioId) => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm${version}/portfolio-scenario/${porfolioId}/report?token=${session}`;
	downloadFile(url);
};
export const downloadFPNATemplate = (version) => async () => {
	const session = localStorage.getItem('user');
	let url;
	if (['5', '6', '0'].includes(version)) {
		url = `${API}cfm${version}/template/?token=${session}`;
	} else {
		url = `${API}cfm${version}/portfolio-scenario-download-template?token=${session}`;
	}
	downloadFile(url);
};
export const downloadFPNA2Template = () => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm/template?token=${session}`;
	downloadFile(url);
};
export const downloadFPNA3Template = () => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm2/template-multiple/?token=${session}`;
	downloadFile(url);
};
export const getPortfolioSampleV4 = (modal, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm4/portfolio-scenario/${modal}/tables1/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_FPNA4_TABLES_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_FPNA4_TABLES_FAILED, dispatch);
		});
};

// second charts in fpna3.1.4
export const getPortfolioCharts = (modal, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm4/portfolio-scenario/${modal}/charts1/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_FPNA4_SECOND_CHARTS_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_FPNA4_SECOND_CHARTS_FAILED, dispatch);
		});
};

export const getCharts3 =
	(modal, type = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm2/portfolio-scenario/${modal}/charts/${type}`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_CHARTS3_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_CHARTS3_FAILED, dispatch);
			});
	};

export const getCashFlow2Charts = (modal, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm2/portfolio/${modal}/amortization-charts/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CHASHFLOW2CHARTS_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CHASHFLOW2CHARTS_FAILED, dispatch);
		});
};

export const getCharts3_2 = (modal, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm2/portfolio/${modal}/default-vintage/charts/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CHARTS3_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CHARTS3_FAILED, dispatch);
		});
};

export const getCharts3_3 = (modal, callback) => async (dispatch) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}cfm2/portfolio/${modal}/default-vintage-summary/charts/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => {
			dispatch({
				type: Types.GET_CHARTS3_3_SUCCESS,
				payload: res.data
			});
			callback(res.data);
		})
		.catch((err) => {
			handleError(err, Types.GET_CHARTS3_3_FAILED, dispatch);
		});
};

export const getCreditRisk6_2_1Charts =
	(modal, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm6/portfolio/${modal}/vintage_charts/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_CHARTS6_2_1_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_CHARTS6_2_1_FAILED, dispatch);
			});
	};

export const getPrepayment6_1_1Charts =
	(modal, callback) => async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm6/portfolio/${modal}/prepayment_charts/`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_PREPAYMENT6_1_1_CHARTS_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					err,
					Types.GET_FPNA6_1_1_PREPAYMENT_CHARTS_FAILED,
					dispatch
				);
			});
	};

export const downloadFPNA4Template = () => async () => {
	const session = localStorage.getItem('user');
	let url = `${API}cfm4/template-multiple/?token=${session}`;
	downloadFile(url);
};

export const getScenarioDetails =
	(version, model, type, query = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm${version}/portfolio/${model}/${type}/${query}`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type:
						version === '0'
							? Types.GET_FPNA0_TABLES_SUCCESS
							: version === '2'
							? Types.GET_FPNA3_TABLES_SUCCESS
							: version === '3'
							? Types.GET_FPNA_TABLES_SUCCESS
							: version === '4'
							? Types.GET_FPNA4_TABLES_SUCCESS
							: version === '5'
							? Types.GET_FPNA5_TABLES_SUCCESS
							: version === '6'
							? Types.GET_FPNA6_TABLES_SUCCESS
							: version === '9'
							? Types.GET_FPNA9_TABLES_SUCCESS
							: Types.GET_FPNA2_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					err,
					version === '0'
						? Types.GET_FPNA0_TABLES_FAILED
						: version === '2'
						? Types.GET_FPNA3_TABLES_FAILED
						: version === '3'
						? Types.GET_FPNA_TABLES_FAILED
						: version === '4'
						? Types.GET_FPNA4_TABLES_FAILED
						: version === '5'
						? Types.GET_FPNA5_TABLES_FAILED
						: version === '6'
						? Types.GET_FPNA6_TABLES_FAILED
						: version === '9'
						? Types.GET_FPNA9_TABLES_FAILED
						: Types.GET_FPNA2_TABLES_FAILED,
					dispatch
				);
			});
	};
export const getCharts4 =
	(modal, type = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm4/portfolio-scenario/${modal}/charts/${type}`, {
				headers: { Authorization: `Token ${session}` }
			})
			.then((res) => {
				dispatch({
					type: Types.GET_FPNA4_CHARTS_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) =>
				handleError(err, Types.GET_FPNA4_CHARTS_FAILED, dispatch)
			);
	};
export const getCharts5 =
	(modal, type = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm5/portfolio/${modal}/chart_all/${type}`, {
				headers: { Authorization: `Token ${session}` }
			})
			.then((res) => {
				dispatch({
					type: Types.GET_FPNA5_CHARTS_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) =>
				handleError(err, Types.GET_FPNA5_CHARTS_FAILED, dispatch)
			);
	};

export const getCalcStatus = (module, model, callback) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}${module}/${model}/calculate/status/`, {
			headers: { Authorization: `Token ${session}` }
		})
		.then((res) => callback(res.data))
		.catch(() => {});
};

export const getPipelineGrowthAssumptionData = (model, id) => async () => {
	const session = localStorage.getItem('user');
	return axios
		.get(
			`${API}cfm${model}/portfolio/${id}/loanmodel/?orient=split&download=1&grade_number=2`,
			{
				responseType: 'blob',
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => {
			const url = window.URL.createObjectURL(res.data);
			const filename = res.headers['content-disposition'].split('filename=')[1];
			downloadFile(url, filename);
		});
};
export const getLoanDataSummaryData = (model, id) => async () => {
	const session = localStorage.getItem('user');
	return axios
		.get(
			`${API}cfm${model}/portfolio/${id}/loanmodel/?orient=split&download=1`,
			{
				responseType: 'blob',
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => {
			const url = window.URL.createObjectURL(res.data);
			const filename = res.headers['content-disposition'].split('filename=')[1];
			downloadFile(url, filename);
		});
};
export const downloadFpna3CustomReports = (porfolioId) => async () => {
	let url = `${API}cfm2/portfolio/${porfolioId}/consolidated_summary_report/`;
	downloadFile(url);
};

export const getScenarioDetailsOutputBreakdown =
	(model, type, query = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm2/portfolio/${model}/${type}/${query}`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type: Types.GET_FPNA3_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(err, Types.GET_FPNA3_TABLES_FAILED, dispatch);
			});
	};

export const getCustomisedDownloadData =
	(model, id, query1 = '', query2 = '', query3 = '') =>
	async () => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm${model}/portfolio/${id}/${query1}${query2}${query3}`, {
				responseType: 'blob',
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				const url = window.URL.createObjectURL(res.data);
				const filename =
					res.headers['content-disposition'].split('filename=')[1];
				downloadFile(url, filename);
			});
	};

export const createPortfolioFPNA =
	(version, name, company_id, data, callback, modelName) =>
	async (dispatch) => {
		if (modelName)
			dispatch({
				type: `TICK_${modelName.toUpperCase()}_TIMER`
			});
		dispatch({
			type:
				version === '0'
					? Types.UPDATE_FPNA0_PORTFOLIOS
					: version === '2'
					? Types.UPDATE_FPNA3_PORTFOLIOS
					: version === '3'
					? Types.UPDATE_FPNA_PORTFOLIOS
					: version === '4'
					? Types.UPDATE_FPNA4_PORTFOLIOS
					: version === '5'
					? Types.UPDATE_FPNA5_PORTFOLIOS
					: version === '6'
					? Types.UPDATE_FPNA6_PORTFOLIOS
					: version === '9'
					? Types.UPDATE_FPNA9_PORTFOLIOS
					: Types.UPDATE_FPNA2_PORTFOLIOS
		});
		const session = localStorage.getItem('user');
		let url = `${API}cfm${version}/portfolio-scenario/?company_id=${company_id}&name=${name}`;
		return axios
			.post(url, data, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				callback(res.data);
			})
			.catch((err) => {
				dispatch({ type: Types.STOP_LOADING, payload: err });
				dispatch(
					version === '0'
						? stopTimer('cfm0')
						: version === '2'
						? stopTimer('cfm2')
						: version === '3'
						? stopTimer('cfm3')
						: version === '4'
						? stopTimer('cfm4')
						: version === '5'
						? stopTimer('cfm5')
						: version === '6'
						? stopTimer('cfm6')
						: version === '9'
						? stopTimer('cfm9')
						: stopTimer('cfm')
				);
				handleError(err, null, dispatch);
			});
	};

export const getScenarioFPNADetails =
	(version, model, type = '', callback) =>
	async (dispatch) => {
		const session = localStorage.getItem('user');
		return axios
			.get(`${API}cfm${version}/portfolio/${model}/${type}`, {
				headers: {
					Authorization: `Token ${session}`
				}
			})
			.then((res) => {
				dispatch({
					type:
						version === '0'
							? Types.GET_FPNA0_TABLES_SUCCESS
							: version === '2'
							? Types.GET_FPNA3_TABLES_SUCCESS
							: version === '3'
							? Types.GET_FPNA_TABLES_SUCCESS
							: version === '4'
							? Types.GET_FPNA4_TABLES_SUCCESS
							: version === '5'
							? Types.GET_FPNA5_TABLES_SUCCESS
							: version === '6'
							? Types.GET_FPNA6_TABLES_SUCCESS
							: version === '9'
							? Types.GET_FPNA9_TABLES_SUCCESS
							: Types.GET_FPNA2_TABLES_SUCCESS,
					payload: res.data
				});
				callback(res.data);
			})
			.catch((err) => {
				handleError(
					err,
					version === '0'
						? Types.GET_FPNA0_TABLES_FAILED
						: version === '2'
						? Types.GET_FPNA3_TABLES_FAILED
						: version === '3'
						? Types.GET_FPNA_TABLES_FAILED
						: version === '4'
						? Types.GET_FPNA4_TABLES_FAILED
						: version === '5'
						? Types.GET_FPNA5_TABLES_FAILED
						: version === '6'
						? Types.GET_FPNA6_TABLES_FAILED
						: version === '9'
						? Types.GET_FPNA9_TABLES_FAILED
						: Types.GET_FPNA2_TABLES_FAILED,
					dispatch
				);
			});
	};

export const downloadFpnaCustomReports =
	(model, porfolioId, type = 'report_loandata') =>
	async () => {
		let url = `${API}cfm${model}/portfolio/${porfolioId}/${type}/`;
		downloadFile(url);
	};
