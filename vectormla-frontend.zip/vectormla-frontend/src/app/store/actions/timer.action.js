import axios from 'axios';
import { API } from '../../../config/EnvironmentConfig';
import { toast } from 'react-toastify';
import {
	START_FPNA_TIMER,
	STOP_FPNA_TIMER,
	TICK_FPNA_TIMER,
	START_FPNA3_TIMER,
	STOP_FPNA3_TIMER,
	TICK_FPNA3_TIMER,
	TASK_PROGRESS_FPNA3,
	START_FPNA4_TIMER,
	STOP_FPNA4_TIMER,
	TICK_FPNA4_TIMER,
	TASK_PROGRESS_FPNA4,
	START_FPNA5_TIMER,
	STOP_FPNA5_TIMER,
	TICK_FPNA5_TIMER,
	TASK_PROGRESS_FPNA5,
	START_FPNA6_TIMER,
	STOP_FPNA6_TIMER,
	TICK_FPNA6_TIMER,
	TASK_PROGRESS_FPNA6,
	START_FPNA9_TIMER,
	STOP_FPNA9_TIMER,
	TICK_FPNA9_TIMER,
	TASK_PROGRESS_FPNA9,
	START_FPNA0_TIMER,
	STOP_FPNA0_TIMER,
	TICK_FPNA0_TIMER,
	TASK_PROGRESS_FPNA0
} from '../types/fpna.type';
import {
	START_CASHFLOW_TIMER,
	STOP_CASHFLOW_TIMER,
	TICK_CASHFLOW_TIMER
} from '../types/cashflow.type';
import {
	START_PREPAYMENT_TIMER,
	STOP_PREPAYMENT_TIMER,
	TICK_PREPAYMENT_TIMER
} from '../types/prepayment.type';
import {
	START_DEFAULT_TIMER,
	STOP_DEFAULT_TIMER,
	TICK_DEFAULT_TIMER
} from '../types/default.type';
import {
	START_CREDIT_RISK_2_TIMER,
	STOP_CREDIT_RISK_2_TIMER,
	TICK_CREDIT_RISK_2_TIMER
} from '../types/credit.type';
let timer = null;

const reducerTypes = {
	cfm0: {
		start: START_FPNA0_TIMER,
		stop: STOP_FPNA0_TIMER,
		tick: TICK_FPNA0_TIMER,
		taskProgress: TASK_PROGRESS_FPNA0,
		startTime: 2
	},
	cfm3: {
		start: START_FPNA_TIMER,
		stop: STOP_FPNA_TIMER,
		tick: TICK_FPNA_TIMER,
		// taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 24
	},
	treasury: {
		start: START_CASHFLOW_TIMER,
		stop: STOP_CASHFLOW_TIMER,
		tick: TICK_CASHFLOW_TIMER,
		// taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 4
	},
	cfm2: {
		start: START_FPNA3_TIMER,
		stop: STOP_FPNA3_TIMER,
		tick: TICK_FPNA3_TIMER,
		taskProgress: TASK_PROGRESS_FPNA3,
		startTime: 2
	},
	cfm4: {
		start: START_FPNA4_TIMER,
		stop: STOP_FPNA4_TIMER,
		tick: TICK_FPNA4_TIMER,
		taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 2
	},
	cfm5: {
		start: START_FPNA5_TIMER,
		stop: STOP_FPNA5_TIMER,
		tick: TICK_FPNA5_TIMER,
		taskProgress: TASK_PROGRESS_FPNA5,
		startTime: 2
	},
	cfm6: {
		start: START_FPNA6_TIMER,
		stop: STOP_FPNA6_TIMER,
		tick: TICK_FPNA6_TIMER,
		taskProgress: TASK_PROGRESS_FPNA6,
		startTime: 2
	},
	cfm9: {
		start: START_FPNA9_TIMER,
		stop: STOP_FPNA9_TIMER,
		tick: TICK_FPNA9_TIMER,
		taskProgress: TASK_PROGRESS_FPNA9,
		startTime: 2
	},
	prepayment: {
		start: START_PREPAYMENT_TIMER,
		stop: STOP_PREPAYMENT_TIMER,
		tick: TICK_PREPAYMENT_TIMER,
		// taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 2
	},
	default: {
		start: START_DEFAULT_TIMER,
		stop: STOP_DEFAULT_TIMER,
		tick: TICK_DEFAULT_TIMER,
		// taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 2
	},
	credit2: {
		start: START_CREDIT_RISK_2_TIMER,
		stop: STOP_CREDIT_RISK_2_TIMER,
		tick: TICK_CREDIT_RISK_2_TIMER,
		// taskProgress: TASK_PROGRESS_FPNA4,
		startTime: 24
	}
};

export const startTimer =
	(path, portfolioId, version = '-scenario') =>
	(dispatch) => {
		let time = 0;
		const session = localStorage.getItem('user');
		clearInterval(timer);
		dispatch({ type: reducerTypes[path].start, portfolioId: portfolioId });
		dispatch({ type: reducerTypes[path].tick });

		timer = setInterval(() => {
			if (
				time > 0 &&
				time < reducerTypes[path].startTime &&
				path !== 'cfm5' &&
				path !== 'cfm0' &&
				path !== 'cfm9' &&
				path !== 'cfm6'
			) {
				dispatch({ type: reducerTypes[path].tick });
			} else {
				axios
					.get(
						`${API}${path}/${
							path === 'prepayment'
								? 'prepay-model'
								: path === 'default'
								? 'default-model'
								: path === 'credit2'
								? 'creditrisk-model'
								: path === 'cfm4'
								? 'portfolio'
								: 'portfolio' + version
						}/${portfolioId}/calculate/status/`,
						{
							headers: {
								Authorization: `Token ${session}`
							}
						}
					)
					.then((res) => {
						if (
							res.data.calc_status == 'PENDING' ||
							(res.data.calc_status === 'NOT STARTED' &&
								(res.data.task_state === 'PENDING' ||
									res.data.task_state === 'NOT STARTED'))
						) {
							dispatch({
								type: reducerTypes[path].tick,
								payload: res.data.task_state,
								calc_time_seconds: res.data.calc_time_seconds
							});
						} else dispatch(stopTimer(path, res.data.calc_status));
						reducerTypes[path]?.taskProgress &&
							dispatch({
								type: reducerTypes[path]?.taskProgress,
								payload: res.data.calc_progress
							});
						if (res.data.task_state === 'FAILURE') {
							toast.error('Please upload the correct file');
							dispatch(stopTimer(path, res.data.calc_status));
						}
					});
			}
			time++;
		}, 1000);
	};

export const stopTimer =
	(path, status = 'STOPPED', callBack) =>
	(dispatch) => {
		clearInterval(timer);
		dispatch({
			type: reducerTypes[path].stop,
			payload: status
		});
		callBack && callBack();
	};
