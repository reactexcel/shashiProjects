// FPNA 3.1.2
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider } from '@material-ui/core';
import { useStyles } from './cashFlowStyles';
import Portfolio from '../components/portfolio/Portfolio';
import Checkboxes from './SelectScenarioChart/SelectScenarioChart';
import SelectChart from './SelectCharts/SelectCharts';
import Chart from '../components/Chart/Chart';
import MainTable from '../components/Table/MainTable';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import {
	getPortfolios,
	createPortfolio,
	deletePortfolio,
	updatePortfolio,
	downloadCashflowTemplate,
	getPortfolioScenarios,
	getPortfolioDetails,
	getChartsDetails,
	downloadCashflowData
} from '../store/actions/cashflow.action';
import headers from './tableHeader';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import { LibHeaders, VectorHeaders } from './liabilityTableFileds';
import { startTimer } from '../store/actions/timer.action';
import { GET_CASHFLOW_TABLES_CLEAN } from '../store/types/cashflow.type';

const Cash = ({ collapsed }) => {
	const defaultChartsCashCheck = [
		'Ending Balance',
		'Actual Amortization',
		'Actual Interest'
		// 'Principal Recovery'
	];
	const defaultChartsCash = [
		'Ending Balance',
		'Actual Amortization',
		'Actual Interest',
		'Principal Recovery',
		'Senior Loan EOP Balance',
		'Cumulative Default Percent'
	];

	const dispatch = useDispatch();
	const user = useSelector((state) => state.auth.user);
	const { tables, scenarios, portfolios, loading, seconds, minutes, status } =
		useSelector((state) => state.cashflow);
	const classes = useStyles();
	const { ref: cashFlowRef, height: cashFlowHeight } = useComponentSize();
	const [selectedPortfolio, setSelectedPortolio] = useState(null);
	const [chartVisible, setChartVisible] = useState(false);
	const [dataTable, setDataTable] = useState([
		'Actual Amortization',
		'Liability Table',
		'Vectors',
		'Analytics Cash Flow',
		'Analytics Summary',
		'Risk Convexity'
	]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedScenarios, setSelectedScenarios] = useState([]);
	const [state, setState] = useState({
		openChart: false,
		portfolio: false,
		openChartsCash: defaultChartsCashCheck
	});
	const [chartsData, setChartsData] = useState([]);
	//map for tables of cashflow
	useEffect(() => {
		if (!portfolios && user?.allowed_pages?.includes(1)) fetchPortfolio();
		if (portfolios && !selectedPortfolio) setSelectedPortolio(portfolios[0]);
		if (scenarios && !selectedScenario) setSelectedScenario(scenarios[0]);
		if (scenarios && !selectedScenarios) setSelectedScenarios([scenarios[0]]);
	}, [portfolios, user]);

	// render charts on change selected Portofolio
	useEffect(() => {
		selectedPortfolio?.id && fetchCharts(selectedPortfolio?.id);
	}, [selectedPortfolio]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible(true);
		} else if (collapsed === 0 && chartVisible) {
			setChartVisible(false);
		}
	}, [collapsed]);

	useEffect(() => {
		if (status === 'SUCCESS') {
			selectedScenario[0] && updateTables(selectedScenario[0]?.id);
			selectedPortfolio?.id && fetchCharts(selectedPortfolio?.id);
		}
	}, [status]);

	useEffect(() => {
		if (tables?.charts) {
			let chart2 = [];
			let chart3 = [];
			let chart7 = [];
			let chart11 = [];
			let chart12 = [];
			let chart13 = [];

			tables?.charts?.forEach((chart) => {
				if (chart.charts) {
					let tempChart2 = [];
					let tempChart3 = [];
					let tempChart7 = [];
					let tempChart11 = [];
					let tempChart12 = [];
					let tempChart13 = [];
					chart.charts['Date Index'].forEach((val1, i) => {
						tempChart2.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Senior Loan EOP Balance'][i].replace(/,/g, '')
							)
						});
						tempChart3.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Cumulative Default Percent'][i].replace(/,/g, '')
							)
						});
						tempChart7.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Ending Balance'][i].replace(/,/g, '')
							)
						});
						tempChart11.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Actual Amortization'][i].replace(/,/g, '')
							)
						});
						tempChart12.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Actual Interest'][i].replace(/,/g, '')
							)
						});
						tempChart13.push({
							'Date Index': val1,
							[`${chart.scenario}`]: parseFloat(
								chart.charts['Principal Recovery'][i].replace(/,/g, '')
							)
						});
					});

					chart2.push(tempChart2);
					chart3.push(tempChart3);
					chart7.push(tempChart7);
					chart11.push(tempChart11);
					chart12.push(tempChart12);
					chart13.push(tempChart13);
				}
			});

			let updatedCharts = [
				{
					ch: chart7,
					xIndex: 'Date Index',
					yIndex: 'Ending Balance',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart11,
					xIndex: 'Date Index',
					yIndex: 'Actual Amortization',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart12,
					xIndex: 'Date Index',
					yIndex: 'Actual Interest',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart13,
					xIndex: 'Date Index',
					yIndex: 'Principal Recovery',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart2,
					xIndex: 'Date Index',
					yIndex: 'Senior Loan EOP Balance',
					xDistance: 390,
					format: 'com'
				},
				{
					ch: chart3,
					xIndex: 'Date Index',
					yIndex: 'Cumulative Default Percent',
					xDistance: 390,
					format: 'per'
				}
			];
			setChartsData(updatedCharts);
		}
	}, [tables]);

	const fetchPortfolio = () => {
		dispatch(
			getPortfolios((res) => {
				setSelectedPortolio(res[0]);
				res[0] && fetchScenarios(res[0].id);
				res[0] && fetchCharts(res[0].id);
			})
		);
	};
	const fetchScenarios = (scenarioGroupId, tableUpdate = true) => {
		dispatch(
			getPortfolioScenarios(scenarioGroupId, (portfolioScenarios) => {
				setSelectedScenario([portfolioScenarios[0]]);
				if (tableUpdate) {
					updateTables(portfolioScenarios[0].id);

					if (!tables)
						dispatch(getPortfolioDetails(portfolioScenarios[0].id, 'tables'));
					if (!tables?.datatape)
						dispatch(
							getPortfolioDetails(portfolioScenarios[0].id, 'data-tape')
						);
				}
			})
		);
	};
	const fetchCharts = (id) => {
		dispatch(getChartsDetails(id));
	};
	const fetchPortfolioDetails = (
		model,
		type = 'tables',
		portfolioExist = false
	) => {
		if (!model || (portfolios?.length === 0 && !portfolioExist)) return;
		dispatch(getPortfolioDetails(model, type));
	};
	const updateTables = (id) => {
		if (!tables) return;
		if (tables.datatape) fetchPortfolioDetails(id, 'data-tape');
		if (tables.Vectors) fetchPortfolioDetails(id, 'tables');
	};
	const handleTableBoxChange = (e, type, table, stateObject) => {
		if (e.length > 0) {
			let arr;
			// compare between to array and return element
			if (e.length > state.openChartsCash.length) {
				arr = e.filter((val) => !state.openChartsCash.includes(val))[0];
				return setState({
					...state,
					openChartsCash: [...state.openChartsCash, arr]
				});
			} else {
				arr = state.openChartsCash.filter((val) => e.includes(val));
				return setState({ ...state, openChartsCash: arr });
			}
		} else {
			let newValName = e.target.name;
			// Table
			if (type === 'table') {
				// if the table is opened close it
				if (table.includes(newValName)) {
					let newDataTable = table.filter(
						(tableName) => tableName !== newValName
					);
					return setDataTable(newDataTable);
				}
				// else open it
				return setDataTable([...table, newValName]);
			} else {
				// if the chart is opened close it
				if (state[stateObject].includes(newValName)) {
					let newChartsData = state[stateObject].filter(
						(chartName) => chartName !== newValName
					);
					return setState({ ...state, [stateObject]: newChartsData });
				}
				// else open it
				return setState({
					...state,
					[stateObject]: [...state[stateObject], newValName]
				});
			}
		}
	};

	const renderTable = (dataMap, checkTable) => {
		return (
			<div>
				{dataMap.map((tableName, index) => (
					<div key={index}>
						<MainTable
							header={checkTable && checkTable[tableName]?.table?.headers}
							data={
								checkTable &&
								(tableName === 'Liability Table' || tableName === 'Vectors'
									? checkTable[tableName]
									: checkTable[tableName]?.table?.rows)
							}
							attributes={
								checkTable && Object.keys(checkTable[tableName]?.table?.rows[0])
							}
							tableName={tableName}
							fetchData={() => {}}
							collapsed={collapsed}
							separator={
								tableName === 'Liability Table'
									? LibHeaders
									: tableName === 'Vectors'
									? VectorHeaders
									: null
							}
							download
							formatType={
								tableName === 'Liability Table' || tableName === 'Vectors'
									? 'split1'
									: 'records'
							}
						/>
					</div>
				))}
			</div>
		);
	};

	const renderChart = (condition, dataMap, conditionReq) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>
				{chartVisible && (
					<div className={classes.cashflow__chart}>
						{condition && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
								style={{ position: 'relative', maxWidth: 1900 }}
							>
								<div
									className={classes.cashflow__chart_check}
									style={{
										position: 'absolute',
										top: -70,
										left: 5,
										zIndex: 999
									}}
								>
									<Checkboxes
										senarioData={scenarios}
										selectedScenario={selectedScenarios}
										setSelectedScenario={setSelectedScenarios}
									/>
								</div>
								<div
									className={classes.cashflow__chart_select}
									style={{
										position: 'absolute',
										top: -70,
										left: 157,
										zIndex: 999
									}}
								>
									<SelectChart
										senarioData={defaultChartsCash}
										selectedScenario={state.openChartsCash}
										setSelectedScenario={handleTableBoxChange}
									/>
								</div>
								{chartsData.length > 0 &&
									dataMap.map((item, index) => {
										return (
											conditionReq.includes(`${item}`) && (
												<Grid
													key={index}
													item
													xs={12}
													sm={12}
													md={4}
													className={classes.container__chart}
												>
													<Chart
														dataT={
															chartsData.find(
																(element) => element.yIndex === item
															).ch
														}
														nameLegend={`${item}`}
														sizeLegend="14px"
														brushID={`${item}`}
														dataX={
															chartsData.find(
																(element) => element.yIndex === item
															).xIndex
														}
														// xDistance={charts.find(element => element.yIndex === item).xDistance}
														format={
															chartsData.find(
																(element) => element.yIndex === item
															).format
														}
														defaultSelect={scenarios && scenarios[0]?.scenario}
														selectedScenario={selectedScenarios}
													/>
												</Grid>
											)
										);
									})}
							</Grid>
						)}
					</div>
				)}
			</div>
		);
	};

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(313)
	)
		return <div></div>;

	return (
		<div ref={cashFlowRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={cashFlowHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'cashflow'}
							port={selectedPortfolio?.id}
							id={selectedScenario?.[0]?.id}
							loading={status === 'pending'}
							key={1001}
							portfolioList={portfolios || []}
							setPortfolio={(val) => {
								setSelectedPortolio(
									portfolios.filter((item) => item.id == val)[0]
								);
								fetchScenarios(val);
							}}
							senarioData={scenarios || []}
							scenarioField={'scenario'}
							scenarioName={'Scenario'}
							scenario={selectedScenario?.scenario || {}}
							setScenario={(item) => {
								setSelectedScenario(item);
								if (portfolios.length === 0) return;
								updateTables(item.id);
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(name, user?.company_id, file, (res) => {
										dispatch(startTimer('treasury', res.data.id));
										fetchPortfolio();
									})
								);
							}}
							update={(name, callback) => {
								dispatch(
									updatePortfolio(selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										callback();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio(selectedPortfolio?.id, () => {
										fetchPortfolio();
										dispatch({ type: GET_CASHFLOW_TABLES_CLEAN });
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('treasury', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(selectedPortfolio?.id, formData, () => {
										fetchScenarios(selectedPortfolio?.id, false);
									})
								);
							}}
							downloadFile={() => {
								downloadCashflowData(selectedPortfolio?.id);
							}}
							downloadTemplate={() => {
								downloadCashflowTemplate();
							}}
							collapsed={collapsed}
							seconds={seconds}
							status={status}
							minutes={minutes}
						/>
						<hr />
						<div style={{ marginTop: 20 }}></div>
						{renderTable(dataTable, tables && !tables.Vectors ? null : tables)}
						<MainTable
							header={headers.dataTapeHeader}
							data={tables?.datatape}
							attributes={headers.dataTapeAttributes}
							tableName="Data Tape"
							fetchData={() => {
								if (!tables?.datatape)
									fetchPortfolioDetails(selectedScenario?.id, 'data-tape');
							}}
							collapsed={collapsed}
							download
						/>
						{renderChart(
							tables ? true : false,
							state.openChartsCash,
							defaultChartsCash
						)}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default Cash;
