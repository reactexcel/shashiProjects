import { makeStyles } from '@material-ui/core';
import { primaryColor } from '../../../common/assets/layout';

export const useStyles = makeStyles((theme) => ({
	sidemenu: {
		maxWidth: '100%',
		// color: primaryColor,
		color: '#2D2D2D'
	},
	sidemenu_header: {
		borderTop: `3px solid ${primaryColor}`,
		borderBottom: `3px solid ${primaryColor}`,
		// color: primaryColor,
		color: '#2D2D2D',
		width: '100%',
		margin: '50px 0 20px 0',
		display: 'flex',
		flexWrap: 'wrap'
	},
	sidemenu__select: {
		paddingLeft: 10,
		paddingRight: 10,
		width: '100%'
	},
	form: {
		display: 'flex'
	},
	inputCollection: {
		marginBottom: 32
	},
	inputCollection__ext_mgbt: {
		[theme.breakpoints.up('lg')]: {
			marginBottom: 67
		}
	},
	parametrHead: {
		height: 32,
		color: '#2D2D2D',
		borderRadius: 0,
		position: 'relative',
		justifyContent: 'flex-start',
		borderBottom: `2px solid rgb(240, 242, 244)`,
		backgroundColor: '#FFF',
		textTransform: 'capitalize',
		'&:hover': {
			backgroundColor: '#FFF'
		},
		'&:before': {
			transition: '0.2s',
			content: '" "',
			position: 'absolute',
			display: 'block',
			width: '3px',
			zIndex: 1,
			left: 0,
			height: '25px',
			marginBottom: '6px',
			backgroundColor: '#3ea8a0'
		}
	},
	// parametrHead_arrow: {
	//   position: "absolute",
	//   top: 3,
	//   right: 10,
	//   color: "#fff",
	// },
	TypoHead: {
		fontWeight: 'bold',
		marginBottom: 15,
		paddingLeft: 10,
		width: '100%',
		position: 'relative',
		'&:before': {
			transition: '0.2s',
			content: '" "',
			position: 'absolute',
			display: 'block',
			width: '3px',
			zIndex: 1,
			left: 0,
			height: '25px',
			marginBottom: '6px',
			backgroundColor: '#3ea8a0'
		}
	},
	senarios: {
		marginTop: 10,
		// marginBottom: 50,
		height: 45
	},
	mbt50: {
		marginTop: 10,
		marginBottom: 50
	},
	selectLabel: {
		alignSelf: 'center'
	},
	selectInput: {
		alignSelf: 'center'
	},
	selectIconGrid: {
		alignSelf: 'center',
		color: '#7991aa'
	},
	selectIcon: {
		width: 16
	},
	emptyParam: {
		// borderTop: `3px solid ${primaryColor}`,
		width: '100%',
		borderBottom: `3px solid ${primaryColor}`,
		alignItems: 'center',
		display: 'flex',
		padding: '8px 10px 10px'
	}
}));
