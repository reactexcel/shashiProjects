// FPNA 3.3.2
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Grid, Divider } from '@material-ui/core';
import { useStyles } from '../Fpna/fpnaStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { startTimer } from '../store/actions/timer.action';
import {
	getPortfolios,
	getScenarioDetails,
	getPortfolioScenarios,
	getCalcStatus,
	getSegment,
	getSubPortofolios,
	getCashFlow2Charts
} from '../store/actions/fpna.action';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import { loanHeaders2, dynamicHeaders } from '../Fpna/liabilityTableFileds';
import {
	GET_FPNA3_TABLES_CLEAN,
	GET_CHARTS3_CLEAN,
	TASK_PROGRESS_FPNA3,
	STOP_FPNA3_TIMER
} from '../store/types/fpna.type';
import MainTable from 'app/components/Table/MainTable';
import Chart from 'app/components/Chart/Chart';

const CashFlowV3 = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);
	const {
		portfolios3,
		// charts3,
		chashflow2charts,
		tables3,
		status3
	} = useSelector((state) => state.fpna);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: fpnaRef, height: fpnaHeight } = useComponentSize();
	const [vintageKeys, setVintageKeys] = useState({});
	const [chartVisible, setChartVisible] = useState({
		chart1: false,
		chart2: false,
		chart3: false
	});
	const [selectedPortfolio, setSelectedPortfolio] = useState([]);
	const [selectedScenario, setSelectedScenario] = useState([]);
	const [selectedSubPorofolio, setSelectedSubPorofolio] = useState([]);
	const [stateMultipleArray, setStateMultipleArray] = useState({});
	const [chartsData, setChartsData] = useState([]);
	const [dataType, setDataType] = useState(
		'output/?incomestatement_orient=split'
	);

	const stopTimerFunction = () => {
		dispatch({
			type: STOP_FPNA3_TIMER,
			payload: { status3: 'stopped' }
		});
	};

	const dispatchClean = (unmount) => {
		dispatch({
			type: GET_FPNA3_TABLES_CLEAN,
			payload: unmount ? null : selectedPortfolio
		});
		dispatch({ type: GET_CHARTS3_CLEAN });
	};

	useEffect(() => {
		if (!portfolios3 && user?.allowed_pages?.includes(1)) fetchPortfolio();
	}, [user, portfolios3]);

	useEffect(() => {
		if (collapsed >= 1) setChartVisible(true);
		else if (collapsed === 0 && chartVisible) setChartVisible(false);
	}, [collapsed]);

	useEffect(() => {
		if (selectedScenario[0] && status3 === 'SUCCESS') {
			updateTables(selectedScenario[0]?.id);
			fetchSubPorofolios(selectedScenario[0]);
		}
	}, [status3]);

	const calculateStatus = (supPorofolioId) => {
		supPorofolioId && dispatch(startTimer('cfm2', supPorofolioId, ''));
		getCalcStatus('cfm2/portfolio', selectedSubPorofolio[0]?.id, (res) => {
			if (res.task_state === 'SUCCESS') {
				updateTables(selectedSubPorofolio[0]?.id);
			}
			if (res.task_state !== 'SUCCESS')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: res.task_progress
				});
			else if (res.task_state === 'FAILURE')
				dispatch({
					type: TASK_PROGRESS_FPNA3,
					payload: 'Failed'
				});
		});
	};

	useEffect(() => {
		if (selectedSubPorofolio && selectedSubPorofolio[0]?.id) {
			calculateStatus();
		}
	}, [selectedSubPorofolio]);

	useEffect(() => {
		return () => {
			dispatchClean('unmount');
			stopTimerFunction();
		};
	}, []);

	const fetchPortfolio = (create) => {
		dispatch(
			getPortfolios('2', (res) => {
				setSelectedPortfolio(res[0]);
				res[0] && create && fetchScenarios(res[0].id, dataType, create);
			})
		);
	};

	const fetchScenarios = (scenarioGroupId, dataTypeVal, create) => {
		dispatch(
			getPortfolioScenarios('2', scenarioGroupId, (portflioScenrios) => {
				setSelectedScenario([portflioScenrios.results[0]]);
				create &&
					dispatch(startTimer('cfm2', portflioScenrios.results[0].id, ''));
			})
		);
	};

	const fetchSubPorofolios = (scenarioId) => {
		dispatch(
			getSubPortofolios('2', scenarioId?.id, (scenriosSubPortofolios) => {
				setSelectedSubPorofolio([scenriosSubPortofolios.results[0]]);
				scenriosSubPortofolios?.results.map((item) => fetchSegments(item));
			})
		);
	};

	const fetchSegments = (supPorofolioId) => {
		dispatch(getSegment('2', supPorofolioId));
	};

	useEffect(() => {
		selectedPortfolio?.id && fetchScenarios(selectedPortfolio?.id, dataType);
	}, [selectedPortfolio]);

	useEffect(() => {
		selectedScenario[0]?.id && fetchSubPorofolios(selectedScenario[0]);
	}, [selectedScenario]);

	const fetchScenarioVintageSummary = (model, type, query = '', name) => {
		if (!model) return;
		dispatch(getScenarioDetails('2', model, type ? type : dataType, query));
	};

	const fetchScenarioDetailsPortfolioVintage = (
		model,
		type,
		query = '',
		name
	) => {
		if (!model) return;
		dispatch(getScenarioDetails('2', model, type ? type : dataType, query));
	};

	const updateTables = (id) => {
		if (!tables3 && !id) return;
		if (tables3?.assetamort_breakdown2 || id)
			fetchScenarioDetailsPortfolioVintage(
				id,
				'output-breakdown',
				'',
				'Portfolio Consolidated - Asset Amortization'
			);
		if (tables3?.incomestatement2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Consolidated Portfolio - Income Statement'
			);
		if (tables3?.issuportschedule2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Consolidated Portfolio - Income Statement Support Schedule'
			);
		if (tables3?.equity_requirement2 || id)
			fetchScenarioVintageSummary(
				id,
				'output-breakdown',
				'',
				'Equity Requirement Consolidated'
			);
	};

	useEffect(() => {
		if (chashflow2charts) {
			let chart1 = [];
			let chart2 = [];
			let chart3 = [];
			let chart4 = [];
			let chart5 = [];
			let chart6 = [];
			let chart7 = [];
			let chart8 = [];
			let chart9 = [];
			let tempChart1 = [];
			let tempChart2 = [];
			let tempChart3 = [];
			let tempChart4 = [];
			let tempChart5 = [];
			let tempChart6 = [];
			let tempChart7 = [];
			let tempChart8 = [];
			let tempChart9 = [];

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart1.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_consolidated?.['closing_balance'][i]
				});
				chart1.push(tempChart1);
			});

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart2.push({
					date: val1,
					interest: chashflow2charts?.chart_consolidated?.['interest'][i]
				});
				chart2.push(tempChart2);
			});

			chashflow2charts?.chart_consolidated?.['date'].forEach((val1, i) => {
				tempChart3.push({
					date: val1,
					principal: chashflow2charts?.chart_consolidated?.['principal'][i]
				});
				chart3.push(tempChart3);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart4.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_current_portfolio?.['closing_balance'][i]
				});
				chart4.push(tempChart4);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart5.push({
					date: val1,
					interest: chashflow2charts?.chart_current_portfolio?.['interest'][i]
				});
				chart5.push(tempChart5);
			});

			chashflow2charts?.chart_current_portfolio?.['date'].forEach((val1, i) => {
				tempChart6.push({
					date: val1,
					principal: chashflow2charts?.chart_current_portfolio?.['principal'][i]
				});
				chart6.push(tempChart6);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart7.push({
					date: val1,
					closing_balance:
						chashflow2charts?.chart_forecast?.['closing_balance'][i]
				});
				chart7.push(tempChart7);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart8.push({
					date: val1,
					interest: chashflow2charts?.chart_forecast?.['interest'][i]
				});
				chart8.push(tempChart8);
			});

			chashflow2charts?.chart_forecast?.['date'].forEach((val1, i) => {
				tempChart9.push({
					date: val1,
					principal: chashflow2charts?.chart_forecast?.['principal'][i]
				});
				chart9.push(tempChart9);
			});

			let updatedCharts = [
				{
					ch: chart1,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart2,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart3,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				},
				{
					ch: chart4,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart5,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart6,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				},
				{
					ch: chart7,
					xIndex: 'date',
					noCharts: ['closing_balance'],
					format: 'com',
					nameLegend: `Closing Balance`
				},
				{
					ch: chart8,
					xIndex: 'date',
					noCharts: ['interest'],
					format: 'com',
					nameLegend: `Interest`
				},
				{
					ch: chart9,
					xIndex: 'date',
					noCharts: ['principal'],
					format: 'com',
					nameLegend: `Principal`
				}
			];
			setChartsData(updatedCharts);
		}
	}, [chashflow2charts]);

	useEffect(() => {
		if (selectedSubPorofolio?.[0]?.id)
			dispatch(getCashFlow2Charts(selectedSubPorofolio?.[0]?.id));
	}, [selectedSubPorofolio]);

	const renderChart = (openType, startIndex, endIndex, chart_name) => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() =>
						setChartVisible({
							...chartVisible,
							[openType]: !chartVisible?.[openType]
						})
					}
				>
					<p className={classes.contentHeader}>{`${chart_name} Charts`}</p>
				</div>
				{chartVisible?.[openType] && (
					<div className={classes.datechat__charts}>
						{chartsData?.length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								{chartsData.slice(startIndex, endIndex).map((itemChart) => {
									return (
										<Grid
											key={itemChart?.nameLegend}
											item
											xs={12}
											sm={12}
											md={4}
											className={classes.container__chart}
										>
											<Chart
												dataT={itemChart.ch}
												nameLegend={itemChart?.nameLegend}
												sizeLegend="14px"
												dataX={itemChart?.xIndex}
												xDistance={400}
												format={itemChart?.format}
												noCharts={itemChart?.noCharts}
												// customTooltip
											/>
										</Grid>
									);
								})}
							</Grid>
						)}
					</div>
				)}
			</div>
		);
	};

	const typeHeaders = (tableName, category) => {
		if (tableName === 'loanmodel') return loanHeaders2;
		else if (tableName.includes('assetamort_breakdown2'))
			return dynamicHeaders(category);
		else if (tableName.includes('equity_requirement2'))
			return dynamicHeaders(category);
		else if (tableName.includes('incomestatement2'))
			return dynamicHeaders(category);
		else if (tableName.includes('issuportschedule2'))
			return dynamicHeaders(category);
		else return null;
	};

	const renderTable = (
		tableId,
		tableName,
		tableData,
		verboseTableName,
		multiple = false,
		multipleArray = [],
		customArrangeExcel
	) => {
		let customArrangeExcelMap = [];
		let customArrangeExcelFinalMap = [];
		if (customArrangeExcel && customArrangeExcel?.length > 0 && tableData) {
			customArrangeExcel?.forEach((item) =>
				customArrangeExcelMap.push(
					...(tableData?.[tableName]?.category?.[item] || [])
				)
			);
			customArrangeExcelMap?.forEach((item) =>
				customArrangeExcelFinalMap.push(tableData?.[tableName]?.columns?.[item])
			);
		}
		return (verboseTableName === 'Vintage' ||
			verboseTableName === 'Portfolio') &&
			Object.keys(vintageKeys).length === 0 ? (
			<></>
		) : (
			<div>
				<MainTable
					header={
						tableData &&
						(customArrangeExcel
							? customArrangeExcelFinalMap
							: tableData[tableName]?.columns)
					}
					data={tableData && tableData[tableName]}
					attributes={
						tableData &&
						tableData[tableName]?.data &&
						Object.keys(tableData[tableName]?.columns)
					}
					customArrangeExcel={customArrangeExcel}
					tableId={tableId}
					tableName={verboseTableName}
					tableSign={
						verboseTableName === 'Loan Data'
							? 'Loan Data Summary first and last 10 loans'
							: verboseTableName
					}
					fetchData={() => {}}
					collapsed={collapsed}
					separator={typeHeaders(tableName, tableData?.[tableName]?.category)}
					multiple={multiple}
					multipleArray={multipleArray}
					stateMultipleArray={stateMultipleArray}
					setStateMultipleArray={setStateMultipleArray}
					download
					formatType="mixedTables"
					model={'2'}
					modelName={'fpna3'}
					id={selectedSubPorofolio[0]?.id}
				/>
			</div>
		);
	};

	if (
		!user?.allowed_pages?.includes(3) ||
		!user?.allowed_section3.includes(314)
	)
		return <div></div>;

	return (
		<div ref={fpnaRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={fpnaHeight} />
			<Grid
				className={classes.appContentContainer}
				container
				justifyContent="center"
			>
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						{renderTable(
							'1325',
							'assetamort_breakdown2',
							tables3,
							'Portfolio Consolidated - Asset Amortization'
						)}
						{renderTable(
							'1013',
							'equity_requirement2',
							tables3,
							'Equity Requirement Consolidated',
							'',
							'',
							[
								'untitled',
								'Portfolio',
								'Active Portfolio Equity Requirement',
								'Expected Loss Over 120',
								'Operating Cashflow'
							]
						)}
						{renderTable(
							'3235',
							'incomestatement2',
							tables3,
							'Consolidated Portfolio - Income Statement'
						)}
						{renderTable(
							'2482',
							'issuportschedule2',
							tables3,
							'Consolidated Portfolio - Income Statement Support Schedule'
						)}
						{renderChart('chart1', 0, 3, 'Consolidated Portfolio')}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};
export default CashFlowV3;
