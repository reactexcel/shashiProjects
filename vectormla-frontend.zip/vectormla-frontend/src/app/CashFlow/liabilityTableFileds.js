export const LibHeaders = {
	untitled: [0, 1],
	Triggers: [2, 3, 4, 5],
	Swap: [6, 7, 8, 9, 10, 11, 12, 13],
	Fees: [14, 15, 16, 17],
	'Senior Debt Interest': [18, 19, 20, 21, 22, 23],
	'Senior Debt Principal': [24, 25, 26, 27, 28, 29, 30],
	'Reserve Account': [31, 32, 33, 34, 35, 36],
	'Sub Loan Interest': [37, 38, 39, 40, 41],
	'Sub Loan Principal': [42, 43, 44, 45],
	Excess: [46, 47],
	'Loan Balances': [48, 49, 50, 51, 52, 53],
	'Cash Check': [54, 55, 56],
	Tracking: [57, 58, 59]
};

export const VectorHeaders = {
	untitled: [0],
	'Forward Rate Curves': [1, 2, 3, 4, 5, 6, 7, 8],
	'SMM Curves': [9, 10, 11],
	'Timing Curves': [12, 13, 14, 15, 16, 17]
};
