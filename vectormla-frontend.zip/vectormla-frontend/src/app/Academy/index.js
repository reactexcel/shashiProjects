import Academy from './Academy';

export default Academy;
