import AccountSetting from './AccountSetting';

export default AccountSetting;
