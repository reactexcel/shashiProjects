import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { toast } from 'react-toastify';
import {
	Grid,
	Button,
	Divider,
	TextField,
	Typography
} from '@material-ui/core';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import { useStyles } from './accountSettingStyles';
import { updateUserData } from '../services/adminService';
import { resetPassword, retrieveUserInfo } from '../store/actions/auth.action';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import { withRouter } from 'react-router-dom';

const AccountSetting = ({ history }) => {
	const user = useSelector((state) => state.auth.user);
	const { ref: adminRef, height: adminHeight } = useComponentSize();
	const [firstName, setFirstName] = useState('');
	const [lastName, setLastName] = useState('');
	const [jobName, setJobName] = useState('');
	const [password1, setPassword1] = useState('');
	const [password2, setPassword2] = useState('');
	const classes = useStyles();

	const dispatch = useDispatch();

	useEffect(() => {
		if (firstName === '' && user) {
			setFirstName(user?.first_name);
			setLastName(user?.last_name);
			setJobName(user?.job_name);
		}
	}, [firstName, user]);
	const updateInfo = () => {
		let values = {
			id: user?.id,
			email: user?.email,
			username: user?.username,
			first_name: firstName,
			last_name: lastName,
			job_name: jobName
		};

		for (let i in values) {
			if (values[i] === null) {
				delete values[i];
			}
		}
		updateUserData(values, () => {
			dispatch(
				retrieveUserInfo(() => {
					history.push({
						pathname: '/app/homepage'
					});
				})
			);
			toast.success('Your information is updated successfully!');
		});
	};

	const resetPass = () => {
		if (password1 !== password2) {
			toast.error('Password must match confirm password field!');
		} else {
			dispatch(
				resetPassword(user.id, { password1, password2 }, () => {
					toast.success('Your password is updated successfully!');
				})
			);
		}
	};

	return (
		<div ref={adminRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={adminHeight} />

			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={12}>
					<div>
						<div className={[classes.contentHeaderContainer]}>
							<p className={classes.contentHeader}>Account Information</p>
							<img
								src={downArrow}
								alt=""
								style={{ justifyContent: 'flex-end' }}
							/>
						</div>
						<Divider style={{ marginBottom: 20 }} />
						<Grid
							container
							justify="flex-start"
							spacing={4}
							style={{ marginBottom: 20 }}
						>
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									First Name
								</Typography>
								<TextField
									name="First Name"
									variant="outlined"
									placeholder="First Name"
									value={firstName}
									onChange={(e) => {
										setFirstName(e.target.value);
									}}
									className={classes.textStyle}
								/>
								<Button
									style={{
										position: 'absolute',
										left: 300
									}}
									className={classes.header__save}
									onClick={() => updateInfo()}
								>
									Update
								</Button>
							</Grid>
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									Last Name
								</Typography>
								<TextField
									name="Last Name"
									variant="outlined"
									placeholder="Last Name"
									value={lastName}
									onChange={(e) => {
										setLastName(e.target.value);
									}}
									className={classes.textStyle}
								/>
							</Grid>
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									Username
								</Typography>
								<TextField
									name="Username"
									variant="outlined"
									placeholder="Username"
									value={user?.username}
									className={classes.textStyle}
									disabled={true}
								/>
							</Grid>
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									Email
								</Typography>
								<TextField
									name="Email"
									variant="outlined"
									placeholder="Email"
									value={user?.email}
									className={classes.textStyle}
									disabled={true}
								/>
							</Grid>

							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									Job Name
								</Typography>
								<TextField
									name="Job Name"
									variant="outlined"
									placeholder="Job Name"
									value={jobName}
									className={classes.textStyle}
									onChange={(e) => {
										setJobName(e.target.value);
									}}
								/>
							</Grid>
						</Grid>
						<div
							className={[classes.contentHeaderContainer]}
							style={{ marginTop: 70 }}
						>
							<p className={classes.contentHeader}>Reset Password</p>
							<img
								alt=""
								src={downArrow}
								style={{ justifyContent: 'flex-end' }}
							/>
						</div>
						<Divider style={{ marginBottom: 20 }} />
						<Grid container justify="flex-start" spacing={4}>
							{/* Company */}
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									password
								</Typography>
								<TextField
									name="password"
									variant="outlined"
									placeholder="password"
									value={password1}
									type="password"
									className={classes.textStyle}
									onChange={(e) => {
										setPassword1(e.target.value);
									}}
								/>
								<Button
									style={{
										position: 'absolute',
										left: 300
									}}
									className={classes.header__save}
									onClick={() => resetPass()}
								>
									Reset
								</Button>
							</Grid>
							<Grid item xs={12} className={classes.gridChild}>
								<Typography
									variant="subtitle2"
									align="left"
									className={classes.label}
								>
									Confirm New Password
								</Typography>
								<TextField
									name="Confirm New Password"
									variant="outlined"
									type="password"
									placeholder="Confirm New Password"
									value={password2}
									className={classes.textStyle}
									onChange={(e) => {
										setPassword2(e.target.value);
									}}
								/>
							</Grid>
						</Grid>
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default withRouter(AccountSetting);
