/////////////////////////////////////////////////////////
export const interestRateItems = [
	{ value: 'Custom 1', label: 'Custom 1' },
	{ value: 'Custom 2', label: 'Custom 2' },
	{ value: 'Custom 3', label: 'Custom 3' }
];

export const interestRateRevisionOnItems = [
	{ value: 0, label: 'False' },
	{ value: 1, label: 'True' }
];

export const yieldMaturityCurveItem = [
	{ value: 'Yield-To-Maturity', label: 'Yield-To-Maturity' }
];

export const riskStressItem = [
	{ value: 0.1, label: '0.1' },
	{ value: 0.2, label: '0.2' },
	{ value: 0.3, label: '0.3' },
	{ value: 0.4, label: '0.4' },
	{ value: 0.5, label: '0.5' },
	{ value: 0.6, label: '0.6' }
];

export const marginItems = [
	{ value: 0, label: '0' },
	{ value: 0.5, label: '0.5' }
];

export const periodicCapItems = [
	{ value: 1, label: '1' },
	{ value: 2, label: '2' }
];

export const lifetimeCapItems = [
	{ value: 1, label: '1' },
	{ value: 2, label: '2' }
];

export const lifetimeFloorItems = [
	{ value: 0, label: '0' },
	{ value: 0.5, label: '0.5' }
];

export const rateResetFreqItems = [
	{ value: 1, label: '1' },
	{ value: 3, label: '3' }
];

export const couponPaymentFreqItems = [{ value: 12, label: '12' }];

export const durationChangeInYieldItems = [
	{ value: 0.01, label: '1%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.9, label: '90%' },
	{ value: 1, label: '100%' }
];

export const prepayCurveItems = [
	{ value: 'SMM 0', label: 'SMM 0' },
	{ value: 'SMM 1', label: 'SMM 1' },
	{ value: 'SMM 2', label: 'SMM 2' }
];

export const prepayStressItems = [
	{ value: 1, label: '1' },
	{ value: 5, label: '5' },
	{ value: 9, label: '9' },
	{ value: 15, label: '15' }
];

export const MLDefaultModelItems = [
	{ value: 0, label: 'Manual Input' },
	{ value: 1, label: 'Model 1' },
	{ value: 2, label: 'Model 2' }
];

export const grossCummulativeLossItems = [
	{ value: 0.01, label: '1%' },
	{ value: 0.02, label: '2%' }
];

export const lossStressItems = [
	{ value: 1, label: '1' },
	{ value: 5, label: '5' },
	{ value: 15, label: '15' }
];

export const lossTimingCurveItems = [
	{ value: 'Timing Curve 0', label: 'Timing Curve 0' },
	{ value: 'Timing Curve 1', label: 'Timing Curve 1' },
	{ value: 'Timing Curve 2', label: 'Timing Curve 2' },
	{ value: 'Timing Curve 3', label: 'Timing Curve 3' },
	{ value: 'Timing Curve 4', label: 'Timing Curve 4' },
	{ value: 'Timing Curve 5', label: 'Timing Curve 5' }
];
export const recoveryRateItems = [
	{ value: 0.01, label: '1%' },
	{ value: 0.09, label: '9%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.9, label: '90%' },
	{ value: 1, label: '100%' }
];
export const recoveryLagItems = [
	{ value: 5, label: 5 },
	{ value: 20, label: 25 },
	{ value: 45, label: 45 },
	{ value: 58, label: 58 }
];

/////////////////////////////////////////////////////
export const assetBasedFeesItems = [
	{ value: 0.02, label: '2%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.25, label: '25%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.35, label: '35%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.45, label: '45%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.55, label: '55%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.65, label: '65%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.75, label: '75%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.85, label: '85%' },
	{ value: 0.9, label: '90%' },
	{ value: 0.95, label: '95%' },
	{ value: 1, label: '100%' }
];

export const reserveAccountItems = [
	{ value: 0.01, label: '1%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.25, label: '25%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.35, label: '35%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.45, label: '45%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.55, label: '55%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.65, label: '65%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.75, label: '75%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.85, label: '85%' },
	{ value: 0.9, label: '90%' },
	{ value: 0.95, label: '95%' },
	{ value: 1, label: '100%' }
];

export const captureAllXsSpdItems = [
	{ value: 'No', label: 'No' },
	{ value: 'Yes', label: 'Yes' }
];

export const postTriggerDefaultMonthItems = [
	{ value: 3, label: '3' },
	{ value: 4, label: '4' },
	{ value: 5, label: '5' },
	{ value: 6, label: '6' },
	{ value: 7, label: '7' },
	{ value: 8, label: '8' },
	{ value: 9, label: '9' },
	{ value: 10, label: '10' }
];

export const defaultTriggerPrcntItems = [
	{ value: 0.05, label: '5%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.25, label: '25%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.35, label: '35%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.45, label: '45%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.55, label: '55%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.65, label: '65%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.75, label: '75%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.85, label: '85%' },
	{ value: 0.9, label: '90%' },
	{ value: 0.95, label: '95%' },
	{ value: 1, label: '100%' }
];

export const swapActiveItems = [
	{ value: 'No', label: 'No' },
	{ value: 'Yes', label: 'Yes' }
];

export const swapRateInItems = [{ value: '1-Month LIBOR', label: '1-M L' }];

export const swapRateOutItems = [{ value: 'Custom 1', label: 'Custom 1' }];

///////////////////////////////////////////////////////////
export const advanceRateSeniorItems = [
	{ value: 0.99, label: '99%' },
	{ value: 0.89, label: '89%' },
	{ value: 0.79, label: '79%' },
	{ value: 0.69, label: '69%' },
	{ value: 0.59, label: '59%' },
	{ value: 0.49, label: '49%' },
	{ value: 0.39, label: '39%' },
	{ value: 0.29, label: '29%' },
	{ value: 0.19, label: '19%' },
	{ value: 0.09, label: '9%' },
	{ value: 0.001, label: '0.1%' }
];

export const liabilityInterestRateCurveSeniorItems = [
	{ value: '1-Month LIBOR', label: '1-M L' }
];

export const loanMarginSeniorItems = [
	{ value: 0.01, label: '1%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.25, label: '25%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.35, label: '35%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.45, label: '45%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.55, label: '55%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.65, label: '65%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.75, label: '75%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.85, label: '85%' },
	{ value: 0.9, label: '90%' },
	{ value: 0.95, label: '95%' },
	{ value: 1.0, label: '100%' }
];

export const feesSeniorItems = [
	{ value: 0.005, label: '0.5%' },
	{ value: 0.01, label: '1%' },
	{ value: 0.015, label: '1.5%' },
	{ value: 0.02, label: '2%' },
	{ value: 0.025, label: '2.5%' },
	{ value: 0.03, label: '3%' },
	{ value: 0.035, label: '3.5%' },
	{ value: 0.04, label: '4%' },
	{ value: 0.045, label: '4.5%' },
	{ value: 0.05, label: '5%' },
	{ value: 0.055, label: '5.5%' },
	{ value: 0.06, label: '6%' },
	{ value: 0.065, label: '6.5%' },
	{ value: 0.07, label: '7%' },
	{ value: 0.075, label: '7.5%' },
	{ value: 0.08, label: '8%' },
	{ value: 0.085, label: '8.5%' },
	{ value: 0.09, label: '9%' },
	{ value: 0.095, label: '9.5%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '10.5%' },
	{ value: 0.2, label: '11%' },
	{ value: 0.25, label: '11.5%' }
];

export const reserveActiveSeniorItems = [
	{ value: 'No', label: 'No' },
	{ value: 'Yes', label: 'Yes' }
];

export const prinAllocationTypeSeniorItems = [
	{ value: 'Pro Rate', label: 'Pro Rate' },
	{ value: 'Sequential', label: 'Sequential' }
];

//////////////////////////////////////////////////
export const liabilityInterestRateCurveSubItems = [
	{ value: 'Custom 1', label: 'Custom 1' }
];

export const loanMarginSubItems = [
	{ value: 0.0, label: '0%' },
	{ value: 0.01, label: '1%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '15%' },
	{ value: 0.2, label: '20%' },
	{ value: 0.25, label: '25%' },
	{ value: 0.3, label: '30%' },
	{ value: 0.35, label: '35%' },
	{ value: 0.4, label: '40%' },
	{ value: 0.45, label: '45%' },
	{ value: 0.5, label: '50%' },
	{ value: 0.55, label: '55%' },
	{ value: 0.6, label: '60%' },
	{ value: 0.65, label: '65%' },
	{ value: 0.7, label: '70%' },
	{ value: 0.75, label: '75%' },
	{ value: 0.8, label: '80%' },
	{ value: 0.85, label: '85%' },
	{ value: 0.9, label: '90%' },
	{ value: 0.95, label: '95%' },
	{ value: 1.0, label: '100%' }
];

export const feesSubItems = [
	{ value: 0.0, label: '0%' },
	{ value: 0.005, label: '0.5%' },
	{ value: 0.01, label: '1%' },
	{ value: 0.015, label: '1.5%' },
	{ value: 0.02, label: '2%' },
	{ value: 0.025, label: '2.5%' },
	{ value: 0.03, label: '3%' },
	{ value: 0.035, label: '3.5%' },
	{ value: 0.04, label: '4%' },
	{ value: 0.045, label: '4.5%' },
	{ value: 0.05, label: '5%' },
	{ value: 0.055, label: '5.5%' },
	{ value: 0.06, label: '6%' },
	{ value: 0.065, label: '6.5%' },
	{ value: 0.07, label: '7%' },
	{ value: 0.075, label: '7.5%' },
	{ value: 0.08, label: '8%' },
	{ value: 0.085, label: '8.5%' },
	{ value: 0.09, label: '9%' },
	{ value: 0.095, label: '9.5%' },
	{ value: 0.1, label: '10%' },
	{ value: 0.15, label: '10.5%' },
	{ value: 0.2, label: '11%' },
	{ value: 0.25, label: '11.5%' }
];

export const advanceRateSubItems = [
	{ value: 0.0, label: '0%' },
	{ value: 0.001, label: '0.1%' },
	{ value: 0.09, label: '9%' },
	{ value: 0.19, label: '19%' },
	{ value: 0.29, label: '29%' },
	{ value: 0.39, label: '39%' },
	{ value: 0.49, label: '49%' },
	{ value: 0.59, label: '59%' },
	{ value: 0.69, label: '69%' },
	{ value: 0.79, label: '79%' },
	{ value: 0.89, label: '89%' },
	{ value: 0.99, label: '99%' }
];

export const reserveActivateAlwaysSubItems = [
	{ value: 'No', label: 'No' },
	{ value: 'Yes', label: 'Yes' }
];

export const prinAllocationTypeSubItems = [
	{ value: 'Pro Rate', label: 'Pro Rate' },
	{ value: 'Sequential', label: 'Sequential' }
];
