// Credit Risk 1.2.3
import React, { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useComponentSize } from 'react-use-size';
import { Divider, Grid } from '@material-ui/core';
import { useStyles } from './defaultStyles';
import RenderAlphaBar from '../components/AssestFunctions/RenderAlphaBar';
import Portfolio from '../components/portfolio/Portfolio';
import MainTable from '../components/Table/MainTable';
import { startTimer } from '../store/actions/timer.action';
import {
	createPortfolio,
	downloadDefaultTemplate,
	getPortfolios,
	deletePortfolio,
	getPortfolioDetails,
	updatePortfolio,
	downloadDefaultData
} from '../store/actions/default.action';
import headers from './tableHeader';
import downArrow from '../../common/assets/vector/images/arrow.svg';
import Chart from '../components/Chart/MultiLineChart';
import { GET_DEFAULT_TABLES_CLEAN } from '../store/types/default.type';

const Default = ({ collapsed }) => {
	const user = useSelector((state) => state.auth.user);

	const { portfolios, tables } = useSelector((state) => state.default);
	const dispatch = useDispatch();
	const classes = useStyles();
	const { ref: defaultRef, height: defaultHeight } = useComponentSize();
	const [selectedPortfolio, setSelectedPortfolio] = useState(null);
	const [dataType, setDataType] = useState('output');
	const [chartVisible, setChartVisible] = useState(false);

	useEffect(() => {
		if (!portfolios && user?.allowed_pages?.includes(1)) fetchPortfolio();
		if (portfolios && !selectedPortfolio) setSelectedPortfolio(portfolios[0]);
	}, [portfolios, user]);

	useEffect(() => {
		if (collapsed >= 1) {
			setChartVisible(true);
		} else if (collapsed === 0 && chartVisible) {
			setChartVisible(false);
		}
	}, [collapsed]);

	useEffect(() => {
		return () => {
			dispatch({ type: GET_DEFAULT_TABLES_CLEAN });
		};
	}, []);

	const fetchPortfolio = () => {
		dispatch(
			getPortfolios((res) => {
				setSelectedPortfolio(res[0]);
				fetchPortfolioDetails(res[0]?.id, 'output');
			})
		);
	};
	const existTables = ['cummulative_default_prcnt'];
	const fetchPortfolioDetails = (model, type) => {
		if (!model) return;
		dispatch(getPortfolioDetails(model, type ? type : dataType));
	};
	const renderTable = (existTables, tableData) => {
		return (
			<div>
				{existTables.map((tableName, index) => (
					<MainTable
						header={tableData && tableData[tableName]?.columns}
						data={tableData && tableData[tableName]?.data}
						attributes={
							tableData &&
							tableData[tableName]?.data &&
							Object.keys(tableData[tableName]?.data)
						}
						tableId={index}
						key={index}
						tableName={'Cummulative Default %'}
						fetchData={() => {
							if (!tables)
								fetchPortfolioDetails(selectedPortfolio?.id, 'output');
						}}
						collapsed={collapsed}
						download
					/>
				))}
			</div>
		);
	};

	const renderCharts = () => {
		return (
			<div>
				<div
					className={classes.contentHeaderContainer}
					onClick={() => setChartVisible(!chartVisible)}
				>
					<p className={classes.contentHeader}>{'Charts'}</p>
				</div>
				{chartVisible && (
					<div className={classes.datechat__charts}>
						{tables && Object.keys(tables).length > 0 && (
							<Grid
								container
								spacing={1}
								justify="flex-start"
								alignItems="center"
								direction="row"
							>
								<Grid
									item
									xs={12}
									sm={12}
									md={6}
									lg={6}
									className={classes.container__chart}
								>
									{tables['cummulative_default_prcnt_plot'] && (
										<Chart
											dataT={tables['cummulative_default_prcnt_plot']}
											nameLegend={`Cumulative Default`}
											sizeLegend="14px"
											brushID={`Cumulative Default`}
											dataX={`Period`}
											xDistance={400}
											format={'com'}
										/>
									)}
								</Grid>
							</Grid>
						)}
					</div>
				)}
			</div>
		);
	};

	const updateTables = (id = selectedPortfolio.id) => {
		if (!tables) return;
		if (tables.loss_distribution || tables.weighted_average_curve)
			fetchPortfolioDetails(id);
	};
	if (
		!user?.allowed_pages?.includes(2) ||
		!user?.allowed_section2.includes(206)
	)
		return <div></div>;
	return (
		<div ref={defaultRef} className={classes.appContainer}>
			<RenderAlphaBar containerHeight={defaultHeight} />
			<Grid container className={classes.appContentContainer} justify="center">
				<Grid item xs={11}>
					<div style={{ marginLeft: -45 }}>
						<Portfolio
							model={'default'}
							port={selectedPortfolio?.id}
							key={1044}
							portfolioList={portfolios || []}
							setPortfolio={(val) => {
								setSelectedPortfolio(
									portfolios.filter((item) => item.id == val)[0]
								);
								updateTables(val);
							}}
							create={(name, file) => {
								dispatch(
									createPortfolio(
										name,
										user?.company_id,
										file,
										(res) => {
											dispatch(startTimer('default', res.data.id));
											fetchPortfolio();
										},
										'default'
									)
								);
							}}
							update={(name, callback) => {
								dispatch(
									updatePortfolio(selectedPortfolio?.id, { name }, () => {
										fetchPortfolio();
										callback();
									})
								);
							}}
							deleteObj={() => {
								dispatch(
									deletePortfolio(selectedPortfolio?.id, () => {
										fetchPortfolio();
										dispatch({ type: GET_DEFAULT_TABLES_CLEAN });
									})
								);
							}}
							upload={(formData) => {
								dispatch(startTimer('default', selectedPortfolio?.id));
								dispatch(
									updatePortfolio(
										selectedPortfolio?.id,
										formData,
										() => {
											updateTables();
										},
										'default'
									)
								);
							}}
							fetchData={() => {
								if (!tables)
									fetchPortfolioDetails(selectedPortfolio?.id, 'output');
							}}
							downloadFile={() => {
								downloadDefaultData(selectedPortfolio?.id);
							}}
							downloadTemplate={() => {
								dispatch(downloadDefaultTemplate());
							}}
							collapsed={collapsed}
						/>
						<MainTable
							header={headers.dfWeightedAverageCurveHeader}
							data={tables?.weighted_average_curve}
							attributes={headers.dfWeightedAverageCurveAttributes}
							tableId={232}
							tableName="Weighted Average Curve"
							fetchData={() => {
								if (!tables?.weighted_average_curve)
									fetchPortfolioDetails(selectedPortfolio?.id, 'output');
							}}
							collapsed={collapsed}
							download
						/>
						<MainTable
							header={headers.lossDistributionHeader}
							data={tables?.loss_distribution}
							attributes={headers.lossDistributionAttributes}
							tableId={232}
							tableName="Loss Distribution"
							fetchData={() => {
								if (!tables?.loss_distribution)
									fetchPortfolioDetails(selectedPortfolio?.id, 'output');
							}}
							collapsed={collapsed}
							download
						/>
						{renderTable(existTables, tables)}
						{renderCharts()}
					</div>
				</Grid>
			</Grid>
		</div>
	);
};

export default Default;
