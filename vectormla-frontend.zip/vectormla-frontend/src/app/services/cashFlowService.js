import { API } from '../../config/EnvironmentConfig';
import axios from 'axios';
export const getTableData = (scenario, params, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.post(
			`${API}loan/book/run?scenario=${scenario}`,
			{
				assumption: params
			},
			{
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => callback(res.data));
};

export const getSenarios = (number = 1, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}loan/book/retrieve?portfolio=${number}`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data));
};

export const getDataTape = (callback) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}loan/book/datatape`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data));
};

export const saveAssumption = async (data, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.put(
			`${API}loan/book/update`,
			{
				assumption: data
			},
			{
				headers: {
					Authorization: `Token ${session}`
				}
			}
		)
		.then((res) => {
			if (res.error) {
				callback(res.error);
			} else {
				callback(true);
			}
		});
};
