import React from 'react';
const InsightsBlock = ({ extra }) => {
	return (
		<section className="partners">
			<div className="container subContainer2">
				<div className="row partners_cont" style={{ margin: 0 }}>
					<div
						onClick={() => window.open('/blogs', '_self')}
						style={{ cursor: 'pointer' }}
						className="col-lg-4 header"
					>
						<h5>Insights</h5>
						<p>
							Learn more with Vector ML Analytics, a leader in data analytics
							and risk management.
						</p>
					</div>
					<div className="col-lg-8">
						<div className="row">
							<div className="col-sm-4">
								<a href="/blogs/0">Impact of COVID on Credit risk Analytics</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/1">Machine Learning Applications in Lending</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/2">Automated Machine Learning</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/3">
									What is Credit Risk and Why is it Important?
								</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/4">Financial and Regulatory Reporting</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/5">Scorecard – Credit Engine</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/6">Prepayment Analytics</a>
							</div>
							<div className="col-sm-4">
								<a href="/blogs/7">Buy Now Pay Later</a>
							</div>
							{/*<div className="col-sm-4">
								<a href="/blogs/8">CECL & IFRS9</a>
							</div>*/}
						</div>
					</div>
					{extra && (
						<div className="col-lg-12 platform_list_container">
							<ul className="platform_list">
								<li>
									<p>
										Quickly analyze the balance sheet and load multiple
										portfolios simultaneously.
									</p>
								</li>
								<li>
									<p>
										Run scenario analysis with control of interest rates,
										prepayments, defaults, and specific variables.
									</p>
								</li>
								<li>
									<p>
										Build complex models and create custom assumption curves
										into user-defined asset groups.
									</p>
								</li>
								<li>
									<p>
										Compare historical performance trends across a spectrum of
										user-defined queries.
									</p>
								</li>
								<li>
									<p>
										Generate, review, and export asset and liability cash flows,
										as well as a full suite of analytics.
									</p>
								</li>
							</ul>
						</div>
					)}
				</div>
			</div>
		</section>
	);
};

export default InsightsBlock;
