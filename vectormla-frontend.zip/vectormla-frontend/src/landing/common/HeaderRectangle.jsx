import React from 'react';

const HeaderRectangle = ({
	header,
	last_update,
	description,
	other_lines,
	p2,
	p3,
	p4,
	p5,
	p6,
	p7,
	p8,
	p9,
	p10,
	p11,
	p12,
	p13,
	p14,
	p15,
	p16,
	p17,
	p18,
	p19,
	p20,
	p21
}) => {
	return (
		<div className="headerContainer">
			<h1 className="demo_top_header">{header}</h1>
			{last_update ? <h3 className="demo_thank_you">{last_update}</h3> : ''}
			<p className="demo_thank_you">{description}</p>
			{p2 ? <p className="demo_thank_you">{p2}</p> : ''}
			{p3 ? <p className="demo_thank_you">{p3}</p> : ''}
			{p4 ? <p className="demo_thank_you">{p4}</p> : ''}
			{p5 ? <p className="demo_thank_you">{p5}</p> : ''}
			{p6 ? <p className="demo_thank_you">{p6}</p> : ''}
			{p7 ? <p className="demo_thank_you">{p7}</p> : ''}
			{p8 ? <p className="demo_thank_you">{p8}</p> : ''}
			{p9 ? <p className="demo_thank_you">{p9}</p> : ''}
			{p10 ? <p className="demo_thank_you">{p10}</p> : ''}
			{p11 ? <p className="demo_thank_you">{p11}</p> : ''}
			{p12 ? <p className="demo_thank_you">{p12}</p> : ''}
			{p13 ? <p className="demo_thank_you">{p13}</p> : ''}
			{p14 ? <p className="demo_thank_you">{p14}</p> : ''}
			{p15 ? <p className="demo_thank_you">{p15}</p> : ''}
			{p16 ? <p className="demo_thank_you">{p16}</p> : ''}
			{p17 ? <p className="demo_thank_you">{p17}</p> : ''}
			{p18 ? <p className="demo_thank_you">{p18}</p> : ''}
			{p19 ? <p className="demo_thank_you">{p19}</p> : ''}
			{p20 ? <p className="demo_thank_you">{p20}</p> : ''}
			{p21 ? <p className="demo_thank_you">{p21}</p> : ''}
			{other_lines
				? other_lines.map((item, i) => (
						<p key={i} className="demo_other_p">
							{item}
						</p>
				  ))
				: ''}
		</div>
	);
};

export default HeaderRectangle;
