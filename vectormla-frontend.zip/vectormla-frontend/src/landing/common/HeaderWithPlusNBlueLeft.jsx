import React from 'react';
const HeaderWithBlueLeft = ({ header, description }) => {
	return (
		<div className="blue_rect_header">
			<p className="blue_rect_header_h1">{header}</p>
			{description ? <p className="blue_rect_header_p">{description}</p> : ''}
		</div>
	);
};

export default HeaderWithBlueLeft;
