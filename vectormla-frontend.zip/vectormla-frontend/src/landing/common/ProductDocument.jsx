import React, { useState, Fragment } from 'react';
import loanstreet from '../../common/assets/images/productdocument201.webp';
import buyNowPayLaterLogo from '../../common/assets/images/buyNowPayLaterLogo.webp';
import vectorProductDoc from '../../common/assets/images/VectorMLPlatformLatest.pdf';
import BNPLModelingMethodology from '../../common/assets/images/BNPLModelingMethodology.pdf';
const ProductDocument = ({
	description,
	header,
	shortDescription,
	shortTitle
}) => {
	const [formData, setFormData] = useState({
		first_name: '',
		last_name: '',
		company: '',
		email: ''
	});

	const productInformation = [
		{
			title: '',
			description: shortDescription
				? shortDescription
				: 'The Loan Portfolio Cash Flow Forecast & Analytics offers in-depth cash flow projections accounting for defaults and prepayments, essential for financial planning and interest risk management. It also supports Investor & Warehouse Securitization Reporting with comprehensive pool analysis and aids in Loan Pricing & Scenario Optimization to maintain a balance between profitability and risk.'
		}
	];
	const handleChange = (e) => {
		const { name, value } = e.target;
		setFormData((prev) => ({ ...prev, [name]: value }));
	};

	const showToast = (message) => {
		const toastContainer = document.getElementById('toastContainer');
		const toastMessage = document.createElement('div');
		toastMessage.classList.add('toast-message');
		toastMessage.textContent = message;

		toastContainer.appendChild(toastMessage);

		toastMessage.addEventListener('animationend', () => {
			setTimeout(() => {
				toastMessage.remove();
			}, 1000);
		});
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
		if (!emailRegex.test(formData.email)) {
			showToast('Please enter a valid email address.');
			return;
		}

		try {
			const response = await fetch(
				'https://vmlanalytics.com/api/dldocs/document1/',
				{
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(formData)
				}
			);

			if (response.ok) {
				console.log('POST request sent successfully');
			} else {
				throw new Error('Make sure all fields are filled.');
			}
		} catch (error) {
			throw new Error('Make sure all fields are filled.');
		}

		const link = document.createElement('a');
		link.href =
			shortTitle === 'Buy Now Pay Later'
				? BNPLModelingMethodology
				: vectorProductDoc;
		link.download =
			shortTitle === 'Buy Now Pay Later'
				? 'BNPL Modeling Methodology'
				: 'Vector Product Doc.pdf';
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
	};

	return (
		<div className="mainContainer">
			<section className="platform" style={{ marginTop: '-20px' }}>
				<div
					className={
						shortTitle === 'Buy Now Pay Later'
							? 'container subContainer99'
							: 'container subContainer9'
					}
				>
					<div className="blogListContainer">
						<div className="guideContainer">
							<div className={description ? 'guideLeft' : 'guideLeft'}>
								<div className="loanstreetContainer">
									<img
										className="loanstreetImage"
										src={
											shortTitle === 'Buy Now Pay Later'
												? buyNowPayLaterLogo
												: loanstreet
										}
										alt="loanstreet"
										width="390px"
										height="230px"
									/>
									<div className="imageFormComponent">
										<form onSubmit={handleSubmit}>
											<div
												className={
													description
														? 'blogFirstLastnameContainer'
														: 'blogFirstLastnameContainer'
												}
											>
												<input
													className="resources-first-name"
													type="text"
													placeholder="First name*"
													name="first_name"
													required
													onChange={handleChange}
													value={formData.first_name}
												/>
												<input
													className="resources-last-name"
													type="text"
													placeholder="Last name*"
													name="last_name"
													required
													onChange={handleChange}
													value={formData.last_name}
													style={{ marginTop: '0.2rem' }}
												/>
											</div>
											<div className="resourcesContainer">
												<input
													type="text"
													placeholder="Company name*"
													className="resources-company-name"
													name="company"
													required
													onChange={handleChange}
													value={formData.company}
												/>
												<div className="emailDownloadContainer">
													<input
														type="text"
														placeholder="Enter your email*"
														className="resources-email"
														name="email"
														required
														onChange={handleChange}
														value={formData.email}
													/>

													<button
														type="submit"
														className="resources-email-button"
													>
														Download
													</button>
												</div>
											</div>
										</form>
									</div>
								</div>
								<div
									className={
										description
											? 'loanstreetTextContainer'
											: 'loanstreetTextContainer'
									}
								>
									<div
										className={
											header ===
											'Vector ML Analytics, the AutoCAD of financial modeling for banks and lenders: Unlocking the next generation of financial planning and forecasting platforms powered by Object-Oriented Design (OOD)'
												? 'loanstreetTextHeader2'
												: 'loanstreetTextHeader'
										}
									>
										<strong
											style={{
												fontSize:
													header ===
													'Vector ML Analytics, the AutoCAD of financial modeling for banks and lenders: Unlocking the next generation of financial planning and forecasting platforms powered by Object-Oriented Design (OOD)'
														? '17px'
														: '32px',
												lineHeight: '2px',
												color: '#1c486e'
											}}
										>
											{header ? shortTitle : 'Product Document'}
										</strong>
									</div>
									<ul className={description ? 'asset_list2' : 'asset_list2'}>
										{productInformation.map((item, index) => (
											<React.Fragment key={index}>
												<li>
													<p
														className={
															shortTitle === 'Buy Now Pay Later'
																? 'blogTitleAssetBnpl'
																: 'blogTitleAsset'
														}
													>
														<strong>{item.title}</strong>
													</p>
												</li>
												<li
													className={
														shortTitle === 'Buy Now Pay Later'
															? 'no-bullet-bnpl'
															: 'no-bullet'
													}
												>
													<p
														className={
															description
																? 'blogDescriptionAsset'
																: 'blogDescriptionAsset'
														}
														style={{ lineHeight: description ? '21px' : '' }}
													>
														{item.description}
													</p>
												</li>
											</React.Fragment>
										))}
									</ul>
								</div>
							</div>
							<div className="guideRight widerFormComponent">
								<form onSubmit={handleSubmit}>
									<div
										className={
											description
												? 'blogFirstLastnameContainer'
												: 'blogFirstLastnameContainer'
										}
									>
										<input
											className="resources-first-name"
											type="text"
											placeholder="First name*"
											name="first_name"
											required
											onChange={handleChange}
											value={formData.first_name}
										/>
										<input
											className="resources-last-name"
											type="text"
											placeholder="Last name*"
											name="last_name"
											required
											onChange={handleChange}
											value={formData.last_name}
											style={{ marginTop: '0.2rem' }}
										/>
									</div>
									<div
										className="resourcesContainer"
										style={{ marginBottom: '200px' }}
									>
										<input
											type="text"
											placeholder="Company name*"
											className="resources-company-name"
											name="company"
											required
											onChange={handleChange}
											value={formData.company}
										/>
										<div className="emailDownloadContainer">
											<input
												type="text"
												placeholder="Enter your email*"
												className="resources-email"
												name="email"
												required
												onChange={handleChange}
												value={formData.email}
											/>

											<button type="submit" className="resources-email-button">
												Download
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</section>
		</div>
	);
};

export default ProductDocument;
