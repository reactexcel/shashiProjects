export const fpna = [
	'Financial Statements Projections',
	'Cash Flow Forecasting',
	'Liquidity and Capital Planning',
	'Pricing & Profitability Analysis',
	'Prepayment Analysis',
	'Regulatory Reporting',
	'Scenario Planning'
];

export const creditRisk = [
	'Static and Dynamic Loss',
	'Vintage Analysis',
	'Delinquency Migration',
	'EL, PD, LGD, EAD',
	'DF Timing Curve',
	'CECL & IFRS 9',
	'Stress Testing',
	'Compliance Monitoring'
];

export const alm = [
	'Interest Rate Risk',
	'Net Interest Income (NII)',
	'Economic Value of Equity (EVE)',
	'Duration Gap Analysis',
	'Stress Testing',
	'Loan Valuation',
	'Hedging'
];

export const debtCapitalMarkets = [
	'Securitization Reporting',
	'Portfolio Surveillance',
	'Warehouse Monitoring',
	'ABS Rating Methodology',
	'WH Optimization of Triggers',
	'Borrowing Base & Waterfall Reporting'
];

export const clients = [
	'Banks',
	'Credit Unions',
	'Fintech',
	'Issuers',
	'Originators',
	'Other Non-Banks'
];

export const assetClasses = [
	'Auto Loans',
	'Consumer Loans',
	'Residential Mortgages',
	'Commercial Mortgages',
	'Credit Cards',
	'Small Businesses',
	'Student Loans'
];

export const innovations = [
	'AutoML',
	'AI',
	'Algorithms',
	'Automation',
	'Security',
	'API',
	'AWS Cloud Native'
];

export const support = [
	'Support Overview',
	'Platform Updates',
	'Manage Products and Account Information',
	'API Library',
	'Documentation',
	'Remote Access and Mobile',
	'FAQ'
];
