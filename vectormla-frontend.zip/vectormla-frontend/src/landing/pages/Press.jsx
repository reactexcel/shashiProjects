import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import PagesSubHeader from '../common/PagesSubHeader';
import pressDetails from '../data/pressDetails.json';
import press from '../data/press.json';
import PressContent from '../common/PressContent';
import new_home_slider from '../../common/assets/images/new_home_slider.svg';
import screen_home9 from '../../common/assets/images/screen_home9.svg';
import BlogContent from '../common/BlogContent';

const Press = () => {
	const [openModal, setOpenModal] = useState(false);
	const [itemKey, setItemKey] = useState(
		window.location.href.split('press/')[1]
	);
	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="home_other_pages">
				<div className="container cont home_cont">
					<div className="row">
						<div className="col-10 col-sm-6 left_cont">
							<h3>Press</h3>
						</div>
						<div
							className="col-sm-6 right_cont img-fluid right-img"
							style={{ zIndex: 0, height: 630 }}
						></div>
					</div>
				</div>
			</section>
			<div className="mainContainer">
				<section className="request_form career_details">
					<div className="container subContainer2">
						<div className="row">
							<div className="col">
								{!itemKey ? (
									press.map((item, i) => (
										<PagesSubHeader
											key={i}
											style={{ marginBottom: 30, cursor: 'pointer' }}
											header={item.header}
											description={item.p}
											onClick={() => window.open(`/press/${i}`, '_self')}
										/>
									))
								) : (
									<PagesSubHeader
										style={{ marginBottom: 30 }}
										header={press[itemKey].header}
										description={press[itemKey].p}
									/>
								)}
								{itemKey && (
									<BlogContent
										imgs={[]}
										style={{}}
										data={pressDetails[itemKey]}
									/>
								)}
							</div>
						</div>
					</div>
				</section>
				<PressContent />
			</div>
			<MainFooter />
		</>
	);
};

export default Press;
