import React from 'react';
import { makeStyles } from '@material-ui/core';
import { InputLabel, FormHelperText } from '@material-ui/core';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';

const useStyles = makeStyles(() => ({
	root: {
		width: '100%',
		margin: '10px auto',
		'& label.Mui-focused': {
			color: '#2E628D'
		},
		'& .MuiOutlinedInput-root': {
			'&.Mui-focused fieldset': {
				borderColor: '#2E628D'
			}
		}
	}
}));

const MuiSelectField = ({
	label,
	input,
	children,
	meta: { touched, invalid, error }
}) => {
	const classes = useStyles();

	return (
		<FormControl
			variant="outlined"
			className={classes.root}
			error={touched && invalid}
		>
			<InputLabel>{label}</InputLabel>
			<Select label={label} {...input}>
				{children}
			</Select>

			<FormHelperText>{touched && error}</FormHelperText>
		</FormControl>
	);
};

export default MuiSelectField;
