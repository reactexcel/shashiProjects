import React, { useState } from 'react';
import Header from '../header/Header';
import MainFooter from '../footer/MainFooter';
import screen_home9 from '../../common/assets/images/screen_home9.svg';
import funder from '../../common/assets/images/vector_funder.jpg';
import funder2 from '../../common/assets/images/funder29.avif';
import zoom from '../../common/assets/images/zoom.png';
import { Grid, Typography, Box } from '@material-ui/core';
import { Badge, withStyles } from '@material-ui/core';
import Avatar from '@material-ui/core/Avatar';
const Investors = () => {
	const [openModal, setOpenModal] = useState(false);

	if (openModal) {
		return (
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
		);
	}
	const StyledBadge = withStyles((theme) => ({
		badge: {
			right: '40%',
			top: '40%',
			minWidth: '20px',
			height: '20px',
			borderRadius: '50%',
			backgroundColor: theme.palette.primary.main,
			color: theme.palette.common.white,
			fontWeight: 'bold',
			border: `2px solid ${theme.palette.background.paper}`,
			boxShadow: `0 0 0 2px ${theme.palette.background.paper}, 0 1px 4px rgba(0,0,0,.3)`
		}
	}))(Badge);

	return (
		<>
			<Header
				clickHandler={(value) => {
					setOpenModal(value);
				}}
			/>
			<section className="home_other_pages">
				<div className="container cont home_cont">
					<div className="row">
						<div className="col-10 col-sm-6 left_cont">
							<h3>Investors</h3>
						</div>
						<div
							className="col-sm-6 right_cont img-fluid right-img"
							style={{ zIndex: 0, height: 630 }}
						></div>
					</div>
				</div>
			</section>

			<div className="mainContainer">
				<section>
					<div
						className="container subContainer2"
						style={{ height: 'max-content' }}
					>
						<div
							style={{
								display: 'flex',
								justifyContent: 'center',
								alignItems: 'center',
								// height: '60vh',
								padding: '',
								height: 'max-content'
							}}
						>
							<img
								src={funder}
								style={{ width: '100%', height: '100% ', borderRadius: '10px' }} // Fixed size, you can adjust these values to your preference
								alt=" "
								className="img-fluid right-img4"
							/>
						</div>

						<div className="row" style={{ padding: '10px 50px' }}>
							<div className="col" style={{ fontSize: '20px' }}>
								<br />
								<p style={{ fontSize: '30px' }}>
									Invest in Vector ML Analytics
								</p>
								<br />
								<p style={{ fontSize: '20px' }}>
									Vector uses AI to build financial models for banks. The
									platform replaces numerous Excel models used by CFOs. Now is
									the critical time to act given the current banking crisis, the
									situation with SVB Bank, extreme interest rate volatility, and
									the ongoing AI revolution, all of which create an environment
									ready for disruption and innovation in the financial sector.
								</p>
								<br />
								<p>
									<b>Why Invest in Vector:</b>
								</p>
								<p>
									{
										"Vector is not just a startup; it's well-established, venture-backed & revenue-generating with a solid pipeline. We're at a pivotal growth juncture and would like to invite you to participate in the crowdfunding round."
									}
								</p>
								<ul>
									<li>Secured 600K from Silicon Valley VCs</li>
									<li>Outstanding Lifetime Value (LTV) at 550K</li>
									<li>Delivered a 500% growth rate year-over-year</li>
									<li>Estimated pipeline of 1M ARR</li>
								</ul>
								<p>
									Investment Opportunity: Join our growth journey on
									<a
										href="https://wefunder.com/vectormlanalytics/?utm_source=EmailOct&utm_medium=email&utm_campaign=Wefunder"
										target="_blank"
										rel="noopener noreferrer"
									>
										{' Wefunder '}
									</a>
									with investments starting at just $250. We look forward for
									your participation.
								</p>
								<br />
								<div
									style={{
										display: 'flex',
										justifyContent: 'center',
										marginTop: '2px',
										marginBottom: '25px',
										width: 'max-content', // Ensures the div is only as wide as its content
										marginRight: 'auto'
									}}
								>
									<a
										href="https://wefunder.com/vectormlanalytics/?utm_source=VMLWeb&utm_medium=VMLA&utm_campaign=Webs"
										target="_blank"
										rel="noreferrer"
									>
										<button
											style={{
												backgroundColor: '#FF5B5B',
												color: 'white',
												fontSize: '16px',
												border: 'none',
												padding: '15px 100px',
												borderRadius: '1px',
												textAlign: 'center',
												cursor: 'pointer',
												transition: '0.3s'
											}}
										>
											INVEST
										</button>
									</a>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section style={{ paddingTop: '30px' }}>
					<div className="container subContainer2">
						<div
							className="row"
							style={{ padding: '10px 50px', marginLeft: '-5px' }}
						>
							<div className="col" style={{ fontSize: '20px' }}>
								<p style={{ fontSize: '30px' }}>Investment Webinar</p>
								<h4 style={{ fontSize: '15px' }}>
									<img
										src="logo.svg"
										alt="Vector ML Analytics Logo"
										style={{
											width: '30px',
											height: '30px',
											marginRight: '10px',
											verticalAlign: 'middle'
										}}
									/>
									Hosted by Vector ML Analytics
								</h4>
							</div>
						</div>
						<div
							className="col"
							style={{
								fontSize: '10px',
								marginLeft: '5px',
								padding: '10px 50px'
							}}
						>
							<br />
							<div
								style={{
									display: 'flex',
									alignItems: 'center'
								}}
							>
								<Box
									border={1}
									borderRadius={5}
									borderColor="grey.400"
									width={60}
									height={70}
									boxShadow={2}
									display="flex"
									flexDirection="column"
									alignItems="center"
									justifyContent="center"
									marginRight="40px"
								>
									<Typography
										variant="caption"
										style={{ fontWeight: 'bold', color: 'grey.600' }}
									>
										NOV
									</Typography>
									<Typography variant="h4" style={{ fontWeight: 'bold' }}>
										29
									</Typography>
								</Box>
								<p
									style={{
										marginLeft: '-30px',
										fontSize: '20px',
										marginTop: '-6px'
									}}
								>
									{'Wednesday, November 29'}
								</p>
								<div
									className="col"
									style={{ fontSize: '10px', marginLeft: '70px' }}
								>
									<br />
									<div style={{ display: 'flex', alignItems: 'center' }}>
										<img src={zoom} alt="zoom-meeting" className="right-img4" />
										<p style={{ fontSize: '15px', marginTop: '20px' }}>Zoom</p>
									</div>
								</div>
							</div>
							<div style={{ display: 'flex', alignItems: 'center' }}>
								<p className="meeting-time">2:00 PM to 3:00 PM EST</p>
							</div>
						</div>
						<div
							style={{
								display: 'flex',
								justifyContent: 'center',
								marginTop: '100px',
								marginBottom: '25px',
								width: 'max-content', // Ensures the div is only as wide as its content
								marginLeft: '55px'
							}}
						>
							<a
								href="https://lu.ma/vector_nov29?utm_source=VMLWeb"
								target="_blank"
								rel="noreferrer"
							>
								<button
									style={{
										backgroundColor: '#3A7BFF',
										color: 'white',
										fontSize: '16px',
										border: 'none',
										padding: '15px 100px',
										borderRadius: '1px',
										textAlign: 'center',
										cursor: 'pointer',
										transition: '0.3s'
									}}
								>
									Register
								</button>
							</a>
						</div>
						<div style={{ marginLeft: '55px', marginTop: '40px' }}>
							<p>
								<b>Sadeq Safarini | CEO - Vector ML Analytics</b>
							</p>
							<p>420 Lexington Avenue, New York, NY 10170</p>
							<p>
								Email:{' '}
								<a href="mailto:ssafarini@vmlanalytics.com">
									ssafarini@vmlanalytics.com
								</a>
							</p>
							<p>
								Website:{' '}
								<a
									href="http://www.vmlanalytics.com"
									target="_blank"
									rel="noopener noreferrer"
								>
									www.vmlanalytics.com
								</a>
							</p>
						</div>
					</div>
				</section>
			</div>
			<MainFooter />
		</>
	);
};

export default Investors;
