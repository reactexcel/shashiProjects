import axios from 'axios';
import { API } from '../config/EnvironmentConfig';
import { toast } from 'react-toastify';

export const adminLogin = async (credentials, callback) => {
	const res = await axios.post(`${API}auth/login`, {
		...credentials,
		admin: true
	});
	localStorage.setItem('user', res.data);
	return callback();
};

export const getCompanies = async (callback) => {
	const session = localStorage.getItem('user');
	return axios
		.get(`${API}admin/company/`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};

export const createCompany = (data, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.post(`${API}admin/company/`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};
export const updateCompany = (id, data, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.put(`${API}admin/company/?id=${id}`, data, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};

export const deleteCompany = (id, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.delete(`${API}admin/company/?id=${id}`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};

export const getUser = (id, callback) => {
	const session = localStorage.getItem('user');

	return axios
		.get(`${API}user/retrieve?id=${id}`, {
			headers: {
				Authorization: `Token ${session}`
			}
		})
		.then((res) => callback(res.data))
		.catch((err) => {
			if (err.response.status >= 400) {
				// Toastify
				toast.warn(Object.values(err.response.data)[0][0], {
					autoClose: 5000
				});
			}
		});
};
