import React, { useEffect, useState } from 'react';
import { Grid, Button } from '@material-ui/core';
import ContentTable from '../../../common/components/table/ContentTable';
import { companyFields, adminFields } from './fields';
import PanelModal from '../../../common/components/fields/PanelModal';
import { useStyles } from './adminHomeStyles';
import {
	getCompanies,
	updateCompany,
	deleteCompany,
	createCompany,
	getUser
} from '../../services';
import { logout } from 'app/store/actions/auth.action';
import { useDispatch } from 'react-redux';
import { withRouter } from 'react-router-dom/cjs/react-router-dom.min';

const AdminHome = ({ history }) => {
	const classes = useStyles();
	const [open, setOpen] = useState(false);
	const session = localStorage.getItem('user');
	const [selected, setSelected] = useState({});
	const [modalState, setModalState] = useState('newCompany');
	const dispatch = useDispatch();

	const [companies, setCompanies] = useState(null);

	const handleClickOpen = () => {
		setModalState('newCompany');
		setOpen(true);
	};

	const handleClose = () => setOpen(false);

	const handleDelete = (clickedID) => {
		const selectedItem = companies.filter((c) => c.id === clickedID)[0];
		setSelected(selectedItem);
		deleteCompany(selectedItem.id, () => {
			getCompanies((res) => {
				setCompanies(res);
			});
		});
	};

	const handleEditCompany = (clickedID) => {
		setModalState('editCompany');

		const selectedItem = companies.filter((c) => c.id === clickedID)[0];
		setSelected(selectedItem);
		setOpen(true);
	};

	const updateCompanyData = (data) => {
		updateCompany(selected.id, data, () => {
			setOpen(false);
			getCompanies((res) => setCompanies(res));
		});
	};

	const handleAddAdmin = (clickedID) => {
		setModalState('editAdmin');
		const selectedItem = companies.filter((c) => c.id === clickedID)[0];
		if (selectedItem.admin_id != -1)
			getUser(selectedItem.admin_id, (res) => {
				let response = res[0];
				response.id = selectedItem.id;
				delete response.date_joined;
				setSelected(response);
				setOpen(true);
			});
		else {
			setSelected({ id: selectedItem.id });
			setOpen(true);
		}
	};

	useEffect(() => {
		if (!companies && session) {
			getCompanies((res) => setCompanies(res));
		}
	}, [companies]);

	const signOut = () => {
		dispatch(
			logout(() => {
				history.push({
					pathname: '/adminpanel/login'
				});
			})
		);
	};

	useEffect(() => {
		if (!session) history.push('/adminpanel/login');
	}, [session]);

	return (
		<div>
			<div
				onClick={signOut}
				style={{ position: 'fixed', top: 10, right: 45, cursor: 'pointer' }}
			>
				<a style={{ color: '#007bff' }}>Logout</a>
			</div>
			<Grid
				container
				className={classes.appContentContainer}
				style={{ marginTop: 20 }}
				justify="center"
			>
				<Grid item xs={11}>
					{
						<ContentTable
							data={companies}
							title={'Companies'}
							handleDelete={handleDelete}
							handleEdit={handleEditCompany}
							editText={'Edit Company'}
							handleEdit2={handleAddAdmin}
							editText2={'Edit Company Admin'}
							editable
							header={[
								{ label: 'Company Id', name: 'id' },
								{ label: 'Name', name: 'name' },
								{ label: 'Description', name: 'description' },
								{ label: 'Allowed Pages', name: 'allowed_pages' },
								{ label: 'Company Link', name: 'link' },
								{ label: 'Admin Id', name: 'admin_id' },
								{ label: 'Status', name: 'isActive' },
								{ label: 'Joined Date', name: 'date_joined' },
								{ label: 'Expired Date', name: 'date_expired' },
								{ name: 'actions' }
							]}
						/>
					}
					<PanelModal
						selected={selected}
						open={open}
						fields={
							['editCompany', 'newCompany'].includes(modalState)
								? companyFields
								: adminFields
						}
						handleClose={handleClose}
						initialValues={
							['editCompany', 'newCompany'].includes(modalState)
								? selected
								: null
						}
						create={
							['editCompany', 'newCompany'].includes(modalState)
								? (data, callback) => {
										createCompany(data, () => {
											callback();
											getCompanies((res) => {
												setCompanies(res);
											});
										});
								  }
								: updateCompanyData
						}
						isComapny={['editCompany', 'newCompany'].includes(modalState)}
						edit
						update={updateCompanyData}
					/>
					<Grid>
						<Button
							style={{ float: 'right', marginTop: 30 }}
							className={classes.header__save}
							onClick={handleClickOpen}
						>
							Add Company
						</Button>
					</Grid>
				</Grid>
			</Grid>
		</div>
	);
};

export default withRouter(AdminHome);
