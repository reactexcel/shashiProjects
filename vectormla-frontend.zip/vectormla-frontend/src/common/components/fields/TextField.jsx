import React from 'react';
import { OutlinedInput, Typography, makeStyles } from '@material-ui/core';

const create__input = {
	width: '100%',
	borderRadius: 0,
	height: 25,
	fontSize: '11px',
	fontFamily: 'Roboto',
	fontWeight: 500,
	lineHeight: '1.18em',
	background: '#f7f8fa',
	color: 'rgba(0, 0, 0, 0.87)'
};
const useStyles = makeStyles((theme) => ({
	create__input,
	create__input_date: {
		...create__input,
		position: 'relative',
		top: '-24px'
	}
}));

const RenderInputField = ({
	required = true,
	input,
	name,
	type,
	disabled,
	placeholder,
	value,
	defaultValue,
	onChange,
	label
}) => {
	const classes = useStyles();

	return (
		<>
			{(type === 'datetime-local' || label) && (
				<Typography style={{ position: 'relative', top: label ? 0 : -24 }}>
					{placeholder}
				</Typography>
			)}
			<OutlinedInput
				disabled={disabled}
				required={required}
				className={
					type === 'datetime-local'
						? classes.create__input_date
						: classes.create__input
				}
				name={name}
				type={type}
				placeholder={placeholder}
				{...input}
				value={value}
				defaultValue={defaultValue}
				onChange={onChange}
			/>
		</>
	);
};

export default RenderInputField;
