import { makeStyles } from '@material-ui/core';
import {
	blueColor,
	contentHeader,
	contentHeaderContainer,
	darkBlueColor
} from '../../assets/layout';

export const useStyles = makeStyles((theme) => ({
	create: {
		position: 'relative',
		'& .MuiDialog-paperScrollPaper': {
			minHeight: 250
		}
	},
	create__body: {
		padding: '10px 25px 50px',
		marginBottom: 20
	},
	create__form: {
		width: '100%'
	},
	create__button: {
		textTransform: 'capitalize',
		backgroundColor: `${blueColor} !important`,
		color: '#FFF !important',
		width: 100,
		borderRadius: 1,
		margin: '30px 0px 30px',
		float: 'right',
		'&:hover': {
			backgroundColor: darkBlueColor
		}
	},
	create__close: {
		position: 'absolute',
		top: 10,
		right: 10
	},
	section_Main_container: {
		padding: '0px 20px'
	},
	section_title: {
		borderBottom: '4px solid #266696',
		padding: '10px 0px',
		fontSize: '13px',
		fontFamily: 'Roboto',
		fontWeight: 'bold'
	},
	sub_section_title: {
		marginTop: '8px',
		flex: 9,
		fontSize: '10px',
		fontWeight: 500
	},
	contentHeaderContainer: {
		...contentHeaderContainer,
		borderBottom: '1px solid #e3e3e3'
	},
	contentHeader,
	collapseContainer: {
		width: '100%'
	},
	gridChild: {
		display: 'flex',
		alignItems: 'center',
		marginBottom: -10,
		gap: '10px',
		position: 'relative',
		'& .MuiInputBase-root': {
			width: '175px',
			top: '0px'
		},
		'&:last-of-type': {
			'& p:last-of-type': {
				display: 'none'
			}
		}
	},
	textStyle: {
		'& .MuiInputBase-root': {
			'& input': {
				color: 'rgba(0, 0, 0, 0.87)',
				padding: '5px 12px',
				width: '150px',
				fontSize: '11px',
				background: '#f7f8fa',
				fontFamily: 'Roboto',
				fontWeight: 500,
				lineHeight: '1.18em',
				borderRadius: 0,
				border: '1px solid rgba(190, 191, 192, 1)'
			}
		}
	},
	selectIcon: {
		width: 16,
		margin: '0 15px 0 10px',
		color: '#dbdcde',
		'&:hover': {
			cursor: 'pointer'
		}
	},
	label: {
		color: '#000',
		minWidth: 120,
		fontSize: '12px',
		fontFamily: 'Roboto'
	},
	selectField: {
		width: '175px',
		'& .MuiInputBase-root': {
			height: '25px'
		},
		'& .MuiSelect-root': {
			padding: '0px 13px 5px',
			'&:focus': {
				backgroundColor: 'transparent'
			}
		}
	}
}));
