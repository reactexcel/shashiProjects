import React, { useState, useEffect } from 'react';
import moment from 'moment';
import {
	Button,
	Dialog,
	DialogActions,
	DialogTitle,
	Divider,
	Grid,
	IconButton,
	Typography
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import TextField from './TextField';
import SelectField from './SelectField';
import { useStyles } from './styles';
import { DarkCheckbox } from 'app/CashFlow/cashFlowStyles';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import { sectionFields, tabsFields } from 'admin-panel/pages/AdminHome/fields';
import downArrow from '../../../common/assets/vector/images/arrow.svg';
import InfoIcon from '@material-ui/icons/Info';

const icon = <CheckBoxOutlineBlankIcon fontSize="small" />;
const checkedIcon = <CheckBoxIcon fontSize="small" />;

function PanelModal({
	open,
	handleClose,
	create,
	update,
	initialValues,
	fields,
	noDate,
	isComapny
}) {
	const classes = useStyles();
	const [states, setStates] = useState({});
	const [openCollapse, setOpenCollapse] = useState({
		finaicial: false,
		models: false,
		allowedModels: false
	});
	useEffect(() => {
		if (
			initialValues &&
			JSON.stringify(states) !== JSON.stringify(initialValues)
		)
			setStates(initialValues);
	}, [initialValues]);

	const submit = () => {
		// let allowedpages_arr = [];
		// remove date joined
		let values = states;
		delete values.date_joined;
		delete values.date_expired;

		if (!initialValues) {
			delete values.date_expired;
			delete values.id;
		} else {
			if (values.date_expired)
				values.date_expired = moment(values.date_expired).format('Y-m-d');
		}
		for (let i in values) {
			if (values[i] === null) {
				delete values[i];
			}
		}
		// values.allowed_pages = [1, 2, 3, 4, 5, 6].map(
		// 	(item) =>
		// 		values[`allowed_section${item}`] &&
		// 		values[`allowed_section${item}`]?.length !== 0 &&
		// 		allowedpages_arr.push(item)
		// );
		// values.allowed_pages = allowedpages_arr;
		initialValues && Object.keys(initialValues).length > 0
			? update(values, handleClose)
			: create(values, handleClose);
	};

	const handleCheck = (type, id) => {
		if (!states[type]?.includes(id))
			setStates({
				...states,
				[`${type}`]: [...new Set(states[type] || []), id]
			});
		else
			setStates({
				...states,
				[`${type}`]: [...new Set(states[type].filter((item) => item !== id))]
			});
	};

	return (
		<Dialog
			className={classes.create}
			fullWidth
			maxWidth="lg"
			open={open}
			onClose={handleClose}
		>
			<form className={classes.create__form}>
				<DialogTitle>
					{initialValues && Object.keys(initialValues).length > 0
						? 'Edit'
						: 'Add'}
				</DialogTitle>
				<div className={classes.create__body}>
					<Grid container justify="flex-start" spacing={0}>
						{/* Personal */}
						{fields.map((field, index) => (
							<Grid
								key={index}
								item
								// xs={4}
								direction="row"
								container
								justify="flex-start"
								spacing={2}
								style={{ marginBottom: 20 }}
							>
								{field.type === 'select' ? (
									<Grid item xs={12} className={classes.gridChild}>
										<Typography
											variant="subtitle2"
											align="left"
											className={classes.label}
										>
											Status
										</Typography>
										<InfoIcon className={classes.selectIcon} />

										<SelectField className={classes.selectField}>
											{field.items?.map((item) => (
												<option key={item.value} value={item.value}>
													{item.label}
												</option>
											))}
										</SelectField>
									</Grid>
								) : field.type === 'text' || field?.typeField === 'admin' ? (
									<Grid item xs={12} className={classes.gridChild}>
										<Typography
											variant="subtitle2"
											align="left"
											className={classes.label}
										>
											{field.placeholder}
										</Typography>
										<InfoIcon className={classes.selectIcon} />
										<TextField
											type={field.type || 'text'}
											name={field.name}
											variant="outlined"
											placeholder={field.placeholder}
											defaultValue={states[field.name]}
											onChange={(e) => {
												let data = states;
												data[field.name] = e.target.value;
												setStates(data);
											}}
											className={classes.textStyle}
										/>
									</Grid>
								) : field.type === 'date' ? (
									initialValues &&
									!noDate && (
										<Grid
											key="index"
											item
											xs={12}
											className={classes.gridChild}
										>
											<Typography
												variant="subtitle2"
												align="left"
												className={classes.label}
											>
												End Date
											</Typography>
											<InfoIcon className={classes.selectIcon} />
											<TextField
												name={'date_expired'}
												type="datetime-local"
												defaultValue={states['date_expired']}
												onChange={(e) => {
													let data = states;
													data['date_expired'] = e.target.value;
													setStates(data);
												}}
											/>
										</Grid>
									)
								) : (
									<></>
								)}
							</Grid>
						))}
						{isComapny && (
							<>
								<div className={classes.collapseContainer}>
									<div
										className={classes.contentHeaderContainer}
										onClick={() =>
											setOpenCollapse({
												...openCollapse,
												finaicial: !openCollapse?.finaicial
											})
										}
									>
										<p className={classes.contentHeader}>
											Financial Models Map
										</p>
										<img
											src={downArrow}
											style={{ justifyContent: 'flex-end' }}
											alt=""
										/>
									</div>
									{openCollapse?.finaicial && (
										<Grid
											style={{ margin: '10px 0px' }}
											item
											xs={12}
											container
											wrap="wrap"
										>
											{tabsFields.map((item) => {
												return (
													<Grid
														item
														xs={12}
														sm={4}
														md={4}
														key={item?.id}
														className={classes.section_Main_container}
													>
														<div style={{ display: 'flex' }}>
															{/* <DarkCheckbox
													icon={icon}
													checkedIcon={checkedIcon}
													name={item?.id}
													style={{ marginRight: '8px', flex: 1 }}
													checked={states?.allowed_pages?.includes(item?.id)}
													onChange={() => handleCheck('allowed_pages', item?.id)}
												/> */}
															<Typography
																style={{ marginTop: '8px', flex: 9 }}
																className={classes.section_title}
															>
																{item?.s_name}
															</Typography>
														</div>
														<div style={{ margin: '20px 0px' }}>
															{item?.list.map((itemList, indexx) => {
																return (
																	<div key={indexx} style={{ display: 'flex' }}>
																		<DarkCheckbox
																			icon={icon}
																			checkedIcon={checkedIcon}
																			style={{ marginRight: '8px', flex: 1 }}
																			checked={states[
																				`${item?.typeList}`
																			]?.includes(itemList?.id)}
																			onChange={() =>
																				handleCheck(
																					item?.typeList,
																					itemList?.id
																				)
																			}
																		/>
																		<Typography
																			className={classes.sub_section_title}
																		>
																			{itemList?.name}
																		</Typography>
																	</div>
																);
															})}
														</div>
													</Grid>
												);
											})}
										</Grid>
									)}
								</div>
								<Divider />
								<div className={classes.collapseContainer}>
									<div
										className={classes.contentHeaderContainer}
										onClick={() =>
											setOpenCollapse({
												...openCollapse,
												models: !openCollapse?.models
											})
										}
									>
										<p className={classes.contentHeader}>Models</p>
										<img
											src={downArrow}
											style={{ justifyContent: 'flex-end' }}
											alt=""
										/>
									</div>
									{openCollapse?.models && (
										<Grid
											style={{ margin: '10px 0px' }}
											item
											xs={12}
											container
											wrap="wrap"
										>
											{sectionFields.map((item) => {
												return (
													<Grid
														item
														xs={12}
														sm={6}
														md={3}
														key={item?.id}
														className={classes.section_Main_container}
													>
														<div style={{ padding: '0px 8px' }}>
															<Typography className={classes.section_title}>
																{item?.s_name}
															</Typography>
														</div>
														<div style={{ margin: '20px 0px' }}>
															{item?.list.map((itemList, indexx) => {
																return (
																	<div key={indexx} style={{ display: 'flex' }}>
																		<DarkCheckbox
																			icon={icon}
																			checkedIcon={checkedIcon}
																			style={{ marginRight: '8px', flex: 1 }}
																			checked={states[
																				`${item?.typeList}`
																			]?.includes(itemList?.id)}
																			onChange={() =>
																				handleCheck(
																					item?.typeList,
																					itemList?.id
																				)
																			}
																		/>
																		<Typography
																			className={classes.sub_section_title}
																			style={{ marginTop: '8px', flex: 9 }}
																		>
																			{itemList?.name}
																		</Typography>
																	</div>
																);
															})}
														</div>
													</Grid>
												);
											})}
										</Grid>
									)}
								</div>
								<Divider />
								<div className={classes.collapseContainer}>
									<div
										className={classes.contentHeaderContainer}
										onClick={() =>
											setOpenCollapse({
												...openCollapse,
												allowedModels: !openCollapse?.allowedModels
											})
										}
									>
										<p className={classes.contentHeader}>Allowed Models</p>
										<img
											src={downArrow}
											style={{ justifyContent: 'flex-end' }}
											alt=""
										/>
									</div>
									{openCollapse?.allowedModels && (
										<Grid
											style={{ margin: '10px 0px' }}
											item
											xs={12}
											container
											wrap="wrap"
										>
											{tabsFields.map((item) => {
												return (
													<Grid
														item
														xs={12}
														sm={4}
														md={4}
														key={item?.id}
														className={classes.section_Main_container}
													>
														<div style={{ display: 'flex' }}>
															<DarkCheckbox
																icon={icon}
																checkedIcon={checkedIcon}
																name={item?.id}
																style={{ marginRight: '8px', flex: 1 }}
																checked={states?.allowed_pages?.includes(
																	item?.id
																)}
																onChange={() =>
																	handleCheck('allowed_pages', item?.id)
																}
															/>
															<Typography
																style={{ marginTop: '8px', flex: 9 }}
																className={classes.section_title}
															>
																{item?.s_name}
															</Typography>
														</div>
													</Grid>
												);
											})}
										</Grid>
									)}
								</div>
							</>
						)}
					</Grid>
					<IconButton
						className={classes.create__close}
						onClick={handleClose}
						aria-label="close"
					>
						<CloseIcon />
					</IconButton>
					<Button
						className={classes.create__button}
						onClick={submit}
						variant="contained"
						color="primary"
					>
						{initialValues && Object.keys(initialValues).length > 0
							? 'Edit'
							: 'Add'}
					</Button>
				</div>
			</form>
		</Dialog>
	);
}

export default PanelModal;
