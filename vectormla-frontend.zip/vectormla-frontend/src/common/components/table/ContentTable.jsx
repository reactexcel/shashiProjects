import React, { useEffect, useState } from 'react';
import {
	Table,
	TableBody,
	TableCell,
	TableContainer,
	TableRow,
	Tooltip,
	Divider
} from '@material-ui/core';
import EditIcon from '@material-ui/icons/Edit';
import Autorenew from '@material-ui/icons/Autorenew';
import Switch from '@material-ui/core/Switch';

import CancelIcon from '@material-ui/icons/Cancel';
import { useStyles } from './contentTableStyles';
import downArrow from '../../assets/vector/images/arrow.svg';
import { mfaToggle } from 'app/services/adminService';

const pages = [
	'',
	'Treasury',
	'Credit Risk ',
	'Fpna',
	'Capital Markets',
	'Academy',
	'Dashboard'
];

const ContentTable = ({
	title,
	header,
	data,
	handleEdit,
	handleEdit2,
	handleDelete,
	handleResetPass,
	editable,
	editText,
	editText2,
	refreshData
}) => {
	const classes = useStyles();
	const [mfaState, setMfaState] = useState([]);

	const handleChange = (event, id) => {
		mfaToggle(id, () => {
			setMfaState(
				mfaState.map((i) =>
					i.id === id ? { ...i, status: event.target.checked ? 2 : 1 } : i
				)
			);
			refreshData();
		});
	};

	useEffect(() => {
		setMfaState(data ? data.map((i) => ({ status: i.status, id: i.id })) : []);
	}, [data]);

	const displayItem = (item, key) => {
		if (key === 'allowed_pages') {
			return item.map((i) => pages[i] + (i != item.length ? ' - ' : ''));
		}

		return item;
	};
	return (
		<>
			<div className={[classes.contentHeaderContainer]}>
				<p className={classes.contentHeader}>{title}</p>
				<img
					src={downArrow}
					style={{ justifyContent: 'flex-end' }}
					alt={title}
				/>
			</div>
			<Divider style={{ marginBottom: 20 }} />
			<TableContainer>
				<Table
					style={{
						border: '1px solid #D8DDE3',
						marginBottom: 10,
						width: '100%'
					}}
					className={classes.table}
				>
					<TableBody>
						<TableRow>
							{header.map((head, i) => (
								<TableCell
									className={classes.bodyCell}
									style={{ textAlign: 'center' }}
									key={i}
								>
									{head.label}
								</TableCell>
							))}
						</TableRow>
						{data &&
							data?.map((row, index) => (
								<TableRow
									className={
										index % 2 === 0
											? classes.table__row_lightGray
											: classes.table__row_white
									}
									key={index}
								>
									{header.map((item, i) =>
										item.name === 'actions' || item.name === 'admin_id' ? (
											<TableCell
												className={classes.bodyCell}
												style={{ textAlign: 'center' }}
												key={i}
											>
												{(editable ||
													(item.name === 'admin_id' && row[item.name])) && (
													<>
														{row[item.name] && `${row[item.name]}  `}
														<Tooltip
															title={
																item.name === 'admin_id'
																	? editText2
																	: editText || 'Edit'
															}
															style={{ cursor: 'pointer' }}
														>
															<EditIcon
																onClick={() =>
																	item.name === 'admin_id'
																		? handleEdit2(row.id)
																		: handleEdit(row.id)
																}
															/>
														</Tooltip>
													</>
												)}
												{!row.date_expired && !(item.name === 'admin_id') && (
													<Tooltip style={{ cursor: 'pointer' }} title="End">
														<CancelIcon onClick={() => handleDelete(row.id)} />
													</Tooltip>
												)}
											</TableCell>
										) : item.name === 'reset_pass' ? (
											<TableCell
												className={classes.bodyCell}
												style={{ textAlign: 'center' }}
												key={i}
											>
												<Tooltip style={{ cursor: 'pointer' }} title="Reset">
													<Autorenew
														onClick={() => {
															handleResetPass(row.id);
														}}
													/>
												</Tooltip>
											</TableCell>
										) : item.name === 'mfa_toggle' ? (
											<TableCell
												className={classes.bodyCell}
												style={{ textAlign: 'center' }}
												key={i}
											>
												<Switch
													checked={
														mfaState.find((i) => i?.id === row?.id)?.status !==
														0
													}
													onChange={(event) => handleChange(event, row?.id)}
													color="primary"
													name="checkedB"
													inputProps={{ 'aria-label': 'primary checkbox' }}
												/>
											</TableCell>
										) : (
											<TableCell
												className={classes.bodyCell}
												style={{ textAlign: 'center' }}
												key={i}
											>
												{row[item.name] === true
													? 'Active'
													: row[item.name] === false
													? 'Inactive'
													: displayItem(row[item.name], item.name)}
											</TableCell>
										)
									)}
								</TableRow>
							))}
					</TableBody>
				</Table>
			</TableContainer>
		</>
	);
};
export default ContentTable;
