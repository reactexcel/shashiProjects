import { createTheme } from '@material-ui/core';

// ==> Theme
export const theme = createTheme({
	typography: {
		fontFamily: 'Roboto'
	},
	overrides: {
		MuiCssBaseline: {
			'@global': {
				'@font-face': 'Roboto'
			}
		}
	}
});

export {};
