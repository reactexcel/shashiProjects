import React from 'react';
import { ThemeProvider } from '@material-ui/core';
import ReactDOM from 'react-dom';
import { ToastContainer } from 'react-toastify';
import { BrowserRouter, Route, Switch, Redirect } from 'react-router-dom';
import { theme } from './common/assets/appStyles';
import Landing from './landing/Landing';

import 'react-toastify/dist/ReactToastify.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './common/assets/vector/css/all.css';
import './common/assets/vector/css/style.css';
import 'bootstrap/dist/js/bootstrap.min.js';

import './common/assets/index.css';

import { Provider } from 'react-redux';
import { store } from 'app/store';
import PrivateRoute from 'routes-middleware/Private.route';

import Insights from 'landing/pages/Insights';
import Careers from 'landing/pages/Careers';
import CareerDetails from 'landing/pages/CareerDetails';
import Solutions from 'landing/pages/Solutions';
import HiddenPage1 from 'landing/pages/HiddenPage1';
import HiddenPage2 from 'landing/pages/HiddenPage2';
import HiddenPage3 from 'landing/pages/HiddenPage3';
import SecurityCommitment from 'landing/pages/SecurityCommitment';
import PrivacyPolicy from 'landing/pages/PrivacyPolicy';
import Support from 'landing/pages/Support';
import RequestDemo from 'landing/pages/RequestDemo';
import Privacy from 'landing/pages/Privacy';
import Blogs from 'landing/pages/Blogs';
import OTP from 'app/Login/OTP';
import App from './app';
import Login from 'app/Login/Login';
import AdminLogin from 'admin-panel/pages/AdminLogin';
import AdminHome from 'admin-panel/pages/AdminHome/AdminHome';

ReactDOM.render(
	<BrowserRouter>
		<ThemeProvider theme={theme}>
			<Provider store={store}>
				<Switch>
					<Route path="/adminpanel/home" component={AdminHome} />
					<Route path="/app" component={App} />
					{[
						{ path: '/request-demo', Component: RequestDemo },
						{ path: '/insights', Component: Insights },
						{ path: '/careers', Component: Careers },
						{ path: '/career_details', Component: CareerDetails },
						{ path: '/terms&conditions/1', Component: Privacy },
						{ path: '/blogs', Component: Blogs },
						{ path: '/solutions', Component: Solutions },
						{ path: '/nothingtosee', Component: HiddenPage1 },
						{ path: '/nothingtosee2', Component: HiddenPage2 },
						{ path: '/hiddenvectorlogo', Component: HiddenPage3 },
						// { path: '/hiddenvectorpitchdeck', Component: HiddenPage4 },
						// { path: '/investors', Component: Investors },
						// { path: '/press', Component: Press },
						// { path: '/team', Component: Team },
						{ path: '/securitycommitment', Component: SecurityCommitment },
						{ path: '/privacypolicy', Component: PrivacyPolicy },
						{ path: '/support', Component: Support },
						{ path: '/home', Component: Landing },
						{ path: '/OTP', Component: OTP },
						{ path: '/login', Component: Login },
						{ path: '/adminpanel/login', Component: AdminLogin },
						{ path: '/', Component: Landing }
					].map(({ path, Component }) => (
						<PrivateRoute
							key={path}
							path={path}
							component={Component}
							authPage={false}
						/>
					))}
					<Route path="*" render={() => <Redirect to="/" />} />
				</Switch>
				<ToastContainer hideProgressBar />
			</Provider>
		</ThemeProvider>
	</BrowserRouter>,
	document.getElementById('root')
);
