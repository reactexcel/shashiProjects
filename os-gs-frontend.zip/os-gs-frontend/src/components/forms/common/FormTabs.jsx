import React from "react";
import { Col } from "react-bootstrap";
import { Tabs } from "react-bootstrap";

class FormTabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      key: 1,
    };
  }

  handleSelect = (key) => {
    this.setState({ key }, () => {
      this.props.changeTabHandler(this.state.key);
    });
  };

  render() {
    const { tabsList, children } = this.props;

    return (
      <Col md={12}>
        <Tabs activeKey={this.state.key} onSelect={this.handleSelect}>
          {children}
        </Tabs>
      </Col>
    );
  }
}

export default FormTabs;
