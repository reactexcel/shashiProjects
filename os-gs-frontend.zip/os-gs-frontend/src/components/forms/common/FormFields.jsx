import React, { Fragment } from "react";
import { FormGroup, FormControl, ControlLabel, Col } from "react-bootstrap";
import RangeSlider from "react-bootstrap-range-slider";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { SketchPicker } from "react-color";
// import "semantic-ui-css/semantic.min.css";
import dotImage from "../../../assets/img/dots.png";
import roundedImage from "../../../assets/img/rounded.png";
import squareImage from "../../../assets/img/square.png";
import Select from "react-select";

export class TextInput extends React.Component {
  render() {
    const {
      input,
      meta,
      label,
      required,
      width,
      disabled,
      placeholder,
      type,
      defaultValue
    } = this.props;
    return (
      <Col md={width} sm={width}>
        <FormGroup>
          <ControlLabel>
            {label}
            {required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <FormControl
            {...input}
            disabled={defaultValue ? true : disabled}
            placeholder={placeholder}
            type={type}
          />
          {meta.touched && meta.error && (
            <small className="text-danger">{meta.error}</small>
          )}
        </FormGroup>
      </Col>
    );
  }
}

export class TextInputWithoutColumn extends React.Component {
    render() {
      const {
        input,
        meta,
        label,
        required,
        disabled,
        placeholder,
        type,
        defaultValue
      } = this.props;
      return (
          <FormGroup>
            <ControlLabel>
              {label}
              {required == true ? <span className="star">*</span> : null}
            </ControlLabel>
            <FormControl
              {...input}
              disabled={defaultValue ? true : disabled}
              placeholder={placeholder}
              type={type}
            />
            {meta.touched && meta.error && (
              <small className="text-danger">{meta.error}</small>
            )}
          </FormGroup>
      );
    }
  }


export class BasicInput extends React.Component {
  render() {
    const { input, meta, placeholder, type, disabled, width, defaultValue, label, required } = this.props;
    return (
      <Col md={width} sm={width}>
        <FormGroup>
          {defaultValue ?
            <ControlLabel>
            {label}
            {required == true ? <span className="star">*</span> : null}
          </ControlLabel> : null}
          <FormControl {...input} placeholder={placeholder} type={type} disabled={defaultValue ? true : disabled} />
          {meta.touched && meta.error && (
            <small className="text-danger">{meta.error}</small>
          )}
        </FormGroup>
      </Col>
    );
  }
}

export class RadioGroup extends React.Component {
  render() {
    const { input, disabled, label, value, currentValue } = this.props;
    let image = squareImage;
    if (value === "rounded") {
      image = roundedImage;
    } else if (value === "square") {
      image = squareImage;
    } else if (value === "dots") {
      image = dotImage;
    }

    return (
      <Col md={2} sm={2}>
        <div className="qr-code-format">
          <FormGroup>
            <ControlLabel>{label}</ControlLabel>
          </FormGroup>
          <div className="qr-code-format-image">
            <img src={image} alt="" />
          </div>
          <div className="qr-code-format-selection">
            <input
              {...input}
              inline
              disabled={disabled}
              checked={value === currentValue}
              type="radio"
              value={value}
            />
          </div>
        </div>
      </Col>
    );
  }
}

export class GroupButton extends React.Component {
  handleOnClick = (e) => {
    this.props.onClick(e.target.value);
  };

  render() {
    const { input, disabled, label, value, currentValue } = this.props;
    const classes = ["format-btn"];
    if (currentValue === value) {
      classes.push("active");
    }

    const className = classes.join(" ");
    return (
      <Button
        {...input}
        onClick={this.handleOnClick}
        className={className}
        disabled={disabled}
        value={value}
      >
        {label}
      </Button>
    );
  }
}

export class Range extends React.Component {
  render() {
    const { input, disabled, min, max } = this.props;
    return <RangeSlider {...input} disabled={disabled} min={min} max={max} />;
  }
}

export class ColorPicker extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showPicker: false,
      color: "#fff",
    };

    this.toggleColor = this.toggleColor.bind(this);
    this.handleChangeComplete = this.handleChangeComplete.bind(this);
  }

  toggleColor(e) {
    e.preventDefault();

    this.setState({
      showPicker: !this.state.showPicker,
    });
  }

  handleChangeComplete(color, event) {
    const { onColorChange } = this.props;
    this.setState({ color: color.hex });
    onColorChange(color.hex);
  }

  render() {
    const { input, meta, label, required, width, disabled } = this.props;
    return (
      <Col md={width} sm={width}>
        <FormGroup>
          <ControlLabel>
            {label}
            {required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <FormControl disabled={disabled} />
          {meta.touched && meta.error && (
            <small className="text-danger">{meta.error}</small>
          )}
          <SketchPicker {...input} />
        </FormGroup>
      </Col>
    );
  }
}

export class RenderSelect extends React.Component {
  onChange = (value) => {
    console.log(value);
  };

  render() {
    const {
      input,
      label,
      title,
      meta,
      items,
      width,
      required,
      disabled,
    } = this.props;
    let options;
    if (input.value && disabled) {
      options = [{
        value: input.value,
        label: input.value,
      }]
    } else if (input.value) {
      const elements = items.filter((item) => item !== input.value);
      options = items.map((item) => ({
        value: item,
        label: item,
      }));
    } else {
      options = items.map((item) => ({
        value: item,
        label: item,
      }));
    }

    const className = `field ${meta.error && meta.touched ? "error" : ""}`;
    return (
      <Col md={width} sm={width}>
        <FormGroup>
          <ControlLabel>
            {label}
            {required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <div>
            <Select
              {...input}
              onBlur={() => input.onBlur(input.value.value)}
              onChange={(e) => input.onChange(e.value)}
              value={{ value: input.value, label: input.value }}
              options={options}
              classNamePrefix="react-select"
              isDisabled={disabled}
            />
          </div>
          {renderError(meta)}
        </FormGroup>
      </Col>
    );
  }
}

export const renderError = ({ error, touched }) => {
  if (touched && error) {
    return <small className="text-danger">{error}</small>;
  }
};
