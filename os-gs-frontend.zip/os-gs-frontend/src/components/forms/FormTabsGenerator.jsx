import React from 'react';

export class FormTabsGenerator extends React.Component {
    render() {
        
    }
}