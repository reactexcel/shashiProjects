import React from "react";
import { Field } from "redux-form";
import { TextInput, RenderSelect } from "./common/FormFields";

export class FormFieldsGenerator extends React.Component {
  render() {
    const { list } = this.props;
    return list.map((item) => {
      switch (item.type) {
        case "text": {
          return (
            <Field
              required={item.required}
              type={item.type}
              key={item.name}
              name={item.name}
              label={item.label}
              width={item.width}
              disabled={item.disabled}
              component={TextInput}
            />
          );
        }
        case "dropdown": {
          return (
            <Field
              required={item.required}
              key={item.name}
              name={item.name}
              label={item.label}
              width={item.width}
              items={item.options}
              disabled={item.disabled}
              component={RenderSelect}
              title="Select"
            />
          );
        }
      }
    });
  }
}
