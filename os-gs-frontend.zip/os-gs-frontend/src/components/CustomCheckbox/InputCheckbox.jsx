import React, { Component } from "react";

class InputCheckbox extends Component {
  constructor(props, context) {
    super(props, context);
    this.selected = {};
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(event, optionID) {
    this.selected = this.selected || {};
    if (event.target.checked) {
      this.selected[optionID] = true;
    } else {
      delete this.selected[optionID];
    }
    console.log(this.selected);
    this.props.onChange({
      questionID: this.props.questionID,
      answerValues: Object.keys(this.selected)
    });
  }

  render() {
    const { name, label, options, inline} = this.props;
    const classes =
      inline !== undefined ? "checkbox checkbox-inline" : "checkbox";
    return (
      <div>
        {options.map(option => {
          return (
            <div className={classes} key={option.id}>
              <input
                name={name}
                id={`option-${option.id}`}
                type="checkbox"
                value={option.id}
                onChange={e => this.handleChange(e, option.id)}
              />{" "}
              <label htmlFor={`${name}-${option.id}`}>{option.value}</label>
            </div>
          );
        })}
      </div>
    );
  }
}

export default InputCheckbox;
