import React, { Component } from "react";
import InputCheckbox from "./InputCheckbox";

class FormQuestion extends Component {
  constructor(props, context) {
    super(props, context);
    this.state = {
      valid: false
    };
    this.onChange = this.onChange.bind(this);
  }

  onChange(event) {
    // console.log("received", event);
  }

  render() {
    return (
      <InputCheckbox
        name="option"
        questionID={this.props.question.questionID}
        options={this.props.question.values}
        onChange={this.onChange}
      />
    );
  }
}

export default FormQuestion;
