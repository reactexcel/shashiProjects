import React, { useState, useCallback } from "react";
import AutoSuggestion from "./AutoSuggestion.jsx";
const SEARCH_URI = "https://api.github.com/search/users";

const AutoSuggestionWithApiCall = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [options, setOptions] = useState([]);

  const handleSearch = useCallback((query) => {
    setIsLoading(true);

    fetch(`${SEARCH_URI}?q=${query}+in:login&page=1&per_page=50`)
      .then((resp) => resp.json())
      .then(({ items }) => {
        const options = items.map((i) => i.login);

        setOptions(options);
        setIsLoading(false);
      });
  });

  return (
    <AutoSuggestion
      isLoading={isLoading}
      options={options}
      handleSearch={handleSearch}
      placeholder="Items"
    />
  );
};

export default AutoSuggestionWithApiCall;
