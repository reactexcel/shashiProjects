import React from "react";
import { AsyncTypeahead } from "react-bootstrap-typeahead";

const AutoSuggestion = ({ placeholder, options, handleSearch, isLoading }) => {
  return (
    <AsyncTypeahead
      id="async-example"
      isLoading={isLoading}
      labelKey="login"
      minLength={1}
      onSearch={handleSearch}
      options={options}
      placeholder={placeholder}
      renderMenuItemChildren={(option) => (
        <div>
          <span>{option}</span>
        </div>
      )}
    />
  );
};

export default AutoSuggestion;
