import React from "react";
import "./AjaxLoader.css";
import styled from "styled-components";

const AjaxLoader = ({ display, fontSize }) => {
  return <i className="loader" />;
};

const Item = styled.i`
  font-size: ${props => (props.fontsize ? props.fontsize : "80px")};
  display: inline-block;
`;

const DivWrapper = styled.div`
  display: ${props => (props.display ? props.display : "block")};
  margin-lef: 0.25rem;
  z-index: 3000;
`;

export default AjaxLoader;
