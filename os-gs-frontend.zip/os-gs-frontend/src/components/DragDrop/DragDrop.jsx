import React, { Component } from "react";
import Dropzone from 'react-dropzone';
import { Row, Col, Table, FormControl, FormGroup } from "react-bootstrap";
import Button from "components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import Select from "react-select";
import * as pagePropertyListConstant from '../../modules/common/constant/commonConstant';
import { setFacilityDocuments } from "../../modules/facilityManagement/actions/facilityActions";
import CommonUtil from '../../modules/common/util/commonUtil';
import Datetime from "react-datetime";
import moment from "moment";
import { touch } from "redux-form";
import list from 'assets/img/list.svg';
import pdf from 'assets/img/pdf.svg';
import excel from 'assets/img/excel.svg';
import csv from 'assets/img/csv.svg';
import file from 'assets/img/file.svg';
import docx from 'assets/img/docx.svg';
import image from 'assets/img/image.svg';

export function resetDropzone() {
	this.setState({
		files: [],
		rejected: null,
		rejectedType: null,
		lengthOfChar: null,
		attributeList: [],
		attributeDataList: []
	});
}
export function handleTypeValidation() {
	this.state.files.length === 0
		? this.setState({
			filesError: (
				<div className="text-danger">Please Upload file.</div>
			)
		})
		: this.setState({ filesError: null });
	var pc = this.state.files.length !== 0;

	var valid = pc
	return valid;
}

var yesterday = moment().subtract(1, "day");
function valid(current) {
  return current.isAfter(yesterday);
}


class DragDrop extends Component {
	constructor(props) {
		super(props);
		this.state = {
			files: [],
			filesError: null,
			rejected: null,
			rejectedType: null,
			lengthOfChar: null,
			attributeObj: null,
		};
		this.onDrop = this.onDrop.bind(this);
		this.dropzoneDropRejected = this.dropzoneDropRejected.bind(this);
		this.checkSize = this.checkSize.bind(this);
		this.checkMaxFiles = this.checkMaxFiles.bind(this);
		this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
		this.handleDropDownChange = this.handleDropDownChange.bind(this);
		this.handleRemove = this.handleRemove.bind(this);
		resetDropzone = resetDropzone.bind(this)
	}

	onDrop = (acceptedFiles, rejectedFiles) => {
		if (rejectedFiles.length) {
			console.log(rejectedFiles);
		}
	
		if(this.checkSize(acceptedFiles, rejectedFiles)) {
			var tempObjFile = [...acceptedFiles];
			var tempObj = {};
			if (CommonUtil.isNotNull(tempObjFile)) {
				tempObj.documentId = this.props.fileNamePrefix;
				tempObj.documentName = tempObjFile[0].name;
				tempObj.fileType = tempObjFile[0].type;
                tempObj.documentExpiryDate = CommonUtil.getFormattedDate(moment().toDate());
				this.setState({ files: tempObjFile, filesError: null, attributeObj: tempObj })
			}
			const data = new FormData();
			data.append('file', tempObjFile[0]);
			data.append('filename', tempObj.documentName);
			data.append('documentId', tempObj.documentId);
			data.append('moduleName', this.props.moduleName);
			var documentIdObj = {};
			documentIdObj.documentId = tempObj.documentId;
			this.props.setFacilityDocuments(data, documentIdObj);
		}
		this.checkMaxFiles(acceptedFiles);
	}

	checkMaxFiles = (acceptedFiles) => {
		let maxFiles = acceptedFiles.length;
		let maxFilesNumber = this.props.maxFiles;
		if (maxFiles && maxFiles > maxFilesNumber) {
			this.setState({ rejected: (<div className="text-danger">You excced the max file limit. No more than {maxFilesNumber} Files</div>), files: [] })
		}
	}

	handleTextBoxChange(event) {
		const { name, value } = event.target;
		var id = parseInt(event.target.id.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		for (var i = 0; i < this.state.attributeDataList.length; i++) {
			if (id == i) {
				attributeDataList[i][name] = value;
				break;
			}
		}
		this.setState({
			attributeDataList: [...attributeDataList]
		});
	}

	handleDateChange = (event, eventId) => {
		var name = eventId.split('_')[0];
		var id = parseInt(eventId.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		for (var i = 0; i < this.state.attributeDataList.length; i++) {
			if (id == i) {
				attributeDataList[i][name] = event.toDate ? 
				 CommonUtil.getFormattedDate(event.toDate()) : ''
				break;
			}
		}
		this.setState({
			attributeDataList: [...attributeDataList]
		});
	}

	handleDropDownChange(event, obj) {
		var id = parseInt(obj.name.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		for (var i = 0; i < this.state.attributeDataList.length; i++) {
			if (id == i) {
				attributeDataList[i][[obj.name.split('_')[0]]] = event.value;
				break;
			}
		}
		this.setState({
			attributeDataList: [...attributeDataList]
		});
	}

	handleRemove(event) {
		var id = parseInt(event.target.id.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		var tempAttributeDataList = [];
		for (var i = 0; i < attributeDataList.length; i++) {
			if (id !== i) {
				tempAttributeDataList.push({ ...attributeDataList[i] });
			}
		}
		this.setState({
			attributeDataList: [...tempAttributeDataList]
		});
		this.props.getdocumentdetails([...tempAttributeDataList]);
	}


	checkSize = (acceptedFiles, rejectedFiles) => {
		let sizeAccepted = 0;
		let sizeRejected = 0;
		let size;
		let charLength;

		if (acceptedFiles && acceptedFiles.length > 0) {
			for (let i = 0; i < acceptedFiles.length; i++) {
				sizeAccepted = sizeAccepted + acceptedFiles[i].size;
				charLength = acceptedFiles[i].name.length;
				if (charLength > 55) {
					this.setState({ lengthOfChar: (<div className="text-danger">Name of the file should not exceed 55 characters.</div>), rejected: "", rejectedType: "", files: [] })
					return false;
				} else {
					this.setState({ lengthOfChar: "", files: [] })
					return true;
				}
			}
		}

		if (rejectedFiles && rejectedFiles.length > 0) {
			for (let i = 0; i < rejectedFiles.length; i++) {
				sizeRejected = sizeRejected + rejectedFiles[i].file.size;
			}
		}

		size = sizeAccepted + sizeRejected

		if (size > this.props.maxSize) {
			this.setState({ rejected: (<div className="text-danger">{this.props.errormsg}</div>), lengthOfChar: "", rejectedType: "", files: [] })
		} else {
			this.setState({ rejected: "", files: [] })
		}
	}

	dropzoneDropAccepted = (acceptedFiles) => {
		console.log("accepted");
		this.setState({ lengthOfChar: "", rejectedType: "", files: [] })
		this.checkSize(acceptedFiles, null);
	}

	dropzoneDropRejected = (rejectedFiles) => {
		console.log("rejected");
		this.setState({ rejectedType: (<div className="text-danger">{this.props.typeerror}</div>), lengthOfChar: "", rejected: "", files: [] })
		this.checkSize(null, rejectedFiles);
	}

	componentDidUpdate(prevProps) {
		if (this.props.files != null && prevProps.files != this.props.files) {
			this.setState({ attributeDataList: this.props.files });
		}
		if (this.props.documentURLObj != null && prevProps.documentURLObj != this.props.documentURLObj) {
			this.updateDocumentObj();
		}
	}
	updateDocumentObj = () => {
		var attributeDataList = [...this.state.attributeDataList];
		const { attributeObj } = this.state;
		if (this.props.documentURLObj.documentURL && this.props.documentURLObj.documentURL != null) {
			attributeObj.documentURL = this.props.documentURLObj.documentURL;
			attributeDataList.push({ ...attributeObj });
			this.setState({
				attributeDataList: [...attributeDataList]
			});
			this.props.getdocumentdetails(attributeDataList);
		}
	}

	componentDidMount = () => {
		let attributeList =  pagePropertyListConstant.FILEUPLOAD_STAGE_LIST.attributeList;
		if(this.props.attributeList != null){
	        attributeList = this.props.attributeList;
		}		
		this.setState({
			attributeList: CommonUtil.getDropDownOptionsFromDictionary(attributeList,
				this.props.dataDictionaryList),
			attributeDataList: this.props.files != null ? this.props.files : [],
		})
	    
	}

	render() {
		const { accept, minSize, maxSize, multiple, maxFiles, uploadedtext, fileNamePrefix, disabled,...rest } = this.props;
		const { attributeList, attributeDataList } = this.state;
		return (
			<Dropzone
				accept="image/jpeg, image/png, text/csv, application/pdf, 
				application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, 
				application/vnd.ms-excel,.doc,.docx,application/msword"
				minSize={minSize}
				maxSize={maxSize}
				multiple={multiple}
				maxFiles={maxFiles}
				onDrop={this.onDrop}
				disabled={disabled}
				onDropAccepted={this.dropzoneDropAccepted}
				onDropRejected={this.dropzoneDropRejected}
			>
				{({ getRootProps, getInputProps, isDragActive, isDragReject, acceptedFiles, rejectedFiles }) => {
					return (
						<section className="dragdrop">
							<Col md={12} {...getRootProps({ className: 'dropzone' })} className={disabled == true ? "selection-box disabled" : "selection-box"}>
								<div><img src={list} alt="" /></div>
								<h4>Drag 'n' drop a file here, or click to select a file</h4>
								<input {...getInputProps()} />
								<p>File Format are doc, xlsx, xls, csv, pdf, png, jpg &nbsp;|&nbsp; Max size 5MB</p>
							</Col>
							<Col md={12} className="selected-file">
								{this.state.rejected}
								{this.state.rejectedType}
								{this.state.filesError}
								{this.state.lengthOfChar}
								{!this.props.hideDocument && attributeDataList && attributeDataList.length > 0 && attributeList.length > 0 ?
									<Table responsive>
										<thead>
											<tr>
												{attributeDataList != null && attributeList.map((tempAttributeListObj, index) => {
													return (
														<th key={index}>{tempAttributeListObj.title}</th>
													)
												})}
											</tr>
										</thead>
										<tbody>
											{attributeDataList != null && attributeDataList.map((tempAttributeDataListObj, index) => {
												return (
													<tr key={index} style={{marginBottom: "7px"}}>
														{attributeList.map((tempAttributeListObj, index1) => {
															return (
																<td key={index1}>
																	{tempAttributeListObj.type == "TEXTBOX" ?

                                 	tempAttributeListObj.inputType != 'date'?
																		<>
																			<FormControl 
																				id={tempAttributeListObj.name + '_' + index} 
																				type={tempAttributeListObj.inputType} 
																				name={tempAttributeListObj.name}
																				title={tempAttributeDataListObj[tempAttributeListObj.name]}
																				onChange={(e) => {this.handleTextBoxChange(e)}} 
																				onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
																				disabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}
																				value={tempAttributeDataListObj[tempAttributeListObj.name]} 
																				onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength)}}
																				onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength)}}
																				maxlength={tempAttributeListObj.maxLength}
																				minlength={tempAttributeListObj.minLength}
																			/>
																			{tempAttributeListObj.required && !tempAttributeDataListObj[tempAttributeListObj.name] &&
														            <small className="text-danger" style={{position: "absolute"}}>
														              {tempAttributeListObj.mandatoryMsgText}
														            </small>
														          }
														          {touch && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.maxLength ?
														            tempAttributeDataListObj[tempAttributeListObj.name].length >= tempAttributeListObj.maxLength ?
														              <small className="text-danger" style={{position: "absolute"}}>
														                Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
														              </small>
														              : null
														            : null
														          }
														          {touch && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.minLength && tempAttributeDataListObj[tempAttributeListObj.name].length < tempAttributeListObj.minLength &&
													              <small className="text-danger" style={{position: "absolute"}}>
													                Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
													              </small>
														          }
																		</>

																	:		<Datetime
															        	id={tempAttributeListObj.name + '_' + index}
																				timeFormat={false}
																				closeOnSelect={true}
																				isValidDate={valid}
																				inputProps={{ 
																					readOnly: true,
																					placeholder: "Date Picker Here",
																					disabled: tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false,
																				}}
																				name={tempAttributeListObj.name}
																	        	onChange={(moment)=> this.handleDateChange(moment, tempAttributeListObj.name + "_"+index)}
																				dateFormat="MM-DD-YYYY"
																				value={moment(tempAttributeDataListObj[tempAttributeListObj.name])}
																		  	/>	


																		: tempAttributeListObj.type == "BUTTON" ?
																			<>
																				<Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : false}>
																					{tempAttributeListObj.downloadIcon == true ?


																						tempAttributeDataListObj.fileType === "application/pdf" ?
																							<a href={tempAttributeDataListObj.documentURL} download="pp">
																								<img key={index} id={tempAttributeListObj.name + '_' + index} src={pdf} alt="pdf" />
																							</a>
																							: tempAttributeDataListObj.fileType
																								=== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || tempAttributeDataListObj.fileType === "application/vnd.ms-excel" ?
																								<a href={tempAttributeDataListObj.documentURL} download="pp">
																									<img key={index} id={tempAttributeListObj.name + '_' + index} src={excel} alt="excel" />
																								</a>
																								: tempAttributeDataListObj.fileType === "text/csv" ?
																									<a href={tempAttributeDataListObj.documentURL} download="pp">
																										<img key={index} id={tempAttributeListObj.name + '_' + index} src={csv} alt="csv" />
																									</a>
																									: tempAttributeDataListObj.fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || tempAttributeDataListObj.fileType === "application/msword" ?
																									<a href={tempAttributeDataListObj.documentURL} download="pp">
																										<img key={index} id={tempAttributeListObj.name + '_' + index} src={docx} alt="docx" />
																									</a>
																										: tempAttributeDataListObj.fileType === "image/jpeg" || tempAttributeDataListObj.fileType === "image/jpg" || tempAttributeDataListObj.fileType === "image/png"  ?
																										<a href={tempAttributeDataListObj.documentURL} download="pp">
																											<img key={index} id={tempAttributeListObj.name + '_' + index} src={image} alt="image" />
																										</a>
																											:
																											<a href={tempAttributeDataListObj.documentURL} download="pp">
																												<img key={index} id={tempAttributeListObj.name + '_' + index} src={file} alt="file" />
																											</a>

																						: null}

																				</Button>
																				<Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}>
																					{tempAttributeListObj.removeIcon == true ?
																						<i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
																							className="fa fa-times" onClick={tempAttributeListObj[this.props.actionMode] != 'disabled' ? this.handleRemove : null} />
																						: null}

																				</Button>
																			</>
																			: tempAttributeListObj.type == "DROPDOWN" ?
																				<>
																					<div title={tempAttributeDataListObj[tempAttributeListObj.name]}>
																						<Select id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name + '_' + index} onChange={this.handleDropDownChange}
																							placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
																							classNamePrefix="react-select" isDisabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}
																							value={CommonUtil.getSelectedOptionLabel(tempAttributeListObj.options, tempAttributeDataListObj[tempAttributeListObj.name])}/>
																		      </div>
																					{tempAttributeListObj.required && (tempAttributeDataListObj[tempAttributeListObj.name] ? (tempAttributeDataListObj[tempAttributeListObj.name].length == 0) : !tempAttributeDataListObj[tempAttributeListObj.name]) &&
																            <small className="text-danger" style={{position: "absolute"}}>
																              {tempAttributeListObj.mandatoryMsgText}
																            </small>
																          }
																	      </>
																				: null

																	}
																</td>
															)
														})}
													</tr>
												)
											})}
										</tbody>
									</Table>
									: null}
							</Col>
						</section>
					)
				}
				}
			</Dropzone>
		);
	}
}

function mapStateToProps(state, ownProps) {
	return {
		documentURLObj: state.supplier.documentURLObj,
		dataDictionaryList: state.dataDictionary.dataDictionaryList
	};
}

const mapDispatchToProps = dispatch => ({
	setFacilityDocuments: (fileObj, documentIdObj) => dispatch(setFacilityDocuments(fileObj, documentIdObj)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DragDrop);

