import React, { Component } from "react";
import Dropzone from 'react-dropzone';
import { Row, Col, Table, FormControl, FormGroup } from "react-bootstrap";
import Button from "components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import Select from "react-select";
import * as pagePropertyListConstant from '../../modules/common/constant/commonConstant';
import { setFacilityDocuments } from "../../modules/facilityManagement/actions/facilityActions";
import CommonUtil from '../../modules/common/util/commonUtil';
import list from 'assets/img/list.svg';
import pdf from 'assets/img/pdf.svg';
import excel from 'assets/img/excel.svg';
import csv from 'assets/img/csv.svg';
import file from 'assets/img/file.svg';
import docx from 'assets/img/docx.svg';
import image from 'assets/img/image.svg';

var Modal = require('react-bootstrap-modal')

export function resetDropzone() {
	this.setState({
		files: [],
		openModal: false,
		rejected: null,
		rejectedType: null,
		lengthOfChar: null,
		attributeList: [],
		attributeDataList: []
	});
}
export function handleTypeValidation() {
	this.state.files.length === 0
		? this.setState({
			filesError: (
				<div className="text-danger">Please Upload file.</div>
			)
		})
		: this.setState({ filesError: null });
	var pc = this.state.files.length !== 0;

	var valid = pc
	return valid;
}

class DragDropDialog extends Component {
	constructor(props) {
		super(props);
		this.state = {
			files: [],
			filesError: null,
			rejected: null,
			rejectedType: null,
			lengthOfChar: null,
			attributeObj: null,
			openModal: true,
			alert: null,
			attributeDataList: []
		};
		this.onDrop = this.onDrop.bind(this);
		this.dropzoneDropRejected = this.dropzoneDropRejected.bind(this);
		this.checkSize = this.checkSize.bind(this);
		this.checkMaxFiles = this.checkMaxFiles.bind(this);
		this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
		this.handleDropDownChange = this.handleDropDownChange.bind(this);
		this.handleRemove = this.handleRemove.bind(this);
		resetDropzone = resetDropzone.bind(this)
		this.closeModal = this.closeModal.bind(this);
		this.handleSave = this.handleSave.bind(this);
	}

	closeModal() {
		this.props.getCompleteDetails(true);
		this.setState({ openModal: false });
		this.setState({ alert: null });
	}

	handleSave() {
		this.props.getdocumentdetails(this.state.attributeDataList);
	}

	onDrop = (acceptedFiles, rejectedFiles) => {
		if (rejectedFiles.length) {
			console.log(rejectedFiles);
		}

		if(this.props.isBulkImport == true) {
			this.setState({ attributeDataList: [] })
		}
		if(this.checkSize(acceptedFiles, rejectedFiles)) {
			var tempObjFile = [...acceptedFiles];
			var tempObj = {};
			if (CommonUtil.isNotNull(tempObjFile)) {
				tempObj.documentId = this.props.fileNamePrefix + "-" + tempObjFile[0].name;
				tempObj.documentName = tempObjFile[0].name;
				tempObj.fileType = tempObjFile[0].type;
				this.setState({ files: tempObjFile, filesError: null, attributeObj: tempObj, })
			}
			const data = new FormData();
			if(CommonUtil.isNotNull(tempObjFile) && (this.props.fileNamePrefix === 'bulk-import')) {
				data.append('bulkImport', true);
				tempObj.keyName = "bulk-upload/" + tempObjFile[0].name;
				tempObj.bucketName = pagePropertyListConstant.S3_TEMPLATE_BASE_FOLDER;
			}
			data.append('file', tempObjFile[0]);
			data.append('filename', tempObj.documentName);
			var documentIdObj = {};
			documentIdObj.documentId = tempObj.documentId;
			this.props.setFacilityDocuments(data, documentIdObj);
		}
		this.checkMaxFiles(acceptedFiles);
	}

	checkMaxFiles = (acceptedFiles) => {
		let maxFiles = acceptedFiles.length;
		let maxFilesNumber = this.props.maxFiles;
		if (maxFiles && maxFiles > maxFilesNumber) {
			this.setState({ rejected: (<div className="text-danger">You excced the max file limit. No more than {maxFilesNumber} Files</div>), files: [] })
		}
	}

	handleTextBoxChange(event) {
		const { name, value } = event.target;
		var id = parseInt(event.target.id.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		for (var i = 0; i < this.state.attributeDataList.length; i++) {
			if (id == i) {
				attributeDataList[i][name] = value;
				break;
			}
		}
		this.setState({
			attributeDataList: [...attributeDataList]
		});
	}

	handleDropDownChange(event, obj) {
		var id = parseInt(obj.name.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		for (var i = 0; i < this.state.attributeDataList.length; i++) {
			if (id == i) {
				attributeDataList[i][[obj.name.split('_')[0]]] = event.value;
				break;
			}
		}
		this.setState({
			attributeDataList: [...attributeDataList]
		});
	}

	handleRemove(event) {
		var id = parseInt(event.target.id.split('_')[1]);
		var attributeDataList = [...this.state.attributeDataList];
		var tempAttributeDataList = [];
		for (var i = 0; i < attributeDataList.length; i++) {
			if (id !== i) {
				tempAttributeDataList.push({ ...attributeDataList[i] });
			}
		}
		this.setState({
			attributeDataList: [...tempAttributeDataList]
		});
	}


	checkSize = (acceptedFiles, rejectedFiles) => {
		let sizeAccepted = 0;
		let sizeRejected = 0;
		let size;
		let charLength;

		if (acceptedFiles && acceptedFiles.length > 0) {
			for (let i = 0; i < acceptedFiles.length; i++) {
				sizeAccepted = sizeAccepted + acceptedFiles[i].size;
				charLength = acceptedFiles[i].name.length;
				if (charLength > 55) {
					this.setState({ lengthOfChar: (<div className="text-danger">Name of the file should not exceed 55 characters.</div>), rejected: "", rejectedType: "", files: [] })
					return false;
				} else {
					this.setState({ lengthOfChar: "", files: [] })
					return true;
				}
			}
		}

		if (rejectedFiles && rejectedFiles.length > 0) {
			for (let i = 0; i < rejectedFiles.length; i++) {
				sizeRejected = sizeRejected + rejectedFiles[i].file.size;
			}
		}

		size = sizeAccepted + sizeRejected

		if (size > this.props.maxSize) {
			this.setState({ rejected: (<div className="text-danger">{this.props.errormsg}</div>), lengthOfChar: "", rejectedType: "", files: [] })
		} else {
			this.setState({ rejected: "", files: [] })
		}
	}

	dropzoneDropAccepted = (acceptedFiles) => {
		console.log("accepted");
		this.setState({ lengthOfChar: "", rejectedType: "", files: [] })
		this.checkSize(acceptedFiles, null);
	}

	dropzoneDropRejected = (rejectedFiles) => {
		console.log("rejected");
		this.setState({ rejectedType: (<div className="text-danger">{this.props.typeerror}</div>), lengthOfChar: "", rejected: "", files: [] })
		this.checkSize(null, rejectedFiles);
	}

	componentDidUpdate(prevProps) {
		if (prevProps.files != this.props.files && this.props.files != null) {
			this.setState({
				attributeDataList: this.props.files,
				openModal: true
			});
		}
		if (this.props.documentURLObj != null && prevProps.documentURLObj != this.props.documentURLObj) {
			this.updateDocumentObj();
		}
	}
	updateDocumentObj = () => {
		var attributeDataList = [...this.state.attributeDataList];
		const { attributeObj } = this.state;
		if (this.props.documentURLObj.documentURL && this.props.documentURLObj.documentURL != null) {
			attributeObj.documentURL = this.props.documentURLObj.documentURL;
			const documentUrlArr = attributeObj.documentURL.split("/");
			if (documentUrlArr[3] && documentUrlArr[4] && documentUrlArr[5] ) {
				const keyName = documentUrlArr[3] + '/' + documentUrlArr[4] + '/' + documentUrlArr[5];	
				attributeObj.keyName = keyName;
			}
			attributeDataList.push({ ...attributeObj });
			this.setState({
				attributeDataList: [...attributeDataList]
			});
		}
	}

	componentDidMount = () => {
		this.setState({
			attributeList: CommonUtil.getDropDownOptionsFromDictionary(
				pagePropertyListConstant.FILEUPLOAD_STAGE_LIST.attributeList, this.props.dataDictionaryList),
			attributeDataList: [],
		})
	}

	render() {
		const { accept, minSize, maxSize, multiple, maxFiles, uploadedtext, fileNamePrefix, disabled, isBulkImport,...rest } = this.props;
		let { attributeList, attributeDataList } = this.state;
		if (isBulkImport && attributeList) {
			const idx = attributeList.find(function(n) {
				return n.name == 'documentName' ;
			});
			attributeList = [];
			attributeList.push(idx);
		}

		return (
			<div >
				<Modal show={this.state.openModal} onHide={this.closeModal} aria-labelledby="ModalHeader">
					<Modal.Header closeButton>
					<Modal.Title><div className="card-header-capital">{isBulkImport ? 'Upload Document' : 'Add/Edit Document'}</div></Modal.Title>
					</Modal.Header>
					<Modal.Body>
						<Dropzone
							accept={accept}
							minSize={minSize}
							maxSize={maxSize}
							multiple={multiple}
							maxFiles={maxFiles}
							onDrop={this.onDrop}
							disabled={disabled}
							onDropAccepted={this.dropzoneDropAccepted}
							onDropRejected={this.dropzoneDropRejected}
						>
							{({ getRootProps, getInputProps, isDragActive, isDragReject, acceptedFiles, rejectedFiles }) => {
								return (
									<section className="dragdrop">
										<div {...getRootProps({ className: 'dropzone' })} className={disabled === true ? "selection-box disabled" : "selection-box"}>
											<div><img src={list} alt="" /></div>
											<h4>Drag 'n' drop a file here, or click to select a file</h4>
											<input {...getInputProps()} />
											{ isBulkImport ? 
												null : 
												<p>File Format are Doc, xlsx, xls, csv, pdf &nbsp;|&nbsp; Max size 5MB</p>
											}
											
										</div>
										<div className="selected-file">
											{this.state.rejected}
											{this.state.rejectedType}
											{this.state.filesError}
											{this.state.lengthOfChar}
										</div>
										<div>
											{attributeDataList && attributeDataList.length > 0 && attributeList.length > 0 ?
												<Table responsive>
													<thead>
														<tr>
															{attributeDataList != null && attributeList.map((tempAttributeListObj, index) => {
																return (
																	<th key={index}>{tempAttributeListObj.title}</th>
																)
															})}
														</tr>
													</thead>
													<tbody>
														{attributeDataList != null && attributeDataList.map((tempAttributeDataListObj, index) => {
															return (
																<tr key={index}>
																	{attributeList.map((tempAttributeListObj, index1) => {
																		return (
																			<td key={index1}>
																				{tempAttributeListObj.type == "TEXTBOX" ?

																					<>
																						<FormControl 
																							id={tempAttributeListObj.name + '_' + index} 
																							type={tempAttributeListObj.inputType} 
																							name={tempAttributeDataListObj[tempAttributeListObj.name]}
																							title={tempAttributeListObj.name}
																							onChange={(e) => {this.handleTextBoxChange(e)}} 
																							disabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}
																							value={tempAttributeDataListObj[tempAttributeListObj.name]} 
																							onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength)}}
																							onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength)}}
																							maxlength={tempAttributeListObj.maxLength}
																						/>
																					</>

																					: tempAttributeListObj.type == "BUTTON" ?
																						<Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}>

																							{tempAttributeListObj.downloadIcon == true ?
																								<a href={tempAttributeDataListObj.documentURL} download="pp">
																									<i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name} className="fa fa-download" />
																								</a> : null}
																							{tempAttributeListObj.removeIcon == true ?
																								<i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
																									className="fa fa-times" onClick={tempAttributeListObj[this.props.actionMode] != 'disabled' ? this.handleRemove : null} />
																								: null}

																						</Button>
																						: tempAttributeListObj.type == "DROPDOWN" ?
																							<div title={tempAttributeDataListObj[tempAttributeListObj.name]}>
																								<Select id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name + '_' + index} onChange={this.handleDropDownChange}
																									placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
																									classNamePrefix="react-select" isDisabled={tempAttributeListObj[this.props.actionMode] == 'disabled' ? true : disabled == true ? true : false}
																									value={{ "label": tempAttributeDataListObj[tempAttributeListObj.name] }} />
																							</div>

																							: tempAttributeListObj.type == "FILEICON" ?
																								<div className="file-icon" {...rest}>
																									{tempAttributeDataListObj.fileType === "application/pdf" ?
																										<img key={index} id={tempAttributeListObj.name + '_' + index} src={pdf} alt="pdf" />
																										: tempAttributeDataListObj.fileType
																											=== "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" || tempAttributeDataListObj.fileType === "application/vnd.ms-excel" ?
																											<img key={index} id={tempAttributeListObj.name + '_' + index} src={excel} alt="excel" />
																											: tempAttributeDataListObj.fileType === "text/csv" ?
																												<img key={index} id={tempAttributeListObj.name + '_' + index} src={csv} alt="csv" />
																												: tempAttributeDataListObj.fileType === "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || tempAttributeDataListObj.fileType === "application/msword" ?
																													<img key={index} id={tempAttributeListObj.name + '_' + index} src={docx} alt="docx" />
																													: tempAttributeDataListObj.fileType === "image/jpeg" || tempAttributeDataListObj.fileType === "image/jpg" || tempAttributeDataListObj.fileType === "image/png"  ?
																														<img key={index} id={tempAttributeListObj.name + '_' + index} src={image} alt="image" />
																														: <img key={index} id={tempAttributeListObj.name + '_' + index} src={file} alt="file" />
																									}
																								</div>
																								: null

																				}
																			</td>
																		)
																	})}
																</tr>
															)
														})}
													</tbody>
												</Table>
												: null}
										</div>
										<div className="action-btns">
											<Button className="btn-cancel" onClick={this.closeModal} >
												Cancel
                                            </Button>
											<Button className="btn-save btn-fill" onClick={this.handleSave} disabled={ disabled == true ? true : this.state.attributeDataList.length > 0 ? false : true} >
												Save
                                            </Button>
										</div>
									</section>
								)
							}
							}
						</Dropzone>
					</Modal.Body>
				</Modal>
			</div>
		);
	}
}

function mapStateToProps(state, ownProps) {
	return {
		documentURLObj: state.supplier.documentURLObj,
		dataDictionaryList: state.dataDictionary.dataDictionaryList
	};
}

const mapDispatchToProps = dispatch => ({
	setFacilityDocuments: (fileObj, documentIdObj) => dispatch(setFacilityDocuments(fileObj, documentIdObj)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DragDropDialog);

