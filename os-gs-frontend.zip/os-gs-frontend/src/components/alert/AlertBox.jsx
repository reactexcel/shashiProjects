import React from "react";
import SweetAlert from "react-bootstrap-sweetalert";

const AlertBox = ({ error, title, success, confirmBtnBsStyle, closeAlert }) => {
  return (
    <SweetAlert
      error={error}
      success={success}
      style={{ display: "block", marginTop: "-100px" }}
      title={title}
      onConfirm={closeAlert}
      onCancel={closeAlert}
      confirmBtnBsStyle={confirmBtnBsStyle}
      cancelBtnCssClass="btn-cancel"
      confirmBtnCssClass="btn-save btn-fill"
      btnSize="sm"
      focusConfirmBtn={false}
      focusCancelBtn={true}
      closeOnCancel={true}
      closeOnConfirm={true}
    />
  );
};

export default AlertBox;
