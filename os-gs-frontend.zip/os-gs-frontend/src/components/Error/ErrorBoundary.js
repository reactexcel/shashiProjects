import React, { Component } from 'react';
import { Redirect } from "react-router-dom";
class ErrorBoundary extends Component {
   state = {
      isErrorOccured: false,
      errorMessage: '',
      redirectUrl: '/admin/dashboard'
   }
   componentDidCatch = (error, info) => {
      this.setState({ isErrorOccured: true, errorMessage: '' });
   }
   render() {
      if (this.state.isErrorOccured) {
         return (
            <div className="main-content manage-page">
               {this.state.isErrorOccured === true && this.state.redirectUrl ? (
                  <Redirect push to={this.state.redirectUrl}></Redirect>
               ) : null}
            </div>
         )
      } else {
         return <div>{this.props.children}</div>
      }
   }
}
export default ErrorBoundary;