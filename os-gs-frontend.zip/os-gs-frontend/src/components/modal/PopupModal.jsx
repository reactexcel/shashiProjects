import React from "react";

import { Modal } from "react-bootstrap";

const PopupModal = ({ closeForm, formHeading, children }) => {
  return (
    <Modal show={true} onHide={closeForm} size="md" backdrop="static">
      <Modal.Header closeButton>
        <Modal.Title>{formHeading}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{children}</Modal.Body>
    </Modal>
  );
};

export default PopupModal;
