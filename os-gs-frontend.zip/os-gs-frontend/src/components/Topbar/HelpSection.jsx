import React from "react";
import { NavDropdown, MenuItem } from "react-bootstrap";

const HelpSection = (props) => {
  return (
    <NavDropdown
      title={
        <div>
          <i className="fa fa-question-circle-o" />
          <p className="hidden-md hidden-lg">
            Actions
            <b className="caret" />
          </p>
        </div>
      }
      noCaret
      id="basic-nav-dropdown-3"
    >
      <MenuItem key={10.1}>Create New Post</MenuItem>
      <MenuItem key={10.2}>Manage Something</MenuItem>
      <MenuItem key={10.3}>Do Nothing</MenuItem>
      <MenuItem key={10.4}>Submit to live</MenuItem>
      <MenuItem key={10.5}>Another action</MenuItem>
    </NavDropdown>
  );
};

export default HelpSection;