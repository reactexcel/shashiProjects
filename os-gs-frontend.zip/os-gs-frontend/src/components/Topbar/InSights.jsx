import React, { Component } from "react";
import { connect } from "react-redux";
import { NavLink, withRouter } from "react-router-dom";
import { setActionMode } from "../../actions/appActions"
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import * as commonConstant from '../../modules/common/constant/commonConstant';
import * as navigationURLConstants from '../../constants/navigationURLConstants';
import insights from "assets/img/insights.svg";

class InSights extends Component {

  constructor(props) {
    super(props);
    this.state = {
    };
    this.handleLinkClick = this.handleLinkClick.bind(this);
  }

  handleLinkClick (){
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
  }
 

  render() {
    return (
      <Nav pullRight className="insights-section" >
        <NavDropdown
          className="navbar-add-option"
          title={
            <div className="navbar-item">
              <div className="insights">
                <img src={insights} alt="" />
                <p>Insights<b className="caret hidden-md hidden-lg" /></p>
              </div>
            </div>
          }
          noCaret id="basic-nav-dropdown-1" bsClass="dropdown">
          {navigationURLConstants.INSIGHT_URL_LIST.map((tempNavigationObj, index) => (
            <MenuItem key={index}>
              <NavLink
                key={index}
                onClick={this.handleLinkClick}
                to={tempNavigationObj.pageURL}>
                {tempNavigationObj.label}
              </NavLink>
            </MenuItem>
          ))}
        </NavDropdown>
      </Nav>
    );
  };
}

function mapStateToProps(state, ownProps) {
  return {
    //currencyCode: state.dataDictionary.currencyCode,
  };
}

const mapDispatchToProps = dispatch => ({
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(InSights));
