import React from "react";
import { Modal } from "react-bootstrap";
import styled from "styled-components";
import "./confirm-box.css";

const ConfirmModelBox = ({
  onClose,
  confirmText,
  cancelText,
  onConfirm,
  onCancel,
  modelHeading,
  className,
}) => {
  const classes = ["ui", "button"];
  classes.push(className);
  return (
    <ModalWrapper
      show={true}
      onHide={onClose}
      size="sm"
      backdrop="static"
      className="confirm-box"
    >
      <Modal.Header closeButton>
        <Modal.Title>{modelHeading}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <div className="ui container sm">
          <div className="ui segment">
            <div style={{ marginBottom: "48px" }}>
              <button
                onClick={onConfirm}
                className={classes.join(" ")}
                style={{ float: "left" }}
              >
                {confirmText}
              </button>
              <button
                onClick={onCancel}
                className="ui button primary"
                style={{ float: "right" }}
              >
                {cancelText}
              </button>
            </div>
          </div>
        </div>
      </Modal.Body>
    </ModalWrapper>
  );
};

const ModalWrapper = styled(Modal)`
    align-items: center;
    background-color: rgba(100, 100, 100, 0.7);
    bottom: 0;
    display: flex;
    height: 100vh;
    justify-content: center;
    left: 0;
    opacity: 0;
    position: fixed;
    right: 0;
    transition: 0.2s ease-in-out all;
    width: 100%;
    z-index: 2000;
}
`;

export default ConfirmModelBox;
