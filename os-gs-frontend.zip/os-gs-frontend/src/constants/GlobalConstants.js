export const leftPanel = "leftPanel";
export const topPanel = "topPanel";
export const superUser = "SuperUser";
export const productOwner = "ProductOwner";
export const participant = "Participant";
export const SESSION_TIMEOUT = 12;
export const ELEVIO_ID = "5f8bde6a4a222";