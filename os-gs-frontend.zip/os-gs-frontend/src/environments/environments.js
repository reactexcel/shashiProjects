const SERVICES_API_JSON_SERVER = 'http://localhost:4000';
const DEV_API_SERVER = 'http://localhost:8080';
const DEV_QR_CODE_API_SERVER = process.env.REACT_APP_API_BASE_URL;
const LOGIN_API_SERVER = 'http://localhost:8080'
const ENVIRONMENTS = {
    JSONSERVER: {
        API_PATHS: {
            GET_USERS: `${SERVICES_API_JSON_SERVER}/users`,
            LOGIN: `${LOGIN_API_SERVER}/api/auth/login`,
            GET_ROLES: `${SERVICES_API_JSON_SERVER}/roles`,
            GET_PRODUCTS: `${SERVICES_API_JSON_SERVER}/products`,
            SENT_INVITATIONS: `${SERVICES_API_JSON_SERVER}/invitations`,
            DEACTIVATE_USER: `${SERVICES_API_JSON_SERVER}/users`,
            USERS_STATS: `${SERVICES_API_JSON_SERVER}/userstats`
        }
    },
    DEV: {
        API_PATHS: {
            GET_QRCODES: `${DEV_QR_CODE_API_SERVER}/qrcodes`,
            POST_QRCODES: `${DEV_QR_CODE_API_SERVER}/qrcodes/`,
            EDIT_QRCODES: `${DEV_QR_CODE_API_SERVER}/qrcodes/`,
            LOGIN: `${LOGIN_API_SERVER}/api/auth/login`,
            GET_ROLES: `${DEV_API_SERVER}/roles`,
            GET_PRODUCTS: `${DEV_API_SERVER}/product`,
            SENT_INVITATIONS: `${DEV_API_SERVER}/invitations`,
            DEACTIVATE_USER: `${DEV_API_SERVER}/users`,
            USERS_STATS: `${DEV_API_SERVER}/userstats`
        }
    },
}

export default ENVIRONMENTS['DEV'];