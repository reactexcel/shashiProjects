import InputColumnFilter from "../views/Tables/PopularTable/Filtering/InputColumnFilter";
import DateColumnFilter from "../views/Tables/PopularTable/Filtering/DateColumnFilter";

const transformColumnData = (columns) => {
  return columns.map((column) => {
    switch (column.type) {
      case "text": {
        return {
          ...column,
          Filter: InputColumnFilter,
        };
      }

      case "date": {
        return {
          ...column,
          Filter: DateColumnFilter,
        };
      }

      default: {
        return column;
      }
    }
  });
};

export const getColumnData = () => {
  const columns = [
    {
      Header: "Rank",
      accessor: "rank",
      disableFilters: true,
      disableSortBy: true,
      type: "text",
    },
    {
      Header: "Order",
      accessor: "order",
      isClickable: true,
      type: "text",
    },
    {
      Header: "Customer",
      accessor: "customer",
      type: "text",
    },
    {
      Header: "Total Amount",
      accessor: "totalAmount",
      type: "text",
    },
    {
      Header: "Delivery Deadline",
      accessor: "deliveryDeadline",
      type: "date",
      Filter: DateColumnFilter,
    },
    {
      Header: "Sales Items",
      accessor: "salesItems",
      type: "text",
    },
    {
      Header: "Ingredients",
      accessor: "ingredients",
      type: "text",
    },
    {
      Header: "Production",
      accessor: "production",
      type: "text",
    },
    {
      Header: "Delivery",
      accessor: "delivery",
      type: "text",
    },
  ];

  const data = [
    {
      id: 1,
      rank: "1",
      order: "SO-GV",
      customer: "Mary Lights",
      totalAmount: 7400.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "In stock",
      ingredients: "Processed",
      production: "Done",
      delivery: "Not shipped",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#E2445C", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#C4C4C4", control: { type: "text" } },
      },
    },
    {
      id: 2,
      rank: "2",
      order: "SO-GV",
      customer: "Mary Lights",
      totalAmount: 7400.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "In stock",
      ingredients: "Processed",
      production: "Done",
      delivery: "Not shipped",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#C4C4C4", control: { type: "select" } },
      },
    },
    {
      id: 3,
      rank: "3",
      order: "SO-6",
      customer: "Mary Lights",
      totalAmount: 1944.0,
      deliveryDeadline: "2020-06-22",
      salesItems: "In stock",
      ingredients: "Processed",
      production: "Done",
      delivery: "Not shipped",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#C4C4C4", control: { type: "select" } },
      },
    },
    {
      id: 4,
      rank: "4",
      order: "SO-2",
      customer: "Rob Decor",
      totalAmount: 4176.0,
      deliveryDeadline: "2020-06-18",
      salesItems: "Not available",
      ingredients: "Expected 2020-07-01",
      production: "Done",
      delivery: "Not shipped",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#E2445C", control: null },
        ingredients: { color: "#FDAB3D", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#C4C4C4", control: { type: "select" } },
      },
    },
    {
      id: 5,
      rank: "5",
      order: "SO-3",
      customer: "Jack Carpets",
      totalAmount: 648.0,
      deliveryDeadline: "2020-06-17",
      salesItems: "In stock",
      ingredients: "Processed",
      production: "Done",
      delivery: "Not shipped",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#C4C4C4", control: { type: "select" } },
      },
    },
    {
      id: 6,
      rank: "6",
      order: "SO-1",
      customer: "Rob Decor",
      totalAmount: 372.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "Picked",
      ingredients: "Processed",
      production: "Done",
      delivery: "Packed",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#FDAB3D", control: { type: "select" } },
      },
    },
    {
      id: 7,
      rank: "7",
      order: "SO001",
      customer: "John Table",
      totalAmount: 7500.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "Picked",
      ingredients: "Processed",
      production: "Done",
      delivery: "Packed",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#FDAB3D", control: { type: "select" } },
      },
    },
    {
      id: 8,
      rank: "8",
      order: "SO-5",
      customer: "Rob Decor",
      totalAmount: 7500.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "Picked",
      ingredients: "Processed",
      production: "Done",
      delivery: "Packed",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#FDAB3D", control: { type: "select" } },
      },
    },
    {
      id: 9,
      rank: "9",
      order: "SO-6",
      customer: "Jack Carpets",
      totalAmount: 7500.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "Picked",
      ingredients: "Processed",
      production: "Done",
      delivery: "Packed",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#FDAB3D", control: { type: "select" } },
      },
    },
    {
      id: 10,
      rank: "10",
      order: "SO-6",
      customer: "Jack Carpets",
      totalAmount: 7500.0,
      deliveryDeadline: "2020-07-07",
      salesItems: "Picked",
      ingredients: "Processed",
      production: "Done",
      delivery: "Packed",
      cellConfig: {
        rank: { color: null, control: null },
        order: { color: null, control: null },
        customer: { color: null, control: null },
        totalAmount: { color: null, control: null },
        deliveryDeadline: { color: null, control: null },
        salesItems: { color: "#00C875", control: null },
        ingredients: { color: "#00C875", control: null },
        production: { color: "#00C875", control: null },
        delivery: { color: "#FDAB3D", control: { type: "select" } },
      },
    },
  ];

  const transformedColumns = transformColumnData(columns);

  const tableData = {
    columns: transformedColumns,
    data,
  };

  return { type: "COLUMN_DATA", payload: { tableData } };
};
