import React, { Component } from "react";
import { Grid, Row, Col, FormControl, FormGroup } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import * as automationConstant from '../constant/automationConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { getAutomationList, setSelectedAutomationCode, getAutomationFacilityList } from "../actions/automationActions";
import { connect } from "react-redux";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { getSupplierList } from "../../supplierManagement/actions/supplierActions";
import { getProductList } from '../../productManagement/actions/productActions';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import PopupUtil from "../../common/util/popupUtil";
import { setActionMode } from "../../../actions/appActions";
import AutomationRuleModal from "./AutomationRuleModal";
import { getUserProfile } from "../../userManagement/actions/userActions";
import * as commonConstant from '../../common/constant/commonConstant';
import automation from "assets/img/automation-page-icon.svg";
import pin from "assets/img/pin.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import isAuthorized from "auth-plugin";

class ManageAutomation extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      selectedTab: 'OPEN',

      openRuleModal: false,
      facilityList: [],

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage Automation loaded");
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getFacilityList();
    this.props.getSupplierList();
    this.props.getProductList();
    this.props.getAutomationFacilityList();
  }

  setSelectedTabDetails = async () => {
    const managePageList = pagePropertyListConstant.MANAGE_AUTOMATION_PAGE_LIST(this);
    let additionalParams = { status: this.state.selectedTab.toLowerCase() };
    if (this.state.location) {
      additionalParams.location = this.state.location;
    }
    const { search } = this.state;
    additionalParams["search"] = search;

    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
    if (prevProps.automationList != this.props.automationList && this.props.automationList != null) {
      PaginationUtil.handlePagination(this.props.automationList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (prevProps.automationFacilityList != this.props.automationFacilityList && this.props.automationFacilityList != null) {
      this.selectedFacility(this.props.automationFacilityList);
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      let tempObj = {};
      tempObj.value = this.props.facilityDetails.facilityId; tempObj.label = this.props.facilityDetails.facilityName;
      this.handleLocationDropdownChange(tempObj);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      PaginationUtil.initPaginationParams(this);
      this.setSelectedTabDetails(this.state.selectedTab);
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
      this.props.facilityList), 'facilityId', 'facilityName', null, false, "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))
    let { location } = this.state;
    let selectedLocation = [];
    if(location) {
      selectedLocation = tempList.filter(item => item.value == location)
    }
    await this.setState({
      facilityList: tempList,
      location: location ? selectedLocation[0].value : tempList[0].value,
      locationName: location ? selectedLocation[0].label : tempList[0].label
    })
    tempList && tempList.length > 0 && await this.setSelectedTabDetails(this.state.selectedTab)
  }

  // updateFacilityDropDownList = async () => {
  //   let params = CommonUtil.getAdditonalPathParams(this);
  //   let tempList = CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
  //     this.props.facilityList), 'facilityId', 'facilityName', null, false, "FAC-")
  //   tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));

  //   let tempObj;
  //   if (CommonUtil.isNotNull(tempList) && tempList.length > 0) {
  //     tempObj = tempList[0];
  //     if (CommonUtil.isNotNull(params) && CommonUtil.isNotNull(params.FACILITY)) {
  //       tempObj = CommonUtil.getFilteredObjFromArray(this.props.facilityList, 'facilityId', params.FACILITY);
  //       const { location, history } = this.props;
  //       history.replace();
  //     }
  //     // await this.setState({ location: tempObj.facilityId, locationName: tempObj.facilityName });
  //     // this.setSelectedTabDetails();
  //   }

  //   await this.setState({
  //     facilityList: tempList,
  //     location: tempObj.facilityId, 
  //     locationName: tempObj.facilityName
  //   });

  //   this.setSelectedTabDetails();
  // }

  selectedFacility = async (list) => {
    if (CommonUtil.isNotNull(list)) {
      await this.props.getFacilityDetails(list[0].facilityId);
    } 
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.automationList &&
      this.props.automationList.filter((value) => {
        return (
          String(value.name).toLowerCase().includes(searchInput.toLowerCase())
          // String(value.ingredientName).toLowerCase().includes(searchInput.toLowerCase()) ||
          // String(value.uniqueId).toLowerCase().includes(searchInput.toLowerCase())
        );
      });
    this.setState({ tableDataList: filteredData })
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ location: tempObj.value, locationName: tempObj.label });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  makeCustomAPICall(tempParamas) {
    this.props.getAutomationList(tempParamas);
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (tempId != null && tempId[1] == commonConstant.MENU_ACTION_MODE) {
      CommonUtil.overlay(event);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      this.handleMenuPopupAction(event);
    }
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedAutomationCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(automationConstant.CREATE_AUTOMATION_PAGE_URL, this);
  };

  handleMenuPopupAction = (event) => {
    let tempId = event.target.id.split("_");
    if (tempId[2] == automationConstant.CREATE_AUTOMATION) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(automationConstant.CREATE_AUTOMATION_PAGE_URL, this);
    }
  };

  // handleMenuPopupAction = async (event) => {
  //   let tempId = event.target.id.split("_");
  //   if (tempId[2] == purchaseOrderConstant.CREATE_PURCHASE_ORDER) {
  //     this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
  //     CommonUtil.handlePageRedirection(purchaseOrderConstant.CREATE_PURCHASE_ORDER_PAGE_URL, this);
  //   } else if (tempId[2] == purchaseOrderConstant.VIEW_PAYMENT_DETAILS) {
  //     await this.setState({ openPaymentModal: true, purchaseOrderId: tempId[0] });
  //   } else if (tempId[2] == stockAdjustmentConstant.PO_RETURN_STATUS) {
  //     this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
  //     let params = { orderCode: tempId[0], action: stockAdjustmentConstant.PO_RETURN_STATUS };
  //     this.props.setCreditNoteDetails(params);
  //     CommonUtil.handlePageRedirection(stockAdjustmentConstant.CREATE_STOCK_ADJUSTMENT_PAGE_URL, this);
  //   } else if (tempId[2] == statusConstant.UPDATE_STATUS) {
  //     this.setState({ purchaseOrderId: tempId[0] });
  //     PurchaseOrderUtil.handleAmendStatusPopup(this);
  //   }
  // };

  handleTableLinkButtonClick = (event) => {
    let automationRuleId = event.target && event.target.id.split("_")[0];
    let automationRuleName = event.target && event.target.id.split("_")[2];
    this.setState({ openRuleModal: true, automationRuleId: automationRuleId, automationRuleName: automationRuleName });
    // this.setState({ openRuleModal: true });
  }

  getUpdatedRuleDetails = () => {
    this.setState({ openRuleModal: false, automationRuleId: null });
    // this.setState({ openRuleModal: false });
  }

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    PaginationUtil.initPaginationParams(this);
    if (tempId[1] === "search") {
      await this.setState({ search: null, searchInput: "" });
      await this.setSelectedTabDetails(this.state.status);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, search } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={automation} alt="" className="page-icon" />
                  {automationConstant.MANAGE_AUTOMATION_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                  <form onSubmit={this.handleSubmit}>
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Name"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </form>
                  </div>
                  {
                    isAuthorized("automationCreate") &&
                    <Button
                      id={"automationrule" + "_" + commonConstant.MENU_ACTION_MODE +
                        "_" + automationConstant.CREATE_AUTOMATION}
                      fill wd className="create-options btn-default btn-fill btn-wd"
                      onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                    </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div className="automation-section">
                    {search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <FormGroup className="location-dropdown">
                      <div className="location-control">
                        <img src={pin} alt="" />
                        <div title={this.state.locationName} >
                          <Select
                            classNamePrefix="react-select"
                            name="location"
                            placeholder="Location"
                            value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                            onChange={(value) => this.handleLocationDropdownChange(value)}
                            options={[...this.state.facilityList]} />
                        </div>
                      </div>
                    </FormGroup>
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                    {this.state.openRuleModal == true ?
                      <AutomationRuleModal
                        automationRuleId={this.state.automationRuleId}
                        automationRuleName={this.state.automationRuleName}
                        facilityId={this.state.location}
                        facilityName={this.state.locationName}
                        getUpdatedRuleDetails={this.getUpdatedRuleDetails}>
                      </AutomationRuleModal>
                      : null}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    facilityList: state.facility.facilityList,
    automationList: state.automation.automationList,
    automationFacilityList: state.automation.automationFacilityList,
    supplierList: state.supplier.supplierList,
    productList: state.product.productList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    facilityDetails: state.facility.facilityDetails,
  };
}

const mapDispatchToProps = dispatch => ({
  getAutomationList: params => dispatch(getAutomationList(params)),
  getAutomationFacilityList: () => dispatch(getAutomationFacilityList()),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  setSelectedAutomationCode: params => dispatch(setSelectedAutomationCode(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageAutomation);