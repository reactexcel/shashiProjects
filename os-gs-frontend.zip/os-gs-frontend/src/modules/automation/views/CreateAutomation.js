import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { setActionMode } from "../../../actions/appActions";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { getProductList } from '../../productManagement/actions/productActions';
import { getIngredientList } from "../../ingredientManagement/actions/ingredientActions";
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getAutomationDetails, setAutomationDetails, updateAutomationRuleDeleteStatus } from "../actions/automationActions";
import * as automationConstant from '../constant/automationConstant';
import * as statusConstant from "../../common/constant/statusConstant";
import * as commonConstant from "../../common/constant/commonConstant";
import CommonUtil from '../../common/util/commonUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import ValidationUtil from '../../common/util/validationUtil';
import PopupUtil from '../../common/util/popupUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import _ from 'lodash'
import mixpanel from "../../analytics/mixpanel/mixpael";
import automation from "assets/img/automation-page-icon.svg";
import TagsInput from "react-tagsinput";
import MultipleSelectionModal from './MultipleSelectionModal';
import isAuthorized from "auth-plugin";

class CreateAutomation extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      multipleSelectionModal: false,
      productList: [],
      categoryList: [],
      emailIdList: []
    };
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleFilledTags = this.handleFilledTags.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Create Automation loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getAutomationDetails(this.props.selectedAutomationCode);
      }
    } else {
      CommonUtil.handlePageRedirection(automationConstant.MANAGE_AUTOMATION_PAGE_URL, this);
    }
    this.props.getFacilityList({ "sourceChannel": commonConstant.ORIGINSCALE });
    let topAttributeList = pagePropertyListConstant.CREATE_AUTOMATION_HEADER_PAGE_LIST(this);
    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        topAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: {
        ...topAttributeList.attributeObj,
        ruleCode: automationConstant.AUTOMATION_RULE_LIST[0].value
      },
    });

    await this.handleCustomDropDownChange(automationConstant.AUTOMATION_RULE_LIST[0], { name: 'ruleCode'} );
  }

  handleCustomDropDownChange = async (event, obj) => {
    if (obj.name == 'ruleCode') {
      await this.intializeRuleListValues();
      CommonUtil.handleDropDownChange(event, obj, this);
      this.handlePageViewByRuleCode(event.value);
      this.updateAttributeObjByRuleCode(event.value);
    } else if (obj.name == 'transferType') {
      await this.intializeRuleListValues();
      CommonUtil.handleDropDownChange(event, obj, this);
      this.handleTransferTypeChange(event.value);
    } else if (obj.name == 'facilityId') {
      await CommonUtil.handleDropDownChange(event, obj, this);
      this.handleFacilityDropDownChange(event.value);
    }
  }

  handleFacilityDropDownChange = (facilityId) => {
    let { attributeObj } = this.state;
    if (attributeObj.ruleCode == "AUTORULE3" && attributeObj.transferType == "inward") {
      attributeObj.toLocation = facilityId;
      this.setState({ attributeObj: attributeObj });
    } else if (attributeObj.ruleCode == "AUTORULE3" && attributeObj.transferType == "outward") {
      attributeObj.fromLocation = facilityId;
      this.setState({ attributeObj: attributeObj });
    }
  }

  validateTransferLocation = () => {
    let { attributeObj } = this.state;
    if (attributeObj.ruleCode == "AUTORULE3") {
      if (attributeObj.toLocation == attributeObj.fromLocation) {
        let popupActionButton = {};
        popupActionButton.onCancelClick = this.handlePopupCancel;
        let popupConfig = CommonUtil.preparePopUpConfigWithOnlyCancel(popupActionButton
          , automationConstant.SAME_FACILITY);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
        return true;
      }
    }
  }

  isValidMakeProduct = () => {
    let { attributeObj } = this.state;
    if (attributeObj.ruleCode == "AUTORULE1") {
      // let tempProductObj = CommonUtil.getFilteredObjFromArray(this.state.productList,
      //   'productId', attributeObj.uniqueId);
      // if (tempProductObj.source == "make") {
      //   if ((tempProductObj.ingredients && tempProductObj.ingredients.length == 0) || (tempProductObj.operations && tempProductObj.operations.length == 0)) {
      //     let popupActionButton = {};
      //     popupActionButton.onCancelClick = this.handlePopupCancel;
      //     let popupConfig = CommonUtil.preparePopUpConfigWithOnlyCancel(popupActionButton,
      //       automationConstant.INVALID_MAKE_PRODUCT);
      //     this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
      //     return true;
      //   }
      // }
    }
  }

  handleTransferTypeChange = (transferType) => {
    let { attributeObj, attributeListBottom } = this.state;
    if (transferType == "inward") {
      attributeListBottom = CommonUtil.setDisabledPropertyInAttribute(attributeListBottom, ['fromLocation'], false);
      attributeListBottom = CommonUtil.setDisabledPropertyInAttribute(attributeListBottom, ['toLocation'], true);
      attributeObj.actionCondition = "lessThanEuqal";
      attributeObj.fromLocation = "";
      attributeObj.toLocation = attributeObj.facilityId;
    } else {
      attributeListBottom = CommonUtil.setDisabledPropertyInAttribute(attributeListBottom, ['toLocation'], false);
      attributeListBottom = CommonUtil.setDisabledPropertyInAttribute(attributeListBottom, ['fromLocation'], true);
      attributeObj.actionCondition = "greaterThanEqual";
      attributeObj.fromLocation = attributeObj.facilityId;
      attributeObj.toLocation = "";
    }
    this.setState({ attributeListBottom: attributeListBottom, attributeObj: attributeObj });
  }

  intializeRuleListValues = async () => {
    let { attributeObj } = this.state;
    // attributeObj.actionAttribute = '';
    // attributeObj.actionCondition = '';
    attributeObj.comparisionValue = '';
    attributeObj.processValue = '';
    // attributeObj.additionalAction1 = '';
    attributeObj.additionalAction2 = '';
    attributeObj.fromLocation = '';
    attributeObj.transferType = '';
    attributeObj.toLocation = '';
    attributeObj.saleChannel = '';
    await this.setState({ attributeObj: attributeObj });
  }

  handlePageViewByRuleCode = async (ruleCode) => {
    let attributeListBottom = [];
    if (ruleCode == "AUTORULE1") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE1_PAGE_LIST(this)));
    } else if (ruleCode == "AUTORULE2") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE2_PAGE_LIST(this)));
    } else if (ruleCode == "AUTORULE3") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE3_PAGE_LIST(this)));
    }
    await this.setState({
      attributeListBottom: CommonUtil.getDropDownOptionsFromDictionary(
        attributeListBottom.attributeList, this.props.dataDictionaryList),
    });
    this.updateSTOFacilityDropDownList(ruleCode);
  };

  updateAttributeObjByRuleCode = async (ruleCode) => {
    let attributeListBottom = [];
    if (ruleCode == "AUTORULE1") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE1_PAGE_LIST(this)));
    } else if (ruleCode == "AUTORULE2") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE2_PAGE_LIST(this)));
    } else if (ruleCode == "AUTORULE3") {
      attributeListBottom = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_AUTOMATION_RULE3_PAGE_LIST(this)));
    }
    let attributeObjBottom = {};
    const { attributeObj } = this.state;
    attributeObjBottom = attributeListBottom.attributeObj;
    attributeObjBottom.ruleCode = attributeObj.ruleCode;
    // attributeObjBottom.uniqueId = attributeObj.uniqueId;
    attributeObjBottom.facilityId = attributeObj.facilityId;
    attributeObjBottom.status = attributeObj.status;
    attributeObjBottom.isProduct = true;
    attributeObjBottom.isRuleExecuted = false;
    attributeObjBottom.processValue = 0;
    attributeObjBottom.emailIds = attributeObj.emailIds || [];
    attributeObjBottom.description = attributeObj.description;

    await this.setState({ attributeObj: attributeObjBottom });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      if (CommonUtil.isCloneMode(this.props.actionMode)) {
        this.updateCloneData(this.props.attributeObj);
      } else {
        this.updateApiData(this.props.attributeObj);
      }
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    // if (this.props.productList != null && prevProps.productList != this.props.productList) {
    //   this.updateProductDropDownList();
    // }
    // if (this.props.ingredientList != null && prevProps.ingredientList != this.props.ingredientList) {
    //   this.updateIngredientDropDownList();
    // }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
  };

  async updateApiData(attributeObj) {
    await this.setState(
      { 
      attributeObj: { ...attributeObj },
      productList: attributeObj.productList ? attributeObj.productList : [],
      categoryList: attributeObj.categoryList ? attributeObj.categoryList : [],
      emailIdList: attributeObj.emailIds && typeof attributeObj.emailIds == 'string'  ? String(attributeObj.emailIds).split(',') : [],
    });
    await this.handlePageViewByRuleCode(attributeObj.ruleCode);
    let { attributeListBottom } = this.state;
    if (CommonUtil.isNotNull(attributeObj.transferType) && CommonUtil.isNotNull(attributeListBottom)) {
      if (attributeObj.transferType == "inward") {
        attributeListBottom = attributeListBottom.map((item) => {
          if (item.name == "toLocation") {
            item.isCustomDisabled = 'true';
          }
          return item;
        });
      } else {
        attributeListBottom = attributeListBottom.map((item) => {
          if (item.name == "fromLocation") {
            item.isCustomDisabled = 'true';
          }
          return item;
        });
      }
    }
    await this.setState({ attributeListBottom: attributeListBottom });
  };

  updateCloneData(attributeObj) {
    this.setState({
      attributeObj: {
        ...attributeObj,
        ruleCode: '',
      }
    });
    this.handlePageViewByRuleCode(attributeObj.ruleCode);
  };

  // updateProductDropDownList = () => {
  //   this.setState({ productList: this.props.productList });
  //   this.mergeProductIngredientList();
  // };

  // updateIngredientDropDownList = () => {
  //   // this.setState({ ingredientList: this.props.ingredientList });
  //   this.setState({ ingredientList: [] });
  //   this.mergeProductIngredientList();
  // };

  // mergeProductIngredientList = () => {
  //   let productList = [], ingredientList = [];
  //   productList = this.props.productList && this.props.productList ? this.props.productList : [];
  //   ingredientList = this.props.ingredientList && this.props.ingredientList ? this.props.ingredientList : [];
  //   this.setState({
  //     attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList,
  //       [...CommonUtil.getOptionsFromList(productList, 'productId', 'productName'),
  //       ...CommonUtil.getOptionsFromList(ingredientList, 'ingredientId', 'ingredientName')], 'uniqueId')
  //   })
  // };

  updateFacilityDropDownList = () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-");
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'facilityId')
    })
  };

  updateSTOFacilityDropDownList = (ruleCode) => {
    if (ruleCode == "AUTORULE3") {
      let tempList = CommonUtil.getOptionsFromList(this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-");
      tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
      this.setState({
        attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, ['fromLocation', 'toLocation'])
      })
    }
  };

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      setTimeout(this.handlePopupContinue, 0);
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      if (PopupUtil.getCustomCustomErrorCode(this) == "409") {
        PopupUtil.popupErrorResponse(this, automationConstant.DUPLICATE_AUTOMATION);
      } else if (PopupUtil.getCustomCustomErrorCode(this) == "403") {
        PopupUtil.popupErrorResponse(this, automationConstant.DEFAULT_SUPPLIER);
      }
      else {
        let responseData = this.props.ajaxCallStatus.data;
        console.log(' errror ----->>> ' + JSON.stringify(responseData));
        PopupUtil.popupErrorResponse(this);
      }
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleSave = () => {
    this.setState({ submitted: true });
    let tempObj = this.state.attributeObj;
    tempObj.productList = this.state.productList;
    tempObj.categoryList = this.state.categoryList;
    tempObj.emailIds = this.state.emailIdList;
    
    const automationRuleId = this.state.attributeObj.automationRuleId

    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, this.props.actionMode);
    if (this.validateTransferLocation() || this.isValidMakeProduct()) {
      return;
    }

    if (tempObj.productList.length == 0 && tempObj.categoryList.length == 0) {
      this.setState({ customError: true})
    } else {
      this.setState({ customError: false})
    }

    if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeListBottom)) {
        if (tempObj.productList.length > 0 || tempObj.categoryList.length > 0) {
          this.props.setAutomationDetails(tempObj, this.props.actionMode, automationRuleId)
        }
      }
    }
  }

  handlePopupContinue() {
    const { attributeObj } = this.state;
    let params = { FACILITY: attributeObj.facilityId };
    CommonUtil.handlePageRedirection(automationConstant.MANAGE_AUTOMATION_PAGE_URL, this, params);
  }

  cloneAutomationRule = (params) => {
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      return;
    }
    this.props.setActionMode(commonConstant.CLONE_ACTION_MODE);
    this.props.getAutomationDetails(this.state.attributeObj.automationRuleId);
  };

  deleteAutomationRule = (params) => {
    if (!CommonUtil.isEditMode(this.props.actionMode)) {
      return;
    }
    // if (this.state.attributeObj.status !== statusConstant.NEW_STATUS) {
    //   return;
    // }
    let popupActionButton = {};
    popupActionButton.onConfirmClick = this.handleStatusAction;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeletPopUpConfig(
      popupActionButton, automationConstant.MODULE_NAME);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  };

  handleStatusAction = (status) => {
    let tempObj = {};
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updateAutomationRuleDeleteStatus(tempObj, this.state.attributeObj.automationRuleId);
  };
  
  handleHeaderIconClick = (e, action) => {
    switch (action) {
      // case commonConstant.PRINT_ACTION:
      //   this.printPurchaseOrder();
      //   break;
      case commonConstant.CLONE_ACTION:
        this.cloneAutomationRule();
        // this.setSelectedTableDetails(this.state.receivedStatusFlag)
        break;
      case commonConstant.TRASH_ACTION:
        this.deleteAutomationRule();
        break;
      // case commonConstant.DOWNLOAD_ACTION_MODE:
      //   this.downloadPurchaseOrder();
      //   break;
      default:
        console.log("Invalid header action");
    }
  };

  handleFilledTags(filledTags) {
    this.setState({
      emailIdList: filledTags,
    });
    // if (this.state.emailList != '') {
    //   let tempList = attributeObj && attributeObj.filter(item => {
    //     if(item.dataType !== this.state.emailList) {
    //       return item;
    //     }
    //     // if(!filledTags.includes(item.label) && item.dataType !== this.state.emailList) {
    //     //   return item;
    //     // }
    //   })
    //   for (var i = 0; i < filledTags.length; i++) {
    //     var tempObj = {}
    //     let tempValue = attributeObj && attributeObj.filter(item => {
    //       if(item.label == filledTags[i] && item.dataType == this.state.emailList) {
    //         return item
    //       }
    //     })
    //     tempObj.value = tempValue && tempValue.length > 0 ? tempValue[0].value : 0;
    //     tempObj.label = filledTags[i];
    //     tempObj.dataType = this.state.emailList;
    //     tempList.push(tempObj)
    //   }
    //   this.setState({
    //     attributeObj: tempList,
    //   })
    // }
  }

  handleSelection = (event, showSelected) => {
    this.setState({ multipleSelectionModal: true, showSelected: showSelected });
  }

  getProductSelectionDetails = async (data, closePopUp) => {
    let { productList, showSelected } = this.state;
    if(data && data.length >= 0) {
      let tempList = showSelected ? data : [...productList, ...data];
      await this.setState({ productList : _.uniqBy(tempList, 'productId') })
    }
    if(closePopUp) {
      this.setState({ multipleSelectionModal: false });
    }
  }
  render() {
    const { attributeList, attributeObj, submitted, attributeListBottom, customError } = this.state;
    const { actionMode } = this.props;
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={automation} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    automationConstant.EDIT_AUTOMATION_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      automationConstant.VIEW_AUTOMATION_HEADER_TITLE
                      : automationConstant.CREATE_AUTOMATION_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                {/* {isAuthorized("createPurchaseOrderActions") && */}
                    <div className="page-action-buttons">
                      {/* <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-copy' : 'fa fa-copy disabled'} title={"Clone"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.CLONE_ACTION)} ></i> */}
                       { isAuthorized("automationCreate") &&
                       <i className={(CommonUtil.isEditMode(actionMode)) ? 'fa fa-trash' : 'fa fa-trash disabled'} title={"Trash"}
                        onClick={(e) => this.handleHeaderIconClick(e, commonConstant.TRASH_ACTION)} ></i>
                      }
                    </div>
                  {/* } */}
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-save btn-fill" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        <Col md={12}>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : null))
                            }
                          </Row>
                          <Row>
                            {customError && <Col md={12}><p className="text-danger">Please select atleast one product to create automation.</p></Col>}
                            <Col md={12}>
                              <div className="orgcontact-title">Applicable on</div>
                            </Col>
                          </Row>
                          <Row>
                            <Col md={4}>
                              <div className="tax-selection-box">
                                <Button className="btn-save btn-fill" onClick={(e) => this.handleSelection(e, false)} style={{ marginLeft: '0'}}>Select Product</Button>
                                <div className="tax-selected" onClick={(e) => (!this.state.productList.includes('all')) && this.state.productList.length > 0 && this.handleSelection(e, true)}>{this.state.productList.includes('all') ? "All" : this.state.productList.length} Products Selected</div>
                              </div>
                            </Col>
                          </Row>
                          {this.state.multipleSelectionModal == true ?
                            <MultipleSelectionModal
                              getProductSelectionDetails={this.getProductSelectionDetails}
                              selectedProductList={this.state.productList}
                              showSelected={this.state.showSelected}>
                            </MultipleSelectionModal>
                          : null}
                        </Col>
                      </Row>
                      <Row>
                        <Col md={12}>
                          <Row>
                            {attributeListBottom != null && attributeListBottom.map((tempAttributeListObj, index) => (

                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : tempAttributeListObj.type == "TEXT_LIST" ? 
                                  (<Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                    <FormGroup >
                                      <ControlLabel>
                                        {tempAttributeListObj.label}
                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                      </ControlLabel>
                                      <TagsInput
                                        value={this.state.emailIdList}
                                        onChange={this.handleFilledTags}
                                        tagProps={{
                                          className: "react-tagsinput-tag tag-fill tag-grey",
                                        }}
                                        className="react-tagsinput-normal"
                                        disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                                        inputProps={{
                                          placeholder: tempAttributeListObj.placeholder,
                                        }}
                                        
                                        addOnBlur={true}
                                      />
                                    </FormGroup>
                                  </Col>) : null
                                  ))
                            }
                          </Row>
                        </Col>
                      </Row>
                    </div>
                  }
                  ftTextRight
                  legend={
                    !CommonUtil.isViewMode(this.props.actionMode) ?
                      <div>
                        <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                        <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                      </div>
                      :
                      <Button className="btn-save btn-fill" onClick={this.handlePopupContinue}>Back</Button>

                  }
                />
              </form>
            </Col>
          </Row>

        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    attributeObj: state.automation.automationDetails,
    selectedAutomationCode: state.automation.selectedAutomationCode,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    productList: state.product.productList,
    ingredientList: state.ingredient.ingredientList,
    facilityList: state.facility.facilityList,
  };
}

const mapDispatchToProps = dispatch => ({
  setAutomationDetails: (automationDetailsObj, actionMode, automationRuleId) => dispatch(setAutomationDetails(automationDetailsObj, actionMode, automationRuleId)),
  getAutomationDetails: automationCode => dispatch(getAutomationDetails(automationCode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (params) => dispatch(getProductList(params)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  updateAutomationRuleDeleteStatus: (automationRuleDetails, automationRuleId) => dispatch(updateAutomationRuleDeleteStatus(automationRuleDetails, automationRuleId)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateAutomation);
