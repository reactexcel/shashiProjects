import React, { Component } from "react";
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getProductList } from '../../productManagement/actions/productActions';
import PaginationUtil from "../../common/util/paginationUtil";
import Datetime from "react-datetime";
import moment from "moment";
import _ from "lodash";
var Modal = require('react-bootstrap-modal')

class MultipleSelectionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataList: [],
      params: null,
      brand: '',
      brandName: '',
      categoryName: '',
      category: '',
      brandSearch: '',
      brandList: [],
      categoryList: [],
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      allList: [{ label: 'All', value: '' }],
      isAllChecked: false,
      customError: false,
      fromDate: '',
      toDate: '',
      autoSave: false,
      searchProducts: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    await this.setSelectedTabDetails();
  };

  setSelectedTabDetails = async () => {
    let selectedProducts = this.props.selectedProductList && this.props.selectedProductList.length > 0 && this.props.selectedProductList.map(item => item.productId);
    const managePageList = pagePropertyListConstant.MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST(this);
    const { search, brand, fromDate, toDate, category } = this.state;
    var additionalParams = {};
    additionalParams["isDropdown"] = true;
    additionalParams["clientSource"] = 'taxes';
    if(this.props.showSelected) additionalParams["productIds"] = _.size(selectedProducts) > 0 && selectedProducts.join(',');
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    if(CommonUtil.isNotNull(brand)) additionalParams["brand"] = brand;
    if(CommonUtil.isNotNull(category)) additionalParams["categoryId"] = category;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["fromDate"] = fromDate;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["toDate"] = toDate;
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    let tableConfig = this.props.showSelected ? managePageList.tableConfigSelected : managePageList.tableConfig
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: tableConfig,
      attributeObj: searchAttributeList.attributeObj,
      additionalParams: additionalParams,
      customPagination: this.props.showSelected,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      brandList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'brandList')],
      categoryList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'categoryList')],
    });
    await this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      tableConfig.defaultPageSize, this));
  };

  makeCustomAPICall(tempParamas) {
    this.setState({isAllChecked: false});
    (this.state.searchProducts || this.props.showSelected) && this.props.getProductList(tempParamas);
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList(this.props.productList);
    }
  }

  updateProductDropDownList = async (productList) => {
    let selectedProducts = this.props.showSelected && this.props.selectedProductList && this.props.selectedProductList.length > 0 && this.props.selectedProductList.map(item => {
      return item.productId;
    });
    let temp = _.size(selectedProducts) > 0 && selectedProducts.map(item => {
      let tempObj = {
        "productId" : item,
        "isChecked" : true
      }
      return tempObj;
    })
    let list = productList;
    list.map(item => {
      if(selectedProducts && selectedProducts.includes(item.productId)) {
        item.isChecked = true
      }
      return item;
    })
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    let checkedList = list.filter(item => item.isChecked);
    let unCheckedList = list.filter(item => !item.isChecked);
    list = [...checkedList, ...unCheckedList]
    await this.setState({ tableDataList: [] })
    await this.setState({ tableDataList: list, selectedProducts: temp })
  }

  closeModal = (event) => {
    this.props.getProductSelectionDetails(null, true);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave = async (event) => {
    let { tableDataList, selectedProducts } = this.state;
    selectedProducts = _.size(selectedProducts) > 0 && selectedProducts.map(x => {
      tableDataList.map(y => {
        if(x.productId == y.productId) {
          x.isChecked = y.isChecked
        }
      })
      return x
    })
    tableDataList = this.props.showSelected ? [...selectedProducts, ...tableDataList] : tableDataList
    let tempList = [];
    tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
      return {"productId": item.productId};
    })
    if(tempList && tempList.length >= 0) {
      this.setState({ openModal: false, submitted: true, autoSave: false, alert: null });
      this.props.getProductSelectionDetails(tempList, true);
    }
  }

  handlePopupContinue = async (event) => {
    let { tableDataList, selectedProducts } = this.state;
    selectedProducts = _.size(selectedProducts) > 0 && selectedProducts.map(x => {
      tableDataList.map(y => {
        if(x.productId == y.productId) {
          x.isChecked = y.isChecked
        }
      })
      return x
    })
    tableDataList = [selectedProducts, ...tableDataList]
    let tempList = [];
    tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
      return {"productId": item.productId};
    })
    if(tempList && tempList.length >= 0) {
      this.setState({ submitted: true, autoSave: false, alert: null });
      await this.props.getProductSelectionDetails(tempList, false);
      await this.makeCustomAPICall(PaginationUtil.getPaginationParams(this.state.currentPage - 1, null, this, true))
    } else {
      this.setState({ submitted: true, autoSave: false, alert: null });
    }
  }

  handleSaveAll = async (event) => {
    let tempList = [];
    tempList.push('all')
    if(tempList && tempList.length > 0) {
      this.setState({ openModal: false, submitted: true});
      this.props.getProductSelectionDetails(tempList, true);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null, currentPage: this.state.pageNumber });
  }

  handlebrandDropdownChange = async (tempObj) => {
    await this.setState({
      brand: tempObj.value, brandName: tempObj.label,
    });
  }

  handlecategoryDropdownChange = async (tempObj) => {
    await this.setState({
      category: tempObj.value, categoryName: tempObj.label,
    });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.props.showSelected && this.globalSearch();
    });
  }

  globalSearch = async () => {
    let { searchInput } = this.state;
    let list = this.props.productList
    list = await list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    let filteredData = list.filter((value) => {
      return (
        String(value.productId).includes(searchInput) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productSKU.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: filteredData });
  };

  advanceSearch = async () => {
    if (!this.props.showSelected) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim(), searchProducts: true });
      this.setSelectedTabDetails();
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    !this.props.showSelected && this.advanceSearch();
  }

  handleRemoveFilter = async (event) => {
    this.setState({ search: null, searchInput: "", brand: null, brandName: "", category: null, categoryName: "", fromDate : "", toDate: "", searchProducts: false, tableDataList: [] });
  }

  handleCheckBoxChange = async (event) => {
    const { id, checked } = event.target;
    var tempId = id.split("_");
    const { tableDataList } = this.state;
    tableDataList.map((item) => {
      if(item.productId == tempId[0]) {
        item.isChecked = checked;
      }
    })
    await this.setState({
      autoSave: true,
      tableDataList: tableDataList
    })
  }

  handleAllCheckboxChange = async (event) => {
    const { checked } = event.target;
    const { tableDataList } = this.state;
    tableDataList.map((item, index) => {
      item.isChecked = checked;
    })
    await this.setState({
      autoSave: true,
      isAllChecked : checked,
      tableDataList: tableDataList
    })
  }

  handleDateChange(event, eventId) {
    var name = eventId.split('_')[0];
    this.setState({
      [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : ''
    })
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, customError, brand, category, fromDate, toDate, searchProducts} = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
        {this.state.alert}
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Select Products</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            <Row className="header-section" style={{marginBottom: '30px'}}>
                              <Col md={12}>
                                <Row>
                                  {!this.props.showSelected && <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="category"
                                      onChange={(value) => this.handlecategoryDropdownChange(value)}
                                      value={{ "label": this.state.categoryName ? this.state.categoryName : 'Select Category' }}
                                      options={[...this.state.allList, ...this.state.categoryList]}
                                      placeholder="Select Category"
                                    />
                                  </Col>}
                                  {!this.props.showSelected && <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="brand"
                                      onChange={(value) => this.handlebrandDropdownChange(value)}
                                      value={{ "label": this.state.brandName ? this.state.brandName : 'Select Brand' }}
                                      options={[...this.state.allList, ...this.state.brandList]}
                                      placeholder="Select Brand"
                                    />
                                  </Col>}
                                  <Col md={6}>
                                    <div className="right-section multi-selection ">
                                      <div className="search-section advance" style={{width: '100%'}}>
                                        <form onSubmit={this.handleSubmit}>
                                        <i className="fa fa-search"></i>
                                        <FormControl type="text" name="searchInput" placeholder="Search by Product Code/Name/SKU"
                                          value={this.state.searchInput} onChange={this.handleChange} />
                                        </form>
                                      </div>
                                    </div>
                                  </Col>
                                </Row>
                                {!this.props.showSelected && <Row style={{marginTop: "20px", display: 'flex', alignItems: 'center'}}>
                                  <Col md={3}>
                                    <Datetime
                                      id="fromDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                        readOnly: true,
                                        placeholder: "From Date",
                                        disabled: false,
                                        title: CommonUtil.getFormattedDate(this.state.fromDate)
                                      }}
                                      name="fromDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'fromDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.fromDate)}
                                    />
                                  </Col>
                                  <Col md={3}>
                                    <Datetime
                                      id="toDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                        readOnly: true,
                                        placeholder: "To Date",
                                        disabled: false,
                                        title: CommonUtil.getFormattedDate(this.state.toDate)
                                      }}
                                      name="toDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'toDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.toDate)}
                                    />
                                  </Col>
                                  <Col md={6} style={{ display: 'flex'}}><Button className="btn-save btn-fill" onClick={this.advanceSearch} style={{marginLeft : 0}}>Search</Button>
                                  {searchProducts ? <Button className="btn-cancel" onClick={this.handleRemoveFilter}>Reset</Button> : null}
                                  </Col>
                                </Row>}
                              </Col>
                            </Row>
                            {customError && <Row><Col md={12}><p className="text-danger">Product limit of 500 has reached in the order.</p></Col></Row>}
                            {tableColumnList != null ? (
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table className={"table-box-height"} 
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                    showCheck={true}
                                  />
                                ) : null}
                              </Row>
                            ) : null}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    productList: state.product.productList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (id) => dispatch(getProductList(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MultipleSelectionModal);
