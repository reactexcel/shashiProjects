import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { Redirect } from "react-router-dom";
import { getAutomatRulesByProduct, updateProductAutomationRules, setSelectedAutomationCode, getAutomationDetails } from "../actions/automationActions";
import { getProductDetailList } from '../../productManagement/actions/productActions';

import * as commonConstant from "../../common/constant/commonConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as automationConstant from '../constant/automationConstant';
import CommonUtil from "../../common/util/commonUtil";
import ValidationUtil from "../../common/util/validationUtil";
import PopularTableUtil from '../../common/util/popularTableUtil';
import { setActionMode } from "../../../actions/appActions";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import isAuthorized from "auth-plugin";
var Modal = require('react-bootstrap-modal')

class AutomationRuleModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      redirect: false,
      redirectUrl: null,
      alert: null,
      tableDataKey: "tableDataList",
      currentPage: 1,
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    // const managePageList = pagePropertyListConstant.MANAGE_AUTOMATION_RULE_PAGE_LIST(this);
    const managePageList = pagePropertyListConstant.MANAGE_PAGE_AUTOMATION_PRODUCTS_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
    // this.props.getAutomatRulesByProduct({
    //   automationRuleId: this.props.automationRuleId,
    //   facilityId: this.props.facilityId
    // });
    this.props.getAutomationDetails(this.props.automationRuleId);
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    // if (this.props.automationProductRuleList != null && prevProps.automationProductRuleList != this.props.automationProductRuleList) {
    //   this.setState({ tableDataList: [...this.props.automationProductRuleList] });
    // }

    if (this.props.automationDetails != null && prevProps.automationDetails != this.props.automationDetails) {
      const tempList = this.props.automationDetails.productList.map((p) => p.productId);
      if(tempList && tempList.length > 0) {
        this.props.getProductDetailList(tempList)
      }
      // this.setState({ tableDataList: [...this.props.automationDetails.productList ] });
    }

    if (this.props.productDetailList != null && prevProps.productDetailList != this.props.productDetailList) {
      let tempList = this.props.productDetailList;
      this.setState({ tableDataList: [...tempList ] });
    }
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  handleTableSwitchChange = (event, state) => {
    PopularTableUtil.handleTableSwitchChange(event, state, this, this.getSelectedTablekey());
  }

  handleTableRemove = (event) => {
    PopularTableUtil.handleTableRemove(event, this, this.getSelectedTablekey());
  };

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  };

  handleEditClone = (id) => {
    let tempId = id.split("_");
    let tempObj = {};
    tempObj.automationRuleId = tempId[0];
    tempObj.ruleCode = tempId[3];
    tempObj.facilityId = this.props.facilityId;
    this.props.setSelectedAutomationCode(tempObj);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(automationConstant.CREATE_AUTOMATION_PAGE_URL, this);
  };

  handleMenuPopupAction = (event) => {
    let tempId = event.target.id.split("_");
    if (tempId[2] == automationConstant.CREATE_AUTOMATION) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(automationConstant.CREATE_AUTOMATION_PAGE_URL, this);
    }
  };

  handleSave = (event) => {
    this.setState({ submitted: true });
    const { tableDataList } = this.state;
    let tempObj = {};
    tempObj.productRuleList = tableDataList;
    tempObj.productRuleList = ValidationUtil.removeAttributeFromArrayList(tempObj.productRuleList,
      pagePropertyListConstant.MANAGE_AUTOMATION_RULE_PAGE_LIST(this).tableColumnList,
      commonConstant.CREATE_ACTION_MODE);

    if (!ValidationUtil.validateArrayListRequestObj(tempObj.productRuleList,
      pagePropertyListConstant.MANAGE_AUTOMATION_RULE_PAGE_LIST(this).tableColumnList)) {
      return false;
    }
    tempObj.productRuleList = (tempObj.productRuleList.length !== 0) ? tempObj.productRuleList : [{}];
    tempObj.automationRuleId = this.props.automationRuleId;
    tempObj.facilityId = this.props.facilityId;
    this.props.updateProductAutomationRules(tempObj);
    this.props.getUpdatedRuleDetails(true);
    this.setState({ openModal: false, submitted: false });
  }

  handlePopupCancel() {
    this.props.getUpdatedRuleDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { submitted, tableColumnList, tableConfig, tableDataList } = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">OS - Automation(All Active Automation Rule)</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="automation">
                            <Row>
                              <Col md={4} className="automation-details">
                                <div className="heading">Automation Rule Details</div>
                                <div className="value">{this.props.automationRuleId} | {this.props.automationRuleName}</div>
                              </Col>
                              <Col md={4} className="automation-details">
                                <div className="heading">FACILITY</div>
                                <div className="value">{this.props.facilityId}  | {this.props.facilityName}</div>
                              </Col>
                            </Row>
                            {tableColumnList != null ?
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                  <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>
                              : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <div>
                            <Button className="btn-cancel" onClick={this.handlePopupCancel}>Cancel</Button>
                            {/* {isAuthorized("automationCreate") && <Button className="btn-save btn-fill" onClick={this.handleSave} >Save</Button>} */}
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    automationProductRuleList: state.automation.automationProductRuleList,
    automationDetails: state.automation.automationDetails,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    productDetailList: state.product.productDetailList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setSelectedAutomationCode: params => dispatch(setSelectedAutomationCode(params)),
  updateProductAutomationRules: params => dispatch(updateProductAutomationRules(params)),
  getAutomatRulesByProduct: params => dispatch(getAutomatRulesByProduct(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getAutomationDetails: automationCode => dispatch(getAutomationDetails(automationCode)),
  getProductDetailList: (id) => dispatch(getProductDetailList(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(AutomationRuleModal);
