export const MANAGE_AUTOMATION_HEADER_TITLE = "Automation";
export const CREATE_AUTOMATION_HEADER_TITLE = "Create Automation";
export const EDIT_AUTOMATION_HEADER_TITLE = "Edit Automation";
export const VIEW_AUTOMATION_HEADER_TITLE = "View Automation";

export const SO_RULE = "soRule";
export const PRODUCT_STOCK_RULE = "productStockRule";

export const MODULE_NAME = "Automation";
export const CREATE_AUTOMATION = "createAutomation";
export const CREATE_AUTOMATION_PAGE_URL = "/admin/create-automation";
export const MANAGE_AUTOMATION_PAGE_URL = "/admin/manage-automation";

export const DAMAGED_STATUS = "pomoOrder";
export const SO_RETURN_STATUS = "soOrder";
export const INVALID_SELECTION_STATUS = "invalidselection";
export const BLOCKED_STATUS = "blocked";
export const DUPLICATE_AUTOMATION = "Records Update Failed! Duplicate Automation Rule.";
export const DEFAULT_SUPPLIER = "Default Supplier not present for the selected product.";
export const INVALID_MAKE_PRODUCT = "Please add at least one ingredient and operation in selected product.";
export const SAME_FACILITY = "From Location and To Location Can't be same!";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_AUTOMATION_LIST_URL = `${BASE_URL}/automations`;
export const GET_AUTOMATION_FACILITY_LIST_URL = `${BASE_URL}/automations/locations`;
export const GET_AUTOMATION_PRODUCT_RULES_URL = `${BASE_URL}/automations/product/`;
export const GET_AUTOMATION_DETAILS_URL = `${BASE_URL}/automations/`;
export const SET_AUTOMATION_UPDATEDELETESTATUS_URL = `${BASE_URL}/automations/`;
export const SET_CREATE_AUTOMATION_DETAILS_URL = `${BASE_URL}/automations/`;
export const SET_UPDATE_AUTOMATION_DETAILS_URL = `${BASE_URL}/automations/`;
export const SET_UPDATE_AUTOMATION_STATUS_URL = `${BASE_URL}/automations/`;
export const SET_AUTOMATION_PRODUCT_RULES_URL = `${BASE_URL}/automations/rules/`;
export const SET_UPDATE_DRAFT_ORDER_STATUS_URL = `${BASE_URL}/automations/update/`;
export const SET_UPDATE_AUTOMATIONRULE_STATUS_URL = `${BASE_URL}/automations/`;

export const AUTOMATION_RULE_LIST = [
    // { label: "Create Draft Order(PO/MO/KIT)", value: "AUTORULE1" },
    { label: "Stock Quantity", value: "AUTORULE1" },
    // { label: "Sale Order Consumption", value: "AUTORULE2" },
    // { label: "Stock Re-allocation", value: "AUTORULE3" }
];

export const AUTOMATION_CONDITION_LIST = [
    { label: "<=", value: "lessThanEuqal" },
    { label: ">=", value: "greaterThanEqual" },
    { label: "==", value: "equal" },
    { label: "!=", value: "notEqual" },
];

export const STOCK_QUANTITY = "stockQuantity";
export const ORDER_QUANTITY = "orderQuantity";
export const DRAFT_ORDER_WITH_NOTIFICATION = "draftOrderWithNotify";
export const NOTIFICATION_ONLY = "notifyOnly";

export const AUTOMATION_ATTRIBUTE_LIST = [
    { label: "Stock Qty", value: STOCK_QUANTITY },
    { label: "Order Qty", value: ORDER_QUANTITY },
];


