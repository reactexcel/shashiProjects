import React from "react";
import Switch from "react-bootstrap-switch";
import CommonUtil from '../../common/util/commonUtil';
import Button from "components/CustomButton/CustomButton.jsx";
import { FormControl, InputGroup } from "react-bootstrap";
import * as commonConstant from "../../common/constant/commonConstant";
import * as statusConstant from "../../common/constant/statusConstant";
import *  as automationConstant from '../constant/automationConstant';
import isAuthorized from "auth-plugin";
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';

export const CREATE_AUTOMATION_HEADER_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      name: '',
      ruleCode: automationConstant.AUTOMATION_RULE_LIST[0].value,
      // uniqueId: '',
      facilityId: '',
      status: statusConstant.ACTIVE_STATUS,
      isRuleExecuted: false,
      emailIds: [],
      productList: [],
      categoryList: [],
    },
    attributeList: [
      {
        name: "name",
        type: "TEXTBOX",
        label: "Rule Name",
        required: true,
        fieldWidth: 4,
        numberOfRow: 0,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: 'enable',
        cloneMode: 'enable',
        editMode: 'enable',
        viewMode: 'disabled',
        maxLength: 100,
        minLength: 2,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "ruleCode",
        type: "DROPDOWN",
        label: "New Automation Rule",
        required: true,
        fieldWidth: 4,
        customAttribute: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: automationConstant.AUTOMATION_RULE_LIST,
      },
      // {
      //   name: "uniqueId",
      //   type: "DROPDOWN",
      //   label: "Product Name",
      //   required: true,
      //   fieldWidth: 4,
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   createMode: "enable",
      //   cloneMode: "enable",
      //   editMode: "disabled",
      //   viewMode: "disabled",
      //   placeholder: "Select",
      //   numberOfRow: 0,
      //   mandatoryMsgText: "Field can not be empty.",
      //   options: [],
      // },
      {
        name: "facilityId",
        type: "DROPDOWN",
        label: "Facility Name",
        required: true,
        fieldWidth: 4,
        customAttribute: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [],
      },
      {
        name: "isRuleExecuted",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "isProduct",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "actionAttribute",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "actionCondition",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "comparisionValue",
        type: "TEMP",
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "processValue",
        type: "TEMP",
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "additionalAction1",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "additionalAction2",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "fromLocation",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "toLocation",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "transferType",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "status",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "saleChannel",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "version",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
      },
      {
        name: "description",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "emailIds",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "productList",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "categoryList",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
    ]
  };
};

export const CREATE_AUTOMATION_RULE1_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      actionAttribute: automationConstant.STOCK_QUANTITY,
      actionCondition: 'lessThanEuqal',
      comparisionValue: '',
      processValue: '',
      additionalAction1: automationConstant.NOTIFICATION_ONLY,
      additionalAction2: '',
      isRuleExecuted: false,
      emailIds: [],
      description: ''
    },
    attributeList: [
      {
        name: "actionAttribute",
        type: "DROPDOWN",
        label: "Automation Action - Criteria",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          { label: "Stock Qty", value: automationConstant.STOCK_QUANTITY },
        ]
      },
      {
        name: "actionCondition",
        type: "DROPDOWN",
        label: "Condition",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: automationConstant.AUTOMATION_CONDITION_LIST
      },
      {
        name: "comparisionValue",
        type: "TEXTBOX",
        label: "Stock Quantity",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        minLength: 1,
        mandatoryMsgText: "Field can not be empty.",
      },
      // {
      //   name: "processValue",
      //   type: "TEXTBOX",
      //   label: "Order Quantity",
      //   required: true,
      //   fieldWidth: 3,
      //   fieldWidthSmall: 4,
      //   inputType: "number",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   createMode: "enable",
      //   cloneMode: "enable",
      //   editMode: "enable",
      //   viewMode: "disabled",
      //   placeholder: "",
      //   numberOfRow: 0,
      //   maxLength: 10,
      //   minLength: 1,
      //   mandatoryMsgText: "Field can not be empty.",
      // },
      {
        name: "processValue",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "additionalAction1",
        type: "DROPDOWN",
        label: "Automatic Action - Output",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          // { label: "Create Draft Order with Notification", value: automationConstant.DRAFT_ORDER_WITH_NOTIFICATION },
          { label: "Send Notification only", value: automationConstant.NOTIFICATION_ONLY },
        ],
      },
      {
        name: "emailIds",
        list: "emailList",
        type: "TEXT_LIST",
        label: "Email List",
        required: false,
        fieldWidth: 12,
        createMode: 'enable',
        editMode: 'enable',
        viewMode: 'disabled',
        placeholder: "Add email addresses.",
        placeholderLarge: "Add email addresses.",
        placeholderTax: "Add email addresses.",
        createModeRemoveFlag: true,
        cloneModeRemoveFlag: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        mandatoryMsgText: "Field can not be empty.",
      },
      // {
      //   name: "email",
      //   type: "TEXTBOX",
      //   label: "Email",
      //   required: false,
      //   fieldWidth: 4,
      //   numberOfRow: 0,
      //   inputType: "email",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   createMode: 'enable',
      //   cloneMode: 'enable',
      //   editMode: 'enable',
      //   viewMode: 'disabled',
      //   //mandatoryMsgText: "Email is required.",
      //   emailMsgText: "Invalid email format.",
      //   customEmailMessage: "Customer Email already exist."
      // },
      {
        name: "description",
        type: "TEXTBOX",
        label: "Description",
        required: false,
        fieldWidth: 4,
        createMode: 'enable',
        cloneMode: 'enable',
        editMode: 'enable',
        viewMode: 'disabled',
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        numberOfRow: 2,
        maxLength: 200,
        minLength: 1,
    },
    ]
  };
};

export const CREATE_AUTOMATION_RULE2_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      actionAttribute: automationConstant.ORDER_QUANTITY,
      actionCondition: 'greaterThanEqual',
      comparisionValue: '',
      processValue: '',
      saleChannel: '',
      additionalAction1: automationConstant.NOTIFICATION_ONLY,
      additionalAction2: '',
      isRuleExecuted: false
    },
    attributeList: [
      {
        name: "actionAttribute",
        type: "DROPDOWN",
        label: "Automation Action - Criteria",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          { label: "Order Qty", value: automationConstant.ORDER_QUANTITY },
        ]
      },
      {
        name: "actionCondition",
        type: "DROPDOWN",
        label: "Condition",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: automationConstant.AUTOMATION_CONDITION_LIST,
      },
      {
        name: "comparisionValue",
        type: "TEXTBOX",
        label: "Order Quantity",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        lengthValidationMessage: "Max length of 10 chars exceeded",
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "additionalAction1",
        type: "DROPDOWN",
        label: "Automatic Action - Output",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          { label: "Send Notification only", value: automationConstant.NOTIFICATION_ONLY },
        ],
      },
    ]
  };
};

export const CREATE_AUTOMATION_RULE3_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      actionAttribute: automationConstant.STOCK_QUANTITY,
      actionCondition: '',
      comparisionValue: '',
      processValue: '',
      additionalAction1: '',
      additionalAction2: '',
      transferLocation: '',
      isRuleExecuted: false
    },
    attributeList: [
      {
        name: "transferType",
        type: "DROPDOWN",
        label: "Transfer Type",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        customAttribute: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          { label: "Inward", value: "inward" },
          { label: "Outward", value: "outward" },
        ]
      },
      {
        name: "actionAttribute",
        type: "DROPDOWN",
        label: "Automation-Criteria",
        required: true,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          { label: "Stock Qty", value: automationConstant.STOCK_QUANTITY },
        ]
      },
      {
        name: "actionCondition",
        type: "DROPDOWN",
        label: "Condition",
        required: true,
        fieldWidth: 2,
        fieldWidthSmall: 4,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: automationConstant.AUTOMATION_CONDITION_LIST,
      },
      {
        name: "comparisionValue",
        type: "TEXTBOX",
        label: "Stock Quantity",
        required: true,
        fieldWidth: 2,
        fieldWidthSmall: 3,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        lengthValidationMessage: "Max length of 10 chars exceeded",
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "processValue",
        type: "TEXTBOX",
        label: "Transfer Quantity",
        required: true,
        fieldWidth: 2,
        fieldWidthSmall: 3,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        lengthValidationMessage: "Max length of 10 chars exceeded",
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "fromLocation",
        type: "DROPDOWN",
        label: "From Location",
        required: true,
        fieldWidth: 3,
        isMulti: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        lengthValidationMessage: "Max length of 32 chars exceeded",
        options: [],
      },
      {
        name: "toLocation",
        type: "DROPDOWN",
        label: "To Location",
        required: true,
        fieldWidth: 3,
        isMulti: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        lengthValidationMessage: "Max length of 32 chars exceeded",
        options: [],
      },
      {
        name: "additionalAction1",
        type: "DROPDOWN",
        label: "Automatic Action - Output",
        required: true,
        fieldWidth: 3,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "Select",
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options: [
          // { label: "Create Draft Order with Notification", value: automationConstant.DRAFT_ORDER_WITH_NOTIFICATION },
          { label: "Send Notification only", value: automationConstant.NOTIFICATION_ONLY },
        ],
      },
    ]
  };
};

export const MANAGE_AUTOMATION_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Name",
        id: "name",
        accessor: "name",
        name: "name",
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 200px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          const { value } = cell;
          return (
            <div name={'name'} id={original.name + "_" + index}>
              <span >{value} </span>
            </div>
          )
        }
      },
      {
        Header: "Automation Rule",
        id: "ruleCode",
        accessor: "ruleCode",
        name: "ruleCode",
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_RULE_LIST,
            'value', original.ruleCode)
          return (
            <div name={'ruleCode'} id={original.uniqueId + "_" + index}>
              <span >{tempRuleObj && tempRuleObj.label} </span>
            </div>
          )
        }
      },
      {
        Header: "Criteria",
        id: "actionAttribute",
        accessor: "actionAttribute",
        name: "actionAttribute",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: "0 0 80px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_ATTRIBUTE_LIST,
            'value', original.actionAttribute)
          return (
            <div name={'actionAttribute'} id={"actionAttribute" + "_" + index}>
              <span >{tempRuleObj && tempRuleObj.label} </span>
            </div>
          )
        }
      },
      {
        Header: "Condition",
        id: "actionCondition",
        accessor: "actionCondition",
        name: "actionCondition",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: "0 0 70px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_CONDITION_LIST,
            'value', original.actionCondition)
          return (
            <div name={'actionCondition'} id={"actionCondition" + "_" + index}>
              <span><b>{tempRuleObj && tempRuleObj.label} </b></span>
            </div>
          )
        }
      },
      {
        Header: "Quantity",
        id: "comparisionValue",
        accessor: "comparisionValue",
        name: "comparisionValue",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        style: {
          flex: "0 0 70px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl id={'comparisionValue' + '_' + index} name={'comparisionValue'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isAuthorized("automationCreate") ? false : true}
                min={0}
                value={CommonUtil.getFloatValue(value)} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Emails",
        id: "emailIds",
        accessor: "emailIds",
        name: "emailIds",
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          const { value } = cell;
          return (
            <div name={'emailIds'} id={original.id + "_" + index}>
              <span >{value} </span>
            </div>
          )
        }
      },
      {
        Header: "Product Count",
        id: "productCount",
        accessor: "productCount",
        style: {
          flex: '0 0 130px',
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => { 
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className={'link'}
              id={original.automationRuleId + '_' + index + "_" + original.name}
              name={'productCount'}
              onClick={(e) => that.handleTableLinkButtonClick(e)}>
              {CommonUtil.getFloatValue(original.productList && original.productList.length ? original.productList.length : 0) + "  " + "Products"}
            </div>
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        isQBOAttribute: false,
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                {isAuthorized("automationCreate") &&
                  <div className="circle">
                    <i title="edit" id={original.automationRuleId + "_" +
                      commonConstant.EDIT_ACTION_MODE + "_" + index}
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("automation") &&
                  <div className="circle">
                    <i title="view" id={original.automationRuleId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                      className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_AUTOMATION_RULE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Automation Rule",
        id: "ruleCode",
        accessor: "ruleCode",
        name: "ruleCode",
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 200px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_RULE_LIST,
            'value', original.ruleCode)
          return (
            <div name={'ruleCode'} id={original.uniqueId + "_" + index}>
              <span >{tempRuleObj && tempRuleObj.label} </span>
            </div>
          )
        }
      },
      {
        Header: "Criteria",
        id: "actionAttribute",
        accessor: "actionAttribute",
        name: "actionAttribute",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: "0 0 80px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_ATTRIBUTE_LIST,
            'value', original.actionAttribute)
          return (
            <div name={'actionAttribute'} id={"actionAttribute" + "_" + index}>
              <span >{tempRuleObj && tempRuleObj.label} </span>
            </div>
          )
        }
      },
      {
        Header: "Condition",
        id: "actionCondition",
        accessor: "actionCondition",
        name: "actionCondition",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: "0 0 70px",
        },
        Cell: ({ cell }) => {
          const { index, original } = cell.row;
          let tempRuleObj = CommonUtil.getFilteredObjFromArray(automationConstant.AUTOMATION_CONDITION_LIST,
            'value', original.actionCondition)
          return (
            <div name={'actionCondition'} id={"actionCondition" + "_" + index}>
              <span><b>{tempRuleObj && tempRuleObj.label} </b></span>
            </div>
          )
        }
      },
      {
        Header: "Quantity",
        id: "comparisionValue",
        accessor: "comparisionValue",
        name: "comparisionValue",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl id={'comparisionValue' + '_' + index} name={'comparisionValue'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isAuthorized("automationCreate") ? false : true}
                min={0}
                value={CommonUtil.getFloatValue(value)} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Order/Transfer Qty",
        id: "processValue",
        accessor: "processValue",
        name: "processValue",
        required: false,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && (original.ruleCode != "AUTORULE2" ? !value : null) ? 'required-error' : ''}>
              <FormControl id={'processValue' + '_' + index} name={'processValue'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                onChange={that.handleTableTextBoxChange}
                disabled={isAuthorized("automationCreate") ? false : true}
                min={0}
                value={CommonUtil.getFloatValue(original.processValue)} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        name: "status",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: "0 0 90px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let tempValue = original.status;
          if (original.status == statusConstant.ACTIVE_STATUS) {
            tempValue = true;
          } else if (original.status == statusConstant.INACTIVE_STATUS) {
            tempValue = false;
          }
          return (
            <Switch
              id={'status' + '_' + index}
              inverse={false}
              value={tempValue}
              offColor={'primary'}
              onColor={'success'}
              disabled={isAuthorized("automationCreate") ? false : true}
              onText="active" offText="inactive" defaultValue={false}
              onChange={(el, state) => that.handleTableSwitchChange(el, state)}
            />
          )
        }
      },
      {
        Header: "Action",
        id: "actions",
        accessor: "actions",
        name: "actions",
        className: "action justify-content-center",
        style: {
          flex: "0 0 100px",
        },
        disableSortBy: true,
        disableFilters: true,
        required: false,
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon>
                {isAuthorized("automationCreate") &&
                  <div className="circle">
                    <i title="edit" id={original.uniqueId + "_" +
                      commonConstant.EDIT_ACTION_MODE + "_" + index + "_" + original.ruleCode}
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("automationCreate") &&
                  <div className="circle">
                    <i title="copy" id={original.uniqueId + "_" +
                      commonConstant.CLONE_ACTION_MODE + "_" + index + "_" + original.ruleCode}
                      className="fa fa-copy"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                <div className="circle">
                  <i title="view" id={original.uniqueId + "_" +
                    commonConstant.VIEW_ACTION_MODE + "_" + index + "_" + original.ruleCode}
                    className="fa fa-eye"
                    onClick={(e) => that.getTdProps(e)}
                  />
                </div>
                {isAuthorized("automationCreate") &&
                  <div className="circle">
                    <i title="view" id={original.uniqueId + "_" + index + "_" + original.ruleCode}
                      className="fa fa-trash"
                      onClick={(e) => that.handleTableRemove(e)}
                    />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};


export const MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  return {
      tableColumnList: [
          {
              Header: "",
              id: "actions",
              accessor: "actions",
              className: "action justify-content-center",
              style: {
                  flex: "0 0 60px",
              },
              disableSortBy: true,
              disableFilters: true,
              Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <div className="actions-left">
                          <CustomCheckbox inline
                              number={original.productId + "_" + commonConstant.CREATE_ACTION_MODE + '_' + index}
                              checked={original.isChecked}
                              onClick={(e) => that.handleCheckBoxChange(e, that)} />
                      </div>
                  )
              }
          },
          {
              Header: "Product Code",
              id: "productId",
              accessor: "productId",
              style: {
                  flex: "0 0 140px",
              },
              Cell: ({ cell }) => {
                  var value = cell.value;
                  const { index, original } = cell.row;
                  return (
                    <>{original.isIngredient ? "ING-" : "PRO-"}{value}</>
                  )
              }
          },
          {
            Header: "Product Name",
            id: "productName",
            accessor: "productName",
            Cell: ({ cell }) => {
              var value = cell.value;
              const { index, original } = cell.row;
              return (
                  <div
                      id={original.productId + "_1" + index + "_" + original.stocktype}
                      title={original.productId ? (original.productName) : ''}>
                      {
                          <span >{original.productId ? (original.productName) : ''} </span>
                      }
                  </div>
              )
          }
        }
      ],
      tableConfig: {
          defaultFilteredList: [],
          defaultSortedList: [],
          defaultPageSize: 50,
          showExport: false,
          customPagination: true,
          showServerSideFilter: false,
          isFilterEnabed: false,
          showPagination: true,
          isDraggable: false,
      }
  }
};

export const MANAGE_PAGE_AUTOMATION_PRODUCTS_LIST = (that) => {
  return {
      tableColumnList: [
          {
              Header: "Product Code",
              id: "productId",
              accessor: "productId",
              style: {
                  flex: "0 0 140px",
              },
              Cell: ({ cell }) => {
                  var value = cell.value;
                  const { index, original } = cell.row;
                  return (
                    <>{original.isIngredient ? "ING-" : "PRO-"}{value}</>
                  )
              }
          },
          {
              Header: "Product Name",
              id: "productName",
              accessor: "productName"
          },
      ],
      tableConfig: {
          defaultFilteredList: [],
          defaultSortedList: [],
          defaultPageSize: 50,
          showExport: false,
          customPagination: false,
          showServerSideFilter: false,
          isFilterEnabed: false,
          showPagination: true,
          isDraggable: false,
      },
      tableConfigSelected: {
        defaultFilteredList: [],
        defaultSortedList: [],
        defaultPageSize: 50,
        showExport: false,
        customPagination: false,
        showServerSideFilter: false,
        isFilterEnabed: false,
        showPagination: true,
        isDraggable: false,
      }
  }
};

export const MANAGE_MULTI_SELECTION_CATEGORY_PAGE_LIST = (that) => {
  return {
      tableColumnList: [
          {
              Header: "",
              id: "actions",
              accessor: "actions",
              className: "action justify-content-center",
              style: {
                  flex: "0 0 60px",
              },
              disableSortBy: true,
              disableFilters: true,
              Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                      <div className="actions-left">
                          <CustomCheckbox inline
                              number={original.categoryId + "_" + commonConstant.CREATE_ACTION_MODE + '_' + index}
                              checked={original.isChecked}
                              onClick={(e) => that.handleCheckBoxChange(e, that)} />
                      </div>
                  )
              }
          },
          {
              Header: "Category Name",
              id: "categoryName",
              accessor: "categoryName"
          },
      ],
      tableConfig: {
          defaultFilteredList: [],
          defaultSortedList: [],
          defaultPageSize: 50,
          showExport: false,
          customPagination: false,
          showServerSideFilter: false,
          isFilterEnabed: false,
          showPagination: true,
          isDraggable: false,
      }
  }
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: '',
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Product Code/Name",
      },
    ],
  }
};