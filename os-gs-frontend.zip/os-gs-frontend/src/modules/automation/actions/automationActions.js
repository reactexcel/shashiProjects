import axios from "../../../axios/axios";
import * as automationActionTypes from "./automationActionTypes";
import * as automationConstant from "../constant/automationConstant";
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';


export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: automationActionTypes.SET_AUTOMATION_REDUCER_INIT_MODE,
      payload: null,
    });
  };
}

export function setAutomationDetails(automationDetailsObj, actionMode, automationRuleId) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(automationConstant.SET_CREATE_AUTOMATION_DETAILS_URL,
        automationDetailsObj).then((response) => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch((error) => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(automationConstant.SET_UPDATE_AUTOMATION_DETAILS_URL +
        // automationDetailsObj.uniqueId + "/" + automationDetailsObj.ruleCode + "/" +
        // automationDetailsObj.facilityId, automationDetailsObj).then((response) => {
          automationRuleId, automationDetailsObj).then((response) => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch((error) => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedAutomationCode(selectedAutomationCode) {
  return function (dispatch) {
    dispatch({
      type: automationActionTypes.SET_SELECTED_AUTOMATION_CODE,
      payload: selectedAutomationCode,
    });
  };
}

export function getAutomationList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(automationConstant.GET_AUTOMATION_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: automationActionTypes.GET_AUTOMATION_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getAutomationFacilityList() {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(automationConstant.GET_AUTOMATION_FACILITY_LIST_URL).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: automationActionTypes.GET_AUTOMATION_FACILITY_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getAutomatRulesByProduct(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(automationConstant.GET_AUTOMATION_PRODUCT_RULES_URL +
      params.uniqueId + "/" + params.facilityId).then((response) => {
        if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
          dispatch({
            type: automationActionTypes.GET_AUTOMATION_PRODUCT_RULES,
            payload: response.data,
          });
        }
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
      });
  };
}

export function getAutomationDetails(selectedAutomationCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    // axios.get(automationConstant.GET_AUTOMATION_DETAILS_URL + selectedAutomationCode.uniqueId
    //   + "/" + selectedAutomationCode.ruleCode + "/" + selectedAutomationCode.facilityId).then((response) => {
    axios.get(automationConstant.GET_AUTOMATION_DETAILS_URL + selectedAutomationCode).then((response) => {
        if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
          dispatch({
            type: automationActionTypes.GET_AUTOMATION_DETAILS,
            payload: response.data[0],
          });
        }
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
      });
  };
}

export function updateProductAutomationRules(automationDetailsObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.put(automationConstant.SET_AUTOMATION_PRODUCT_RULES_URL +
      automationDetailsObj.uniqueId + "/" + automationDetailsObj.facilityId
      , automationDetailsObj).then((response) => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}

export function updateAutomationDraftStatus(draftOrderDetails) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(automationConstant.SET_UPDATE_DRAFT_ORDER_STATUS_URL + draftOrderDetails.uniqueId
      + "/" + draftOrderDetails.draftCode,
      draftOrderDetails).then((response) => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch((error) => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}

export function updateAutomationRuleDeleteStatus(automationDetailsObj, automationRuleId) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(automationConstant.SET_UPDATE_AUTOMATIONRULE_STATUS_URL +
      automationRuleId, automationDetailsObj).then((response) => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      })
      .catch((error) => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}

export function getAutomationDraftOrderList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(automationConstant.GET_AUTOMATION_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: automationActionTypes.GET_AUTOMATION_DRAFT_ORDER_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}