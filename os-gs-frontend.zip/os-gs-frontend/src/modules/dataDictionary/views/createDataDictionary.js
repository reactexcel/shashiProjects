import React, { Component } from "react";
import { Row, Col, FormGroup } from "react-bootstrap";
import { ControlLabel } from "react-bootstrap";
import Select from "react-select";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { setDataDictionaryDetails, getDataDictionaryDetails, setReducerInitMode } from "../actions/dataDictionaryActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as dataDictionaryConstant from '../constant/dataDictionaryConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import TagsInput from "react-tagsinput";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import CheckBoxUtil from '../../common/util/checkBoxUtil';
import * as commonConstant from '../../common/constant/commonConstant';
import mixpanel from "../../analytics/mixpanel/mixpael";
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import isAuthorized from "auth-plugin"
import { resetUserDetails } from "../../../actions/appActions";
import { doLogout } from "../../../actions/authActions";
import _ from 'lodash';

class CreateDataDictionary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedIdValues: [],
      attributeList: null,
      attributeObj: [],
      submitted: false,
      alert: null,
      selectedDictionaryId: 'categoryList',
      selectedDictionaryLabel: 'Category',
      currencyCode: "USD",
      selectedTimeZone: null,
      timeZones: null,
    };

    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handleDropDownChange = this.handleDropDownChange.bind(this);
    this.handleFilledTags = this.handleFilledTags.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
  }

  handleRadioButtonsChange = async (event) => {
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    await this.setState({
      attributeObj: attributeObj,
    })
  }

  handleFilledTags(filledTags) {
    let { attributeObj } = this.state;
    this.setState({ selectedIdValues: filledTags });
    if (this.state.selectedDictionaryId != '') {
      let tempList = attributeObj && attributeObj.filter(item => {
        if(item.dataType !== this.state.selectedDictionaryId) {
          return item;
        }
        // if(!filledTags.includes(item.label) && item.dataType !== this.state.selectedDictionaryId) {
        //   return item;
        // }
      })
      for (var i = 0; i < filledTags.length; i++) {
        var tempObj = {}
        let tempValue = attributeObj && attributeObj.filter(item => {
          if(item.label == filledTags[i] && item.dataType == this.state.selectedDictionaryId) {
            return item
          }
        })
        tempObj.value = tempValue && tempValue.length > 0 ? tempValue[0].value : 0;
        tempObj.label = filledTags[i];
        tempObj.dataType = this.state.selectedDictionaryId;
        tempList.push(tempObj)
      }
      this.setState({
        attributeObj: tempList,
      })
    }
  }

  onSelectedCurrency = async (event) => {
    const { value } = event;
    let { attributeObj } = this.state;
    let temp = attributeObj.filter(item => item.dataType == "currencyCode")
    if(temp.length == 1) {
      attributeObj.map(item => {
        if (item.dataType == "currencyCode") {
          item.label = value;
        }
        return item;
      })
    } else {
      var tempObj = {};
      tempObj.value = 0;
      tempObj.label = value;
      tempObj.dataType = "currencyCode";
      attributeObj.push(tempObj)
    }
    await this.setState({
      attributeObj: attributeObj,
      currencyCode: value
    })
  }

  onSelectedTimeZone = async (event) => {
    const { value } = event;
    let { attributeObj } = this.state;
    let temp = attributeObj.filter((item) => item.dataType === "timeZone");
    if (temp.length == 1) {
      attributeObj.map((item) => {
        if (item.dataType === "timeZone") {
          item.label = value;
        }
        return item;
      });
    } else {
      var tempObj = {};
      tempObj.value = 0;
      tempObj.label = value;
      tempObj.dataType = "timeZone";
      attributeObj.push(tempObj);
    }

    await this.setState({
      attributeObj: attributeObj,
      selectedTimeZone: value,
    });
  };

  componentDidMount = () => {
    mixpanel.track("Create Data dictionary loaded");
    this.props.getDataDictionaryDetails(this.props.selectedDataDictionaryCode);
    this.setState({
      attributeList: pagePropertyListConstant.CREATE_DATA_DICTIONARY_PAGE_LIST.attributeList,
      attributeObj: pagePropertyListConstant.CREATE_DATA_DICTIONARY_PAGE_LIST.attributeObj,
    });   
    this.setTimeZonesAndSelectedTimeZone();
  };

  setTimeZonesAndSelectedTimeZone = () => {
    const timeZonesList = this.getTimeZonesList();

    this.setState({
        timeZones: timeZonesList.options
    });

    const recentTimeZone = this.getRecentTimeZone();
    if (recentTimeZone) {
      this.setState({
          selectedTimeZone: recentTimeZone.label
      });
    }
  };

  getTimeZonesList = () => {
    return pagePropertyListConstant.CREATE_DATA_DICTIONARY_PAGE_LIST.attributeList
      .find(attribute => attribute.type === "ZONES") || { options: [] };
  };

  getRecentTimeZone = () => {
    const timeZoneObjs = this.props.attributeObj.filter(item => item.dataType === "timeZone");
    if (timeZoneObjs.length > 0) {
      return timeZoneObjs.reduce((prev, current) => {
        return (prev.value > current.value) ? prev : current;
      });
    }
    return null;
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  updateApiData = async (attributeObj) => {
    if(attributeObj.filter(item => item.dataType == "currencyCode").length == 0) {
      var tempObj = {};
      tempObj.value = 0;
      tempObj.label = "USD";
      tempObj.dataType = "currencyCode";
      attributeObj.push(tempObj)
    }
    await this.setState({
      attributeObj: attributeObj,
      currencyCode: attributeObj && attributeObj.length > 0 ? attributeObj.filter(item => item.dataType == "currencyCode")[0] ? attributeObj.filter(item => item.dataType == "currencyCode")[0].label : "USD" : "USD"
      // isAllowed: attributeObj && attributeObj.isStocktransferAllowed ? 'yes' : 'no',
    })
    this.handleDropDownChange({ value: this.state.selectedDictionaryId, label: this.state.selectedDictionaryLabel });
    // this.updateSystemTrackDetails();
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleSave(event) {
    this.setState({ submitted: true, alert: null });
    let tempObj = this.state.attributeObj;
    // tempObj.dataDictionary = true;
    // tempObj.orgInformation = tempObj.orgInformation ? tempObj.orgInformation : [];
    // tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
    //   this.state.attributeList, commonConstant.EDIT_ACTION_MODE);
    // if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
    //   this.props.setDataDictionaryDetails(tempObj, commonConstant.EDIT_ACTION_MODE);
    // }
    this.props.setDataDictionaryDetails(tempObj, commonConstant.EDIT_ACTION_MODE);
  }

  updateSystemTrackDetails = () => {
    const { userProfile, attributeObj } = this.props;
    if (attributeObj.track == 'lot' && userProfile && userProfile.isDummyDataDeleted == false) {
      this.props.resetUserDetails(true);
      this.props.doLogout();
    }
  }

  handleSubmit = () => {
    // const { attributeObj } = this.state;
    // const { userProfile } = this.props;
    // if (attributeObj.track == 'lot' && userProfile && userProfile.isDummyDataDeleted == false) {
    //   PopupUtil.popupLotTracking(this);
    // } else {
    // }
    this.handleSave();
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  async handleDropDownChange(event) {
    var selectedIdValues = [];
    const { attributeObj } = this.state;
    var tempObj = _.cloneDeep(attributeObj)
    if (attributeObj) {
      let temp = tempObj.filter(item => item.dataType == event.value).sort((a,b) => (a.label > b.label) ? 1 : ((b.label > a.label) ? -1 : 0))
      selectedIdValues = temp && temp.length > 0 ? temp.map(item => {
        return item.label;
      }) : []
    }
    await this.setState({
      attributeObj: attributeObj,
      selectedDictionaryId: event.value,
      selectedDictionaryLabel: event.label,
      selectedIdValues: selectedIdValues
    })
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      setTimeout({}, 0);
    }
    let responseData = this.props.ajaxCallStatus.data && this.props.ajaxCallStatus.data.response;
    if (this.props.ajaxCallStatus.status == "FAILED" && responseData && responseData.status != 409 &&
      responseData.status != 405) {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(dataDictionaryConstant.MANAGE_DASHBOARD_URL, this);
  }

  handleCustomBlurChange = async (event) => {
    CommonUtil.handleTextBoxBlur(event, this);
    CommonUtil.handleNumberChange(event, this)
    const { attributeObj } = this.state;
    const { name } = event.target;
    let stateGST = "";
    let centralGST = "";
    if (name == "centralGST") {
      const centralGST = event.target.value;
      if (CommonUtil.isNotNull(centralGST) && centralGST <= 100) {
        stateGST = CommonUtil.getFloatValue(100 - centralGST, true);
      }
    }
    if (name == "stateGST") {
      const stateGST = event.target.value;
      if (CommonUtil.isNotNull(stateGST) && stateGST <= 100) {
        centralGST = CommonUtil.getFloatValue(100 - stateGST, true);
      }
    }

    await this.setState({
      attributeObj: attributeObj
    });
  }

  render() {
    const { attributeObj, submitted } = this.state;
    let { attributeList } = this.state;
    const { userProfile } = this.props;
    if(userProfile != null) {
      let tempList = attributeList && attributeList.map(item => {
        if(item.name == "dictionaryType") {
          if(((userProfile && userProfile.metadata) ? (userProfile.metadata.isSubCategoryVisible ? false : true) : false)) {
            item.options = item.options && item.options.filter(x => {
              return x.value !== "subcategoryList"
            })
          }
        }
        return item;
      })
      attributeList = tempList
    }
    return (
      <Row>
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Col md={12}>
          <Card
            content={
              <Row>
                <Col md={4} sm={4}>
                  <Row>
                    {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                      tempAttributeListObj.type == "TEXTBOX" ?
                        TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, null)

                        : tempAttributeListObj.type == "DROPDOWN" ?

                          <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                            <FormGroup>
                              <ControlLabel>
                                {tempAttributeListObj.label}
                                {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                              </ControlLabel>

                              <Select name={tempAttributeListObj.name} onChange={this.handleDropDownChange}
                                placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
                                classNamePrefix="react-select"
                                menuIsOpen={true} className="catagory-dropdown"
                                defaultValue={tempAttributeListObj.options[0]} blurInputOnSelect={true} isFocused={true}
                              />
                            </FormGroup>
                          </Col>
                          : null))
                    }
                  </Row>
                </Col>
                <Col md={8} sm={8}>
                  <Row>
                    {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                      tempAttributeListObj.type == "TEXT_LIST" ?
                        <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                          <FormGroup >
                            <ControlLabel>
                              {tempAttributeListObj.label}
                              {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                            </ControlLabel>
                            <TagsInput
                              value={this.state.selectedIdValues}
                              onChange={this.handleFilledTags}
                              tagProps={{
                                className: "react-tagsinput-tag tag-fill tag-grey",
                              }}
                              validationRegex={this.state.selectedDictionaryId == 'taxList' ? /^(\d{0,2}(\.\d{1,2})?|100(\.00?)?)$/ : (this.state.selectedDictionaryId == 'accountList' || this.state.selectedDictionaryId == 'expenses') ? /^.{1,60}$/ : /^.{1,32}$/}
                              inputProps={{
                                placeholder: this.state.selectedDictionaryId == 'taxList' ? tempAttributeListObj.placeholderTax : (this.state.selectedDictionaryId == 'accountList' || this.state.selectedDictionaryId == 'expenses') ? tempAttributeListObj.placeholderLarge : tempAttributeListObj.placeholder,
                              }}
                              addOnBlur={true}
                            />
                          </FormGroup>
                        </Col>
                        : null))
                    }
                  </Row>
                  <Row>
                    {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                      tempAttributeListObj.type == "DROPDOWN_CURRENCY" ?
                          <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                          <FormGroup>
                            <ControlLabel>
                              {tempAttributeListObj.label}
                              {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                            </ControlLabel>

                            <Select name={tempAttributeListObj.name} onChange={this.onSelectedCurrency}
                              placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
                              classNamePrefix="react-select"
                              isMulti={tempAttributeListObj.isMulti}
                              closeMenuOnSelect={tempAttributeListObj.closeMenuOnSelect}
                              value={{ "label": this.state.currencyCode ? this.state.currencyCode : '' }}
                            />
                          </FormGroup>
                        </Col>
                        : tempAttributeListObj.type == "TEXTBOX_TAX" ?
                          TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, null) 
                          : tempAttributeListObj.type == "CHECKBOX" ?
                          CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, null) 
                            : tempAttributeListObj.type == "CUSTOM_RADIO" ?

                              isAuthorized("adminSettings") && userProfile && userProfile.isDummyDataDeleted == false ?
                                <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index} className="product-checkbox">
                                  <FormGroup style={{ width: '100%' }}>
                                    <div>
                                      <ControlLabel style={{ textTransform: 'none', fontWeight: '500' }}>
                                        {tempAttributeListObj.label}
                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                      </ControlLabel>
                                    </div>
                                    <div className="source-btn">
                                      {tempAttributeListObj.checkList.map((check, Nestedindex) => {
                                        return (
                                          <Col md={4} key={Nestedindex}>
                                            <CustomRadio key={Nestedindex} name={check.name} number={check.name} label={check.label}
                                              onChange={this.handleRadioButtonsChange} value={check.value}
                                              checked={attributeObj.track === check.value} />
                                          </Col>
                                        )
                                      })}
                                    </div>
                                  </FormGroup>
                                </Col>
                                : null
                              : null))
                    }
                    <Col>
                      <Row>
                      {attributeList != null ? (
                        <Col
                          sm={
                            attributeList[2].fieldWidthSmall
                              ? attributeList[2].fieldWidthSmall
                              : attributeList[2].fieldWidth
                          }
                          md={attributeList[2].fieldWidth}
                        >
                          <FormGroup>
                            <ControlLabel>{"TimeZone"}</ControlLabel>

                            <Select
                              name={"timezone"}
                              onChange={this.onSelectedTimeZone}
                              placeholder={"select timezone"}
                              options={this.state.timeZones}
                              classNamePrefix="react-select"
                              value={{
                                label: this.state.selectedTimeZone
                              }}
                            />
                          </FormGroup>
                        </Col>
                      ) : null}
                      </Row>
                    </Col>
                  </Row>
                </Col>
              </Row>
            }
            ftTextRight
            legend={
              <div>
                {isAuthorized("updateData") && <Button className="btn-save btn-fill" onClick={this.handleSubmit}>
                  Save
                </Button>}
              </div>
            }
          />
        </Col>
      </Row>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.dataDictionary.dataDictionaryList,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setDataDictionaryDetails: (dataDictionaryDetailsObj, actionMode) => dispatch(setDataDictionaryDetails(dataDictionaryDetailsObj, actionMode)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  resetUserDetails: additionalData => dispatch(resetUserDetails(additionalData)),
  doLogout: () => dispatch(doLogout()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateDataDictionary);
