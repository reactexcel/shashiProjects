import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, ControlLabel, FormControl, OverlayTrigger, Tooltip } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant.js';
import { connect } from "react-redux";
import CommonUtil from '../../common/util/commonUtil.js';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions.js';
import { setUploadImportFileStatus } from '../../../actions/ajaxStatusActions.js';
import * as dataDictionaryConstant from '../constant/dataDictionaryConstant.js';
import { setTierPricingDetails, getTierPricingDetails } from '../actions/dataDictionaryActions.js';
import * as commonConstant from '../../common/constant/commonConstant.js';
import { setActionMode } from "../../../actions/appActions.js";
import { getUserProfile } from "../../userManagement/actions/userActions.js";
import PopupUtil from '../../common/util/popupUtil.js';
import mixpanel from "../../analytics/mixpanel/mixpael.js";
import { touch } from "redux-form";
import _ from 'lodash';
import ValidationUtil from '../../common/util/validationUtil';
import isAuthorized from "auth-plugin"

class tierPricing extends Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      redirectUrl: null,
      attributeList: null,
      attributeObj: null,
      alert: null,
      tierPricingList: [{}],
      facilityList: [],
      facility: '',
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage Tier Pricing loaded");
    this.props.getTierPricingDetails();
    let commonAttributeList = pagePropertyListConstant.CREATE_TIERPRICING_PAGE_LIST;
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
      tierPricingList: [{}],
    })
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.attributeObj != null && _.size(this.props.attributeObj) && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
  }

  async updateApiData(attributeObj) {
    await this.setState({
      // attributeObj: {
      //   ...attributeObj,
      // },
      tierPricingList: attributeObj ? [...attributeObj] : [{}]
    });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      setTimeout({}, 0);
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleTableTextBoxChange(event) {
    const { name, value } = event.target;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.tierPricingList];
    attributeDataList[id][name] = value;
    this.setState({ tierPricingList: [...attributeDataList] });
  }

  handleNumberChange(event) {
    const { name, value } = event.target;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.tierPricingList];
    const re = /^\d+(\.\d{0,2})?$/;
    if (value === '' || re.test(value)) {
      attributeDataList[id][name] = value;
      this.setState({ tierPricingList: [...attributeDataList] });
    } else {
      attributeDataList[id][name] = value.substring(0, value.length - 1);
      this.setState({ tierPricingList: [...attributeDataList] });
    }
  }

  maxLengthCheck(object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  maxValueCheck(object, maxValue) {
    let customErrorFlag = false;
    if (object.target.value > maxValue) {
      object.target.value = object.target.value.slice(0, 3)
      customErrorFlag = true
    }
    return customErrorFlag;
  }

  handleRemove = (event) => {
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.tierPricingList];
    let tempAttributeDataList = [];
    for (let i = 0; i < attributeDataList.length; i++) {
      if (id !== i) {
        tempAttributeDataList.push({ ...attributeDataList[i] });
      }
    }
    this.setState({ tierPricingList: [...tempAttributeDataList] });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(dataDictionaryConstant.MANAGE_DASHBOARD_URL, this);
  }

  handleAddTerms = (event) => {
    let { tierPricingList } = this.state;
    let tempPricingList = [...tierPricingList];
    let tempObj = {};
    tempPricingList.push(tempObj);
    this.setState({ tierPricingList: [...tempPricingList] });
  }

  hasDuplicateNames(arr) {
    const nameSet = new Set();
  
    for (const obj of arr) {
      if (nameSet.has(obj.tierName)) {
        return true;
      } else {
        nameSet.add(obj.tierName);
      }
    }
    return false;
  }

  async handleSave(event) {
    this.setState({ submitted: true });
    let { tierPricingList } = this.state;
    const isDuplicateName = this.hasDuplicateNames(tierPricingList);
    if(isDuplicateName) {
      PopupUtil.popupErrorResponse(this, "Tier name already exists");
      return
    }
    if (ValidationUtil.validateArrayListRequestObj(tierPricingList, this.state.attributeList)) {
      let tempPricingList = tierPricingList.map(item => {
        item.percentage = item.percentage.toString();
        return item;
      })
      await this.props.setTierPricingDetails(tempPricingList);
    }
  }

  render() {
    const { attributeList, attributeObj, submitted, tierPricingList, customErrorFlag } = this.state;
    const actionMode = commonConstant.CREATE_ACTION_MODE;
    return (
      <Grid fluid>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Row>
          <Col md={12}>
            <Card
              content={
                <div>
                  <div className="orgcontact-heading">
                    <Row>
                      <Col md={12}>
                        <p>Set the tier pricing for wholesale customers and allow them to save time and cost without having to negotiate individual pricing agreements. Typically, the more a customer purchases, the lower the price they pay per unit, incentivizing larger purchases.</p>
                      </Col>
                    </Row>
                  </div>
                  {tierPricingList != null && tierPricingList.map((tempAttributeDataListObj, index) => (
                    <Row className="terms-dictionary" key={index}>
                      {attributeList != null && attributeList.map((tempAttributeListObj, index1) => (
                        (tempAttributeListObj.type == "TEXTBOX" || tempAttributeListObj.type == "TEXTBOX_TAX") && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                          <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index1}>
                            <FormGroup>
                              <ControlLabel>
                                <span> {tempAttributeListObj.label}
                                  {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                              </ControlLabel>
                              <FormControl
                                id={tempAttributeListObj.name + '_' + index}
                                componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                                name={tempAttributeListObj.name}
                                onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                                onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
                                onChange={(e) => {
                                  this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                  if (tempAttributeListObj.type == "TEXTBOX_TAX") { this.maxValueCheck(e, 100) };
                                  tempAttributeListObj.inputType == "number" ?
                                    this.handleNumberChange(e) :
                                    this.handleTableTextBoxChange(e)
                                }}
                                disabled={false}
                                value={tempAttributeDataListObj[tempAttributeListObj.name]}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                maxLength={tempAttributeListObj.maxLength}
                                rows={tempAttributeListObj.numberOfRow}
                              />
                              {submitted && tempAttributeListObj.required && !CommonUtil.isNotNull(tempAttributeDataListObj[tempAttributeListObj.name]) &&
                                <small className="text-danger">
                                  {tempAttributeListObj.mandatoryMsgText}
                                </small>
                              }
                               {submitted && customErrorFlag && tempAttributeDataListObj[tempAttributeListObj.name] ?
                                  <small className="text-danger">
                                    {tempAttributeListObj.customMessage}
                                  </small>
                                  : null
                                }
                              {(touch || submitted) && tempAttributeListObj.maxLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                +tempAttributeDataListObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                                <small className="text-danger">
                                  Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                </small>
                              }
                              {(touch || submitted) && tempAttributeListObj.minLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                +tempAttributeDataListObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                                <small className="text-danger">
                                  Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                </small>
                              }
                              {(touch || submitted) && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.type == "TEXTBOX_TAX" && tempAttributeDataListObj[tempAttributeListObj.name] > 100 ?
                                <small className="text-danger">
                                  Allowed value limit is 0 to 100.
                                  </small>
                                : null
                              }
                            </FormGroup>
                          </Col>
                          : null))}
                      <Col md={3}>
                        {index == (tierPricingList && tierPricingList.length - 1) && <i className="fa fa-plus" onClick={this.handleAddTerms} style={{opacity: 1, pointerEvents: 'all'}}></i>}
                        {tierPricingList && tierPricingList.length > 1 && <i id={"REMOVE" + '_' + index} className="fa fa-close" onClick={this.handleRemove} style={{opacity: 1, pointerEvents: 'all'}}></i>}
                      </Col>
                    </Row>
                  ))}
                </div>
              }
              ftTextRight
              legend={
                <>
                  {isAuthorized("updateOrg") &&
                    <div>
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                  }
                </>
              }
            />
          </Col>
        </Row>
      </Grid>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.dataDictionary.tierPricing,
    userProfile: state.user.userProfile,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setUploadImportFileStatus: status => dispatch(setUploadImportFileStatus(status)),
  setTierPricingDetails: (pricingObj) => dispatch(setTierPricingDetails(pricingObj)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(tierPricing);
