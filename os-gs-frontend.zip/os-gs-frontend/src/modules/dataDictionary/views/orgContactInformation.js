import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, ControlLabel, FormControl, OverlayTrigger, Tooltip } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import CommonUtil from '../../common/util/commonUtil';
import LocationUtil from "../../common/util/locationUtil";
import ValidationUtil from '../../common/util/validationUtil';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { setUploadImportFileStatus } from '../../../actions/ajaxStatusActions';
import * as dataDictionaryConstant from '../constant/dataDictionaryConstant';
import { setOrganizationDetails, getOrganizationDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as commonConstant from '../../common/constant/commonConstant';
import { setActionMode } from "../../../actions/appActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import DragDropDialog from '../../../components/DragDrop/DragDropDialog';
import upload from "assets/img/upload-white.svg";
import uploadblue from "assets/img/upload-blue.svg";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import PopupUtil from '../../common/util/popupUtil';
import mixpanel from "../../analytics/mixpanel/mixpael";
import { touch } from "redux-form";
import Select from "react-select";
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import _ from 'lodash';
import isAuthorized from "auth-plugin"

class orgContactInformation extends Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      redirectUrl: null,
      attributeList: null,
      attributeObj: null,
      alert: null,
      termsDictionaryList: [{
        id: null,
        termsContainerHeader: "",
        termsContainerText: ""
      }],
      facilityList: [],
      facility: '',
      showContent: true,
    };
    this.handleSave = this.handleSave.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handleLocationChange = this.handleLocationChange.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage organization Information loaded");
    this.props.getFacilityList({ isDropdown: true });
    let commonAttributeList = pagePropertyListConstant.CREATE_ORGINFORMATION_PAGE_LIST;
    commonAttributeList.attributeList = LocationUtil.getCountryList(commonAttributeList.attributeList);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeListLocation: LocationUtil.getCountryList(commonAttributeList.attributeListLocation),
      locationAttributeObj: commonAttributeList.locationAttributeObj,
      attributeObj: commonAttributeList.attributeObj,
      termsDictionaryList: [{
        id: null,
        termsContainerHeader: "",
        termsContainerText: ""
      }],
      attributeListTermsContainer: commonAttributeList.attributeListTermsContainer,
    })
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
  }

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(
      this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))

    if (tempList && tempList.length) {
      await this.setState({
        facilityList: tempList,
        facility: this.state.facility ? this.state.facility : tempList[0].value,
        facilityName: this.state.facilityName ? this.state.facilityName : tempList[0].label
      })
      this.props.getOrganizationDetails(tempList[0].value);
    }
  }

  handleFacilityDropdownChange = async (tempObj) => {
    await this.setState({ facility: tempObj.value, facilityName: tempObj.label });
    await this.props.getOrganizationDetails(tempObj.value);
    await this.updateApiData(this.props.attributeObj);
  }

  handleUpload = async (event) => {
    let eventId = event.target.id;
    await this.setState({
      openBulkImportModal: true,
      openBulkImportErrorModal: false,
      eventId: eventId
    })
    this.props.setUploadImportFileStatus(null);
  }

  getDocumentDetails = async (documents) => {
    const { attributeObj } = this.state;
    attributeObj.logoURL = documents && documents.length > 0 && documents[0].documentURL;
    await this.setState({ attributeObj: { ...attributeObj } })
    this.handleSave();
    this.setState({ openBulkImportModal: false });
  }

  getCompleteDetails = (completeDetails) => {
    this.setState({ openBulkImportModal: false });
  }

  async updateApiData(orgData) {
    await this.setState({
      showContent: false,
      locationAttributeObj: {}
    });
    let temp = orgData && orgData.length > 0 && orgData.filter((item) => item.facilityId == this.state.facility)
    let attributeObj = temp && temp.length > 0 ? temp[0] : {}
    // const { locationAttributeObj } = this.state;
    await this.setState({
      showContent: true,
      attributeObj: {
        ...attributeObj,
      },
      locationAttributeObj: {
        country: attributeObj && attributeObj.country ? attributeObj.country : '',
        state: attributeObj && attributeObj.state ? attributeObj.state : '',
        city: attributeObj && attributeObj.city ? attributeObj.city : '',
        zipcode: attributeObj && attributeObj.zipcode ? attributeObj.zipcode : '',
      }, function() {
      },
      termsDictionaryList: attributeObj && _.size(attributeObj.termsDictionaryList) ? [...attributeObj.termsDictionaryList] : [{
        id: null,
        termsContainerHeader: "",
        termsContainerText: ""
      }]
    });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      setTimeout({}, 0);
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleLocationTextChange = async (event) => {
    await LocationUtil.updateLocationTextChange(event, this);
    this.handleLocationChange();
  }

  handleLocationNumberChange = async (event) => {
    await LocationUtil.updateLocationNumberChange(event, this);
    this.handleLocationChange();
  }

  handleLocationDropDownChange = async (event, obj) => {
    await LocationUtil.updateLocationDropDownChange(event, obj, this);
    this.handleLocationChange();
  }

  handleLocationChange() {
    var tempLocationList = [];
    tempLocationList.push({ ...this.state.locationAttributeObj });
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        country: tempLocationList[0].country,
        state: tempLocationList[0].state,
        city: tempLocationList[0].city,
        zipcode: tempLocationList[0].zipcode,
        locations: [...tempLocationList]
      }
    })
  }

  handleTableTextBoxChange(event) {
    const { name, value } = event.target;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.termsDictionaryList];
    attributeDataList[id][name] = value;
    this.setState({ termsDictionaryList: [...attributeDataList] });
  }
  maxLengthCheck(object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  handleRemove = (event) => {
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.termsDictionaryList];
    let tempAttributeDataList = [];
    for (let i = 0; i < attributeDataList.length; i++) {
      if (id !== i) {
        tempAttributeDataList.push({ ...attributeDataList[i] });
      }
    }
    this.setState({ termsDictionaryList: [...tempAttributeDataList] });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(dataDictionaryConstant.MANAGE_DASHBOARD_URL, this);
  }

  handleAddTerms = (event) => {
    let { termsDictionaryList } = this.state;
    let tempDictionaryList = [...termsDictionaryList];
    let tempObj = {};
    tempDictionaryList.push(tempObj);
    this.setState({ termsDictionaryList: [...tempDictionaryList] });
  }

  handleSave(event) {
    // console.log("handler",)
    this.setState({ submitted: true });
    console.log("termsContainerText",this.state)
    // let tempObj = this.props.attributeObj;
    let { attributeObj } = this.state;
    // tempObj = tempObj ? tempObj : []
    // let tempOrgInformation = {};
    let tempOrgInformation = _.cloneDeep(attributeObj);
    const OrgId = attributeObj.id ? attributeObj.id : '';
    tempOrgInformation.facility = this.state.facility;
    tempOrgInformation.businessName = this.state.facilityName;
    tempOrgInformation.status = true;
    tempOrgInformation.termsDictionaryList = [];
    tempOrgInformation.location = this.state.locationAttributeObj;
    tempOrgInformation = ValidationUtil.removeAttributeFromRequestObj(tempOrgInformation,
      this.state.attributeList, commonConstant.EDIT_ACTION_MODE);
    tempOrgInformation.termsDictionaryList = [...this.state.termsDictionaryList];
    delete tempOrgInformation.id;
    delete tempOrgInformation.location;
    if (ValidationUtil.validateArrayListRequestObj(tempOrgInformation, this.state.attributeList)) {
      console.log(tempOrgInformation, OrgId,tempOrgInformation,"tempOrgInformation, OrgId")
      this.props.setOrganizationDetails(tempOrgInformation, OrgId ? commonConstant.EDIT_ACTION_MODE : commonConstant.CREATE_ACTION_MODE, OrgId);
    }
  }
  render() {
    const { attributeList, attributeObj, attributeListTermsContainer, submitted,
      termsDictionaryList, attributeListLocation, locationAttributeObj, showContent } = this.state;
    const actionMode = commonConstant.CREATE_ACTION_MODE;
    return (
      <Grid fluid>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        {this.state.openBulkImportModal ?
          <DragDropDialog
            accept="image/jpeg, image/png"
            minSize={0}
            maxSize={1000000}
            multiple={false}
            maxFiles={1}
            errormsg="File size exceed max size limit of 1 MB."
            typeerror="File type is not accepted"
            getdocumentdetails={this.getDocumentDetails}
            getCompleteDetails={this.getCompleteDetails}
            files={attributeObj != null && attributeObj.documents && attributeObj.documents.length > 0 ?
              attributeObj.documents : null}
            fileNamePrefix="bulk-import"
            isBulkImport={true}
          />
          : null}
        <Row>
          <Col md={12}>
            <Card
              content={
                <div>
                  <div className="orgcontact-heading">
                    <Row>
                      <Col md={12}>
                        <p>The following details are required to print on the Sales delivery note, Purchase order, Pro-forma Invoice or any such document which is sent over to the consumer or vendor against any order.</p>
                      </Col>
                    </Row>
                  </div>

                  <div className="orgcontact-details">
                    <Row>
                      <Col md={12}>
                        <div className="orgcontact-title">Contact Details</div>
                      </Col>
                      <Col md={4}>
                        <FormGroup>
                          <ControlLabel>
                            Business
                          </ControlLabel>
                          <Select
                            classNamePrefix="react-select"
                            name="location"
                            placeholder="Location"
                            value={{ "label": this.state.facilityName ? this.state.facilityName : 'Select Location' }}
                            onChange={(value) => this.handleFacilityDropdownChange(value)}
                            options={[...this.state.facilityList]} />
                        </FormGroup>
                      </Col>
                    </Row>

                    <Row>
                      {showContent && attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                        tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                          TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                          : tempAttributeListObj.type == "DROPDOWN" ?
                            DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                            : null))
                      }
                    </Row>

                    <Row>
                      {showContent && attributeListLocation != null && attributeListLocation.map((tempAttributeListObj, index) => (
                        tempAttributeListObj.type == "TEXTBOX" ?
                          TextBoxUtil.locationTextBoxAttribute(tempAttributeListObj, index, locationAttributeObj, submitted, this, actionMode)

                          : tempAttributeListObj.type == "DROPDOWN" ?
                            DropDownUtil.locationDropDownAttribute(tempAttributeListObj, index, locationAttributeObj, submitted, this, actionMode)
                            : null))
                      }
                    </Row>
                  </div>

                  <div className="bulk-import-page orgcontact-details">
                    <Row className="import">
                      <Col md={12}>
                        <Row className="d-flex">
                          <Col md={2}><h3>Upload Logo</h3></Col>
                          <div className="download-upload-btns">
                            <Button id="logo" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}>
                              <img src={upload} alt="" className="normal-state" />
                              <img src={uploadblue} alt="" className="hover-state" />
                              Upload
                            </Button>
                          </div>
                          {(showContent && attributeObj && attributeObj.logoURL) ? <img id="logo-preview" src={attributeObj.logoURL} alt="logo" /> : null}
                        </Row>
                      </Col>
                      <Col md={12} className="text-danger">* Logo should be in format jpg, png and not more than 1MB size.</Col>
                    </Row>
                  </div>

                  <Row>
                    <Col md={12}>
                      <div className="orgcontact-title">Terms & Conditions</div>
                    </Col>
                  </Row>
                  {showContent && termsDictionaryList != null && termsDictionaryList.map((tempAttributeDataListObj, index) => (
                    <Row className="terms-dictionary" key={index}>
                      {attributeListTermsContainer != null && attributeListTermsContainer.map((tempAttributeListObj, index1) => (
                        tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                          <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index1}>
                            <FormGroup>
                              <ControlLabel>
                                {tempAttributeListObj.tooltipText ?
                                  <OverlayTrigger
                                    placement="right"
                                    overlay={
                                      <Tooltip id={tempAttributeListObj.label}>
                                        {tempAttributeListObj.tooltipText}
                                      </Tooltip>
                                    }
                                  >
                                    <span> {tempAttributeListObj.label}
                                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                                  </OverlayTrigger>
                                  : <span> {tempAttributeListObj.label}
                                    {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                                }
                              </ControlLabel>
                              <FormControl
                                id={tempAttributeListObj.name + '_' + index}
                                type={tempAttributeListObj.inputType}
                                componentClass={tempAttributeListObj.numberOfRow == 0 ? "text" : 'textarea'}
                                name={tempAttributeListObj.name}
                                onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
                                onChange={(e) => {
                                  this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                  this.handleTableTextBoxChange(e)
                                }}
                                disabled={false}
                                value={tempAttributeDataListObj[tempAttributeListObj.name]}
                                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                maxLength={tempAttributeListObj.maxLength}
                                rows={tempAttributeListObj.numberOfRow}
                              />
                              {(touch || submitted) && tempAttributeListObj.maxLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                +tempAttributeDataListObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                                <small className="text-danger">
                                  Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                </small>
                              }
                              {(touch || submitted) && tempAttributeListObj.minLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                +tempAttributeDataListObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                                <small className="text-danger">
                                  Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                </small>
                              }
                            </FormGroup>
                          </Col>
                          : null))}
                      {/* <Col md={3}>
                        <i className="fa fa-plus" onClick={this.handleAddTerms}></i>
                        <i id={"REMOVE" + '_' + index} className="fa fa-close" onClick={this.handleRemove}></i>
                      </Col> */}
                    </Row>
                  ))}
                </div>
              }
              ftTextRight
              legend={
                <>
                  {isAuthorized("updateOrg") &&
                    <div>
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                  }
                </>
              }
            />
          </Col>
        </Row>
      </Grid>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.dataDictionary.orgInformation,
    userProfile: state.user.userProfile,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    facilityList: state.facility.facilityList,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setUploadImportFileStatus: status => dispatch(setUploadImportFileStatus(status)),
  setOrganizationDetails: (dataDictionaryDetailsObj, actionMode, OrgId) => dispatch(setOrganizationDetails(dataDictionaryDetailsObj, actionMode, OrgId)),
  getOrganizationDetails: selectedFacilityCode => dispatch(getOrganizationDetails(selectedFacilityCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(orgContactInformation);
