import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab, FormGroup, ControlLabel } from "react-bootstrap";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from '../../common/util/popupUtil';
var Modal = require('react-bootstrap-modal')

class DetailModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      alert: null,
      importSummary: null,
      importFacilitySummary: null,
      importSupplierSummary: null,
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getErrorDetails(true);
    this.setState({ openModal: false, alert: null });
  }

  render() {
    let summary = this.props.uploadImportFileStatus;

    return (
      <div>
        {
          summary ? 
          summary.isFileEmpty ?
            <Modal show={this.state.openModal}
              onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
              <Modal.Header closeButton>
                <Modal.Title>
                  <div className="model-heading">Import Failed</div>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <div className="main-content">
                  <div className="text" style={{ color: 'red' }}>Uploaded File is Empty, Please verify file again.</div>
                </div>
              </Modal.Body>
            </Modal>
            :
           (summary.isTemplateHeaderInvalid ?
              <Modal show={this.state.openModal}
                onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
                <Modal.Header closeButton>
                  <Modal.Title>
                    <div className="model-heading">Import Failed</div>
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="main-content">
                    <div className="text" style={{ color: 'red' }}>Column header of the uploaded file does not match to the template. Please download the template again and verify it.</div>
                  </div>
                </Modal.Body>
              </Modal>
              :
              <Modal show={this.state.openModal}
                onHide={this.handlePopupCancel} aria-labelledby="ModalHeader">
                <Modal.Header closeButton>
                  <Modal.Title>
                    <div className="model-heading">Import Summary</div>
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                  <div className="main-content">
                    <Grid fluid>
                      <Row>
                        <Col md={12}>
                          <div className="success-record">
                            <i className="fa fa-check" />
                            <div className="text"><span>{summary.successCount}</span> of total {summary.totalCount} rows have been imported successfully.</div>
                          </div>
                        </Col>
                        {summary.totalCount != summary.successCount &&
                          <Col md={12}>
                            <div className="failed-record">
                              <div className="circle"><i className="fa fa-exclamation" /></div>
                              {summary.duplicateCount > 0 ?
                                <div className="text"><span>{summary.duplicateCount} rows </span>
                                are skipped because of duplicate data.</div>
                                : null}
                                
                                {summary.failedCount > 0 &&
                                  <div className="text"><span>{summary.failedCount} rows</span> are skipped because of incorrect data.</div>
                                }
                            </div>
                            <div className="failded-record-deatils">
                              {summary.failedRecords.map((value, index) => {
                                return <p>{value}</p>
                              })}
                            </div>
                          </Col>
                          }
                      </Row>
                    </Grid>
                  </div>
                </Modal.Body>
              </Modal>
          ) : (
              null
            )}
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    uploadImportFileStatus: state.ajaxStatusReducer.uploadImportFileStatus,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DetailModal);
