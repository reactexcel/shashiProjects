import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import { setAjaxCallStatus, setUploadImportFileStatus } from '../../../actions/ajaxStatusActions';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import download from "assets/img/download-white.svg";
import upload from "assets/img/upload-white.svg";
import downloadblue from "assets/img/download-blue.svg";
import uploadblue from "assets/img/upload-blue.svg";
import DragDropDialog from '../../../components/DragDrop/DragDropDialog';
import BulkImportErrorModal from "./BulkImportErrorModal.js";
// import { setBulkIngredient } from '../../ingredientManagement/actions/ingredientActions';
import { setBulkFacilities } from '../../facilityManagement/actions/facilityActions';
// import { setBulkOperation } from '../../operation/actions/operationActions';
import { setBulkProduct } from '../../productManagementFp/actions/productActions';
import { setBulkInventory } from '../../stockAdjustment/actions/stockAdjustmentActions';
import { setBulkSupplier, setMappingBulkSupplier } from '../../supplierManagementFp/actions/supplierActions';
import { setBulkPurchaseOrder } from '../../purchaseOrderFp/actions/purchaseOrderActions';
import * as bulkConstant from "../constant/bulkConstant";
import { setBulkCustomers } from '../../customer/actions/customerActions';

class Bulkimport extends Component {
    constructor(props) {
        super(props);
        this.state = {
            openBulkImportModal: false,
            openBulkImportErrorModal: false,
            attributeObj: null,
            alert: null,
            eventId: null,
        };

        this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
        this.handleUpload = this.handleUpload.bind(this);
        this.getDocumentDetails = this.getDocumentDetails.bind(this);
        this.getCompleteDetails = this.getCompleteDetails.bind(this);
        this.getErrorDetails = this.getErrorDetails.bind(this);
        this.handleSave = this.handleSave.bind(this);
    }

    componentDidMount = () => {
        this.props.getUserProfile();
        this.props.getDataDictionaryDetails();
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
            this.handleAjaxResponse();
        }
        if (this.props.uploadImportFileStatus != prevProps.uploadImportFileStatus) {
            this.getErrorDetails(this.props.uploadImportFileStatus);
        }
    }

    componentWillUnmount() {

    }

    getDocumentDetails(documents) {
        const { attributeObj } = this.state;
        this.setState({
            attributeObj: {
                ...attributeObj,
                documents: [...documents]
            }
        })
        this.handleSave(documents);
    }

    getCompleteDetails = (completeDetails) => {
        this.setState({ openBulkImportModal: false });
    }

    getErrorDetails = (errorDetails) => {
        this.setState({ openBulkImportErrorModal: true });
    }

    handleAjaxResponse() {
        if (this.props.ajaxCallStatus.status == "SUCCESS") {
            this.props.getDataDictionaryDetails();
            this.props.setAjaxCallStatus(null);
            this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
            setTimeout({}, 0);
        }
        let responseData = this.props.ajaxCallStatus.data && this.props.ajaxCallStatus.data.response;
        if (this.props.ajaxCallStatus.status == "FAILED" && responseData.status != 409 &&
            responseData.status != 405) {
            PopupUtil.popupErrorResponse(this);
            this.props.setAjaxCallStatus(null);
        }
    }

    handleUpload = async (event) => {
        let eventId = event.target.id;
        await this.setState({
            openBulkImportModal: true,
            openBulkImportErrorModal: false,
            eventId: eventId
        })
        this.props.setUploadImportFileStatus(null);
    }

    handleSave = async (documents) => {
        this.setState({ submitted: true, alert: null });
        const { eventId } = this.state;
        var params = {
            documents: [...documents]
        }
        if (eventId == "facility") {
            this.props.setBulkFacilities(params);
        } else if (eventId == "supplier") {
            this.props.setBulkSupplier(params);
        } else if (eventId == "product") {
            this.props.setBulkProduct(params);
        } else if (eventId == "stock") {
            this.props.setBulkInventory(params);
        } else if (eventId == "suppliermapping") {
            this.props.setMappingBulkSupplier(params);
        } else if (eventId == "purchaseorder") {
            this.props.setBulkPurchaseOrder(params);
        } else if (eventId == "customer") {
            this.props.setBulkCustomers(params);
        }
        await this.setState({ openBulkImportModal: false });
    }

    render() {
        const { attributeObj } = this.state;

        return (
            <Row>
                {this.state.redirect === true ?
                    <Redirect push to={this.state.redirectUrl}></Redirect> : null
                }
                {this.state.alert}
                {this.state.openBulkImportModal ?
                    <DragDropDialog
                        accept='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'
                        minSize={0}
                        maxSize={5000000}
                        multiple={false}
                        maxFiles={1}
                        errormsg="File size exceed max size limit of 5 MB."
                        typeerror="File type is not accepted"
                        getdocumentdetails={this.getDocumentDetails}
                        getCompleteDetails={this.getCompleteDetails}
                        files={attributeObj != null && attributeObj.documents.length > 0 ?
                            attributeObj.documents : null}
                        fileNamePrefix="bulk-import"
                        isBulkImport={true}
                    />
                    : null}
                <Col md={12} className="bulk-import-page">
                    <Card
                        content={
                            <Row>
                                <Col md={12}>
                                    <div className="heading-section">
                                        <div className="heading">You can import your data in bulk by using our template. Please follow below steps:</div>
                                        <ul className="bulk-import-step-list">
                                            <li>Download the template.</li>
                                            <li>Fill in the template and save it in XLS or XLSX format on your computer. There are few comments in column headers  which will guide you to understand the template.</li>
                                            <li>Import data into originscale by using the “Upload Data” option.</li>
                                        </ul>
                                    </div>
                                </Col>
                                <Col md={12}>
                                    <div className="import">
                                        <h3>Import Products</h3>
                                        <Row>
                                            <Col md={8}>You can import new products using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_PRODUCT_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="product" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    {/*<div className="import">
                                        <h3>Import Ingredients</h3>
                                        <Row>
                                            <Col md={8}>You can import new ingredients using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_INGREDIENT_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="ingredient" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Import Operations</h3>
                                        <Row>
                                            <Col md={8}>You can import all your product-specific operations using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_OPERATION_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="operation" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>*/}
                                    <div className="import">
                                        <h3>Import Facilities</h3>
                                        <Row>
                                            <Col md={8}>You can import your facility information using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_FACILITY_DOCUMENTS_URL} className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="facility" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Import Suppliers</h3>
                                        <Row>
                                            <Col md={8}>You can import your supplier details using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_SUPPLIER_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="supplier" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Import Stock</h3>
                                        <Row>
                                            <Col md={8}>You can import your stock details using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_INVENTORY_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="stock" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Map Products with Suppliers</h3>
                                        <Row>
                                            <Col md={8}>You can map your products/ingredients with supplier details using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_SUPPLIER_MAPPING_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="suppliermapping" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Import Purchase Orders</h3>
                                        <Row>
                                            <Col md={8}>You can import your purchase order using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_PURCHASE_ORDER_DOCUMENTS_URL} download className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="purchaseorder" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                    <div className="import">
                                        <h3>Import Customer</h3>
                                        <Row>
                                            <Col md={8}>You can import your customer information using our import template. Download and fill in the template and upload it back to originscale.</Col>
                                            <Col md={4} className="download-upload-btns">
                                                <a href={bulkConstant.DOWNLOAD_CUSTOMER_DOCUMENTS_URL} className="btn-save btn-fill btn btn-default"><img src={download} alt="" className="normal-state" /><img src={downloadblue} alt="" className="hover-state" /> Download</a>
                                                <Button id="customer" className="btn-save btn-fill btn btn-default" onClick={this.handleUpload}><img src={upload} alt="" className="normal-state" /><img src={uploadblue} alt="" className="hover-state" /> Upload</Button>
                                            </Col>
                                        </Row>
                                    </div>
                                </Col>
                            </Row>
                        }
                    />
                </Col>
                {this.state.openBulkImportErrorModal ?
                    <BulkImportErrorModal
                        getErrorDetails={this.getErrorDetails}
                        summaryDetails={this.props.bulkImportIngredientDetails}
                    >
                    </BulkImportErrorModal>
                    : null}
            </Row>
        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
        ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
        userProfile: state.user.userProfile,
        uploadImportFileStatus: state.ajaxStatusReducer.uploadImportFileStatus,
    };
}

const mapDispatchToProps = dispatch => ({
    setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
    setUploadImportFileStatus: status => dispatch(setUploadImportFileStatus(status)),
    getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
    getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
    // setBulkIngredient: params => dispatch(setBulkIngredient(params)),
    setBulkFacilities: params => dispatch(setBulkFacilities(params)),
    // setBulkOperation: params => dispatch(setBulkOperation(params)),
    setBulkProduct: params => dispatch(setBulkProduct(params)),
    setBulkInventory: params => dispatch(setBulkInventory(params)),
    setBulkSupplier: params => dispatch(setBulkSupplier(params)),
    setMappingBulkSupplier: params => dispatch(setMappingBulkSupplier(params)),
    setBulkPurchaseOrder: params => dispatch(setBulkPurchaseOrder(params)),
    setBulkCustomers: params => dispatch(setBulkCustomers(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Bulkimport);
