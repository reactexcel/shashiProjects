import * as commonConstant from '../../common/constant/commonConstant';

export const DOWNLOAD_FACILITY_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Facilities.xlsx';
export const DOWNLOAD_SUPPLIER_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'lotsys/Import_Suppliers.xlsx';
export const DOWNLOAD_SUPPLIER_MAPPING_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_SuppliersMapping.xlsx';
export const DOWNLOAD_INGREDIENT_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Ingredients.xlsx';
export const DOWNLOAD_OPERATION_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Operations.xlsx';
export const DOWNLOAD_PRODUCT_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'lotsys/Import_Products.xlsx';
export const DOWNLOAD_INVENTORY_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Inventory.xlsx';
export const DOWNLOAD_PURCHASE_ORDER_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Purchase_Orders.xlsx';
export const DOWNLOAD_CUSTOMER_DOCUMENTS_URL = commonConstant.FILEDOWNLOAD_URL + 'Import_Customers.xlsx';