import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, ControlLabel, Tabs, Tab, FormControl, InputGroup } from "react-bootstrap";
import Select from "react-select";
import { touch } from "redux-form";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import { Redirect } from "react-router-dom";
import { connect } from "react-redux";
import {
  setIngredientDetails, getIngredientDetails, setReducerInitMode, getSKUNumber
} from "../actions/ingredientActions";
import { getSupplierList, getSupplierDetails } from "../../supplierManagement/actions/supplierActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as ingredientConstant from '../constant/ingredientConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import LabelUtil from '../../common/util/labelUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import SuggestionAttrUtil from '../../common/util/suggestionAttrUtil';
import _ from 'lodash';
import CheckBoxUtil from '../../common/util/checkBoxUtil';
import flour from "assets/img/flour-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import CreateSupplierModal from '../../common/components/CreateSupplierModal';
import * as statusConstant from '../../common/constant/statusConstant';
import { getDataDictionaryDetails, getTierPricingDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getUserProfile } from "../../userManagement/actions/userActions";
class CreateIngredient extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      isOpenModal: false,
      tierPriceAttributeList: null,
      showTier: false,
    };

    this.handleSave = this.handleSave.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Create Ingredient loaded");
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({searchInput : searchInput ? searchInput : ''})
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      // this.props.getSupplierList();
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getIngredientDetails(this.props.selectedIngredientCode, {categoryId: this.props.selectedCategoryCode});
      }
    }
    else {
      CommonUtil.handlePageRedirection(ingredientConstant.MANAGE_INGREDIENT_PAGE_URL, this);
    }
    this.props.getDataDictionaryDetails();
    this.props.getTierPricingDetails();
    this.props.getUserProfile();
    const commonAttributeList = pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(commonAttributeList.attributeList,
        this.props.dataDictionaryList),
      attributeObj: pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this).attributeObj,
      tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
      // usageAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
      //   commonAttributeList.usageAttributeList, this.props.dataDictionaryList),
    }, () => this.updateCommonAttribute());
  }

  updateAttributeObj(supplierDetails) {
    const { attributeObj } = this.state;
    for (let i = 0; i < supplierDetails.ingredients.length; i++) {
      if (supplierDetails.ingredients[i].productId == attributeObj.productId) {
        attributeObj.leadTime = supplierDetails.ingredients[i].leadTime;
        attributeObj.moq = supplierDetails.ingredients[i].moq;
        attributeObj.moa = supplierDetails.ingredients[i].moa;
        attributeObj.tax = supplierDetails.ingredients[i].taxCode;
        attributeObj.purchasePrice = supplierDetails.ingredients[i].purchasePrice;
        attributeObj.showSupplierFields = true;
        this.setState({
          attributeObj: {
            ...attributeObj
          }
        });
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj !== null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }

    if (CommonUtil.isCreateMode(this.props.actionMode) && _.size(this.props.tierPricing) && prevProps.tierPricing != this.props.tierPricing) {
      const commonAttributeList = pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this, this.props.tierPricing);
      this.setState({
        attributeObj : { ...this.state.attributeObj, tierPrices: this.props.tierPricing },
        tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
      })
    }

    if (this.props.skuNumber != null && prevProps.skuNumber != this.props.skuNumber) {
      this.updateSkuNumber();
    }
    if (this.props.supplierDetails != null && prevProps.supplierDetails != this.props.supplierDetails) {
      if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
        this.updateAttributeObj(this.props.supplierDetails);
      }
    }
    if (prevProps.supplierList !== this.props.supplierList && this.props.supplierList !== null) {
      this.updateSupplierDropDownList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    // if (prevProps.location && prevProps.location.key !== this.props.location.key) {
    //   if (!CommonUtil.isCreateMode(this.props.actionMode)) {
    //     this.props.getIngredientDetails(this.props.selectedIngredientCode);
    //   } else {
    //     this.createNew();
    //   }
    // }
    if (prevProps.location.key !== this.props.location.key && this.props.location.state === "new") {
      if (CommonUtil.isCreateMode(this.props.actionMode)) {
        this.createNew();
      }
    }
  }

  updateSkuNumber = async () => {
    const { attributeObj } = this.state;
    await this.setState({
      attributeObj: {
        ...attributeObj,
        productSKU: this.props.skuNumber + "",
      }
    })
  }

  updateSupplierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.supplierList,'supplierId', 'supplierName');
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList, tempList, 'supplierId')
    })
    if (!CommonUtil.isCreateMode(this.props.actionMode)) {
      this.getDefaultSupplierPrice();
    }
  }

  getDefaultSupplierPrice = async () => {
    if(this.props.supplierList != null && this.props.attributeObj != null) {
      let selectedSupplierObj = CommonUtil.getFilteredObjFromArray(
        this.props.supplierList, 'supplierId', this.props.attributeObj.supplier);
      if (selectedSupplierObj != null) {
        let selectedIngredientObj = CommonUtil.getFilteredObjFromArray(
          selectedSupplierObj.ingredients, 'productId', this.props.selectedIngredientCode);
        const { attributeObj } = this.state;
        if (CommonUtil.isEditMode(this.props.actionMode) || CommonUtil.isViewMode(this.props.actionMode)) {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: selectedIngredientObj.purchasePrice
            },
          })
        } else {
          await this.setState({
            attributeObj: {
              ...attributeObj,
              purchasePrice: '',
              supplier: ''
            },
          })
        }
      }
    }
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleSave(event) {
    this.setState({ submitted: true });
    var tempObj = this.state.attributeObj, actionMode = this.props.actionMode;
    delete tempObj['status'];
    const tierPrices = _.get(tempObj, 'tierPrices', []);
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, actionMode);
    if(tempObj.isSellable) {
      tempObj.tierPrices = tierPrices;
    }
    if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      tempObj.productId = this.state.attributeObj.productId ? this.state.attributeObj.productId : '';

      // if (!tempObj.usgVolumeUnit) {
      //   tempObj.usgVolumeUnit = null;
      // }

      // if (!tempObj.usgUOM) {
      //   tempObj.usgUOM = null;
      // }
      this.props.setIngredientDetails(tempObj, actionMode);
    }
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      if (!this.state.isSupplierPopupFlag) {
        setTimeout(this.handlePopupContinue, 0);
      } else {
        this.setState({ openModal: false });
        this.closeModal();
        this.props.getSupplierList();
      }
    }

    if (this.props.ajaxCallStatus.status == "FAILED" && this.state.isOpenModal == false) {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handleLinkClick = (event) => {
    event.preventDefault();
    this.handleFamilyRedirection(ingredientConstant.MANAGE_INGREDIENT_PAGE_URL,
      this.getFamilyRequestParams(event));
  }

  generateSKUClick = (event) => {
    this.props.getSKUNumber();
  }

  handleFamilyRedirection = (redirectURL, params) => {
    this.setState({ redirect: true, redirectUrl: redirectURL, params }, () => {
    });
  }

  getFamilyRequestParams(event) {
    var tempParamas = {};
    tempParamas.family = this.state.attributeObj && this.state.attributeObj.family;
    return tempParamas;
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = this.state.attributeObj.status ? this.state.attributeObj.status : null;
    CommonUtil.handlePageRedirection(ingredientConstant.MANAGE_INGREDIENT_PAGE_URL, this, params);
  }

  async updateApiData(attributeObj) {
    const commonAttributeList = pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this);
    let taxesList = [];
    _.size(attributeObj.taxes) && attributeObj.taxes.map(item => {
      if(item.isactive) {
        let temp = item.taxName + " (" + (item.taxType == "volume" ? "$" : "") + item.taxValue + (item.taxType == "percentage" ? "%" : "") + ")"
        taxesList.push(temp);
      }
    })
    let taxes = taxesList.join(", ");
    await this.setState({
      attributeObj: {
        ...attributeObj,
        productId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productId,
        productName: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productName,
        productSKU: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.productSKU,
        taxes: CommonUtil.isCloneMode(this.props.actionMode) ? '' : taxes,
      },
      tierPriceAttributeList: commonAttributeList.tierPriceAttributeList,
    })
    if (!CommonUtil.isCreateMode(this.props.actionMode)) {
      this.getDefaultSupplierPrice();
    }
    await this.updateCommonAttribute();
  }

  createNew = async () => {
    let tempObj = [];
    await this.setState({
      attributeObj: {
        ...tempObj,
        productId: "",
        productName: "",
        productGTIN: "",
        productSKU: "",
        purchasePrice: "",
        hsnCode: "",
        // upcNumber: "",
        status: statusConstant.ACTIVE_STATUS,
      },
    });
  };

  showModal = () => {
    this.setState({ isOpenModal: true, isSupplierPopupFlag: true });
  };

  closeModal = () => {
    this.setState({ isOpenModal: false, isSupplierPopupFlag: false });
  }

  getCompleteDetails = (completeDetails) => {
    this.setState({ isOpenModal: false, isSupplierPopupFlag: false });
  }

  handleCustomDropDownChange = async (event, obj) => {
    if (obj.name == 'supplier') {
      const { attributeObj } = this.state;
      attributeObj.leadTime = "";
      attributeObj.moq = "";
      attributeObj.moa = "";
      attributeObj.tax = "";
      attributeObj.purchasePrice = "";

      const { attributeList } = this.state;
      var newlist = attributeList.map((item) => {
        if (item.supplierfields) {
          item.showField = true;
          item.required = true;
          item.createMode = 'enable';
          item.cloneMode = 'enable';
          item.editMode = 'enable';
        }
        return item;
      });

      if (CommonUtil.isEditMode(this.props.actionMode)) {
        attributeObj.showSupplierFields = true;
      }
      await this.setState({
        attributeList: newlist,
        attributeObj: {
          ...attributeObj,
          [obj.name]: event.value,
          ['supplierId']: event.value,
        },
      });
      this.props.getSupplierDetails(event.value);
    }
  }

  handleCustomCheckBoxChange = async (event) => {
    await CommonUtil.handleCheckBoxChange(event, this);
    await this.updateCommonAttribute();
  }

  // handleRadioButtonsChange = async (event) => {
  //   const { name, value } = event.target;
  //   const { attributeObj } = this.state;

  //   attributeObj.usgPackSizeQty = null;
  //   attributeObj.usgUOM = '';
  //   attributeObj.usgCostPerUnit = null;
  //   attributeObj.usgVolume = null;
  //   attributeObj.usgVolumeUnit = null;

  //   await this.setState({
  //     attributeObj: {
  //       ...attributeObj,
  //       usgType: value
  //     }
  //   });

  //   this.updateCommonAttribute();
  // }

  
  updateCommonAttribute = async () => {
    let attributeList = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this))).attributeList;
    let { attributeObj } = this.state;
    const { actionMode } = this.props;
    let showTier = false;
    await this.setState({ attributeObj: attributeObj })

    attributeList = CommonUtil.getDropDownOptionsFromDictionary(
      pagePropertyListConstant.CREATE_INGREDIENT_PAGE_LIST(this).attributeList,
      this.props.dataDictionaryList);

    if(CommonUtil.isNotNull(this.state.attributeObj.taxes) && attributeObj.isSellable) {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'taxes', `${actionMode}ShowFlag`, true);
    }

    if (attributeObj.isSellable) {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'salesPrice', `${actionMode}ShowFlag`, true);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'salesPrice', `required`, true);
      showTier = true;
    } else {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'salesPrice', `${actionMode}ShowFlag`, false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'salesPrice', `required`, false);
      showTier = false;
      await this.setState({ 
        attributeObj: {
          ...attributeObj,
          salesPrice: '',
        } 
      })
    }

    if(((this.props.userProfile && this.props.userProfile.metadata) ? (this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : true): false)) {
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'subcategory', `${actionMode}ShowFlag`, this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : false);
      attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'subcategory', `required`, this.props.userProfile.metadata.isSubCategoryVisible ? this.props.userProfile.metadata.isSubCategoryVisible : false);
    }

  //   attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgType', `value`, attributeObj.usgType);

  //   if (attributeObj.usgType == ingredientConstant.CREATE_INGREDIENT_USAGE_PACKSIZE) {
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolume', `${actionMode}ShowFlag`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolumeUnit', `${actionMode}ShowFlag`, false);

  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolume', `required`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolumeUnit', `required`, false);

  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgPackSizeQty', `${actionMode}ShowFlag`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgUOM', `${actionMode}ShowFlag`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgCostPerUnit', `${actionMode}ShowFlag`, true);

  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgPackSizeQty', `required`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgUOM', `required`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgCostPerUnit', `required`, true);
  //   } else if (attributeObj.usgType == ingredientConstant.CREATE_INGREDIENT_USAGE_VOLUME) {
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgPackSizeQty', `${actionMode}ShowFlag`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgUOM', `${actionMode}ShowFlag`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgCostPerUnit', `${actionMode}ShowFlag`, false);

  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgPackSizeQty', `required`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgUOM', `required`, false);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgCostPerUnit', `required`, false);
      
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolume', `${actionMode}ShowFlag`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolumeUnit', `${actionMode}ShowFlag`, true);

  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolume', `required`, true);
  //     attributeList = CommonUtil.updateAttributePropertyValue(attributeList, 'usgVolumeUnit', `required`, true);
  //   }

    await this.setState({ attributeList: attributeList, showTier: showTier });
  }

  handleCustomTextBoxChange = async (event) => {
    const { name, value } = event.target;
    if (name == 'purchasePrice' || name == 'usgPackSizeQty') {
      await CommonUtil.handleNumberChange(event, this);
      await this.handleUsageCostPerUnitCalulation();
    }
  }

  handleUsageCostPerUnitCalulation = () => {
    let { attributeObj } = this.state;
    var grandTotal = 0;

    var tempPurchasePrice = 0, tempQuantity = 0;
    tempPurchasePrice = Number(attributeObj.purchasePrice);
    tempQuantity = Number(attributeObj.usgPackSizeQty);

    if (tempQuantity) {
      grandTotal = Number(tempPurchasePrice / tempQuantity);
    } else {
      grandTotal = 0;
    }

    grandTotal = Number(grandTotal).toFixed(2);

    this.setState({
      attributeObj: {
        ...attributeObj,
        usgCostPerUnit: grandTotal
      }
    })
  }

  handleTierDropdownChange(event, obj, index, that) {
    let { attributeObj } = that.state;
    let updatedTierPrice = { ...attributeObj.tierPrices[index], [obj.name]: event.value };
    let updatedTierPrices = [...attributeObj.tierPrices];
    updatedTierPrices[index] = updatedTierPrice;
    let updatedAttributeObj = { ...attributeObj, tierPrices: updatedTierPrices };
    this.setState({ attributeObj: updatedAttributeObj });
  }

  handleChangeTierValue(event, index, that) {
    console.log({ event, index, that })
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let updatedTierPrice = { ...attributeObj.tierPrices[index], [name]: value };
    let updatedTierPrices = [...attributeObj.tierPrices];
    updatedTierPrices[index] = updatedTierPrice;
    let updatedAttributeObj = { ...attributeObj, tierPrices: updatedTierPrices };
    this.setState({ attributeObj: updatedAttributeObj });
  }

  handleTableTierTextBoxChange(event, that) {
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.attributeObj.tierPrices];
    attributeDataList[id][name] = value;
    const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
    this.setState({ attributeObj: u });
  }

  handleNumberChange(event, that) {
    const { name, value } = event.target;
    let { attributeObj } = that.state;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.attributeObj.tierPrices];
    const re = /^\d+(\.\d{0,2})?$/;
    if (value === '' || re.test(value)) {
      attributeDataList[id][name] = value;
      const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
      this.setState({ attributeObj: u });
    } else {
      attributeDataList[id][name] = value.substring(0, value.length - 1);
      const u = { ...attributeObj, tierPrices: [...attributeDataList]  }
      this.setState({ attributeObj: u });
    }
  }

  maxLengthCheck(object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  maxValueCheck(object, maxValue) {
    let customErrorFlag = false;
    if (object.target.value > maxValue) {
      object.target.value = object.target.value.slice(0, 3)
      customErrorFlag = true
    }
    return customErrorFlag;
  }

  render() {
    // const { attributeList, attributeObj, submitted, customErrorFlag, usageAttributeList } = this.state;
    const { attributeList, attributeObj, submitted, customErrorFlag, tierPriceAttributeList, showTier } = this.state;
    const actionMode = this.props.actionMode;

    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={flour} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    ingredientConstant.EDIT_INGREDIENT_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      ingredientConstant.VIEW_INGREDIENT_HEADER_TITLE
                      : ingredientConstant.CREATE_INGREDIENT_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>

          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>

                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                          tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              tempAttributeListObj.supplierfields == true ?
                                (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                  : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                    : null
                                : TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                              : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                tempAttributeListObj.supplierfields == true ?
                                  (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                    : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      : null
                                  : DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "SUGGESTION" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  SuggestionAttrUtil.suggestionDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "CUSTOM_RADIO" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index} className="usage-checkbox">
                                  <FormGroup style={{ width: '100%' }}>
                                    <div>
                                      <ControlLabel style={{ textTransform: 'none' }}>
                                        {tempAttributeListObj.label}
                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                      </ControlLabel>
                                    </div>
                                    <div className="usage-btn">
                                      {tempAttributeListObj.checkList.map((check, Nestedindex) => {
                                        return (
                                          <Col md={4} key={Nestedindex}>
                                            <CustomRadio key={Nestedindex} name={check.name} number={check.name} label={check.label}
                                              onChange={this.handleRadioButtonsChange} value={check.value}
                                              disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                              checked={attributeObj.usgType == check.value} />
                                          </Col>
                                        )
                                      })}
                                    </div>
                                  </FormGroup>
                                </Col>
                                : tempAttributeListObj.type == "CHECKBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                    : null))
                        }
                      </Row>
                      {showTier && _.size(attributeObj) && _.size(attributeObj.tierPrices) > 0 && <Row>
                          <Col md={12}>
                            <div className="orgcontact-title">Tier Pricing</div>
                          </Col>
                        </Row>}
                        {showTier && _.size(attributeObj) && _.size(attributeObj.tierPrices) > 0 && attributeObj.tierPrices.map((tempAttributeDataListObj, index) => (
                          <Row>
                            {tierPriceAttributeList != null && tierPriceAttributeList.map((tempAttributeListObj, index1) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index1}>
                                  <FormGroup>
                                    <ControlLabel style={{ marginBottom: 'unset' }}>
                                      <span> {tempAttributeListObj.label}
                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                                    </ControlLabel>
                                    <FormControl
                                      id={tempAttributeListObj.name + '_' + index}
                                      componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                                      name={tempAttributeListObj.name}
                                      onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                                      onBlur={(e) => this.handleChangeTierValue(e, index, this)}
                                      onChange={(e) => {
                                        this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                        if (tempAttributeListObj.type == "TEXTBOX_TAX") { this.maxValueCheck(e, 100) };
                                        tempAttributeListObj.inputType == "number" ?
                                          this.handleNumberChange(e, this) :
                                          this.handleTableTierTextBoxChange(e, this)
                                      }}
                                      disabled={!tempAttributeDataListObj['adjustmentType'] || tempAttributeDataListObj['adjustmentType'] === "Global"}
                                      value={(tempAttributeDataListObj['adjustmentType'] === 'Global' || tempAttributeDataListObj[tempAttributeListObj.name] === null || !tempAttributeDataListObj['adjustmentType']) ? tempAttributeDataListObj['percentage'] : tempAttributeDataListObj[tempAttributeListObj.name]}
                                      onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                      onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, tempAttributeListObj.maxLength) }}
                                      maxLength={tempAttributeListObj.maxLength}
                                      rows={tempAttributeListObj.numberOfRow}
                                    />
                                    {submitted && tempAttributeListObj.required && !CommonUtil.isNotNull(tempAttributeDataListObj[tempAttributeListObj.name]) &&
                                      <small className="text-danger">
                                        {tempAttributeListObj.mandatoryMsgText}
                                      </small>
                                    }
                                    {submitted && customErrorFlag && tempAttributeDataListObj[tempAttributeListObj.name] ?
                                      <small className="text-danger">
                                        {tempAttributeListObj.customMessage}
                                      </small>
                                      : null
                                    }
                                    {(touch || submitted) && tempAttributeListObj.maxLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                      +tempAttributeDataListObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                    }
                                    {(touch || submitted) && tempAttributeListObj.minLength && tempAttributeDataListObj[tempAttributeListObj.name] &&
                                      +tempAttributeDataListObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                    }
                                    {(touch || submitted) && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.type == "TEXTBOX_TAX" && tempAttributeDataListObj[tempAttributeListObj.name] > 100 ?
                                      <small className="text-danger">
                                        Allowed value limit is 0 to 100.
                                      </small>
                                      : null
                                    }
                                  </FormGroup>
                                </Col>
                                : tempAttributeListObj.type == "DROPDOWN" ?
                                  <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                    <FormGroup>
                                      {tempAttributeListObj.label}
                                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                      <Select name={tempAttributeListObj.name}
                                        id={tempAttributeListObj.name + '_' + index}
                                        onChange={(e, obj) => this.handleTierDropdownChange(e, obj, index, this)}
                                        isMulti={tempAttributeListObj.isMulti}
                                        value={CommonUtil.getSelectedOptionLabel(tempAttributeListObj.options, (tempAttributeDataListObj[tempAttributeListObj.name] || 'Global'))}
                                        classNamePrefix="react-select"
                                        isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                                        placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options} />
                                      {(touch || submitted) && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                        <small className="text-danger">
                                          {tempAttributeListObj.mandatoryMsgText}
                                        </small>
                                      }
                                    </FormGroup>
                                  </Col>
                                  : null
                            ))
                            }
                          </Row>
                        ))}
                      {/* <Row>
                        <Col md={12}>
                          <div className="orgcontact-title">Usage</div>
                        </Col>
                      </Row>
                      <Row className="terms-dictionary">
                        {usageAttributeList != null && usageAttributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            tempAttributeListObj.supplierfields == true ?
                              (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)
                                  : null
                              : TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                              : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                tempAttributeListObj.supplierfields == true ?
                                  (CommonUtil.isCreateMode(actionMode) || CommonUtil.isEditOrCloneMode(actionMode) || CommonUtil.isViewMode(actionMode)) && tempAttributeListObj.showField == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                    : CommonUtil.isEditMode(actionMode) && tempAttributeListObj.showField == true && attributeObj.showSupplierFields == true ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      : null
                                  : DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                            : null))
                        }
                      </Row> */}
                    </div>

                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
        {this.state.isOpenModal == true ?
          <CreateSupplierModal getCompleteDetails={this.getCompleteDetails} /> : null
        }
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.ingredient.ingredientDetails,
    supplierDetails: state.supplier.supplierDetails,
    selectedIngredientCode: state.ingredient.selectedIngredientCode,
    currencyCode: state.dataDictionary.currencyCode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    actionMode: state.app.actionMode,
    supplierList: state.supplier.supplierList,
    skuNumber: state.ingredient.skuNumber,
    tierPricing: state.dataDictionary.tierPricing,
    selectedCategoryCode: state.ingredient.selectedCategoryCode,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setIngredientDetails: (ingredientDetailsObj, actionMode) => dispatch(setIngredientDetails(ingredientDetailsObj, actionMode)),
  getIngredientDetails: (selectedIngredientCode, selectedCategoryCode) => dispatch(getIngredientDetails(selectedIngredientCode, selectedCategoryCode)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  getSupplierDetails: selectedSupplierCode => dispatch(getSupplierDetails(selectedSupplierCode)),
  getSKUNumber: (params) => dispatch(getSKUNumber(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateIngredient);
