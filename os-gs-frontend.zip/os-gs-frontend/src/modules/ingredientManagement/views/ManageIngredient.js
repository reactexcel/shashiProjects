import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as ingredientConstant from '../constant/ingredientConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import {
  setSelectedIngredientCode, getIngredientList, updateIngredientStatus, getIngredientSearchList, setSelectedCategoryCode
} from "../actions/ingredientActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopupUtil from '../../common/util/popupUtil';
import { setActionMode } from "../../../actions/appActions";
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import _ from 'lodash'
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import flour from "assets/img/flour-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import StatusUtil from '../../common/util/statusUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import filter from 'assets/img/filter.svg';
import check from "assets/img/check.svg";
import Select from "react-select";
import MultipleSelectionModal from './MultipleSelectionModal';

class ManageIngredient extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: statusConstant.ACTIVE_STATUS,
      alert: null,
      redirect: false,
      redirectUrl: null,
      productId: null,
      status: null,
      activate: false,
      search: null,
      statusfilter: false,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      allList: [{ label: 'All', value: 'All' }]
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }


  componentDidMount = async () => {
    mixpanel.track("Manage Ingredient loaded");
    let status = CommonUtil.getAdditonalPathParams(this);
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({status: status, searchInput : searchInput ? searchInput : '', search : searchInput ? searchInput : ''})
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.setSelectedTabDetails(status);
    this.setState({ status: status });
  }

  setSelectedTabDetails = async (status) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    var additionalParams = {};
    additionalParams['isIngredient'] = true;
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setState({ selectedFilter: statusConstant.INACTIVE_STATUS });
      additionalParams.status = statusConstant.INACTIVE_STATUS;
    } else if (status && status.family != null) {
      additionalParams.family = status.family;
    } else if (status) {
      additionalParams.status = status;
    }
    if (this.state.categorySelect)
      additionalParams["categoryId"] = this.state.categorySelect;
    const { location, history } = this.props;
    history.replace();
    const managePageList = pagePropertyListConstant.MANAGE_INGREDIENT_PAGE_LIST(this);
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.ingredientList != this.props.ingredientList && this.props.ingredientList != null) {
      PaginationUtil.handlePagination(this.props.ingredientList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.ingredientList.filter(value => {
      return (
        String(value.productId).includes(searchInput) ||
        String(value.productSKU).includes(searchInput) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  handleFIlter = (event) => {
    PaginationUtil.initPaginationParams(this);
    let status = event.toLowerCase();
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setSelectedTabDetails(status);
    } else {
      this.setSelectedTabDetails();
    }
    this.setState({ selectedFilter: event, status: status, statusfilter: true });
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  advanceSearch = async () => {
    if(CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput});
      this.setSelectedTabDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  // closeSearchBox = () => {
  //   this.state.attributeObj.orderNumber = '';
  //   this.setState({ menuOpen: false });
  // }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedIngredientCode(tempId[0]);
    this.props.setSelectedCategoryCode(tempId[3])
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(ingredientConstant.CREATE_INGREDIENT_PAGE_URL, this);
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[1] == ingredientConstant.CREATE_INGREDIENT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(ingredientConstant.CREATE_INGREDIENT_PAGE_URL, this);
    }

    if (tempId[2] == ingredientConstant.ACTIVATE_INGREDIENT) {
      this.handleStatusAction(tempId[0], statusConstant.ACTIVE_STATUS);
      this.setState({ statusfilter: false,activate: true });
    }

    if (tempId[2] == ingredientConstant.DEATIVATE_INGREDIENT) {
      this.setState({
        productId: tempId[0],
        // status: statusConstant.INACTIVE_STATUS,
        activate: false,
        statusfilter: false,
      });
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeactivatePopUpConfig(popupActionButton, ingredientConstant.MODULE_NAME);
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleStatusAction(productId, status) {
    var tempObj = {};
    var productId = productId ? productId : this.state.productId;
    tempObj.deleted = true;
    tempObj.status = status ? status : statusConstant.INACTIVE_STATUS;
    PaginationUtil.initPaginationParams(this);
    this.setState({ alert: null, selectedFilter: statusConstant.ACTIVE_STATUS });
    this.props.updateIngredientStatus(tempObj, productId);
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if(this.state.activate == true) {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      } else {
        this.props.handleClick(CommonUtil.prepareDeactivateSuccessPopUpConfig());
      }
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
        this.props.setAjaxCallStatus(null);
        PopupUtil.popupErrorResponse(this, 'Ingredient can not be deactivated as it is used in any of the products.');
    }
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getIngredientSearchList(tempParamas);
    } else {
      this.props.getIngredientList(tempParamas);
    }
  }

  handlePopupContinue() {
    this.setState({ alert: null });
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isDeleteMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, searchInput: ""});
      await this.setSelectedTabDetails(this.state.status);
    }
    if (tempId[1] === "status") {
      await this.setState({ statusfilter: false, status: null, selectedFilter: statusConstant.ACTIVE_STATUS, lastEvaluatedKeyArray: []});
      await this.setSelectedTabDetails();
    }
  }

  generateBarCode = (event) => {
    let productId = event.target && event.target.id.split("_")[0];
    let productSKU = event.target && event.target.id.split("_")[1];
    const barcodeId = `generatedBarcode${productSKU}`;
    this.download(barcodeId);
  }

  download = (barcodeId) => {
    const svg = document.getElementById(barcodeId);
    const serializer = new XMLSerializer();
    const svgStr = serializer.serializeToString(svg);

    const url = "data:image/svg+xml;base64," + window.btoa(svgStr);

    let downloadLink = document.createElement("a");
    downloadLink.href = url;
    downloadLink.download = "barcode.svg";
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
  }

  handleMultipleSelection = (event) => {
    this.setState({ multipleSelectionModal: true, updateType : event, activate: true });
  }

  getProductSelectionDetails = async (flag) => {
    await this.setSelectedTabDetails();
    await this.setState({ multipleSelectionModal: false, currentPage: 1, statusfilter: false, status: null, selectedFilter: statusConstant.ACTIVE_STATUS });
  }

  handleCategoryDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);

    if (tempObj.value == 'All')
      await this.setState({ 'categorySelect': null, 'categoryName':  ''});
    else
      await this.setState({ 'categorySelect': tempObj.value, 'categoryName': tempObj.label });

    this.setSelectedTabDetails();
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter, attributeList, attributeObj, submitted, search, status, statusfilter } = this.state;
    return (
      <div className="main-content manage-page">
         {this.state.redirect === true ? (
          <Redirect push to={{ pathname: this.state.redirectUrl, searchInput: this.state.searchInput }}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={flour} alt="" className="page-icon" />
                  {ingredientConstant.MANAGE_INGREDIENT_PAGENAME}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search By Ingredient Code/Name/Strain/SKU"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? {cursor: 'default'} : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}
                  {isAuthorized("createIngredient") &&
                    <Nav pullRight>
                      <NavDropdown
                        title={<div className="filter"> <i title="Bulk Update" className="fa fa-pencil"  style={{color: '#212121', fontSize: '18px', cursor: 'pointer' }} />  </div>}
                        noCaret id=" bulk-update" className="filter-status bulk-update"
                        onSelect={this.handleMultipleSelection}>
                        <MenuItem eventKey={ingredientConstant.UPDATE_PRODUCT}>
                          Ingredient Update
                        </MenuItem>
                        <MenuItem eventKey={ingredientConstant.UPDATE_TIER}>
                          Tier Update
                        </MenuItem>
                      </NavDropdown>
                    </Nav>
                  }

                  <Nav pullRight>
                    <NavDropdown
                      title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status"
                      onSelect={this.handleFIlter}>
                      <MenuItem eventKey={statusConstant.ACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.ACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)}
                      </MenuItem>
                      <MenuItem eventKey={statusConstant.INACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.INACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.INACTIVE_STATUS)}
                      </MenuItem>
                    </NavDropdown>
                  </Nav>

                  {isAuthorized("createIngredient") &&
                    <Button id={"productId" + "_" + ingredientConstant.CREATE_INGREDIENT}
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                    </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {statusfilter || search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ? 
                            <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                          {statusfilter ? 
                            <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                      </div>
                    : null }

                    <Row>
                      <Col md={12}>
                        <FormGroup className="top-filter-section">
                          <div className="filter-title">Category: </div>
                          <div className="location-control">
                            {/* <ControlLabel>
                              Category
                            </ControlLabel> */}
                            <Select classNamePrefix="react-select"
                              name="categorySelect"
                              value={{ "label": this.state.categorySelect ? this.state.categoryName : 'All' }}
                              onChange={(value) => this.handleCategoryDropdownChange(value)}
                              options={this.props.dataDictionaryList != null &&
                                this.props.dataDictionaryList.length ?
                                [...this.state.allList, ...this.props.dataDictionaryList.filter((d) => d.dataType === 'categoryList')] : [...this.state.allList]}
                              placeholder="Select Category" />
                          </div>
                        </FormGroup>
                      </Col>
                    </Row>

                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}

                    {this.state.multipleSelectionModal == true ?
                      <MultipleSelectionModal
                        getProductSelectionDetails={this.getProductSelectionDetails}
                        updateType={this.state.updateType} 
                      >
                      </MultipleSelectionModal>
                    : null}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ingredientList: state.ingredient.ingredientList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    ingredientSearchList: state.ingredient.ingredientSearchList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
  };
}

const mapDispatchToProps = dispatch => ({
  getIngredientList: (id) => dispatch(getIngredientList(id)),
  setSelectedIngredientCode: (productId) => dispatch(setSelectedIngredientCode(productId)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  updateIngredientStatus: (obj, status) => dispatch(updateIngredientStatus(obj, status)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getIngredientSearchList: params => dispatch(getIngredientSearchList(params)),
  setSelectedCategoryCode: (selectedCategoryCode) => dispatch(setSelectedCategoryCode(selectedCategoryCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageIngredient);
