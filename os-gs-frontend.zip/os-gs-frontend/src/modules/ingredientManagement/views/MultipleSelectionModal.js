import React, { Component } from "react";
import * as _ from 'lodash';
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getProductList, getProductSearchList, setProductPrice } from '../../productManagement/actions/productActions';
import PaginationUtil from "../../common/util/paginationUtil";
import ValidationUtil from '../../common/util/validationUtil';
import PopularTableUtil from '../../common/util/popularTableUtil';
import Datetime from "react-datetime";
import moment from "moment";
import { getTierPricingDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as ingredientConstant from "../constant/ingredientConstant";
var Modal = require('react-bootstrap-modal')

class MultipleSelectionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataList: [],
      params: null,
      brand: '',
      brandName: '',
      categoryName: '',
      category: '',
      brandSearch: '',
      brandList: [],
      categoryList: [],
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      allList: [{ label: 'All', value: '' }],
      isAllChecked: false,
      customError: false,
      error: false,
      fromDate: '',
      toDate: '',
      autoSave: false,
      searchProducts: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    await this.setSelectedTabDetails();
  };

  setSelectedTabDetails = async (status) => {
    const managePageList = this.props.updateType == ingredientConstant.UPDATE_PRODUCT ? pagePropertyListConstant.MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST(this) : pagePropertyListConstant.MANAGE_MULTI_SELECTION_TIER_PRODUCTS_PAGE_LIST(this) ;
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const { search, brand, fromDate, toDate, category } = this.state;
    var additionalParams = {};
    additionalParams["isDropdown"] = true;
    additionalParams['isIngredient'] = true;
    additionalParams['isSellable'] = true;
    if(this.props.updateType == ingredientConstant.UPDATE_PRODUCT) {
      additionalParams["clientSource"] = 'taxes';
    }
    if(this.props.updateType == ingredientConstant.UPDATE_TIER) {
      await this.props.getTierPricingDetails();
      additionalParams["showPrice"] = true;
    }
    if(CommonUtil.isNotNull(category)) additionalParams["categoryId"] = category;
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    if(CommonUtil.isNotNull(brand)) additionalParams["brand"] = brand;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["fromDate"] = fromDate;
    if(CommonUtil.isNotNull(fromDate) && CommonUtil.isNotNull(toDate)) additionalParams["toDate"] = toDate;
    await this.setState({
      tableColumnList: [...managePageList.tableColumnList, ...managePageList.tierPriceColumns],
      tableConfig: managePageList.tableConfig,
      attributeObj: searchAttributeList.attributeObj,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      brandList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'brandList')],
      categoryList: [...CommonUtil.getDictionaryListByKey(this.props.dataDictionaryList, 'categoryList')],
    });
    await this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  makeCustomAPICall(tempParamas) {
    this.setState({isAllChecked: false});
    this.state.searchProducts && this.props.getProductList(tempParamas);
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList(this.props.productList);
    }
    if (this.props.productDetailList != null && prevProps.productDetailList != this.props.productDetailList) {
      let tempList = this.props.productDetailList;
      tempList.map((item) => {
        item.price = item.purchasePrice;
      })
      this.props.getProductSelectionDetails(tempList);
      this.setState({ openModal: false, submitted: true});
    }
    if (this.props.tierPricing != null && prevProps.tierPricing != this.props.tierPricing) {
      this.updateProductTierPriceList(this.props.tierPricing);
    }
  }

  formatTier = (tiers) => {
    let result = {}
    _.size(tiers) && tiers.forEach((item, index) => {
      const key = `tierId_${item.tierId}`;
      result[key] = tiers[index];
    });
    return result;
  }

  updateProductTierPriceList = (tierPrices) => {
    const attributeObjWithTier = _.map(this.state.tableDataList, obj => ({ ...obj, tierPrices: _.size(obj.tierPrices) ? obj.tierPrices: tierPrices }))
    this.setState({ tableDataList: [...attributeObjWithTier] });
    const managePageList = pagePropertyListConstant.MANAGE_MULTI_SELECTION_TIER_PRODUCTS_PAGE_LIST(this, this.props.tierPricing) ;
    this.setState({ tableColumnList: [...managePageList.tableColumnList, ...managePageList.tierPriceColumns] });
    const result = {};
    this.props.tierPricing && this.props.tierPricing.forEach((item, index) => {
      const key = `tierId_${item.tierId}`;
      result[key] = this.props.tierPricing[index];
    });
    let updatedTableDataList = _.map(this.state.tableDataList, t => ({ ...t, ...(_.size(t.tierPrices) ? this.formatTier(t.tierPrices) : result) }));
    this.setState({ tableDataList: updatedTableDataList });
  }

  updateProductDropDownList = async (productList) => {
    let list = productList;
    let parentProduct = list.filter(item => !item.parentProductId)
    if(parentProduct && parentProduct.length > 0) {
      await this.setState({ productId: parentProduct[0].productId, productName: parentProduct[0].productName })
    }
    list = await _.size(list) && list.sort((a,b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: list })
    if(this.props.updateType == ingredientConstant.UPDATE_TIER) {
      this.updateProductTierPriceList(this.props.tierPricing)
    }
  }

  closeModal = (event) => {
    this.props.getProductSelectionDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave = async (event) => {
    const { tableDataList } = this.state;
    let tempList = [], tempArrayList = _.clone(tableDataList);
    if(this.props.updateType == ingredientConstant.UPDATE_PRODUCT) {
      tempArrayList = tempArrayList && tempArrayList.map(item => {
        delete item.tierPrices
        return item;
      })
      tempList = tempArrayList && tempArrayList.filter((item) => item.isChecked == true).map((item) => {
        let temp = {
          productId : item.productId,
          productName : item.productName,
          salesPrice : Number(item.salesPrice) >= 0 ? Number(item.salesPrice) : null,
          purchasePrice: Number(item.purchasePrice) >= 0 ? Number(item.purchasePrice) : null,
        }
        return temp
      })
    }
    if(this.props.updateType == ingredientConstant.UPDATE_TIER) {
      tempArrayList = tempArrayList && tempArrayList.filter(item => item.tierPrices)

      tempList = tempArrayList && tempArrayList.filter((item) => item.isChecked == true).map((item) => {
        let temp = {
          productId : item.productId,
          productName : item.productName,
          salesPrice : Number(item.salesPrice) >= 0 ? Number(item.salesPrice) : null,
          purchasePrice: Number(item.purchasePrice) >= 0 ? Number(item.purchasePrice) : null,
          tierPrices: item.tierPrices
        }
        return temp
      })
    }
    if(tempList && tempList.length > 0) {
      if (this.isValidRequestObj(tempList)) {
          await this.props.setProductPrice(tempList)
          this.setState({ openModal: false, submitted: true, autoSave: false, alert: null });
          this.props.getProductSelectionDetails(false);
        }
    } else {
      this.setState({ openModal: false, submitted: true, autoSave: false, alert: null });
        this.props.getProductSelectionDetails(false);
    }
  }
  
  handlePopupContinue = async (event) => {
    const { tableDataList } = this.state;
    let tempList = [], tempArrayList = _.clone(tableDataList);
    if(this.props.updateType == ingredientConstant.UPDATE_PRODUCT) {
      tempArrayList = tempArrayList && tempArrayList.map(item => {
        delete item.tierPrices
        return item;
      })
      tempList = tempArrayList && tempArrayList.filter((item) => item.isChecked == true).map((item) => {
        let temp = {
          productId : item.productId,
          productName : item.productName,
          salesPrice : Number(item.salesPrice) >= 0 ? Number(item.salesPrice) : null,
          purchasePrice: Number(item.purchasePrice) >= 0 ? Number(item.purchasePrice) : null,
        }
        return temp
      })
    }
    if(this.props.updateType == ingredientConstant.UPDATE_TIER) {
      tempArrayList = tempArrayList && tempArrayList.filter(item => item.tierPrices)

      tempList = tempArrayList && tempArrayList.filter((item) => item.isChecked == true).map((item) => {
        let temp = {
          productId : item.productId,
          productName : item.productName,
          salesPrice : Number(item.salesPrice) >= 0 ? Number(item.salesPrice) : null,
          purchasePrice: Number(item.purchasePrice) >= 0 ? Number(item.purchasePrice) : null,
          tierPrices: item.tierPrices
        }
        return temp
      })
    }
    if(tempList && tempList.length > 0) {
      if (this.isValidRequestObj(tempList)) {
          await this.props.setProductPrice(tempList)
          this.setState({ submitted: false, autoSave: false, alert: null });
          await this.makeCustomAPICall(PaginationUtil.getPaginationParams(this.state.currentPage - 1, null, this, true))
        }
    } else {
      this.setState({ submitted: true, autoSave: false, alert: null });
    }
  }
  
  isValidRequestObj = (tempObj) => {
    const managePageList = this.props.updateType == ingredientConstant.UPDATE_PRODUCT ? pagePropertyListConstant.MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST(this) : pagePropertyListConstant.MANAGE_MULTI_SELECTION_TIER_PRODUCTS_PAGE_LIST(this) ;
    if (!ValidationUtil.validateArrayListRequestObj(tempObj,managePageList.tableColumnList)) {
      this.setState({ error: true });
      return false;
    } else {
      this.setState({ error: false });
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null, currentPage: this.state.pageNumber });
  }

  handlebrandDropdownChange = async (tempObj) => {
    await this.setState({
      brand: tempObj.value, brandName: tempObj.label, searchInput: ""
    });
  }

  handlecategoryDropdownChange = async (tempObj) => {
    await this.setState({
      category: tempObj.value, categoryName: tempObj.label,
    });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      // this.globalSearch();
    });
  }

  globalSearch = async () => {
    let { searchInput } = this.state;
    let list = this.props.productList
    list = await _.size(list) && list.sort((a, b) => (a.productId > b.productId) ? 1 : ((b.productId > a.productId) ? -1 : 0))
    let filteredData = _.size(list) && list.filter((value) => {
      return (
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productName.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.productSKU.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    const attributeObjWithTier = _.map(filteredData, obj => ({ ...obj, tierPrices: _.size(obj.tierPrices) ? obj.tierPrices: this.props.tierPricing }))
    this.setState({ tableDataList: [...attributeObjWithTier] });
    const result = {};
    this.props.tierPricing && this.props.tierPricing.forEach((item, index) => {
      const key = `tierId_${item.tierId}`;
      result[key] = this.props.tierPricing[index];
    });
    let updatedTableDataList = _.map(filteredData, t => ({ ...t, ...(_.size(t.tierPrices) ? this.formatTier(t.tierPrices) : result) }));
    await this.setState({ tableDataList: [] });
    await this.setState({ tableDataList: updatedTableDataList });
  };


  advanceSearch = async () => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ search: this.state.searchInput.trim(), searchProducts: true  });
    this.setSelectedTabDetails();
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleRemoveFilter = async (event) => {
    this.setState({ search: null, searchInput: "", brand: null, brandName: "", category: null, categoryName: "", fromDate : "", toDate: "", searchProducts: false, tableDataList: [] });
  }

  handleCheckBoxChange = async (event) => {
    const { id, checked } = event.target;
    var tempId = id.split("_");
    const { tableDataList} = this.state;
    tableDataList.map((item) => {
      if(item.productId == tempId[0]) {
        item.isChecked = checked;
      }
    })
    await this.setState({
      tableDataList: tableDataList
    })
  }

  handleAllCheckboxChange = async (event) => {
    const { checked } = event.target;
    const { tableDataList} = this.state;
    tableDataList.map((item, index) => {
      item.isChecked = checked;
    })
    await this.setState({
      isAllChecked : checked,
      tableDataList: tableDataList
    })
  }

  copyTierPrice = async (value) => {
    const { tableDataList } = this.state;
    if(value){
      let tierPrices = value.tierPrices;
      let tempList = tableDataList.map(item => {
        if(item.isChecked) {
          let tempPrices = item.tierPrices.map(x => {
            tierPrices.map(y => {
              if(x.tierId == y.tierId) {
                x.adjustmentType = y.adjustmentType;
                x.productId = item.productId;
                x.percentage = y.percentage;
                x.tierName = y.tierName;
                x.tierValue = y.tierValue;
              }
            })
            return x
          })
          item.tierPrices = tempPrices 
        }
        return { ...item, ...this.formatTier(item.tierPrices) };
      })
      await this.setState({ tableDataList: tempList, autoSave: true })
    }
  }

  copyPrice = async (value) => {
    const { tableDataList } = this.state;
    if(value) {
      let salesPrice = value.salesPrice;
      let purchasePrice = value.purchasePrice;
      let tempList = tableDataList.map(item => {
        if(item.isChecked) {
          item.salesPrice = salesPrice;
          item.purchasePrice = purchasePrice;
        }
        return item;
      })
      await this.setState({ tableDataList: tempList, autoSave: true })
    }
  }

  handleTierValueChange = (e, value, selectedTier) => {
    const updatedTableDataList = this.state.tableDataList.map(product => {
      if (product.productId === value.productId) {
        const updatedTierPrices = product.tierPrices.map(tier => {
          const id = _.split(selectedTier, '_')[1]
          if (tier.tierId === Number(id)) {
            tier.tierValue = e.target.value
          }
          return tier;
        });
        return { ...product, tierPrices: updatedTierPrices };
      }
      return product;
    });
    this.setState({ tableDataList: updatedTableDataList, autoSave: true });
  };

  handleTierAdjustmentTypeChange = (e, value, selectedTier) => {
    const updatedTableDataList = this.state.tableDataList.map(product => {
      if (product.productId === value.productId) {
        const updatedTierPrices = product.tierPrices.map(tier => {
          const id = _.split(selectedTier, '_')[1]
          if (tier.tierId === Number(id)) {
            if(e.value === "Global"){
              tier.tierValue = tier.percentage 
            }
            tier.adjustmentType = e.value
          }
          return tier;
        });
        return { ...product, tierPrices: updatedTierPrices };
      }
      return product;
    });
    this.setState({ tableDataList: updatedTableDataList, autoSave: true });
  };


  handleTableTextBoxChange = (event) => {
    this.setState({ autoSave: true })
    PopularTableUtil.handleTableTextBoxChange(event, this, "tableDataList");
  }

  handleDateChange(event, eventId) {
    var name = eventId.split('_')[0];
    this.setState({
      [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '',
      autoSave: true
    })
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, error, customError, brand, category, fromDate, toDate, searchProducts} = this.state;
    const { showVariant } = this.props;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal className={this.props.updateType == ingredientConstant.UPDATE_TIER ? "productModal" : ""} show={this.state.openModal}
          onHide={this.closeModal} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          {this.state.alert}
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                {showVariant ? <div className="model-heading">Variations | PRO-{this.state.productId} | {this.state.productName}</div> :
                <div className="model-heading">{this.props.updateType == ingredientConstant.UPDATE_PRODUCT ? "Edit Bulk Ingredient" : "Tier Update" }</div>}
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            {!showVariant && <Row className="header-section" style={{marginBottom: '30px'}}>
                              <Col md={12}>
                                <Row>
                                  <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="category"
                                      onChange={(value) => this.handlecategoryDropdownChange(value)}
                                      value={{ "label": this.state.categoryName ? this.state.categoryName : 'Select Category' }}
                                      options={[...this.state.allList, ...this.state.categoryList]}
                                      placeholder="Select Category"
                                    />
                                  </Col>
                                  <Col md={3}>
                                    <Select
                                      classNamePrefix="react-select"
                                      name="brand"
                                      onChange={(value) => this.handlebrandDropdownChange(value)}
                                      value={{ "label": this.state.brandName ? this.state.brandName : 'Select Brand' }}
                                      options={[...this.state.allList, ...this.state.brandList]}
                                      placeholder="Select Brand"
                                    />
                                  </Col>
                                  <Col md={6}>
                                    <div className="right-section multi-selection ">
                                      <div className="search-section advance" style={{width: '100%'}}>
                                        <form onSubmit={this.handleSubmit}>
                                        <i className="fa fa-search"></i>
                                        <FormControl type="text" name="searchInput" placeholder="Search by Ingredient Code/Name/SKU"
                                          value={this.state.searchInput} onChange={this.handleChange} />
                                        </form>
                                      </div>
                                    </div>
                                  </Col>
                                </Row>
                                <Row style={{marginTop: "20px", display: 'flex', alignItems: 'center'}}>
                                  <Col md={4}>
                                    <Datetime
                                      id="fromDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                          readOnly: true,
                                          placeholder: "From Date",
                                          disabled: false,
                                          title: CommonUtil.getFormattedDate(this.state.fromDate)
                                      }}
                                      name="fromDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'fromDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.fromDate)}
                                    />
                                  </Col>
                                  <Col md={4}>
                                    <Datetime
                                      id="toDate"
                                      timeFormat={false}
                                      closeOnSelect={true}
                                      isValidDate={''}
                                      inputProps={{
                                          readOnly: true,
                                          placeholder: "To Date",
                                          disabled: false,
                                          title: CommonUtil.getFormattedDate(this.state.toDate)
                                      }}
                                      name="toDate"
                                      onChange={(moment) => this.handleDateChange(moment, 'toDate')}
                                      dateFormat="MM-DD-YYYY"
                                      value={moment(this.state.toDate)}
                                    />
                                  </Col>
                                  <Col md={6} style={{ display: 'flex'}}><Button className="btn-save btn-fill" onClick={this.advanceSearch} style={{marginLeft : 0}}>Search</Button>
                                  {searchProducts ? <Button className="btn-cancel" onClick={this.handleRemoveFilter}>Reset</Button> : null}
                                  </Col>
                                </Row>
                              </Col>
                            </Row>}
                            {customError && <Row><Col md={12}><p className="text-danger">Product limit of 500 has reached in the order.</p></Col></Row>}
                            {tableColumnList != null ? (
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table
                                    className={this.props.updateType == ingredientConstant.UPDATE_TIER ? 'productTable' : 'table-box-height'}
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                    showCheck={true}
                                  />
                                ) : null}
                              </Row>
                            ) : null}
                            {error && <p className="text-danger">Please fill missing fields.</p>}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            <div>
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                              <Button className="btn-save btn-fill" onClick={this.handleSave}>Update Ingredients</Button>
                            </div>
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    productList: state.product.productList,
    productDetailList: state.product.productDetailList,
    tierPricing: state.dataDictionary.tierPricing,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getProductList: (id) => dispatch(getProductList(id)),
  setProductPrice: (id) => dispatch(setProductPrice(id)),
  getProductSearchList: params => dispatch(getProductSearchList(params)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
});
export default connect(mapStateToProps, mapDispatchToProps)(MultipleSelectionModal);
