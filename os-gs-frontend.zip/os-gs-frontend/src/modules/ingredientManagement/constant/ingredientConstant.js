export const CREATE_INGREDIENT_HEADER_TITLE = "Create Ingredient";
export const EDIT_INGREDIENT_HEADER_TITLE = "Edit Ingredient";
export const VIEW_INGREDIENT_HEADER_TITLE = "View Ingredient";
export const MANAGE_INGREDIENT_PAGENAME = "Ingredients";
export const MODULE_NAME = "ingredient";

export const CREATE_INGREDIENT = "createIngredient";
export const DEATIVATE_INGREDIENT = "deactivateIngredient";
export const DELETE_INGREDIENT = "deleteIngredient";
export const ACTIVATE_INGREDIENT = "activateIngredient";
export const UPDATE_PRODUCT = "updateProduct";
export const UPDATE_TIER = "updateTier";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_INGREDIENT_LIST_URL = `${BASE_URL}/products`;
export const SET_UPDATE_INGREDIENT_STATUS_URL = `${BASE_URL}/products/`;
export const SET_UPDATE_INGREDIENT_DETAILS_URL = `${BASE_URL}/products/v1/`;
export const GET_INGREDIENT_DETAILS_URL = `${BASE_URL}/products/`;
export const SET_CREATE_INGREDIENT_DETAILS_URL = `${BASE_URL}/products/v1/`;
export const SET_CREATE_BULK_INGREDIENT_URL = `${BASE_URL}/productsbulkupload/v1/?isIngredient=true`;
export const GET_INGREDIENT_DETAILS_LIST = `${BASE_URL}/products/multi`;

export const MANAGE_INGREDIENT_PAGE_URL = '/admin/manage-ingredient';
export const CREATE_INGREDIENT_PAGE_URL = '/admin/create-ingredient';
export const GET_INGREDIENT_SEARCH_URL = BASE_URL + '/products';
export const GET_SKU_DETAILS_URL = BASE_URL + '/products/generate/sku';

export const CREATE_INGREDIENT_USAGE_PACKSIZE = "packsize";
export const CREATE_INGREDIENT_USAGE_VOLUME = "volume";