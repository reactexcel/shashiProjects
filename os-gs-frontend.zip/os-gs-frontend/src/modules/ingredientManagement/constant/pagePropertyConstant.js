import * as ingredientConstant from "./ingredientConstant";
import React from "react";
import { Nav, NavDropdown, MenuItem, FormControl, InputGroup, FormGroup, Col, Row } from "react-bootstrap";
import Button from "components/CustomButton/CustomButton.jsx";
import * as statusConstant from "../../common/constant/statusConstant";
import * as commonConstant from "../../common/constant/commonConstant";
import isAuthorized from "auth-plugin";
import StatusUtil from "../../common/util/statusUtil";
import CommonUtil from "../../common/util/commonUtil";
import DownloadSKUBarCode from "../../CreateQRCode/views/DownloadSKUBarCode";
import CustomCheckbox from "../../../components/CustomCheckbox/CustomCheckbox";
import currencyIcon from "../../common/util/currencyIcon";
import Select from "react-select";
import _ from 'lodash';

const adjustmentType = [
  {
    label: 'Global',
    value: 'Global',
  },
  {
    label: 'Fixed Price',
    value: 'Fixed Price',
  },
  {
    label: 'Custom',
    value: 'Custom',
  }
]

export const CREATE_INGREDIENT_PAGE_LIST = (that, tierPrices) => {
  const tierPriceAttributeList = [
    {
      name: "tierId",
      type: "DROPDOWN",
      label: "Customer Tier",
      required: false,
      fieldWidth: 2,
      fieldWidthSmall: 4,
      createMode: "disabled",
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "categoryList",
      options: _.map(_.get(that, 'props.attributeObj.tierPrices', tierPrices || []), tier => ({ label: tier.tierName, value: tier.tierId })),
    },
    {
      name: "adjustmentType",
      type: "DROPDOWN",
      label: "Adjustment Type",
      required: false,
      fieldWidth: 2,
      fieldWidthSmall: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      supplierfields: false,
      buyShowFlag: true,
      makeShowFlag: true,
      kittingShowFlag: true,
      placeholder: "Select",
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "categoryList",
      options: adjustmentType,
    },
    {
      name: "tierValue",
      type: "TEXTBOX",
      label: "Value",
      required: true,
      fieldWidth: 3,
      inputType: "number",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
    },
  ]
  return {
    attributeObj: {
      productId: "",
      productName: "",
      productGTIN: "",
      productUOM: "",
      productSKU: "",
      category: "",
      subcategory: "",
      status: statusConstant.ACTIVE_STATUS,
      brand: "",
      usgType: "packsize",
      usgPackSizeQty: null,
      usgUOM: null,
      usgCostPerUnit: null,
      usgVolume: null,
      usgVolumeUnit: null,
      isSellable: false,
      isIngredient: true,
      source: "buy",
      volume: null,
      volumeUnit: null,
      packSizeQty: null,
    },
    attributeList: [
      {
        name: "productId",
        type: "UNIQUE_CODE",
        label: "Ingredient Code",
        prefix: "ING",
        required: false,
        fieldWidth: 4,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        createModeRemoveFlag: true,
        cloneModeRemoveFlag: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "productName",
        type: "TEXTBOX",
        label: "Ingredient Name",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        maxLength: 55,
        minLength: 3,
        customMessage: "Ingredient Name already exist.",
      },
      {
        name: "strainName",
        type: "DROPDOWN",
        label: "Strain Name",
        required: false,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        placeholder: "Select",
        dataDictionaryFlag: true,
        dataDictionaryId: "strainNameIngredient",
        options: [],
       },
      {
        name: "category",
        type: "DROPDOWN",
        label: "Category",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        placeholder: "Select",
        mandatoryMsgText: "Field can not be empty.",
        dataDictionaryFlag: true,
        dataDictionaryId: "categoryList",
        options: [],
      },
      {
        name: "subcategory",
        type: "DROPDOWN",
        label: "Sub Category",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        placeholder: "Select",
        mandatoryMsgText: "Field can not be empty.",
        dataDictionaryFlag: true,
        dataDictionaryId: "subcategoryList",
        options: [],
      },
      {
        name: "brand",
        type: "DROPDOWN",
        label: "Brand",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        placeholder: "Select",
        mandatoryMsgText: "Field can not be empty.",
        dataDictionaryFlag: true,
        dataDictionaryId: "brandList",
        options: [],
      },
      // {
      //   name: "familyId",
      //   type: "DROPDOWN",
      //   label: "Family",
      //   required: true,
      //   fieldWidth: 4,
      //   createMode: "enable",
      //   editMode: "enable",
      //   viewMode: "disabled",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   placeholder: "Select",
      //   mandatoryMsgText: "Field can not be empty.",
      //   MsgText: "View all ingredients for selected family",
      //   MsgTextHref: "#",
      //   linkOnClickFun: that.handleLinkClick,
      //   dataDictionaryFlag: true,
      //   dataDictionaryId: "familyList",
      //   options: [],
      // },
      {
        name: "productUOM",
        type: "DROPDOWN",
        label: "UOM",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        placeholder: "Select",
        mandatoryMsgText: "Field can not be empty.",
        dataDictionaryFlag: true,
        dataDictionaryId: "unitofMesurementList",
        options: [],
      },
      {
        name: "productGTIN",
        type: "TEXTBOX",
        label: "GTIN",
        required: false,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        maxLength: 25,
        minLength: 3,
      },
      {
        name: "productSKU",
        type: "TEXTBOX",
        label: "SKU/GTIN",
        required: true,
        fieldWidth: 4,
        createMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        maxLength: 25,
        minLength: 3,
        errorType: "sku",
        MsgText: "Generate SKU",
        MsgTextHref: "#",
        linkOnClickFun: that.generateSKUClick,
      },
      {
        name: "purchasePrice",
        type: "TEXTBOX",
        label: "Cost",
        required: true,
        allowCopyPaste: true,
        fieldWidth: 4,
        customAttribute: true,
        inputType: "number",
        showCurrency: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        supplierfields: true,
        showField: true,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        maxLength: 10,
        minLength: 1,
        tooltipText:
          "Please select a default supplier to enter the purchase price.",
        },
      {
        name: "salesPrice",
        type: "TEXTBOX",
        label: "Sales Price",
        allowCopyPaste: true,
        required: false,
        fieldWidth: 4,
        inputType: "number",
        showCurrency: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        supplierfields: true,
        showField: true,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        maxLength: 10,
        minLength: 1,
      },
      {
        name: "taxes",
        type: "TEXTBOX",
        label: "Taxes",
        required: false,
        fieldWidth: 3,
        fieldWidthSmall: 4,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: false,
        viewModeShowFlag: false,
        supplierfields: true,
        showField: true,
        buyShowFlag: true,
        makeShowFlag: true,
        kittingShowFlag: true,
        numberOfRow: 0,
      },
      // {
      //   name: "usgType",
      //   type: "CUSTOM_RADIO",
      //   checkList: [
      //       {
      //           name: 'packSize',
      //           label: 'Pack Size',
      //           value: 'packsize'
      //       },
      //       {
      //           name: 'volume',
      //           label: 'Volume',
      //           value: 'volume'
      //       }
      //   ],
      //   label: "Usage",
      //   required: true,
      //   fieldWidth: 12,
      //   fieldWidthSmall: 12,
      //   createMode: 'enable',
      //   cloneMode: 'enable',
      //   editMode: 'enable',
      //   viewMode: 'disabled',
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   supplierfields: false,
      //   packSizeShowFlag: true,
      //   volumeShowFlag: true,
      //   numberOfRow: 1,
      //   mandatoryMsgText: "Field can not be empty."
      // },
      // {
      //   name: "hsnCode",
      //   type: "TEXTBOX",
      //   label: "HSN Code",
      //   required: true,
      //   fieldWidth: 3,
      //   createMode: 'enable',
      //   cloneMode: 'enable',
      //   editMode: 'enable',
      //   viewMode: 'disabled',
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   supplierfields: false,
      //   buyShowFlag: true,
      //   makeShowFlag: true,
      //   kittingShowFlag: true,
      //   numberOfRow: 0,
      //   mandatoryMsgText: "Field can not be empty.",
      //   maxLength: 10,
      //   minLength: 3,
      // },
      // {
      //   name: "upcNumber",
      //   type: "TEXTBOX",
      //   label: "UPC Number",
      //   required: false,
      //   fieldWidth: 3,
      //   createMode: 'enable',
      //   cloneMode: 'enable',
      //   editMode: 'enable',
      //   viewMode: 'disabled',
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      //   supplierfields: false,
      //   buyShowFlag: true,
      //   makeShowFlag: true,
      //   kittingShowFlag: true,
      //   numberOfRow: 0,
      //   mandatoryMsgText: "Field can not be empty.",
      //   maxLength: 10,
      //   minLength: 3,
      // },
      {
        name: "isSellable",
        type: "CHECKBOX",
        label: "Is Sellable",
        required: false,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        supplierfields: false,
        fieldWidth: 4,
        customAttribute: true,
      },
      {
        name: "isIngredient",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        name: "source",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
      },
      {
        id: "volumeUnit",
        name: "volumeUnit",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "volume",
        name: "volume",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        id: "packSizeQty",
        name: "packSizeQty",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      // {
      //   name: "supplierId",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      // },
      {
        name: "status",
        type: "TEMP",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
      },
      {
        name: "version",
        type: "TEMP",
        createModeShowFlag: false,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
      },
      // {
      //   name: "usgPackSizeQty",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      // },
      // {
      //   name: "usgUOM",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      // },
      // {
      //   name: "usgCostPerUnit",
      //   type: "TEMP",
      //   createModeShowFlag: true,
      //   cloneModeShowFlag: true,
      //   editModeShowFlag: true,
      //   viewModeShowFlag: true,
      // },
    ],
    tierPriceAttributeList: tierPriceAttributeList,
    // usageAttributeList: [
    //   {
    //     name: "usgPackSizeQty",
    //     type: "TEXTBOX",
    //     label: "Pack Size Qty",
    //     customAttribute: true,
    //     inputType: "number",
    //     numberType: "fixed",
    //     showCurrency: false,
    //     required: true,
    //     fieldWidth: 4,
    //     createMode: "enable",
    //     cloneMode: "enable",
    //     editMode: "enable",
    //     viewMode: "disabled",
    //     createModeShowFlag: true,
    //     cloneModeShowFlag: true,
    //     editModeShowFlag: true,
    //     viewModeShowFlag: true,
    //     supplierfields: false,
    //     showField: false,
    //     packSizeShowFlag: false,
    //     volumeShowFlag: false,
    //     numberOfRow: 0,
    //     mandatoryMsgText: "Field can not be empty.",
    //     maxLength: 10,
    //     minLength: 1,
    //   },
    //   {
    //     name: "usgUOM",
    //     type: "DROPDOWN",
    //     label: "Unit",
    //     required: true,
    //     fieldWidth: 4,
    //     createMode: "enable",
    //     cloneMode: "enable",
    //     editMode: "enable",
    //     viewMode: "disabled",
    //     createModeShowFlag: true,
    //     cloneModeShowFlag: true,
    //     editModeShowFlag: true,
    //     viewModeShowFlag: true,
    //     supplierfields: false,
    //     packSizeShowFlag: false,
    //     volumeShowFlag: false,
    //     placeholder: "Select",
    //     mandatoryMsgText: "Field can not be empty.",
    //     dataDictionaryFlag: true,
    //     dataDictionaryId: "unitofMesurementList",
    //     options: [],
    //   },
    //   {
    //     name: "usgCostPerUnit",
    //     type: "TEXTBOX",
    //     label: "Cost Per Unit",
    //     inputType: "number",
    //     showCurrency: true,
    //     required: true,
    //     fieldWidth: 4,
    //     createMode: "disabled",
    //     cloneMode: "disabled",
    //     editMode: "disabled",
    //     viewMode: "disabled",
    //     createModeShowFlag: true,
    //     cloneModeShowFlag: true,
    //     editModeShowFlag: true,
    //     viewModeShowFlag: true,
    //     supplierfields: false,
    //     packSizeShowFlag: false,
    //     volumeShowFlag: false,
    //     numberOfRow: 0,
    //     maxLength: 10,
    //     minLength: 1,
    //     mandatoryMsgText: "Field can not be empty.",
    //   },
    // ],
  };
};

export const MANAGE_INGREDIENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Ingredient Code",
        id: "productId",
        accessor: "productId",
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return <>ING-{value}</>;
        },
      },
      {
        Header: "Ingredient Name",
        id: "productName",
        accessor: "productName",
      },
      {
        Header: "Strain name",
        id: "strainName",
        accessor: "strainName",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>
              {CommonUtil.getSelectedOptionNameFromCode(
                that.props.dataDictionaryList,
                original.strainName
              )}
            </>
          );
        },
      },
      {
        Header: "SKU",
        id: "productSKU",
        accessor: "productSKU",
        style: {
          flex: "0 0 120px",
        },
      },
      {
        Header: "Category",
        id: "category",
        accessor: "category",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>
              {CommonUtil.getSelectedOptionNameFromCode(
                that.props.dataDictionaryList,
                original.category
              )}
            </>
          );
        },
      },
      {
        Header: "Brand",
        id: "brand",
        accessor: "brand",
        style: {
          flex: "0 0 120px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <>
              {CommonUtil.getSelectedOptionNameFromCode(
                that.props.dataDictionaryList,
                original.brand
              )}
            </>
          );
        },
      },
      // {
      //   Header: "Status",
      //   id: "status",
      //   accessor: "status",
      //   style: {
      //     flex: "0 0 120px",
      //   },
      //   disableSortBy: true,
      //   id: "status",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     return (
      //       <div
      //         className="full-td"
      //         style={{
      //           backgroundColor: value
      //             ? StatusUtil.getStatusColor(statusConstant.ACTIVE_STATUS)
      //             : StatusUtil.getStatusColor(statusConstant.INACTIVE_STATUS),
      //         }}
      //       >
      //         {value
      //           ? StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)
      //           : StatusUtil.getStatusLabel(statusConstant.INACTIVE_STATUS)}
      //       </div>
      //     );
      //   },
      // },
      {
        Header: "Actions",
        id: "actions",
        accessor: "action",
        style: {
          flex: "0 0 110px",
        },
        className: "action",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              {isAuthorized("deactivateIngredient") && (
                <Nav pullRight>
                  <NavDropdown
                    id={
                      original.productId +
                      "_" +
                      commonConstant.MENU_ACTION_MODE
                    }
                    title={
                      <i
                        className="fa fa-ellipsis-v"
                        id={
                          original.productId +
                          "_" +
                          commonConstant.MENU_ACTION_MODE
                        }
                        onClick={(e) => that.getTdProps(e)}
                      />
                    }
                    noCaret
                  >
                    {!original.status ? (
                      <MenuItem
                        id={
                          original.productId +
                          "_" +
                          commonConstant.MENU_ACTION_MODE +
                          "_" +
                          ingredientConstant.ACTIVATE_INGREDIENT
                        }
                        onClick={(e) => that.getTdProps(e)}
                      >
                        Activate
                      </MenuItem>
                    ) : (
                      <MenuItem
                        id={
                          original.productId +
                          "_" +
                          commonConstant.MENU_ACTION_MODE +
                          "_" +
                          ingredientConstant.DEATIVATE_INGREDIENT
                        }
                        onClick={(e) => that.getTdProps(e)}
                      >
                        Deactivate
                      </MenuItem>
                    )}
                    {
                      isAuthorized("ingredient") &&
                      original.status && CommonUtil.isNotNull(original.productSKU) && (
                        <>
                          <DownloadSKUBarCode
                            SKUNumber={original.productSKU}
                          />
                          <MenuItem
                            id={
                              original.productId + "_" + original.productSKU
                            }
                            onClick={(e) => that.generateBarCode(e)}
                          >
                            Generate Barcode
                          </MenuItem>
                        </>
                      )}
                  </NavDropdown>
                </Nav>
              )}
              <Button bsStyle="default" simple icon>
                {original.status && isAuthorized("editIngredient") ? (
                  <div className="circle">
                    <i
                      title="edit"
                      id={
                        original.productId +
                        "_" +
                        commonConstant.EDIT_ACTION_MODE +
                        "_" +
                        index +
                        "_" +
                        original.category
                      }
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                ) : null}

                {original.status && isAuthorized("cloneIngredient") ? (
                  <div className="circle">
                    <i
                      title="clone"
                      id={
                        original.productId +
                        "_" +
                        commonConstant.CLONE_ACTION_MODE +
                        "_" +
                        index +
                        "_" +
                        original.category
                      }
                      className="fa fa-copy"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                ) : null}

                {isAuthorized("viewIngredient") ? (
                  <div className="circle">
                    <i
                      title="view"
                      id={
                        original.productId +
                        "_" +
                        commonConstant.VIEW_ACTION_MODE +
                        "_" +
                        index +
                        "_" +
                        original.category
                      }
                      className="fa fa-eye"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                ) : null}
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: "",
        },
      ],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: "",
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Ingredient Code/Name",
      },
    ],
  };
};

export const MANAGE_MULTI_SELECTION_PRODUCTS_PAGE_LIST = (that) => {
  const actionColumn =  {
    Header: "Actions",
    id: "actions",
    accessor: "actions",
    className: "action justify-content-center",
    style: {
      flex: "0 0 60px",
    },
    disableSortBy: true,
    disableFilters: true,
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    Cell: ({ cell }) => {
      const { value } = cell;
      const { index, original } = cell.row;
      const { tableDataList } = that.state
      const firstChecked = tableDataList && tableDataList.find(item => item.isChecked);
      return (
        <div
          className={
            CommonUtil.isViewMode(that.props.actionMode) ||
              !isAuthorized("changeProductStatus")
              ? "actions-left disabled"
              : "actions-left"
          }
        >
          {(firstChecked && original && original.productId === firstChecked.productId) ?
            <Button bsStyle="default" simple icon>
                <div className="circle">
                  <i
                    title="clone"
                    id={"copy" + "_" + index}
                    className="fa fa-copy"
                    onClick={(e) => that.copyPrice(e)}
                  />
                </div>
            </Button>
          : null}
        </div>
      );
    },
  };

  return {
    tableColumnList: [
      {
        Header: "",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeRemoveFlag: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox
                inline
                number={
                  original.productId +
                  "_" +
                  commonConstant.CREATE_ACTION_MODE +
                  "_" +
                  index
                }
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)}
              />
            </div>
          );
        },
      },
      {
        Header: "Ingredient Code",
        id: "productId",
        accessor: "productId",
        name: "productId",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 130px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return <>ING-{value}</>;
        },
      },
      {
        Header: "Ingredient Name",
        id: "productName",
        accessor: "productName",
        name: "productName",
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"productName" + "_" + index}
                name={"productName"}
                min={0}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                onKeyUp={(e) => {CommonUtil.maxLengthCheck(e, 100)}}
                onKeyDown={(e) => {CommonUtil.maxLengthCheck(e, 100)}}
                maxLength={100}
                minLength={3}
              />
            </InputGroup>
          );
        },
      },
      {
        Header: "Cost Price",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        style: {
          flex: "0 0 100px",
        },
        type: "text",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        inputType: "number",
        submitted: that.state.submitted,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          console.log('cost', value)
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"purchasePrice" + "_" + index}
                data-type={"number"}
                name={"purchasePrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
            </InputGroup>
          );
        },
      },
      {
        Header: "Sale Price",
        id: "salesPrice",
        accessor: "salesPrice",
        name: "salesPrice",
        style: {
          flex: "0 0 100px",
        },
        type: "text",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        inputType: "number",
        submitted: that.state.submitted,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={
                that.state.submitted &&
                  !CommonUtil.isNotNull(value) &&
                  original.isChecked
                  ? "required-error"
                  : ""
              }
              style={{
                border: original.isChecked ? "1px solid #70707080" : "none",
              }}
            >
              <FormControl
                id={"salesPrice" + "_" + index}
                data-type={"number"}
                name={"salesPrice"}
                onChange={that.handleTableTextBoxChange}
                disabled={!original.isChecked ? true : false}
                value={value}
                className="center-align"
                onKeyUp={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                onKeyDown={(e) => {
                  CommonUtil.maxLengthCheck(e, 10);
                }}
                maxLength={10}
                minLength={1}
              />
            </InputGroup>
          );
        },
      },
    ],
    tierPriceColumns: [actionColumn],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};
export const MANAGE_MULTI_SELECTION_TIER_PRODUCTS_PAGE_LIST = (that, tierPrices) => {
  const tierPriceColumns = _.map(tierPrices, tier => {
    return {
      Header: tier.tierName,
      id: `tierId_${tier.tierId}`,
      accessor: `tierId_${tier.tierId}`,
      name: `tierId_${tier.tierId}`,
      style: {
        flex: "0 0 190px",
      },
      type: "text",
      required: true,
      inputType: "number",
      submitted: that.state.submitted,
      className: "input-field",
      disableSortBy: true,
      disableFilters: true,
      Cell: ({ cell }) => {
        const { value } = cell;
        const { index, original } = cell.row;
        const adjustmentTypeValue = CommonUtil.getSelectedOptionLabel(adjustmentType, (_.get(original, `tierId_${tier.tierId}.adjustmentType`) ? _.get(original, `tierId_${tier.tierId}.adjustmentType`) : 'Global'));
        return (
          <Row style={{
            display: 'flex',
            position: 'relative',
            margin: '0px',
            width: '100%'
          }}>
            <Row style={{ width: 'calc(100% - 120px)', margin: '0px' }}>
              <InputGroup
                className={
                  that.state.submitted &&
                    !CommonUtil.isNotNull(_.get(value, 'percentage')) &&
                    original.isChecked
                    ? "required-error"
                    : ""
                }
                style={{
                  border: (original.isChecked && adjustmentTypeValue.label !== 'Global') ? "1px solid #70707080" : "none",
                }}
              >
                <FormControl
                  id={"tierPrice" + "_" + index}
                  data-type={"number"}
                  name={`tierId_${tier.tierId}`}
                  onChange={(e) => that.handleTierValueChange(e, original, `tierId_${tier.tierId}`)}
                  disabled={(!original.isChecked || adjustmentTypeValue.label === 'Global') ? true : false}
                  value={_.get(original, `tierId_${tier.tierId}.tierValue`) !== null ? _.get(original, `tierId_${tier.tierId}.tierValue`) : _.get(value, 'percentage')}
                  className="center-align"
                  onKeyUp={(e) => {
                    CommonUtil.maxLengthCheck(e, 10);
                  }}
                  onKeyDown={(e) => {
                    CommonUtil.maxLengthCheck(e, 10);
                  }}
                  maxLength={10}
                  minLength={1}
                />

              </InputGroup>
            </Row>
            <Row style={{
              width: `120px`,
              margin: `0px`,
            }}>
              <FormGroup style={{marginBottom: '0'}}>
                <Select
                  name={`tierId_${tier.tierId}.adjustmentType`}
                  onChange={(e) => that.handleTierAdjustmentTypeChange(e, original, `tierId_${tier.tierId}`)}
                  value={adjustmentTypeValue}
                  id={'_id'}
                  isDisabled={!original.isChecked ? true : false}
                  options={adjustmentType} 
                />

              </FormGroup>
            </Row>
          </Row>
        );
      },
    }
  });

  const actionColumn =  {
    Header: "Actions",
    id: "actions",
    accessor: "actions",
    className: "action justify-content-center",
    style: {
      flex: "0 0 60px",
    },
    disableSortBy: true,
    disableFilters: true,
    createModeShowFlag: true,
    cloneModeShowFlag: true,
    editModeShowFlag: true,
    viewModeShowFlag: true,
    Cell: ({ cell }) => {
      const { value } = cell;
      const { index, original } = cell.row;
      const { tableDataList } = that.state
      const firstChecked = tableDataList && tableDataList.find(item => item.isChecked);
      return (
        <div
          className={
            CommonUtil.isViewMode(that.props.actionMode) ||
              !isAuthorized("changeProductStatus")
              ? "actions-left disabled"
              : "actions-left"
          }
        >
          {(firstChecked && original && original.productId === firstChecked.productId) ?
            <Button bsStyle="default" simple icon>
              <div className="circle">
                <i
                  title="clone"
                  id={"copy" + "_" + index}
                  className="fa fa-copy"
                  onClick={(e) => that.copyTierPrice(e)}
                />
              </div>
            </Button>
          : null}
        </div>
      );
    },
  };

  return {
    tableColumnList: [
      {
        Header: "",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 60px",
        },
        required: false,
        disableSortBy: true,
        disableFilters: true,
        createModeRemoveFlag: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <CustomCheckbox
                inline
                number={
                  original.productId +
                  "_" +
                  commonConstant.CREATE_ACTION_MODE +
                  "_" +
                  index
                }
                checked={original.isChecked}
                onClick={(e) => that.handleCheckBoxChange(e, that)}
              />
            </div>
          );
        },
      },
      {
        Header: "Ingredient Code",
        id: "productId",
        accessor: "productId",
        name: "productId",
        disableSortBy: true,
        disableFilters: true,
        required: true,
        style: {
          flex: "0 0 110px",
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return <>ING-{value}</>;
        },
      },
      {
        Header: "Ingredient Name",
        id: "productName",
        accessor: "productName",
        name: "productName",
        required: false,
        style: {
          flex: "0 0 200px",
        },
        disableSortBy: true,
        disableFilters: true,
      },
      {
        Header: "Cost Price",
        id: "purchasePrice",
        accessor: "purchasePrice",
        name: "purchasePrice",
        disableSortBy: true,
        disableFilters: true,
        required: false,
        style: {
          flex: "0 0 90px",
        },
      },
      {
        Header: "Sale Price",
        id: "salesPrice",
        accessor: "salesPrice",
        name: "salesPrice",
        required: false,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 90px",
        },
      },
    ],
    tierPriceColumns: [...tierPriceColumns, actionColumn],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};