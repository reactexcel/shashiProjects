import axios from '../../../axios/axios';
import * as ingredientActionTypes from './ingredientActionTypes';
import * as ingredientConstant from '../constant/ingredientConstant';
import * as actionTypes from '../../../actions/actionTypes';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: ingredientActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setSelectedIngredientCode(selectedIngredientCode) {
  return function (dispatch) {
    dispatch({
      type: ingredientActionTypes.SET_SELECTED_INGREDIENT_CODE,
      payload: selectedIngredientCode
    });
  }
}

export function setIngredientDetails(ingredientDetailsObj, actionMode) {

  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(ingredientConstant.SET_CREATE_INGREDIENT_DETAILS_URL,
        ingredientDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(ingredientConstant.SET_UPDATE_INGREDIENT_DETAILS_URL +
        ingredientDetailsObj.productId, ingredientDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function getIngredientList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_INGREDIENT_LIST_URL,
      { params: params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_INGREDIENT_LIST,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getInactiveIngredientList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_INGREDIENT_LIST_URL,{ params: params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_INACTIVE_INGREDIENT_LIST,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getIngredientGrossList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_INGREDIENT_LIST_URL,
      { params: params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_INGREDIENT_GROSS_LIST,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getIngredientDetails(selectedIngredientCode, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_INGREDIENT_DETAILS_URL +
      selectedIngredientCode, { params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_INGREDIENT_DETAILS,
            payload: response.data[0]
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getIngredientDetailList(list, facilityId, customerId, tierId) {
  let url = '';
  if (facilityId && customerId) {
    url = ingredientConstant.GET_INGREDIENT_DETAILS_LIST + "/?facilityId=" + facilityId + "&customerId=" + customerId + "&tierId=" + tierId;
  } else if (facilityId) {
    url = ingredientConstant.GET_INGREDIENT_DETAILS_LIST + "/?facilityId=" + facilityId;
  } else {
    url = ingredientConstant.GET_INGREDIENT_DETAILS_LIST
  }
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(url, list).then(response => {
      if (response.status == 200) {
        dispatch({
          type: ingredientActionTypes.GET_INGREDIENT_DETAILS_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function updateIngredientStatus(ingredientDetailsObj, ingredientId) {
  let params = { isIngredient: true, limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(ingredientConstant.SET_UPDATE_INGREDIENT_STATUS_URL +
        ingredientId, ingredientDetailsObj).then(response => {
        if (response.status == 200) {

          if (response.data && response.data.isIngredientDeleted == false && response.data.productAssociated && response.data.productAssociated.length > 0) {
            dispatch(setAjaxCallStatus(failedApiResponse(response)));
            dispatch(endAjaxCall());
          } else {
            axios.get(ingredientConstant.GET_INGREDIENT_LIST_URL, { params: params }).then(response => {
              if (response.status == 200) {
                dispatch(setAjaxCallStatus(updateApiResponse(response)));
                dispatch({
                  type: ingredientActionTypes.GET_INGREDIENT_LIST,
                  payload: response.data
                })
              }
              dispatch(endAjaxCall());
            })
          }
        }
      }).catch(error => {
        dispatch(endAjaxCall());
      });
  }
}

export function setBulkIngredient(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(ingredientConstant.SET_CREATE_BULK_INGREDIENT_URL, params).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch({
          type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
          payload: response.data.uploadDetails
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
      throw error;
    });
  };
}

export function getIngredientSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_INGREDIENT_SEARCH_URL,
      { params: params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_INGREDIENT_LIST,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function getSKUNumber() {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(ingredientConstant.GET_SKU_DETAILS_URL).then(response => {
        if (response.status == 200) {
          dispatch({
            type: ingredientActionTypes.GET_SKU_DETAILS,
            payload: response.data
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function setSelectedCategoryCode(selectedCategoryCode) {
  return function (dispatch) {
    dispatch({
      type: ingredientActionTypes.SET_SELECTED_CATEGORY_CODE,
      payload: selectedCategoryCode
    });
  }
}