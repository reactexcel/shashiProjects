export const UNCONFIRMED_COLOR = "#ff3d3d";
export const DRAFT_COLOR = "#ff3d3d";
export const INACTIVE_COLOR = "#ff3d3d";
export const EXPIRE_COLOR = "#ff3d3d";
export const DELETE_COLOR = "#ff3d3d";
export const BLOCKED_COLOR = "#ff3d3d";
export const SHIP_COLOR = "#FF7F50";


export const NEW_COLOR = "#0086c0";
export const NOT_AVAILABLE_COLOR = "#0086c0";
export const PENDING_COLOR = "#0086c0";
export const NOT_SOLD_COLOR = "#0086c0";

export const PARTIAL_DELIVERED_COLOR = "#d27a05";
export const IN_PROGRESS_COLOR = "#d27a05";
export const PARTIALLY_SOLD_COLOR = "#d27a05";
export const PARTIAL_RECEIVED_COLOR = "#d27a05";
export const PARTIALLY_PAID_COLOR = "#d27a05";

export const PACKED_COLOR = "#9139b6";
export const DELIVERED_COLOR = "#9139b6";

export const CONFIRMED_COLOR = "#0ba767";
export const IN_STOCK_COLOR = "#0ba767";
export const ACTIVE_COLOR = "#0ba767";
export const COMPLETED_COLOR = "#0ba767";
export const CREATE_COLOR = "#0ba767";
export const CLOSED_COLOR = "#0ba767";
export const DONE_COLOR = "#0ba767";
export const GENERATED_COLOR = "#0ba767";
export const SOLD_OUT_COLOR = "#0ba767";
export const PAID_COLOR = "#0ba767";
//-------------------------------------

export const IN_PRODUCTION_COLOR = "#EC8F13";
export const OPEN_COLOR = "#E2445C";
export const PASS_COLOR = "#0BA767";
export const FAIL_COLOR = "#FF0C0C";







