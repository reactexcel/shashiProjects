import CommonUtil from "./commonUtil";
import validateEmail from '../../security/validation/validateEmail';
import validatePhone from '../../security/validation/validatePhone';

const ValidationUtil = {
    validateCreateRequestObj: function (attributeObj, attributeList) {
        let validObj = true;
        for (let i = 0; i < attributeList.length; i++) {
            if (attributeList[i].required) {
                if (!CommonUtil.isNotNull(attributeObj[attributeList[i].name])) {
                    validObj = false;
                    break;
                }
                if (CommonUtil.isNotNull(attributeObj[attributeList[i].name]) && attributeObj[attributeList[i].name].length < attributeList[i].minLength) {
                    validObj = false;
                    break;
                }
            }
            if (attributeList[i].inputType == "email") {
                if (CommonUtil.isNotNull(attributeObj[attributeList[i].name]) && !validateEmail(attributeObj[attributeList[i].name])) {
                    validObj = false;
                    break;
                }
            }
            if (attributeList[i].inputType == "phone") {
                if (CommonUtil.isNotNull(attributeObj[attributeList[i].name]) && !validatePhone(attributeObj[attributeList[i].name])) {
                    validObj = false;
                    break;
                }
            }
            if (attributeList[i].inputType == "number") {
                attributeObj[attributeList[i].name] = CommonUtil.getFloatValue(attributeObj[attributeList[i].name]);
                if (attributeList[i].type == "TEXTBOX_TAX") {
                    if (attributeObj[attributeList[i].name] > 100) {
                        validObj = false;
                        break;
                    }
                }
            }
        }
        return validObj;
    },
    removeAttributeFromRequestObj: function (attributeObj, attributeList, actionMode) {
        let tempObj = {};
        for (let i = 0; i < attributeList.length; i++) {
            if (attributeList[i][actionMode + "ShowFlag"] && !attributeList[i][actionMode + "RemoveFlag"]) {
                tempObj[attributeList[i].name] =
                    CommonUtil.getFormattedValue(attributeObj[attributeList[i].name], attributeList[i].inputType)
            }
        }
        return tempObj;
    },

    removeAttributeListForActionMode: function (attributeList, actionMode) {
        let tempAttributeList = [];
        for (let i = 0; i < attributeList.length; i++) {
            if (attributeList[i][actionMode + "ShowFlag"] && !attributeList[i][actionMode + "RemoveFlag"]) {
                tempAttributeList.push(attributeList[i]);
            }
        }
        return tempAttributeList;
    },

    validateArrayListRequestObj: function (attributeListObj, attributeList) {
        let validObj = true;
        for (let i = 0; i < attributeListObj.length; i++) {
            for (let j = 0; j < attributeList.length; j++) {
                if (attributeList[j].required) {
                    if (!CommonUtil.isNotNull(attributeListObj[i][attributeList[j].name]) && !attributeList[j].isZeroAllowed) {
                        validObj = false;
                        break;
                    }
                }
                if (attributeList[j].inputType == "number") {
                    attributeListObj[i][attributeList[j].name] = CommonUtil.getFloatValue(attributeListObj[i][attributeList[j].name]);
                }
            }
        }
        return validObj;
    },

    removeAttributeFromArrayList: function (dataListObj, attributeList, actionMode) {
        let validObj = [];
        let tempObj = {};
        for (let i = 0; i < dataListObj.length; i++) {
            tempObj = {};
            for (let j = 0; j < attributeList.length; j++) {
                if (attributeList[j][actionMode + "ShowFlag"]) {
                    tempObj[attributeList[j].name] =
                        CommonUtil.getFormattedValue(dataListObj[i][attributeList[j].name], attributeList[j].inputType)
                }
            }
            validObj.push({ ...tempObj });
        }
        return validObj;
    },
    removeAttributeFromArrayListByKey: function (attributeList, key) {
        let tempAttributeList = [];
        for (let i = 0; i < attributeList.length; i++) {
            if (attributeList[i]["name"] != key) {
                tempAttributeList.push(attributeList[i]);
            }
        }
        return tempAttributeList;
    },
};

export default ValidationUtil;