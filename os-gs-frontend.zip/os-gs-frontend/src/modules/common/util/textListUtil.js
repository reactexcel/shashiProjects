import React, { Component } from "react";
import {Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import CommonUtil from './commonUtil';
const TextListUtil = {
  textListAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup >
          <ControlLabel>
            {tempAttributeListObj.label}
            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <div className="form-control ingredients">
            <ul>
              {attributeObj != null && attributeObj[tempAttributeListObj.list].map((tempList, index) => (
                <li key={index}>
                  {tempList} <i id={tempAttributeListObj.name + '_' + index} className="fa fa-close"
                    onClick={(e) => CommonUtil.handelRemoveTextList(e, that)} />
                </li>
              ))}
            </ul>
          </div>
        </FormGroup>
        <div className="add-row">
          <div className="row-data">
            <FormControl type="text" name={tempAttributeListObj.name} value={attributeObj[tempAttributeListObj.name]}
              onChange={(e) => CommonUtil.handleTextBoxChange(e, that)}
              disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false} />
          </div>
          <div id={tempAttributeListObj.name} className="add-row-button" onClick={(e) => CommonUtil.handleTextList(e, that)} >
            <i id={tempAttributeListObj.name} className=" fa fa-plus" />
            Add New
            </div>
        </div>
      </Col>
    )
  }
};

export default TextListUtil;