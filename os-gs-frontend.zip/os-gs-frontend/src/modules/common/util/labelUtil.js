import React from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import CommonUtil from '../../common/util/commonUtil';
const LabelUtil = {
  labelAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode, customErrorFlag) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <div className="section-code-number">
          <div className="heading">
            {tempAttributeListObj.label}
          </div>
          <div className="number">
            {CommonUtil.isCreateOrCloneMode(actionMode) || !attributeObj[tempAttributeListObj.name] ?
              `${tempAttributeListObj.prefix}${tempAttributeListObj.prefix ? "-" : ""}*****` :
              `${tempAttributeListObj.prefix}${tempAttributeListObj.prefix ? "-" : ""}${attributeObj[tempAttributeListObj.name]}`
            }
          </div>
        </div>
      </Col>
    )
  },
  fixedAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode, customErrorFlag) {
    return (
      <Col md={tempAttributeListObj.fieldWidth} sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          <ControlLabel className="fixed-label">
            {tempAttributeListObj.label}
            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <div className="fixed-text">
            {CommonUtil.isCreateOrCloneMode(actionMode) || !attributeObj[tempAttributeListObj.name] ?
              "-" :
              attributeObj[tempAttributeListObj.name]
            }
          </div>
          {submitted && customErrorFlag &&
            <small className="text-danger">
              {tempAttributeListObj.customMessage}
            </small>
          }
          {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }
        </FormGroup>
      </Col>
    )
  },
};

export default LabelUtil;