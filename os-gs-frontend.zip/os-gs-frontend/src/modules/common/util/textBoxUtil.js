import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, FormControl, ControlLabel, InputGroup, Tooltip, OverlayTrigger } from "react-bootstrap";
import CommonUtil from './commonUtil';
import { touch } from "redux-form";
import validateEmail from '../../security/validation/validateEmail';
import validatePhone from '../../security/validation/validatePhone';
import currencyIcon from './currencyIcon';

const TextBoxUtil = {
  textBoxAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode, customErrorFlag, customEmailErrorFlag, customErrorObj) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          <ControlLabel>
            {tempAttributeListObj.tooltipText ?
              <OverlayTrigger
                placement="right"
                overlay={
                  <Tooltip id={tempAttributeListObj.label}>
                    {tempAttributeListObj.tooltipText}
                  </Tooltip>
                }
              >
                <span> {tempAttributeListObj.label}
                  {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
              </OverlayTrigger>
              : <span> {tempAttributeListObj.label}
                {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
            }
          </ControlLabel>

          {tempAttributeListObj.showCurrency || tempAttributeListObj.showUOM || tempAttributeListObj.addonvalue ?
            <InputGroup>
              {tempAttributeListObj.showCurrency ?
                <InputGroup.Addon>
                  {currencyIcon.getCurrencyIcon(that.props.currencyCode)}
                </InputGroup.Addon>
                : null}
              <FormControl rows={tempAttributeListObj.numberOfRow} componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                placeholder={tempAttributeListObj.placeholder} name={tempAttributeListObj.name}
                className={tempAttributeListObj.camelCase == true ? 'camelcase' : ''}
                value={attributeObj[tempAttributeListObj.name]}
                title={attributeObj[tempAttributeListObj.name]}
                disabled={tempAttributeListObj[actionMode] == 'disabled' ? true :
                  tempAttributeListObj.isCustomDisabled ? true : false}
                min={tempAttributeListObj.minValue}
                maxLength={tempAttributeListObj.maxLength}
                minLength={tempAttributeListObj.minLength}
                onPaste={(e) => tempAttributeListObj.inputType == "number" && !tempAttributeListObj.allowCopyPaste ? CommonUtil.handleNumberPaste(e, that) : null}
                onBlur={(e) => CommonUtil.handleTextBoxBlur(e, that)}
                onChange={(e) => {
                  this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                  if (tempAttributeListObj.type == "TEXTBOX_TAX") { this.maxValueCheck(e, 100) };
                  tempAttributeListObj.customAttribute == true ?
                    that.handleCustomTextBoxChange(e) :
                    tempAttributeListObj.inputType == "number" ?
                      tempAttributeListObj.numberType == "fixed" ?
                        CommonUtil.handleFixedNumberChange(e, that) :
                        CommonUtil.handleNumberChange(e, that) :
                      tempAttributeListObj.textType == "fixed" ?
                        CommonUtil.handleFixedTextBoxChange(e, that) :
                        CommonUtil.handleTextBoxChange(e, that)
                }} />
              {tempAttributeListObj.showUOM ?
                <InputGroup.Addon>
                  {/* {attributeObj[tempAttributeListObj.uomName]} */}
                  {
                    Number(attributeObj[tempAttributeListObj.uomName]) > 0 ?
                    CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, attributeObj[tempAttributeListObj.uomName]) 
                    : attributeObj[tempAttributeListObj.uomName]
                  }
                </InputGroup.Addon>
                : null}
              {tempAttributeListObj.addonvalue ?
                <InputGroup.Addon>
                  {tempAttributeListObj.addonvalue}
                </InputGroup.Addon>
                : null}
            </InputGroup>
            :
            <FormControl rows={tempAttributeListObj.numberOfRow} componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
              placeholder={tempAttributeListObj.placeholder} name={tempAttributeListObj.name}
              value={attributeObj[tempAttributeListObj.name]}
              title={attributeObj[tempAttributeListObj.name]}
              disabled={tempAttributeListObj[actionMode] == 'disabled' ? true :
                tempAttributeListObj.isCustomDisabled ? true : false}
              min={tempAttributeListObj.minValue}
              maxLength={tempAttributeListObj.maxLength}
              minLength={tempAttributeListObj.minLength}
              onBlur={(e) => {
                tempAttributeListObj.customBlurAttribute == true ?
                  that.handleCustomBlurChange(e)
                  : CommonUtil.handleTextBoxBlur(e, that)
              }}
              onKeyDown={e => e.stopPropagation()}
              onPaste={(e) => tempAttributeListObj.inputType == "number" && !tempAttributeListObj.allowCopyPaste ? CommonUtil.handleNumberPaste(e, that) : null}
              onChange={(e) => {
                this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                if (tempAttributeListObj.type == "TEXTBOX_TAX") { this.maxValueCheck(e, 100) };
                tempAttributeListObj.customAttribute == true ?
                  that.handleCustomTextBoxChange(e) :
                  tempAttributeListObj.inputType == "number" ?
                    tempAttributeListObj.numberType == "fixed" ?
                      CommonUtil.handleFixedNumberChange(e, that) :
                      CommonUtil.handleNumberChange(e, that) :
                    tempAttributeListObj.textType == "fixed" ?
                      CommonUtil.handleFixedTextBoxChange(e, that) :
                      CommonUtil.handleTextBoxChange(e, that)
              }} />

          }
          {submitted && tempAttributeListObj.required && !CommonUtil.isNotNull(attributeObj[tempAttributeListObj.name]) &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }
          {submitted && customErrorFlag && attributeObj[tempAttributeListObj.name] ?
            <small className="text-danger">
              {tempAttributeListObj.customMessage}
            </small>
            : null
          }
          {submitted && customErrorObj && customErrorObj.customErrorFlag && tempAttributeListObj.errorType == customErrorObj.errorType &&
            <small className="text-danger">
              {customErrorObj.errorMessage}
            </small>
          }
          {submitted && customEmailErrorFlag && attributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.customEmailMessage}
            </small>
          }
          {(touch || submitted) && attributeObj[tempAttributeListObj.name] && tempAttributeListObj.maxLength && tempAttributeListObj.type != "TEXTBOX_TAX" ?
            attributeObj[tempAttributeListObj.name].length >= tempAttributeListObj.maxLength ?
              <small className="text-danger">
                Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
              </small>
              : null
            : null
          }
          {(touch || submitted) && attributeObj[tempAttributeListObj.name] && tempAttributeListObj.minLength && tempAttributeListObj.type != "TEXTBOX_TAX" ?
            attributeObj[tempAttributeListObj.name].length < tempAttributeListObj.minLength ?
              <small className="text-danger">
                Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
              </small>
              : null
            : null
          }
          {(touch || submitted) && attributeObj[tempAttributeListObj.name] && tempAttributeListObj.inputType == "email" ?
            !validateEmail(attributeObj[tempAttributeListObj.name]) ?
              <small className="text-danger">
                {tempAttributeListObj.emailMsgText}
              </small>
              : null
            : null
          }
          {(touch || submitted) && attributeObj[tempAttributeListObj.name] && tempAttributeListObj.inputType == "phone" ?
            !validatePhone(attributeObj[tempAttributeListObj.name]) ?
              <small className="text-danger">
                {tempAttributeListObj.phoneMsgText}
              </small>
              : null
            : null
          }
          {(touch || submitted) && attributeObj[tempAttributeListObj.name] && tempAttributeListObj.type == "TEXTBOX_TAX" && attributeObj[tempAttributeListObj.name] > 100 ?
            <small className="text-danger">
              Allowed value limit is 0 to 100.
              </small>
            : null
          }

          {tempAttributeListObj.MsgText && actionMode != "viewMode" ?
            <a href={tempAttributeListObj.MsgTextHref} id={tempAttributeListObj.name}
              onClick={tempAttributeListObj.linkOnClickFun} className="msgtext">
              {tempAttributeListObj.MsgText}
            </a>
            : null}

        </FormGroup>
      </Col>
    )
  },
  maxLengthCheck: function (object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  },

  locationTextBoxAttribute: function (tempAttributeListObj, index, locationAttributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          <ControlLabel>
            {tempAttributeListObj.label}
            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <FormControl rows={tempAttributeListObj.numberOfRow} componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
            className={tempAttributeListObj.camelCase == true ? 'camelcase' : ''}
            min={tempAttributeListObj.minValue}
            maxLength={tempAttributeListObj.maxLength}
            minLength={tempAttributeListObj.minLength}
            name={tempAttributeListObj.name} value={locationAttributeObj[tempAttributeListObj.name]}
            disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
            onPaste={(e) => tempAttributeListObj.inputType == "number" && !tempAttributeListObj.allowCopyPaste ? CommonUtil.handleNumberPaste(e, that) : null}
            onBlur={(e) => CommonUtil.handleTextBoxBlur(e, that)}
            onChange={(e) => {
              this.maxLengthCheck(e, tempAttributeListObj.maxLength)
              tempAttributeListObj.inputType == "number" ?
                that.handleLocationNumberChange(e) :
                that.handleLocationTextChange(e)
            }} />
          {submitted && tempAttributeListObj.required && !locationAttributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }

          {(touch || submitted) && tempAttributeListObj.maxLength && locationAttributeObj[tempAttributeListObj.name] &&
            locationAttributeObj[tempAttributeListObj.name].length >= tempAttributeListObj.maxLength &&
            <small className="text-danger">
              Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
            </small>
          }
          {(touch || submitted) && tempAttributeListObj.minLength && locationAttributeObj[tempAttributeListObj.name] &&
            locationAttributeObj[tempAttributeListObj.name].length < tempAttributeListObj.minLength &&
            <small className="text-danger">
              Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
            </small>
          }
        </FormGroup>
      </Col>
    )

  },

  documentTextBoxAttribute: function (tempAttributeListObj, index, documentAttributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          <ControlLabel>
            {tempAttributeListObj.label}
            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <FormControl rows={tempAttributeListObj.numberOfRow} componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
            className={tempAttributeListObj.camelCase == true ? 'camelcase' : ''}
            type={tempAttributeListObj.inputType} name={tempAttributeListObj.name} value={documentAttributeObj[tempAttributeListObj.name]}
            disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
            onBlur={(e) => CommonUtil.handleTextBoxBlur(e, that)}
            onChange={(e) => {
              this.maxLengthCheck(e, tempAttributeListObj.maxLength)
              { that.handleDocumentTextChange(e) }

            }} />
          {submitted && tempAttributeListObj.required && !documentAttributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }

          {(touch || submitted) && tempAttributeListObj.maxLength && +documentAttributeObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
            <small className="text-danger">
              Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
            </small>
          }
          {(touch || submitted) && tempAttributeListObj.minLength && +documentAttributeObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
            <small className="text-danger">
              Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
            </small>
          }
        </FormGroup>
      </Col>
    )
  },

  maxValueCheck: function (object, maxValue) {
    let customErrorFlag = false;
    if (object.target.value > maxValue) {
      object.target.value = object.target.value.slice(0, 3)
      customErrorFlag = true
    }
    return customErrorFlag;
  },
};

export default TextBoxUtil;