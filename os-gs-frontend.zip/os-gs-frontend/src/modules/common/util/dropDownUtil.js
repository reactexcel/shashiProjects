import React from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import Select from "react-select";
import CommonUtil from './commonUtil';
const DropDownUtil = {
  dropDownAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          {tempAttributeListObj.label != null ?
            <ControlLabel>
              {tempAttributeListObj.label}
              {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
            </ControlLabel> : null
          }
          <div title={tempAttributeListObj.isMulti ? "" : CommonUtil.getSelectedOptionTitle(tempAttributeListObj.options, attributeObj[tempAttributeListObj.name])} >
            <Select
              name={tempAttributeListObj.name}
              onChange={
                tempAttributeListObj.isDropdownCall == true ?
                  (e, obj) => that.handleCustomDropDownCall(e, obj) :
                  tempAttributeListObj.customAttribute == true ?
                    (e, obj) => that.handleCustomDropDownChange(e, obj) :
                    tempAttributeListObj.isMulti ?
                      (e, obj) => CommonUtil.handleMultiDropDownChange(e, obj, that) :
                      (e, obj) => CommonUtil.handleDropDownChange(e, obj, that)}
              isMulti={tempAttributeListObj.isMulti}
              closeMenuOnSelect={tempAttributeListObj.closeMenuOnSelect}
              options={tempAttributeListObj.options}
              classNamePrefix="react-select"
              isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true :
                tempAttributeListObj.isCustomDisabled ? true : false}
              placeholder={tempAttributeListObj.placeholder}
              value={tempAttributeListObj.isMulti ? attributeObj[tempAttributeListObj.name] :
                CommonUtil.getSelectedOptionLabel(tempAttributeListObj.options, attributeObj[tempAttributeListObj.name])
              }
            />
          </div>
          {tempAttributeListObj.createSupplier && actionMode != "viewMode" ? <div className="create-new-supplier" onClick={that.showModal}>{tempAttributeListObj.createSupplier}</div> : null}
          {submitted && tempAttributeListObj.required && (attributeObj[tempAttributeListObj.name] ? (attributeObj[tempAttributeListObj.name].length == 0) : !attributeObj[tempAttributeListObj.name]) &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }
          {tempAttributeListObj.MsgText && actionMode != "viewMode" ?
            <a href={tempAttributeListObj.MsgTextHref} id={tempAttributeListObj.name}
              onClick={tempAttributeListObj.linkOnClickFun} className="msgtext">
              {tempAttributeListObj.MsgText}
            </a>
            : null}
        </FormGroup>
      </Col>

    )
  },
  locationDropDownAttribute: function (tempAttributeListObj, index, locationAttributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          {tempAttributeListObj.label != null ?
            <ControlLabel>
              {tempAttributeListObj.label}
              {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
            </ControlLabel> : null
          }
          <div title={tempAttributeListObj.isMulti ? "" : CommonUtil.getSelectedOptionTitle(tempAttributeListObj.options, locationAttributeObj[tempAttributeListObj.name])} >
            <Select
              name={tempAttributeListObj.name}
              onChange={that.handleLocationDropDownChange}
              isMulti={tempAttributeListObj.isMulti}
              options={tempAttributeListObj.options}
              classNamePrefix="react-select"
              isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
              placeholder={tempAttributeListObj.placeholder}
              value={{ "label": locationAttributeObj[tempAttributeListObj.name] }}
            />
          </div>
          {submitted && tempAttributeListObj.required && !locationAttributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }
        </FormGroup>
      </Col>

    )
  },
};

export default DropDownUtil;