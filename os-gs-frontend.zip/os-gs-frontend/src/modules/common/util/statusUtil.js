import * as ColorConstant from "../../common/constant/colorConstant";
import * as StatusConstant from "../../common/constant/statusConstant";

const StatusUtil = {
  getStatusColor: function (value) {
    var color;
    switch (value) {
      case StatusConstant.IN_STOCK_STATUS:
        color = ColorConstant.IN_STOCK_COLOR;
        break;
      case StatusConstant.IN_PRODUCTION_STATUS:
        color = ColorConstant.IN_PRODUCTION_COLOR;
        break;
      case StatusConstant.NOT_AVAILABLE_STATUS:
        color = ColorConstant.NOT_AVAILABLE_COLOR;
        break;
      case StatusConstant.PACKED_STATUS:
        color = ColorConstant.PACKED_COLOR;
        break;
      case StatusConstant.COLLECT_STATUS:
        color = ColorConstant.PACKED_COLOR;
        break;
      case StatusConstant.SHIP_STATUS:
        color = ColorConstant.SHIP_COLOR;
        break;
      case StatusConstant.DELIVERED_STATUS:
        color = ColorConstant.DELIVERED_COLOR;
        break;
      case StatusConstant.PARTIAL_RECEIVED:
        color = ColorConstant.PARTIAL_RECEIVED_COLOR;
        break;
      case StatusConstant.INACTIVE_STATUS:
        color = ColorConstant.INACTIVE_COLOR;
        break;
      case StatusConstant.ACTIVE_STATUS:
        color = ColorConstant.ACTIVE_COLOR;
        break;
      case StatusConstant.IN_PROGRESS_STATUS:
        color = ColorConstant.IN_PROGRESS_COLOR;
        break;
      case StatusConstant.OPEN_STATUS:
        color = ColorConstant.OPEN_COLOR;
        break;
      case StatusConstant.NEW_STATUS:
        color = ColorConstant.NEW_COLOR;
        break;
      case StatusConstant.CLOSED_STATUS:
        color = ColorConstant.CLOSED_COLOR;
        break;
      case StatusConstant.COMPLETED_STATUS:
        color = ColorConstant.COMPLETED_COLOR;
        break;
      case StatusConstant.DONE_STATUS:
        color = ColorConstant.DONE_COLOR;
        break;
      case StatusConstant.BLOCKED_STATUS:
        color = ColorConstant.BLOCKED_COLOR;
        break;
      case StatusConstant.PASS_STATUS:
        color = ColorConstant.PASS_COLOR;
        break;
      case StatusConstant.FAIL_STATUS:
        color = ColorConstant.FAIL_COLOR;
        break;
      case StatusConstant.CREATE_STATUS:
        color = ColorConstant.CREATE_COLOR;
        break;
      case StatusConstant.EXPIRE_STATUS:
        color = ColorConstant.EXPIRE_COLOR;
        break;
      case StatusConstant.SOLD_OUT_STATUS:
        color = ColorConstant.SOLD_OUT_COLOR;
        break;
      case StatusConstant.PARTIALLY_SOLD_STATUS:
        color = ColorConstant.PARTIALLY_SOLD_COLOR;
        break;
      case StatusConstant.NOT_SOLD_STATUS:
        color = ColorConstant.NOT_SOLD_COLOR;
        break;
      case StatusConstant.PARTIAL_DELIVERED_STATUS:
        color = ColorConstant.PARTIAL_DELIVERED_COLOR;
        break;
      case StatusConstant.CONFIRMED_STATUS:
        color = ColorConstant.CONFIRMED_COLOR;
        break;
      case StatusConstant.UNCONFIRMED_STATUS:
        color = ColorConstant.UNCONFIRMED_COLOR;
        break;
      case StatusConstant.OVERDUE_STATUS:
        color = ColorConstant.EXPIRE_COLOR;
        break;
      case StatusConstant.USER_INACTIVE_STATUS:
        color = ColorConstant.INACTIVE_COLOR;
        break;
      case StatusConstant.USER_UNCONFIRMED_STATUS:
        color = ColorConstant.UNCONFIRMED_COLOR;
        break;
      case StatusConstant.USER_CONFIRMED_STATUS:
        color = ColorConstant.CONFIRMED_COLOR;
        break;
      case StatusConstant.PENDING_STATUS:
        color = ColorConstant.PENDING_COLOR;
        break;
      case StatusConstant.DELETE_STATUS:
        color = ColorConstant.DELETE_COLOR;
        break;
      case StatusConstant.GENERATED_STATUS:
        color = ColorConstant.GENERATED_COLOR;
        break;
      case StatusConstant.CREATE_BILLS_STATUS:
        color = ColorConstant.CREATE_COLOR;
        break;
      case StatusConstant.CREATE_INVOICE_STATUS:
        color = ColorConstant.CREATE_COLOR;
        break;
      case StatusConstant.PENDING_BILLS_STATUS:
        color = ColorConstant.PENDING_COLOR;
        break;
      case StatusConstant.PENDING_INVOICE_STATUS:
        color = ColorConstant.PENDING_COLOR;
        break;
      case StatusConstant.DRAFT_STATUS:
        color = ColorConstant.DRAFT_COLOR;
        break;
      case StatusConstant.NOTIFY_STATUS:
        color = ColorConstant.DELIVERED_COLOR;
        break;
      case StatusConstant.PARTIALLY_PAID_STATUS:
        color = ColorConstant.PARTIALLY_PAID_COLOR;
        break;

      case StatusConstant.PAID_STATUS:
        color = ColorConstant.PAID_COLOR;
        break;

      default:
        color = ColorConstant.IN_STOCK_COLOR;
    }
    return color;
  },

  getStatusLabel: function (value) {
    var label;
    switch (value) {
      case StatusConstant.IN_STOCK_STATUS:
        label = StatusConstant.IN_STOCK_LABEL;
        break;
      case StatusConstant.IN_PRODUCTION_STATUS:
        label = StatusConstant.IN_PRODUCTION_LABEL;
        break;
      case StatusConstant.NOT_AVAILABLE_STATUS:
        label = StatusConstant.NOT_AVAILABLE_LABEL;
        break;
      case StatusConstant.PACKED_STATUS:
        label = StatusConstant.PACKED_LABEL;
        break;
      case StatusConstant.PICKING_STATUS:
        label = StatusConstant.PICKING_LABEL;
        break;
      case StatusConstant.SHIP_STATUS:
        label = StatusConstant.SHIP_LABEL;
        break;
      case StatusConstant.COLLECT_STATUS:
        label = StatusConstant.COLLECT_LABEL;
        break;
      case StatusConstant.DELIVERED_STATUS:
        label = StatusConstant.DELIVERED_LABEL;
        break;
      case StatusConstant.PARTIAL_RECEIVED:
        label = StatusConstant.PARTIAL_RECEIVED_LABEL;
        break;
      case StatusConstant.INACTIVE_STATUS:
        label = StatusConstant.INACTIVE_LABEL;
        break;
      case StatusConstant.ACTIVE_STATUS:
        label = StatusConstant.ACTIVE_LABEL;
        break;
      case StatusConstant.COMPLETED_STATUS:
        label = StatusConstant.COMPLETED_LABEL;
        break;
      case StatusConstant.RECALL_STATUS:
        label = StatusConstant.RECALL_LABEL;
        break;
      case StatusConstant.WITHDRAW_STATUS:
        label = StatusConstant.WITHDRAW_LABEL;
        break;
      case StatusConstant.IN_PROGRESS_STATUS:
        label = StatusConstant.IN_PROGRESS_LABEL;
        break;
      case StatusConstant.OPEN_STATUS:
        label = StatusConstant.OPEN_LABEL;
        break;
      case StatusConstant.NEW_STATUS:
        label = StatusConstant.NEW_LABEL;
        break;
      case StatusConstant.CLOSED_STATUS:
        label = StatusConstant.CLOSED_LABEL;
        break;
      case StatusConstant.ALL_STATUS:
        label = StatusConstant.ALL_LABEL;
        break;
      case StatusConstant.DONE_STATUS:
        label = StatusConstant.DONE_LABEL;
        break;
      case StatusConstant.BLOCKED_STATUS:
        label = StatusConstant.BLOCKED_LABEL;
        break;
      case StatusConstant.PASS_STATUS:
        label = StatusConstant.PASS_LABEL;
        break;
      case StatusConstant.FAIL_STATUS:
        label = StatusConstant.FAIL_LABEL;
        break;
      case StatusConstant.CREATE_STATUS:
        label = StatusConstant.CREATE_LABEL;
        break;
      case StatusConstant.EXPIRE_STATUS:
        label = StatusConstant.EXPIRE_LABEL;
        break;
      case StatusConstant.OVERDUE_STATUS:
        label = StatusConstant.OVERDUE_LABEL;
        break;
      case StatusConstant.SOLD_OUT_STATUS:
        label = StatusConstant.SOLD_OUT_LABEL;
        break;
      case StatusConstant.PARTIALLY_SOLD_STATUS:
        label = StatusConstant.PARTIALLY_SOLD_LABEL;
        break;
      case StatusConstant.NOT_SOLD_STATUS:
        label = StatusConstant.NOT_SOLD_LABEL;
        break;
      case StatusConstant.PARTIAL_DELIVERED_STATUS:
        label = StatusConstant.PARTIAL_DELIVERED_LABEL;
        break;
      case StatusConstant.CONFIRMED_STATUS:
        label = StatusConstant.CONFIRMED_LABEL;
        break;
      case StatusConstant.UNCONFIRMED_STATUS:
        label = StatusConstant.UNCONFIRMED_LABEL;
        break;
      case StatusConstant.USER_INACTIVE_STATUS:
        label = StatusConstant.INACTIVE_LABEL;
        break;
      case StatusConstant.USER_UNCONFIRMED_STATUS:
        label = StatusConstant.UNCONFIRMED_LABEL;
        break;
      case StatusConstant.USER_CONFIRMED_STATUS:
        label = StatusConstant.CONFIRMED_LABEL;
        break;
      case StatusConstant.PENDING_STATUS:
        label = StatusConstant.PENDING_LABEL;
        break;
      case StatusConstant.GENERATED_STATUS:
        label = StatusConstant.GENERATED_LABEL;
        break;
      case StatusConstant.DELETE_STATUS:
        label = StatusConstant.DELETE_LABEL;
        break;
      case StatusConstant.CREATE_BILLS_STATUS:
        label = StatusConstant.CREATE_BILLS_LABEL;
        break;
      case StatusConstant.CREATE_INVOICE_STATUS:
        label = StatusConstant.CREATE_INVOICE_LABEL;
        break;
      case StatusConstant.PENDING_BILLS_STATUS:
        label = StatusConstant.PENDING_BILLS_LABEL;
        break;
      case StatusConstant.PENDING_INVOICE_STATUS:
        label = StatusConstant.PENDING_INVOICE_LABEL;
        break;
      case StatusConstant.DRAFT_STATUS:
        label = StatusConstant.DRAFT_LABEL;
        break;
      case StatusConstant.NOTIFY_STATUS:
        label = StatusConstant.NOTIFY_LABEL;
        break;
      case StatusConstant.PARTIALLY_PAID_STATUS:
        label = StatusConstant.PARTIALLY_PAID_LABEL;
        break;
      case StatusConstant.PAID_STATUS:
        label = StatusConstant.PAID_LABEL;
        break;

      case StatusConstant.SO_RETURN_STATUS:
        label = StatusConstant.SO_RETURN_LABEL;
        break;
      case StatusConstant.PO_RETURN_STATUS:
        label = StatusConstant.PO_RETURN_LABEL;
        break;
      case StatusConstant.CUSTOMER_CREDIT_STATUS:
        label = StatusConstant.CUSTOMER_CREDIT_LABEL;
        break;
      case StatusConstant.SUPPLIER_CREDIT_STATUS:
        label = StatusConstant.SUPPLIER_CREDIT_LABEL;
        break;

      case StatusConstant.CUSTOMER_RETURN_STATUS:
        label = StatusConstant.CUSTOMER_RETURN_LABEL;
        break;
      case StatusConstant.SUPPLIER_RETURN_STATUS:
        label = StatusConstant.SUPPLIER_RETURN_LABEL;
        break;
      default:
        label = value;
    }
    return label;
  },
  getStockLabel: function (value) {
    var border;
    switch (value) {
      case "PRODUCT": {
        border = '6px solid #007285';
        break;
      }
      case "INGREDIENT": {
        border = '6px solid #e458b9';
        break;
      }
      default:
        border = '6px solid #e458b9';
    }
    return border;
  },
  getNegativeColor: function (value) {
    var fontColor;
    if (value < 0) {
      fontColor = "Red";
    } else {
      fontColor = "Black";
    }

    return fontColor;
  },
};

export default StatusUtil;
