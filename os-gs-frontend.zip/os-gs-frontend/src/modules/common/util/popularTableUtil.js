import { Link, Redirect } from "react-router-dom";
import React, { Component } from "react";
import _ from 'lodash'
import CommonUtil from "./commonUtil";

const PopularTableUtil = {
  handleInputClickTable: function (e, rowIndex, that, tableDataKeyName) {
    let tableData = _.cloneDeep(that.state[tableDataKeyName])
    tableData.data[rowIndex][e.target.name] = e.target.value
    let data = that.state[tableDataKeyName].data.splice(0, that.state[tableDataKeyName].data.length - 1)
    //if(tableData && tableData.data)  {
    tableData.data[rowIndex][e.target.name] = e.target.value
    data = { ...tableData }
    that.setState({
      [tableDataKeyName]: {
        data: data.data,
        columns: data.columns
      }

    })
  },

  handleDropDownChange: function (e, rowIndex, that, tableDataKeyName, attributeName) {
    let value = e.value
    let tableData = that.state[tableDataKeyName]
    if (tableData && tableData.data) {
      tableData.data[rowIndex][attributeName] = value
      that.setState({
        [tableDataKeyName]: {
          data: [],
          columns: tableData.columns
        }
      }, () => that.setState({ [tableDataKeyName]: tableData }));
    }
  },
  handleIconClickTable: function (e, rowIndex, that, tableDataKeyName, operation) {
    if (operation === 'delete') {
      let tableData = that.state[tableDataKeyName]
      tableData.data.splice(rowIndex, 1);
      that.setState({
        [tableDataKeyName]: {
          columns: tableData.columns,
          data: []
        }
      }, () => that.setState({ [tableDataKeyName]: tableData }))
    }
  },
  handleStockModalTextBoxChange: async function (event, that, tableDataKeyName) {
    const { name, value } = event.target;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...that.state[tableDataKeyName]];
    let tempObj = attributeDataList[id];

    let availableStock = CommonUtil.getFloatValue(tempObj.remainingstock) -
      CommonUtil.getFloatValue(tempObj.blockedstock);

    let tempValue = value <= availableStock ? value : availableStock;

    const re = /^\d+(\.\d{0,2})?$/;
    if (tempValue === '' || re.test(tempValue)) {
      attributeDataList[id][name] = tempValue;
    }
    else {
      attributeDataList[id][name] = tempValue.substring(0, tempValue.length - 1);
    }

    let data = attributeDataList;
    const newData = data.map(d => ({ ...d }));
    await that.setState({ [tableDataKeyName]: newData });
  },
  handleComparativeTextBoxChange: async function (event, that, tableDataKeyName, compareAttribute, secondcompareAttribute) {
    const { name, value } = event.target;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...that.state[tableDataKeyName]];
    let tempObj = attributeDataList[id];

    let availableStock = CommonUtil.getFloatValue(tempObj[compareAttribute]) - (secondcompareAttribute ? CommonUtil.getFloatValue(tempObj[secondcompareAttribute]) : 0) - CommonUtil.getFloatValue(value);
    let tempValue = availableStock > 0 ? value : CommonUtil.getFloatValue(tempObj[compareAttribute]) - (secondcompareAttribute ? CommonUtil.getFloatValue(tempObj[secondcompareAttribute]) : 0);
    const re = /^\d+(\.\d{0,2})?$/;
    if (tempValue === '' || re.test(tempValue)) {
      attributeDataList[id][name] = tempValue;
    }
    else {
      attributeDataList[id][name] = tempValue.substring(0, tempValue.length - 1);
    }

    let data = attributeDataList;
    const newData = data.map(d => ({ ...d }));
    await that.setState({ [tableDataKeyName]: newData });
  },
  handleTableTextBoxChange: function (event, that, tableDataKeyName) {
    const { name, value } = event.target;
    var id = parseInt(event.target.id.split('_')[1]);
    var attributeDataList = [...that.state[tableDataKeyName]];
    const type = event.target.getAttribute("data-type");
    const numbertype = event.target.getAttribute("data-numbertype");
    const re = /^\d+(\.\d{0,2})?$/;
    const reg = /^[0-9\b]+$/;

    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      if (id == i) {
        if (type == 'number') {
          if (numbertype == 'fixed') {
            if (value === '' || reg.test(value)) {
              attributeDataList[i][name] = value;
            }
            else {
              attributeDataList[i][name] = value.substring(0, value.length - 1);
            }
          } else {
            if (value === '' || re.test(value)) {
              attributeDataList[i][name] = value;
            }
            else {
              attributeDataList[i][name] = value.substring(0, value.length - 1);
            }
          }
        } else {
          attributeDataList[i][name] = value;
        }
        break;
      }
    }
    let data = attributeDataList;
    const newData = data.map(d => ({ ...d }));
    that.setState({ [tableDataKeyName]: newData })
  },

  handleTableSwitchChange: function (event, state, that, tableDataKeyName) {
    var eventId = event.props.id.split('_');
    var attributeDataList = [...that.state[tableDataKeyName]];
    var id = parseInt(eventId[1]);
    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      if (id == i) {
        attributeDataList[i][eventId[0]] = state;
        break;
      }
    }
    let data = attributeDataList;
    const newData = data.map(d => ({ ...d }));
    that.setState({ [tableDataKeyName]: newData })
  },

  handleTableDateChange: function (event, eventId, that, tableDataKeyName) {
    var name = eventId.split('_')[0];
    var id = parseInt(eventId.split('_')[1]);
    var attributeDataList = [...that.state[tableDataKeyName]];
    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      if (id == i) {
        attributeDataList[i][name] = event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : ''
        break;
      }
    }
    that.setState({ [tableDataKeyName]: attributeDataList })
  },
  handleTableSuggestionChangeStockCount: async function (event, eventId, searchOptions, that, tableDataKeyName, order) {
    var attributeDataList = [...that.state[tableDataKeyName]];
    let temp = {};
    if (order == "stockCount") {
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptions[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    attributeDataList.unshift(temp)
    await that.setState({ [tableDataKeyName]: [] })
    await that.setState({ [tableDataKeyName]: attributeDataList })
  },
  handleTableSuggestionChangeAMS: async function (event, eventId, searchOptions, that, tableDataKeyName, order) {
    var attributeDataList = [...that.state[tableDataKeyName]];
    let temp = {};
    if (order == "saleOrder") {
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptions[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    if (order == "purchaseOrder") {
      let searchOptionsList = ["productId", "productName", "productSKU"]
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptionsList[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    if (order == "purchaseOrderIngredient") {
      let searchOptionsList = ["ingredientId", "ingredientName", "ingredientSKU"]
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptionsList[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    temp.quantity = 1;
    attributeDataList.unshift(temp)
    await that.setState({ [tableDataKeyName]: [] })
    await that.setState({ [tableDataKeyName]: attributeDataList })
  },

  handleSTASuggestionChangeAMS: async function (event, eventId, searchOptions, that, tableDataKeyName, order) {
    var attributeDataList = [...that.state[tableDataKeyName]];
    let temp = {};
    if (order == "saleOrder") {
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptions[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    if (order == "purchaseOrder") {
      let searchOptionsList = ["productId", "productName", "productSKU"]
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptionsList[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    if (order == "purchaseOrderIngredient") {
      let searchOptionsList = ["ingredientId", "ingredientName", "ingredientSKU"]
      for (var j = 0; j < searchOptions.length; j++) {
        if (event && event[0] && event[0][searchOptions[j]]) {
          temp[searchOptionsList[j]] = event && event[0][searchOptions[j]];
        }
      }
    }
    temp.returnQuantity = 1;
    attributeDataList.unshift(temp)
    await that.setState({ [tableDataKeyName]: [] })
    await that.setState({ [tableDataKeyName]: attributeDataList })
  },


  handleTableSuggestionChange: function (event, eventId, searchOptions, that, tableDataKeyName) {
    var id = parseInt(eventId.split('_')[1]);
    var name = eventId.split('_')[0];
    var attributeDataList = [...that.state[tableDataKeyName]];
    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      if (id == i) {
        for (var j = 0; j < searchOptions.length; j++) {
          if (event && event[0] && event[0][searchOptions[j]]) {
            attributeDataList[i][searchOptions[j]] = event && event[0][searchOptions[j]];
          }
        }
        break;
      }
    }
    that.setState({ [tableDataKeyName]: attributeDataList })
  },

  handleTableDropDownChange: function (event, obj, that, tableDataKeyName) {
    let id = parseInt(obj.name.split('_')[1]);
    let attributeDataList = [...that.state[tableDataKeyName]];
    attributeDataList[id][[obj.name.split('_')[0]]] = event.value;
    that.setState({ [tableDataKeyName]: attributeDataList })
  },

  handleMultiTableDropDownChange: function (event, obj, that, tableDataKeyName) {
    let id = parseInt(obj.name.split('_')[1]);
    let attributeDataList = [...that.state[tableDataKeyName]];
    var tempAttributeDataList = [];
    for (var j = 0; j < event.length; j++) {
      tempAttributeDataList.push(event[j].value);
    }
    attributeDataList[id][[obj.name.split('_')[0]]] = tempAttributeDataList;
    that.setState({ [tableDataKeyName]: attributeDataList })
  },

  handleQboTableDropDownChange: function (event, obj, that, tableDataKeyName) {
    let id = parseInt(obj.name.split('_')[1]);
    let attributeDataList = [...that.state[tableDataKeyName]];
    attributeDataList[id][[obj.name.split('_')[0]]] = event.value;
    attributeDataList[id][[obj.name.split('_')[0] + 'label']] = event.label;
    that.setState({ [tableDataKeyName]: attributeDataList })
  },

  handleTableAllRemove: async function (that, tableDataKeyName) {
    await that.setState({ [tableDataKeyName]: [] });
    let tempAttributeDataList = [{}];
    await that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },

  handleTabletwentyRows: async function (that, tableDataKeyName) {
    await that.setState({ [tableDataKeyName]: [] });
    let tempAttributeDataList = [...Array(0)].map(() => ({}));
    await that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },

  handleTableRemove: async function (event, that, tableDataKeyName, eventId) {
    var id = eventId ? parseInt(event.split('_')[1]) : parseInt(event.target.id.split('_')[1]);
    var attributeDataList = [...that.state[tableDataKeyName]];
    await that.setState({ [tableDataKeyName]: [] });
    var tempAttributeDataList = [];
    for (var i = 0; i < attributeDataList.length; i++) {
      if (id !== i) {
        tempAttributeDataList.push({ ...attributeDataList[i] });
      }
    }
    await that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },
  handleTableCloneRow: function (event, that, tableDataKeyName) {
    var id = parseInt(event.target.id.split('_')[1]);
    var tempAttributeDataList = [];
    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      tempAttributeDataList.push({ ...that.state[tableDataKeyName][i] });
      if (id == i) {
        tempAttributeDataList.push({ ...that.state[tableDataKeyName][i] });
      }
    }
    that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },
  handleTableAddRow: function (that, tableDataKeyName) {
    var tempAttributeDataList = [...that.state[tableDataKeyName]];
    var tempObj = {};
    tempAttributeDataList.push({ ...tempObj });
    that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },
  handleTableAddRowVariant: function (that, tableDataKeyName) {
    var tempAttributeDataList = [...that.state[tableDataKeyName]];
    var tempObj = that.state.selectedProduct;
    tempAttributeDataList.push({ ...tempObj });
    that.setState({ [tableDataKeyName]: tempAttributeDataList })
  },

  handleIngredientTableAddRow: function (dbIngredientList, ingredients) {
    let dbIngredientCodeList = [];
    let uiIngredientCodeList = [];
    dbIngredientList.forEach(ingredient => {
      dbIngredientCodeList.push(ingredient.ingredientId);
    });
    ingredients.forEach(ingredient => {
      uiIngredientCodeList.push(ingredient.ingredientId);
    });
  },

  handleTableButtonMenuAction: function (event, that, tableDataKeyName) {
    const { name } = event.target;
    var eventId = event.target.id.split("_");
    var id = parseInt(eventId[1]);
    var attributeDataList = [...that.state[tableDataKeyName]];
    for (var i = 0; i < that.state[tableDataKeyName].length; i++) {
      if (id == i) {
        attributeDataList[i][name] = eventId[0];
        break;
      }
    }
    that.setState({ [tableDataKeyName]: attributeDataList })
  }

}
export default PopularTableUtil;