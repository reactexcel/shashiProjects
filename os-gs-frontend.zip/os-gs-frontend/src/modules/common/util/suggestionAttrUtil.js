import React from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import CommonUtil from './commonUtil';
import SuggestionUtil from '../../common/util/suggestionUtil';

const SuggestionAttrUtil = {
    suggestionDownAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
        return (
            <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                <FormGroup>
                    {tempAttributeListObj.label != null ?
                        <ControlLabel>
                            {tempAttributeListObj.label}
                            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                        </ControlLabel> : null
                    }
                    <div className="full-width" title={attributeObj[tempAttributeListObj.name]}>
                        <SuggestionUtil
                            searchOptionList={tempAttributeListObj.searchOptionList}
                            id={tempAttributeListObj.name}
                            options={tempAttributeListObj.options}
                            placeholder={tempAttributeListObj.placeholder}
                            isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                            value={attributeObj[tempAttributeListObj.name]}
                            selectedValue={attributeObj[tempAttributeListObj.name]}
                            onChange={(e) => CommonUtil.handleSuggestionTextChange(e, tempAttributeListObj.name, that)}
                            handleSuggestionChange={CommonUtil.handleSuggestionTextChange}
                        />
                    </div>


                    {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                        <small className="text-danger">
                            {tempAttributeListObj.mandatoryMsgText}
                        </small>
                    }
                    {tempAttributeListObj.MsgText && attributeObj[tempAttributeListObj.name] ?
                        <a href={tempAttributeListObj.MsgTextHref} id={tempAttributeListObj.name}
                            onClick={tempAttributeListObj.linkOnClickFun} className="msgtext">
                            {tempAttributeListObj.MsgText}
                        </a>
                        : null}
                </FormGroup>
            </Col>

        )
    },

};

export default SuggestionAttrUtil;