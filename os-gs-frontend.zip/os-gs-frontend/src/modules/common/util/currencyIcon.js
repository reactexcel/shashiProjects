const currencyIcon = {
  getCurrencyIcon: function (value) {
    var icon;
    switch (value && value.toUpperCase()) {
      case 'AUD':
        icon = '$';
        break;
      case 'CAD':
        icon = '$';
        break;
      case 'NZD':
        icon = '$';
        break;
      case 'USD':
        icon = '$';
        break;
      case 'GBP':
        icon = '£';
        break;
      case 'EUR':
        icon = '€';
        break;
      case 'CHF':
        icon = 'CHF';
        break;
      case 'CNH':
        icon = '¥';
        break;
      case 'HKD':
        icon = 'HK$';
        break;
      case 'INR':
        icon = '₹';
        break;
      case 'JPY':
        icon = '¥';
        break;
      default:
        icon = '$';
    }
    return icon;
  },

  getCurrencyDecimalFormat: function (code, value) {
    var format;
    switch (code && code.toUpperCase()) {
      case 'AUD':
        format = 'en-AU';
        break;
      case 'CAD':
        format = 'en-CA';
        break;
      case 'NZD':
        format = 'en-NZ';
        break;
      case 'USD':
        format = 'en-US';
        break;
      case 'GBP':
        format = 'en-GB';
        break;
      case 'EUR':
        format = 'en-150';
        break;
      case 'CHF':
        format = 'en-CH';
        break;
      case 'CNH':
        format = 'en-CN';
        break;
      case 'HKD':
        format = 'en-HK';
        break;
      case 'INR':
        format = 'en-IN';
        break;
      case 'JPY':
        format = 'en-JP';
        break;
      default:
        format = 'en-US';
    }
    return value ? Intl.NumberFormat(format).format(value) : value;
  },
}

export default currencyIcon;