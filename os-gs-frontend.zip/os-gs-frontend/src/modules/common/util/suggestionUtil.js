import React from "react";
import { AsyncTypeahead } from "react-bootstrap-typeahead";
import "react-bootstrap-typeahead/css/Typeahead.css";

export default class SuggestionUtil extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            options: [],
            selectedItem: [],
            open: false
        };
    }

    handleSearch = (queryText) => {
        var classLength = document.getElementsByClassName("rbt").length;
        for (var i = 0; i < classLength; i++) {
            document.getElementsByClassName("rbt")[i].style.position = 'unset'
        }
        var tempArrayList = [];
        var isAlreadySelectedValue = false;
        this.props && this.props.options && this.props.options.filter(value => {

            if (this.getFilteredValue(value, queryText)) {
                if (this.props && this.props.selectedAttributeList && this.props.selectedAttributeList.length > 0) {
                    isAlreadySelectedValue = false;
                    for (var i = 0; i < this.props.selectedAttributeList.length; i++) {
                        for (var j = 0; j < this.props.selectedListKeys.length; j++) {
                            if (this.props.selectedAttributeList[i][this.props.selectedListKeys[j]]) {
                                if (this.getFilteredValue(value, this.props.selectedAttributeList[i][this.props.selectedListKeys[j]])) {
                                    isAlreadySelectedValue = this.props.reSelect ? false : true;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (!isAlreadySelectedValue) {
                    var tempObj = {};
                    for (var i = 0; i < this.props.searchOptionList.length; i++) {
                        if (this.props.searchOptionList[i] && value[this.props.searchOptionList[i]]) {
                            tempObj[this.props.searchOptionList[i]] = value[this.props.searchOptionList[i]];
                        }
                    }
                    tempObj.value = this.getSelectedValues(value);
                    tempArrayList.push(tempObj);
                }
            }
        });
        if (tempArrayList.length === 1) {
            const selectKeys = this.props.selectedListKeys;
            const selectKey = selectKeys[0];
            const selectKey1 = selectKeys[1];
            const suggestedProduct = tempArrayList[0][selectKey] || tempArrayList[0]['productId'] || tempArrayList[0]['ingredientId'];
            const suggestedProduct1 = tempArrayList[0][selectKey1];
            if (suggestedProduct && queryText && ((String(suggestedProduct).toLowerCase() === queryText.toLowerCase())
                || (suggestedProduct1 && String(suggestedProduct1).toLowerCase() === queryText.toLowerCase()))) {
                this.setState({ options: tempArrayList, selectedItem: tempArrayList, open: false });
                this.props.handleSuggestionChange(tempArrayList, this.props.id, this.props.searchOptionList, true);
            } else {
                this.setState({ options: tempArrayList, open: true });
            }
        } else {
            this.setState({ options: tempArrayList, open: true });
        }

    };


    getFilteredValue = (value, queryText) => {
        for (var i = 0; i < this.props.searchOptionList.length; i++) {
            if (value[this.props.searchOptionList[i]] &&
                String(value[this.props.searchOptionList[i]]).toLowerCase().indexOf(String(queryText).toLowerCase()) !== -1) {
                return true;
            }
        }
        return false;
    }

    getSelectedValues = (value) => {
        var tempValue = "";
        for (var i = 0; i < this.props.searchOptionList.length; i++) {
            if (value[this.props.searchOptionList[i]]) {
                if (i > 0 && tempValue) {
                    tempValue = tempValue + "|";
                }
                tempValue = tempValue + value[this.props.searchOptionList[i]];
            }
        }
        return tempValue;
    }

    customizedOnchange = (event) => {
        this.setState({ selectedItem: event, open: false });
        this.props.handleSuggestionChange(event, this.props.id, this.props.searchOptionList);
    }

    render() {
        const { ...rest } = this.props;
        return (
            <AsyncTypeahead
                {...rest}
                onChange={this.customizedOnchange}
                id="suggestion-dropdown"
                isLoading={false}
                labelKey="value"
                autoFocus={this.props.setNoFocus ? false : true}
                // open={this.state.open}
                minLength={1}
                selected={this.props.resetOnSelection ? [] : this.state.selectedItem}
                onSearch={this.handleSearch}
                options={this.state.options}
                defaultInputValue={this.props.selectedValue}
                placeholder={this.props.placeholder}
                onInputChange={this.props.onInputChange}
                renderMenuItemChildren={(option) => (
                    <div className="suggestion-items">{option.value}</div>
                )}
            />
        );
    }
}
