import React, { Component } from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import CommonUtil from './commonUtil';
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';
const CheckBoxUtil = {
  checkBoxAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
        <FormGroup>
          <ControlLabel>
            {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
          </ControlLabel>
          <CustomCheckbox inline key={tempAttributeListObj.name}
            number={tempAttributeListObj.name}
            disabled={tempAttributeListObj[actionMode] == 'disabled' ? true :
              tempAttributeListObj.isCustomDisabled ? true : false}
            checked={attributeObj[tempAttributeListObj.name]}
            label={tempAttributeListObj.label} onClick={tempAttributeListObj.customAttribute == true ? 
              (e) => that.handleCustomCheckBoxChange(e) : (e) => CommonUtil.handleCheckBoxChange(e, that)} />

          {tempAttributeListObj.extraMsg &&
            <small>
              {tempAttributeListObj.extraMsg}
            </small>
          }

          {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
            <small className="text-danger">
              {tempAttributeListObj.mandatoryMsgText}
            </small>
          }
        </FormGroup>
      </Col>

    )
  },

};

export default CheckBoxUtil;