import React from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import CommonUtil from './commonUtil';
import Datetime from "react-datetime";
import moment from "moment";

const yesterday = moment().subtract(1, 'day');
const disablePastDt = current => {
    return current.isAfter(yesterday);
};

const today = moment();
const disableFutureDt = current => {
    return current.isBefore(today)
}

const DateUtil = {
    dateAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
        return (
            <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                <FormGroup>
                    <ControlLabel>
                        {tempAttributeListObj.label}
                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                    </ControlLabel>
                    <Datetime
                        id={tempAttributeListObj.name}
                        timeFormat={false}
                        closeOnSelect={true}
                        isValidDate={tempAttributeListObj.backDateNotAllowed ? disablePastDt :
                            tempAttributeListObj.futureDateNotAllowed ? disableFutureDt : ''}
                        inputProps={{
                            readOnly: true,
                            placeholder: tempAttributeListObj.placeholder,
                            disabled: tempAttributeListObj[actionMode] == 'disabled' ? true : false,
                            title: CommonUtil.getFormattedDate(attributeObj[tempAttributeListObj.name])
                        }}
                        name={tempAttributeListObj.name}
                        onChange={(moment) => CommonUtil.handleDateChange(moment, tempAttributeListObj.name, that)}
                        dateFormat="MM-DD-YYYY"
                        value={moment(attributeObj[tempAttributeListObj.name])}
                    />

                    {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                        <small className="text-danger">
                            {tempAttributeListObj.mandatoryMsgText}
                        </small>
                    }
                </FormGroup>
            </Col>
        )
    },
};

export default DateUtil;