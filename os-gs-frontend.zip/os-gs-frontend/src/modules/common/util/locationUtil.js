import csc from 'country-state-city';

const LocationUtil = {
  populateStateList: async function (locationlist, country) {
    let countryList;

    for (let i = 0; i < locationlist.length; i++) {
      if (locationlist[i].name == 'country') {
        countryList = locationlist[i].options;
        break;
      }
    }

    for (let i = 0; i < countryList.length; i++) {
      if (countryList[i].label == country) {
        await this.getStateList(locationlist,
          countryList[i].value);
        break;
      }
    }
  },
  populateCityList: async function (locationlist, state) {
    let stateList;

    for (let i = 0; i < locationlist.length; i++) {
      if (locationlist[i].name == 'state') {
        stateList = locationlist[i].options;
        break;
      }
    }

    for (let i = 0; i < stateList.length; i++) {
      if (stateList[i].label == state) {
        await this.getCityList(locationlist,
          stateList[i].value);
        break;
      }
    }
  },
  updateLocationTextChange: async function (event, that) {
    const { name, value } = event.target;
    const { locationAttributeObj } = that.state;
    await that.setState({
      locationAttributeObj: {
        ...locationAttributeObj,
        [name]: value
      }, function() {
      }
    })
  },
  updateLocationNumberChange: async function (event, that) {
        const { name, value } = event.target;
        const { locationAttributeObj } = that.state;
        const re = /^[0-9\b]+$/;
        if (value === '' || re.test(value)) {
          await  that.setState({
                locationAttributeObj: {
                    ...locationAttributeObj,
                    [name]: value,
                }
            })
        } else {
          await  that.setState({
                locationAttributeObj: {
                    ...locationAttributeObj,
                    [name]: value.substring(0, value.length - 1),
                }
            })
        }
    },
  updateLocationDropDownChange: async function (event, obj, that) {
    const { locationAttributeObj } = that.state;
    if (obj.name === 'country') {
      locationAttributeObj.state = '';
      locationAttributeObj.city = '';
      locationAttributeObj.zipcode ='';
      LocationUtil.getStateList(that.state.attributeListLocation,
        event.value)
    }
    if (obj.name === 'state') {
      locationAttributeObj.city = '';
      locationAttributeObj.zipcode ='';
      LocationUtil.getCityList(that.state.attributeListLocation,
        event.value)
    }
    await that.setState({
      locationAttributeObj: {
        ...locationAttributeObj,
        [obj.name]: event.label
      }, function() {
      }
    })
  },
  handleLocationDropDownChange: async function (event, obj, that) {
    const { attributeObj } = that.state;
    if (obj.name === 'country') {
      attributeObj.state = '';
      attributeObj.city = '';
      attributeObj.zipcode = '';
      await this.getStateList(that.state.attributeList,
        event.value)
    }
    if (obj.name === 'state') {
      attributeObj.city = '';
      attributeObj.zipcode = '';
      await this.getCityList(that.state.attributeList,
        event.value)
    }
    await that.setState({
      attributeObj: {
        ...attributeObj,
        [obj.name]: event.label
      }
    })
  },
  updateLocationListObj: function (that,isDefault) {
    var tempLocationList = [];
    for (var i = 0; i < that.state.attributeObj.locations.length; i++) {
      if (that.state.selectedLocationId != i) {
        if(isDefault){
          that.state.attributeObj.locations[i].isDefault = false;
        }
        tempLocationList.push(that.state.attributeObj.locations[i]);
      }
    }
    return tempLocationList;
  },

  getCountryList: function (attributeList) {
    var allContryList = csc.getAllCountries();
    var validParams = attributeList != null && attributeList.length > 0 &&
      allContryList != null && allContryList.length > 0;
    if (validParams) {
      var tempAttributeList = [...attributeList];
      for (var i = 0; i < attributeList.length; i++) {
        if (attributeList[i].isCountry) {
          tempAttributeList[i].options = [];
          for (var j = 0; j < allContryList.length; j++) {
            var tempObj = {}
            tempObj.value = allContryList[j].id;
            tempObj.label = allContryList[j].name;
            tempAttributeList[i].options.push(tempObj);
          }
        }
        if (attributeList[i].isState || attributeList[i].isCity) {
          tempAttributeList[i].options = [];
        }
      }
      return tempAttributeList;
    }
    return attributeList;
  },

  getStateList: function (attributeList, id) {
    var allStateList = csc.getStatesOfCountry(id);
    var validParams = attributeList != null && attributeList.length > 0 &&
      allStateList != null && allStateList.length > 0;
    if (validParams) {
      var tempAttributeList = [...attributeList];
      for (var i = 0; i < attributeList.length; i++) {
        if (attributeList[i].isState) {
          tempAttributeList[i].options = [];
          for (var j = 0; j < allStateList.length; j++) {
            var tempObj = {}
            tempObj.value = allStateList[j].id;
            tempObj.label = allStateList[j].name;
            tempAttributeList[i].options.push(tempObj);
          }
        }
        if (attributeList[i].isCity) {
          tempAttributeList[i].options = [];
        }
      }
      return tempAttributeList;
    }
    return attributeList;
  },
  getCityList: function (attributeList, id) {
    var allCityList = csc.getCitiesOfState(id);
    var validParams = attributeList != null && attributeList.length > 0 &&
      allCityList != null && allCityList.length > 0;
    if (validParams) {
      var tempAttributeList = [...attributeList];
      for (var i = 0; i < attributeList.length; i++) {
        if (attributeList[i].isCity) {
          tempAttributeList[i].options = [];
          for (var j = 0; j < allCityList.length; j++) {
            var tempObj = {}
            tempObj.value = allCityList[j].id;
            tempObj.label = allCityList[j].name;
            tempAttributeList[i].options.push(tempObj);
          }
        }
      }
      return tempAttributeList;
    }
    return attributeList;
  }
};

export default LocationUtil;