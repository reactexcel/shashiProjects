import React, { Component } from "react";
import { Col, FormGroup, ControlLabel } from "react-bootstrap";
import CustomRadio from "../../../components/CustomRadio/CustomRadio";
import CommonUtil from './commonUtil';

const RadioButtonUtil = {
  radioButtonAttribute: function (tempAttributeListObj, index, attributeObj, submitted, that, actionMode) {
    console.log(tempAttributeListObj)
    return (
      <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index} className="product-checkbox">
        <FormGroup style={{ width: '100%' }}>
          <div>
            <ControlLabel style={{ textTransform: 'none' }}>
              {tempAttributeListObj.label}
              {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
            </ControlLabel>
          </div>
          <div className="source-btn">
            
            {
            tempAttributeListObj.checkList.map((check, Nestedindex) => {
              return (
                <Col md={4} key={Nestedindex}>
                  <CustomRadio key={Nestedindex} name={check.name} number={check.name} label={check.label}
                    onChange={(e) => CommonUtil.handleRadioButtonsChange(e, that)} value={check.value}
                    disabled={CommonUtil.isViewMode(actionMode) ? true : false}
                    checked={attributeObj[tempAttributeListObj.name] == check.value} />
                </Col>
              )
            })}
          </div>
        </FormGroup>
      </Col>

    )
  },

};

export default RadioButtonUtil;