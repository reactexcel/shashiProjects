import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from '../../../components/Card/Card.jsx';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "./pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import LocationUtil from "../../common/util/locationUtil";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DropDownUtil from "modules/common/util/dropDownUtil";
import { Redirect } from "react-router-dom";
import LocationDetails from './LocationDetails';
import { setSupplierDetails, setReducerInitMode } from "../../supplierManagementFp/actions/supplierActions";
import ValidationUtil from '../../common/util/validationUtil';
import * as commonConstant from '../../common/constant/commonConstant';
var Modal = require('react-bootstrap-modal')

class CreateSupplierModalFp extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeListLocation: null,
      attributeObj: null,
      submitted: false,
      alert: null,
    };
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.getLocationDetails = this.getLocationDetails.bind(this);
    this.handleLocationChange = this.handleLocationChange.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    let commonAttributeList = pagePropertyListConstant.CREATE_SUPPLIER_PAGE_LIST_FP;
    let tempAttributeobj = commonAttributeList.attributeObj;
    const locationPageList = pagePropertyListConstant.LOCATION_PAGE_LIST;
    tempAttributeobj.locations = [locationPageList.attributeObj];
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
      attributeListLocation: LocationUtil.getCountryList(locationPageList.attributeList)
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  closeModal = (event) => {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
        CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
        facilityId: CommonUtil.isCloneMode(commonConstant.CREATE_ACTION_MODE) ?
          '' : attributeObj.facilityId
      }
    })
  }

  handleLocationChange(locationAttributeObj) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        locations: [locationAttributeObj]
      }
    });
  }

  handlePopupCancel() {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  maxLengthCheck = (object, maxLength) => {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  handleSave = async (event) => {
    this.setState({ submitted: true, alert: null });

    var tempObj = this.state.attributeObj;
    var actionMode = commonConstant.CREATE_ACTION_MODE;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, actionMode);
    tempObj.products = [];
    // tempObj.ingredients = [];    

    if (this.isValidRequestObj(tempObj)) {
      this.props.setSupplierDetails(tempObj, actionMode);
    }
  }

  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }

    if (!ValidationUtil.validateCreateRequestObj(tempObj.locations[0], this.state.attributeListLocation)) {
      return false;
    }

    return true;
  }

  getLocationDetails = (locationAttributeObj) => {
    this.handleLocationChange({ ...locationAttributeObj });
  }

  saveAttributeObj = (locationAttributeObj) => {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        locations: [locationAttributeObj]
      }
    });
  }
  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }
  render() {
    const { attributeList, attributeObj, attributeListLocation, submitted, customErrorFlag } = this.state;
    const actionMode = commonConstant.CREATE_ACTION_MODE;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              Create Supplier
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <div className="supplier-section">
                <Row>
                    <Col md={12}>
                      <form>
                        <Row className="content-section">
                          {attributeList != null &&
                            attributeList.map((tempAttributeListObj, index) =>

                              tempAttributeListObj.type == "TEXTBOX" &&
                                tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                                : tempAttributeListObj.type == "DROPDOWN" &&
                                  tempAttributeListObj[actionMode + "ShowFlag"] == true ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                  : null
                            )}
                        </Row>
                      </form>
                    </Col>
                </Row>
                <Row>
                  <Col md={12}>
                    <form>
                      <div className="content-section">
                        {attributeListLocation != null &&
                          <LocationDetails attributeList={attributeListLocation}
                            attributeObj={attributeObj.locations[0]}
                            getLocationDetails={this.getLocationDetails}
                            submitted={submitted}
                            saveAttributeObj={this.saveAttributeObj}
                          />
                          }
                      </div>
                    </form>
                  </Col>
                </Row>
                  <Row>
                    <Col md={12}>
                      <form>
                        <Card
                          ftTextRight
                          legend={
                            CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>
                                  Cancel
                                </Button>
                              </div>
                            : <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>
                                  Cancel
                                </Button>

                                <Button className="btn-save btn-fill btn-wd" onClick={this.handleSave}>
                                  Save
                                </Button>
                              </div>
                          }
                        />
                      </form>
                    </Col>
                  </Row>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = (dispatch) => ({
  setSupplierDetails: (supplierDetailsObj, actionMode) => dispatch(setSupplierDetails(supplierDetailsObj, actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init))
});
export default connect(mapStateToProps, mapDispatchToProps)(CreateSupplierModalFp);
