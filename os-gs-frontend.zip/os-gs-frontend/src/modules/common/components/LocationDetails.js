import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl } from "react-bootstrap";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { touch } from "redux-form";
import LocationUtil from "modules/common/util/locationUtil";

class LocationDetails extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: this.props.attributeList,
      attributeObj: this.props.attributeObj
    };
  }

  componentDidMount = () => {
    if (this.props.attributeList != null) {
      this.setState({
        attributeList: this.props.attributeList,
        attributeObj: this.props.attributeObj,
      })
    }
  }

  componentDidUpdate(prevProps) {
    if (this.state.attributeObj != null && prevProps.attributeObj != this.state.attributeObj) {
      this.setState({
        attributeObj: this.state.attributeObj,
      });
      this.props.saveAttributeObj(this.state.attributeObj);
    }
  }

  
  maxLengthCheck = (object, maxLength) => {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  };

  render() {
    const { attributeList, attributeObj } = this.state;
    return (
      <Row>
        {this.props.attributeList != null && this.props.attributeList.map((tempAttributeListObj, index) => (
          tempAttributeListObj.type == "TEXTBOX" ?
            <Col md={tempAttributeListObj.fieldWidth} key={index}>
              <FormGroup>

                {tempAttributeListObj.label}
                {tempAttributeListObj.required == true ? <span className="star">*</span> : null}

                <FormControl rows={tempAttributeListObj.numberOfRow}
                  componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                  name={tempAttributeListObj.name}
                  value={attributeObj[tempAttributeListObj.name]}
                  onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                  maxLength={tempAttributeListObj.maxLength}
                  minLength={tempAttributeListObj.minLength}
                  onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
                  onChange={(e) => {
                    this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                    tempAttributeListObj.inputType == "number" ?
                      CommonUtil.handleNumberChange(e, this) :
                      CommonUtil.handleTextBoxChange(e, this)
                    this.props.getLocationDetails(this.state.attributeObj);
                  }} />

                {this.props.submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                  <small className="text-danger">
                    {tempAttributeListObj.mandatoryMsgText}
                  </small>
                }
                {(touch || this.props.submitted) && tempAttributeListObj.maxLength && attributeObj[tempAttributeListObj.name] &&
                  +attributeObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                  <small className="text-danger">
                    Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                  </small>
                }
                {(touch || this.props.submitted) && tempAttributeListObj.minLength && attributeObj[tempAttributeListObj.name] &&
                  +attributeObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                  <small className="text-danger">
                    Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                  </small>
                }


              </FormGroup>
            </Col>

            : tempAttributeListObj.type == "DROPDOWN" ?
              <Col md={tempAttributeListObj.fieldWidth} key={index}>
                <FormGroup>
                  {tempAttributeListObj.label}
                  {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                  <Select name={tempAttributeListObj.name}
                    onChange={(e, obj) => {
                      LocationUtil.handleLocationDropDownChange(e, obj, this).then(() => {
                        this.props.getLocationDetails(this.state.attributeObj);
                      });
                    }}
                    isMulti={tempAttributeListObj.isMulti}
                    value={{ "label": attributeObj[tempAttributeListObj.name] }}
                    classNamePrefix="react-select"
                    placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options} />
                  {this.props.submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                    <small className="text-danger">
                      {tempAttributeListObj.mandatoryMsgText}
                    </small>
                  }
                </FormGroup>
              </Col>

              : null
        ))
        }
      </Row>
    );
  }
}

export default LocationDetails;

