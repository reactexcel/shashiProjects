import React from 'react';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { checkoutPlans } from "../actions/billingActions";

class PopuPlans extends React.Component {
    handleSave = () => {
        this.props.checkoutPlans();
    }
    render() {
        return (
            <div>
                <h1>Hello World</h1>
                <Button className="btn-save btn-fill" onClick={this.handleSave}>Buy Plan</Button>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        productList: state.product.productList,
    }
}
export default connect(mapStateToProps, { checkoutPlans })(withRouter(PopuPlans));
