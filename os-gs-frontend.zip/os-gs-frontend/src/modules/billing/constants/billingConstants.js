const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const BILLING_PUBLISHABLE_KEY = process.env.REACT_APP_BILLING_PK;
export const PLANS_CHECKOUT_URL = `${BASE_URL}/plans/checkout`;
export const GET_PRICES = `${BASE_URL}/prices`;
export const USER_IS_ACTIVE = `${BASE_URL}/users/isActive`;