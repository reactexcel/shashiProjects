import React from "react";
import healing24 from "../../assets/healing-24px.png";
import spa24 from "../../assets/spa-24px.png";
import maskGroup5 from "../../assets/MaskGroup5.png";
import maskGroup4 from "../../assets/MaskGroup4.png";
import CKEditor from "ckeditor4-react";

const ProductVitals = ({ closeProductVitals }) => {
  const styleInfo = { marginTop: "30px" };
  return (
    <div className="hoverWrapper">
      <div id="hoverShow1">
        <ul className="hoversetting">
          <li>
            <button className="hoverbuttons" onClick={closeProductVitals}>
              Delete
            </button>
          </li>
          <li>
            <button className="hoverbuttons">Setting</button>
          </li>
        </ul>
      </div>
      <div className="container">
        <div className="row mb-5">
          <h3
            className="text-center mb-4"
            style={{ width: "100%", marginTop: "30px" }}
          >
            <CKEditor
              type="inline"
              data={`
              <div id="introduction11">Product Vitals</div>
                `}
            />
          </h3>
          <div className="col-lg-3 col-xs-6">
            <div className="hoverWrapper">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div className="pv1">
                <div id="introduction7">
                  <CKEditor
                    type="inline"
                    data={`
              <p>
              <img
                src=${healing24}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </p>
            <p> Healing</p>
                `}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-3 col-xs-6">
            <div className="hoverWrapper">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div className="pv1">
                <div id="introduction8">
                  <CKEditor
                    type="inline"
                    data={`
              <p>
              <img
                src=${spa24}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </p>
            <p>Therapeutic</p>
                `}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-3 col-xs-6">
            <div className="hoverWrapper">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div className="pv1">
                <div id="introduction9">
                  <CKEditor
                    type="inline"
                    data={`
                    <p>
                    <img
                      src=${maskGroup5}
                      alt="Simply Easy Learning"
                      style=${styleInfo}
                    />
                  </p>
                  <p> Soothing</p>
                `}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-3 col-xs-6">
            <div className="hoverWrapper">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div className="pv1">
                <div id="introduction10">
                  <CKEditor
                    type="inline"
                    data={`
              <p>
              <img
                src=${maskGroup4}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </p>
            <p> Natural</p>
                `}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductVitals;
