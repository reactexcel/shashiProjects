import React from "react";

const TraceabilityScore = ({ closeTraceabilityScore }) => {
  return (
    <div
      className="hoverWrapper"
      style={{ background: "#daf0ff", padding: "40px" }}
    >
      <div className="row">
        <div className="col">
          <div id="hoverShow2">
            <ul className="hoversetting">
              <li>
                <button
                  className="hoverbuttons"
                  onClick={closeTraceabilityScore}
                >
                  Delete
                </button>
              </li>
              <li>
                <button className="hoverbuttons">Setting</button>
              </li>
            </ul>
          </div>
          <div className="progress blue">
            <span className="progress-left">
              <span className="progress-bar"></span>
            </span>
            <span className="progress-right">
              <span className="progress-bar"></span>
            </span>
            <div className="progress-value">90%</div>
          </div>
          <h4 className="text-center m-2">
            <div id="introduction21">OVERALL TRACEABILITY SCORE</div>
          </h4>
        </div>
      </div>
    </div>
  );
};

export default TraceabilityScore;
