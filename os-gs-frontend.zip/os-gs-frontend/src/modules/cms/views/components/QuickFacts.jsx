import React from "react";
import CKEditor from "ckeditor4-react";
import local_library from "../../assets/local_library-24px.png";

const QuickFacts = ({ closeQuickFacts }) => {
  return (
    <div className="row">
      <div className="col-lg-3 hide-xs"></div>
      <div className="col-lg-6 col-xs-12">
        <div className="hoverWrapper">
          <div id="hoverShow2">
            <ul className="hoversetting">
              <li>
                <button className="hoverbuttons" onClick={closeQuickFacts}>
                  Delete
                </button>
              </li>
              <li>
                <button className="hoverbuttons">Setting</button>
              </li>
            </ul>
          </div>
          <div id="introduction3" style={{ padding: "15px" }}>
            <CKEditor
              type="inline"
              data={`
                <h3>
                <img
                  src=${local_library}
                  alt="Simply Easy Learning"
                  style=${{ marginRight: "10px" }}
                />
                Quick Facts
              </h3>
              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry.
              </p>
                `}
            />
          </div>
        </div>
        <div className="col-lg-3 hide-xs"></div>
      </div>
    </div>
  );
};

export default QuickFacts;
