import React from "react";

const TraceabilityMap = ({ closeMap }) => {
  return (
    <div className="row">
      <div className="col">
        <div className="hoverWrapper">
          <div id="hoverShow2">
            <ul className="hoversetting">
              <li>
                <button className="hoverbuttons" onClick={closeMap}>
                  Delete
                </button>
              </li>
              <li>
                <button className="hoverbuttons">Setting</button>
              </li>
            </ul>
          </div>
          <div className="mapsection">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26519.17964747974!2d150.991223106839!3d-33.81495926293101!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12a2e0e3114a79%3A0x391712577a04a8ca!2sOld%20Government%20House!5e0!3m2!1sen!2sin!4v1592132425063!5m2!1sen!2sin"
              style={{ width: "100%", height: "450px", border: "0" }}
              title="mapTitle"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TraceabilityMap;
