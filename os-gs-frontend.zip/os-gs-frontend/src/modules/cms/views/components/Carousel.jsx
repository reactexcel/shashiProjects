import React, { useState } from "react";
import banner1Image from "../../assets/banner1.png";
import banner2Image from "../../assets/banner2.png";
import FileUploadModal from "./FileUploadModal";
const banner1 = "url(" + { banner1Image } + ")";
const banner2 = "url(" + { banner2Image } + ")";

const Carousel = ({ closeCarousel }) => {
  const [showSettingsModal, setSettingsModal] = useState(false);
  const [fileUrl1, setFileUrl1] = useState();
  const [fileUrl2, setFileUrl2] = useState();

  const closeModal = () => {
    setSettingsModal(false);
  };

  const handleFile1Change = (e) => {
    const fileUrl = URL.createObjectURL(e.target.files[0]);
    setFileUrl1(fileUrl);
  };

  const handleFile2Change = (e) => {
    const fileUrl = URL.createObjectURL(e.target.files[0]);
    setFileUrl2(fileUrl);
  };

  return (
    <React.Fragment>
      <div
        id="carouselExampleIndicators"
        className="carousel slide"
        data-ride="carousel"
      >
        <ol className="carousel-indicators">
          <li
            data-target="#carouselExampleIndicators"
            data-slide-to="0"
            className="active"
          ></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div className="carousel-inner hoverWrapper">
          <div id="hoverShow1">
            <ul className="hoversetting">
              <li>
                <button className="hoverbuttons" onClick={closeCarousel}>
                  Delete
                </button>
              </li>
              <li>
                <button
                  className="hoverbuttons"
                  onClick={() => setSettingsModal(true)}
                >
                  Setting
                </button>
              </li>
            </ul>
          </div>
          <div
            className="carousel-item active"
            style={{
              minHeight: "150px",
              maxHeight: "500px",
              backgroundImage: banner1,
            }}
          >
            <div id="dvPreview">
              {fileUrl1 && <img src={fileUrl1} alt="Image1"></img>}
            </div>
          </div>
          <div
            className="carousel-item"
            style={{
              minHeight: "150px",
              maxHeight: "500px",
              backgroundImage: banner2,
            }}
          >
            <div id="dvPreviewa">
              {fileUrl2 && <img src={fileUrl2} alt="Image2" />}
            </div>
          </div>
        </div>
      </div>
      {showSettingsModal && (
        <FileUploadModal
          closeModal={closeModal}
          handleFile1Change={handleFile1Change}
          handleFile2Change={handleFile2Change}
        />
      )}
    </React.Fragment>
  );
};

export default Carousel;
