import React from "react";

const SettingsModal = ({ closeModal, setNumberOfColumn }) => {
  return (
    <div className="modal" id="myModal1">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h4 className="modal-title">Setting</h4>
            <button
              type="button"
              className="close"
              data-dismiss="modal"
              onClick={closeModal}
            >
              &times;
            </button>
          </div>

          <div className="modal-body">
            <input
              type="radio"
              name="tab"
              value="igottwo"
              onClick={() => setNumberOfColumn(1)}
            />
            One column
            <input
              type="radio"
              name="tab"
              value="igottwo"
              onClick={() => setNumberOfColumn(2)}
            />
            Two columns
            <input
              type="radio"
              name="tab"
              value="igottwo"
              onClick={() => setNumberOfColumn(3)}
            />
            Three columns
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
