import React from "react";
import sj1 from "../../assets/SJ-1.png";
import sj2 from "../../assets/SJ-2.png";
import group43 from "../../assets/Group43.png";
import CKEditor from "ckeditor4-react";

const Blog = ({ closeBlog }) => {
  const styleInfo = { width: "100%" };
  return (
    <div style={{ background: "#ffffff" }}>
      <div className="hoverWrapper">
        <div id="hoverShow1">
          <ul className="hoversetting">
            <li>
              <button className="hoverbuttons" onClick={closeBlog}>
                Delete
              </button>
            </li>
            <li>
              <button className="hoverbuttons">Setting</button>
            </li>
          </ul>
        </div>
        <div className="container">
          <div className="row">
            <h3
              className="text-center mb-4"
              style={{ width: "100%", marginTop: "30px" }}
            >
              <CKEditor
                type="inline"
                data={`
              <div id="introduction18">Blog</div>
                `}
              />
            </h3>
            <div className="col-lg-4 col-xs-12">
              <div className="hoverWrapper">
                <div id="hoverShow2">
                  <ul className="hoversetting">
                    <li>
                      <button className="hoverbuttons">Delete</button>
                    </li>
                  </ul>
                </div>
                <div id="introduction15">
                  <CKEditor
                    type="inline"
                    data={`
              <div className="recommendationssection mb-3">
              <img
                src=${sj1}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </div>
            <h3>The Secrets of Scents</h3>
            <p>
              Today everyone wants to live a good and healthy life, and
              for that, people work hard, eat healthy, try to make better…
            </p>
                `}
                  />
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-xs-12">
              <div className="hoverWrapper">
                <div id="hoverShow2">
                  <ul className="hoversetting">
                    <li>
                      <button className="hoverbuttons">Delete</button>
                    </li>
                  </ul>
                </div>
                <div id="introduction16">
                  <CKEditor
                    type="inline"
                    data={`
                    <div className="recommendationssection mb-3">
                    <img
                      src=${sj2}
                      alt="Simply Easy Learning"
                      style=${styleInfo}
                    />
                  </div>
                  <h3>The Art of Blending Oils</h3>
                  <p>
                    Today everyone wants to live a good and healthy life, and
                    for that, people work hard, eat healthy, try to make better…
                  </p>
                `}
                  />
                </div>
              </div>
            </div>

            <div className="col-lg-4 col-xs-12">
              <div className="hoverWrapper">
                <div id="hoverShow2">
                  <ul className="hoversetting">
                    <li>
                      <button className="hoverbuttons">Delete</button>
                    </li>
                  </ul>
                </div>
                <div id="introduction17">
                  <CKEditor
                    type="inline"
                    data={`
                    <div className="recommendationssection mb-3">
                    <img
                      src=${sj1}
                      alt="Simply Easy Learning"
                      style=${styleInfo}
                    />
                  </div>
                  <h3>The Secrets of Scents</h3>
                  <p>
                    Today everyone wants to live a good and healthy life, and
                    for that, people work hard, eat healthy, try to make better…
                  </p>
                `}
                  />
                </div>
              </div>
            </div>

            <h3
              className="text-center"
              style={{
                width: "100%",
                marginTop: "20px",
                borderBottom: "solid 1px #ccc",
              }}
            >
              <button>
                <img
                  style={{ paddingBottom: "30px" }}
                  src={group43}
                  alt="Simply Easy Learning"
                />
              </button>
            </h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Blog;
