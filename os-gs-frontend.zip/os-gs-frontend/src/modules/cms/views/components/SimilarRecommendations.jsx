import React, { useState } from "react";
import zeroTwo from "../../assets/02.jpg";
import zeroThree from "../../assets/03.jpg";
import group51 from "../../assets/Group51.png";
import SettingsModal from "./SettingsModal";
import CKEditor from "ckeditor4-react";

const SimilarRecommendations = ({ closeRecommendations }) => {
  const [showSettingsModal, setSettingsModal] = useState(false);
  const [numberOfColumn, setNumberOfColumn] = useState(1);
  const closeModal = () => {
    setSettingsModal(false);
  };
  const styleInfo = { width: "100%" };
  return (
    <React.Fragment>
      <div className="hoverWrapper">
        <div id="hoverShow1">
          <ul className="hoversetting">
            <li>
              <button className="hoverbuttons" onClick={closeRecommendations}>
                Delete
              </button>
            </li>
            <li>
              <button
                className="hoverbuttons"
                onClick={() => setSettingsModal(true)}
              >
                Setting
              </button>
            </li>
          </ul>
        </div>

        <div
          className="pb-2"
          style={{ background: "#ffffff", paddingTop: "40px" }}
        >
          <div className="container">
            <h3 className="text-center mb-4" style={{ width: "100%" }}>
              <div id="introduction12">
                <CKEditor
                  type="inline"
                  data={`
              <h1>Similar Recommendations </h1>
                `}
                />
              </div>
            </h3>
            {numberOfColumn === 1 && (
              <div id="div0">
                <div className="row">
                  <div className="col">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>

                      <div className="row">
                        <div className="col-lg-4">
                          <div id="introduction19">
                            <div className="recommendationssection mb-3">
                              <CKEditor
                                type="inline"
                                data={`
              <img
              src=${zeroTwo}
              alt="Simply Easy Learning"
              style=${styleInfo}
            />
                `}
                              />
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-8">
                          <div id="introduction13" className="pt-5">
                            <CKEditor
                              type="inline"
                              data={`
                            <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
                            <p>
                              Lorem Ipsum is simply dummy text of the printing and
                              typesetting industry.
                            </p>
                `}
                            />
                          </div>
                          <button
                            type="button"
                            className="btn btn-success btn-sm"
                          >
                            Buy Now
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {numberOfColumn === 2 && (
              <div id="div1">
                <div className="row">
                  <div className="col-lg-6 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>
                      <div id="introduction13">
                        <CKEditor
                          type="inline"
                          data={`
              <div className="recommendationssection mb-3">
              <img
                src=${zeroTwo}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </div>
            <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
            <p>
              Lorem Ipsum is simply dummy text of the printing and
              typesetting industry.
            </p>
                `}
                        />
                      </div>
                      <button type="button" className="btn btn-success btn-sm">
                        Buy Now
                      </button>
                    </div>
                  </div>

                  <div className="col-lg-6 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>
                      <div id="introduction14">
                        <CKEditor
                          type="inline"
                          data={`
              <div className="recommendationssection mb-3">
              <img
                src=${zeroThree}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </div>
            <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
            <p>
              Lorem Ipsum is simply dummy text of the printing and
              typesetting industry.
            </p>
                `}
                        />
                      </div>
                      <button type="button" className="btn btn-success btn-sm">
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {numberOfColumn === 3 && (
              <div id="div2">
                <div className="row">
                  <div className="col-lg-4 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>
                      <div id="introduction13">
                        <CKEditor
                          type="inline"
                          data={`
                        <div className="recommendationssection mb-3">
                        <img
                          src=${zeroTwo}
                          alt="Simply Easy Learning"
                          style=${styleInfo}
                        />
                      </div>
                      <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
                      <p>
                        Lorem Ipsum is simply dummy text of the printing and
                        typesetting industry.
                      </p>
                `}
                        />
                      </div>
                      <button type="button" className="btn btn-success btn-sm">
                        Buy Now
                      </button>
                    </div>
                  </div>

                  <div className="col-lg-4 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>
                      <div id="introduction14">
                        <CKEditor
                          type="inline"
                          data={`
              <div className="recommendationssection mb-3">
              <img
                src=${zeroThree}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </div>
            <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
            <p>
              Lorem Ipsum is simply dummy text of the printing and
              typesetting industry.
            </p>

                `}
                        />
                      </div>
                      <button type="button" className="btn btn-success btn-sm">
                        Buy Now
                      </button>
                    </div>
                  </div>
                  <div className="col-lg-4 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <button className="hoverbuttons">Delete</button>
                          </li>
                        </ul>
                      </div>
                      <div id="introduction14">
                        <CKEditor
                          type="inline"
                          data={`
              <div className="recommendationssection mb-3">
              <img
                src=${zeroThree}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
            </div>
            <h3>Aura Fuchsia 100% Eucalyptus - Essential Oil </h3>
            <p>
              Lorem Ipsum is simply dummy text of the printing and
              typesetting industry.
            </p>
                `}
                        />
                      </div>
                      <button type="button" className="btn btn-success btn-sm">
                        Buy Now
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
            <h3
              className="text-center mb-4"
              style={{
                width: "100%",
                marginTop: "40px",
                borderBottom: "solid 1px #ccc",
              }}
            >
              <button>
                <img
                  style={{ paddingBottom: "30px" }}
                  src={group51}
                  alt="Simply Easy Learning"
                />
              </button>
            </h3>
          </div>
        </div>
      </div>
      {showSettingsModal && (
        <SettingsModal
          setNumberOfColumn={setNumberOfColumn}
          closeModal={closeModal}
        />
      )}
    </React.Fragment>
  );
};

export default SimilarRecommendations;
