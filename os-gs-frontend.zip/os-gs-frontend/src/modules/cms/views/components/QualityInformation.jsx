import React from "react";
import group35 from "../../assets/Group35.png";
import group38 from "../../assets/Group38.png";
import group39 from "../../assets/Group39.png";
import CKEditor from "ckeditor4-react";

const QualityInformation = ({ closeQualityInformation }) => {
  const styleInfo = { marginRight: "10px" };
  return (
    <div
      className="hoverWrapper mb-2"
      style={{ backgroundColor: "#d1ebeb", padding: "30px" }}
    >
      <div id="hoverShow1">
        <ul className="hoversetting">
          <li>
            <button className="hoverbuttons" onClick={closeQualityInformation}>
              Delete
            </button>
          </li>
          <li>
            <button className="hoverbuttons">Setting</button>
          </li>
        </ul>
      </div>
      <div className="container">
        <div className="row">
          <h3
            className="text-center mb-2"
            style={{ width: "100%", marginTop: "30px" }}
          >
            <CKEditor
              type="inline"
              data={`
              <div id="introduction5">Quality Information</div>
                `}
            />
          </h3>
          <div className="col-lg-4 col-sm-12">
            <div className="hoverWrapper qisection">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div id="introduction1" style={{ paddingTop: "20px" }}>
                <CKEditor
                  type="inline"
                  data={`
              <h4 className="qisection">
              <img
                src=${group35}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
              Quality Certificates
            </h4>
                `}
                />
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-12">
            <div className="hoverWrapper qisection">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div id="introduction2" style={{ paddingTop: "20px" }}>
                <CKEditor
                  type="inline"
                  data={`
              <h4 className="qisection">
              <img
                src=${group38}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
              Compliance Information
            </h4>
                `}
                />
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-sm-12">
            <div className="hoverWrapper qisection">
              <div id="hoverShow2">
                <ul className="hoversetting">
                  <li>
                    <button className="hoverbuttons">Delete</button>
                  </li>
                </ul>
              </div>
              <div id="introduction4" style={{ paddingTop: "20px" }}>
                <CKEditor
                  type="inline"
                  data={`
              <h4 className="qisection">
              <img
                src=${group39}
                alt="Simply Easy Learning"
                style=${styleInfo}
              />
              Fair Trade Information
            </h4>
                `}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QualityInformation;
