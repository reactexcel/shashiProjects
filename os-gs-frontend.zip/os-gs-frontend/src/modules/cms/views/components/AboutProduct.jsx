import React from "react";
import CKEditor from "ckeditor4-react";

const AboutProduct = ({ closeAboutProduct }) => {
  return (
    <div className="row">
      <div className="hoverWrapper">
        <div className="col">
          <div className="textboxaboutproduct">
            <div id="introduction" style={{ padding: "15px" }}>
              <CKEditor
                type="inline"
                data={`
                <h2>Main Heading</h2>
                <p className="editor-title">
                    <b>Second Heading</b>
                </p>

                <p>
                    Lorem Ipsum is simply dummy text of the printing and typesetting
                    industry. Lorem Ipsum has been the industry's standard dummy
                    text ever since the 1500
                </p>
                `}
              />
            </div>
            <div id="hoverShow2">
              <ul className="hoversetting">
                <li>
                  <button className="hoverbuttons" onClick={closeAboutProduct}>
                    Delete
                  </button>
                </li>
                <li>
                  <button className="hoverbuttons">Setting</button>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutProduct;
