import React from "react";
import footerSub from "../../assets/footer-sub.png";

const Footer = () => {
  return (
    <div className="pt-3 pb-3" style={{ background: "#323232" }}>
      <div className="container">
        <div className="row">
          <div className="col-lg-6 col-xs-12">
            <div id="introduction18">
              <img src={footerSub} alt="Simply Easy Learning" />
            </div>
          </div>
          <div className="col-lg-6 col-xs-12" style={{ float: "right" }}>
            <p style={{ color: "#ffffff", textAlign: "right" }}>
              {" "}
              <span id="introduction19">
                Copyright 2020. All Rights Reserved.
              </span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
