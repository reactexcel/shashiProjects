import React from "react";
import styled from "styled-components";

const MainHeading = () => {
  return (
    <Row>
      <HoverWrapper>
        <Col>
          <div className="textboxaboutproduct">
            <div id="introduction" style={{ padding: "15px" }}>
              <h2>Main Heading</h2>
              <p className="editor-title">
                <b>Second Heading</b>
              </p>

              <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting
                industry. Lorem Ipsum has been the industry's standard dummy
                text ever since the 1500
              </p>
            </div>
            <div id="hoverShow2">
              <ul className="hoversetting">
                <li>
                  <button className="hoverbuttons">Delete</button>
                </li>
                <li>
                  <button className="hoverbuttons">Setting</button>
                </li>
              </ul>
            </div>
          </div>
        </Col>
      </HoverWrapper>
    </Row>
  );
};

const Row = styled.div`
  position: relative;
`;

const Col = styled.div``;
const HoverWrapper = styled.div`
  display: none;
  position: absolute;
  background-color: #ccc;
  width: 100%;
  height: auto;
  z-index: 999;
`;
export default MainHeading;
