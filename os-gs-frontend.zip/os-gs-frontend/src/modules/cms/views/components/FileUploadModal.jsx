import React, { useState } from "react";

const FileUploadModal = ({
  closeModal,
  handleFile1Change,
  handleFile2Change,
}) => {
  return (
    <div className="modal" id="myModal">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h4 className="modal-title">Settings</h4>
            <button
              type="button"
              className="close"
              data-dismiss="modal"
              onClick={closeModal}
            >
              &times;
            </button>
          </div>

          <div className="modal-body">
            <p>
              Slider 1&nbsp;&nbsp;&nbsp;
              <input
                id="fileupload"
                type="file"
                multiple="multiple"
                onChange={handleFile1Change}
              />
            </p>
            <p>
              slider 2&nbsp;&nbsp;&nbsp;
              <input
                id="fileupload1"
                type="file"
                multiple="multiplea"
                onChange={handleFile2Change}
              />
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileUploadModal;
