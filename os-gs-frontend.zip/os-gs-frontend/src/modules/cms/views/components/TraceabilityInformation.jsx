import React from "react";
import maskGroup2 from "../../assets/MaskGroup2.png";
import path16 from "../../assets/Path16.png";
import localShipping from "../../assets/local_shiping.png";
import businessCenter from "../../assets/business_center-24px.png";

const TraceabilityInformation = () => {
  return (
    <div className="textboxaboutproduct1" style={{ marginTop: "20px" }}>
      <h3 className="text-center mb-4" style={{ width: "100%" }}>
        <div id="introduction20">Traceability Information</div>
      </h3>
      <div className="row">
        <div
          className="col-lg-2 col-sm-3 trac"
          style={{ fontSize: "12px", zIndex: 999 }}
        >
          <img src={maskGroup2} alt="Simply Easy Learning" />
          <span
            style={{
              background: "#ffffff",
              fontWeight: "bold",
              writingMode: "vertical-rl",
              textOrientation: "mixed",
            }}
          >
            325 Miles
          </span>
        </div>

        <div
          className="col-lg-10 col-sm-9"
          style={{
            borderLeft: "dotted 1px #464646",
            paddingLeft: "50px",
            marginLeft: "-40px",
          }}
        >
          <h4>
            <b>Manufacturing plant</b>{" "}
            <span style={{ fontSize: "16px" }}>New Delhi, India</span>
          </h4>
          <p style={{ fontSize: "14px" }}>
            Everything came together at AG Industries where oils were
            manufactured. Raw material…
          </p>
          <button type="button" className="btn btn-success btn-sm">
            Read More...
          </button>
          <br />
          <br />
          <br />
        </div>
      </div>

      <div className="row">
        <div
          className="col-lg-2 col-sm-3 trac"
          style={{ fontSize: "12px", zIndex: 999 }}
        >
          <img
            src={path16}
            style={{ marginRight: "3px" }}
            alt="Simply Easy Learning"
          />
          <span
            style={{
              background: "#ffffff",
              fontWeight: "bold",
              writingMode: "vertical-rl",
              textOrientation: "mixed",
            }}
          >
            325 Miles
          </span>
        </div>
        <div
          className="col-lg-10 col-sm-9"
          style={{
            borderLeft: "dotted 1px #464646",
            paddingLeft: "50px",
            marginLeft: "-40px",
          }}
        >
          <h4>
            <b>Nhava Sheva Seaport </b>
            <span style={{ fontSize: "16px" }}>New Delhi, India</span>
          </h4>
          <p style={{ fontSize: "14px" }}>
            Shipping initiated from New Delhi on 05/02/2020 at 2:35 PM by…
          </p>
          <button type="button" className="btn btn-success btn-sm">
            Read More...
          </button>
          <br />
          <br />
          <br />
        </div>
      </div>
      <div className="row">
        <div
          className="col-lg-2 col-sm-3 trac"
          style={{ fontSize: "12px", zIndex: 999 }}
        >
          <img src={localShipping} alt="Simply Easy Learning" />
          <span
            style={{
              background: "#ffffff",
              fontWeight: "bold",
              writingMode: "vertical-rl",
              textOrientation: "mixed",
            }}
          >
            325 Miles
          </span>
        </div>
        <div
          className="col-lg-10 col-sm-9"
          style={{
            borderLeft: "dotted 1px #464646",
            paddingLeft: "50px",
            marginLeft: "-40px",
          }}
        >
          <h4>
            <b>Newark Seaport</b>
            <span style={{ fontSize: "16px" }}>New Jersey, USA</span>
          </h4>
          <p style={{ fontSize: "14px" }}>
            Shipment was delivered at Newark seaport on 06/22/2020. Upon arrival
          </p>
          <button type="button" className="btn btn-success btn-sm">
            Read More...
          </button>
          <br />
          <br />
          <br />
        </div>
      </div>
      <div className="row">
        <div
          className="col-lg-2 col-sm-3 trac"
          style={{ fontSize: "12px", zIndex: 999 }}
        >
          <img src={businessCenter} alt="Simply Easy Learning" />
          <span
            style={{
              background: "#ffffff",
              fontWeight: "bold",
              writingMode: "vertical-rl",
              textOrientation: "mixed",
            }}
          >
            325 Miles
          </span>
        </div>
        <div
          className="col-lg-10 col-sm-9"
          style={{
            borderLeft: "dotted 1px #464646",
            paddingLeft: "50px",
            marginLeft: "-40px",
          }}
        >
          <h4>
            <b>Aura Fuchsia Warehouse and Distribution Center</b>{" "}
            <span style={{ fontSize: "16px" }}>New Jersey, USA</span>
          </h4>
          <p style={{ fontSize: "16px" }}>Delivery was received on….</p>
          <button type="button" className="btn btn-success btn-sm">
            Read More...
          </button>
        </div>
      </div>
    </div>
  );
};

export default TraceabilityInformation;
