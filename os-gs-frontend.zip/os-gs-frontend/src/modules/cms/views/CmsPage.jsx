import React, { Fragment, useState } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import "./cms.css";
import Card from "components/Card/Card.jsx";
import TracabilityInformation from "./components/TraceabilityInformation";
import QuickFacts from "./components/QuickFacts";
import TraceabilityMap from "./components/TraceabilityMap";
import TraceabilityScore from "./components/TraceabilityScore";
import AddIcon from "./components/AddIcon";
import AboutProduct from "./components/AboutProduct";
import Carousel from "./components/Carousel";
import QualityInformation from "./components/QualityInformation";
import ProductVitals from "./components/ProductVitals";
import SimilarRecommendations from "./components/SimilarRecommendations";
import Blog from "./components/Blog";
import Footer from "./components/Footer";
import NavBar from "./components/NavBar";
import mixpanel from "../../analytics/mixpanel/mixpael";

function CmsPage() {
  const [showCarousel, setCarousel] = useState(true);
  const [showAboutProduct, setAboutProduct] = useState(true);
  const [traceabilityScore, setTracebilityScore] = useState(true);
  const [showMap, setMap] = useState(true);
  const [showQuickFacts, setQuickFacts] = useState(true);
  const [showQualityInformation, setQualityInformation] = useState(true);
  const [showProductVitals, setProductVitals] = useState(true);
  const [showSimilarRecommendations, setSimilarRecommendations] = useState(
    true
  );
  const [showBlog, setBlog] = useState(true);

  const closeCarousel = () => {
    setCarousel(false);
  };

  const closeAboutProduct = () => {
    setAboutProduct(false);
  };

  const closeTraceabilityScore = () => {
    setTracebilityScore(false);
  };

  const closeMap = () => {
    setMap(false);
  };

  const closeQuickFacts = () => {
    setQuickFacts(false);
  };

  const closeQualityInformation = () => {
    setQualityInformation(false);
  };

  const closeProductVitals = () => {
    setProductVitals(false);
  };

  const closeSimilarRecommendations = () => {
    setSimilarRecommendations(false);
  };

  const closeBlog = () => {
    setBlog(false);
  };

  mixpanel.track("Cms page loaded");
  return (
    <Grid fluid>
      <Row>
        <Col md={12}>
          <Card
            content={
              <Fragment>
                <div className="container">
                  {showCarousel && <Carousel closeCarousel={closeCarousel} />}

                  {showAboutProduct && (
                    <AboutProduct closeAboutProduct={closeAboutProduct} />
                  )}

                  <AddIcon />

                  {traceabilityScore && (
                    <TraceabilityScore
                      closeTraceabilityScore={closeTraceabilityScore}
                    />
                  )}

                  {showMap && <TraceabilityMap closeMap={closeMap} />}

                  {showQuickFacts && (
                    <QuickFacts closeQuickFacts={closeQuickFacts} />
                  )}

                  <TracabilityInformation />
                </div>

                {showQualityInformation && (
                  <QualityInformation
                    closeQualityInformation={closeQualityInformation}
                  />
                )}

                {showProductVitals && (
                  <ProductVitals closeProductVitals={closeProductVitals} />
                )}

                {showSimilarRecommendations && (
                  <SimilarRecommendations
                    closeRecommendations={closeSimilarRecommendations}
                  />
                )}
                {showBlog && <Blog closeBlog={closeBlog} />}
                <Footer />
              </Fragment>
            }
          />
        </Col>
      </Row>
    </Grid>
  );
}

export default CmsPage;
