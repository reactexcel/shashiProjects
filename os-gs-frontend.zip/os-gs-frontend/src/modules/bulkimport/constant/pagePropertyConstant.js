import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import * as commonConstant from "../../common/constant/commonConstant";

export const MANAGE_BULK_EXECUTION_PAGE_LIST = (that) => {
    return {
      tableColumnList: [
        // {
        //   Header: "Report Id",
        //   id: "id",
        //   accessor: "id",
        //   disableSortBy: true,
        //   disableFilters: true,
        //   style: {
        //     flex: '0 0 80px'
        //   },
        // },
        {
          Header: "Module Name",
          id: "type",
          accessor: "type",
          disableSortBy: true,
          disableFilters: true,
          style: {
            flex: '0 0 200px'
          },
        },
        {
          Header: "File Name",
          id: "fileName",
          accessor: "fileName",
          disableSortBy: true,
          disableFilters: true,
          Cell: ({ cell }) => {
            const { value } = cell;
            const { index, original } = cell.row;
            return (
              <div>
                <a href={original.fileLink} download={true}>{original.fileName}</a>
              </div>
            );
        },
        },
        // {
        //     Header: "File Path",
        //     id: "fileLink",
        //     accessor: "fileLink",
        //     disableSortBy: true,
        //     disableFilters: true,
        //     Cell: ({ cell }) => {
        //         const { value } = cell;
        //         const { index, original } = cell.row;
        //         return (
        //           <div>
        //             <a href={original.fileLink} download={true}>{original.fileLink}</a>
        //           </div>
        //         );
        //     },
        // },
        {
          Header: "Status",
          id: "status",
          accessor: "status",
          disableSortBy: true,
          disableFilters: true,
          style: {
            flex: '0 0 100px'
          },
        },
        {
            Header: "Actions",
            id: "actions",
            accessor: "actions",
            sortable: false,
            className: "action justify-content-center",
            disableSortBy: true,
            disableFilters: true,
            style: {
              flex: "0 0 60px",
            },
            Cell: ({ cell }) => {
              const { value } = cell;
              const { index, original } = cell.row;
              return (
                <div className="actions-left">
                  <Button bsStyle="default" simple icon>
                    <div className={original.status != "completed" ? "circle disabled" : "circle"}>
                        <i title="View Execution" id={original.id + "_" + commonConstant.VIEW_ACTION_MODE + "_" + index}
                          className="fa fa-eye"
                          onClick={(e) => that.getTdProps(e)}
                        />
                      </div>
                  </Button>
                </div>
              );
            },
          },
      ],
      tableConfig: {
        defaultFilteredList: [],
        defaultSortedList: [],
        defaultPageSize: 50,
        showExport: false,
        customPagination: false,
        showServerSideFilter: false,
        isFilterEnabed: false,
        showPagination: false,
        isDraggable: false,
      }
    }
  };