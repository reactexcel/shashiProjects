import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as commonConstant from '../../common/constant/commonConstant';
import { connect } from "react-redux";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { getBulkExecutionDetails, getBulkExexutionList } from "../actions/bulkActions";
import { setActionMode } from "../../../actions/appActions";
import CommonUtil from "../../common/util/commonUtil";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { getUserList } from "../../userManagement/actions/userActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import mixpanel from "../../analytics/mixpanel/mixpael";
import PopupUtil from '../../common/util/popupUtil';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import setting from "assets/img/setting-page-icon.svg";
import BulkImportErrorModal from "./BulkImportErrorModal.js";
import Button from "../../../components/CustomButton/CustomButton.jsx";

class BulkExecution extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      alert: null,
      dateError: false,
      redirect: false,
      redirectUrl: null,
      submitted: false,
      additionalParams: {},
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      selectedReportId: null,
      openBulkImportErrorModal: false,
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.getErrorDetails = this.getErrorDetails.bind(this);
  }

    componentDidMount = async () => {
        mixpanel.track("Manage Audit Page loaded");
        this.props.getUserProfile();
        if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
        this.props.getDataDictionaryDetails();
        }
        this.setSelectedTabDetails()
    };

    setSelectedTabDetails = () => {
        let managePageList = pagePropertyListConstant.MANAGE_BULK_EXECUTION_PAGE_LIST(this);
        var additionalParams = {};
        this.setState({
        tableColumnList: managePageList.tableColumnList,
        tableConfig: managePageList.tableConfig,
        lastEvaluatedKeyArray: [],
        additionalParams: additionalParams,
        })
        this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
            managePageList.tableConfig.defaultPageSize, this));
    }

    makeCustomAPICall(tempParamas) {
        this.props.getBulkExexutionList(tempParamas);
    }

    handlePopupCancel = () => {
        this.setState({ alert: null, openBulkImportErrorModal: false });
    }

    componentDidUpdate(prevProps) {
        if (prevProps.bulkExecutionList != this.props.bulkExecutionList && this.props.bulkExecutionList != null) {
            PaginationUtil.handlePagination(this.props.bulkExecutionList, this);
        }
        if (prevProps.bulkExecutionDetails != this.props.bulkExecutionDetails && this.props.bulkExecutionDetails != null) {
            this.setState({ openBulkImportErrorModal: true });
        }
    }

    getTdProps = async (event) => {
        var tempId = event.target.id.split("_");
        if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
            await this.setState({ selectedReportId: tempId[0] });
            await this.props.getBulkExecutionDetails(tempId[0])
        }
    }

    getErrorDetails = (errorDetails) => {
        this.setState({ openBulkImportErrorModal: false });
    }

    render() {
        const { attributeList, attributeObj, submitted, tableColumnList, tableDataList, tableConfig } = this.state;
        const actionMode = commonConstant.CREATE_ACTION_MODE;
        return (
        <div className="main-content create-page">
            {this.state.redirect === true ? (
            <Redirect push to={this.state.redirectUrl}></Redirect>
            ) : null}
            {this.state.alert}
            <Grid fluid>
            <Row className="top-row">
                <div className="header-section">
                <Col sm={4} md={4}>
                    <div className="page-title">
                    <img src={setting} alt="" className="page-icon" />
                    Bulk Executions
                    </div>
                </Col>
                <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                    <div className="page-control-buttons">
                      <Button className="btn-save btn-fill" onClick={this.setSelectedTabDetails}>Reload Executions</Button>
                    </div>
                </div>
              </Col>
                </div>
            </Row>
            {tableColumnList != null ?
                <Row>
                <Col md={12}>
                    <form>

                    <Card
                        content={
                        <>
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                            <div>
                                <Row>
                                <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                />
                                </Row>
                            </div>
                            : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                            {this.state.openBulkImportErrorModal ?
                                <BulkImportErrorModal
                                    getErrorDetails={this.getErrorDetails}
                                >
                                </BulkImportErrorModal>
                            : null}
                        </>
                        }
                    />

                    </form>
                </Col>
                </Row>
                : null}
            </Grid>
        </div>
        );
    }
}

function mapStateToProps(state, ownProps) {
  return {
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    actionMode: state.app.actionMode,
    bulkExecutionList: state.bulk.bulkExecutionList,
    bulkExecutionDetails: state.bulk.bulkExecutionDetails,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getBulkExecutionDetails: (selectedReportCode) => dispatch(getBulkExecutionDetails(selectedReportCode)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getBulkExexutionList: (id) => dispatch(getBulkExexutionList(id)),
  getUserList: (id) => dispatch(getUserList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(BulkExecution);
