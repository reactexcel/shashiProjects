import axios from '../../../axios/axios';
import * as bulkActionTypes from './bulkActionTypes';
import * as bulkConstant from '../constant/bulkConstant';
import {
  beginAjaxCall, endAjaxCall
} from "../../../actions/ajaxStatusActions";

export function getBulkExexutionList(params) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.get(bulkConstant.GET_BULK_EXECUTION_LIST_URL, { params: params }).then(response => {
        if (response.status == 200) {
          dispatch({
            type: bulkActionTypes.GET_BULKEXECUTION_LIST,
            payload: response.data.reports
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
    };
}

export function getBulkExecutionDetails(selectedReportCode, params) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.get(bulkConstant.GET_BULK_EXECUTION_DETAILS_URL +
        selectedReportCode, { params }).then(response => {
          if (response.status == 200) {
            dispatch({
              type: bulkActionTypes.GET_BULKEXECUTION_DETAIL,
              payload: response.data
            });
          }
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          throw error;
        });
    };
}