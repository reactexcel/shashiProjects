import * as commonConstant from '../../common/constant/commonConstant';
export const CREATE_SALE_ORDER = "createSaleOrder";
export const VIEW_SALE_ORDER = "viewSaleOrder";

export const CREATE_CUSTOMER_HEADER_TITLE = "Create Customer";
export const EDIT_CUSTOMER_HEADER_TITLE = "Edit Customer";
export const VIEW_CUSTOMER_HEADER_TITLE = "View Customer";
export const MANAGE_CUSTOMER_HEADER_TITLE = "Customer";

export const LOCATION_HEADER_TITLE = "Location";
export const DOCUMENT_HEADER_TITLE = "Document";
export const FACILITY_USAGE_HEADER_TITLE = "Facility Usage";
export const LOCATION_CHECKBOX_TITLE = "Set as default";
export const ADDRESS_MANDATORY_MSG = "Address is required.";
export const MODULE_NAME = "Customer";
export const CREATE_CUSTOMER = "createCustomer";

export const DEATIVATE_CUSTOMER = "deActivateCustomer";
export const ACTIVATE_CUSTOMER = "activateCustomer";
export const CREATE_CUSTOMER_PAGE_URL = '/admin/create-customer';
export const MANAGE_CUSTOMER_PAGE_URL = '/admin/manage-customer';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_CUSTOMER_LIST_URL = `${BASE_URL}/customers`;
export const GET_CUSTOMER_DETAILS_URL = `${BASE_URL}/customers/`;
export const SET_CREATE_CUSTOMER_DETAILS_URL = `${BASE_URL}/customers/`;
export const SET_UPDATE_CUSTOMER_DETAILS_URL = `${BASE_URL}/customers/`;
export const SET_UPDATE_CUSTOMER_STATUS_URL = `${BASE_URL}/customers/`;
export const GET_CUSTOMER_SEARCH_URL = `${BASE_URL}/customers`;
export const SET_CREATE_BULK_CUSTOMER_URL = `${BASE_URL}/customers/bulkimport`;
export const SET_CUSTOMER_DOCUMENTS_URL = commonConstant.FILEUPLOAD_URL + '/upload';
export const GET_CUSTOMER_PAYMENT_DETAILS_URL = `${BASE_URL}/finance/payments`;
export const SET_CUSTOMER_TIER_PRICE = BASE_URL + '/customers?bulkTier=true';