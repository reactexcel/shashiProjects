import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import _ from 'lodash';
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import * as stockAdjustmentConstant from '../../stockAdjustment/constant/stockAdjustmentConstant';
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import isAuthorized from "auth-plugin";
import * as customerConstant from './customerConstant';
import { countryList } from "../../common/constant/countryConstant";
import { FormControl, InputGroup } from "react-bootstrap";
import CustomCheckbox from "../../../components/CustomCheckbox/CustomCheckbox";
import CommonUtil from "../../common/util/commonUtil";
import Select from "react-select";

export const CREATE_CUSTOMER_PAGE_LIST =
{
    attributeObj: {
        // customerId: '',
        customerName: '',
        creditPeriod: '',
        notes: '',
        status: true, //statusConstant.ACTIVE_STATUS,
        locations: [],
        documents: [],
        emailIds : [],
        phone : [],
        tierId:"",
        countryCode: '+1'
        // sourceChannel: commonConstant.ORIGINSCALE
    },
    attributeList: [
        {
            name: "customerId",
            type: "UNIQUE_CODE",
            label: "Customer Code",
            prefix: "CUS",
            required: false,
            fieldWidth: 6,
            inputType: "text",
            numberOfRow: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "contactPerson",
            type: "TEXTBOX",
            label: "Business Name",
            required: true,
            fieldWidth: 6,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 100,
            minLength: 2,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "customerName",
            type: "TEXTBOX",
            label: "Customer Name",
            required: true,
            fieldWidth: 6,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 100,
            minLength: 2,
            mandatoryMsgText: "Field can not be empty.",
            customMessage: "Customer Name already exist."
        }, {
            name: "creditAmount",
            type: "TEXTBOX",
            label: "Available Credit",
            required: false,
            fieldWidth: 6,
            numberOfRow: 0,
            inputType: "number",
            pattern: "^[0-9]*$",
            minValue: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            editModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            maxLength: 10,
            minLength: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
       
        {
            name: "countryCode",
            type: "DROPDOWN",
            label: "Country Code ",
            required: false,
            fieldWidth: 3,
            numberOfRow: 0,
            minValue: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            options: _.map(countryList, country => ({ label: `${country.code} (${country.dial_code})`, value: `${country.dial_code}` }))
        },

        {
            name: "phone",
            type: "TEXT_LIST",
            label: "Phone Number",
           // inputType: "phone",
            required: false,
            fieldWidth: 9,
            numberOfRow: 0,
            minValue: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            //mandatoryMsgText: "Field can not be empty.",
            // phoneMsgText: "Please enter valid phone number.",
        },
        {
            name: "emailIds",
            type: "TEXT_LIST",
            label: "Email",
            required: false,
            fieldWidth: 12,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            //mandatoryMsgText: "Email is required.",
            emailMsgText: "Invalid email format.",
            customEmailMessage: "Customer Email already exist."
        },
        {
            name: "loyaltyPoints",
            type: "TEXTBOX",
            label: "Loyalty Points",
            required: false,
            fieldWidth: 6,
            numberOfRow: 0,
            inputType: "number",
            pattern: "^[0-9]*$",
            minValue: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            editModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            maxLength: 10,
            minLength: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "creditPeriod",
            type: "TEXTBOX",
            label: "Credit Days",
            required: false,
            fieldWidth: 6,
            numberOfRow: 0,
            inputType: "number",
            minValue: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 10,
            minLength: 1,
            lengthValidationMessage: "Max length of 10 chars reached",
            minLengthValidationMessage: "Min length should be 1 chars",
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "tierId",
            type: "DROPDOWN",
            label: "Customer Tier",
            required: false,
            fieldWidth: 6,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            tierPriceFlag: true,
            numberOfRow: 2,
            maxLength: 200,
            minLength: 1,
        },
        {
            name: "notes",
            type: "TEXTBOX",
            label: "Notes",
            required: false,
            fieldWidth: 6,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            numberOfRow: 2,
            maxLength: 200,
            minLength: 1,
        },
        {
            name: "status",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
        },
        // {
        //     name: "version",
        //     type: "TEMP",
        //     createModeShowFlag: false,
        //     cloneModeShowFlag: false,
        //     editModeShowFlag: true,
        // },
        {
            name: "locations",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
        {
            name: "documents",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
        // {
        //     name: "sourceChannel",
        //     type: "TEMP",
        //     createModeShowFlag: true,
        //     cloneModeShowFlag: true,
        //     editModeShowFlag: true,
        // },

    ],
    attributeListOpeningBalance: [
        {
            name: "facilityId",
            type: "DROPDOWN",
            label: "Facility",
            required: false,
            fieldWidth: 3,
            inputType: "text",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "openingBalance",
            type: "TEXTBOX",
            label: "Opening Balance",
            required: false,
            showCurrency: true,
            fieldWidth: 3,
            inputType: "number",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            minValue: 0,
            minLength: 1,
            maxLength: 10,
            lengthValidationMessage: "Max length of 10 chars exceeded",
        },
    ],
};

export const LOCATION_PAGE_LIST =
{
    attributeObj: {
        locationName: '',
        address: '',
        country: '',
        state: '',
        city: '',
        zipcode: '',
        isDefault: false
    },
    attributeList: [
        {
            name: "locationName",
            type: "TEXTBOX",
            label: "Location Name",
            required: true,
            fieldWidth: 4,
            numberOfRow: 0,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 100,
            minLength: 1,
            mandatoryMsgText: "Field can not be empty.",
            customMessage: "Location name already exist."
        },
        {
            name: "address",
            type: "TEXTBOX",
            label: "Address",
            inputType: "text",
            required: true,
            fieldWidth: 8,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            maxLength: 200,
            minLength: 1,
            mandatoryMsgText: "Field can not be empty."
        },
        {
            name: "country",
            type: "DROPDOWN",
            label: "Country",
            required: true,
            isCountry: true,
            fieldWidth: 3,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "state",
            type: "DROPDOWN",
            label: "State",
            required: true,
            fieldWidth: 3,
            isState: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "city",
            type: "DROPDOWN",
            label: "City",
            required: true,
            fieldWidth: 3,
            isCity: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "zipcode",
            type: "TEXTBOX",
            label: "Zip Code",
            minValue: 0,
            required: true,
            fieldWidth: 3,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            maxLength: 15,
            minLength: 1,
            mandatoryMsgText: "Field can not be empty."
        },
        {
            name: "isDefault",
            type: "CHECKBOX",
            label: "Set As Default",
            required: false,
            fieldWidth: 3,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 0,
            maxLength: 10,
            mandatoryMsgText: "Field can not be empty."
        },
    ]

};

export const MANAGE_CUSTOMER_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Customer Code",
                id: "customerId",
                accessor: "customerId",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>CUST-{value}</>
                    )
                }
            },
            {
                Header: "Name",
                id: "customerName",
                accessor: "customerName",
                style: {
                    flex: '0 0 25%'
                },
            },
            {
                Header: "Email",
                id: "email",
                accessor: "email",
                Cell: ({ cell }) => {
                    const { index, original } = cell.row;
                    const { value } = cell;
                    return (
                      <div name={'email'} id={original.id + "_" + index}>
                        <span >{value} </span>
                       
                      </div>
                    )
                  }
            },
            {
                Header: "Phone",
                id: "phone",
                accessor: "phone",
                style: {
                    flex: '0 0 120px'
                },
                Cell: ({ cell }) => {
                    const { index, original } = cell.row;
                    const { value } = cell;
                    return (
                      <div name={'phone'} id={original.id + "_" + index}>
                        <span >{value} </span>
                       
                      </div>
                    )
                  }
            },
            {
                Header: "Location",
                id: "location",
                accessor: (values) => {
                    if (values.locations) {
                        var location = null;
                        for (var i = 0; i < values.locations.length; i++) {
                            if (values.locations[i].isDefault) {
                                location = values.locations[i].city + "-" +
                                    values.locations[i].country
                                break;
                            }
                        }
                        if (!location) {
                            if (values.locations[0]) {
                                location = values.locations[0].city + "-" +
                                    values.locations[0].country;
                            }
                            else {
                                location = "";
                            }
                        }
                        return location;
                    } else {
                        return ''
                    }

                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                style: {
                    flex: '0 0 140px'
                },
                className: "action",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (

                        <div className="actions-left">
                            {(isAuthorized("createSalesOrder") || isAuthorized("salesOrder")) &&
                                <Nav pullRight>
                                    <NavDropdown id={original.customerId + "_" + commonConstant.MENU_ACTION_MODE}
                                        title={<i className="fa fa-ellipsis-v" id={original.customerId + "_" + commonConstant.MENU_ACTION_MODE}
                                            onClick={(e) => that.getTdProps(e)} />} noCaret >
                                        {isAuthorized("createSalesOrder") &&
                                            <MenuItem
                                                id={original.customerId + "_" + commonConstant.MENU_ACTION_MODE + "_" + customerConstant.CREATE_SALE_ORDER}
                                                onClick={(e) => that.getTdProps(e)}>
                                                Create Sale Order
                                        </MenuItem>
                                        }
                                        {isAuthorized("salesOrder") && <MenuItem
                                            id={original.customerId + "_" + commonConstant.MENU_ACTION_MODE + "_" + customerConstant.VIEW_SALE_ORDER}
                                            onClick={(e) => that.getTdProps(e)}>
                                            View Sale Order
                                    </MenuItem>}
                                    </NavDropdown>
                                </Nav>
                            }
                            <Button bsStyle="default" simple icon >
                                {isAuthorized("editCustomer") ?
                                    <div className="circle"><i title="edit"
                                        id={original.customerId + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index}
                                        className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                    : null}
                                {isAuthorized("cloneCustomer") &&
                                    <div className="circle"><i title="clone"
                                        id={original.customerId + "_" + commonConstant.CLONE_ACTION_MODE + '_' + index}
                                        className="fa fa-copy" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                                {isAuthorized("viewCustomer") &&
                                    <div className="circle"><i title="view"
                                        id={original.customerId + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index}
                                        className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }

                                {isAuthorized("creditNoteCustomer") &&
                                    <div className="circle">
                                        <i title="Credit Note"
                                            id={original.customerId + '_' + commonConstant.MENU_ACTION_MODE + "_" +
                                                stockAdjustmentConstant.CUSTOMER_CREDIT_STATUS + "_" + index}
                                            className="fa fa-money" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                }
                            </Button>
                        </div>

                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const ADVANCE_SEARCH_LIST = (that) => {
    return {
        attributeObj: {
            orderNumber: '',
        },
        attributeList: [
            {
                name: "orderNumber",
                type: "TEXTBOX",
                label: "",
                inputType: "text",
                fieldWidth: 12,
                numberOfRow: 0,
                placeholder: "Search by Customer Code/Name",
            },
        ],
    }
};
export const MANAGE_MULTI_SELECTION_CUSTOMER_PAGE_LIST = (that) => {
    return {
      tableColumnList: [
        {
          Header: "",
          id: "action",
          accessor: "action",
          className: "action justify-content-center",
          style: {
            flex: "0 0 60px",
          },
          required: false,
          disableSortBy: true,
          disableFilters: true,
          createModeRemoveFlag: true,
          Cell: ({ cell }) => {
            const { value } = cell;
            const { index, original } = cell.row;
            return (
              <div className="actions-left">
                <CustomCheckbox
                  inline
                  number={
                    original.customerId +
                    "_" +
                    commonConstant.CREATE_ACTION_MODE +
                    "_" +
                    index
                  }
                  checked={original.isChecked}
                  onClick={(e) => that.handleCheckBoxChange(e, that)}
                />
              </div>
            );
          },
        },
        {
          Header: "Customer Code",
          id: "customerId",
          accessor: "customerId",
          name: "customerId",
          disableSortBy: true,
          disableFilters: true,
          Cell: ({ cell }) => {
            var value = cell.value;
            const { index, original } = cell.row;
            return <>CUST-{value}</>;
          },
        },
        {
            Header: "Customer Name",
            id: "customerName",
            accessor: "customerName",
            name: "customerName",
            disableSortBy: true,
            disableFilters: true,
        },
        {
            Header: "Email",
            id: "email",
            accessor: "email",
            disableSortBy: true,
            disableFilters: true,
        },
        {
            Header: "Phone",
            id: "phone",
            accessor: "phone",
            disableSortBy: true,
            disableFilters: true,
            style: {
                flex: '0 0 120px'
            },
        },
        {
            Header: "Location",
            id: "location",
            disableSortBy: true,
            disableFilters: true,
            accessor: (values) => {
                if (values.locations) {
                    var location = null;
                    for (var i = 0; i < values.locations.length; i++) {
                        if (values.locations[i].isDefault) {
                            location = values.locations[i].city + "-" +
                                values.locations[i].country
                            break;
                        }
                    }
                    if (!location) {
                        if (values.locations[0]) {
                            location = values.locations[0].city + "-" +
                                values.locations[0].country;
                        }
                        else {
                            location = "";
                        }
                    }
                    return location;
                } else {
                    return ''
                }

            }
        },
        {
            Header: "Tier",
            id: "tierId",
            name: "tierId",
            accessor: "tierId",
            required: false,
            inputType: "text",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            disableSortBy: true,
            disableFilters: true,
            className: "input-field",
            style: {
                flex: "0 0 120px",
            },
            Cell: ({ cell }) => {
                let { value } = cell;
                const { index, original } = cell.row;   
                return (
                    <div style={{
                        border: original.isChecked ? "1px solid #70707080" : "none", width: '100%',
                    }}>
                        <Select
                            className={that.state.submitted &&
                                CommonUtil.isNullValue(value) ? 'required-error' : ''}
                            id={'tierId' + '_' + index}
                            name={"tierId" + '_' + index}
                            onChange={that.handleTableDropDownChange}
                            placeholder=""
                            options={that.state.tierPricing}
                            classNamePrefix="react-select"
                            isDisabled={!original.isChecked ? true : false}
                            value={CommonUtil.getSelectedOptionLabel(that.state.tierPricing, original.tierId)} />
                    </div>
                );
            },
        },

        {
          Header: "Actions",
          id: "actions",
          accessor: "actions",
          className: "action justify-content-center",
          style: {
            flex: "0 0 60px",
          },
          disableSortBy: true,
          disableFilters: true,
          createModeShowFlag: true,
          cloneModeShowFlag: true,
          editModeShowFlag: true,
          viewModeShowFlag: true,
          Cell: ({ cell }) => {
            const { value } = cell;
            const { index, original } = cell.row;
            const { customerList } = that.props
            const firstChecked = customerList && customerList.find(item => item.isChecked);
            return (
              <div
                className={
                  CommonUtil.isViewMode(that.props.actionMode) ||
                    !isAuthorized("editCustomer")
                    ? "actions-left disabled"
                    : "actions-left"
                }
               >
                    {(firstChecked && original && original.customerId === firstChecked.customerId) ?
                        <Button bsStyle="default" simple icon>

                            <div className="circle">
                                <i
                                    title="clone"
                                    id={"copy" + "_" + index}
                                    className="fa fa-copy"
                                    onClick={(e) => that.copyPrice(original)}
                                />
                            </div>
                        </Button> : null}
              </div>
            );
          },
        },
      ],
      tableConfig: {
        defaultFilteredList: [],
        defaultSortedList: [],
        defaultPageSize: 50,
        showExport: false,
        customPagination: true,
        showServerSideFilter: false,
        isFilterEnabed: false,
        showPagination: true,
        isDraggable: false,
      },
    };
  };