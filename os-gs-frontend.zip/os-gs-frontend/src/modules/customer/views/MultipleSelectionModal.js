import React, { Component } from "react";
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { Redirect } from "react-router-dom";
import Select from "react-select";
import { getCustomerList, getCustomerSearchList, setCustomerTierPrice } from "../actions/customerActions";
import PaginationUtil from "../../common/util/paginationUtil";
import ValidationUtil from '../../common/util/validationUtil';
import PopularTableUtil from '../../common/util/popularTableUtil';
import check from "assets/img/check.svg";
import { getTierPricingDetails } from "../../dataDictionary/actions/dataDictionaryActions";
var Modal = require('react-bootstrap-modal')

class MultipleSelectionModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      params: null,
      searchInput: "",
      selectedFilter: "",
      additionalParams: null,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      noneOption: [{ label: 'None', value: '' }],
      isAllChecked: false,
      customError: false,
      error: false,
      tierPricing: [],
      autoSave: false,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    this.setState({ openModal: true });
    this.props.getTierPricingDetails();
    await this.setSelectedTabDetails();
  };

  setSelectedTabDetails = async (status) => {
    const managePageList = pagePropertyListConstant.MANAGE_MULTI_SELECTION_CUSTOMER_PAGE_LIST(this);
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const { search } = this.state;
    var additionalParams = {};
    if(CommonUtil.isNotNull(search)) additionalParams["search"] = search;
    await this.setState({
        tableColumnList: managePageList.tableColumnList,
        tableConfig: managePageList.tableConfig,
        additionalParams: additionalParams,
        attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
        attributeObj: searchAttributeList.attributeObj,
      })
    await this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
        managePageList.tableConfig.defaultPageSize, this));
  };

    makeCustomAPICall(tempParamas) {
      this.setState({isAllChecked: false});
        if (CommonUtil.isNotNull(tempParamas.search)) {
        this.props.getCustomerSearchList(tempParamas);
        } else {
        this.props.getCustomerList(tempParamas);
        }
    }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.customerList != null && prevProps.customerList != this.props.customerList) {
    //   this.updateCustomerDropDownList(this.props.customerList);
      PaginationUtil.handlePagination(this.props.customerList, this);
    }
    if (this.props.tierPricing != null && prevProps.tierPricing != this.props.tierPricing) {
        this.updateTierDropDownList();
    }
  }

  updateTierDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(this.props.tierPricing, 'tierId', 'tierName', null, true);
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0));
    await this.setState({ tierPricing: [...this.state.noneOption, ...tempList]})
  }

  closeModal = (event) => {
    this.props.getCustomerSelectionDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave = async (event) => {
    const { tableDataList } = this.state;
    let tempList = [];
    tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
        let temp = {
            custId : item.customerId,
            tierId : item.tierId ? item.tierId : '',
        }
        return temp
      })
    if(tempList && tempList.length > 0) {
        if (this.isValidRequestObj(tempList)) {
          await this.props.setCustomerTierPrice(tempList)
          this.setState({ openModal: false, submitted: true, autoSave: false, alert: null });
          this.props.getCustomerSelectionDetails(false);
        }
    } else {
        this.setState({ openModal: false, submitted: true, autoSave: false, alert: null });
        this.props.getCustomerSelectionDetails(false);
    }
} 

    handlePopupContinue = async () => {
        const { tableDataList } = this.state;
        let tempList = [];
        tempList = tableDataList && tableDataList.filter((item) => item.isChecked == true).map((item) => {
            let temp = {
                custId : item.customerId,
                tierId : item.tierId,
            }
            return temp
        })
        if(tempList && tempList.length > 0) {
            if (this.isValidRequestObj(tempList)) {
                await this.props.setCustomerTierPrice(tempList)
                await this.setState({ submitted: false, autoSave: false, alert: null });
                await this.makeCustomAPICall(PaginationUtil.getPaginationParams(this.state.currentPage - 1, null, this, true))
            } else {
                await this.setState({ submitted: true, autoSave: false });
            }
        } else {
            await this.setState({ submitted: false, autoSave: false, alert: null });
        }
    }
  
  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateArrayListRequestObj(tempObj,
      pagePropertyListConstant.MANAGE_MULTI_SELECTION_CUSTOMER_PAGE_LIST(this).tableColumnList)) {
      this.setState({ error: true });
      return false;
    } else {
      this.setState({ error: false });
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null, currentPage: this.state.pageNumber });
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = async () => {
    let { searchInput } = this.state;
    let list = this.props.customerList
    list = await list.sort((a,b) => (a.customerId > b.customerId) ? 1 : ((b.customerId > a.customerId) ? -1 : 0))
    let filteredData = list.filter((value) => {
      return (
        String(value.customerId).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.customerName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    await this.setState({ tableDataList: filteredData });
  };

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleCheckBoxChange = async (event) => {
    const { id, checked } = event.target;
    var tempId = id.split("_");
    const {tableDataList} = this.state;
    tableDataList.map((item) => {
      if(item.customerId == tempId[0]) {
        item.isChecked = checked;
      }
    })
    await this.setState({
      tableDataList: tableDataList
    })
  }

  handleAllCheckboxChange = async (event) => {
    const { checked } = event.target;
    const { tableDataList} = this.state;
    tableDataList.map((item, index) => {
      item.isChecked = checked;
    })
    await this.setState({
      isAllChecked : checked,
      tableDataList: tableDataList
    })
  }

  copyPrice = async (value) => {
    const { tableDataList } = this.state;
    if(value) {
      let tierId = value.tierId;
      let tempList = tableDataList.map(item => {
        if(item.isChecked) {
          item.tierId = tierId;
        }
        return item;
      })
      await this.setState({ tableDataList: tempList, autoSave: true })
    }
  }

  handleTableTextBoxChange = (event) => {
    this.setState({ autoSave: true })
    PopularTableUtil.handleTableTextBoxChange(event, this, "tableDataList");
  }

  handleTableDropDownChange = (event, obj) => {
    this.setState({ autoSave: true })
    PopularTableUtil.handleTableDropDownChange(event, obj, this, "tableDataList");
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: null, searchInput: "" });
      await this.setSelectedTabDetails(this.state.status);
    }
  }

  render() {
    const { tableColumnList, tableConfig, tableDataList, search, customError, error} = this.state;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.closeModal} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
            {this.state.alert}
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Edit Bulk Customer</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            <Row className="header-section" style={{marginBottom: '30px'}}>
                              <Col md={12}>
                                <Row>
                                  <Col md={6}>
                                    <div className="right-section">
                                      <div className="search-section advance" style={{width: 'calc(100% - 30px)'}}>
                                        <form onSubmit={this.handleSubmit}>
                                        <i className="fa fa-search"></i>
                                        <FormControl type="text" name="searchInput" placeholder="Search by Customer Code/Name/Phone/Address/Email"
                                          value={this.state.searchInput} onChange={this.handleChange} />
                                        </form>
                                      </div>
                                      <div className="advance-filter">
                                        <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                                            <img src={check} onClick={this.advanceSearch} alt="submit" />
                                        </div>
                                        </div>
                                    </div>
                                  </Col>
                                </Row>
                              </Col>
                            </Row>
                            {customError && <Row><Col md={12}><p className="text-danger">Product limit of 500 has reached in the order.</p></Col></Row>}
                            {tableColumnList != null ? (
                              <Row>
                                <Col md={12}>
                                  {search ?
                                    <div className="showfilter">
                                      Search / Filter by:
                                        {search ?
                                        <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                                        : null}
                                    </div>
                                    : null}
                                </Col>
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                  <Table className={"table-box-height"} 
                                    columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                    showCheck={true}
                                  />
                                ) : null}
                              </Row>
                            ) : null}
                            {error && <p className="text-danger">Please fill missing fields.</p>}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            <div>
                            <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            <Button className="btn-save btn-fill" onClick={this.handleSave}>Update Customer</Button>
                            </div>
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    actionMode: state.app.actionMode,
    customerList: state.customer.customerList,
    customerSearchList: state.customer.customerSearchList,
    tierPricing: state.dataDictionary.tierPricing,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getCustomerList: (id) => dispatch(getCustomerList(id)),
  setCustomerTierPrice: (id) => dispatch(setCustomerTierPrice(id)),
  getCustomerSearchList: params => dispatch(getCustomerSearchList(params)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
});
export default connect(mapStateToProps, mapDispatchToProps)(MultipleSelectionModal);
