import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as customerConstant from '../constant/customerConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { setCreditNoteDetails } from "../../stockAdjustment/actions/stockAdjustmentActions";
import { setSelectedCustomerCode, getCustomerList, updateCustomerStatus, getCustomerSearchList } from "../actions/customerActions";
import CommonUtil from '../../common/util/commonUtil';
import * as stockAdjustmentConstant from '../../stockAdjustment/constant/stockAdjustmentConstant';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopupUtil from '../../common/util/popupUtil';
import PaginationUtil from '../../common/util/paginationUtil';
import * as commonConstant from '../../common/constant/commonConstant';
import * as saleOrderConstant from '../../saleOrder/constant/saleOrderConstant';
import * as  statusConstant from '../../common/constant/statusConstant';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import StatusUtil from '../../common/util/statusUtil';
import customer from "assets/img/customer-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import filter from 'assets/img/filter.svg';
import TextBoxUtil from '../../common/util/textBoxUtil';
import check from "assets/img/check.svg";
import MultipleSelectionModal from './MultipleSelectionModal';

class ManageCustomer extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: statusConstant.ACTIVE_STATUS,
      alert: null,
      redirect: false,
      redirectUrl: null,
      customerId: null,
      status: null,
      activate: false,
      search: null,

      additionalParams: {},
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      multipleSelectionModal: false,
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Manage customer loaded");
    let status = CommonUtil.getAdditonalPathParams(this);
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({status: status, searchInput : searchInput ? searchInput : '', search : searchInput ? searchInput : ''})
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setState({ selectedFilter: statusConstant.INACTIVE_STATUS });
      this.setSelectedTabDetails(statusConstant.INACTIVE_STATUS);
      const { location, history } = this.props;
      history.replace();
    } else {
      this.setSelectedTabDetails();
    }
  }

  setSelectedTabDetails = async (status) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    let additionalParams = {};
    if (status) {
      additionalParams.status = status;
    }
    const managePageList = pagePropertyListConstant.MANAGE_CUSTOMER_PAGE_LIST(this);
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.customerList != this.props.customerList && this.props.customerList != null) {
      PaginationUtil.handlePagination(this.props.customerList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse(this.props.ajaxCallStatus.data);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let DataArray = [];
    let filteredData = this.props.customerList && this.props.customerList.filter(value => {
      let Data = this.dataFilter(value, searchInput);
      if (CommonUtil.isNotNull(Data)) {
        DataArray.push(Data);
      }
      return (
        String(value.customerId).includes(searchInput) ||
        String(value.phone).includes(searchInput) ||
        String(value.email).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.customerName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    if (CommonUtil.isNotNull(DataArray)) {
      this.setState({ tableDataList: DataArray });
    } else {
      this.setState({ tableDataList: filteredData });
    }
  }

  dataFilter = (output, searchInput) => {
    let filteredData2 = output.locations && output.locations.filter(value => {
      return (
        String(value.address).toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.locationName).toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    if (CommonUtil.isNotNull(filteredData2)) {
      return output;
    }
  }

  handleFIlter = (event) => {
    PaginationUtil.initPaginationParams(this);
    let status = event.toLowerCase()
    if (status == statusConstant.INACTIVE_STATUS) {
      this.setSelectedTabDetails(status);
    } else {
      this.setSelectedTabDetails();
    }
    this.setState({ selectedFilter: event });
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  // closeSearchBox = () => {
  //   this.state.attributeObj.orderNumber = '';
  //   this.setState({ menuOpen: false });
  // }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedCustomerCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(customerConstant.CREATE_CUSTOMER_PAGE_URL, this);
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == customerConstant.CREATE_CUSTOMER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(customerConstant.CREATE_CUSTOMER_PAGE_URL, this);
    } else if (tempId[2] == customerConstant.CREATE_SALE_ORDER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(saleOrderConstant.CREATE_SALE_ORDER_PAGE_URL, this);
    } else if (tempId[2] == customerConstant.VIEW_SALE_ORDER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      this.props.setSelectedCustomerCode(tempId[0]);
      CommonUtil.handlePageRedirection(saleOrderConstant.MANAGE_SALE_ORDER_PAGE_URL, this);
    } else if (tempId[2] == stockAdjustmentConstant.CUSTOMER_CREDIT_STATUS) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      let params = { orderCode: tempId[0], action: stockAdjustmentConstant.CUSTOMER_CREDIT_STATUS };
      this.props.setCreditNoteDetails(params);
      CommonUtil.handlePageRedirection(stockAdjustmentConstant.CREATE_STOCK_ADJUSTMENT_PAGE_URL, this);
    } else if (tempId[2] == customerConstant.ACTIVATE_CUSTOMER) {
      this.handleStatusAction(tempId[0], statusConstant.ACTIVE_STATUS);
      this.setState({ activate: true });
    } else if (tempId[2] == customerConstant.DEATIVATE_CUSTOMER) {
      this.setState({
        customerId: tempId[0], status: statusConstant.INACTIVE_STATUS,
        activate: false
      });
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeactivatePopUpConfig(popupActionButton, customerConstant.MODULE_NAME);
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    this.setState({ alert: null });
  }

  handleStatusAction(customerId, status) {
    var tempObj = {};
    var customerId = customerId ? customerId : this.state.customerId;
    tempObj.status = status ? status : this.state.status;
    tempObj.customerId = customerId;
    PaginationUtil.initPaginationParams(this);
    this.setState({ alert: null, selectedFilter: statusConstant.ACTIVE_STATUS });
    this.props.updateCustomerStatus(tempObj, customerId);
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getCustomerSearchList(tempParamas);
    } else {
      this.props.getCustomerList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleAjaxResponse(response) {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (this.state.activate == true) {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      } else {
        this.props.handleClick(CommonUtil.prepareDeactivateSuccessPopUpConfig());
      }
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      PopupUtil.popupErrorResponse(this);
    }
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: null, searchInput: "" });
      await this.setSelectedTabDetails(this.state.status);
    }
  }

  handleMultipleSelection = (event) => {
    this.setState({ multipleSelectionModal: true, activate: true });
  }

  getCustomerSelectionDetails = async (flag) => {
    await this.setSelectedTabDetails();
    await this.setState({ multipleSelectionModal: false, currentPage: 1, statusfilter: false, status: null, selectedFilter: statusConstant.ACTIVE_STATUS });
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter, attributeList, attributeObj, submitted, search } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={customer} alt="" className="page-icon" />
                  {customerConstant.MANAGE_CUSTOMER_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search by Customer Code/Name/Phone/Address/Email"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                {
                isAuthorized("createCustomer") &&
                  <div className="filter-status bulk-update" onClick={(e) => this.handleMultipleSelection(e)}>
                    <i title="Bulk Update" className="fa fa-pencil"  style={{color: '#212121', fontSize: '18px', cursor: 'pointer' }} />
                  </div>
                }

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}

                  {/*<Nav pullRight>
                    <NavDropdown
                      title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status"
                      onSelect={this.handleFIlter}>
                      <MenuItem eventKey={statusConstant.ACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.ACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.ACTIVE_STATUS)}
                      </MenuItem>
                      <MenuItem eventKey={statusConstant.INACTIVE_STATUS}
                        className={CommonUtil.isBothEqual(selectedFilter, statusConstant.INACTIVE_STATUS) ? 'active' : null}>
                        {StatusUtil.getStatusLabel(statusConstant.INACTIVE_STATUS)}
                      </MenuItem>
                    </NavDropdown>
                  </Nav>*/}

                  {isAuthorized("createCustomer") &&
                    <Button id={"customerId" + "_" + commonConstant.MENU_ACTION_MODE + "_" + customerConstant.CREATE_CUSTOMER}
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                    </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                      {this.state.multipleSelectionModal == true ?
                        <MultipleSelectionModal
                          getCustomerSelectionDetails={this.getCustomerSelectionDetails}>
                        </MultipleSelectionModal>
                    : null}
                </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    customerList: state.customer.customerList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    customerSearchList: state.customer.customerSearchList,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedCustomerCode: selectedCustomerCode => dispatch(setSelectedCustomerCode(selectedCustomerCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getCustomerList: params => dispatch(getCustomerList(params)),
  updateCustomerStatus: (customerDetails, customerId) => dispatch(updateCustomerStatus(customerDetails, customerId)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getCustomerSearchList: params => dispatch(getCustomerSearchList(params)),
  setCreditNoteDetails: (params) => dispatch(setCreditNoteDetails(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageCustomer);
