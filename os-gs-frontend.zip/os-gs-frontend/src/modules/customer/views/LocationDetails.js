import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl } from "react-bootstrap";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Select from "react-select";
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import { touch } from "redux-form";
import LocationUtil from "modules/common/util/locationUtil.js";
var Modal = require('react-bootstrap-modal')

class LocationDetails extends Component {
    constructor(props) {
        super(props);
        this.state = {
            openModal: true,
            submitted: false,
            customErrorFlag: false,
            attributeList: this.props.attributeList,
            attributeObj: this.props.attributeObj
        };
        this.handleSave = this.handleSave.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    componentDidMount = () => {
        if (this.props.attributeList != null) {
            this.setState({
                attributeList: this.props.attributeList,
                attributeObj: this.props.attributeObj,
            })
        }
    }

    componentDidUpdate(prevProps) {
        if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
            this.setState({
                openModal: true,
                attributeObj: this.props.attributeObj,
            })
        }
    }

    handleSave = async (event) => {
        await this.setState({ submitted: true });
        let tempObj = this.state.attributeObj;
        tempObj.locationName = tempObj.locationName.trim();
        if(this.props.attributeObj.locationName != tempObj.locationName) {
            this.isDuplicateValue(tempObj.locationName);
        }
        if (this.isValidRequestObj(tempObj) && !this.state.customErrorFlag) {
          this.props.getLocationDetails(this.state.attributeObj);
        }
    }

    isValidRequestObj = (tempObj) => {
        if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
          return false;
        }
        return true;
    }

    isDuplicateValue = (value) => {
        let filteredList = [];
        if (CommonUtil.isNotNull(this.props.locationsList) && this.props.locationsList.length > 0) {
            filteredList = this.props.locationsList.filter(function (tempObj) {
                if (CommonUtil.isNotNull(tempObj["locationName"]) && CommonUtil.isNotNull(value)) {
                    return tempObj["locationName"].toLowerCase() == value.toLowerCase().trim();
                }
            });
        }
        if (filteredList.length > 0) {
            this.setState({ customErrorFlag: true})
        } else {
            this.setState({ customErrorFlag: false})
        }
    }

    closeModal(event) {
        this.setState({ openModal: false, submitted: false });
    }

    maxLengthCheck = (object, maxLength) => {
        if (object.target.value.length > maxLength) {
            object.target.value = object.target.value.slice(0, maxLength)
        }
    };

    render() {
        const { attributeList, attributeObj, submitted, customErrorFlag } = this.state;
        return (
            <div >
                <Modal show={this.state.openModal} onHide={this.closeModal} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
                    <Modal.Header closeButton>
                        <Modal.Title><div className="card-header-capital">Add/Edit Location</div></Modal.Title>
                    </Modal.Header>
                    <Modal.Body>
                        <div className="main-content">
                            <div className="location-section">
                                <Row>
                                    {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                                        tempAttributeListObj.type == "TEXTBOX" ?
                                            <Col md={tempAttributeListObj.fieldWidth} key={index}>
                                                <FormGroup>

                                                    {tempAttributeListObj.label}
                                                    {tempAttributeListObj.required == true ? <span className="star">*</span> : null}

                                                    <FormControl rows={tempAttributeListObj.numberOfRow}
                                                        componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                                                        name={tempAttributeListObj.name}
                                                        value={attributeObj[tempAttributeListObj.name]}
                                                        onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                                                        maxLength={tempAttributeListObj.maxLength}
                                                        minLength={tempAttributeListObj.minLength}
                                                        onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
                                                        onChange={(e) => {
                                                            this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                                            tempAttributeListObj.inputType == "number" ?
                                                                CommonUtil.handleNumberChange(e, this) :
                                                                CommonUtil.handleTextBoxChange(e, this)
                                                        }} />

                                                    {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                                        <small className="text-danger">
                                                            {tempAttributeListObj.mandatoryMsgText}
                                                        </small>
                                                    }
                                                    {submitted && customErrorFlag && attributeObj[tempAttributeListObj.name] &&
                                                        <small className="text-danger">
                                                          {tempAttributeListObj.customMessage}
                                                        </small>
                                                    }
                                                    {(touch || submitted) && tempAttributeListObj.maxLength && attributeObj[tempAttributeListObj.name] &&
                                                        +attributeObj[tempAttributeListObj.name].length >= +tempAttributeListObj.maxLength &&
                                                        <small className="text-danger">
                                                            Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                                        </small>
                                                    }
                                                    {(touch || this.props.submitted) && tempAttributeListObj.minLength && attributeObj[tempAttributeListObj.name] &&
                                                      +attributeObj[tempAttributeListObj.name].length < +tempAttributeListObj.minLength &&
                                                      <small className="text-danger">
                                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                                      </small>
                                                    }

                                                </FormGroup>
                                            </Col>

                                            : tempAttributeListObj.type == "DROPDOWN" ?
                                                <Col md={tempAttributeListObj.fieldWidth} key={index}>
                                                    <FormGroup>
                                                        {tempAttributeListObj.label}
                                                        {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                                        <Select name={tempAttributeListObj.name}
                                                            onChange={(e, obj) => LocationUtil.handleLocationDropDownChange(e, obj, this)}
                                                            isMulti={tempAttributeListObj.isMulti}
                                                            value={{ "label": attributeObj[tempAttributeListObj.name] }}
                                                            classNamePrefix="react-select"
                                                            placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options} />
                                                        {submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                                            <small className="text-danger">
                                                                {tempAttributeListObj.mandatoryMsgText}
                                                            </small>
                                                        }
                                                    </FormGroup>
                                                </Col>

                                                : tempAttributeListObj.type = "CHECKBOX" ?
                                                    <Col md={9} key={index} >
                                                        <CustomCheckbox inline number={tempAttributeListObj.name}
                                                            checked={attributeObj[tempAttributeListObj.name]}
                                                            label={tempAttributeListObj.label} onClick={(e) => CommonUtil.handleCheckBoxChange(e, this)} />
                                                    </Col>
                                                    : null))

                                    }
                                </Row>
                            </div>

                            <div className="modal-buttons">
                                <Button className="btn-cancel" onClick={this.closeModal}>
                                    Cancel
                                </Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>
                                    Save
                                </Button>
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>
            </div>
        );
    }
}

export default LocationDetails;

