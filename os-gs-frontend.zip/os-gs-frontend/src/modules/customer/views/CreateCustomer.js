import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab, FormGroup, ControlLabel, FormControl, InputGroup } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { setCustomerDetails, getCustomerDetails, setReducerInitMode } from "../actions/customerActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as customerConstant from '../constant/customerConstant';
import LocationDetails from "./LocationDetails.js";
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import LocationUtil from '../../common/util/locationUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import _ from 'lodash'
import LabelUtil from '../../common/util/labelUtil';
import customer from "assets/img/customer-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import Select from "react-select";
import { touch } from "redux-form";
import currencyIcon from '../../common/util/currencyIcon';
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getTierPricingDetails } from "../../dataDictionary/actions/dataDictionaryActions.js";
import * as commonConstant from '../../common/constant/commonConstant';
import TagsInput from "react-tagsinput";
class CreateCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      openLocationModal: false,
      locationAttributeObj: null,
      customerId: null,
      submitted: false,
      alert: null,
      products: [],
      ingredients: [],
      selectedTab: "PRODUCT",
      ingredientTableKey: "ingredients",
      productTableKey: "products",
      cusFacList: [{}],
      facilityList: [],
      emailIds : [],
      phone : []
    };

    this.handleSave = this.handleSave.bind(this);
    this.getDocumentDetails = this.getDocumentDetails.bind(this);
    this.getLocationDetails = this.getLocationDetails.bind(this);
    this.handleLocationChange = this.handleLocationChange.bind(this);
    this.handleAddEditLocation = this.handleAddEditLocation.bind(this);
    this.handleRemoveLocation = this.handleRemoveLocation.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleFilledTagsEmail = this.handleFilledTagsEmail.bind(this);
    this.handleFilledTagsPhone = this.handleFilledTagsPhone.bind(this)
  }

  getDropDownOptionsFromTierPricing = (attributeList, dataDictionaryList) => {
    var validParams = attributeList != null && attributeList.length > 0 &&
      dataDictionaryList != null && dataDictionaryList.length > 0;
    if (validParams) {
      var tempAttributeList = [...attributeList];
      for (var i = 0; i < attributeList.length; i++) {
        if (attributeList[i].tierPriceFlag) {
          tempAttributeList[i].options = [{ label: '--None--', value: null }, ...(dataDictionaryList.map(item => ({ label: item.tierName, value: item.tierId })))];
        }
      }
      return tempAttributeList;
    }
    return attributeList;
  }

  componentDidMount = async () => {
    mixpanel.track("Create Customer loaded");
    let searchInput = CommonUtil.getAdditonalPathSearch(this);
    await this.setState({searchInput : searchInput ? searchInput : ''});
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getCustomerDetails(this.props.selectedCustomerCode);
      }
    }
    else {
      CommonUtil.handlePageRedirection(customerConstant.MANAGE_CUSTOMER_PAGE_URL, this);
    }
    this.props.getFacilityList({ isDropdown: true });
    this.props.getTierPricingDetails();
    const commonAttributeList = pagePropertyListConstant.CREATE_CUSTOMER_PAGE_LIST;
    const locationPageList = pagePropertyListConstant.LOCATION_PAGE_LIST;
    await this.setState({
      // attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        // commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeList: this.getDropDownOptionsFromTierPricing(commonAttributeList.attributeList, this.props.tierPricing),
      attributeObj: commonAttributeList.attributeObj,
      locationAttributeObj: locationPageList.attributeObj,
      locationAttributeList: LocationUtil.getCountryList(locationPageList.attributeList),
      cusFacList: [{}],
      attributeListOpeningBalance: commonAttributeList.attributeListOpeningBalance,
      attributeListDocuments: commonConstant.FILEUPLOAD_STAGE_LIST.attributeList,
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj, this.props.tierPricing);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
  }

  async updateApiData(attributeObj, tierPricing) {
    const commonAttributeList = pagePropertyListConstant.CREATE_CUSTOMER_PAGE_LIST;
    await this.setState({
      attributeList: this.getDropDownOptionsFromTierPricing(commonAttributeList.attributeList, tierPricing),
      attributeObj: {
        ...attributeObj,
        customerId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.customerId,
        customerName: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.customerName,
        emailIds: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.emailIds,
        documents: CommonUtil.isCloneMode(this.props.actionMode) ?
          [] : attributeObj.documents,
        countryCode: _.get(attributeObj, 'countryCode') ? attributeObj.countryCode : '+1',
      },
      cusFacList: !CommonUtil.isCloneMode(this.props.actionMode) ? attributeObj && attributeObj.cusFacList ? [...attributeObj.cusFacList] : [{}] : [{}],
      emailIds: attributeObj.email && typeof attributeObj.email == 'string'  ? String(attributeObj.email).split(',') : [],
      phone: attributeObj.phone && typeof attributeObj.phone == 'string'  ? String(attributeObj.phone).split(',') : [],
    })
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleSave = async (event) => {
    this.setState({ submitted: true, alert: null });
    let tempObj = _.cloneDeep(this.state.attributeObj);
    const customerId = this.state.attributeObj.customerId ? this.state.attributeObj.customerId : '';
    tempObj && tempObj.locations.length > 0 && tempObj.locations.forEach(item => {
      CommonUtil.isCloneMode(this.props.actionMode) && delete item.locationId;
      item.isDefault = item.isDefault ? item.isDefault : false;
      return item;
    })
    delete tempObj.customerId;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, this.props.actionMode);
  
    tempObj.cusFacList = [];
    tempObj.cusFacList = [...this.state.cusFacList];
    tempObj.emailIds = [...this.state.emailIds];
    tempObj.phone = [...this.state.phone]

    if (tempObj.cusFacList != null && tempObj.cusFacList.length > 0) {
      tempObj.cusFacList = tempObj.cusFacList.filter(x => x.facilityId !== "")
    } else {
      tempObj.cusFacList = [];
    }
    if (this.isValidRequestObj(tempObj)) {
      delete tempObj.creditAmount;
      delete tempObj.loyaltyPoints;
      this.props.setCustomerDetails(tempObj, this.props.actionMode, CommonUtil.getFloatValue(customerId));
    }
    
  }

  getDocumentDetails(documents) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        documents: [...documents]
      }
    })
  }

  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }
    if (tempObj.locations.length < 1) {
      return false;
    }
    if (tempObj.documents.length > 0) {
      if (!ValidationUtil.validateArrayListRequestObj(tempObj.documents,
        this.state.attributeListDocuments)) {
        return false;
      }
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      setTimeout(this.handlePopupContinue, 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = this.state.attributeObj.status ? this.state.attributeObj.status : null;
    CommonUtil.handlePageRedirection(customerConstant.MANAGE_CUSTOMER_PAGE_URL, this, params);
  }

  handleLocationChange(locationAttributeObj) {
    var isDefault = locationAttributeObj && locationAttributeObj.isDefault;
    var tempLocationList = LocationUtil.updateLocationListObj(this, isDefault);
    if (locationAttributeObj != null) {
      tempLocationList.push({ ...locationAttributeObj });
    }
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        locations: [...tempLocationList]
      }
    })
  }

  handleAddEditLocation = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("_") : null;
    var locationAttributeObj = new Object();
    var locationId = null;

    if (id != null) {

      if (tempId[1] === "EDIT") {
        locationAttributeObj = { ...this.state.attributeObj.locations[tempId[0]] };
        await LocationUtil.populateStateList(this.state.locationAttributeList, locationAttributeObj.country);
        await LocationUtil.populateCityList(this.state.locationAttributeList, locationAttributeObj.state);
        locationId = tempId[0];
      }
      if (tempId[1] === "ADD") {
        locationAttributeObj = { ...pagePropertyListConstant.LOCATION_PAGE_LIST.attributeObj };
        locationId = this.state.attributeObj.locations.length + 1;
      }

      await this.setState({
        openLocationModal: true,
        selectedLocationId: locationId,
        locationAttributeObj: { ...locationAttributeObj }
      })
    }
  }

  async handleRemoveLocation(event, index) {
    var id = event != undefined ? event.target.id : null;
    await this.setState({
      selectedLocationId: id
    });
    this.handleLocationChange(null);
  }

  getLocationDetails(locationAttributeObj) {
    this.setState({ openLocationModal: false });
    this.handleLocationChange({ ...locationAttributeObj });
  }

  handleSelect = (key) => {
    this.setState({ key });
  };

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(
      this.props.facilityList, 'facilityId', 'facilityName', "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))
    await this.setState({
      facilityList: tempList,
    })
  }

  async handleOpeningBalanceTextBoxChange(event) {
    const { name, value } = event.target;
    const re = /^\d+(\.\d{0,2})?$/;
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.cusFacList];
    let tempValue = (value === '' || re.test(value)) ? value : await CommonUtil.getFloatValue(value.substring(0, value.length - 1), true)
    attributeDataList[id][name] = tempValue;
    await this.setState({ cusFacList: [...attributeDataList] });
  }

  handleRemove = (event) => {
    let id = parseInt(event.target.id.split('_')[1]);
    let attributeDataList = [...this.state.cusFacList];
    let tempAttributeDataList = [];
    for (let i = 0; i < attributeDataList.length; i++) {
      if (id !== i) {
        tempAttributeDataList.push({ ...attributeDataList[i] });
      }
    }
    this.setState({ cusFacList: [...tempAttributeDataList] });
  }

  handleAddTerms = (event) => {
    let { cusFacList } = this.state;
    let tempDictionaryList = [...cusFacList];
    let tempObj = {};
    tempDictionaryList.push(tempObj);
    this.setState({ cusFacList: [...tempDictionaryList] });
  }

  handleFilledTagsEmail(filledTags) {  
    this.setState({
      emailIds: filledTags, 
    });
  }
  handleFilledTagsPhone(filledTags){
    this.setState({
      phone : filledTags
    })
  }
  maxLengthCheck(object, maxLength) {
    if (object.target.value.length > maxLength) {
      object.target.value = object.target.value.slice(0, maxLength)
    }
  }

  render() {
    const { attributeList, attributeObj, locationAttributeObj,
      locationAttributeList, submitted, customErrorFlag, customEmailErrorFlag, attributeListOpeningBalance } = this.state;
    const actionMode = this.props.actionMode;
    let cusFacList = this.state.cusFacList.map(x => {
      this.state.facilityList && this.state.facilityList.map(y => {
        if (x.facilityId == y.value) {
          x.name = y.label
        }
      })
      return x;
    })
    let optionsList = [];
    optionsList = this.state.facilityList && this.state.facilityList.filter(function (x) {
      return cusFacList.filter(function (y) {
        return y.facilityId == x.value;
      }).length == 0
    });
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params, searchInput: this.state.searchInput }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={customer} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    customerConstant.EDIT_CUSTOMER_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      customerConstant.VIEW_CUSTOMER_HEADER_TITLE
                      : customerConstant.CREATE_CUSTOMER_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        <Col md={6}>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode,
                                    customErrorFlag, customEmailErrorFlag)
                                    : tempAttributeListObj.type == "TEXT_LIST" && tempAttributeListObj.name == "emailIds"  && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    (<Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                      <FormGroup >
                                        <ControlLabel>
                                          {tempAttributeListObj.label}
                                          {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                        </ControlLabel>
                                        <TagsInput
                                          value={this.state.emailIds}
                                          onChange={this.handleFilledTagsEmail}
                                          tagProps={{
                                            className: "react-tagsinput-tag tag-fill tag-grey",
                                          }}
                                          className="react-tagsinput-normal"
                                          disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                                          inputProps={{
                                            placeholder: tempAttributeListObj.placeholder,
                                          }}
                                          
                                          addOnBlur={true}
                                        />
                                      </FormGroup>
                                    </Col>) 
                                     : tempAttributeListObj.type == "TEXT_LIST" && tempAttributeListObj.name == "phone" && tempAttributeListObj[actionMode + 'ShowFlag'] == true  ?
                                    (<Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                      <FormGroup >
                                        <ControlLabel>
                                          {tempAttributeListObj.label}
                                          {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                        </ControlLabel>
                                        <TagsInput
                                          value={this.state.phone}
                                          onChange={this.handleFilledTagsPhone}
                                          tagProps={{
                                            className: "react-tagsinput-tag tag-fill tag-grey",
                                          }}
                                          className="react-tagsinput-normal"
                                          disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : false}
                                          inputProps={{
                                            placeholder: tempAttributeListObj.placeholder,
                                          }}
                                          
                                          addOnBlur={true}
                                        />
                                      </FormGroup>
                                    </Col>) 
                                  : tempAttributeListObj.type == "DROPDOWN" ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                    
                                    : null))
                            }
                          </Row>

                        </Col>


                        {this.state.openLocationModal ?
                          <LocationDetails attributeList={locationAttributeList}
                            attributeObj={locationAttributeObj}
                            getLocationDetails={this.getLocationDetails}
                            locationsList={this.state.attributeObj.locations}
                          ></LocationDetails>
                          : null}

                        <Col md={6}>
                          <h5 className="title">{customerConstant.LOCATION_HEADER_TITLE}<span className="star">*</span></h5>

                          <div className="loaction-tabs">

                            {attributeObj != null && attributeObj.locations != null && attributeObj.locations.length > 0 ?
                              attributeObj.locations.map((tempAttributeListObj, index) => (
                                <div key={index} className="loaction-tab">
                                  <div className="heading"><span className="location-title"><b>Location: </b></span> <span className="location-value">{tempAttributeListObj.locationName}</span></div>
                                  <div className="address">
                                    <p>
                                      <span>{tempAttributeListObj.address}</span>
                                      <span>{tempAttributeListObj.city}</span>
                                      <span>{tempAttributeListObj.state}</span>
                                      <span>{tempAttributeListObj.zipcode}</span>
                                    </p>
                                    <p>{tempAttributeListObj.country}</p>
                                  </div>
                                  {tempAttributeListObj.isDefault ?
                                    <div className="location-actions">
                                      <div className={CommonUtil.isViewMode(this.props.actionMode) ? "circle disabled" : "circle"}>
                                        <i id={index + "_EDIT"} onClick={(event) => this.handleAddEditLocation(event)} className="fa fa-pencil" />
                                      </div>&nbsp;&nbsp;|&nbsp;
                                      <div className={CommonUtil.isViewMode(this.props.actionMode) ? "circle disabled" : "circle"}>
                                        <i id={index} onClick={(event) => this.handleRemoveLocation(event)} className="fa fa-trash" />
                                      </div>&nbsp;&nbsp;|&nbsp;
                                      <span className="location-title"><b>Default</b></span>
                                    </div>
                                    :
                                    <div className="location-actions">
                                      <div className={CommonUtil.isViewMode(this.props.actionMode) ? "circle disabled" : "circle"}>
                                        <i id={index + "_EDIT"} onClick={(event) => this.handleAddEditLocation(event)} className="fa fa-pencil" />
                                      </div>&nbsp;&nbsp;|&nbsp;
                                      <div className={CommonUtil.isViewMode(this.props.actionMode) ? "circle disabled" : "circle"}>
                                        <i id={index} onClick={(event) => this.handleRemoveLocation(event)} className="fa fa-trash" />
                                      </div>
                                    </div>
                                  }
                                </div>
                              ))
                              : null}

                            <Button className={CommonUtil.isViewMode(this.props.actionMode) ? "add-location loaction-tab disabled" : "add-location loaction-tab"} id={"" + "_ADD"} onClick={(event) => this.handleAddEditLocation(event)}>
                              <i className="fa fa-plus" id={"" + "_ADD"} />
                              <span id={"" + "_ADD"}>Add Location</span>
                            </Button>
                            {submitted && attributeObj.locations != null && attributeObj.locations.length == 0 ?
                              <small className="text-danger">
                                {customerConstant.ADDRESS_MANDATORY_MSG}
                              </small>
                              : null}
                          </div>
                        </Col>
                      </Row>
                      {cusFacList && <Row>
                        <Col md={12}>
                          <div className="orgcontact-title">Opening Balance</div>
                        </Col>
                      </Row>}
                      {cusFacList != null && cusFacList.map((tempAttributeDataListObj, index) => (
                        <Row className="terms-dictionary" key={index}>
                          {attributeListOpeningBalance != null && attributeListOpeningBalance.map((tempAttributeListObj, index1) => (
                            tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index1}>
                                <FormGroup>
                                  <ControlLabel style={{ marginBottom: '0px', fontWeight: 'normal' }}>
                                    <span> {tempAttributeListObj.label}
                                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}</span>
                                  </ControlLabel>
                                  <InputGroup>
                                    {tempAttributeListObj.showCurrency ?
                                      <InputGroup.Addon>
                                        {currencyIcon.getCurrencyIcon(this.props.currencyCode)}
                                      </InputGroup.Addon>
                                      : null}
                                    <FormControl
                                      id={tempAttributeListObj.name + '_' + index}
                                      componentClass={tempAttributeListObj.numberOfRow == 0 ? 'input' : 'textarea'}
                                      name={tempAttributeListObj.name}
                                      onPaste={(e) => tempAttributeListObj.inputType == "number" ? CommonUtil.handleNumberPaste(e, this) : null}
                                      onChange={(e) => {
                                        this.maxLengthCheck(e, tempAttributeListObj.maxLength)
                                        this.handleOpeningBalanceTextBoxChange(e)
                                      }}
                                      disabled={tempAttributeListObj[actionMode] == 'disabled' ? true : true}
                                      value={tempAttributeDataListObj[tempAttributeListObj.name]}
                                      min={tempAttributeListObj.minValue}
                                      maxLength={tempAttributeListObj.maxLength}
                                      minLength={tempAttributeListObj.minLength}
                                      rows={tempAttributeListObj.numberOfRow}
                                    />
                                  </InputGroup>
                                  {(touch || submitted) && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.maxLength ?
                                    tempAttributeDataListObj[tempAttributeListObj.name].toString().length >= tempAttributeListObj.maxLength ?
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                      : null
                                    : null
                                  }
                                  {(touch || submitted) && tempAttributeDataListObj[tempAttributeListObj.name] && tempAttributeListObj.minLength ?
                                    tempAttributeDataListObj[tempAttributeListObj.name].toString().length < tempAttributeListObj.minLength ?
                                      <small className="text-danger">
                                        Allowed characters limit is {tempAttributeListObj.minLength} to {tempAttributeListObj.maxLength}
                                      </small>
                                      : null
                                    : null
                                  }
                                  {(submitted) && tempAttributeListObj.required && !CommonUtil.isNotNull(tempAttributeDataListObj[tempAttributeListObj.name]) &&
                                    <small className="text-danger">
                                      {tempAttributeListObj.mandatoryMsgText}
                                    </small>
                                  }
                                </FormGroup>
                              </Col>
                              : tempAttributeListObj.type == "DROPDOWN" ?
                                <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                                  <FormGroup>
                                    {tempAttributeListObj.label}
                                    {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                    <Select name={tempAttributeListObj.name}
                                      id={tempAttributeListObj.name + '_' + index}
                                      onChange={(value) => this.handleFacilityDropdownChange(index, value)}
                                      isMulti={tempAttributeListObj.isMulti}
                                      value={{ "label": this.state.cusFacList[index].name ? this.state.cusFacList[index].name : '' }}
                                      classNamePrefix="react-select"
                                      isDisabled={tempAttributeListObj[actionMode] == 'disabled' ? true : true}
                                      placeholder={tempAttributeListObj.placeholder} options={[...optionsList]} />
                                    {(touch || submitted) && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                                      <small className="text-danger">
                                        {tempAttributeListObj.mandatoryMsgText}
                                      </small>
                                    }
                                  </FormGroup>
                                </Col>
                                : null))}
                          {/* <Col md={2}>
                            {optionsList && optionsList.length > 0 && <i className="fa fa-plus" onClick={this.handleAddTerms}></i>}
                            {cusFacList.length > 1 && <i id={"REMOVE" + '_' + index} className="fa fa-close" onClick={this.handleRemove}></i>}
                          </Col> */}
                        </Row>
                      ))}
                      <Row>
                        <Col md={6}>
                          <Card
                            plain
                            title={customerConstant.DOCUMENT_HEADER_TITLE}
                            content={
                              <DragDrop
                                minSize={0}
                                maxSize={5000000}
                                multiple={false}
                                disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                errormsg="File size exceed max size limit of 5 MB."
                                typeerror="File type is not accepted"
                                getdocumentdetails={this.getDocumentDetails}
                                files={attributeObj != null && attributeObj.documents.length > 0 ?
                                  attributeObj.documents : null}
                                fileNamePrefix={attributeObj != null && attributeObj.customerId && _.isString(attributeObj.customerId) ? parseInt(attributeObj.customerId.split('-')[1]) : null}
                                moduleName="customer"
                              />
                            }
                          />
                        </Col>

                      </Row>

                    </div>
                  }

                />
              </form>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>

        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.customer.customerDetails,
    selectedCustomerCode: state.customer.selectedCustomerCode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    facilityList: state.facility.facilityList,
    tierPricing: state.dataDictionary.tierPricing,
  };
}

const mapDispatchToProps = dispatch => ({
  setCustomerDetails: (customerDetailsObj, actionMode, customerId) => dispatch(setCustomerDetails(customerDetailsObj, actionMode, customerId)),
  getCustomerDetails: selectedCustomerCode => dispatch(getCustomerDetails(selectedCustomerCode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getTierPricingDetails: () => dispatch(getTierPricingDetails()),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateCustomer);
