import axios from '../../../axios/axios';
import * as customerActionTypes from './customerActionTypes';
import * as customerConstant from '../constant/customerConstant';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';
import * as actionTypes from '../../../actions/actionTypes';


export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: customerActionTypes.SET_CUSTOMER_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setCustomerDetails(customerDetailsObj, actionMode, customerId) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(customerConstant.SET_CREATE_CUSTOMER_DETAILS_URL,
        customerDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(customerConstant.SET_UPDATE_CUSTOMER_DETAILS_URL +
        customerId, customerDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedCustomerCode(selectedCustomerCode) {
  return function (dispatch) {
    dispatch({
      type: customerActionTypes.SET_SELECTED_CUSTOMER_CODE,
      payload: selectedCustomerCode
    });
  }
}

export function getCustomerList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(customerConstant.GET_CUSTOMER_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: customerActionTypes.GET_CUSTOMER_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getCustomerDetails(selectedCustomerCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(customerConstant.GET_CUSTOMER_DETAILS_URL + selectedCustomerCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: customerActionTypes.GET_CUSTOMER_DETAILS,
          payload: response.data[0]
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function updateCustomerStatus(customerDetailsObj, customerId) {
  let params = { limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(customerConstant.SET_UPDATE_CUSTOMER_STATUS_URL + customerId,
      customerDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(customerConstant.GET_CUSTOMER_LIST_URL, { params: params }).then(response => {
            if (response.status == 200) {
              dispatch(setAjaxCallStatus(updateApiResponse(response)));
              dispatch({
                type: customerActionTypes.GET_CUSTOMER_LIST,
                payload: response.data
              });
            }
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
      });
  }
}

export function getCustomerSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(customerConstant.GET_CUSTOMER_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: customerActionTypes.GET_CUSTOMER_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function setBulkCustomers(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(customerConstant.SET_CREATE_BULK_CUSTOMER_URL, params).then(response => {
        if (response.status == 200) {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch({
            type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
            payload: response.data.uploadDetails
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
        throw error;
      });
  };
}

export function setCustomerDocuments(documentObj, documentIdObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    let headers = {
      'Content-Type':'application/x-www-form-urlencoded'
    }
    axios.post(customerConstant.SET_CUSTOMER_DOCUMENTS_URL, documentObj).then(response => {
      if (response.status == 201) {
        documentIdObj.documentURL = response.data;
        dispatch({
          type: customerActionTypes.SET_UPLOADED_FILE_URL,
          payload: documentIdObj
        });
      }
      else {
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      dispatch(endAjaxCall());
    });
  };
}
export function getCustomerPaymentDetails(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(customerConstant.GET_CUSTOMER_PAYMENT_DETAILS_URL, { params: params }).then(response => {
      if (response.status == 200 && CommonUtil.isNotNull(response.data)) {
        dispatch({
          type: customerActionTypes.GET_CUSTOMER_PAYMENT_DETAILS,
          payload: response.data[0]
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}
export function setCustomerTierPrice(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.put(customerConstant.SET_CUSTOMER_TIER_PRICE, params).then(response => {
      dispatch(setAjaxCallStatus(updateApiResponse(response)));
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}