import axios from '../../../axios/axios';
import * as documentActionTypes from './documentActionTypes';
import * as documentConstant from '../constant/documentConstant';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: documentActionTypes.SET_DOCUMENT_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setDocumentDetails(documentDetailsObj, actionMode) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(documentConstant.SET_CREATE_DOCUMENT_DETAILS_URL,
        documentDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(documentConstant.SET_UPDATE_DOCUMENT_DETAILS_URL +
        documentDetailsObj.documentDetailsCode, documentDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedDocumentDetailsCode(selecteddocumentDetailsCode) {
  return function (dispatch) {
    dispatch({
      type: documentActionTypes.SET_SELECTED_DOCUMENT_CODE,
      payload: selecteddocumentDetailsCode
    });
  }
}

export function getDocumentDetailsList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(documentConstant.GET_DOCUMENT_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: documentActionTypes.GET_DOCUMENT_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}


export function getDocumentDetails(selecteddocumentDetailsCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(documentConstant.GET_DOCUMENT_DETAILS_URL +
      selecteddocumentDetailsCode).then(response => {
        if (response.status == 200) {
          dispatch({
            type: documentActionTypes.GET_DOCUMENT_DETAILS,
            payload: response.data.Item
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
      });
  };
}

export function updateDocumentDetailsStatus(documentDetailsObj, documentDetailsCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(documentConstant.SET_UPDATE_DOCUMENT_STATUS_URL +
      documentDetailsCode, documentDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(documentConstant.GET_DOCUMENT_LIST_URL).then(response => {
            if (response.status == 200) {
              dispatch({
                type: documentActionTypes.GET_DOCUMENT_LIST,
                payload: response.data
              })
            }
            dispatch(endAjaxCall());
          })
        }
      }).catch(error => {
        dispatch(endAjaxCall());
      });
  };
}

export function updateDocumentDetailsDeleteStatus(documentDetailsObj, documentDetailsCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(documentConstant.SET_UPDATE_DOCUMENT_STATUS_URL +
      documentDetailsCode, documentDetailsObj).then(response => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}



