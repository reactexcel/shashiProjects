export const MANAGE_DOCUMENT_HEADER_TITLE = "Document Management";
export const MODULE_NAME = "Document";

export const CREATE_DOCUMENT = "createIncident";
export const DEATIVATE_DOCUMENT = "deActivate";
export const ACTIVATE_DOCUMENT = "activate";

export const MANAGE_DOCUMENT_PAGE_URL = '/admin/manage-documents';
export const CREATE_DOCUMENT_PAGE_URL = '/admin/manage-documents';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_DOCUMENT_LIST_URL = `${BASE_URL}/documents`;
export const GET_DOCUMENT_DETAILS_URL = `${BASE_URL}/documents/`;
export const SET_CREATE_DOCUMENT_DETAILS_URL = `${BASE_URL}/documents/`;
export const SET_UPDATE_DOCUMENT_DETAILS_URL = `${BASE_URL}/documents/`;
export const SET_UPDATE_DOCUMENT_STATUS_URL = `${BASE_URL}/documents/`;
export const GET_USER_LIST = `${BASE_URL}/users`;


export const dataTable = [];