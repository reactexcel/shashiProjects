import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import StatusUtil from "../../common/util/statusUtil";
import CommonUtil from "../../common/util/commonUtil";
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import isAuthorized from "auth-plugin";
import pdf from 'assets/img/pdf.svg';
import upload from 'assets/img/upload.svg';
import moment from "moment";


export const SEARCH_DOCUMENT_PAGE_LIST =
{
    // attributeObj: {
    //     mfgOdr: '',
    //     purchaseOdr: '',
    //     byDate: '',
    //     supplier: '',
    //     byStatus: '',
    // },

    // attributeList: [
    //     {
    //         name: "mfgOdr",
    //         type: "TEXTBOX",
    //         label: "",
    //         inputType: "text",
    //         required: false,
    //         fieldWidth: 2,
    //         placeholder: "Manufacturing Order",
    //         numberOfRow: 0,
    //     },
    //     {
    //         name: "purchaseOdr",
    //         type: "TEXTBOX",
    //         label: "",
    //         inputType: "text",
    //         required: false,
    //         fieldWidth: 2,
    //         placeholder: "Purchase Order",
    //         numberOfRow: 0,
    //     },
    //     {
    //         name: "byDate",
    //         type: "DATE",
    //         label: "",
    //         inputType: "text",
    //         required: false,
    //         fieldWidth: 2,
    //         placeholder: "Search By Date",
    //         numberOfRow: 0,
    //     },
    //     {
    //         name: "supplier",
    //         type: "TEXTBOX",
    //         label: "",
    //         inputType: "text",
    //         required: false,
    //         fieldWidth: 2,
    //         placeholder: "Supplier",
    //         numberOfRow: 0,
    //     },
    //     {
    //         name: "byStatus",
    //         type: "DROPDOWN",
    //         label: "",
    //         inputType: "text",
    //         required: false,
    //         isMulti: false,
    //         fieldWidth: 2,
    //         placeholder: "Search By Status",
    //         numberOfRow: 0,
    //         options: [
    //             { value: "All", label: "All" },
    //             { value: "Active", label: "Active" },
    //             { value: "Expire", label: "Expire" }
    //         ],
    //     },
    // ],
};

export const MANAGE_DOCUMENT_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Source",
                id: "source",
                accessor: "source",
                style: {
                    flex: '0 0 120px',
                },
            },
            {
                Header: "Document Type",
                id: "documentType",
                accessor: "docType",
            },
            {
                Header: "Document Name",
                id: "documentName",
                accessor: "docName"
            },
            {
                Header: "Ref No",
                id: "refNumber",
                accessor: "refNumber",
                style: {
                    flex: '0 0 80px',
                },
            },
            {
                Header: "Created Date",
                id: "createdTime",
                accessor: "createdTime",
                disableSortBy: false,
                specialFilter: false,
            },
            {
                Header: "Expiry Date",
                id: "docExpiry",
                accessor: "docExpiry",
                style: {
                    flex: '0 0 100px',
                },
                disableSortBy: false,
                specialFilter: false,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        CommonUtil.getFormattedDate(value)
                    )
                }
            },
            // {
            //     Header: "Updated Date",
            //     id: "modifieddate",
            //     accessor: "modifieddate",
            //     disableSortBy: true,
            //     specialFilter: true,
            //     style: {
            //         flex: '0 0 140px',
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         return (
            //             <div>
            //                 {value}
            //             </div>
            //         )
            //     }
            // },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: '0 0 100px',
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var isDateExpired = CommonUtil.isDateExpired(original.docExpiry);
                    var documentStatus = isDateExpired ? statusConstant.EXPIRE_STATUS : statusConstant.ACTIVE_STATUS
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(documentStatus)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(documentStatus)}</div>
                        </div>
                    )
                }
            },
            {
                Header: "Document",
                id: "fileType",
                accessor: "fileType",
                // style: {
                //     flex: '0 0 75px',
                // },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">

                            <Button bsStyle="default" simple icon >
                                { isAuthorized("downloaddocuments") ?
                                    <a href={original.docUrl} download="click to download">
                                        <img title="document" src={CommonUtil.getDocumentIcon(value)} alt="Document" />
                                    </a>
                                : <img title="document" src={CommonUtil.getDocumentIcon(value)} alt="Document" /> }
                            </Button>
                        </div>
                    )
                }
            },
            {
                Header: "Action",
                id: "action",
                accessor: "action",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: '0 0 50px',
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                { isAuthorized("editDocuments") &&
                                    <div className="circle">
                                        <i title="view"  id={original.refNumber +"_" + commonConstant.VIEW_ACTION_MODE +
                                            "_" + index} className="fa fa-eye" onClick={(e) => that.handleEditClone(e,original.source)} />
                                    </div>
                                }
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [
                {
                    id: "refNumber",
                    desc: true
                }
            ],
            defaultPageSize: 50,
            rowId: 'source',
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

