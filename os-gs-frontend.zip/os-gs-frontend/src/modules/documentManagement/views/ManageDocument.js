import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tab, Tabs } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as documentDetailsConstant from '../constant/documentConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { getDocumentDetailsList, updateDocumentDetailsStatus } from "../actions/documentActions";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopupUtil from '../../common/util/popupUtil';
import { setActionMode } from "../../../actions/appActions";
import { setSelectedFacilityCode } from "../../facilityManagement/actions/facilityActions";
import { setSelectedSupplierCode } from "../../supplierManagement/actions/supplierActions";
import { setSelectedSaleOrderCode } from "../../saleOrder/actions/saleOrderActions";
import { setSelectedMfgOrderCode } from "../../manufacturingOrder/actions/mfgOrderActions";
import { setSelectedCustomerCode } from "../../customer/actions/customerActions";
import PopularTableUtil from '../../common/util/popularTableUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as facilityConstant from '../../facilityManagement/constant/facilityConstant';
import * as supplierConstant from '../../supplierManagement/constant/supplierConstant';
import PaginationUtil from '../../common/util/paginationUtil';
import { setSelectedPurchaseOrderCode } from "../../purchaseOrder/actions/purchaseOrderActions";
import StatusUtil from '../../common/util/statusUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import * as commonConstant from '../../common/constant/commonConstant';
import DateUtil from "../../common/util/dateUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import check from 'assets/img/check.svg';
import filter from "assets/img/filter.svg";
import pin from "assets/img/pin.svg";
import * as purchaseOrderConstant from '../../purchaseOrder/constant/purchaseOrderConstant';
import * as saleOrderConstant from '../../saleOrder/constant/saleOrderConstant';
import * as mfgOrderConstant from '../../manufacturingOrder/constant/mfgOrderConstant';
import * as customerConstant from '../../customer/constant/customerConstant';
import { getUserProfile } from "../../userManagement/actions/userActions";
import documentmangment from "assets/img/Document-Mangment-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import isAuthorized from "auth-plugin";

class DocumentDetails extends Component {

  constructor(props) {
    super(props);
    this.state = {
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,
      attributeList: null,
      submitted: false,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }


  componentDidMount = () => {
      mixpanel.track("Manage documents loaded");
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.setSelectedTabDetails();
  }

  setSelectedTabDetails = async () => {
    const managePageList = pagePropertyListConstant.MANAGE_DOCUMENT_PAGE_LIST(this);
    let additionalParams = {};
    additionalParams = CommonUtil.getAdditonalPathParams(this) ?
     CommonUtil.getAdditonalPathParams(this) : {};
    if (CommonUtil.isNotNull(this.state.source)) {
      additionalParams.source = this.state.source;
    }
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      attributeList: pagePropertyListConstant.SEARCH_DOCUMENT_PAGE_LIST.attributeList,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  }


  componentDidUpdate(prevProps) {
    if (prevProps.documentDetailsList != this.props.documentDetailsList && this.props.documentDetailsList != null) {
      PaginationUtil.handlePagination(this.props.documentDetailsList, this);
    }
  }


  handleEditClone = (event, source) => {
    var tempId = event.target.id.split("_");
    this.props.setActionMode(tempId[1]);
    if (source == 'facility') {
      this.props.setSelectedFacilityCode(tempId[0]);
      CommonUtil.handlePageRedirection(facilityConstant.CREATE_FACILITY_PAGE_URL, this);
    }
    if (source == 'supplier') {
      this.props.setSelectedSupplierCode(tempId[0]);
      CommonUtil.handlePageRedirection(supplierConstant.CREATE_SUPPLIER_PAGE_URL, this);
    }
    if (source == 'procure') {
      this.props.setSelectedPurchaseOrderCode(tempId[0]);
      CommonUtil.handlePageRedirection(purchaseOrderConstant.CREATE_PURCHASE_ORDER_PAGE_URL, this);
    }
    if (source == 'sell') {
      this.props.setSelectedSaleOrderCode(tempId[0]);
      CommonUtil.handlePageRedirection(saleOrderConstant.CREATE_SALE_ORDER_PAGE_URL, this);
    }
    if (source == 'make') {
      this.props.setSelectedMfgOrderCode(tempId[0]);
      CommonUtil.handlePageRedirection(mfgOrderConstant.CREATE_MFG_ORDER_PAGE_URL, this);
    }
    if (source == 'customer') {
      this.props.setSelectedCustomerCode(tempId[0]);
      CommonUtil.handlePageRedirection(customerConstant.CREATE_CUSTOMER_PAGE_URL, this);
    }
  }

  getButtonStatusColor = (value) => {
    return PopularTableUtil.getButtonStatusColor(value, documentDetailsConstant);
  }

  handleFIlter = async (event) => {
    await this.setState({source:event});
    await PaginationUtil.initPaginationParams(this);
    this.setSelectedTabDetails();
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == documentDetailsConstant.CREATE_DOCUMENT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(documentDetailsConstant.CREATE_DOCUMENT_PAGE_URL, this);
    }

    if (tempId[2] == documentDetailsConstant.ACTIVATE_DOCUMENT) {
      this.handleStatusAction(tempId[0], statusConstant.ACTIVE_STATUS);
    }

    if (tempId[1] == commonConstant.DELETE_ACTION_MODE) {
      this.setState({
        documentDetailsCode: tempId[0],
        status: statusConstant.INACTIVE_STATUS
      });
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, documentDetailsConstant.MODULE_NAME);
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  handleStatusAction(documentDetailsCode, status) {
    var tempObj = {};
    var documentDetailsCode = documentDetailsCode ? documentDetailsCode : this.state.documentDetailsCode;
    tempObj.deleted = true;
    this.setState({ alert: null });
    this.props.updateDocumentDetailsStatus(tempObj, documentDetailsCode);
  }

  makeCustomAPICall(tempParamas) {
    this.props.getDocumentDetailsList(tempParamas);
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isDeleteMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }


  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableDataList, tableConfig, selectedFilter } = this.state;
    const actionMode = this.props.documentDetailsActionMode;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={6} md={4}>
                <div className="page-title">
                  <img src={documentmangment} alt="" className="page-icon" />
                  {documentDetailsConstant.MANAGE_DOCUMENT_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={6} md={8}>
                <div className="left-section">
                  <Nav pullRight>
                    <NavDropdown
                      title={<div className="filter"><img src={filter} alt="" title="Filter by source" /></div>}
                      noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                      <MenuItem eventKey="" className={selectedFilter === "" ? "active" : null}>
                        All
                        </MenuItem>
                      {isAuthorized("facility") && <MenuItem eventKey="Facility" className={selectedFilter === "Facility" ? "active" : null}>
                        Facility
                        </MenuItem>}
                      {isAuthorized("supplier") && <MenuItem eventKey="Supplier" className={selectedFilter === "Supplier" ? "active" : null}>
                        Supplier
                      </MenuItem>}
                      {isAuthorized("customer") && <MenuItem eventKey="Customer" className={selectedFilter === "Customer" ? "active" : null}>
                        Customer
                      </MenuItem>}
                     {isAuthorized("manufacture") && <MenuItem eventKey="Make" className={selectedFilter === "MFGOrder" ? "active" : null}>
                        Make
                        </MenuItem>}
                      {isAuthorized("salesOrder") && <MenuItem eventKey="Sell" className={selectedFilter === "SaleOrder" ? "active" : null}>
                        Sell
                        </MenuItem>}
                      {isAuthorized("purchaseOrder") && <MenuItem eventKey="Procure" className={selectedFilter === "PurchaseOrder" ? "active" : null}>
                      Procure
                        </MenuItem>}
                    </NavDropdown>
                  </Nav>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    { attributeList != null ?
                      <div className="advance-search">
                        <Row>
                          {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                            tempAttributeListObj.type == "DATE" ?
                              DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "DROPDOWN" ?
                                  DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : null))
                          }
                          <Col md={1} sm={1}>
                            {/* <div className="submit-btn">
                              <img src={check} alt="submit" />
                            </div> */}
                          </Col>
                        </Row>
                      </div> : null
                    }
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    documentDetailsList: state.documentDetails.documentDetailsList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getDocumentDetailsList: id => dispatch(getDocumentDetailsList(id)),
  setSelectedFacilityCode: id => dispatch(setSelectedFacilityCode(id)),
  setSelectedSupplierCode: id => dispatch(setSelectedSupplierCode(id)),
  setSelectedPurchaseOrderCode: (selectedSaleOrderCode) => dispatch(setSelectedPurchaseOrderCode(selectedSaleOrderCode)),
  updateDocumentDetailsStatus: (obj, status) => dispatch(updateDocumentDetailsStatus(obj, status)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setSelectedSaleOrderCode: selectedSaleOrderCode => dispatch(setSelectedSaleOrderCode(selectedSaleOrderCode)),
  setSelectedMfgOrderCode: selectedMfgOrderCode => dispatch(setSelectedMfgOrderCode(selectedMfgOrderCode)),
  setSelectedCustomerCode: selectedCustomerCode => dispatch(setSelectedCustomerCode(selectedCustomerCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(DocumentDetails);
