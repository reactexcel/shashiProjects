import * as pipeLineConstant from './pipeLineConstant';
import * as batchConstant from './batchConstant';
import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import intersection from "lodash/intersection";

export const PIPELINE_CONFIGURATION_LIST =
{
  attributeObj: {
    pipeLineCode: '',
    pipeLineName: '',
    productId: '',
    productName: '',
    poNumber: '',
    batchCode: ''
  },
  attributeList: [
    {
      name: "pipeLineCode",
      type: "TEXTBOX",
      label: "PIPELINE CODE",
      required: true,
      fieldWidth: 3,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: true,
      modifyPipeLineShowFlag: true,
      clonePipeLineShowFlag: true,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty."
    },
    {
      name: "pipeLineName",
      type: "TEXTBOX",
      label: "PIPELINE NAME",
      required: true,
      fieldWidth: 4,
      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'enable',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: true,
      modifyPipeLineShowFlag: true,
      clonePipeLineShowFlag: true,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty."
    },
    {
      name: "productId",
      type: "TEXTBOX",
      label: "PRODUCT CODE",
      required: true,
      fieldWidth: 4,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: true,
      modifyPipeLineShowFlag: true,
      clonePipeLineShowFlag: true,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty."
    },
    {
      name: "productName",
      type: "TEXTBOX",
      label: "PRODUCT NAME",
      required: true,
      fieldWidth: 4,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: true,
      modifyPipeLineShowFlag: true,
      clonePipeLineShowFlag: true,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "poNumber",
      type: "TEXTBOX",
      label: "PO NUMBER",
      required: true,
      fieldWidth: 3,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: false,
      modifyPipeLineShowFlag: false,
      clonePipeLineShowFlag: false,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "batchCode",
      type: "TEXTBOX",
      label: "BATCH NUMBER",
      required: true,
      fieldWidth: 3,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: false,
      modifyPipeLineShowFlag: false,
      clonePipeLineShowFlag: false,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "batchCodeButton",
      type: "BUTTON",
      label: "Get Batch Number",
      fieldWidth: 2,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'disabled',
      configurePipeLineShowFlag: false,
      modifyPipeLineShowFlag: false,
      clonePipeLineShowFlag: false,
      createBatchShowFlag: true,
      modifyBatchShowFlag: true,
    }
  ]
};

export const PIPELINE_STAGE_LIST = {
  attributeObj: {
    SOURCING_1: '',
    PROCESSING_1: '',
    WAREHOUSE_1: '',
    DISTRIBUTION_1: '',
    POS_1: ''
  },
  attributeList: [
    {
      name: "Sourcing",
      id: "SOURCING_1",
      type: "CARD",
      stageType: pipeLineConstant.PIPELINE_SOURCING_STAGE_TYPE,
      cloneIcon: true,
      editIcon: true,
      removeIcon: true,
      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'disabled',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      dynamicSection: false,
      disableStageText: true

    },
    {
      name: "Processing",
      id: "PROCESSING_1",
      type: "CARD",
      stageType: pipeLineConstant.PIPELINE_PROCESSING_STAGE_TYPE,
      cloneIcon: true,
      editIcon: true,
      removeIcon: true,

      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'enable',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      dynamicSection: false,
      disableStageText: true
    },
    {
      name: "Warehouse",
      id: "WAREHOUSE_1",
      type: "CARD",
      stageType: pipeLineConstant.PIPELINE_WAREHOUSE_STAGE_TYPE,
      cloneIcon: true,
      editIcon: true,
      removeIcon: true,
      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'enable',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      dynamicSection: false,
      disableStageText: true
    },
    {
      name: "Distribution",
      id: "DISTRIBUTION_1",
      type: "CARD",
      stageType: pipeLineConstant.PIPELINE_DISTRIBUTION_STAGE_TYPE,
      cloneIcon: true,
      editIcon: true,
      removeIcon: true,
      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'enable',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      dynamicSection: false,
      disableStageText: true
    },
    {
      name: "POS",
      id: "POS_1",
      type: "CARD",
      stageType: pipeLineConstant.PIPELINE_POS_STAGE_TYPE,
      cloneIcon: true,
      editIcon: true,
      removeIcon: true,
      configurePipeLine: 'enable',
      modifyPipeLine: 'enable',
      clonePipeLine: 'enable',
      createBatch: 'disabled',
      modifyBatch: 'disabled',
      dynamicSection: false,
      disableStageText: true
    }

  ]
}

/* sourcing ------------------------*/
export const SOURCING_STAGE_LIST = {
  attributeObj: {
    sourceFG: '',
    locations: '',
    qualityCheck: '',
  },
  attributeList: [
    {
      name: "sourceFG",
      label: "SOURCE",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.SOURCING_FG_STAGE_TYPE,
      showHideFlag: true,
    },
    {
      name: "qualityCheck",
      label: "QC DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.SOURCING_QUALITY_CHECK_STAGE_TYPE,
      showHideFlag: true,
    },
    {
      name: "documentation",
      label: "DOCUMENT DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.SOURCING_DOCUMENTATION_STAGE_TYPE,
      showHideFlag: true,
    },
  ],
  checkBoxList: [
    {
      name: "FG",
      label: "FG",
      type: "checkbox",
      checked: true,
      value: true,
      stageType: pipeLineConstant.SOURCING_FG_STAGE_TYPE
    },
    {
      name: "ingredients",
      label: "INGREDIENTS",
      type: "checkbox",
      value: false,
      stageType: pipeLineConstant.SOURCING_INGREDIENTS_STAGE_TYPE
    },
  ]

};

export const SOURCING_FG_STAGE_LIST =
{
  attributeObj: {
    id: 'SOURCING_FG',
    purchaseOrderNumber: '',
    quantityUOM: '',
    supplierCodeName: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: '',
    disabled: true,
  },
  attributeList: [
    {
      title: "Purchase Order Number",
      name: "purchaseOrderNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity(UOM)",
      name: "quantityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Supplier Code/Name",
      name: "supplierCodeName",
      searchOptionList: ["supplierId", "supplierName"],
      searchListName: 'supplierListItem',
      placeholder: "Search Supplier",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'supplierLocationList',
      placeholder: "Search Supplier Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Facility Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    }
  ],
};

export const SOURCING_INGREDIENTS_STAGE_LIST =
{
  attributeObj: {
    id: 'SOURCING_INGREDIENTS',
    srNumber: '',
    ingredientCodeName: '',
    supplierCodeName: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: '',
    disabled: true,
  },
  attributeList: [
    {
      title: "SR No.",
      name: "srNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Ingredient Code/Name",
      name: "ingredientCodeName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Supplier Code/Name",
      name: "supplierCodeName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      type: "TEXTBOX",
      inputType: "date",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    }
  ],

};

export const SOURCING_QUALITY_CHECK_STAGE_LIST =
{
  attributeObj: {
    id: '',
    QCNumber: '',
    QCType: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "QC Number",
      name: "QCNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "QC Type",
      name: "QCType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'qcTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const SOURCING_DOCUMENTATION_STAGE_LIST =
{
  attributeObj: {
    id: '',
    documentType: '',
    documentDetails: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "DOCUMENT TYPE",
      name: "documentType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'documentTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "DOCUMENT Deatils",
      name: "documentDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

/*processing -------------------*/

export const PROCESSING_STAGE_LIST = {
  attributeObj: {
    productDetails: '',
    documentationDetails: '',
    qcDetails: ''
  },
  attributeList: [
    {
      name: "productDetails",
      label: "PRODUCT DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.PROCESSING_PLANT_STAGE_TYPE,
    },
    {
      name: "qcDetails",
      label: "QC DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.PROCESSING_QUALITY_CHECK_STAGE_TYPE,
    },
    {
      name: "documentDetails",
      label: "DOCUMENT DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.PROCESSING_DOCUMENTATION_STAGE_TYPE,
    }
  ]
}

export const PROCESSING_PLANT_STAGE_LIST =
{
  attributeObj: {
    id: '',
    plantCodeName: '',
    quantityUOM: '',
    processType: '',
    processStateDate: '',
    processEndDate: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: ''
  },
  attributeList: [
    {
      title: "Plant Code/Name",
      name: "plantCodeName",
      searchOptionList: ["facilityId", "facilityName"],
      searchListName: 'facilityListItem',
      placeholder: "Search Plant Code",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity(UoM)",
      name: "quantityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Process Type",
      name: "processType",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Process Start Date",
      name: "processStateDate",
      type: "TEXTBOX",
      inputType: "date",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Process End Date",
      name: "processEndDate",
      type: "TEXTBOX",
      inputType: "date",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'supplierLocationList',
      placeholder: "Search Supplier Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Facility Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const PROCESSING_DOCUMENTATION_STAGE_LIST =
{
  attributeObj: {
    id: '',
    documentType: '',
    documentDetails: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "DOCUMENT TYPE",
      name: "documentType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'documentTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "DOCUMENT Deatils",
      name: "documentDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const PROCESSING_QUALITY_CHECK_STAGE_LIST =
{
  attributeObj: {
    id: '',
    QCNumber: '',
    QCType: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "QC Number",
      name: "QCNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "QC Type",
      name: "QCType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'qcTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

/* warehose ---------------------------------------*/

export const WAREHOUSE_STAGE_LIST = {
  attributeObj: {
    warehouseDetails: '',
    documentDetails: '',
    qcDetails: ''
  },
  attributeList: [
    {
      name: "warehouseDetails",
      label: "WAREHOUSE",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.WAREHOUSE_STOCK_STAGE_TYPE,
    },
    {
      name: "warehouseChannel",
      label: "WAREHOUSE CHANNEL",
      type: "TAB1",
      dynamicSection: false,
      stageType: pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE,
    },
    {
      name: "qcDetails",
      label: "QC DETAILS ",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.WAREHOUSE_QUALITY_CHECK_STAGE_TYPE,
    },
    {
      name: "documentDetails",
      label: "DOCUMENT DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.WAREHOUSE_DOCUMENTATION_STAGE_TYPE,
    },

  ],
  checkBoxList: [
    {
      name: "stockTransfer",
      label: "Stock Transfer",
      type: "checkbox",
      checked: true,
      value: true,
      stageType: pipeLineConstant.WAREHOUSE_STOCK_STAGE_TYPE
    },
    {
      name: "channelSales",
      label: "Channel Sales",
      type: "checkbox",
      value: false,
      stageType: pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE
    },
  ]

}

export const WAREHOUSE_STOCK_STAGE_LIST =
{
  attributeObj: {
    id: '',
    sto: '',
    quantityUOM: '',
    uom: '',
    channelType: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: ''
  },
  attributeList: [
    {
      title: "STO",
      name: "sto",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity UOM",
      name: "quantityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Channel Type",
      name: "channelType",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search WareHouse Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Warehouse Location",
      type: "SUGGESTION",
      inputType: "date",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]

};

export const WAREHOUSE_CHANNEL_SALES_STAGE_LIST =
{
  attributeObj: {
    invoiceNumber: '',
    quanityUOM: '',
    channelType: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: '',
  },
  attributeList: [
    {
      title: "Invoice Number",
      name: "invoiceNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity(UoM)",
      name: "quanityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Channel Type",
      name: "channelType",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      type: "TEXTBOX",
      inputType: "date",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const WAREHOUSE_DOCUMENTATION_STAGE_LIST =
{
  attributeObj: {
    id: '',
    documentType: '',
    documentDetails: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "DOCUMENT TYPE",
      name: "documentType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'documentTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "DOCUMENT Deatils",
      name: "documentDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const WAREHOUSE_QUALITY_CHECK_STAGE_LIST =
{
  attributeObj: {
    id: '',
    QCNumber: '',
    QCType: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "QC Number",
      name: "QCNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "QC Type",
      name: "QCType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'qcTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

/* distribution --------------------*/

export const DISTRIBUTION_STAGE_LIST = {
  attributeObj: {
    distributionCenter: '',
    qcDetails: '',
    documentDetails: '',
  },
  attributeList: [
    {
      name: "distributionCenter",
      label: "DISTRIBUTION CENTER",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.DISTRIBUTION_CENTER_STAGE_TYPE,
    },
    {
      name: "qcDetails",
      label: "QC DETAILS ",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.DISTRIBUTION_QUALITY_CHECK_STAGE_TYPE,
    },
    {
      name: "documentDetails",
      label: "DOCUMENT DETAILS",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.DISTRIBUTION_DOCUMENTATION_STAGE_TYPE,
    },

  ]
}

export const DISTRIBUTION_CENTER_STAGE_LIST =
{
  attributeObj: {
    id: '',
    invoiceNumber: '',
    quantityUOM: '',
    distributionCenterCodeName: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: '',
  },
  attributeList: [
    {
      title: "Invoice Number",
      name: "invoiceNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity(UOM)",
      name: "quantityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Distribution Center Code/Name",
      name: "distributionCenterCodeName",
      searchOptionList: ["facilityId", "facilityName"],
      searchListName: 'facilityListItem',
      placeholder: "Search Distribution Center",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Facility Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Distribution Location",
      type: "SUGGESTION",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },

    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }

  ]
};

export const DISTRIBUTION_DOCUMENTATION_STAGE_LIST =
{
  attributeObj: {
    id: '',
    documentType: '',
    documentDetails: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "DOCUMENT TYPE",
      name: "documentType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'documentTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "DOCUMENT Deatils",
      name: "documentDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};
export const DISTRIBUTION_QUALITY_CHECK_STAGE_LIST =
{
  attributeObj: {
    id: '',
    QCNumber: '',
    QCType: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "QC Number",
      name: "QCNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "QC Type",
      name: "QCType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'qcTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

/*pos ------------------------------------*/

export const POS_STAGE_LIST = {
  attributeObj: {
    salesChannel: '',
    documentDetails: ''
  },
  attributeList: [
    {
      name: "salesChannel",
      label: "SALES CHANNEL",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.POS_SALES_CHANNEL_STAGE_TYPE,
    },
    {
      name: "documentDetails",
      label: "Document Details",
      type: "TAB",
      dynamicSection: false,
      stageType: pipeLineConstant.POS_DOCUMENTATION_STAGE_TYPE,
    }

  ]
};

export const POS_SALES_CHANNEL_STAGE_LIST =
{
  attributeObj: {
    id: '',
    channelType: '',
    invoiceNumber: '',
    quanityUOM: '',
    customerName: '',
    customerDetails: '',
    fromLocationCodeName: '',
    receivedLocationCodeName: '',

  },
  attributeList: [
    {
      title: "Channel Type",
      name: "channelType",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Invoice Number",
      name: "invoiceNumber",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Quantity(UoM)",
      name: "quanityUOM",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Customer Name",
      name: "customerName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Customer Details",
      name: "customerDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "From Location Code/Name",
      name: "fromLocationCodeName",
      searchOptionList: ["locationCode", "locatioName"],
      searchListName: 'facilityLocationList',
      placeholder: "Search Facility Location",
      type: "SUGGESTION",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "Received Location Code/Name",
      name: "receivedLocationCodeName",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const POS_DOCUMENTATION_STAGE_LIST =
{
  attributeObj: {
    id: '',
    documentType: '',
    documentDetails: '',
    documentDetailsList: []
  },
  attributeList: [
    {
      title: "DOCUMENT TYPE",
      name: "documentType",
      type: "DROPDOWN",
      dataDictionaryFlag: true,
      dataDictionaryId: 'documentTypeList',
      options: [],
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "DOCUMENT Deatils",
      name: "documentDetails",
      type: "TEXTBOX",
      inputType: "text",
      configurePipeLine: 'disabled',
      modifyPipeLine: 'disabled',
      clonePipeLine: 'disabled',
      createBatch: 'enable',
      modifyBatch: 'enable',
    },
    {
      title: "attachment",
      name: "attachment",
      type: "BUTTON",
      documentIcon: true,
    },
    {
      title: "",
      name: "action",
      type: "BUTTON",
      editIcon: true,
      removeIcon: true,
      cloneIcon: true,
      disabled: false
    }
  ]
};

export const MANAGE_BATCH_PAGE_LIST = (userPermission, that) => {
  return {
    tableColumnList: [
      {
        Header: "Batch ID",
        id: "batchCode",
        accessor: "batchCode"
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName",
        disableFilters: true,
        style: {
          flex: '0 0 25%'
        },
      },
      {
        Header: "Batch Status",
        id: "batchStatus",
        accessor: "batchStatus",
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div style={{ textAlign: 'center', color: 'red' }}>
              {value}
            </div>
          )
        }
      },
      {
        Header: "Consumer Page",
        id: "consumerPage",
        accessor: "consumerPageStatus",
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div style={{ textAlign: 'center', color: 'red' }}>
              {value}
            </div>
          )
        }
      },
      {
        Header: "Modified Date",
        id: "modifieddate",
        accessor: "modifieddate",
        disableFilters: true,
      },
      {
        Header: "QR Code",
        id: "qrcodeStatus",
        accessor: "qrcodeStatus",
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div style={{ textAlign: 'center', color: 'red' }}>
              {value}
            </div>
          )
        }
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        disableSortBy: true,
        disableFilters: true,
        className: "action",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div>
              <div className="actions-left">
                <Nav pullRight>
                  <NavDropdown id={original.productId + index} title={<i className="fa fa-ellipsis-v" id={original.productId + index + "_" + batchConstant.MENU_ACTION_MODE} />} noCaret >
                    {intersection(userPermission, batchConstant.GENERATE_QR_CODE.allowedPermissions).length !== 0 ?
                      original.qrcodeStatus != 'Active' ?
                        <MenuItem id={original.productId + "_" + batchConstant.MENU_ACTION_MODE + "_" + batchConstant.GENERATE_QR_CODE.action + "_" + original.batchCode} onClick={(e) => that.getTdProps(e)}>Generate QR Code</MenuItem>
                        : <MenuItem id={original.productId + "_" + batchConstant.MENU_ACTION_MODE + "_" + batchConstant.MODIFY_QR_CODE.action + "_" + original.batchCode} onClick={(e) => that.getTdProps(e)}>Modify QR Code</MenuItem>
                      : null
                    }
                    {intersection(userPermission, batchConstant.PREVIEW_CONSUMER_PAGE.allowedPermissions).length !== 0 && (
                      <React.Fragment>
                        <MenuItem id={original.productId + "_" + batchConstant.MENU_ACTION_MODE + "_" + batchConstant.TRACK_BATCH.action + "_" + original.batchCode} onClick={(e) => that.getTdProps(e)}>Track</MenuItem>
                        <MenuItem id={original.productId + "_" + batchConstant.MENU_ACTION_MODE + "_" + batchConstant.PREVIEW_CONSUMER_PAGE.action + "_" + original.batchCode} onClick={(e) => that.getTdProps(e)}>Preview Consumer Page</MenuItem>
                      </React.Fragment>
                    )}
                  </NavDropdown>
                </Nav>
                <Button bsStyle="default" simple icon>
                  <div className="circle"><i title="edit" id={original.productId + "_" + batchConstant.EDIT_ACTION_MODE + '_' + original.batchCode} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
                </Button>
              </div>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
          {
              id: "status",
              value: ""
          }
      ],
      defaultSortedList: [
          {
              id: "modifieddate",
              desc: true
          }
      ],
      defaultPageSize: 10,
      rowId: 'batchCode',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
  }
  };
}

export const DASHBOARD_MANAGE_BATCH_PAGE_LIST = (userPermission, that) => {
  return {
    tableColumnList: [
      {
        Header: "Batch ID",
        id: "batchCode",
        accessor: "batchCode",
        disableSortBy: true,
        disableFilters: true,
      },
      {
        Header: "Product Name",
        id: "productName",
        accessor: "productName",
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: '0 0 25%'
        },
      },
      {
        Header: "Status",
        id: "batchStatus",
        accessor: "batchStatus",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div style={{ textAlign: 'center', color: 'red' }}>
              {value}
            </div>
          )
        }
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        sortable: false,
        width: 95,
        className: "action",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div>
              <div className="actions-left">
                <Button bsStyle="default" simple icon>
                  <div className="circle"><i title="track" id={original.productId + "_" + batchConstant.TRACK_BATCH + '_' + original.batchCode} onClick={(e) => that.getTdProps(e)} className="fa fa-pencil" /></div>
                </Button>
              </div>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
          {
              id: "status",
              value: ""
          }
      ],
      defaultSortedList: [
          {
              id: "modifieddate",
              desc: true
          }
      ],
      defaultPageSize: 10,
      rowId: 'batchCode',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
  }
  }
};
