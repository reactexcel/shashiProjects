export const PIPELINE_CONFIGURE_PIPELINE_HEADER_TITLE = "Pipeline";
export const PIPELINE_CONFIGURE_PIPELINE_SUBHEADER_TITLE = "Capturing general infrmation about Pipeline"
export const PIPELINE_CLASSIFICATION_SECTION = "pipeLineClassification";
export const PIPELINE_STAGE_SECTION = "pipeLineStageList";
export const PIPELINE_SUB_STAGE_SECTION = "pipeLineSubStageList";

export const PAGE_TYPE_TABLE = "TABLE";
export const PAGE_TYPE_FORM = "FORM";
export const CARD_TYPE = "CARD";

export const PIPELINE_STAGE_ADD_BTN_TXT = "ADD";
export const PIPELINE_SOURCING_STAGE_TYPE = "SOURCING";
export const PIPELINE_PROCESSING_STAGE_TYPE = "PROCESSING";
export const PIPELINE_WAREHOUSE_STAGE_TYPE = "WAREHOUSE";
export const PIPELINE_DISTRIBUTION_STAGE_TYPE = "DISTRIBUTION";
export const PIPELINE_POS_STAGE_TYPE = "POS";

export const SOURCING_INGREDIENTS_STAGE_TYPE = "SOURCING_INGREDIENTS";
export const SOURCING_FG_STAGE_TYPE = "SOURCING_FG";
export const SOURCING_LOCATIONS_STAGE_TYPE = "SOURCING_LOCATIONS";
export const SOURCING_DOCUMENTATION_STAGE_TYPE = "SOURCING_DOCUMENTATION";
export const SOURCING_QUALITY_CHECK_STAGE_TYPE = "SOURCING_QUALITY_CHECK";

export const PROCESSING_PLANT_STAGE_TYPE = "PROCESSING_PLANT";
export const PROCESSING_FINAL_PRODUCT_STAGE_TYPE = "PROCESSING_FINAL_PRODUCT";
export const PROCESSING_SHIPPING_STAGE_TYPE = "PROCESSING_SHIPPING";
export const PROCESSING_DOCUMENTATION_STAGE_TYPE = "PROCESSING_DOCUMENTATION";
export const PROCESSING_QUALITY_CHECK_STAGE_TYPE = "PROCESSING_QUALITY_CHECK";

export const WAREHOUSE_STOCK_STAGE_TYPE = "WAREHOUSE_STOCK";
export const WAREHOUSE_CHANNEL_SALES_STAGE_TYPE = "WAREHOUSE_CHANNEL_SALES";
export const WAREHOUSE_DOCUMENTATION_STAGE_TYPE = "WAREHOUSE_DOCUMENTATION";
export const WAREHOUSE_QUALITY_CHECK_STAGE_TYPE = "WAREHOUSE_QUALITY_CHECK";

export const DISTRIBUTION_CENTER_STAGE_TYPE = "DISTRIBUTION_CENTER";
export const DISTRIBUTION_DOCUMENTATION_STAGE_TYPE = "DISTRIBUTION_DOCUMENTATION";
export const DISTRIBUTION_QUALITY_CHECK_STAGE_TYPE = "DISTRIBUTION_QUALITY_CHECK";
export const POS_SALES_CHANNEL_STAGE_TYPE = "POS_SALES_CHANNEL";
export const POS_DOCUMENTATION_STAGE_TYPE = "POS_DOCUMENTATION";

export const CONFIGURE_PIPELINE_PAGE_URL = '/admin/configure-pipeline';
export const MANAGE_PRODUCT_PAGE_URL = '/admin/manage-product';
export const MANAGE_PIPELINE_PAGE_URL = '/admin/manage-pipeline';
export const CREATE_ACTION_MODE = "createMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";
export const VIEW_ACTION_MODE = "viewMode";
export const ACTIVE_STATUS = "Active";
export const INACTIVE_STATUS = "Inactive";
export const MENU_ACTION_MODE = "MENU";

export const MANAGE_PIPELINE_HEADER_TITLE = "Pipeline";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_PIPELINE_LIST_URL = `${BASE_URL}/products`;
export const GET_PIPELINE_DETAILS_URL = `${BASE_URL}/products/`;
export const GET_GENERATED_PIPELINE_CODE_URL = `${BASE_URL}/products/getId`;
export const SET_CREATE_PIPELINE_DETAILS_URL = `${BASE_URL}/products/`;
export const SET_UPDATE_PIPELINE_DETAILS_URL = `${BASE_URL}/products/`;

export const CONFIGURE_PIPELINE = "configurePipeLine";
export const MODIFY_PIPELINE = "modifyPipeLine";
export const CLONE_PIPELINE = "clonePipeLine";
export const CREATE_BATCH = "createBatch";
export const MODIFY_BATCH = "modifyBatch";
export const VIEW_BATCH = "viewBatch";
export const TRACK_PRODUCT = "trackProduct";

export const UNIQUE_CODE_PREFIX = "PPL-";
export const BATCH_CODE_PREFIX = "BATCH-";
export const ZERO_PAD_COUNT = 4;

export const dataTable = [
];
