import {
    participant,
    productOwner,
    superUser
} from "../../../constants/GlobalConstants";

export const BATCH_DETAILS_HEADER_TITLE = "Create Batch";
export const BATCH_DETAILS_SUBHEADER_TITLE = "Capturing general infrmation about Batch"
export const MANAGE_BATCH_HEADER_TITLE = "Batch";
export const LOCATION_HEADER_TITLE = "Location";
export const LOCATION_CHECKBOX_TITLE = "Set as default";
export const DOCUMENT_HEADER_TITLE = "Document";

export const BATCH_INPROGRESS_STATUS = "In Progress";
export const BATCH_COMPLETED_STATUS = "Completed";
export const CONSUMER_PAGE_STATUS = "Not Started";
export const CREATE_ACTION_MODE = "createMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";
export const VIEW_ACTION_MODE = "viewMode";
export const ACTIVE_STATUS = "Active";
export const INACTIVE_STATUS = "Inactive";
export const CREATE_BATCH = "createBatch";
export const MODIFY_BATCH = "modifyBatch";
export const VIEW_BATCH = "viewBatch";
export const MENU_ACTION_MODE = "MENU";

export const GENERATE_QR_CODE = {"action": "generateQRCode", allowedPermissions: [superUser, productOwner]};
export const MODIFY_QR_CODE = {"action": "modifyQRCode", allowedPermissions: [superUser, productOwner]};
export const TRACK_BATCH = {"action": "tackBatch", allowedPermissions: [superUser, productOwner, participant]};
export const PREVIEW_CONSUMER_PAGE = {"action": "previewConsumerPage", allowedPermissions: [superUser, productOwner, participant]};

export const CONFIGURE_PIPELINE_PAGE_URL = '/admin/configure-pipeline';
export const GENERATE_QR_CODE_PAGE_URL = '/admin/createqrcode';
export const MODIFY_QR_CODE_PAGE_URL = '/admin/edit-qrcode';

export const CREATE_BATCH_PAGE_URL = '/admin/batches';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const BATCH_URL_KEY = '/batches/'
export const GET_GENERATED_BATCH_CODE_URL = `${BASE_URL}/batches/getId`;
export const GET_BATCH_LIST_URL = `${BASE_URL}/batches`;
export const GET_BATCH_DETAILS_URL = `${BASE_URL}/products/`;
export const SET_CREATE_BATCH_DETAILS_URL = `${BASE_URL}/products/`;
export const SET_UPDATE_BATCH_DETAILS_URL = `${BASE_URL}/products/`;
export const GET_PRODUCT_BATCH_LIST_URL = `${BASE_URL}/products/`;

export const SET_BATCH_DOCUMENTS_URL  =  `${BASE_URL}/upload`;


export const dataTable = [];