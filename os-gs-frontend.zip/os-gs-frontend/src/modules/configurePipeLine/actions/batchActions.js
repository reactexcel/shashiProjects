import axios from '../../../axios/axios';
import * as batchActionTypes from './batchActionTypes';
import * as batchConstant from '../constant/batchConstant';
import * as pipeLineActionTypes from './pipeLineActionTypes';
import * as actionTypes from '../../../actions/actionTypes';
import { beginAjaxCall, endAjaxCall, setAjaxCallStatus } from "../../../actions/ajaxStatusActions";

let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};


export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: batchActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setBatchDetails(batchDetailsObj, actionMode) {
  if (actionMode === batchConstant.CREATE_ACTION_MODE || actionMode === batchConstant.CLONE_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(batchConstant.SET_CREATE_BATCH_DETAILS_URL + batchDetailsObj.productId + batchConstant.BATCH_URL_KEY, batchDetailsObj, { headers }).then(response => {
        if (response.status == 201) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };
  }
  if (actionMode === batchConstant.EDIT_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(batchConstant.SET_UPDATE_BATCH_DETAILS_URL + batchDetailsObj.productId + batchConstant.BATCH_URL_KEY + batchDetailsObj.batchCode, batchDetailsObj, { headers }).then(response => {
        if (response.status == 200) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };

  }
}

export function setSelectedBatchCode(selectedBatchCode) {
  return function (dispatch) {
    dispatch({
      type: batchActionTypes.SET_SELECTED_BATCH_CODE,
      payload: selectedBatchCode
    });
  }
}

export function getBatchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_BATCH_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_BATCH_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getIncompleteBatchCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_BATCH_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_INCOMPLETE_BATCH_COUNT,
          payload: response.data.Count
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getBatchWithoutQRCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_BATCH_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_BATCH_WITHOUT_QR_COUNT,
          payload: response.data.Count
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}


export function getBatchWithoutCMSCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_BATCH_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_BATCH_WITHOUT_CMS_COUNT,
          payload: response.data.Count
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getBatchListByProduct(selectedProductCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_PRODUCT_BATCH_LIST_URL + selectedProductCode + batchConstant.BATCH_URL_KEY, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_BATCH_LIST,
          payload: response.data.Items
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getBatchDetails(selectedProductCode, selectedBatchCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_BATCH_DETAILS_URL + selectedProductCode + batchConstant.BATCH_URL_KEY + selectedBatchCode, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: pipeLineActionTypes.SET_PIPELINE_SUB_STAGE_LIST,
          payload: response.data.Item.batchData
        });

        dispatch({
          type: batchActionTypes.GET_BATCH_DETAILS,
          payload: response.data.Item
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function setBatchDocuments(documentObj, documentIdObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(batchConstant.SET_BATCH_DOCUMENTS_URL, documentObj, { headers }).then(response => {
      if (response.status == 201) {
        documentIdObj.documentURL = response.data;
        dispatch({
          type: batchActionTypes.SET_UPLOADED_FILE_URL,
          payload: documentIdObj
        });
      }
      else {
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      dispatch(endAjaxCall());
    });
  };
}

export function getGeneratedBatchCode(id) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(batchConstant.GET_GENERATED_BATCH_CODE_URL, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: batchActionTypes.GET_GENERATED_BATCH_CODE,
          payload: response.data.Item.latestcount
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}


