import * as pipeLineActionTypes from './pipeLineActionTypes';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import * as actionTypes from '../../../actions/actionTypes';
import { beginAjaxCall, endAjaxCall, setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import axios from '../../../axios/axios';


let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setPipeLineSaveFlag(saveFlag) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_SAVE_FLAG,
      payload: saveFlag
    });
  }
}

export function setPipeLineModal(pipeLineModal) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_MODAL,
      payload: pipeLineModal
    });
  }
}

export function setSelectedStageType(stageType) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_SELECTED_STAGE_TYPE,
      payload: stageType
    });
  }
}

export function setSourcingSubStageType(sourcingStageType) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_SELECTED_SOURCING_SUB_STAGE_TYPE,
      payload: sourcingStageType
    });
  }
}


export function setSelectedSubStageType(subStageType) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_SELECTED_SUB_STAGE_TYPE,
      payload: subStageType
    });
  }
}

export function setSelectedStageId(stageId) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_SELECTED_STAGE_ID,
      payload: stageId
    });
  }
}


export function setPipeLineClassification(pipeLineClassification) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_CLASSIFICATION,
      payload: pipeLineClassification
    });
  }
}

export function setPipeLineStageList(pipeLineStageList) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_STAGE_LIST,
      payload: pipeLineStageList
    });
  }
}

export function setPipeLineSubStageList(pipeLineSubStageList) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_SUB_STAGE_LIST,
      payload: pipeLineSubStageList
    });
  }
}

export function setPipeLineBatchActionMode(pipeLineBatchActionMode) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_PIPELINE_BATCH_ACTION_MODE,
      payload: pipeLineBatchActionMode
    });
  }
}

export function setPipeLineDetails(pipeLineDetailsObj, actionMode) {
  if (actionMode === pipeLineConstant.CREATE_ACTION_MODE || actionMode === pipeLineConstant.CLONE_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(pipeLineConstant.SET_CREATE_PIPELINE_DETAILS_URL, pipeLineDetailsObj, { headers }).then(response => {
        if (response.status == 201) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };
  }
  if (actionMode === pipeLineConstant.EDIT_ACTION_MODE) {
    pipeLineDetailsObj.actionType = "PIPELINE";
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(pipeLineConstant.SET_UPDATE_PIPELINE_DETAILS_URL + pipeLineDetailsObj.productId, pipeLineDetailsObj, { headers }).then(response => {
        if (response.status == 200) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };

  }
}

export function setSelectedPipeLineCode(selectedPipeLineCode) {
  return function (dispatch) {
    dispatch({
      type: pipeLineActionTypes.SET_SELECTED_PIPELINE_CODE,
      payload: selectedPipeLineCode
    });
  }
}

export function getPipeLineList() {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(pipeLineConstant.GET_PIPELINE_LIST_URL, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: pipeLineActionTypes.GET_PIPELINE_LIST,
          payload: response.data.Items
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getPipeLineDetails(selectedPipeLineCode, pipeLineActionMode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(pipeLineConstant.GET_PIPELINE_DETAILS_URL + selectedPipeLineCode, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: pipeLineActionTypes.GET_PIPELINE_DETAILS,
          payload: response.data.Item
        });
        if (pipeLineActionMode != pipeLineConstant.CONFIGURE_PIPELINE) {
          dispatch({
            type: pipeLineActionTypes.SET_PIPELINE_CLASSIFICATION,
            payload: response.data.Item.pipeLineDetails.pipeLineClassification
          });
          dispatch({
            type: pipeLineActionTypes.SET_PIPELINE_STAGE_LIST,
            payload: response.data.Item.pipeLineDetails.pipeLineStageList
          });
        }
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}


export function getGeneratedPipeLineCode(id) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(pipeLineConstant.GET_GENERATED_PIPELINE_CODE_URL, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: pipeLineActionTypes.GET_GENERATED_PIPELINE_CODE,
          payload: response.data.Item.latestcount
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}





