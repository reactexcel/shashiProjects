import React, { Component } from "react";
import { Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import {
  setPipeLineClassification, getPipeLineDetails, getGeneratedPipeLineCode, setReducerInitMode
} from "../actions/pipeLineActions";
import { getBatchDetails, getGeneratedBatchCode } from "../actions/batchActions";
import { setPipeLineBatchActionMode } from "../../configurePipeLine/actions/pipeLineActions";
import { setSelectedProductCode } from "../../productManagement/actions/productActions";
import { connect } from "react-redux";
import Select from "react-select";
import AutoSuggestion from '../../../components/autosuggestion/AutoSuggestionWithApiCall.jsx';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import CommonUtil from '../../common/util/commonUtil';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { getSupplierList } from "../../supplierManagement/actions/supplierActions";
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";

class PPLClassificationSection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeObj: null,
      attributeList: null,
      productId: null,
      pipeLineDetails: null,
      generatedBatchCode: null,
      batchDetails: null,
      batchCode: null,
      pipeLineCode: null,
      submitted: null
    };
    this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
    this.handleDropDownChange = this.handleDropDownChange.bind(this);
    this.handleTextBoxBlur = this.handleTextBoxBlur.bind(this);
    this.handleOnLoadPipeLineAction = this.handleOnLoadPipeLineAction.bind(this);
    this.handleOnLoadBatchAction = this.handleOnLoadBatchAction.bind(this);
    this.handlePipeLineDetails = this.handlePipeLineDetails.bind(this);
    this.handleBatchDetails = this.handleBatchDetails.bind(this);
    this.createProductUniqueCode = this.createProductUniqueCode.bind(this);
    this.createBatchUniqueCode = this.createBatchUniqueCode.bind(this);
    this.handleBatchAction = this.handleBatchAction.bind(this);
  }

  componentDidMount = () => {
    if (this.props.pipeLineBatchActionMode == pipeLineConstant.CONFIGURE_PIPELINE ||
      this.props.pipeLineBatchActionMode == pipeLineConstant.MODIFY_PIPELINE ||
      this.props.pipeLineBatchActionMode == pipeLineConstant.CLONE_PIPELINE) {
      this.handleOnLoadPipeLineAction();
    }
    if (this.props.pipeLineBatchActionMode == pipeLineConstant.CREATE_BATCH ||
      this.props.pipeLineBatchActionMode == pipeLineConstant.MODIFY_BATCH) {
      this.handleOnLoadBatchAction();
      // this.props.getSupplierList();
      // this.props.getFacilityList();
    }
    this.props.getSupplierList();
    this.props.getFacilityList();
    this.setState({
      attributeList: pagePropertyListConstant.PIPELINE_CONFIGURATION_LIST.attributeList,
      attributeObj: pagePropertyListConstant.PIPELINE_CONFIGURATION_LIST.attributeObj,
    })
  }

  handleOnLoadPipeLineAction() {
    if (this.props.pipeLineBatchActionMode == pipeLineConstant.CONFIGURE_PIPELINE ||
      this.props.pipeLineBatchActionMode == pipeLineConstant.CLONE_PIPELINE) {
      this.createProductUniqueCode();
    }
    if (this.props.productId != null) {
      this.props.getPipeLineDetails(this.props.productId, this.props.pipeLineBatchActionMode);
    }
  }

  createBatchUniqueCode() {
    const { attributeObj } = this.state;
    var tempUniqueCode = CommonUtil.generateUniqueCode(this.props.latestUniqueCode, pipeLineConstant.BATCH_CODE_PREFIX,
      pipeLineConstant.ZERO_PAD_COUNT);
    this.setState({
      attributeObj: {
        ...attributeObj,
        batchCode: tempUniqueCode
      },
      batchCode: this.props.latestUniqueCode,
    })
  }

  createProductUniqueCode() {
    var latestUniqueCode = this.props.productId.split("-")[1];
    const { attributeObj } = this.state;
    var tempUniqueCode = CommonUtil.generateUniqueCodeWithoutIncr(latestUniqueCode, pipeLineConstant.UNIQUE_CODE_PREFIX,
      pipeLineConstant.ZERO_PAD_COUNT);
    this.setState({ pipeLineCode: tempUniqueCode });
  }

  handleOnLoadBatchAction() {
    if (this.props.pipeLineBatchActionMode == pipeLineConstant.CREATE_BATCH) {
      if (this.props.productId != null) {
        this.props.getPipeLineDetails(this.props.productId, this.props.pipeLineBatchActionMode);
      }
    }
    if (this.props.pipeLineBatchActionMode == pipeLineConstant.MODIFY_BATCH) {
      if (this.props.productId != null && this.props.batchCode != null) {
        this.props.getPipeLineDetails(this.props.productId, this.props.pipeLineBatchActionMode);
        this.props.getBatchDetails(this.props.productId, this.props.batchCode)
      }
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevState.attributeObj != this.props.attributeObj) {
      this.setState({ attributeObj: this.props.attributeObj });
    }
    if (this.props.pipeLineDetails != null && prevState.pipeLineDetails != this.props.pipeLineDetails) {
      this.handlePipeLineDetails();
    }
    if (this.props.batchDetails != null && prevState.batchDetails != this.props.batchDetails) {
      this.handleBatchDetails();
    }
    if (this.props.latestUniqueCode != null && prevState.batchCode != this.props.latestUniqueCode) {
      this.createBatchUniqueCode();
    }
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handlePipeLineDetails() {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        productId: this.props.pipeLineDetails.productId,
        productName: this.props.pipeLineDetails.productName,
        pipeLineCode: this.state.pipeLineCode != null ? this.state.pipeLineCode : attributeObj.pipeLineCode
      },
      pipeLineDetails: this.props.pipeLineDetails,
      function() {
      }
    })
  }

  handleBatchDetails() {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        batchCode: this.props.batchDetails.batchCode,
        poNumber: this.props.batchDetails.poNumber
      },
      batchDetails: this.props.batchDetails,
      function() {
      }
    })
  }

  handleTextBoxChange(event) {
    const { name, value } = event.target;
    const { attributeObj } = this.state;

    this.setState({
      attributeObj: {
        ...attributeObj,
        [name]: value
      }, function() {
      }
    })
  }


  handleTextBoxBlur(event) {
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    if (name == "productId") {
      this.props.setSelectedProductCode(value);
      this.props.getPipeLineDetails(value, pipeLineConstant.CONFIGURE_PIPELINE);
    }
    if (name == "batchCode") {
      this.props.getGeneratedBatchCode();
    }
  }

  handleBatchAction(event) {
    this.props.getGeneratedBatchCode();
  }

  handleDropDownChange(event, obj) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        [obj.name]: event.value
      }, function() {
      }
    })
  }

  render() {
    this.props.setPipeLineClassification(this.state.attributeObj);
    const { attributeObj, submitted } = this.state;
    return (
      <div >
        {this.state.attributeList != null && this.state.attributeList.map((tempAttributeListObj, index) => (
          tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[this.props.pipeLineBatchActionMode + 'ShowFlag'] == true ?
            <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
              <FormGroup>
                <ControlLabel>
                  {tempAttributeListObj.label}
                  {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                </ControlLabel>
                <FormControl type="text" name={tempAttributeListObj.name} value={attributeObj[tempAttributeListObj.name]}
                  onChange={this.handleTextBoxChange} onBlur={this.handleTextBoxBlur}
                  disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false} />
                {this.props.submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                  <small className="text-danger">
                    {tempAttributeListObj.mandatoryMsgText}
                  </small>
                }
              </FormGroup>
            </Col>
            : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[this.props.pipeLineBatchActionMode + 'ShowFlag'] == true ?
              <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                <FormGroup>
                  <ControlLabel>
                    {tempAttributeListObj.label}
                    {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                  </ControlLabel>
                  <Select name={tempAttributeListObj.name} onChange={this.handleDropDownChange}
                    placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
                    value={{ "label": attributeObj[tempAttributeListObj.name] }}
                    isDisabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false} />
                  {this.props.submitted && tempAttributeListObj.required && !attributeObj[tempAttributeListObj.name] &&
                    <small className="text-danger">
                      {tempAttributeListObj.mandatoryMsgText}
                    </small>
                  }
                </FormGroup>
              </Col>
              : tempAttributeListObj.type == "SUGGESTION" && tempAttributeListObj[this.props.pipeLineBatchActionMode + 'ShowFlag'] == true ?
                <Col sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} md={tempAttributeListObj.fieldWidth} key={index}>
                  <FormGroup>
                    <ControlLabel>
                      {tempAttributeListObj.label}
                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                    </ControlLabel>
                    <AutoSuggestion
                      searchUri="https://api.github.com/search/users"
                      placeholder={tempAttributeListObj.label}
                    />
                  </FormGroup>
                </Col>
                : tempAttributeListObj.type == "BUTTON" && tempAttributeListObj[this.props.pipeLineBatchActionMode + 'ShowFlag'] == true ?
                  <Col md={tempAttributeListObj.fieldWidth} className="generate-batch-number">
                    <Button fill wd bsStyle="info" disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}
                      onClick={this.handleBatchAction}>{tempAttributeListObj.label} </Button>
                  </Col>
                  : null

        ))
        }
      </div>
    );
  }
}


function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.pipeLine.pipeLineClassification,
    submitted: state.pipeLine.submitted,
    pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
    pipeLineDetails: state.pipeLine.pipeLineDetails,
    latestUniqueCode: state.batch.generatedBatchCode,
    batchCode: state.batch.selectedBatchCode,
    batchDetails: state.batch.batchDetails,
    productId: state.product.selectedProductCode,
    dataDictionaryList:state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = dispatch => ({
  setPipeLineClassification: pipeLineClassification => dispatch(setPipeLineClassification(pipeLineClassification)),
  getPipeLineDetails: (selectedProductCode, pipeLineBatchActionMode) => dispatch(getPipeLineDetails(selectedProductCode, pipeLineBatchActionMode)),
  getGeneratedPipeLineCode: id => dispatch(getGeneratedPipeLineCode(id)),
  setSelectedProductCode: selectedProductCode => dispatch(setSelectedProductCode(selectedProductCode)),
  getGeneratedBatchCode: id => dispatch(getGeneratedBatchCode(id)),
  getBatchDetails: (selectedProductCode, selectedBatchCode) => dispatch(getBatchDetails(selectedProductCode, selectedBatchCode)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getSupplierList: id => dispatch(getSupplierList(id)),
  getFacilityList: id => dispatch(getFacilityList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PPLClassificationSection);

