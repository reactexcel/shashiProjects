import React, { Component } from "react";
import { Row, Col, Table } from "react-bootstrap";
import { connect } from "react-redux";
import { setSelectedStageType, setSelectedSubStageType } from "../actions/pipeLineActions";
import ConfigureTable from "./ConfigureTable";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import ConfigureForm from "./ConfigureForm";
import { setPipeLineModal } from "../actions/pipeLineActions";
import PipeLinePopupModal from './PipeLinePopupModal';

class DistributionStage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeList: null,
      selectedSubStageType: null,
      selectedStageType: null,
      componentAttributeObj: null,
    };
    this.handlePipelinePopupModal = this.handlePipelinePopupModal.bind(this);
  }

  componentDidMount = () => {

  }
  handlePipelinePopupModal() {
    this.props.setPipeLineModal('FACILITY');
    this.setState({ openModal: true });
  }
  render() {

    if (this.props.selectedStageType != null) {
      this.state.attributeList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`];
      this.state.selectedStageType = this.props.selectedStageType;
      this.state.selectedSubStageType = this.props.selectedSubStageType;
    }

    return (
      <Row>

        <Col md={12}>
          {this.props.pipeLineModal != null ?
            <PipeLinePopupModal></PipeLinePopupModal>
            : null}

          <div className="create-new">
            <a><i className="fa fa-plus" onClick={this.handlePipelinePopupModal} />ADD NEW DISTRIBUTION</a>
          </div>
        </Col>
        {this.props.selectedStageType != null ?
          <Col md={12}>
            {this.state.attributeList.map((tempAttributeListObj, index) => (

              tempAttributeListObj.dynamicSection == false ?

                tempAttributeListObj.stageType == pipeLineConstant.DISTRIBUTION_CENTER_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.stageType == pipeLineConstant.DISTRIBUTION_DOCUMENTATION_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureTable key={index}> </ConfigureTable>
                    : tempAttributeListObj.stageType == pipeLineConstant.DISTRIBUTION_QUALITY_CHECK_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                      <ConfigureTable key={index}> </ConfigureTable>
                      : null
                :

                tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureForm key={index}> </ConfigureForm>
                    : null

            ))}
          </Col>
          : null}
      </Row>
    );
  }

}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType,
    pipeLineModal: state.pipeLine.pipeLineModal,
  };
}

const mapDispatchToProps = dispatch => ({
  setPipeLineModal: pipeLineModal => dispatch(setPipeLineModal(pipeLineModal)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DistributionStage);

