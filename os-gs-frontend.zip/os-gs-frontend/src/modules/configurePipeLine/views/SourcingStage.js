import React, { Component } from "react";
import { connect } from "react-redux";
import { setSourcingSubStageType, setPipeLineModal } from "../actions/pipeLineActions";
import { Row, Col, Table } from "react-bootstrap";
import ConfigureTable from "./ConfigureTable";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import ConfigureForm from "./ConfigureForm";
import SourcingSubStageSection from "./SourcingSubStageSection";
import PipeLinePopupModal from './PipeLinePopupModal';

class SourcingStage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeList: null,
      selectedSubStageType: null,
      selectedStageType: null,
      sourcingSubStageType: null,
      pipeLineSubStageList: null,
      openModal: false,
    };
    this.handleAddIngredients = this.handleAddIngredients.bind(this);
    this.handlePipelinePopupModal = this.handlePipelinePopupModal.bind(this);
  }

  componentDidMount = () => {
  }

  componentWillUnmount() {
    this.props.setSourcingSubStageType(true);
    this.setState({ sourcingSubStageType: null });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.sourcingSubStageType != null && prevState.sourcingSubStageType != this.props.sourcingSubStageType) {
      this.setState({
        sourcingSubStageType: this.props.sourcingSubStageType
      })
    }
  }

  handleAddIngredients(event) {
    this.setState({ sourcingSubStageType: true });
    this.props.setSourcingSubStageType(true);
  }

  handlePipelinePopupModal() {
    this.props.setPipeLineModal('SUPPLIER');
    this.setState({ openModal: true });
  }

  render() {
    if (this.props.selectedStageType != null) {
      this.state.attributeList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`];
      this.state.selectedStageType = this.props.selectedStageType;
      this.state.selectedSubStageType = this.props.selectedSubStageType;
    }

    return (
      <Row>
        <Col md={12}>
          {this.props.pipeLineModal != null ?
            <PipeLinePopupModal></PipeLinePopupModal>
            : null}
          <div className="create-new">
            <a><i className="fa fa-plus" onClick={this.handlePipelinePopupModal} />ADD NEW SUPPLIER</a>
          </div>
        </Col>
        {this.props.selectedStageType != null ?
          <Col md={12}>
            {this.state.attributeList.map((tempAttributeListObj, index) => (

              tempAttributeListObj.dynamicSection == false ?

                tempAttributeListObj.stageType == pipeLineConstant.SOURCING_FG_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <div key={index}>
                    <ConfigureTable> </ConfigureTable>
                    <SourcingSubStageSection selectedsubstagetype="SOURCING_INGREDIENTS"> </SourcingSubStageSection>
                  </div>
                  : tempAttributeListObj.stageType == pipeLineConstant.SOURCING_DOCUMENTATION_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureTable key={index}> </ConfigureTable>
                    : tempAttributeListObj.stageType == pipeLineConstant.SOURCING_QUALITY_CHECK_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                      <ConfigureTable key={index}> </ConfigureTable>
                      : null
                :

                tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index} > </ConfigureTable>
                  : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureForm key={index}  > </ConfigureForm>
                    : null

            ))}
          </Col>
          : null}
        <Col md={2}>
          <div className="create-new">
            <a><i className="fa fa-plus" onClick={this.handleAddIngredients} />ADD INGREDIENTS</a>
          </div>
        </Col>

      </Row>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType,
    sourcingSubStageType: state.pipeLine.sourcingSubStageType,
    selectedStageId: state.pipeLine.selectedStageId,
    pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
    pipeLineModal: state.pipeLine.pipeLineModal,
  };

}

const mapDispatchToProps = dispatch => ({
  setSourcingSubStageType: sourcingSubStageType => dispatch(setSourcingSubStageType(sourcingSubStageType)),
  setPipeLineModal: pipeLineModal => dispatch(setPipeLineModal(pipeLineModal)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SourcingStage);

