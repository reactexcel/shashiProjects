import React, { Component } from "react";
import { setSelectedStageType, setSelectedSubStageType, setSelectedStageId } from "../actions/pipeLineActions";
import { connect } from "react-redux";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as  pipeLineConstant from '../constant/pipeLineConstant';
import PPLClassificationSection from "./PPLClassificationSection";
import PPLStageSection from "./PPLStageSection";
import PPLStageSubSection from "./PPLStageSubSection";
import SourcingStage from "./SourcingStage";
import ProcessingStage from "./ProcessingStage";
import WareHouseStage from "./WareHouseStage";
import DistributionStage from "./DistributionStage";
import POSStage from "./POSStage";
import ConfigureDynamic from "./ConfigureDynamic";
import PPLActionButtonSection from "./PPLActionButtonSection";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import mixpanel from "../../analytics/mixpanel/mixpael";
class ConfigurePipeline extends Component {
  constructor(props) {
    super(props);

    this.state = {
      selectedStageType: pipeLineConstant.PIPELINE_SOURCING_STAGE_TYPE,
      selectedSubStageType: pipeLineConstant.SOURCING_FG_STAGE_TYPE,
      selectedStageId: "SOURCING_1"
    };
  }

  componentDidMount = () => {
      mixpanel.track("Configure pipeline loaded");
    this.props.setSelectedStageType(this.state.selectedStageType);
    this.props.setSelectedSubStageType(this.state.selectedSubStageType);
    this.props.setSelectedStageId(this.state.selectedStageId);
  }


  componentDidUpdate(prevProps) {
    if (prevProps.selectedStageType !== this.props.selectedStageType || prevProps.selectedSubStageType != this.props.selectedSubStageType) {
      this.setState({
        selectedStageType: this.props.selectedStageType,
        selectedSubStageType: this.props.selectedSubStageType
      })
    }
  }

  render() {
    return (
      <div className="main-content create-page">
        <Grid fluid>
          <Row className="top-row">
            <Col md={12}>
              <h3>{pipeLineConstant.MANAGE_PIPELINE_HEADER_TITLE}</h3>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>

                      <Row>
                        <PPLClassificationSection />
                      </Row>



                      <Row>
                        <PPLStageSection />
                      </Row>

                      <Row>
                        <PPLStageSubSection />
                      </Row>

                      {pagePropertyListConstant.PIPELINE_STAGE_LIST.attributeList.map((tempPPLStageListObj, index) => (

                        tempPPLStageListObj.dynamicSection == false ?

                          this.state.selectedStageType == tempPPLStageListObj.stageType &&
                            tempPPLStageListObj.stageType == pipeLineConstant.PIPELINE_SOURCING_STAGE_TYPE ?
                            <SourcingStage key={index} />

                            : this.state.selectedStageType == tempPPLStageListObj.stageType &&
                              tempPPLStageListObj.stageType == pipeLineConstant.PIPELINE_PROCESSING_STAGE_TYPE ?
                              <ProcessingStage key={index} />

                              : this.state.selectedStageType == tempPPLStageListObj.stageType &&
                                tempPPLStageListObj.stageType == pipeLineConstant.PIPELINE_WAREHOUSE_STAGE_TYPE ?
                                <WareHouseStage key={index} />

                                : this.state.selectedStageType == tempPPLStageListObj.stageType &&
                                  tempPPLStageListObj.stageType == pipeLineConstant.PIPELINE_DISTRIBUTION_STAGE_TYPE ?
                                  <DistributionStage key={index} />

                                  : this.state.selectedStageType == tempPPLStageListObj.stageType &&
                                    tempPPLStageListObj.stageType == pipeLineConstant.PIPELINE_POS_STAGE_TYPE ?
                                    <POSStage key={index} />
                                    : null
                          :
                          tempPPLStageListObj.stageType === this.state.selectedStageType ?
                            <ConfigureDynamic key={index} />
                            : null
                      ))}
                    </div>
                  }
                  ftTextRight
                  legend={
                    <PPLActionButtonSection></PPLActionButtonSection>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedStageType: selectedStageType => dispatch(setSelectedStageType(selectedStageType)),
  setSelectedStageId: selectedStageId => dispatch(setSelectedStageId(selectedStageId)),
  setSelectedSubStageType: selectedSubStageType => dispatch(setSelectedSubStageType(selectedSubStageType)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ConfigurePipeline);

