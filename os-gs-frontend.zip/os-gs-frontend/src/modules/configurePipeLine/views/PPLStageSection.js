import React, { Component } from "react";
import { setSelectedStageType, setSelectedSubStageType, setPipeLineStageList, setSelectedStageId } from "../actions/pipeLineActions";
import { connect } from "react-redux";
import { Col, FormControl } from "react-bootstrap";
import Slider from "react-slick";
import Button from "components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';

class PPLStageSection extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeObj: null,
      attributeList: null,
      infinite: false,
      oldSlide: 0,
      activeSlide: 0,
      cardActionClicked: false,
      disableStageText: true,
      settings: {
        dots: false,
        speed: 500,
        swipeToSlide: true,
        focusOnSelect: true,
        infinite: false,
        slidesToShow: 5,
        slidesToScroll: 1,
        responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 3,
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 2,
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
          }
        }
      ],
      // afterChange: (current) => this.handleSlideChange(current),
      }
    };
    this.handleSlideChange = this.handleSlideChange.bind(this);
    this.handleEditStage = this.handleEditStage.bind(this);
    this.handleCloneStage = this.handleCloneStage.bind(this);
    this.handleRemoveStage = this.handleRemoveStage.bind(this);
    this.handleSlideClick = this.handleSlideClick.bind(this);
    this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
  }


  componentDidMount() {
    this.setState({
      attributeList: pagePropertyListConstant.PIPELINE_STAGE_LIST.attributeList,
      attributeObj: pagePropertyListConstant.PIPELINE_STAGE_LIST.attributeObj,
    })
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeList != null && prevState.attributeList != this.props.attributeList) {
      this.setState({
        attributeList: this.props.attributeList,
      })
    }
  }

  async handleTextBoxChange(event) {
    var id = event != undefined ? event.target.id : null;
    var tempAttributeList = [...this.state.attributeList];

    for (var i = 0; i < this.state.attributeList.length; i++) {
      if (this.state.attributeList[i].id == id) {
        tempAttributeList[i].name = event.target.value;
        break;
      }
    }
    await this.setState({
      attributeList: tempAttributeList,
      cardActionClicked: true
    });
  }

  async handleEditStage(event, index) {
    var id = event != undefined ? event.target.id : null;
    var name = event.target.attributes.name.value;

    var tempAttributeList = [...this.state.attributeList];

    for (var i = 0; i < this.state.attributeList.length; i++) {
      if (this.state.attributeList[i].id == id) {
        if (name == "saveStage") {
          tempAttributeList[i].disableStageText = true;
        }
        else {
          tempAttributeList[i].disableStageText = false;
        }
        break;
      }
    }
    await this.setState({
      attributeList: tempAttributeList,
      cardActionClicked: true
    });
  }

  handleCloneStage = async (event, index) => {
    var id = event != undefined ? event.target.id : null;
    var tempStageType = id.split('_')[0];

    const attributeList = [...this.state.attributeList];
    const count = this.state.attributeList.length;
    var tempAttributeList = [];
    var tempMaxStageId = 0;

    for (var i = 0; i < attributeList.length; i++) {
      if (attributeList[i].stageType == tempStageType) {
        var tempId = parseInt(attributeList[i].id.split('_')[1]);
        if (tempMaxStageId < tempId) {
          tempMaxStageId = tempId;
        }
      }
    }

    tempMaxStageId = tempMaxStageId + 1;
    for (var i = 0; i < attributeList.length; i++) {
      tempAttributeList.push(attributeList[i]);
      if (attributeList[i].id == id) {
        var tempAttributeObj = { ...attributeList[i] };
        tempAttributeObj.id = attributeList[i].stageType + "_" + tempMaxStageId;
        tempAttributeObj.name = attributeList[i].stageType + "_" + tempMaxStageId;
        tempAttributeList.push(tempAttributeObj);
      }
    }
    await this.setState({
      attributeList: tempAttributeList,
      cardActionClicked: true,
      settings: { slidesToShow: count > 6 ? count - 1 : 5 }
    });
  }


  async handleRemoveStage(event, index) {
    var id = event != undefined ? event.target.id : null;
    var tempAttributeList = [];
    const count = this.state.attributeList.length;

    for (var i = 0; i < this.state.attributeList.length; i++) {
      if (this.state.attributeList[i].id != id) {
        tempAttributeList.push(this.state.attributeList[i]);
      }
    }

    await this.setState({
      attributeList: tempAttributeList,
      cardActionClicked: true,
      settings: { slidesToShow: count < 6 ? count - 1 : 5 }

    });

    this.props.setSelectedStageType(tempAttributeList[0].stageType);
    this.props.setSelectedStageId(tempAttributeList[0].id);
    const tempSubStageAttributeList = pagePropertyListConstant[tempAttributeList[0].stageType + "_STAGE_LIST"][`attributeList`];
    this.props.setSelectedSubStageType(tempSubStageAttributeList[0].stageType);
    this.props.setSelectedStageId(tempSubStageAttributeList[0].id);
    this.props.setPipeLineStageList(tempAttributeList);
  }

  async handleSlideClick(event) {
    if (this.state.cardActionClicked == false) {
      for (var i = 0; i < this.state.attributeList.length; i++) {
        if (event.currentTarget.id == this.state.attributeList[i].id) {
          this.props.setSelectedStageType(this.state.attributeList[i].stageType);
          this.props.setSelectedStageId(this.state.attributeList[i].id);
          const tempSubStageAttributeList = pagePropertyListConstant[this.state.attributeList[i].stageType + "_STAGE_LIST"][`attributeList`];
          this.props.setSelectedSubStageType(tempSubStageAttributeList[0].stageType);
        }
      }
    }
    this.setState({
      cardActionClicked: false
    });
  }

  handleSlideChange(current) {
    this.setState({ cardActionClicked: true });
    for (var i = 0; i < this.state.attributeList.length; i++) {
      if (i == current) {
        this.props.setSelectedStageType(this.state.attributeList[i].stageType);
        this.props.setSelectedStageId(this.state.attributeList[i].id);
        const tempSubStageAttributeList = pagePropertyListConstant[this.state.attributeList[i].stageType + "_STAGE_LIST"][`attributeList`];
        this.props.setSelectedSubStageType(tempSubStageAttributeList[0].stageType);
        break;
      }
    }
  }

  render() {
    this.props.setPipeLineStageList(this.state.attributeList);
    return (
      <div>
        <Col md={12}>
          <div className="content">
            {this.state.attributeList != null && this.state.attributeList.length > 0 ?
              <Slider {...this.state.settings} infinite={this.state.infinite} asNavFor={this.state.nav2}>

                {this.state.attributeList.map((tempAttributeListObj, index) => (
                  tempAttributeListObj.type == pipeLineConstant.CARD_TYPE ?
                    <div className="configure-section" id={tempAttributeListObj.id} key={index} onClick={this.handleSlideClick}>
                      <div className="config-tools"  >

                        <Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : null}>

                          {tempAttributeListObj.editIcon == true ?
                            <i id={tempAttributeListObj.id} name={tempAttributeListObj.name} className="fa fa-pencil" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleEditStage : null} />
                            : null}
                          {tempAttributeListObj.cloneIcon == true ?
                            <i id={tempAttributeListObj.id} name={tempAttributeListObj.name} className="fa fa-copy" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleCloneStage : null} />
                            : null}
                          {tempAttributeListObj.removeIcon == true ?
                            <i id={tempAttributeListObj.id} name={tempAttributeListObj.name} className="fa fa-times-circle-o" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleRemoveStage : null} />
                            : null}

                          {tempAttributeListObj.disableStageText == false ?
                            <i id={tempAttributeListObj.id} name="saveStage" className="fa fa-check" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleEditStage : null} />
                            : null}


                        </Button>
                      </div>
                      <FormControl id={tempAttributeListObj.id} className={tempAttributeListObj.disableStageText == true ? 'pipeline-stage-input' : null} type="text" name={tempAttributeListObj.name} value={tempAttributeListObj.name}
                        onChange={this.handleTextBoxChange} disabled={tempAttributeListObj.disableStageText} />
                    </div>
                    : null))}
              </Slider>
              : null}
          </div>
        </Col>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeList: state.pipeLine.pipeLineStageList,
    pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedStageType: selectedStageType => dispatch(setSelectedStageType(selectedStageType)),
  setSelectedSubStageType: selectedSubStageType => dispatch(setSelectedSubStageType(selectedSubStageType)),
  setSelectedStageId: selectedStageId => dispatch(setSelectedStageId(selectedStageId)),
  setPipeLineStageList: pipeLineStageList => dispatch(setPipeLineStageList(pipeLineStageList))
});

export default connect(mapStateToProps, mapDispatchToProps)(PPLStageSection);

