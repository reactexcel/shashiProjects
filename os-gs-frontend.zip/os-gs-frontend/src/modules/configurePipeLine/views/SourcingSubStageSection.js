import React, { Component } from "react";
import { Row, Col, Table, FormControl } from "react-bootstrap";
import * as pipeLineConstant from '../constant/pipeLineConstant';
import Button from "components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setPipeLineSubStageList } from "../actions/pipeLineActions";

class SourcingSubStageSection extends Component {

    constructor(props) {
        super(props);

        this.state = {
            attributeList: null,
            attributeObj: null,
            selectedStageId: null,
            selectedStageType: null,
            selectedSubStageType: this.props.selectedsubstagetype,
            attributeDataList: null,
            pipeLineSubStageList: null,
            sourcingSubStageType: null
        };
        this.handleEdit = this.handleEdit.bind(this);
        this.handleClone = this.handleClone.bind(this);
        this.handleRemove = this.handleRemove.bind(this);
        this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
        this.updatePipeLineSubStageList = this.updatePipeLineSubStageList.bind(this);
    }

    componentDidMount = () => {
        if (this.state.selectedSubStageType != null) {
            this.setState({
                attributeList: pagePropertyListConstant[this.state.selectedSubStageType + "_STAGE_LIST"][`attributeList`],
                attributeObj: pagePropertyListConstant[this.state.selectedSubStageType + "_STAGE_LIST"][`attributeObj`],
                // attributeDataList: [pagePropertyListConstant[this.state.selectedSubStageType + "_STAGE_LIST"][`attributeObj`]]
            })
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.selectedStageId != null && prevState.selectedStageId != this.props.selectedStageId) {
            this.setState({
                selectedStageId: this.props.selectedStageId,
                selectedSubStageType: this.state.selectedSubStageType,
                selectedStageType: this.props.selectedStageType,
            })
        }
        if (this.props.pipeLineSubStageList != null && prevState.pipeLineSubStageList != this.props.pipeLineSubStageList) {
            if (this.props.pipeLineSubStageList[this.props.selectedStageId] != null &&
                this.props.pipeLineSubStageList[this.props.selectedStageId][this.state.selectedSubStageType] != null) {
                this.setState({
                    attributeDataList: this.props.pipeLineSubStageList[this.props.selectedStageId][this.state.selectedSubStageType]
                })
            }
            this.setState({
                pipeLineSubStageList: this.props.pipeLineSubStageList
            })
        }
        if (this.props.sourcingSubStageType != null && prevProps.sourcingSubStageType != this.props.sourcingSubStageType) {
            this.setState({ attributeDataList: [pagePropertyListConstant[this.state.selectedSubStageType + "_STAGE_LIST"][`attributeObj`]] })
        }
    }


    handleTextBoxChange(event) {
        const { name, value } = event.target;
        var id = parseInt(event.target.id.split('_')[1]);

        var attributeDataList = [...this.state.attributeDataList];

        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                attributeDataList[i][name] = value;
                break;
            }
        }
        this.setState({
            attributeDataList: [...attributeDataList]
        });
        this.updatePipeLineSubStageList(attributeDataList);
    }

    updatePipeLineSubStageList(attributeDataList) {
        if (this.state.pipeLineSubStageList != null) {
            var tempPipeLineSubStageList = { ...this.state.pipeLineSubStageList };
            if (tempPipeLineSubStageList[this.props.selectedStageId] == null) {
                tempPipeLineSubStageList[this.props.selectedStageId] = {};
            }
            tempPipeLineSubStageList[this.props.selectedStageId][this.state.selectedSubStageType] = [...attributeDataList];
            this.props.setPipeLineSubStageList({ ...tempPipeLineSubStageList });
        }
        else {
            var tempPipeLineSubStageList = {};
            tempPipeLineSubStageList[this.props.selectedStageId] = {};
            tempPipeLineSubStageList[this.props.selectedStageId][this.state.selectedSubStageType] = [...attributeDataList];
            this.props.setPipeLineSubStageList({ ...tempPipeLineSubStageList });
        }
    }

    handleEdit(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var tempAttributeDataList = [...this.state.attributeDataList];

        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                tempAttributeDataList[i].disabled = false;
            }
        }
        this.setState({
            attributeDataList: [...tempAttributeDataList]
        });
    }

    handleClone(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var tempAttributeDataList = [];

        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            tempAttributeDataList.push({ ...this.state.attributeDataList[i] });
            if (id == i) {
                tempAttributeDataList.push({ ...this.state.attributeDataList[i] });
            }
        }
        this.setState({
            attributeDataList: [...tempAttributeDataList]
        });
        this.updatePipeLineSubStageList([...tempAttributeDataList]);
    }


    handleRemove(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var attributeDataList = [...this.state.attributeDataList];
        var tempAttributeDataList = [];
        var count = attributeDataList.length;
        if (count > 1) {
            for (var i = 0; i < attributeDataList.length; i++) {
                if (id != i) {
                    tempAttributeDataList.push({ ...attributeDataList[i] });
                }
            }
            this.setState({
                attributeDataList: [...tempAttributeDataList]
            });
        }
    }


    render() {
        const { attributeList, attributeObj, attributeDataList } = this.state;
        const { ...rest } = this.props;
        return (
            <div>
                {attributeList != null && attributeList.length > 0 && this.state.selectedSubStageType != null ?
                    <Table responsive>
                        <thead>
                            <tr>
                                {attributeDataList != null && attributeList.map((tempAttributeListObj, index) => {
                                    return (
                                        <th key={index}>{tempAttributeListObj.title}</th>
                                    )
                                })}
                            </tr>
                        </thead>
                        <tbody>
                            {attributeDataList != null && attributeDataList.map((tempAttributeDataListObj, index) => {
                                return (
                                    <tr key={index}>
                                        {attributeList.map((tempAttributeListObj, index1) => {
                                            return (
                                                <td key={index1}>
                                                    {tempAttributeListObj.type == "TEXTBOX" ?

                                                        <FormControl id={tempAttributeListObj.name + '_' + index} type="text" name={tempAttributeListObj.name}
                                                            onChange={this.handleTextBoxChange} disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}
                                                            value={tempAttributeDataListObj[tempAttributeListObj.name]} />

                                                        : tempAttributeListObj.type == "BUTTON" ?
                                                            <Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}>

                                                                {tempAttributeListObj.editIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name} className="fa fa-pencil"
                                                                        onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleEdit : null} />
                                                                    : null}
                                                                {tempAttributeListObj.cloneIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
                                                                        className="fa fa-copy" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleClone : null} />
                                                                    : null}
                                                                {tempAttributeListObj.removeIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
                                                                        className="fa fa-times" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleRemove : null} />
                                                                    : null}

                                                            </Button>
                                                            : null}
                                                </td>
                                            )
                                        })}
                                    </tr>
                                )
                            })}
                        </tbody>
                    </Table>
                    : null}
            </div>
        );
    }

}

function mapStateToProps(state, ownProps) {
    return {
        sourcingSubStageType: state.pipeLine.sourcingSubStageType,
        selectedStageType: state.pipeLine.selectedStageType,
        selectedStageId: state.pipeLine.selectedStageId,
        pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
        productDetails: state.pipeLine.pipeLineDetails,
        pipeLineSubStageList: state.pipeLine.pipeLineSubStageList,
    };
}

const mapDispatchToProps = dispatch => ({
    setPipeLineSubStageList: pipeLineSubStageList => dispatch(setPipeLineSubStageList(pipeLineSubStageList))
});
export default connect(mapStateToProps, mapDispatchToProps)(SourcingSubStageSection);

