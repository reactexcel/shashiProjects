import React, { Component } from "react";
import { Row, Col, Table, FormControl, FormGroup } from "react-bootstrap";
import * as pipeLineConstant from '../constant/pipeLineConstant';
import Button from "components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import Select from "react-select";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setPipeLineSubStageList } from "../actions/pipeLineActions";
import { setBatchDocuments } from "../actions/batchActions";
import SuggestionUtil from '../../common/util/suggestionUtil';
import CommonUtil from "modules/common/util/commonUtil";
import DragDropDialog from '../../../components/DragDrop/DragDropDialog';

class ConfigureTable extends Component {

    constructor(props) {
        super(props);

        this.state = {
            attributeList: null,
            attributeObj: null,
            selectedStageId: null,
            selectedStageType: null,
            selectedSubStageType: null,
            attributeDataList: null,
            pipeLineSubStageList: null,
            openDocumentModal: false

        };
        this.handleEdit = this.handleEdit.bind(this);
        this.handleClone = this.handleClone.bind(this);
        this.handleRemove = this.handleRemove.bind(this);
        this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
        this.handleDropDownChange = this.handleDropDownChange.bind(this);
        this.updatePipeLineSubStageList = this.updatePipeLineSubStageList.bind(this);
        this.handleSuggestionChange = this.handleSuggestionChange.bind(this);
        this.handleDocumentAttachment = this.handleDocumentAttachment.bind(this);
        this.getDocumentDetails = this.getDocumentDetails.bind(this);
    }

    componentDidMount = () => {
        if (this.props.selectedSubStageType != null) {
            this.setState({
                attributeList: CommonUtil.getDropDownOptionsFromDictionary(
                 pagePropertyListConstant[this.props.selectedSubStageType + "_STAGE_LIST"][`attributeList`],
                 this.props.dataDictionaryList),
                attributeObj: pagePropertyListConstant[this.props.selectedSubStageType + "_STAGE_LIST"][`attributeObj`],
                attributeDataList: [pagePropertyListConstant[this.props.selectedSubStageType + "_STAGE_LIST"][`attributeObj`]]
            })
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.selectedSubStageType != null && prevState.selectedSubStageType != this.props.selectedSubStageType) {
            this.setState({
                selectedStageId: this.props.selectedStageId,
                selectedSubStageType: this.props.selectedSubStageType,
                selectedStageType: this.props.selectedStageType,
            })
        }

        if (this.props.pipeLineSubStageList != null && prevState.pipeLineSubStageList != this.props.pipeLineSubStageList) {
            if (this.props.pipeLineSubStageList[this.props.selectedStageId] != null &&
                this.props.pipeLineSubStageList[this.props.selectedStageId][this.props.selectedSubStageType] != null) {
                this.setState({
                    attributeDataList: this.props.pipeLineSubStageList[this.props.selectedStageId][this.props.selectedSubStageType]
                })
            }
            this.setState({
                pipeLineSubStageList: this.props.pipeLineSubStageList
            })
        }

        if (this.props.supplierList != null && prevState.supplierList != this.props.supplierList) {
            this.setState({
                supplierLocationList:
                    CommonUtil.getSupplierFacilityLocationList(this.props.supplierList.Items),
                supplierList: this.props.supplierList,
                supplierListItem: this.props.supplierList.Items
            })
        }
        if (this.props.facilityList != null && prevState.facilityList != this.props.facilityList) {
            this.setState({
                facilityLocationList:
                    CommonUtil.getSupplierFacilityLocationList(this.props.facilityList.Items),
                facilityList: this.props.facilityList,
                facilityListItem: this.props.facilityList.Items
            })
        }
    }

    handleSuggestionChange = (value, eventId) => {
        var id = parseInt(eventId.split('_')[1]);
        var name = eventId.split('_')[0];
        var attributeDataList = [...this.state.attributeDataList];
        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                attributeDataList[i][name] = value[0];
                break;
            }
        }
        this.setState({
            attributeDataList: [...attributeDataList]
        });
        this.updatePipeLineSubStageList(attributeDataList);
    }

    handleTextBoxChange(event) {
        const { name, value } = event.target;
        var id = parseInt(event.target.id.split('_')[1]);
        var attributeDataList = [...this.state.attributeDataList];
        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                attributeDataList[i][name] = value;
                break;
            }
        }
        this.setState({
            attributeDataList: [...attributeDataList]
        });
        this.updatePipeLineSubStageList(attributeDataList);
    }


    handleDropDownChange(event, obj) {
        var id = parseInt(obj.name.split('_')[1]);
        var attributeDataList = [...this.state.attributeDataList];
        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                attributeDataList[i][[obj.name.split('_')[0]]] = event.value;
                break;
            }
        }
        this.setState({
            attributeDataList: [...attributeDataList]
        });
        this.updatePipeLineSubStageList(attributeDataList);
    }


    updatePipeLineSubStageList(attributeDataList) {
        if (this.state.pipeLineSubStageList != null) {
            var tempPipeLineSubStageList = { ...this.state.pipeLineSubStageList };
            if (tempPipeLineSubStageList[this.props.selectedStageId] == null) {
                tempPipeLineSubStageList[this.props.selectedStageId] = {};
            }
            tempPipeLineSubStageList[this.props.selectedStageId][this.props.selectedSubStageType] = [...attributeDataList];
            this.props.setPipeLineSubStageList({ ...tempPipeLineSubStageList });
        }
        else {
            var tempPipeLineSubStageList = {};
            tempPipeLineSubStageList[this.props.selectedStageId] = {};
            tempPipeLineSubStageList[this.props.selectedStageId][this.props.selectedSubStageType] = [...attributeDataList];
            this.props.setPipeLineSubStageList({ ...tempPipeLineSubStageList });
        }
    }

    handleEdit(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var tempAttributeDataList = [...this.state.attributeDataList];

        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (id == i) {
                tempAttributeDataList[i].disabled = false;
            }
        }
        this.setState({
            attributeDataList: [...tempAttributeDataList]
        });
    }

    handleClone(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var tempAttributeDataList = [];

        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            tempAttributeDataList.push({ ...this.state.attributeDataList[i] });
            if (id == i) {
                tempAttributeDataList.push({ ...this.state.attributeDataList[i] });
            }
        }
        this.setState({
            attributeDataList: [...tempAttributeDataList]
        });
        this.updatePipeLineSubStageList([...tempAttributeDataList]);
    }

    handleDocumentAttachment(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var documentDetailsList = [...this.state.attributeDataList[id].documentDetailsList];
        this.setState({
            openDocumentModal: true,
            selectedRowId: id,
            documentDetailsList: documentDetailsList
        })
    }

    getDocumentDetails(documentDetailsList) {
        var attributeDataList = [...this.state.attributeDataList];
        for (var i = 0; i < this.state.attributeDataList.length; i++) {
            if (this.state.selectedRowId == i) {
                attributeDataList[i].documentDetailsList = [...documentDetailsList];
                break;
            }
        }
        this.setState({
            openDocumentModal: false,
            attributeDataList: [...attributeDataList]
        });
        this.updatePipeLineSubStageList(attributeDataList);
    }

    handleRemove(event) {
        var id = parseInt(event.target.id.split('_')[1]);
        var attributeDataList = [...this.state.attributeDataList];
        var tempAttributeDataList = [];
        var count = attributeDataList.length;
        if (count > 1) {
            for (var i = 0; i < attributeDataList.length; i++) {
                if (id != i) {
                    tempAttributeDataList.push({ ...attributeDataList[i] });
                }
            }
            this.setState({
                attributeDataList: [...tempAttributeDataList]
            });
        }
    }


    render() {
        const { attributeList, attributeObj, attributeDataList } = this.state;
        return (
            <div>
                {this.state.openDocumentModal ?
                    <DragDropDialog
                        accept='text/csv, application/pdf, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel'
                        minSize={0}
                        maxSize={5000000}
                        multiple={false}
                        errormsg="File size exceed max size limit of 5 MB."
                        typeerror="File type is not accepted"
                        getdocumentdetails={this.getDocumentDetails}
                        files={this.state.documentDetailsList}
                        fileNamePrefix={this.state.attributeObj.batchCode}
                    />
                    : null}

                {attributeList != null && attributeList.length > 0 && this.props.selectedSubStageType != null ?
                    <Table responsive>
                        <thead>
                            <tr>
                                {attributeList.map((tempAttributeListObj, index) => {
                                    return (
                                        <th key={index}>{tempAttributeListObj.title}</th>
                                    )
                                })}
                            </tr>
                        </thead>
                        <tbody>
                            {attributeDataList != null && attributeDataList.map((tempAttributeDataListObj, index) => {
                                return (
                                    <tr key={index} onClick={this.checkSubStageType}>
                                        {attributeList.map((tempAttributeListObj, index1) => {
                                            return (
                                                <td key={index1}>
                                                    {tempAttributeListObj.type == "TEXTBOX" ?
                                                        <FormControl id={tempAttributeListObj.name + '_' + index} type={tempAttributeListObj.inputType} name={tempAttributeListObj.name}
                                                            onChange={this.handleTextBoxChange} disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}
                                                            value={tempAttributeDataListObj[tempAttributeListObj.name]} />
                                                        : tempAttributeListObj.type == "BUTTON" ?
                                                            <Button bsStyle="primary" simple icon disabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}>

                                                                {tempAttributeListObj.editIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name} className="fa fa-pencil"
                                                                        onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleEdit : null} />
                                                                    : null}
                                                                {tempAttributeListObj.cloneIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
                                                                        className="fa fa-copy" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleClone : null} />
                                                                    : null}
                                                                {tempAttributeListObj.removeIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name}
                                                                        className="fa fa-times" onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleRemove : null} />
                                                                    : null}
                                                                {tempAttributeListObj.documentIcon == true ?
                                                                    <i id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name} className="fa fa-cloud-upload"
                                                                        onClick={tempAttributeListObj[this.props.pipeLineBatchActionMode] != 'disabled' ? this.handleDocumentAttachment : null} >
                                                                        {tempAttributeDataListObj.documentDetailsList.length + " file attached"}</i>
                                                                    : null}


                                                            </Button>

                                                            : tempAttributeListObj.type == "SUGGESTION" ?
                                                                <SuggestionUtil
                                                                    searchOptionList={tempAttributeListObj.searchOptionList}
                                                                    id={tempAttributeListObj.name + '_' + index}
                                                                    options={this.state[tempAttributeListObj.searchListName]}
                                                                    placeholder={tempAttributeListObj.placeholder}
                                                                    selectedValue={tempAttributeDataListObj[tempAttributeListObj.name]}
                                                                    onChange={(e) => this.handleSuggestionChange(e, tempAttributeListObj.name + '_' + index)}
                                                                    handleSuggestionChange={this.handleSuggestionChange}
                                                                />


                                                                : tempAttributeListObj.type == "DROPDOWN" ?
                                                                    <Select id={tempAttributeListObj.name + '_' + index} name={tempAttributeListObj.name + '_' + index} onChange={this.handleDropDownChange}
                                                                        isMulti={tempAttributeListObj.isMulti}
                                                                        placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options}
                                                                        classNamePrefix="react-select" isDisabled={tempAttributeListObj[this.props.pipeLineBatchActionMode] == 'disabled' ? true : false}
                                                                        value={{ "label": tempAttributeDataListObj[tempAttributeListObj.name] }} />
                                                                    : null

                                                    }
                                                </td>
                                            )
                                        })}
                                    </tr>
                                )
                            })}
                        </tbody>
                    </Table>
                    : null}
            </div>
        );
    }

}

function mapStateToProps(state, ownProps) {
    return {
        selectedStageType: state.pipeLine.selectedStageType,
        selectedSubStageType: state.pipeLine.selectedSubStageType,
        selectedStageId: state.pipeLine.selectedStageId,
        productDetails: state.pipeLine.pipeLineDetails,
        pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
        pipeLineSubStageList: state.pipeLine.pipeLineSubStageList,
        pipeLineClassification: state.pipeLine.pipeLineClassification,
        documentURLObj: state.supplier.documentURLObj,
        supplierList: state.supplier.supplierList,
        facilityList: state.facility.facilityList,
        dataDictionaryList:state.dataDictionary.dataDictionaryList
    };
}

const mapDispatchToProps = dispatch => ({
    setBatchDocuments: (fileObj, documentIdObj) => dispatch(setBatchDocuments(fileObj, documentIdObj)),
    setPipeLineSubStageList: pipeLineSubStageList => dispatch(setPipeLineSubStageList(pipeLineSubStageList)),

});
export default connect(mapStateToProps, mapDispatchToProps)(ConfigureTable);
