import React, { Component } from "react";
import { Row, Col, Table } from "react-bootstrap";
import ConfigureTable from "./ConfigureTable";
import ConfigureForm from "./ConfigureForm";
import * as pipeLineConstant from '../constant/pipeLineConstant';

class ConfigureDynamic extends Component {
  constructor(props) {
    super(props);

    this.state = {
      componentAttributeObj: null,
      selectedSubStageType: 'SOURCING_INGREDIENTS',
    };
    this.handleTabClick = this.handleTabClick.bind(this);
  }

  componentDidMount = () => {

  }

  handleTabClick(event) {
    const { name, value } = event.target;
    const { componentAttributeObj } = this.state;
    this.setState({
      componentAttributeObj: {
        ...componentAttributeObj,
        [name]: value
      }
    });
    this.props.getAttributeObj(this.state.componentAttributeObj);
  }

  render() {
    const { pagePropertyListConstant } = this.props;
    return (
      <Row>
        <Col md={12}>
          {pagePropertyListConstant.SOURCING_STAGE_LIST.attributeList.map((tempAttributeListObj, index) => (

            tempAttributeListObj.dynamicSection == true ?
              tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                <ConfigureTable> </ConfigureTable>
                : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureForm> </ConfigureForm>
                  : null
              : null
          ))}
        </Col>
      </Row>
    );
  }

}
export default ConfigureDynamic;
