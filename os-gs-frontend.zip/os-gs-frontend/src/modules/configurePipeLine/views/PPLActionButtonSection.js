import React, { Component } from "react";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setPipeLineSaveFlag, setPipeLineDetails } from "../actions/pipeLineActions";
import { setBatchDetails } from "../actions/batchActions";
import * as pipeLineConstant from '../constant/pipeLineConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { Link, Redirect } from "react-router-dom";
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import * as  batchConstant from '../constant/batchConstant';

class PPLActionButtonSection extends Component {
    constructor(props) {
        super(props);
        this.state = {
            attributeList: null,
            attributeObj: null,
            redirectUrl: false,
            pipeLineDetails: null,
            alert: null,
            submitted: false,
        };
        this.handleCancel = this.handleCancel.bind(this);
        this.handlePopupCancel = this.handlePopupCancel.bind(this);
        this.handlePopupContinue = this.handlePopupContinue.bind(this);
        this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
        this.handleSave = this.handleSave.bind(this);
        this.handlePageRedirection = this.handlePageRedirection.bind(this);
        this.prepareCreateBatchData = this.prepareCreateBatchData.bind(this);
        this.prepareModifyBatchData = this.prepareModifyBatchData.bind(this);
        this.updateBatchCountInProduct = this.updateBatchCountInProduct.bind(this);
    }

    componentDidMount() {

    }

    componentDidUpdate(prevProps) {
        if (this.props.pipeLineDetails != null && prevProps.pipeLineDetails != this.props.pipeLineDetails) {
            this.setState({
                pipeLineDetails: this.props.pipeLineDetails
            })
        }
        if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
            this.handleAjaxResponse();
        }
    }

    handleAjaxResponse() {
        if (this.props.ajaxCallStatus == "SUCCESS") {
            this.props.setAjaxCallStatus(null);
            this.handlePageRedirection(pipeLineConstant.MANAGE_PRODUCT_PAGE_URL);
        }
        if (this.props.ajaxCallStatus == "FAILED") {
            var popActionButton = {};
            popActionButton.onConfirmClick = this.handlePopupContinue;
            popActionButton.onCancelClick = this.handlePopupCancel;
            var popupConfig = CommonUtil.prepareAjaxCallErrorPopUpConfig(popActionButton);
            this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
            this.props.setAjaxCallStatus(null);
        }
    }

    handleCancel() {
        var popActionButton = {};
        popActionButton.onConfirmClick = this.handlePopupContinue;
        popActionButton.onCancelClick = this.handlePopupCancel;
        var popupConfig = CommonUtil.prepareCancelPopUpConfig(popActionButton);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handlePopupCancel() {
        this.setState({ alert: null });
    }

    handlePopupContinue() {
        this.handlePageRedirection(pipeLineConstant.MANAGE_PRODUCT_PAGE_URL);
    }

    handlePageRedirection = (redirectURL) => {
        this.setState({ redirect: true, redirectUrl: redirectURL }, () => {
        });
    }

    handleSave() {
        this.setState({ submitted: true });
        this.props.setPipeLineSaveFlag(true);
        if (this.props.pipeLineBatchActionMode == pipeLineConstant.CONFIGURE_PIPELINE ||
            this.props.pipeLineBatchActionMode == pipeLineConstant.MODIFY_PIPELINE) {
            var tempObj = {};
            tempObj = this.state.pipeLineDetails;
            tempObj.pipeLineDetails = {};
            tempObj.pipeLineCode = this.props.pipeLineClassification.pipeLineCode;
            tempObj.pipeLineName = this.props.pipeLineClassification.pipeLineName;
            if (this.state.pipeLineDetails && tempObj.pipeLineCode && tempObj.pipeLineName && tempObj.productId) {
                tempObj.pipeLineDetails.pipeLineClassification = this.props.pipeLineClassification;
                tempObj.pipeLineDetails.pipeLineStageList = this.props.pipeLineStageList;
                this.props.setPipeLineDetails(tempObj, pipeLineConstant.EDIT_ACTION_MODE);
            }
        }

        if (this.props.pipeLineBatchActionMode == pipeLineConstant.CREATE_BATCH) {
            var tempObj = this.prepareCreateBatchData();
            var tempBatchCountObj = this.updateBatchCountInProduct();
            if (tempObj.poNumber && tempObj.batchCode) {
                this.props.setBatchDetails(tempObj, pipeLineConstant.CREATE_ACTION_MODE);
                this.props.setPipeLineDetails(tempBatchCountObj, pipeLineConstant.EDIT_ACTION_MODE);
            }
        }
        if (this.props.pipeLineBatchActionMode == pipeLineConstant.MODIFY_BATCH) {
            var tempObj = this.prepareModifyBatchData();
            this.props.setBatchDetails(tempObj, pipeLineConstant.EDIT_ACTION_MODE);
        }
    }

    updateBatchCountInProduct() {
        var tempObj = {};
        tempObj = this.state.pipeLineDetails;
        tempObj.batchCount = tempObj.batchCount + 1;
        return tempObj;
    }

    prepareCreateBatchData() {
        var tempObj = {};
        tempObj.batchCode = this.props.pipeLineClassification.batchCode;
        tempObj.poNumber = this.props.pipeLineClassification.poNumber;
        tempObj.pipeLineCode = this.props.pipeLineClassification.pipeLineCode;
        tempObj.batchStatus = batchConstant.BATCH_INPROGRESS_STATUS;
        tempObj.consumerPageStatus = batchConstant.CONSUMER_PAGE_STATUS;
        tempObj.productId = this.props.pipeLineClassification.productId;
        tempObj.productName = this.props.pipeLineClassification.productName;
        tempObj.pipeLineStageList = this.props.pipeLineStageList;
        tempObj.batchData = this.props.pipeLineSubStageList;
        tempObj.status = pipeLineConstant.ACTIVE_STATUS;
        console.log("BATCH DATA " + JSON.stringify(tempObj));
        return tempObj;
    }

    prepareModifyBatchData() {
        var tempObj = {};
        tempObj = this.props.batchDetails;
        tempObj.batchStatus = batchConstant.BATCH_INPROGRESS_STATUS;
        tempObj.batchData = this.props.pipeLineSubStageList;
        return tempObj;
    }

    render() {
        return (
            <div>
                {this.state.alert}
                <Button className="btn-cancel" onClick={this.handleCancel}>
                    Cancel
                 </Button>
                <Button className="btn-save btn-fill" onClick={this.handleSave}>
                    Save
               </Button>
                {this.state.redirect === true ?
                    <Redirect push to={this.state.redirectUrl}></Redirect> : null
                }
            </div>
        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
        pipeLineClassification: state.pipeLine.pipeLineClassification,
        pipeLineStageList: state.pipeLine.pipeLineStageList,
        pipeLineSubStageList: state.pipeLine.pipeLineSubStageList,
        pipeLineDetails: state.pipeLine.pipeLineDetails,
        batchDetails: state.batch.batchDetails,
        pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
        sourcingSubStageType: state.pipeLine.sourcingSubStageType,
        ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus
    };
}

const mapDispatchToProps = dispatch => ({
    setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
    setPipeLineSaveFlag: submitted => dispatch(setPipeLineSaveFlag(submitted)),
    setPipeLineDetails: (pipeLineData, actionMode) => dispatch(setPipeLineDetails(pipeLineData, actionMode)),
    setBatchDetails: (batchData, actionMode) => dispatch(setBatchDetails(batchData, actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PPLActionButtonSection);


