import React, { Component } from "react";
import { connect } from "react-redux";
import { Grid, Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import CreateFacility from '../../facilityManagement/views/CreateFacility';
import CreateSupplier from '../../supplierManagement/views/CreateSupplier';
import { setActionMode } from "../../../actions/appActions";
import * as facilityConstant from "../../facilityManagement/constant/facilityConstant";
import * as supplierConstant from "../../supplierManagement/constant/supplierConstant";
import { setPipeLineModal } from "../actions/pipeLineActions";
import * as commonConstant from '../../common/constant/commonConstant';

var Modal = require('react-bootstrap-modal')

class PipeLinePopupModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      moduleName: null,
      pipeLineModal: null,
    };
    this.closeModal = this.closeModal.bind(this);
    this.checkModuleName = this.checkModuleName.bind(this);
  }

  componentDidMount() {
    this.setState({ openModal: true });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.pipeLineModal != null && prevState.pipeLineModal != this.props.pipeLineModal) {
      this.checkModuleName();
    }
  }

  checkModuleName() {
    this.setState({
      openModal: true,
      pipeLineModal: this.props.pipeLineModal,
    })
    if (this.props.pipeLineModal == "SUPPLIER") {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    }
    if (this.props.pipeLineModal == "FACILITY") {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    }
  }

  closeModal(event) {
    this.setState({ openModal: false });
    this.props.setPipeLineModal(null);
  }

  render() {

    return (
      <div >
        <Modal show={this.state.openModal} onHide={this.closeModal} aria-labelledby="ModalHeader">
          <Modal.Header closeButton>
            <Modal.Title><div className="card-header-capital"></div></Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {this.props.pipeLineModal === "FACILITY" ?
              <CreateFacility></CreateFacility>
              : this.props.pipeLineModal === "SUPPLIER" ?
                <CreateSupplier></CreateSupplier>
                : null}
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    pipeLineModal: state.pipeLine.pipeLineModal,
  };
}

const mapDispatchToProps = dispatch => ({
  setActionMode: supplierActionMode => dispatch(setActionMode(supplierActionMode)),
  setPipeLineModal: pipeLineModal => dispatch(setPipeLineModal(pipeLineModal)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PipeLinePopupModal);


