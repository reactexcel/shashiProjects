import React, { Component } from "react";
import { Row } from "react-bootstrap";
import { connect } from "react-redux";
import { setPipeLineModal } from "../actions/pipeLineActions";
import { Col, Table } from "react-bootstrap";
import ConfigureTable from "./ConfigureTable";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import ConfigureForm from './ConfigureForm';
import PipeLinePopupModal from './PipeLinePopupModal';

class ProcessingStage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeList: null,
      selectedSubStageType: null,
      selectedStageType: null,
      componentAttributeObj: null,
    };
    this.handlePipelinePopupModal = this.handlePipelinePopupModal.bind(this);
  }

  handlePipelinePopupModal() {
    this.props.setPipeLineModal('FACILITY');
    this.setState({ openModal: true });
  }

  componentDidMount = () => {

  }

  render() {

    if (this.props.selectedStageType != null) {
      this.state.attributeList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`];
      this.state.selectedStageType = this.props.selectedStageType;
      this.state.selectedSubStageType = this.props.selectedSubStageType;
    }

    return (
      <Row>
        <Col md={12}>
          {this.props.pipeLineModal != null ?
            <PipeLinePopupModal></PipeLinePopupModal>
            : null}
          <div className="create-new">
            <a><i className="fa fa-plus" onClick={this.handlePipelinePopupModal} />Add NEW PROCESSING</a>
          </div>
        </Col>
        {this.props.selectedStageType != null ?
          <Col md={12}>
            {this.state.attributeList.map((tempAttributeListObj, index) => (

              tempAttributeListObj.dynamicSection == false ?

                tempAttributeListObj.stageType == pipeLineConstant.PROCESSING_PLANT_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.stageType == pipeLineConstant.PROCESSING_DOCUMENTATION_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureTable key={index}> </ConfigureTable>
                    : tempAttributeListObj.stageType == pipeLineConstant.PROCESSING_QUALITY_CHECK_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                      <ConfigureTable key={index}> </ConfigureTable>
                      : null
                :

                tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index} > </ConfigureTable>
                  : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureForm key={index}  > </ConfigureForm>
                    : null

            ))}
          </Col>
          : null}
      </Row>
    );
  }

}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType,
    pipeLineModal: state.pipeLine.pipeLineModal,
  };
}

const mapDispatchToProps = dispatch => ({
  setPipeLineModal: pipeLineModal => dispatch(setPipeLineModal(pipeLineModal)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ProcessingStage);

