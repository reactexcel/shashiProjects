import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as batchConstant from '../constant/batchConstant';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setSelectedBatchCode, getBatchList, getBatchListByProduct, setReducerInitMode } from "../actions/batchActions";
import { setPipeLineBatchActionMode } from "../../configurePipeLine/actions/pipeLineActions";
import { setSelectedProductCode } from "../../productManagement/actions/productActions";
import CommonUtil from '../../common/util/commonUtil';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import map from "lodash/map";
import Table from '../../../views/Tables/PopularTable/Table/Table';
import PaginationUtil from "../../common/util/paginationUtil";
import mixpanel from "../../analytics/mixpanel/mixpael";

import filter from 'assets/img/filter.svg';

class ManageBatch extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      dashboardPage: false,

      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      defaultPageSize: 3,
      lastEvaluatedKeyArray: [],
      propertiesInnitialized: false,

    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePageRedirection = this.handlePageRedirection.bind(this);
    this.setSelectedPageDetails = this.setSelectedPageDetails.bind(this);
    this.handleDashBoardFilter = this.handleDashBoardFilter.bind(this);
    this.handleFilterStatus = this.handleFilterStatus.bind(this);
    this.makeCustomAPICall= this.makeCustomAPICall.bind(this);
  }

  componentDidMount = () => {
      mixpanel.track("Manage batch loaded");
    if (this.props.pipeLineBatchActionMode == batchConstant.VIEW_BATCH) {
      this.props.getBatchListByProduct(this.props.productId);
    }
    else {
      this.makeCustomAPICall(PaginationUtil.getPaginationParams(1, null, this));
     // this.props.getBatchList(this.props.location && this.props.location.state);
    }
    this.setSelectedPageDetails();
    this.handleFilterStatus();
  }

  makeCustomAPICall(tempParamas) {
    this.props.getBatchList(tempParamas);
  }

  handleFilterStatus = () => {
    var tempStatus = this.props.location && this.props.location.state && this.props.location.state.status;

    if (tempStatus == "I") {
      this.setState({
        batchStatusLabel: "Incomplete Batches",
        batchFilterFlag: true
      });
    }
    if (tempStatus == "Q") {
      this.setState({
        batchStatusLabel: "Batch Without QR Code",
        batchFilterFlag: true
      });
    }
    if (tempStatus == "C") {
      this.setState({
        batchStatusLabel: "Batch Without CMS Page",
        batchFilterFlag: true
      });
    }
  }

  getRoles = (userPermissions) => {
    const permissions = map(userPermissions, (permission) => {
      return permission.role;
    });
    return permissions;
  };

  setSelectedPageDetails() {
    var selectedPageName = this.props.dashboardPage !== undefined ? this.props.dashboardPage + "_" : '';
    //const userPermissions = this.getRoles(this.props.userInfo.roles);
    const userPermissions = null;
    if (selectedPageName === "") {
      const managebatchesPageList = pagePropertyListConstant.MANAGE_BATCH_PAGE_LIST(userPermissions, this);
      this.setState({
        tableColumnList: managebatchesPageList.tableColumnList,
        defaultFilteredList: managebatchesPageList.defaultFilteredList,
        defaultSortedList: managebatchesPageList.defaultSortedList,
        defaultPageSize: managebatchesPageList.defaultPageSize,
        tableConfig: managebatchesPageList.tableConfig,
        tableDataList: batchConstant.dataTable,
      });
    } else {
      const managebatchesPageList = pagePropertyListConstant[selectedPageName + "MANAGE_BATCH_PAGE_LIST"](userPermissions, this);
      this.setState({
        tableColumnList: managebatchesPageList.tableColumnList,
        defaultFilteredList: managebatchesPageList.defaultFilteredList,
        defaultSortedList: managebatchesPageList.defaultSortedList,
        defaultPageSize: managebatchesPageList.defaultPageSize,
        tableConfig: managebatchesPageList.tableConfig,
        tableDataList: batchConstant.dataTable
      });
    }
  }


  componentDidUpdate(prevProps) {
    if (prevProps.batchList != this.props.batchList && this.props.batchList != null) {
      PaginationUtil.handlePagination(this.props.batchList, this);
    }
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.batchList.filter(value => {
      return (
        value.batchCode.toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  handleFIlter = (event) => {
    this.setState({
      defaultFilteredList: [
        {
          id: "batchStatus",
          value: event
        }
      ]
    })
  }

  handleDashBoardFilter = (event) => {
    this.props.getBatchList();
    this.setState({
      batchStatusLabel: "Batch Without CMS Page",
      batchFilterFlag: false
    });
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedProductCode(tempId[0]);
    this.props.setPipeLineBatchActionMode(batchConstant.MODIFY_BATCH);
    this.props.setSelectedBatchCode(tempId[2]);
    this.handlePageRedirection(batchConstant.CONFIGURE_PIPELINE_PAGE_URL);
  }


  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");
    if (tempId[2] == batchConstant.GENERATE_QR_CODE) {
      this.props.setSelectedProductCode(tempId[0]);
      this.props.setPipeLineBatchActionMode(tempId[2]);
      this.props.setSelectedBatchCode(tempId[3]);
      this.handlePageRedirection(batchConstant.GENERATE_QR_CODE_PAGE_URL);
    }
    if (tempId[2] == batchConstant.MODIFY_QR_CODE) {
      this.props.setSelectedProductCode(tempId[0]);
      this.props.setPipeLineBatchActionMode(tempId[2]);
      this.props.setSelectedBatchCode(tempId[3]);
      this.handlePageRedirection(batchConstant.MODIFY_QR_CODE_PAGE_URL);
    }
    if (tempId[2] == batchConstant.TRACK_BATCH) {
      this.props.setSelectedProductCode(tempId[0]);
      this.props.setPipeLineBatchActionMode(tempId[2]);
      this.props.setSelectedBatchCode(tempId[3]);

    }
    if (tempId[2] == batchConstant.PREVIEW_CONSUMER_PAGE) {
      this.props.setSelectedProductCode(tempId[0]);
      this.props.setPipeLineBatchActionMode(tempId[2]);
      this.props.setSelectedBatchCode(tempId[3]);
    }
  }

  handlePageRedirection = (redirectURL) => {
    this.setState({ redirect: true, redirectUrl: redirectURL }, () => {
    });
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (tempId != null && tempId[1] == batchConstant.EDIT_ACTION_MODE || tempId[1] == batchConstant.CLONE_ACTION_MODE) {
      this.handleEditClone(event.target.id);
    }
    if (tempId != null && tempId[1] == batchConstant.MENU_ACTION_MODE) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  render() {
    const { tableColumnList, tableDataList, defaultSortedList, defaultFilteredList,
      defaultPageSize, batchFilterFlag ,tableConfig} = this.state;
    return (
     <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }

        {this.state.alert}
        <Grid fluid>
          {this.props.dashboardPage == undefined ?
            <Row className="top-row">
              <div className="header-section">
                <Col sm={4} md={4}>
                  <div className="page-title">
                    {batchConstant.MANAGE_BATCH_HEADER_TITLE}
                  </div>
                </Col>
                <Col xs={12} sm={8} md={8}>
                  <div className="left-section">
                    <div className="search-section">
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search By Batch Code / Name"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </div>

                    <Nav pullRight>
                      <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                        noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                        <MenuItem eventKey="">All</MenuItem>
                        <MenuItem eventKey={batchConstant.BATCH_INPROGRESS_STATUS}>In Progress</MenuItem>
                        <MenuItem eventKey={batchConstant.BATCH_COMPLETED_STATUS}>Completed</MenuItem>
                      </NavDropdown>
                    </Nav>
                  </div>
                </Col>
              </div>
            </Row>
            : null}
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>

                    {tableColumnList != null ?
                      <Row>
                        {this.state.batchFilterFlag ?
                          <Button fill wd bsStyle="info" className="batch-filter btn-fill btn-wd">
                            {this.state.batchStatusLabel} <i className="fa fa-close" onClick={this.handleDashBoardFilter} />
                          </Button>
                          : null}

                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}

                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state) {
  return {
    batchList: state.batch.batchList,
    productId: state.product.selectedProductCode,
    pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
    userInfo: state.authReducer.userInfo,
    dataDictionaryList:state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedBatchCode: selectedBatchCode => dispatch(setSelectedBatchCode(selectedBatchCode)),
  setPipeLineBatchActionMode: pipeLineBatchActionMode => dispatch(setPipeLineBatchActionMode(pipeLineBatchActionMode)),
  getBatchList: params => dispatch(getBatchList(params)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getBatchListByProduct: selectedProductCode => dispatch(getBatchListByProduct(selectedProductCode)),
  setSelectedProductCode: selectedProductCode => dispatch(setSelectedProductCode(selectedProductCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageBatch);


