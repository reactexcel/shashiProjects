import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Select from "react-select";
import { connect } from "react-redux";

class ConfigureForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null
    };
    this.handleTextBoxChange = this.handleTextBoxChange.bind(this);
    this.handleDropDownChange = this.handleDropDownChange.bind(this);
    this.handleTextList = this.handleTextList.bind(this);
    this.handelRemoveTextList = this.handelRemoveTextList.bind(this);
  }

  componentDidMount = () => {
    if (this.props.attributeList != null) {
      this.setState({
        attributeList: this.props.attributeList,
        attributeObj: this.props.attributeObj,
      })
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.productDetails != null) {
      this.setState({
        attributeObj: this.props.productDetails,
      })
    }
  }

  handelRemoveTextList(event) {
    const listName = event.target.id.split('_')[0] + 'List';
    const index = parseInt(event.target.id.split('_')[1]);
    var attributeObj = { ...this.state.attributeObj };
    attributeObj[listName].splice(index, 1);
    this.setState({
      attributeObj: {
        ...attributeObj,
      }, function() {
      }
    })
  }

  handleTextList(event) {
    const id = event.target.id;
    var attributeObj = { ...this.state.attributeObj };
    var tempName = id + 'List';
    attributeObj[tempName].push(this.state.attributeObj[id])
    this.setState({
      attributeObj: {
        ...attributeObj,
      }, function() {
      }
    })
  }

  handleTextBoxChange(event) {
    const { name, value } = event.target;
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        [name]: value
      }, function() {
      }
    })
  }

  handleDropDownChange(event, obj) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        [obj.name]: event.value
      }, function() {
      }
    })
  }


  render() {
    const { attributeList, attributeObj } = this.state;
    return (
      <div className="main-content">
        <Grid fluid>
          <Row>
            <Col md={12}>
              <form>
                <Card title={<legend>Configure Form</legend>}
                  content={
                    <div>
                      <Row>
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (

                          tempAttributeListObj.type == "TEXTBOX" ?
                            <Col md={tempAttributeListObj.fieldWidth} key={index}>
                              <FormGroup>
                                <ControlLabel>
                                  {tempAttributeListObj.label}
                                  {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                </ControlLabel>
                                <FormControl rows={tempAttributeListObj.numberOfRow} componentClass={tempAttributeListObj.numberOfRow != 1 ? 'textarea' : 'textarea'} type="text" name={tempAttributeListObj.name} value={attributeObj[tempAttributeListObj.name]}
                                  onChange={this.handleTextBoxChange} />
                                <small className="text-danger">
                                  {tempAttributeListObj.mandatoryMsgText}
                                </small>
                              </FormGroup>
                            </Col>

                            : tempAttributeListObj.type == "DROPDOWN" ?
                              <Col md={tempAttributeListObj.fieldWidth} key={index}>
                                <FormGroup>
                                  <ControlLabel>
                                    {tempAttributeListObj.label}
                                    {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                  </ControlLabel>
                                  <Select name={tempAttributeListObj.name} onChange={this.handleDropDownChange}
                                    isMulti={tempAttributeListObj.isMulti}
                                    placeholder={tempAttributeListObj.placeholder} options={tempAttributeListObj.options} />
                                  <small className="text-danger">
                                    {tempAttributeListObj.mandatoryMsgText}
                                  </small>
                                </FormGroup>
                              </Col>

                              : tempAttributeListObj.type == "TEXT_LIST" ?
                                <Col md={tempAttributeListObj.fieldWidth} key={index}>
                                  <FormGroup >
                                    <ControlLabel>
                                      {tempAttributeListObj.label}
                                      {tempAttributeListObj.required == true ? <span className="star">*</span> : null}
                                    </ControlLabel>
                                    <div className="form-control ingredients">
                                      <ul>
                                        {attributeObj != null && attributeObj[tempAttributeListObj.list].map((tempList, index) => (
                                          <li key={index}>
                                            {tempList} <i id={tempAttributeListObj.name + '_' + index} className="fa fa-close" onClick={this.handelRemoveTextList} />
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  </FormGroup>
                                  <div className="add-row">
                                    <div className="row-data">
                                      <FormControl type="text" name={tempAttributeListObj.name} value={attributeObj[tempAttributeListObj.name]}
                                        onChange={this.handleTextBoxChange} />
                                    </div>
                                    <div id={tempAttributeListObj.name} className="add-row-button" onClick={this.handleTextList} >
                                      <i id={tempAttributeListObj.name} className=" fa fa-plus" />
                                      Add New
                                    </div>
                                  </div>
                                </Col>
                                : null))
                        }
                      </Row>
                    </div>
                  }
                  ftTextCenter
                  legend={
                    <div>
                      <Button fill wd bsStyle="info" onClick={this.handleCancel}>
                        Create Product
                   </Button>
                      <Button fill wd bsStyle="info" onClick={this.handleCancel}>
                        Cancel
                     </Button>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
   // productDetails: state.product.productDetails,
  };
}

const mapDispatchToProps = dispatch => ({
 // setProductDetails: productDetailsObj => dispatch(setProductDetails(productDetailsObj))
});

export default connect(mapStateToProps, mapDispatchToProps)(ConfigureForm);

