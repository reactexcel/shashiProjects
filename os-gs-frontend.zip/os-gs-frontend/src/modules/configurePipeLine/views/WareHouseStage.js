import React, { Component } from "react";
import { Row, Col, Table } from "react-bootstrap";
import { connect } from "react-redux";
import ConfigureTable from "./ConfigureTable";
import { setSelectedSubStageType, setSelectedStageType } from "../actions/pipeLineActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import ConfigureForm from "./ConfigureForm";
import CustomRadio from "../../../components/CustomRadio/CustomRadio.jsx";
import { setPipeLineModal } from "../actions/pipeLineActions";
import PipeLinePopupModal from './PipeLinePopupModal';

class WareHouseStage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeList: null,
      selectedSubStageType: null,
      selectedStageType: null,
      componentAttributeObj: null,
      pipeLineSubStageList: null,
      wareHouseSubStageType: pipeLineConstant.WAREHOUSE_STOCK_STAGE_TYPE,
    };
    this.handleRadioButton = this.handleRadioButton.bind(this);
    this.handlePipelinePopupModal = this.handlePipelinePopupModal.bind(this);
  }

  handlePipelinePopupModal() {
    this.props.setPipeLineModal('FACILITY');
    this.setState({ openModal: true });
  }

  componentDidMount = () => {
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.pipeLineSubStageList != null && prevState.pipeLineSubStageList != this.props.pipeLineSubStageList) {
      if (this.props.pipeLineSubStageList[this.props.selectedStageId] != null &&
        this.props.pipeLineSubStageList[this.props.selectedStageId][pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE] != null) {
        this.setState({
          wareHouseSubStageType: pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE,
          selectedSubStageType: pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE,
        })
        this.props.setSelectedSubStageType(pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE);
      }
      this.setState({
        pipeLineSubStageList: this.props.pipeLineSubStageList
      })
    }
  }

  handleRadioButton(event) {
    this.props.setSelectedSubStageType(event.target.value);
    this.setState({ wareHouseSubStageType: event.target.value });
    console.log("PP WareHouse " + event.target.value);
  }


  render() {
    if (this.props.selectedStageType != null) {
      this.state.attributeList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`];
      this.state.checkBoxList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"]['checkBoxList'];
      this.state.selectedStageType = this.props.selectedStageType;
      this.state.selectedSubStageType = this.props.selectedSubStageType;
    }

    return (
      <Row>
        <Col md={12}>
          {this.props.pipeLineModal != null ?
            <PipeLinePopupModal></PipeLinePopupModal>
            : null}

          {this.state.checkBoxList && this.state.checkBoxList.map((tempAttributeListObj, index) => (
            tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_STOCK_STAGE_TYPE ?

              <div key={index} className="inline-checkbox">
                <CustomRadio key={index} name={1} number={tempAttributeListObj.name} label={tempAttributeListObj.label}
                  onChange={this.handleRadioButton} value={tempAttributeListObj.stageType}
                  checked={this.state.wareHouseSubStageType == "WAREHOUSE_STOCK"} />
              </div>
              : tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE ?
                <div key={index} className="inline-checkbox">
                  <CustomRadio key={index} name={1} number={tempAttributeListObj.name} label={tempAttributeListObj.label}
                    onChange={this.handleRadioButton} value={tempAttributeListObj.stageType}
                    checked={this.state.wareHouseSubStageType == "WAREHOUSE_CHANNEL_SALES"} />
                </div>
                : null
          ))}
          <div className="create-new">
            <a ><i className="fa fa-plus" onClick={this.handlePipelinePopupModal} />ADD NEW WAREHOUSE</a>
          </div>
        </Col>

        {this.props.selectedStageType != null ?
          <Col md={12}>

            {this.state.attributeList.map((tempAttributeListObj, index) => (

              tempAttributeListObj.dynamicSection == false ?

                tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_STOCK_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_CHANNEL_SALES_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureTable key={index}> </ConfigureTable>
                    : tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_DOCUMENTATION_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                      <ConfigureTable key={index}> </ConfigureTable>
                      : tempAttributeListObj.stageType == pipeLineConstant.WAREHOUSE_QUALITY_CHECK_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                        <ConfigureTable key={index}> </ConfigureTable>
                        : null
                :

                tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureForm key={index}  > </ConfigureForm>
                    : null

            ))}
          </Col>
          : null}
      </Row>
    );
  }

}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType,
    selectedStageId: state.pipeLine.selectedStageId,
    pipeLineBatchActionMode: state.pipeLine.pipeLineBatchActionMode,
    pipeLineSubStageList: state.pipeLine.pipeLineSubStageList,
    pipeLineModal: state.pipeLine.pipeLineModal,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedSubStageType: selectedSubStageType => dispatch(setSelectedSubStageType(selectedSubStageType)),
  setSelectedStageType: selectedStageType => dispatch(setSelectedStageType(selectedStageType)),
  setPipeLineModal: pipeLineModal => dispatch(setPipeLineModal(pipeLineModal)),
});

export default connect(mapStateToProps, mapDispatchToProps)(WareHouseStage);

