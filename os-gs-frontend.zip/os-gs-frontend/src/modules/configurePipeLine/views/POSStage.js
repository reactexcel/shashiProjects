import React, { Component } from "react";
import { Row, Col, Table } from "react-bootstrap";
import { connect } from "react-redux";
import ConfigureTable from "./ConfigureTable";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as pipeLineConstant from '../constant/pipeLineConstant';
import ConfigureForm from "./ConfigureForm";

class POSStage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      attributeList: null,
      selectedSubStageType: null,
      selectedStageType: null,
      componentAttributeObj: null,
    };

  }

  componentDidMount = () => {

  }


  render() {

    if (this.props.selectedStageType != null) {
      this.state.attributeList = pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`];
      this.state.selectedStageType = this.props.selectedStageType;
      this.state.selectedSubStageType = this.props.selectedSubStageType;
    }

    return (
      <Row>
        <Col md={12}>
           
        </Col>
        {this.props.selectedStageType != null ?
          <Col md={12}>
            {this.state.attributeList.map((tempAttributeListObj, index) => (

              tempAttributeListObj.dynamicSection == false ?

                tempAttributeListObj.stageType == pipeLineConstant.POS_SALES_CHANNEL_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index}> </ConfigureTable>
                  : tempAttributeListObj.stageType == pipeLineConstant.POS_DOCUMENTATION_STAGE_TYPE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureTable key={index}> </ConfigureTable>
                    : null
                :

                tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_TABLE && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                  <ConfigureTable key={index} > </ConfigureTable>
                  : tempAttributeListObj.dynamicSectionType == pipeLineConstant.PAGE_TYPE_FORM && this.state.selectedSubStageType == tempAttributeListObj.stageType ?
                    <ConfigureForm key={index} > </ConfigureForm>
                    : null

            ))}
          </Col>
          : null}
      </Row>
    );
  }

}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType
  };
}

const mapDispatchToProps = dispatch => ({

});

export default connect(mapStateToProps, mapDispatchToProps)(POSStage);

