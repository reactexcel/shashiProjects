import React, { Component } from "react";
import { Col } from "react-bootstrap";
import { connect } from "react-redux";
import { Tabs, Tab } from 'react-bootstrap-tabs';
import { setSelectedSubStageType } from "../actions/pipeLineActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import Checkbox from "../../../components/CustomCheckbox/CustomCheckbox.jsx";

class PPLStageSubSection extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      checkBoxList: null,
      attributeObj: null,
      sourcingSubStageType:null,
    };
    this.handleTabClick = this.handleTabClick.bind(this);
   }

  componentDidMount() {
    if (this.props.selectedStageType != null) {
      this.setState({
        attributeList: pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`],
        checkBoxList: pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"]['checkBoxList'],
        key:1
      })
    }
  }

  componentDidUpdate(prevProps) {
    if (this.props.selectedStageType != null && prevProps.selectedStageType != this.props.selectedStageType) {
      this.setState({
        attributeList: pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"][`attributeList`],
        checkBoxList: pagePropertyListConstant[this.props.selectedStageType + "_STAGE_LIST"]['checkBoxList'],
      })
    }
  }

  handleTabClick(index, label) {
    for (var i = 0; i < this.state.attributeList.length; i++) {
      if (this.state.attributeList[i].label == label) {
        this.props.setSelectedSubStageType(this.state.attributeList[i].stageType);
        break;
      }
    }
  }

  render() {
    return (
      <div >
        <Col md={12}>
        
          {this.state.attributeList != null && this.props.selectedStageType != null ?
            <Tabs onSelect={this.handleTabClick}>

              {this.state.attributeList.map((tempAttributeListObj, index) => (
                tempAttributeListObj.type == "TAB" ?
                  <Tab  name={tempAttributeListObj.name} key={index} label={tempAttributeListObj.label}></Tab>
                  :<a key={index}></a>))}
            </Tabs>
            : null}
        </Col>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    selectedStageType: state.pipeLine.selectedStageType,
    selectedSubStageType: state.pipeLine.selectedSubStageType
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedSubStageType: selectedSubStageType => dispatch(setSelectedSubStageType(selectedSubStageType)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PPLStageSubSection);


