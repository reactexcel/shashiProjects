export const INVENTORY_DETAILS_HEADER_TITLE = "Stock";
export const INVENTORY_DETAILS_SUBHEADER_TITLE = "Capturing general infrmation about Stock"
export const MANAGE_INVENTORY_HEADER_TITLE = "Stock";
export const MANAGE_STOCKADJUSTMENT_HEADER_TITLE = "Stock Adjustment";

export const ADDRESS_MANDATORY_MSG = "address is required.";
export const MODULE_NAME = "Stock";

export const STOCK_TRANSFER = "transferStock";
export const STOCK_ADJUSTMENT = "adjustmentStock";
export const STOCK_KIT = "kitStock";
export const CREATE_ACTION_MODE = "createMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";
export const VIEW_ACTION_MODE = "viewMode";
export const ACTIVE_STATUS = "Active";
export const INACTIVE_STATUS = "Inactive";
export const MENU_ACTION_MODE = "MENU";
export const TRANSFER_INVENTORY = "STOCK_TRANSFER";
export const ADJUSTMENT_INVENTORY = "STOCK_ADJUSTMENT";
export const UNIQUE_CODE_PREFIX = "STO-";
export const STOCK_TRANSFER_PAGE_URL = '/admin/create-stock-transfer';
export const STOCK_ADJUSTMENT_PAGE_URL = '/admin/create-stock-adjustment';
export const STOCK_KIT_PAGE_URL = '/admin/create-stock-kit';
export const MANAGE_INVENTORY_PAGE_URL = '/admin/manage-inventory';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_INVENTORY_LIST_URL = BASE_URL + '/inventory/v1';
export const GET_INVENTORY_SEARCH_URL = BASE_URL + '/inventory/v1/search';
export const GET_INVENTORY_DETAILS_URL = BASE_URL + '/inventory/v1/details';
export const GET_INVENTORY_COUNT_DASHBOARD_LIST_URL = BASE_URL + '/inventory/dashboard';
export const DOWNLOAD_XLS_FILE_URL = `${BASE_URL}/inventory/v1/downloadxls`;
export const SET_CREATE_INVENTORY_DETAILS_URL = BASE_URL + '';
export const SET_UPDATE_INVENTORY_DETAILS_URL = BASE_URL + '';
export const SET_UPDATE_INVENTORY_STATUS_URL = BASE_URL + '';
export const DOWNLOAD_XLXS_FILE = `${BASE_URL}/inventory/filepath`;

export const dataTable = [];
export const createdataTable = [
  { productName: "1", quantity: "1", price: "Main Store", value: "DIS-1" }
];
