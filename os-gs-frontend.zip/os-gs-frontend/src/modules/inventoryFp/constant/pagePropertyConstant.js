import React from "react";
import StatusUtil from '../../common/util/statusUtil';
import CommonUtil from '../../common/util/commonUtil';
import currencyIcon from '../../common/util/currencyIcon';

export const MANAGE_PRODUCT_INVENTORY_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product",
                id: "stockId",
                accessor: "stockId",
                style: {
                    flex: '0 0 25%',
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td label-black" style={{ borderLeft: StatusUtil.getStockLabel(original.stocktype) }} id={original.stockId + "_1" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.stockId, original.stocktype)}>
                            <span >{original.stockId ? original.stockId + " | " + original.productName : ''} </span>
                        </div>
                    )
                }
            },
            {
                Header: "Owner",
                id: "supplier",
                accessor: "supplier"
            },
            {
                Header: "In Stock",
                id: "stock",
                accessor: "stock",
                name: "stock",
                style: {
                    cursor: 'grab'
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let stockValue = CommonUtil.getFloatValue(original.stock, 2)
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.stockId, original.stocktype)}>
                            <span > {stockValue}  {original.uom}</span>
                        </div>
                    )
                }
            },
            {
                Header: "In ward",
                id: "orderstock",
                accessor: "orderstock",
                style: {
                    cursor: 'grab'
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let inwardValue = CommonUtil.getFloatValue(original.orderstock, 2)
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.stockId, original.stocktype)}>
                            <span >
                                {inwardValue}  {original.uom}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Out ward",
                id: "committedstock",
                accessor: "committedstock",
                style: {
                    cursor: 'grab'
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let outwardValue = CommonUtil.getFloatValue(original.committedstock, 2)
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.stockId, original.stocktype)}>
                            <span >
                                {outwardValue}  {original.uom}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Total Value",
                id: "totalValues",
                accessor: "totalValues",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    cell.column.Header = that.props.currencyCode ? ("Total Value" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")") : "Total Value";
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,original.totalValues)}
                        </>

                    )
                }
            },
            // {
            //     Header: "Action",
            //     id: "actions",
            //     accessor: "actions",
            //     className: "action justify-content-center",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     style: {
            //         flex: '0 0 50px'
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (

            //             <div className="actions-left">
            //                 <Nav pullRight>
            //                     <NavDropdown id={original.stockId + "_" + inventoryConstant.MENU_ACTION_MODE}
            //                         title={<i className="fa fa-ellipsis-v"
            //                             id={original.stockId + "_" + inventoryConstant.MENU_ACTION_MODE} />} noCaret>
            //                         {isAuthorized("newStockTransfer") &&
            //                             <MenuItem id={original.stockId + "_" + inventoryConstant.MENU_ACTION_MODE + "_" + inventoryConstant.STOCK_TRANSFER}
            //                                 onClick={(e) => that.getTdProps(e)}>Stock Transfer</MenuItem>}
            //                         <MenuItem id={original.stockId + "_" + inventoryConstant.MENU_ACTION_MODE + "_" + inventoryConstant.STOCK_ADJUSTMENT}
            //                             onClick={(e) => that.getTdProps(e)}>Stock Adjustment</MenuItem>
            //                     </NavDropdown>
            //                 </Nav>
            //             </div>

            //         )
            //     }
            // }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_LOT_INVENTORY_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Lot #",
                id: "lotNumber",
                accessor: "lotNumber",
            },
            {
                Header: "Pallet#",
                id: "paletteNumber",
                accessor: "paletteNumber"
            },
            {
                Header: "Product",
                id: "stockId",
                accessor: "stockId",
                style: {
                    flex: '0 0 20%',
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    let productId = original.pk.split('#')[2];
                    let productObj = CommonUtil.getFilteredObjFromArray(that.state.productList, 'productId', productId);
                    let productName = productObj && productObj.productName;
                    return (
                        <div id={productId + "_" + index + "_" + original.stocktype}>
                            <span >{productId ? productId + " | " + productName : ''} </span>
                        </div>
                    )
                }
            },
            {
                Header: "Catagory",
                id: "catagory",
                accessor: "catagory",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    let productId = original.pk && original.pk.split('#')[2];
                    let productObj = CommonUtil.getFilteredObjFromArray(that.state.productList, 'productId', productId);
                    let category = productObj ? productObj.category : null;
                    return (
                        <div id={productId + "_" + index + "_" + original.stocktype}>
                            <span >{category} </span>
                        </div>
                    )
                }
            },
            {
                Header: "Brand",
                id: "brand",
                accessor: "brand",
            },
            {
                Header: "Received Qty",
                id: "receivedstock",
                accessor: "receivedstock",
                name: "receivedstock",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let stockValue = CommonUtil.getFloatValue(original.receivedstock, 2)
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + original.stocktype}>
                            <span > {stockValue}  {original.uom}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Available Qty",
                id: "remainingstock",
                accessor: "remainingstock",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let availableQtyValue = CommonUtil.getFloatValue(original.remainingstock, 2)
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + original.stocktype}>
                            <span >
                                {availableQtyValue}  {original.uom}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Expiry Days",
                id: "expiryDays",
                accessor: "expiryDays",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let expiryDate = '2022-10-10';
                    let productId = original.pk && original.pk.split('#')[2];
                    const productObj = CommonUtil.getFilteredObjFromArray(that.state.productList,
                        'productId', productId);
                    if (CommonUtil.isNotNull(productObj)) {
                        expiryDate = CommonUtil.addDaysInDate(original.createddate, productObj.shelflife);
                    }
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + 'expiryDays'}>
                            <span >
                                {CommonUtil.getDifferenceInDate(expiryDate, new Date())}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Days in Stock",
                id: "stockDays",
                accessor: "stockDays",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let stockDate = original.createddate;
                    return (
                        <div className="full-td label-black" id={original.stockId + "_" + index + "_" + 'stockDays'}>
                            <span >
                                {CommonUtil.getDifferenceInDate(stockDate, new Date())}
                            </span>
                        </div>

                    )
                }
            },

        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};
export const DETAIL_MODAL_INSTOCK_TABLE_LIST = (that) => {
    return {
        tableData: [{
            createddate: '',
            lot: '',
            pallet: '',
            ordernumber: '',
            remainingstock: '',
            perUnitPrice: '',
            blockedstock: '',
            totalQty: '',
            totalValue: '',
            uti: '',
            expiryDays: '',
            fac_location: ''
        }],
        tableColumnList: [
            {
                Header: "Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                style: {
                    flex: "0 0 150px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        CommonUtil.getCurrentZoneFormatDate(value)
                    )
                },
            },
            {
                Header: "Lot#",
                id: "lotNumber",
                accessor: "lotNumber",
                name: "lotNumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Pallet#",
                id: "paletteNumber",
                accessor: "paletteNumber",
                name: "paletteNumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Inward",
                id: "ordernumber",
                accessor: "ordernumber",
                name: "ordernumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "On Hand Qty",
                id: "remainingstock",
                accessor: "remainingstock",
                name: "remainingstock",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let dispVal = CommonUtil.getFloatValue(original.remainingstock, true);
                    let remainingstockValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {remainingstockValue} {original.uom}
                        </span>
                    )
                }
            },
            {
                Header: "Price/Unit" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "perUnitPrice",
                accessor: "perUnitPrice",
                name: "perUnitPrice",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var dispVal = CommonUtil.getFloatValue(original.perUnitPrice);
                    let purchasePriceValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,purchasePriceValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "Total Qty",
                id: "totalQty",
                accessor: "totalQty",
                name: "totalQty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let remaining = CommonUtil.getFloatValue(original.remainingstock);
                    let blocked = CommonUtil.getFloatValue(original.blockedstock);
                    let total = remaining - blocked;
                    let totalQtyValue = CommonUtil.getFloatValue(total, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(total) }}>
                            {totalQtyValue} {original.uom}
                        </span>
                    )
                }
            },
            {
                Header: "Total Value" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "totalValue",
                accessor: "totalValue",
                name: "totalValue",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let tempPurchasePrice = CommonUtil.getFloatValue(original.perUnitPrice);
                    let received = CommonUtil.getFloatValue(original.remainingstock);
                    let dispVal = received * tempPurchasePrice;
                    let tempTotalValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,tempTotalValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{original.fac_location + " | " + original.fac_location_name} </span>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const DETAIL_MODAL_EXPECTED_TABLE_LIST = (that) => {
    return {
        tableData: [{
            ordernumber: '',
            qty: '',
            fac_location: '',
        }],
        tableColumnList: [
            {
                Header: "Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                style: {
                    flex: "0 0 150px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        CommonUtil.getCurrentZoneFormatDate(value)
                    )
                },
            },
            {
                Header: "Inward",
                id: "ordernumber",
                accessor: "ordernumber",
                name: "ordernumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Receiving Qty",
                id: "qty",
                accessor: "qty",
                name: "qty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let qtyValue = CommonUtil.getFloatValue(value, 2)
                    return (
                        <span >
                            {qtyValue} {original.uom}
                        </span>
                    )
                }
            },
            {
                Header: "Price/unit" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "perUnitPrice",
                accessor: "perUnitPrice",
                name: "perUnitPrice",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var dispVal = CommonUtil.getFloatValue(original.perUnitPrice);
                    let purchasePriceValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,purchasePriceValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "Total Value" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "totalValue",
                accessor: "totalValue",
                name: "totalValue",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let perUnitPrice = CommonUtil.getFloatValue(original.perUnitPrice);
                    let quantity = CommonUtil.getFloatValue(original.qty);
                    let dispVal = perUnitPrice * quantity;
                    let tempTotalValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,tempTotalValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "ETA",
                id: "eta",
                accessor: "eta",
                name: "eta",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{original.fac_location + " | " + original.fac_location_name} </span>
                    )
                }
            }
        ],

        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const DETAIL_MODAL_CONSUMPTION_TABLE_LIST = (that) => {
    return {
        tableData: [{
            ordernumber: '',
            qty: '',
            fac_location: '',
        }],
        tableColumnList: [
            {
                Header: "Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                style: {
                    flex: "0 0 150px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        CommonUtil.getCurrentZoneFormatDate(value)
                    )
                },
            },
            {
                Header: "Outward",
                id: "ordernumber",
                accessor: "ordernumber",
                name: "ordernumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Delivering Qty",
                id: "qty",
                accessor: "qty",
                name: "qty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let qtyValue = CommonUtil.getFloatValue(value, 2)
                    return (
                        <span >
                            {qtyValue} {original.uom}
                        </span>
                    )
                }
            },
            {
                Header: "Price/unit" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "perUnitPrice",
                accessor: "perUnitPrice",
                name: "perUnitPrice",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    var dispVal = CommonUtil.getFloatValue(original.perUnitPrice);
                    let purchasePriceValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,purchasePriceValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "Total Value" + ' ' + "("+currencyIcon.getCurrencyIcon(that.props.currencyCode)+")",
                id: "totalValue",
                accessor: "totalValue",
                name: "totalValue",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let perUnitPrice = CommonUtil.getFloatValue(original.perUnitPrice);
                    let quantity = CommonUtil.getFloatValue(original.qty);
                    let dispVal = perUnitPrice * quantity;
                    let tempTotalValue = CommonUtil.getFloatValue(dispVal, 2);
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode,tempTotalValue)} 
                        </span>
                    )
                }
            },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{original.fac_location + " | " + original.fac_location_name} </span>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const INVENTORY_MODAL_DETAIL_LIST = (that) => ({
    attributeObj: {
        stock: "",
        orderstock: "",
        committedstock: "",
        forecast: "",
        surplus: "",
        uom: "",
    },
    attributeList: [
        {
            name: "stock",
            type: "FIXED",
            label: "In Stock",
            required: false,
            inputType: "text",
            fieldWidth: 4,
            numberOfRow: 0,
        },
        {
            name: "orderstock",
            type: "FIXED",
            label: "Expected",
            required: false,
            inputType: "text",
            fieldWidth: 4,
            numberOfRow: 0,
        },
        {
            name: "committedstock",
            type: "FIXED",
            label: "Committed",
            required: false,
            inputType: "text",
            fieldWidth: 4,
            numberOfRow: 0,
        },

    ],
});
export const ADVANCE_SEARCH_LIST = (that) => {
    return {
        attributeObj: {
            orderNumber: '',
        },
        attributeList: [
            {
                name: "orderNumber",
                type: "TEXTBOX",
                label: "",
                inputType: "text",
                fieldWidth: 12,
                numberOfRow: 0,
                placeholder: "Search by Product/Ingredient",
            },
        ],
    }
};