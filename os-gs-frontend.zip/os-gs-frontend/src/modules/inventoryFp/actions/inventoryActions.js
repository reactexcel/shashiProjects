import axios from '../../../axios/axios';
import * as inventoryActionTypes from './inventoryActionTypes';
import * as inventoryConstant from '../constant/inventoryConstant';
import * as actionTypes from '../../../actions/actionTypes';
import { beginAjaxCall, endAjaxCall, setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: inventoryActionTypes.SET_INVENTORY_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setInventoryDetails(inventoryDetailsObj, actionMode) {
  if (actionMode === inventoryConstant.CREATE_ACTION_MODE || actionMode === inventoryConstant.CLONE_ACTION_MODE) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(inventoryConstant.SET_CREATE_INVENTORY_DETAILS_URL, inventoryDetailsObj, { headers }).then(response => {
        if (response.status == 201) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };
  }
  if (actionMode === inventoryConstant.EDIT_ACTION_MODE) {
    inventoryDetailsObj.actionType = "INVENTORY";
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(inventoryConstant.SET_UPDATE_INVENTORY_DETAILS_URL + inventoryDetailsObj.inventoryCode, inventoryDetailsObj, { headers }).then(response => {
        if (response.status == 200) {
          dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
        } else {
          dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      });
    };

  }
}

export function getInventoryList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(inventoryConstant.GET_INVENTORY_LIST_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: inventoryActionTypes.GET_INVENTORY_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}


export function getInventoryDetails(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(inventoryConstant.GET_INVENTORY_DETAILS_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: inventoryActionTypes.GET_INVENTORY_DETAILS,
          payload: response.data.Items
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getinventoryCount(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(inventoryConstant.GET_INVENTORY_COUNT_DASHBOARD_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: inventoryActionTypes.GET_INVENTORY_COUNT_DASHBOARD_LIST,
          payload: response.data.item,
        });
      }
      dispatch(endAjaxCall());
    })
      .catch((error) => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

export function downLoadXLSFile(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(inventoryConstant.DOWNLOAD_XLS_FILE_URL, { params: params }).then((response) => {
      if (response.status == 200 && response.data == "success") {
        getDownLoadFileURL();
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

function getDownLoadFileURL() {
  axios.get(inventoryConstant.DOWNLOAD_XLXS_FILE).then((response) => {
    if (response.status == 200 && response.data && response.data.Item && response.data.Item.filePath) {
      CommonUtil.buildLinkAndDownLoadFile(response.data.Item.filePath);
    } else {
      setTimeout(function () { getDownLoadFileURL(); }, 10000);
    }
  })
}

export function getInventorySearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(inventoryConstant.GET_INVENTORY_SEARCH_URL, { params: params }, { headers }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: inventoryActionTypes.GET_INVENTORY_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}