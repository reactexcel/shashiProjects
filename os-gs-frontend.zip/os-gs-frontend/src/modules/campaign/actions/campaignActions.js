import axios from '../../../axios/axios';
import * as campaignActionTypes from './campaignActionTypes';
import * as campaignConstant from '../constant/campaignConstant';
import * as actionTypes from '../../../actions/actionTypes';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';


export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: campaignActionTypes.SET_CAMPAIGN_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setCampaignDetails(campaignDetailsObj, actionMode) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(campaignConstant.SET_CREATE_CAMPAIGN_DETAILS_URL,
        campaignDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(campaignConstant.SET_UPDATE_CAMPAIGN_DETAILS_URL +
        campaignDetailsObj.campaignCode, campaignDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };

  }
}

export function setSelectedCampaignCode(selectedCampaignCode) {
  return function (dispatch) {
    dispatch({
      type: campaignActionTypes.SET_SELECTED_CAMPAIGN_CODE,
      payload: selectedCampaignCode
    });
  }
}

export function getCampaignList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_CAMPAIGN_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_CAMPAIGN_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getCampaignDetails(selectedCampaignCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_CAMPAIGN_DETAILS_URL + selectedCampaignCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_CAMPAIGN_DETAILS,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function updateCampaignStatus(campaignDetailsObj, campaignCode) {
  let params = { limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(campaignConstant.SET_UPDATE_CAMPAIGN_STATUS_URL + campaignCode,
      campaignDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(campaignConstant.GET_CAMPAIGN_LIST_URL, { params: params }).then(response => {
            if (response.status == 200) {
              dispatch(setAjaxCallStatus(updateApiResponse(response)));
              dispatch({
                type: campaignActionTypes.GET_CAMPAIGN_LIST,
                payload: response.data
              });
              dispatch(endAjaxCall());
            }
          });

        }
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  }

}

export function getCampaignSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_CAMPAIGN_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_CAMPAIGN_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function setCampaignCouponDetails(couponDetailsObj, actionMode) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(campaignConstant.SET_CREATE_COUPONS_DETAILS_URL,
        couponDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(campaignConstant.SET_UPDATE_COUPONS_DETAILS_URL +
        couponDetailsObj.couponCode, couponDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };

  }
}

export function getCampaignCouponList(selectedCampaignCode, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_COUPONS_DETAILS_URL + selectedCampaignCode, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_COUPON_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function setSelectedCouponCode(selectedCouponCode) {
  return function (dispatch) {
    dispatch({
      type: campaignActionTypes.SET_SELECTED_COUPON_CODE,
      payload: selectedCouponCode
    });
  }
}

export function getCouponDetails(selectedCouponCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_COUPON_DETAILS_URL + selectedCouponCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_COUPON_DETAILS,
          payload: response.data.Item
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function setCouponPulish(couponDetailsObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(campaignConstant.SET_COUPONS_PUBLISH_URL,
      couponDetailsObj).then(response => {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  };
}

export function getCouponSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(campaignConstant.GET_COUPON_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: campaignActionTypes.GET_COUPON_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function updateCouponStatus(couponDetailsObj, couponCode, selectedCampaignCode) {
  let params = { limit: 15, page: 1, pageIndex: 1 };
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(campaignConstant.SET_UPDATE_COUPON_STATUS_URL + couponCode,
      couponDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(campaignConstant.GET_COUPONS_DETAILS_URL + selectedCampaignCode, { params: params }).then(response => {
            if (response.status == 200) {
              dispatch(setAjaxCallStatus(updateApiResponse(response)));
              dispatch({
                type: campaignActionTypes.GET_COUPON_LIST,
                payload: response.data
              });
              dispatch(endAjaxCall());
            }
          }); 
        }
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
  }

}
