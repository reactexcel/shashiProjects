import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab, FormControl } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { setCampaignDetails, getCampaignDetails, setReducerInitMode, getCampaignCouponList, setSelectedCouponCode, getCouponSearchList, updateCouponStatus } from "../actions/campaignActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import * as campaignConstant from '../constant/campaignConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import _ from 'lodash'
import Table from '../../../views/Tables/PopularTable/Table/Table';
import LabelUtil from '../../common/util/labelUtil';
import DateUtil from "../../common/util/dateUtil";
import campaign from "assets/img/campaign-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import check from "assets/img/check.svg";
import PaginationUtil from '../../common/util/paginationUtil';
import AddCoupon from './AddCoupon';
import { setActionMode } from "../../../actions/appActions";
import isAuthorized from "auth-plugin";
import PublishModal from './PublishModal';
class CreateCampaign extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      searchInput: "",
      openCouponModal: false,
      openPublishModal: false,
      currentPage: 1,
    };

    this.handleSave = this.handleSave.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
  }

  componentDidMount = () => {
      mixpanel.track("Create Campaign loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getCampaignDetails(this.props.selectedCampaignCode);
      }
    }
    else {
      CommonUtil.handlePageRedirection(campaignConstant.MANAGE_CAMPAIGN_PAGE_URL, this);
    }

    this.setSelectedTableDetails();
    const commonAttributeList = pagePropertyListConstant.CREATE_CAMPAIGN_PAGE_LIST;
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  }


  setSelectedTableDetails = async () => {
    const managePageList = pagePropertyListConstant["MANAGE_COUPON_PAGE_LIST"](this);
    let additionalParams = [];
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      lastEvaluatedKeyArray: [],
      searchInput: "",
      limit: managePageList.tableConfig.defaultPageSize
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getCouponSearchList(tempParamas);
    } else {
      this.props.getCampaignCouponList(this.props.selectedCampaignCode, tempParamas);
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (prevProps.couponList != this.props.couponList && this.props.couponList != null) {
      this.updateCouponApiData(this.props.couponList);
      PaginationUtil.handlePagination(this.props.couponList, this);
    }
  
  }


  async updateApiData(attributeObj) {
   
    await this.setState({
      attributeObj: {
        ...attributeObj,
        campaignCode: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.campaignCode,
        campaignName: CommonUtil.isCloneMode(this.props.actionMode) ?
                    '' : attributeObj.campaignName
      }
    
    })
  }

  async updateCouponApiData(couponList) {
    let filteredData = couponList.Items.map((item) => {
      return item.discountType = this.getCouponType(item.discountType)
    })
    this.setState({ tableDataList: filteredData });
  }

  getCouponType = (type) => {
    let tempType = '';
    for (let i = 0; i < campaignConstant.discountType.length; i++) {
      if(campaignConstant.discountType[i].value == type) {
        tempType = campaignConstant.discountType[i].label;
      }
    }
    return tempType;
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleSave = async (event) => {
    this.setState({ submitted: true, alert: null });

    let tempObj = this.state.attributeObj;
    let actionMode = this.props.actionMode;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, actionMode);

    if (this.isValidRequestObj(tempObj)) {
      this.props.setCampaignDetails(tempObj, actionMode);
    }
  }

  isValidRequestObj = (tempObj) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      return false;
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      setTimeout(this.handlePopupContinue, 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      let errorMessage = this.props.ajaxCallStatus.data && this.props.ajaxCallStatus.data.response;
      if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "409") {
        this.handleDuplicateErrorPopup();
      }
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handleDuplicateErrorPopup = function () {
    let popupActionButton = {};
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, campaignConstant.DUPLICATE_ERROR);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    let params = this.state.attributeObj.status ? this.state.attributeObj.status : null;
    CommonUtil.handlePageRedirection(campaignConstant.MANAGE_CAMPAIGN_PAGE_URL, this, params);
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && tempId[1] == "publish") {
      this.handlePublish(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isDeleteMode(tempId[1])) {
      this.handleDeleteCompain(tempId[0]);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleDeleteCompain = (id) => {
    let popupActionButton = {};
    this.setState({ couponCode: id, status: "deleted" });
    popupActionButton.onConfirmClick = this.handleStatusAction;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, "Coupon");
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleStatusAction() {
    let tempObj = {};
    const { couponCode, status } = this.state;
    tempObj.status = status;
    tempObj.couponCode = couponCode;
    PaginationUtil.initPaginationParams(this);
    this.setState({ alert: null });
    this.props.updateCouponStatus(tempObj, couponCode, this.props.selectedCampaignCode);
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedCouponCode(tempId[0]);
    this.setState({mode : tempId[1]});
    this.handleAddCouponClick();
  }

  handlePublish = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedCouponCode(tempId[0]);
    this.handleAddPublishClick();
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == campaignConstant.CREATE_CAMPAIGN) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(campaignConstant.CREATE_CAMPAIGN_PAGE_URL, this);
    }
  }

  handleCreateCoupon = (event) => {
    this.setState({mode : commonConstant.CREATE_ACTION_MODE});
    this.handleAddCouponClick();
  } 

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.couponList.Items.filter(value => {
      return (
        value.couponCode.toLowerCase().includes(searchInput.toLowerCase()) 
        // value.couponType.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  advanceSearch = async () => {
    if(CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTableDetails(this.state.status);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  getCoupons = async () => {
    this.setState({ openCouponModal: false });
  }

  handleAddCouponClick = (event) => {
    this.setState({ openCouponModal: true});
  }

  getPublishDetails = async () => {
    this.setState({ openPublishModal: false });
  }

  handleAddPublishClick = (event) => {
    this.setState({ openPublishModal: true});
  }

  render() {
    const { attributeList, attributeObj, tableDataList, submitted, tableColumnList, tableConfig } = this.state;
    const actionMode = this.props.actionMode;

    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={campaign} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    campaignConstant.EDIT_CAMPAIGN_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      campaignConstant.VIEW_CAMPAIGN_HEADER_TITLE
                      : campaignConstant.CREATE_CAMPAIGN_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isCreateMode(actionMode) && <>
                    <div className="search-section advance">
                      <form onSubmit={this.handleSave}>
                        <i className="fa fa-search"></i>
                        <FormControl type="text" name="searchInput" placeholder="Search By Coupon Code/Type"
                          value={this.state.searchInput} onChange={this.handleChange} />
                      </form>
                    </div>
                    <div className="advance-filter">
                      <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? {cursor: 'default'} : null}>
                        <img src={check} onClick={this.advanceSearch} alt="submit" />
                      </div>
                    </div>
                  </>}
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        <Col md={12}>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "DROPDOWN" ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : null))
                            }
                          </Row>
                        </Col>
                      </Row>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
           <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      {!(CommonUtil.isCreateMode(actionMode) && tableColumnList != null) &&
                        <Row>
                          <Col md={12} className="resoure-management-title">Coupons</Col>
                          {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                            <div>
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                            </div>
                            : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                            { isAuthorized("adminSettings") &&
                              <div className="add-new-section">
                                <Col md={12}>
                                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                                    <div className="add-row-button" onClick={(e) => this.handleCreateCoupon(e)}>
                                      <i className=" fa fa-plus" />
                                      Add Row
                                    </div>
                                    : null}
                                </Col>
                              </div>
                            }
                            {this.state.openCouponModal == true ?
                              <AddCoupon 
                                campaignCode={this.props.selectedCampaignCode}
                                getCoupons={this.getCoupons}
                                actionMode={this.state.mode} 
                                selectedCouponCode={this.props.selectedCouponCode} 
                                productList={this.props.productList} >
                              </AddCoupon>
                              : null}
                            {this.state.openPublishModal == true ?
                              <PublishModal 
                                campaignCode={this.props.selectedCampaignCode}
                                getPublishDetails={this.getPublishDetails} 
                                selectedCouponCode={this.props.selectedCouponCode} >
                              </PublishModal>
                              : null}
                        </Row>}
                    </div>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.campaign.campaignDetails,
    selectedCampaignCode: state.campaign.selectedCampaignCode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    couponList: state.campaign.couponList,
    selectedCouponCode: state.campaign.selectedCouponCode,
    couponSearchList: state.campaign.campaignList,
  };
}

const mapDispatchToProps = dispatch => ({
  setCampaignDetails: (campaignDetailsObj, actionMode) => dispatch(setCampaignDetails(campaignDetailsObj, actionMode)),
  getCampaignDetails: selectedCampaignCode => dispatch(getCampaignDetails(selectedCampaignCode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getCampaignCouponList: params => dispatch(getCampaignCouponList(params)),
  setSelectedCouponCode: selectedCouponCode => dispatch(setSelectedCouponCode(selectedCouponCode)),
  getCouponSearchList: params => dispatch(getCouponSearchList(params)),
  updateCouponStatus: (couponDetails, couponCode, selectedCampaignCode) => dispatch(updateCouponStatus(couponDetails, couponCode, selectedCampaignCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateCampaign);
