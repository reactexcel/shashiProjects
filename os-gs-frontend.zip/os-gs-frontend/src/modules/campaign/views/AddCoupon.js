import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import { Redirect } from "react-router-dom";
import ValidationUtil from '../../common/util/validationUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import DateUtil from '../../common/util/dateUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import CheckBoxUtil from '../../common/util/checkBoxUtil';
import * as campaignConstant from '../constant/campaignConstant';
import { setCampaignCouponDetails } from "../actions/campaignActions";
import { getCouponDetails } from "../actions/campaignActions";
import { getProductList } from '../../productManagement/actions/productActions';
var Modal = require('react-bootstrap-modal')

class AddCoupon extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      secondattributeList: null,
      secondattributeObj: null,
      submitted: false,
      alert: null,
      params: null,
      selectedTab: "GENERAL",
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getCouponDetails(this.props.selectedCouponCode);
      }
    }
    this.setState({ openModal: true });
    const commonAttributeList = pagePropertyListConstant.CREATE_COUPON_PAGE_LIST;
    this.setSelectedTabDetails(this.state.selectedTab);
    this.props.getProductList();
    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  setSelectedTabDetails = async (selectedTab) => {
    const commonAttributeList = pagePropertyListConstant["CREATE_COUPON_" + selectedTab + "_PAGE_LIST"];
    await this.setState({
      selectedTab: selectedTab,
      secondattributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      secondattributeObj: commonAttributeList.attributeObj,
    })
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
      }
    })
  }

  updateProductDropDownList = async () => {
    const commonAttributeList = pagePropertyListConstant["CREATE_COUPON_USAGERESTRICTION_PAGE_LIST"];
    const secondattributeList = CommonUtil.getDropDownOptionsFromDictionary(commonAttributeList.attributeList, this.props.dataDictionaryList);
    let products = this.props.productList;
    let tempProductList = CommonUtil.getOptionsFromList(products, 'productId', 'productName', null, true);
    var newlist = secondattributeList.map((item) => {
      if (item.name === "products" || item.name === 'excludeproducts') {
        item.options=[...tempProductList]
      }
      return item;
    });
  }

  closeModal = (event) => {
    this.props.getCoupons(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    const { attributeObj, attributeList } = this.state;
    this.setState({ submitted: true });
    let products = [], excludeproducts= [], categories = [], excludeCategories = [];
    let tempObj = attributeObj;
    let { actionMode } = this.props;

    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,this.state.attributeList, actionMode);
    tempObj.campaignCode = this.props.campaignCode;

    if (this.isValidRequestObj(tempObj, attributeList)) {
      this.props.setCampaignCouponDetails(tempObj, actionMode);
      this.props.getCoupons();
      this.setState({ openModal: false });
    }
  }

  isValidRequestObj = (tempObj, attributeList) => {
    if (!ValidationUtil.validateCreateRequestObj(tempObj, attributeList)) {
      return false;
    }
    return true;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getCouponDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }


  handleTabClick = (label, event) => {
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  render() {
    const { attributeList, attributeObj, submitted, secondattributeList, secondattributeObj } = this.state;
    const { actionMode } = this.props;
    const COUPON_PAGE_TAB_LIST = campaignConstant.COUPON_PAGE_TAB_LIST
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Add Coupons</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="coupon-section">
                            <Row>
                              {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                                tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : tempAttributeListObj.type == "CHECKBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                      CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                      : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                        DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                        : null))
                              }
                            </Row>
                            <Tabs id="add-coupon-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                              {COUPON_PAGE_TAB_LIST.map((tempTabObj, index) => (
                                <Tab eventKey={tempTabObj.key} title={tempTabObj.title} key={index}>
                                  <Row style={{ marginTop: '20px' }}>
                                    {secondattributeList != null && secondattributeList.map((tempAttributeListObj, index) => (
                                      tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                        DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                        : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                          TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                          : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                            DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                            : tempAttributeListObj.type == "CHECKBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                              CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                              : null))
                                    }
                                  </Row>
                                </Tab>
                              ))}
                            </Tabs>
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.campaign.couponDetails,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    productList: state.product.productList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setCampaignCouponDetails: (couponDetailsObj, actionMode) => dispatch(setCampaignCouponDetails(couponDetailsObj, actionMode)),
  getCouponDetails: selectedCouponCode => dispatch(getCouponDetails(selectedCouponCode)),
  getProductList: (params) => dispatch(getProductList(params)),
});
export default connect(mapStateToProps, mapDispatchToProps)(AddCoupon);
