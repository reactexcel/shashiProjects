import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { getWoocomAccessToken } from "../../integrations/actions/integrationActions";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import { Redirect } from "react-router-dom";
import CustomCheckbox from '../../../components/CustomCheckbox/CustomCheckbox';
import Datetime from "react-datetime";
import { setCouponPulish } from "../actions/campaignActions";
const Modal = require('react-bootstrap-modal')

class PublishModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      params: null,
      isWoocomConnected: false,
      immediately: false,
      pulishDate: null,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    const { attributeObj } = this.props;
    this.props.getWoocomAccessToken();
    this.setState({ openModal: true });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.woocomToken != null && prevProps.woocomToken != this.props.woocomToken) {
      if (this.props.woocomToken && this.props.woocomToken.shop != null) {
        this.setState({ isWoocomConnected: true });
      }
    }
  }

  closeModal = (event) => {
    this.props.getPublishDetails(null);
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    if (this.props.woocomToken && this.props.woocomToken.shop != null) {
      this.setState({ isWoocomConnected: true });
    } else {
      this.setState({ isWoocomConnected: false });
      return false;
    }
    this.setState({ submitted: true });
    let tempObj = {};
    tempObj.immediately = this.state.immediately;
    tempObj.pulishDate = this.state.pulishDate;
    tempObj.couponCode = this.props.selectedCouponCode;
    tempObj.status = "publish";
    tempObj.pulishTime = this.state.pulishTime;
    this.props.setCouponPulish(tempObj);
    this.props.getPublishDetails(tempObj);
    this.setState({ openModal: false, submitted: true });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getPublishDetails(null);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }


  handleTabClick = (label, event) => {
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  handleDateChange = async (event) => {
    await this.setState({
      pulishDate: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : ''
    })
  };

  render() {
    const { isWoocomConnected } = this.state;
    const { woocomToken } = this.props;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aaria-labelledby="ModalHeader" backdrop="static" keyboard={false} className="coupon-publish">
          <Modal.Header closeButton>
            <Modal.Title>
              <div>
                <div className="model-heading">Publish</div>
              </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="coupon-section">
                            <Row>
                              <Col md={12}>
                                <i class="fa fa-map-pin" /> Status: <span style={{ fontWeight: 600 }}>Draft</span>
                              </Col>
                              <Col md={12}>
                                <Row>
                                  <Col md={3} style={{ marginTop: '10px' }}><i className="fa fa-calendar" /> Publish at :</Col>
                                  <Col md={9}>
                                    <CustomCheckbox inline number="immediately" checked={this.state.immediately} label="Immediately" onChange={() => this.setState({ immediately: !this.state.immediately })} />
                                    <Row>
                                      <Col md={6}>
                                        <Datetime
                                          id="pulishDate"
                                          timeFormat={false}
                                          closeOnSelect={true}
                                          isValidDate={CommonUtil.disablePastDt()}
                                          inputProps={{
                                            readOnly: true,
                                            placeholder: 'Date',
                                            disabled: this.state.immediately ? true : false,
                                            title: CommonUtil.getFormattedDate(this.state.pulishDate)
                                          }}
                                          name="pulishDate"
                                          onChange={(moment) => this.handleDateChange(moment)}
                                          value={CommonUtil.getFormattedDate(this.state.pulishDate)}
                                        />
                                      </Col>
                                      <Col md={6}>
                                        <Datetime
                                          dateFormat={false}
                                          id="pulishTime"
                                          name="pulishTime"
                                          inputProps={{
                                            readOnly: true,
                                            placeholder: 'Time',
                                            disabled: this.state.immediately ? true : false,
                                          }}
                                          onChange={(value) => this.setState({ pulishTime: value.format('h:mm a') })}
                                        />
                                      </Col>
                                    </Row>
                                  </Col>
                                </Row>
                              </Col>
                              <Col md={12}>
                                {!isWoocomConnected ?
                                  <small className="text-danger">
                                    Please do integration with Woocommerce first before publishing Coupon!
                              </small>
                                  : null}
                              </Col>
                            </Row>
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Schedule</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    woocomToken: state.integration.woocomToken,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getWoocomAccessToken: (params) => dispatch(getWoocomAccessToken(params)),
  setCouponPulish: (couponDetailsObj) => dispatch(setCouponPulish(couponDetailsObj)),
});
export default connect(mapStateToProps, mapDispatchToProps)(PublishModal);
