import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Tab, Tabs } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as campaignConstant from '../constant/campaignConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { setSelectedCampaignCode, getCampaignList, updateCampaignStatus, getCampaignSearchList } from "../actions/campaignActions";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopupUtil from '../../common/util/popupUtil';
import PaginationUtil from '../../common/util/paginationUtil';
import * as commonConstant from '../../common/constant/commonConstant';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import * as statusConstant from '../../common/constant/statusConstant';
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import StatusUtil from '../../common/util/statusUtil';
import campaign from "assets/img/campaign-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import check from "assets/img/check.svg";

class ManageCampaign extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      campaignCode: null,
      status: null,
      search: null,
      statusfilter: false,
      defaultSelectedTab: "OPEN",
      selectedTab: "OPEN",

      additionalParams: {},
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Campaign loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    const { selectedTab } = this.state;
    if (params == "COMPLETED") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("COMPLETED");
      const { location, history } = this.props;
      history.replace();
    } else {
      await this.setSelectedTabDetails(selectedTab);
    }
  }

  setSelectedTabDetails = async (selectedTab) => {
    const { location, history } = this.props;
    let additionalParams = { status: selectedTab.toLowerCase() };
    // let additionalParams = {};
    const managePageList = pagePropertyListConstant.MANAGE_CAMPAIGN_PAGE_LIST(this);
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      lastEvaluatedKeyArray: [],
      selectedTab: selectedTab,
      searchInput: "",
      limit: managePageList.tableConfig.defaultPageSize
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this), selectedTab);
  };

  componentDidUpdate(prevProps) {
    if (prevProps.campaignList != this.props.campaignList && this.props.campaignList != null) {
      PaginationUtil.handlePagination(this.props.campaignList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse(this.props.ajaxCallStatus.data);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.campaignList.Items.filter(value => {
      return (
        value.campaignCode.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.campaignName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedCampaignCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(campaignConstant.CREATE_CAMPAIGN_PAGE_URL, this);
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == campaignConstant.CREATE_CAMPAIGN) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(campaignConstant.CREATE_CAMPAIGN_PAGE_URL, this);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handlePopupContinue() {
    this.setState({ alert: null });
  }

  handleTabClick = (label, event) => {
    PaginationUtil.initPaginationParams(this);
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  handleStatusAction() {
    let tempObj = {};
    const { campaignCode, status } = this.state;
    tempObj.status = status;
    tempObj.campaignCode = campaignCode;
    PaginationUtil.initPaginationParams(this);
    this.setState({ alert: null });
    this.props.updateCampaignStatus(tempObj, campaignCode);
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getCampaignSearchList(tempParamas);
    } else {
      this.props.getCampaignList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isDeleteMode(tempId[1])) {
      this.handleDeleteCompain(tempId[0]);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleDeleteCompain = (id) => {
    let popupActionButton = {};
    this.setState({ campaignCode: id, status: "deleted" });
    popupActionButton.onConfirmClick = this.handleStatusAction;
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, campaignConstant.MODULE_NAME);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleAjaxResponse(response) {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      if (this.state.activate == true) {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      } else {
        this.props.handleClick(CommonUtil.prepareDeactivateSuccessPopUpConfig());
      }
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      const message = response.data && response.data.message ? response.data.message : campaignConstant.DELETE_ERROR;
      let messageDetails = '';
      var popupActionButton = {};
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeactivateFailedPopUpConfig(popupActionButton, message, messageDetails);
      this.setState({ alert: PopupUtil.deletePopup(popupConfig) });
    }
  }

  handleDeleteErrorPopup = function () {
    let popupActionButton = {};
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, campaignConstant.DELETE_ERROR);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleRemoveFilter = async (event) => {
    let id = event != undefined ? event.target.id : null;
    let tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, searchInput: "" });
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, search, status, statusfilter } = this.state;
    const MANAGE_PAGE_TAB_LIST = campaignConstant.MANAGE_PAGE_TAB_LIST
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={campaign} alt="" className="page-icon" />
                  {campaignConstant.MANAGE_CAMPAIGN_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search By Campaign Code/Name"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {isAuthorized("adminSettings") &&
                    <Button id={"campaignCode" + "_" + commonConstant.MENU_ACTION_MODE + "_" + campaignConstant.CREATE_CAMPAIGN}
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                      Create
                    </Button>
                  }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {statusfilter || search ?
                      <div className="showfilter">
                        Search / Filter by:
                        {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                        {statusfilter ?
                          <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <Tabs id="manage-purchase-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-tabs">
                      {MANAGE_PAGE_TAB_LIST.map((tempTabObj, index) => (
                        <Tab eventKey={tempTabObj.key} title={tempTabObj.title} key={index}>
                          {tableColumnList != null ? (
                            <Row>
                              {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                                <Table
                                  columns={tableColumnList}
                                  data={tableDataList}
                                  config={tableConfig}
                                  getRowProps={this.getTdProps}
                                  that={this}
                                  banner={"campaign"}
                                />
                              ) : (
                                <Col md={12}>
                                  <div className="no-record">No Record Found</div>
                                </Col>
                              )}
                            </Row>
                          ) : (
                            <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>
                          )}
                        </Tab>
                      ))}
                    </Tabs>
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    campaignList: state.campaign.campaignList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    campaignSearchList: state.campaign.campaignList,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedCampaignCode: selectedCampaignCode => dispatch(setSelectedCampaignCode(selectedCampaignCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getCampaignList: params => dispatch(getCampaignList(params)),
  updateCampaignStatus: (campaignDetails, campaignCode) => dispatch(updateCampaignStatus(campaignDetails, campaignCode)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getCampaignSearchList: params => dispatch(getCampaignSearchList(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageCampaign);
