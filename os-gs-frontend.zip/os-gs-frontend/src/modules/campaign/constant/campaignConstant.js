import * as commonConstant from '../../common/constant/commonConstant';
export const CREATE_CAMPAIGN_HEADER_TITLE = "Create Campaign";
export const EDIT_CAMPAIGN_HEADER_TITLE = "Edit Campaign";
export const VIEW_CAMPAIGN_HEADER_TITLE = "View Campaign";
export const MANAGE_CAMPAIGN_HEADER_TITLE = "Campaign";
export const LOCATION_HEADER_TITLE = "Location";
export const LOCATION_CHECKBOX_TITLE = "Set as default";
export const DOCUMENT_HEADER_TITLE = "Document";

export const PRODUCT_TABLE_NAME = "PRODUCT";
export const INGREDIENT_TABLE_NAME = "INGREDIENTS";
export const ADDRESS_MANDATORY_MSG = "Address is required.";
export const MODULE_NAME = "Campaign";
export const CREATE_CAMPAIGN = "createCampaign";

export const DEATIVATE_CAMPAIGN = "deActivateCampaign";
export const ACTIVATE_CAMPAIGN = "activateCampaign";
export const CREATE_CAMPAIGN_PAGE_URL = '/admin/create-campaign';
export const MANAGE_CAMPAIGN_PAGE_URL = '/admin/manage-campaign';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_CAMPAIGN_LIST_URL = `${BASE_URL}/campaigns`;

export const GET_CAMPAIGN_DETAILS_URL = `${BASE_URL}/campaigns/`;
export const SET_CREATE_CAMPAIGN_DETAILS_URL = `${BASE_URL}/campaigns/`;
export const SET_UPDATE_CAMPAIGN_DETAILS_URL = `${BASE_URL}/campaigns/`;
export const SET_UPDATE_CAMPAIGN_STATUS_URL = `${BASE_URL}/campaigns/`;
export const GET_CAMPAIGN_SEARCH_URL = BASE_URL + '/campaigns/search';
export const SET_CREATE_COUPONS_DETAILS_URL = `${BASE_URL}/coupons/`;
export const SET_UPDATE_COUPONS_DETAILS_URL = `${BASE_URL}/coupons/`;
export const GET_COUPONS_DETAILS_URL = `${BASE_URL}/campaigns/coupons/`;
export const GET_COUPON_DETAILS_URL = `${BASE_URL}/coupons/`;
export const SET_COUPONS_PUBLISH_URL = `${BASE_URL}/coupons/publish`;
export const GET_COUPON_SEARCH_URL = BASE_URL + '/campaigns/coupons/search';
export const SET_UPDATE_COUPON_STATUS_URL = `${BASE_URL}/coupons/`;
export const DUPLICATE_ERROR = "Coupon Code can not be duplicated.";
export const DELETE_ERROR = "Campaign cannot deleted because it contain one or more coupon in published state.";

export const MANAGE_PAGE_TAB_LIST = [
    {
        key: "OPEN",
        title: "OPEN"
    },
    {
        key: "COMPLETED",
        title: "COMPLETED"
    },
];
export const COUPON_PAGE_TAB_LIST = [
    {
        key: "GENERAL",
        title: "GENERAL"
    },
    {
        key: "USAGERESTRICTION",
        title: "USAGE RESTRICTION"
    },
    {
        key: "USAGELIMIT",
        title: "USAGE LIMIT"
    }
];
export const discountType = [
    { value: 'percent', label: 'Percentage Discount' },
    { value: 'fixed_cart', label: 'Fixed Cart Discount' },
    { value: 'fixed_product', label: 'Fixed Product Discount' },
]