import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import SuggestionUtil from '../../common/util/suggestionUtil';
import { FormControl, InputGroup, Nav, NavDropdown, MenuItem } from "react-bootstrap";
import isAuthorized from "auth-plugin";
import CommonUtil from '../../common/util/commonUtil';
import Select from "react-select";
import * as campaignConstant from './campaignConstant';
import currencyIcon from '../../common/util/currencyIcon';
import publish from "assets/img/publish.svg";

export const CREATE_CAMPAIGN_PAGE_LIST = {
    attributeObj: {
        campaignCode: '',
        campaignName: '',
        description: '',
        objective: '',
        startDate: CommonUtil.getTodaysDate(),
        endDate: CommonUtil.getTodaysDate(),
    },
    attributeList: [
        // {
        //     name: "campaignCode",
        //     type: "UNIQUE_CODE",
        //     label: "Campaign Code",
        //     prefix: "CAM",
        //     required: false,
        //     fieldWidth: 3,
        //     inputType: "text",
        //     numberOfRow: 0,
        //     createModeRemoveFlag: true,
        //     cloneModeRemoveFlag: true,
        //     createModeShowFlag: true,
        //     cloneModeShowFlag: true,
        //     editModeShowFlag: true,
        //     viewModeShowFlag: true,
        //     createMode: 'disabled',
        //     cloneMode: 'disabled',
        //     editMode: 'disabled',
        //     viewMode: 'disabled',
        //     mandatoryMsgText: "Field can not be empty.",
        // },
        {
            name: "campaignName",
            type: "TEXTBOX",
            label: "Name",
            required: true,
            fieldWidth: 3,
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 100,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "startDate",
            type: "DATE",
            label: "Start Date",
            required: true,
            fieldWidth: 3,
            inputType: "date",
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            backDateNotAllowed: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "endDate",
            type: "DATE",
            label: "End Date",
            required: true,
            fieldWidth: 3,
            inputType: "date",
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            backDateNotAllowed: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "description",
            type: "TEXTBOX",
            label: "Description",
            required: true,
            fieldWidth: 6,
            numberOfRow: 3,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 200,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "objective",
            type: "TEXTBOX",
            label: "Objective",
            required: false,
            fieldWidth: 6,
            numberOfRow: 3,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 200,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "version",
            type: "TEMP",
            createModeShowFlag: false,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "campaignCode",
            type: "TEMP",
            createModeShowFlag: false,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
    ],
};

export const MANAGE_CAMPAIGN_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Campaign Code",
                id: "campaignCode",
                accessor: "campaignCode",
            },
            {
                Header: "Campaign Name",
                id: "campaignName",
                accessor: "campaignName"
            },
            {
                Header: "Campaign Description",
                id: "campaignDescription",
                accessor: "campaignDescription"
            },
            {
                Header: "Start Date",
                id: "startDate",
                accessor: "startDate"
            },
            {
                Header: "End Date",
                id: "endDate",
                accessor: "endDate"
            },
            {
                Header: "No of Coupons",
                id: "coupons",
                accessor: "coupons"
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                style: {
                    flex: '0 0 60px'
                },
                className: "action",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (

                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                <div className="circle"><i title="edit"
                                    id={original.campaignCode + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index}
                                    className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />
                                </div>
                                <div className="circle"><i title="delete" 
                                    id={original.campaignCode + "_" + commonConstant.DELETE_ACTION_MODE + '_' + index} 
                                    className="fa fa-trash" onClick={(e) => that.getTdProps(e)} />
                                </div>
                            </Button>
                        </div>

                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_COUPON_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Code",
                id: "couponCode",
                accessor: "couponCode",
            },
            {
                Header: "Coupon Type",
                id: "discountType",
                accessor: "discountType"
            },
            {
                Header: "Coupon Amount",
                id: "couponAmount",
                accessor: "couponAmount",
                disableSortBy: true,
            },
            {
                Header: "Description",
                id: "description",
                accessor: "description",
                disableSortBy: true,
            },
            {
                Header: "Limit",
                id: "limitPerCoupon",
                accessor: "limitPerCoupon",
                disableSortBy: true,
            },
            {
                Header: "Expiry Date",
                id: "expiryDate",
                accessor: "expiryDate",
                disableSortBy: true,
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                disableSortBy: true,
                style: {
                    flex: '0 0 110px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            {StatusUtil.getStatusLabel(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                style: {
                    flex: '0 0 90px'
                },
                className: "action",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                { isAuthorized("adminSettings") ?
                                    <div className="circle"><i title="edit"
                                        id={original.couponCode + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index}
                                        className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />
                                    </div>
                                : null }
                                { isAuthorized("adminSettings") && original.status == 'draft' ?
                                    <div className="circle"><i title="delete" 
                                        id={original.couponCode + "_" + commonConstant.DELETE_ACTION_MODE + '_' + index} 
                                        className="fa fa-trash" onClick={(e) => that.getTdProps(e)} />
                                    </div> 
                                : null }
                                { isAuthorized("adminSettings") && original.status == 'draft' ?
                                    <div className="circle"><img title="publish" id={original.couponCode + "_" + "publish" + '_' + index} src={publish} alt="publish" onClick={(e) => that.getTdProps(e)} />
                                    </div> 
                                : null }
                            </Button>
                        </div>

                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const CREATE_COUPON_PAGE_LIST = {
    attributeObj: {
        couponCode: '',
        description: '',
        discountType: '',
        couponAmount: '',
        expiryDate: '',
        minSpend: '',
        maxSpend: '',
        individualUse: false,
        excludeSale: false,
        products: [],
        excludeproducts: [],
        categories: [],
        excludeCategories: [],
        limitPerCoupon: '',
        limitToItems: '',
        limitPerUser: '',
    },
    attributeList: [
        {
            name: "couponCode",
            type: "TEXTBOX",
            label: "Coupon Code",
            required: true,
            fieldWidth: 6,
            textType: "fixed",
            numberOfRow: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'disabled',
            viewMode: 'disabled',
            maxLength: 65,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "description",
            type: "TEXTBOX",
            label: "Description",
            required: false,
            fieldWidth: 6,
            numberOfRow: 3,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 200,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "discountType",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "couponAmount",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "expiryDate",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "minSpend",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "maxSpend",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "individualUse",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "excludeSale",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "products",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "excludeproducts",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "categories",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "excludeCategories",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "limitPerCoupon",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "limitToItems",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "limitPerUser",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "version",
            type: "TEMP",
            createModeShowFlag: false,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        
    ]
};

export const CREATE_COUPON_GENERAL_PAGE_LIST = {
    attributeList: [
        {
            name: "discountType",
            type: "DROPDOWN",
            label: "Discount Type",
            required: false,
            fieldWidth: 4,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: "Select",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            options: campaignConstant.discountType
        },
        {
            name: "couponAmount",
            type: "TEXTBOX",
            label: "Coupon Amount",
            required: false,
            fieldWidth: 4,
            numberOfRow: 0,
            inputType: "number",
            minValue: 0,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 10,
            minLength: 1,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "expiryDate",
            type: "DATE",
            label: "Expiry Date",
            required: false,
            fieldWidth: 4,
            inputType: "date",
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            backDateNotAllowed: true,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "",
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
    ]
};

export const CREATE_COUPON_USAGERESTRICTION_PAGE_LIST = {
    attributeList: [
        {
            name: "minSpend",
            type: "TEXTBOX",
            label: "Minimum Spend",
            required: false,
            fieldWidth: 6,
            inputType: "number",
            numberOfRow: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 6,
            minLength: 1,
            placeholder: "No minimum",
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "maxSpend",
            type: "TEXTBOX",
            label: "Maximum Spend",
            required: false,
            fieldWidth: 6,
            inputType: "number",
            numberOfRow: 0,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            maxLength: 6,
            minLength: 1,
            placeholder: "No maximum",
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "individualUse",
            type: "CHECKBOX",
            label: "Individual Use Only",
            required: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            fieldWidth: 6,
            extraMsg: "Tick the box if you don’t want this coupon to be used in combination with other coupons."
        },
        {
            name: "excludeSale",
            type: "CHECKBOX",
            label: "Exclude Sale Items",
            required: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            fieldWidth: 6,
            extraMsg: "Tick the box if you don’t want this coupon to apply to products on sale. Per-cart coupons do not work if a sale item is added afterward."
        },
        {
            name: "products",
            type: "DROPDOWN",
            label: "Products",
            required: false,
            fieldWidth: 6,
            isMulti: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            closeMenuOnSelect: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "Search for a product",
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "excludeproducts",
            type: "DROPDOWN",
            label: "Exclude Products",
            required: false,
            fieldWidth: 6,
            isMulti: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            closeMenuOnSelect: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "Search for a product",
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "categories",
            type: "DROPDOWN",
            label: "Products Categories",
            required: false,
            fieldWidth: 6,
            isMulti: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            closeMenuOnSelect: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "Any Category",
            mandatoryMsgText: "Field can not be empty.",
            dataDictionaryFlag: true,
            dataDictionaryId: 'categoryList',
        },
        {
            name: "excludeCategories",
            type: "DROPDOWN",
            label: "Exclude Categories",
            required: false,
            fieldWidth: 6,
            isMulti: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            closeMenuOnSelect: false,
            createMode: "enable",
            cloneMode: "enable",
            editMode: "enable",
            viewMode: "disabled",
            placeholder: "No categories",
            mandatoryMsgText: "Field can not be empty.",
            dataDictionaryFlag: true,
            dataDictionaryId: 'categoryList',
        },
    ]
};

export const CREATE_COUPON_USAGELIMIT_PAGE_LIST = {
    attributeList: [
        {
            name: "limitPerCoupon",
            type: "TEXTBOX",
            label: "Usage Limit Per Coupon",
            inputType: 'number',
            required: false,
            showCurrency: false,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            maxLength: 4,
            minLength: 1,
            placeholder: "Unlimited usage",
        },
        {
            name: "limitToItems",
            type: "TEXTBOX",
            label: "Limit Usage to X Items ",
            inputType: 'number',
            required: false,
            showCurrency: false,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            maxLength: 4,
            minLength: 1,
            placeholder: "Apply to all qualifying items in cart",
        },
        {
            name: "limitPerUser",
            type: "TEXTBOX",
            label: "Usage Limit Per User",
            inputType: 'number',
            required: false,
            showCurrency: false,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
            maxLength: 4,
            minLength: 1,
            placeholder: "Unlimited usage",
        },
    ]
};

