import axios from '../../../axios/axios';
import * as demandPlanningActionTypes from './demandPlanningActionTypes';
import * as demandPlanningConstant from '../constant/demandPlanningConstant';
import * as actionTypes from '../../../actions/actionTypes';
import { beginAjaxCall, endAjaxCall, setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import PaginationUtil from '../../common/util/paginationUtil';

let headers = {
  "Access-Control-Allow-Origin": "*",
  methods: "GET,PUT,POST,DELETE"
};

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: demandPlanningActionTypes.SET_DEMANDPLANNING_REDUCER_INIT_MODE,
      payload: null
    });
  }
}




