export const MANAGE_DEMANDPLANNING_HEADER_TITLE = "Demand Planning";

export const MODULE_NAME = "Demand Planning";

export const CREATE_ACTION_MODE = "createMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";
export const VIEW_ACTION_MODE = "viewMode";
export const ACTIVE_STATUS = "Active";
export const INACTIVE_STATUS = "Inactive";
export const MENU_ACTION_MODE = "MENU";

export const BASE_URL =  process.env.REACT_APP_API_BASE_URL;
export const GET_AUTOMATION_LIST_URL = BASE_URL + '';
export const GET_AUTOMATION_DETAILS_URL = BASE_URL + '';
export const MANAGE_AUTOMATION_URL = '/admin/demandplanning';

export const dataTable = [];
export const createdataTable = [
  { stockId: "test", productName: "test", supplier: "test", leadTime: "test", moq: "test", min: "test", max: "test", sft: "test", reorder: "test", rule: "test" },
  { stockId: "test1", productName: "test1", supplier: "test1", leadTime: "test1", moq: "test1", min: "test1", max: "test1", sft: "test1", reorder: "test1", rule: "test1" }
];
export const createPopupdataTable = [
  { type: "test", createdBy: "test", createdon: "test", Status: "test"},
  { type: "test1", createdBy: "test1", createdon: "test1", Status: "test1"}
];
