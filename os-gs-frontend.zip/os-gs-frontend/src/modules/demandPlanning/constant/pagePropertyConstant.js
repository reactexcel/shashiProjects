import * as demandPlanningConstant from './demandPlanningConstant';
import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import StatusUtil from '../../common/util/statusUtil';
import CommonUtil from '../../common/util/commonUtil';
import Switch from "react-bootstrap-switch";
import Button from "components/CustomButton/CustomButton.jsx";
import { FormControl, InputGroup } from "react-bootstrap";

export const MANAGE_DEMANDPLANNING_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
            },
            {
                Header: "In Stock",
                id: "inStock",
                accessor: "inStock",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 100px',
                },
            },
            {
                Header: "On Order",
                id: "onOrder",
                accessor: "onOrder",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 100px',
                },
            },
            {
                Header: "Commited",
                id: "commited",
                accessor: "commited",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 100px',
                },
            },
            {
                Header: "Reorder Qty",
                id: "reorderQty",
                accessor: "reorderQty",
                disableSortBy: true,
                disableFilters: true,
                inputType: "number",
                style: {
                    flex: '0 0 120px',
                },
                className: "input-field",
                Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                    <InputGroup>
                      <FormControl id={'id: "reorderQty",' + '_' + index} name={'reorderQty'}
                        min={0}
                        data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                        onChange={that.handleTableTextBoxChange}
                        disabled={CommonUtil.isViewMode(that.props.actionMode)}
                        value={value}
                        onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        maxLength={10}
                        minLength={1} />
                      <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                    </InputGroup>
                  )
                }
            },
            {
                Header: "Safty Stock",
                id: "saftyStock",
                accessor: "saftyStock",
                disableSortBy: true,
                disableFilters: true,
                inputType: "number",
                style: {
                    flex: '0 0 100px',
                },
                className: "input-field",
                Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                    <InputGroup>
                      <FormControl id={'saftyStock' + '_' + index} name={'saftyStock'}
                        min={0}
                        data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                        onChange={that.handleTableTextBoxChange}
                        disabled={CommonUtil.isViewMode(that.props.actionMode)}
                        value={value}
                        onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        maxLength={10}
                        minLength={1} />
                      <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                    </InputGroup>
                  )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "action",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 60px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Nav pullRight>
                                <NavDropdown id=""
                                    title={<i className="fa fa-ellipsis-v" id="" onClick={(e) => that.getTdProps(e)} />} noCaret >
                                        <MenuItem id="" onClick={(e) => that.getTdProps(e)}>Club Order</MenuItem>
                                        <MenuItem id="" onClick={(e) => that.getTdProps(e)}>Order with Supplier</MenuItem>
                                </NavDropdown>
                            </Nav>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 100,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

export const MANAGE_DEMANDPLANNING_LOCATION_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product",
                id: "productName",
                accessor: "productName",
            },
            {
                Header: "Location",
                id: "location",
                accessor: "location",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Supplier",
                id: "supplier",
                accessor: "supplier",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Order Qty",
                id: "orderQty",
                accessor: "orderQty",
                disableSortBy: true,
                disableFilters: true,
                inputType: "number",
                className: "input-field",
                Cell: ({ cell }) => {
                  const { value } = cell;
                  const { index, original } = cell.row;
                  return (
                    <InputGroup>
                      <FormControl id={'id: "orderQty",' + '_' + index} name={'orderQty'}
                        min={0}
                        data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                        onChange={that.handleTableTextBoxChange}
                        disabled={CommonUtil.isViewMode(that.props.actionMode)}
                        value={value}
                        onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                        maxLength={10}
                        minLength={1} />
                      <InputGroup.Addon>{original.productUOM}</InputGroup.Addon>
                    </InputGroup>
                  )
                }
            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [],
            defaultPageSize: 100,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

