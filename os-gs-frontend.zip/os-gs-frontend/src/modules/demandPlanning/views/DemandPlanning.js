import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tabs, Tab, FormGroup, PanelGroup, Panel, Table} from "react-bootstrap";
import { Redirect, NavLink } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import * as demandPlanningConstant from '../constant/demandPlanningConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PaginationUtil from '../../common/util/paginationUtil';
import PopularTable from '../../../views/Tables/PopularTable/Table/Table';
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import { getProductList } from '../../productManagement/actions/productActions';
import * as commonConstant from '../../common/constant/commonConstant';
import filter from 'assets/img/filter.svg';
import { setActionMode } from "../../../actions/appActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import demandPlanning from "assets/img/demandPlanning-page-icon.svg";
import pin from "assets/img/pin.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import Checkbox from "components/CustomCheckbox/CustomCheckbox.jsx";
import PerfectScrollbar from "perfect-scrollbar";
import { ResponsiveBar } from '@nivo/bar';
import { ResponsiveLine } from '@nivo/line';
var ps;

class DemandPlanning extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,
      key: 1,
      additionalParams: null,
      defaultSelectedTab: "PRODUCT",
      selectedTab: "PRODUCT",
      duration: 'days',

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage Demand Planning loaded");
    // if (navigator.platform.indexOf("Win") > -1) {
    //   ps = new PerfectScrollbar(this.refs.inventoryPanelbody);
    // }
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getFacilityList();
    this.props.getProductList();
    const { defaultSelectedTab, selectedSubTab } = this.state;
    this.setSelectedTabDetails(defaultSelectedTab, selectedSubTab);
  }

  componentWillUnmount() {
//     if (navigator.platform.indexOf("Win") > -1) {
// //      ps.destroy();
//   //    ps = null;
//     }
  }

  setSelectedTabDetails = async (selectedTab, selectedSubTab) => {
    var additionalParams = {};
    if (CommonUtil.isNotNull(this.props.location) && CommonUtil.isNotNull(this.props.location.state)) {
      additionalParams = this.props.location.state;
    }
    const managePageList = pagePropertyListConstant.MANAGE_DEMANDPLANNING_PAGE_LIST(this);
    const manageLocatioPageList = pagePropertyListConstant.MANAGE_DEMANDPLANNING_LOCATION_PAGE_LIST(this);
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      tableSecondColumnList: manageLocatioPageList.tableColumnList,
      tableSecondConfig: manageLocatioPageList.tableConfig,
      additionalParams: additionalParams,
      tableDataList: demandPlanningConstant.createdataTable,
      selectedTab: selectedTab,
      searchInput: "",
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    PaginationUtil.initPaginationParams(this);
    this.setSelectedTabDetails(selectedTabKey);
  }

  componentDidUpdate(e) {
  //   if (window.matchMedia(`(min-width: 960px)`).matches && !this.isMac()) {
  //     this._reactInternalInstance._currentElement._owner._instance._reactInternalInstance._currentElement._owner._instance.componentDidUpdate(
  //       e
  //     );
  //   }
  //   if (navigator.platform.indexOf("Win") > -1) {
  //     setTimeout(() => {
  //       if(ps){
  //       ps.update();
  //       }
  //     }, 350);
  //   }
  // }
  // isMac() {
  //   let bool = false;
  //   if (
  //     navigator.platform.toUpperCase().indexOf("MAC") >= 0 ||
  //     navigator.platform.toUpperCase().indexOf("IPAD") >= 0
  //   ) {
  //     bool = true;
  //   }
  //   return bool;
   }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.inventoryList.Items.filter((value) => {
      return (
        value.productName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData })
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  makeCustomAPICall(tempParamas) {

  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (tempId != null && tempId[1] == demandPlanningConstant.MENU_ACTION_MODE) {
      CommonUtil.overlay(event);
    }
  }

  handleCustomSelection = (options) => {
    this.setState({ duration: options });
  }


  render() {
    const { tableColumnList, tableSecondColumnList, tableDataList, tableConfig, location, duration } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={demandPlanning} alt="" className="page-icon" />
                  {demandPlanningConstant.MANAGE_DEMANDPLANNING_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Code / Name"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <Row className="planning-requirement">
                    <Col md={3}>
                      <div className="inventory-summary">
                        <div className="title">Inventory</div>
                        <PanelGroup
                          accordion
                          id="inventoryPanels"
                          ref="inventoryPanels"
                          className="inventory-panels"
                          onClick={() => this.forceUpdate()}
                        >
                          <Panel eventKey="1">
                            <Panel.Heading>
                              <Panel.Title toggle>
                                <div className="inventory-subsection">
                                  <div className="heading">Product Variant</div>
                                  <div className="value">02</div>
                                </div>
                                <i className="fa fa-chevron-up"></i>
                              </Panel.Title>
                            </Panel.Heading>
                            <Panel.Body collapsible ref="inventoryPanelbody">
                              <Checkbox
                                isChecked
                                number="1"
                                label="Product Variant 1"
                              />
                              <Checkbox
                                number="2"
                                label="Product Variant 2"
                              />
                              <Checkbox
                                number="3"
                                label="Product Variant 3"
                              />
                              <Checkbox
                                number="4"
                                label="Product Variant 4"
                              />
                              <Checkbox
                                number="5"
                                label="Product Variant 5"
                              />
                              <Checkbox
                                number="6"
                                label="Product Variant 6"
                              />
                              <Checkbox
                                number="7"
                                label="Product Variant 7"
                              />
                            </Panel.Body>
                          </Panel>
                          <Panel eventKey="2">
                            <Panel.Heading>
                              <Panel.Title toggle>
                                <div className="inventory-subsection">
                                  <div className="heading">Catagory</div>
                                  <div className="value">02</div>
                                </div>
                                <i className="fa fa-chevron-up"></i>
                              </Panel.Title>
                            </Panel.Heading>
                            <Panel.Body collapsible ref="inventoryPanelbody">
                              <Checkbox
                                number="8"
                                label="Product Variant 1"
                              />
                              <Checkbox
                                number="9"
                                label="Product Variant 2"
                              />
                              <Checkbox
                                number="10"
                                label="Product Variant 3"
                              />
                              <Checkbox
                                number="11"
                                label="Product Variant 4"
                              />
                            </Panel.Body>
                          </Panel>
                          <Panel eventKey="3">
                            <Panel.Heading>
                              <Panel.Title toggle>
                                <div className="inventory-subsection">
                                  <div className="heading">Detailes</div>
                                  <div className="value">02</div>
                                </div>
                                <i className="fa fa-chevron-up"></i>
                              </Panel.Title>
                            </Panel.Heading>
                            <Panel.Body collapsible ref="inventoryPanelbody">
                              <Checkbox
                                number="12"
                                label="Product Variant 1"
                              />
                              <Checkbox
                                number="13"
                                label="Product Variant 2"
                              />
                              <Checkbox
                                number="14"
                                label="Product Variant 3"
                              />
                              <Checkbox
                                number="15"
                                label="Product Variant 4"
                              />
                            </Panel.Body>
                          </Panel>
                        </PanelGroup>
                      </div>
                    </Col>
                    <Col md={9}>
                      <div className="period">
                        <div className="heading">View By</div>
                        <ul className="time">
                          <li className={duration == "days" ? 'active' :''} onClick={() => this.handleCustomSelection('days')}>Days</li>
                          <li className={duration == "week" ? 'active' :''} onClick={() => this.handleCustomSelection('week')}>Week</li>
                          <li className={duration == "month" ? 'active' :''} onClick={() => this.handleCustomSelection('month')}>Month</li>
                        </ul>
                      </div>

                      {tableColumnList != null ?
                      <Row className="product-table">
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <PopularTable columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}

                      <Col md={12} className="graph-section-wrapper">
                        <Row>
                          <Col md={3}>
                            <div className="graph-date">Jul 2020</div>
                          </Col>
                          <Col md={9} className="graph-pointers">
                            <div className="graph-highlighter">
                              <div className="box" style={{background: '#199D9D'}}></div>
                              Past Sales History
                            </div>
                            <div className="graph-highlighter">
                              <div className="box" style={{background: '#6CC0C0'}}></div>
                              Actual Sales
                            </div>
                            <div className="graph-highlighter">
                              <div className="box" style={{background: '#2A3439'}}></div>
                              Forecast
                            </div>
                            <div className="graph-highlighter">
                              <div className="box" style={{background: '#777D80'}}></div>
                              Planing & Pro
                            </div>
                          </Col>
                        </Row>
                        <Row className="graph-section">
                          <Col md={12}>
                            <Row>
                              <Col md={6}>
                                <div className="graph">
                                  <ResponsiveBar
                                    data={
                                      [
                                        {"date": 21, "Past Sales History": 20, "Actual Sales": 5, "Forecast": 20, "Planing & Pro": 15},
                                        {"date": 22, "Past Sales History": 30, "Actual Sales": 15, "Forecast": 5, "Planing & Pro": 17},
                                        {"date": 23, "Past Sales History": 10, "Actual Sales": 25, "Forecast": 5, "Planing & Pro": 14},
                                        {"date": 24, "Past Sales History": 20, "Actual Sales": 5, "Forecast": 11, "Planing & Pro": 11},
                                        {"date": 25, "Past Sales History": 30, "Actual Sales": 15, "Forecast": 5, "Planing & Pro": 9},
                                        {"date": 26, "Past Sales History": 10, "Actual Sales": 25, "Forecast": 5, "Planing & Pro": 23},
                                        {"date": 27, "Past Sales History": 10, "Actual Sales": 25, "Forecast": 5, "Planing & Pro": 33},
                                      ]
                                    }
                                    keys={['Past Sales History', 'Actual Sales', 'Forecast', 'Planing & Pro']}
                                    indexBy="date"
                                    margin={{ top: 5, right: 0, bottom: 20, left: 0 }}
                                    padding={0.3}
                                    innerPadding={2}
                                    minValue="auto"
                                    maxValue="auto"
                                    groupMode="grouped"
                                    colors={["#199D9D", "#6CC0C0", "#2A3439", "#777D80"]}
                                    axisTop={null}
                                    axisRight={null}
                                    axisBottom={{
                                      tickSize: 0,
                                      tickPadding: 5,
                                      tickRotation: 0,
                                      legend: '',
                                      legendPosition: 'middle',
                                      legendOffset: 32
                                    }}
                                    axisLeft={null}
                                    gridYValues={[0, 10, 20, 30, 40, 50]}
                                    enableGridY={false}
                                    labelSkipWidth={0}
                                    labelSkipHeight={0}
                                    enableLabel={false}
                                    labelTextColor="white"
                                    isInteractive={true}
                                    animate={false}
                                  />
                                </div>
                              </Col>
                              <Col md={6}>
                                <div className="graph">
                                  <ResponsiveLine
                                    data={
                                      [
                                        {"id": "Past Sales History", "data": [{"x": "01","y": 20},{"x": "02","y": 5},{"x": "03","y": 22},{"x": "04","y": 15}]},
                                        {"id": "Actual Sales", "data": [{"x": "01","y": 30},{"x": "02","y": 15},{"x": "03","y": 33},{"x": "04","y": 11}]},
                                        {"id": "Forecast", "data": [{"x": "01","y": 20},{"x": "02","y": 30},{"x": "03","y": 33},{"x": "04","y": 15}]},
                                        {"id": "Planing & Pro", "data": [{"x": "01","y": 15},{"x": "02","y": 50},{"x": "03","y": 33},{"x": "04","y": 19}]},
                                      ]
                                    }
                                    margin={{ top: 10, right: 20, bottom: 20, left: 60 }}
                                    xScale={{ type: 'point' }}
                                    yScale={{ type: 'linear', min: 'auto', max: 'auto', stacked: true, reverse: false }}
                                    yFormat=" >-.2f"
                                    axisTop={null}
                                    axisRight={null}
                                    axisBottom={{
                                      orient: 'bottom',
                                      tickSize: 0,
                                      tickPadding: 5,
                                      tickRotation: 0,
                                      legend: '',
                                      legendOffset: 36,
                                      legendPosition: 'middle'
                                    }}
                                    axisLeft={{
                                        orient: 'left',
                                        tickSize: 0,
                                        tickPadding: 5,
                                        tickRotation: 0,
                                        legend: '',
                                        legendOffset: -40,
                                        legendPosition: 'middle'
                                    }}
                                    pointSize={7}
                                    pointColor={["#199D9D", "#6CC0C0", "#2A3439", "#777D80"]}
                                    pointBorderWidth={2}
                                    pointBorderColor="#199D9D"
                                    enableGridX={false}
                                    minValue="auto"
                                    maxValue="auto"
                                    theme={{
                                      fontSize: 8,
                                      axis: {
                                        "legend": {
                                          "text": {
                                            "fill": "#4988A6"
                                          }
                                        },
                                        "domain": {
                                          "line": {
                                            "stroke": "#9AC7D7",
                                            "strokeWidth": 1
                                          }
                                        },
                                      },
                                    }}
                                    gridYValues={"auto"}
                                    lineWidth={1}
                                    enableGridX={false}
                                    pointLabelYOffset={-10}
                                    useMesh={false}
                                    isInteractive={false}
                                    enablePointLabel={false}
                                  />
                                </div>
                              </Col>
                            </Row>
                          </Col>
                        </Row>
                      </Col>

                      <Table responsive className="plan-table">
                        <thead>
                          <tr>
                            <th>Details</th>
                            <th>Day 01</th>
                            <th>Day 02</th>
                            <th>Day 03</th>
                            <th>Day 04</th>
                            <th>Day 05</th>
                            <th>Day 06</th>
                            <th>Day 07</th>
                            <th>Day 08</th>
                            <th>Day 09</th>
                            <th>Day 10</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td>Past Sales History</td>
                            <td>9</td>
                            <td>12</td>
                            <td>5</td>
                            <td>5</td>
                            <td>5</td>
                            <td>7</td>
                            <td>5</td>
                            <td>9</td>
                            <td>5</td>
                            <td>8</td>
                          </tr>
                          <tr>
                            <td>Actual Sales</td>
                            <td>9</td>
                            <td>12</td>
                            <td>-</td>
                            <td>-</td>
                            <td>5</td>
                            <td>7</td>
                            <td>5</td>
                            <td>9</td>
                            <td>-</td>
                            <td>8</td>
                          </tr>
                          <tr>
                            <td>Forecast</td>
                            <td>9</td>
                            <td>12</td>
                            <td>5</td>
                            <td>5</td>
                            <td>-</td>
                            <td>7</td>
                            <td>5</td>
                            <td>9</td>
                            <td>5</td>
                            <td>8</td>
                          </tr>
                          <tr>
                            <td>Planing & Pro</td>
                            <td>9</td>
                            <td>12</td>
                            <td>5</td>
                            <td>5</td>
                            <td>5</td>
                            <td>7</td>
                            <td>-</td>
                            <td>9</td>
                            <td>5</td>
                            <td>8</td>
                          </tr>
                        </tbody>
                      </Table>

                      {tableSecondColumnList != null ?
                      <Row className="product-table">
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <PopularTable columns={tableSecondColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                    </Col>
                  </Row>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    facilityList: state.facility.facilityList,
    productList: state.product.productList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getProductList: (params) => dispatch(getProductList(params)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(DemandPlanning);
