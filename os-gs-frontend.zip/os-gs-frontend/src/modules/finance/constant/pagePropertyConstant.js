import React from "react";
import CommonUtil from "../../common/util/commonUtil";
import Select from "react-select";
import Datetime from "react-datetime";
import { FormControl, InputGroup } from "react-bootstrap";
import currencyIcon from '../../common/util/currencyIcon';
import moment from "moment";
import Button from "components/CustomButton/CustomButton.jsx";
import isAuthorized from "auth-plugin";

export const MANAGE_EXPENSE_SO_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order #",
        id: "saleOrderId",
        accessor: "saleOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 100px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>
              SO-{original.saleOrderId}
            </>
          )
        }
      },
      {
        Header: "description",
        id: "description",
        accessor: "description",
      },
      {
        Header: "account",
        id: "account",
        accessor: "account",
      },
      {
        Header: "Expense Date",
        id: "expenseDate",
        accessor: "expenseDate",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
          )
        }
      },
      {
        Header: "Amt",
        id: "amount",
        accessor: "amount",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, Number(original.amount))}</>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_EXPENSE_PO_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order #",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        isQBOAttribute: false,
        style: {
          flex: "0 0 100px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>
              PO-{original.purchaseOrderId}
            </>
          )
        }
      },
      {
        Header: "description",
        id: "description",
        accessor: "description",

      },
      {
        Header: "account",
        id: "account",
        accessor: "account",

      },
      {
        Header: "Expense Date",
        id: "expenseDate",
        accessor: "expenseDate",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
          )
        }
      },
      {
        Header: "Amt",
        id: "amount",
        accessor: "amount",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, Number(original.amount))}</>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_LEDGER_CUSTOMER_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Name #",
        id: "customerName",
        accessor: "customerName",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td label-black"
              id={original.customerId + "_" + index}
              onClick={(e) => that.showChildCustomers(original.customerId, original.customerName, e)} title={original.customerName}>
              <span> {original.customerName}</span>
            </div>
          )
        }
      },
      {
        Header: "Opening Balance",
        id: "openingBalance",
        accessor: "openingBalance",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Open Balance" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Open Bal";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.openingBalance)}</>
          )
        }
      },
      {
        Header: "Order Amt",
        id: "totalOrderAmount",
        accessor: "totalOrderAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Order Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalOrderAmount)}</>
          )
        }
      },
      {
        Header: "Total Amt",
        id: "totalAmount",
        accessor: "totalAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalAmount)}</>
          )
        }
      },
      {
        Header: "Available Credit",
        id: "creditAmount",
        accessor: "creditAmount",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Available Credit" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Available Credit";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.creditAmount)}</>
          )
        }
      },
      {
        Header: "Paid Amt",
        id: "paidAmount",
        accessor: "paidAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Paid Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Paid Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.paidAmount)}</>
          )
        }
      },
      {
        Header: "Outstanding",
        id: "outStandingAmount",
        accessor: "outStandingAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Outstanding" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Outstanding";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.outStandingAmount)}</>
          )
        }
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 70px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <div className="circle">
                {isAuthorized("viewBulkPaymentFinance") &&
                  <Button bsStyle="default" simple icon>
                    <i class="fa fa-credit-card" aria-hidden="true" title="Make Payment"
                      onClick={() => that.bulkPaymentOpen(original.customerId, original.customerName, original.openingBalance, "CUST")}></i>
                  </Button>
                }
              </div>
              <div className="circle">
                {isAuthorized("viewBulkPaymentFinance") &&
                  <Button bsStyle="default" simple icon>
                    <i class="fa fa-money" aria-hidden="true" title="View Payment"
                      id={"CUST-" + original.customerId + "_viewPayment_" + index}
                      onClick={(e) => that.handleMenuPopupAction(e, "Opening Balance")}></i>
                  </Button>
                }
              </div>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};


export const MANAGE_LEDGER_SUPPLIER_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Name #",
        id: "supplierName",
        accessor: "supplierName",
        style: {
          flex: "0 0 250px",
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td label-black"
              id={original.supplierId + "_" + index}
              onClick={(e) => that.showChildSuppliers(original.supplierId, original.supplierName, e)} title={original.supplierName}>
              <span> {original.supplierName}</span>
            </div>
          )
        }
      },
      {
        Header: "Opening Balance",
        id: "openingBalance",
        accessor: "openingBalance",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Open Balance" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Open Bal";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.openingBalance)}</>
          )
        }
      },
      {
        Header: "Order Amt",
        id: "totalOrderAmount",
        accessor: "totalOrderAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Order Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalOrderAmount)}</>
          )
        }
      },
      {
        Header: "Total Amt",
        id: "totalAmount",
        accessor: "totalAmount",
        isQBOAttribute: false,
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalAmount)}</>
          )
        }
      },
      {
        Header: "Available Credit",
        id: "creditAmount",
        accessor: "creditAmount",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Available Credit" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Available Credit";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.creditAmount)}</>
          )
        }
      },
      {
        Header: "Paid Amt",
        id: "paidAmount",
        accessor: "paidAmount",
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Paid Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Paid Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.paidAmount)}</>
          )
        }
      },
      {
        Header: "Outstanding",
        id: "outStandingAmount",
        accessor: "outStandingAmount",
        isQBOAttribute: false,
        disableSortBy: false,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Outstanding" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Outstanding";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.outStandingAmount)}</>
          )
        }
      },
      {
        Header: "Action",
        id: "action",
        accessor: "action",
        className: "action justify-content-center",
        style: {
          flex: "0 0 70px",
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <div className="circle">
                {isAuthorized("viewBulkPaymentFinance") &&
                  <Button bsStyle="default" simple icon>
                    <i class="fa fa-credit-card" aria-hidden="true" title="Make Payment"
                      onClick={() => that.bulkPaymentOpen(original.supplierId, original.supplierName, original.openingBalance, "SUP")}></i>
                  </Button>
                }
              </div>
              <div className="circle">
                {isAuthorized("viewBulkPaymentFinance") &&
                  <Button bsStyle="default" simple icon>
                    <i class="fa fa-money" aria-hidden="true" title="View Payment"
                      id={"SUP-" + original.supplierId + "_viewPayment_" + index}
                      onClick={(e) => that.handleMenuPopupAction(e, "Opening Balance")}></i>
                  </Button>
                }
              </div>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_SUPPLIER_CHILD_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Purchase Order #",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let paymentList = (original.paymentDetailsList && original.paymentDetailsList.length > 0)
            ? true : false;
          return (
            <div className="label-black-link">
              <div className="link-payment"
                id={"PO-" + original.purchaseOrderId + "_viewPayment_" + index}
                onClick={(e) => that.handleMenuPopupAction(e)} >
                PO-{original.purchaseOrderId}
              </div>
              {original.purchaseOrderId != "Opening Balance" && <i class="fa fa-external-link" aria-hidden="true" onClick={() => that.props.openOrderDetailsWindow("PO-" + original.purchaseOrderId)}></i>}
            </div>
          )
        }
      },
      {
        Header: "Date",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
          )
        }
      },
      // {
      //   Header: "Mode",
      //   id: "mode",
      //   accessor: "mode",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let paymentMode = (original.paymentDetailsList && original.paymentDetailsList.length > 0)
      //       ? original.paymentDetailsList[0].paymentMode : '';
      //     return (
      //       <div>
      //         {paymentMode}
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Total Amt",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalValue)}</>
          )
        }
      },
      {
        Header: "Paid Amt",
        id: "totalPaidAmount",
        accessor: "totalPaidAmount",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Paid Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Paid Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalPaidAmount)}</>
          )
        }
      },
      {
        Header: "Outstanding Amt",
        id: "outStandingAmount",
        accessor: "outStandingAmount",
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Outstanding Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Outstanding";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td label-black"
              id={original.supplierId + "outStandingAmount" + "_" + index}>
              <span> {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(original.totalValue) - CommonUtil.getFloatValue(original.totalPaidAmount))}</span>
            </div>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_CUSTOMER_CHILD_FINANCE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Sale Order #",
        id: "saleOrderId",
        accessor: "saleOrderId",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let paymentList = (original.paymentDetailsList && original.paymentDetailsList.length > 0)
            ? true : false;
          return (
            <div className="label-black-link">
              <div className="link-payment"
                id={"SO-" + original.saleOrderId + "_viewPayment_" + index}
                onClick={(e) => that.handleMenuPopupAction(e)} >
                SO-{original.saleOrderId}
              </div>
              {original.saleOrderId != "Opening Balance" && <i class="fa fa-external-link" aria-hidden="true" onClick={() => that.props.openOrderDetailsWindow("SO-" + original.saleOrderId)}></i>}
            </div>
          )
        }
      },
      {
        Header: "Receipt #",
        id: "invoiceNumber",
        accessor: "invoiceNumber",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td label-black">

              {original.invoiceNumber}
            </div>
          )
        }
      },
      {
        Header: "Date",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
          )
        }
      },
      // {
      //   Header: "Mode",
      //   id: "mode",
      //   accessor: "mode",
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let paymentMode = (original.paymentDetailsList && original.paymentDetailsList.length > 0)
      //       ? original.paymentDetailsList[0].paymentMode : '';
      //     return (
      //       <div>
      //         {paymentMode}
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Total Amt",
        id: "totalValue",
        accessor: "totalValue",
        isQBOAttribute: false,
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Total Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Total Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalValue)}</>
          )
        }
      },
      {
        Header: "Paid Amt",
        id: "totalPaidAmount",
        accessor: "totalPaidAmount",
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Paid Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Paid Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>{that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, original.totalPaidAmount)}</>
          )
        }
      },
      {
        Header: "Outstanding Amt",
        id: "outStandingAmount",
        accessor: "outStandingAmount",
        disableSortBy: true,
        Cell: ({ cell }) => {
          cell.column.Header = that.props.currencyCode ? ("Outstanding Amt" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")") : "Outstanding Amt";
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="full-td label-black"
              id={original.supplierId + "outStandingAmount" + "_" + index}>
              <span> {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, CommonUtil.getFloatValue(original.totalValue) - CommonUtil.getFloatValue(original.totalPaidAmount))}</span>
            </div>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const PAYMENT_PROCESS_CUSTOMER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Received Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: true
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Received Amt",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl id={'receivedAmount' + '_' + index}
                min={0}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          )
        }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 150px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={true}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentMode)} />
          )
        },
      },
      {
        Header: "Deposit Date",
        id: "depositeDate",
        name: "depositeDate",
        accessor: "depositeDate",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              // className={that.state.submitted && !value ? 'required-error' : ''}
              id={"depositeDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: true
              }}
              name={'depositeDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "depositeDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const PAYMENT_PROCESS_SUPPLIER_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Payment Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: true
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Paid Amt",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup
              className={that.state.submitted && !value ? 'required-error' : ''}>
              <FormControl id={'receivedAmount' + '_' + index}
                min={0}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          )
        }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 150px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={true}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentMode)} />
          )
        },
      },
      {
        Header: "Deposit Date",
        id: "depositeDate",
        name: "depositeDate",
        accessor: "depositeDate",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              // className={that.state.submitted && !value ? 'required-error' : ''}
              id={"depositeDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: true
              }}
              name={'depositeDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "depositeDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={true}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const BULK_PAYMENT_PROCESS_CUST_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Received Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: false
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Received Amt",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isZero = CommonUtil.getFloatValue(value, true) == 0 || !value
          return (
            <InputGroup
              className={that.state.submitted && isZero ? 'required-error' : ''}>
              <FormControl id={'receivedAmount' + '_' + index}
                min={0}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                disabled={false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          )
        }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 150px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={false}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentMode)} />
          )
        },
      },
      {
        Header: "Deposit Date",
        id: "depositeDate",
        name: "depositeDate",
        accessor: "depositeDate",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              // className={that.state.submitted && !value ? 'required-error' : ''}
              id={"depositeDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: false
              }}
              name={'depositeDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "depositeDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const BULK_PAYMENT_PROCESS_SUP_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Payment Date",
        id: "receivedDate",
        name: "receivedDate",
        accessor: "receivedDate",
        required: true,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={"receivedDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: false
              }}
              name={'receivedDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "receivedDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Paid Amt",
        id: "receivedAmount",
        accessor: "receivedAmount",
        name: "receivedAmount",
        required: true,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 150px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let isZero = CommonUtil.getFloatValue(value, true) == 0 || !value
          return (
            <InputGroup
              className={that.state.submitted && isZero ? 'required-error' : ''}>
              <FormControl id={'receivedAmount' + '_' + index}
                min={0}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                name={'receivedAmount'} onChange={that.handleTableTextBoxChange}
                disabled={false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
              {/*<InputGroup.Addon>{that.props.currencyCode}</InputGroup.Addon>*/}
            </InputGroup>
          )
        }
      },
      {
        Header: "Payment Mode",
        id: "paymentMode",
        accessor: "paymentMode",
        name: "paymentMode",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: false,
        style: {
          flex: "0 0 150px",
        },
        dataDictionaryId: 'paymentMode',
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && !value ? 'required-error' : ''}
              id={'paymentMode' + '_' + index}
              name={"paymentMode" + '_' + index}
              onChange={that.handleTableDropDownChange}

              options={that.props.dataDictionaryList &&
                that.props.dataDictionaryList &&
                that.props.dataDictionaryList.filter((d) => d.dataType === 'paymentModeList')}
              classNamePrefix="react-select"
              isDisabled={false}
              value={CommonUtil.getSelectedOptionLabel(that.props.dataDictionaryList, original.paymentMode)} />
          )
        },
      },
      {
        Header: "Deposit Date",
        id: "depositeDate",
        name: "depositeDate",
        accessor: "depositeDate",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        style: {
          flex: "0 0 120px",
        },
        className: "input-field",
        Cell: ({ cell }) => {
          let value = cell.value;
          const { index, original } = cell.row;
          return (
            <Datetime
              // className={that.state.submitted && !value ? 'required-error' : ''}
              id={"depositeDate" + '_' + index}
              timeFormat={false}
              // isValidDate={CommonUtil.disablePastDt()}
              closeOnSelect={true}
              inputProps={{
                readOnly: true,
                placeholder: "Date Picker Here",
                disabled: false
              }}
              name={'depositeDate'}
              onChange={(moment) => that.handleTableDateChange(moment, "depositeDate" + "_" + index)}
              dateFormat="MM-DD-YYYY"
              value={value ? moment(value) : ''}
            />
          )
        },
      },
      {
        Header: "Description",
        id: "description",
        name: "description",
        accessor: "description",
        required: false,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup>
              <FormControl
                id={"description" + "_" + index}
                name={"description"}
                onChange={that.handleTableTextBoxChange}
                disabled={false}
                value={value}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 55) }}
                maxLength={55}
                minLength={3} />
            </InputGroup>
          )
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: '',
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Lot Number",
      },
    ],
  }
};
