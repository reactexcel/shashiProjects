export const MANAGE_FINANCE_HEADER_TITLE = "Finance";
export const VIEW_PURCHASE_HEADER_TITLE = "View Finance";;
export const MODULE_NAME = "Finance";
export const MANAGE_FINANCE_PAGE_URL = "/admin/manage-finance";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_FINANCE_LIST_URL = `${BASE_URL}/finances`;
export const GET_FINANCE_SUPPLIER_LIST_URL = `${BASE_URL}/suppliers/purchaseOrders`;
export const GET_FINANCE_CUSTOMER_LIST_URL = `${BASE_URL}/customers/saleorders`;
export const GET_FINANCE_SEARCH_URL = BASE_URL + '/finances';

export const MANAGE_PAGE_TAB_LIST = [
    {
        key: "SO",
        title: "SALE ORDER"
    },
    {
        key: "PO",
        title: "PURCHASE ORDER"
    },
];
export const MANAGE_PAGE_LEDGER_TAB_LIST = [
    {
        key: "CUSTOMER",
        title: "CUSTOMER",
        tab: "viewCustomerFinance",
    },
    {
        key: "SUPPLIER",
        title: "SUPPLIER",
        tab: "viewCustomerSupplier",
    },
];

export const MANAGE_PAGE_CUSTOMER_LEDGER_TAB_LIST = [
    {
        key: "CUSTOMER",
        title: "CUSTOMER",
        tab: "viewCustomerFinance",
    },
];
export const MANAGE_PAGE_SUPPLIER_LEDGER_TAB_LIST = [
    {
        key: "SUPPLIER",
        title: "SUPPLIER",
        tab: "viewCustomerSupplier",
    },
];


