import axios from "../../../axios/axios";
import * as financeActionTypes from "./financeActionTypes";
import * as financeConstant from "../constant/financeConstant";
import {
  beginAjaxCall, endAjaxCall
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: financeActionTypes.SET_FINANCE_REDUCER_INIT_MODE,
      payload: null,
    });
  };
}

export function getFinanceList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(financeConstant.GET_FINANCE_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: financeActionTypes.GET_FINANCE_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getFinanceSearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(financeConstant.GET_FINANCE_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: financeActionTypes.GET_FINANCE_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function getFinanceSupplierList(supplierId, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(financeConstant.GET_FINANCE_SUPPLIER_LIST_URL + "/" + supplierId, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: financeActionTypes.GET_FINANCE_SUPPLIER_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

export function getFinanceCustomerList(customerId, params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(financeConstant.GET_FINANCE_CUSTOMER_LIST_URL + "/" + customerId, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: financeActionTypes.GET_FINANCE_CUSTOMER_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}

