import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Tab, Tabs, FormGroup } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as financeConstant from "../constant/financeConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import { getSupplierList } from "../../supplierManagement/actions/supplierActions";
import { connect } from "react-redux";
import { getFinanceList, getFinanceSearchList } from "../actions/financeActions";
import CommonUtil from "../../common/util/commonUtil";
import * as statusConstant from '../../common/constant/statusConstant';
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { setActionMode } from "../../../actions/appActions";
import StatusUtil from '../../common/util/statusUtil';
import PaginationUtil from "../../common/util/paginationUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { getUserProfile } from "../../userManagement/actions/userActions";
import trace from "assets/img/trace-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import PopupUtil from '../../common/util/popupUtil';
import check from "assets/img/check.svg";
import scrollToComponent from 'react-scroll-to-component';
import PaymentProcessModal from "./PaymentProcessModal";
import LedgerChildTable from "./LedgerChildTable";
import isAuthorized from "auth-plugin";
import { setSelectedPurchaseOrderCode } from "../../purchaseOrder/actions/purchaseOrderActions";
import { setSelectedSaleOrderCode } from "../../saleOrder/actions/saleOrderActions";
import CreatePurchaseOrder from "../../purchaseOrderAMS/views/CreatePurchaseOrder";
import CreateSaleOrder from "../../saleOrderAMS/views/CreateSaleOrder";
import * as commonConstant from '../../common/constant/commonConstant';
import BulkPayment from "./BulkPayment";
import pin from "assets/img/pin.svg";
import Select from "react-select";
var Modal = require('react-bootstrap-modal')

class ManageFinance extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      defaultSelectedTab: "EXPENSE",
      selectedTab: "CUSTOMER",
      mainSelectedTab: "LEDGER",
      status: null,
      facilityList: [],
      allList: [{ label: 'All', value: '' }],
      search: null,
      showDetailView: false,
      orderDetailsModal: false,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      openPaymentModal: false,
      openBulkPaymentModal: false,
      code: null,
      name: '',
      paymentList: [],
      showSelected: false,
      reload: true,
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  componentDidMount = async () => {
    mixpanel.track("Manage finance loaded");
    let location = CommonUtil.getAdditonalPathLocation(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    // this.props.getFacilityList({ "source": true });
    this.props.getFacilityList({ isDropdown: true });
    this.props.getSupplierList();
    if (CommonUtil.isNotNull(location)) {
      await this.props.getFacilityDetails(location);
    }
    await this.setSelectedTabDetails(true);
  };

  setSelectedTabDetails = async (flag) => {
    if (flag && !isAuthorized("viewCustomerSupplier") && !isAuthorized("viewCustomerFinance") && isAuthorized("viewExpense")) {
      await this.setState({ mainSelectedTab: "EXPENSE", selectedTab: "SO" });
    }
    if (flag && isAuthorized("viewCustomerSupplier")) {
      await this.setState({ selectedTab: "CUSTOMER" });
    } else if (flag && isAuthorized("viewCustomerFinance")) {
      await this.setState({ selectedTab: "SUPPLIER" });
    }
    const { mainSelectedTab, selectedTab } = this.state;
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const managePageList = pagePropertyListConstant["MANAGE_" + mainSelectedTab + "_" + selectedTab + "_FINANCE_PAGE_LIST"](this);
    let additionalParams = { tab: mainSelectedTab.toLowerCase(), source: selectedTab.toLowerCase() };
    if (this.state.location) {
      additionalParams.location = this.state.location;
    }
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      lastEvaluatedKeyArray: [],
      additionalParams: additionalParams,
      selectedTab: selectedTab,
      searchInput: "",
      showDetailView: false,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
      limit: managePageList.tableConfig.defaultPageSize
    });
    this.state.location && this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this), selectedTab);
  };

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim(), reload: true  });
      this.setSelectedTabDetails();
      this.setState({ menuOpen: false, status: null });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleTabClick = async (label, event) => {
    this.setState({ showDetailView: false, showSelected: false });
    PaginationUtil.initPaginationParams(this);
    let selectedTabKey = label.toUpperCase();
    await this.setState({ selectedTab: selectedTabKey, search: null });
    await this.setSelectedTabDetails();
  };

  componentDidUpdate(prevProps) {
    if (this.props.financeList != null && prevProps.financeList != this.props.financeList) {
      this.handleCustomPagination();
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.updateFacilityDropDownList();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleCustomPagination = async () => {
    if (this.state.selectedTab == "DRAFT") {
      PaginationUtil.handlePagination(this.props.automationDraftList, this);
    } else if (CommonUtil.isNotNull(this.props.financeList)) {
      PaginationUtil.handlePagination(this.props.financeList, this);
    }
    if(this.state.showSelected) {
      let id = "";
      if (this.state.source == "CUST") {
        this.props.financeList.map((item, index) => {
          if(item.customerId == this.state.code) {
            id = item.customerId + "_" + index
          }
        })
        await this.setState({ selectedIndex: id });
        await this.showChildCustomers(this.state.code, this.state.name)
      } else if (this.state.source == "SUP") {
        this.props.financeList.map((item, index) => {
          if(item.supplierId == this.state.code) {
            id = item.supplierId + "_" + index
          }
        })
        await this.setState({ selectedIndex: id });
        await this.showChildSuppliers(this.state.code, this.state.name)
      }
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      PaginationUtil.initPaginationParams(this);
      this.setSelectedTabDetails();
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      await this.props.setAjaxCallStatus(null);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  };

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.financeList.filter((value) => {
      if (this.state.mainSelectedTab == "EXPENSE") {
        return (
          String(value.saleOrderId).toLowerCase().includes(searchInput.toLowerCase()) ||
          String(value.purchaseOrderId).toLowerCase().includes(searchInput.toLowerCase()) ||
          String(value.account).toLowerCase().includes(searchInput.toLowerCase())
        );
      } else {
        if (this.state.selectedTab == "CUSTOMER") {
          return (
            value.customerName.toLowerCase().includes(searchInput.toLowerCase())
          );
        } else {
          return (
            value.supplierName.toLowerCase().includes(searchInput.toLowerCase())
          );
        }
      }
    });
    this.setState({ tableDataList: filteredData });
  };

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ location: tempObj.value, locationName: tempObj.label, reload: true, showSelected: false  });
    this.setSelectedTabDetails();
  }

  handleFIlter = (event) => {
    let status = CommonUtil.isNotNull(event) ? event.toLowerCase() : null;
    let filteredData = this.props.financeList.filter((value) => {
      if (event == statusConstant.OVERDUE_STATUS) {
        return (CommonUtil.isDateExpired(value.requestedDeliveryDate) == true);
      } else if (event == statusConstant.ALL_STATUS) {
        return value;
      } else if (event !== "") {
        return value.status.toLowerCase() == event.toLowerCase();
      }
      return value;
    });
    this.setState({ tableDataList: filteredData, selectedFilter: event, status: status });
  }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedFinanceCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
  };

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(
      this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))
    await this.setState({
      facilityList: tempList,
      location: this.state.location ? this.state.location : tempList[0].value,
      locationName: this.state.locationName ? this.state.locationName : tempList[0].label
    })
    this.state.reload && tempList && tempList.length > 0 && await this.setSelectedTabDetails(true)
  }

  // handleMenuPopupAction = async (event) => {
  //   let tempId = event.target.id.split("_");
  // };

  handlePopupCancel = () => {
    this.setState({ alert: null });
  };


  makeCustomAPICall(tempParamas, selectedTab) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getFinanceSearchList(tempParamas);
    } else {
      this.props.getFinanceList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    } else if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      this.handleMenuPopupAction(event);
    }
  };

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      await this.setState({ search: null, status: null, selectedFilter: null, searchInput: "", reload: true });
      await this.setSelectedTabDetails();
    }
    if (tempId[1] === "status") {
      await this.setState({ status: null, lastEvaluatedKeyArray: [], selectedFilter: null, reload: true });
      await this.setSelectedTabDetails();
    }
  }

  handleMainTabClick = async (label, event) => {
    let mainSelectedTab = label.toUpperCase();
    let selectedTab = mainSelectedTab == "LEDGER" ? "CUSTOMER" : "SO";
    PaginationUtil.initPaginationParams(this);
    await this.setState({ mainSelectedTab: mainSelectedTab, selectedTab: selectedTab, search: null, reload: true, selectedIndex: '', showDetailView : false, showSelected: false });
    await this.setSelectedTabDetails();
  }

  showChildSuppliers = async (code, name, e) => {
    let id = this.state.selectedIndex;
    e && e.target.closest('.table-body').querySelectorAll(".active").forEach(e =>
      e.classList.remove("active"));
    e && e.target.closest('.rt-tr-group').classList.add('active');
    !e && id && document.getElementById(id).closest('.table-body').querySelectorAll(".active").forEach(e =>
      e.classList.remove("active"));
    !e && id && document.getElementById(id).closest('.rt-tr-group').classList.add('active');
    await this.setState({ showDetailView: false, showSelected: true });
    await this.setState({
      showDetailView: true, code: code, name: name, source: "SUP"
    });
    await scrollToComponent(this.details, { offset: 0, align: 'top', duration: 1500 });
  }

  showChildCustomers = async (code, name, e) => {
    let id = this.state.selectedIndex;
    e && e.target.closest('.table-body').querySelectorAll(".active").forEach(e =>
      e.classList.remove("active"));
    e && e.target.closest('.rt-tr-group').classList.add('active');
    !e && id && document.getElementById(id).closest('.table-body').querySelectorAll(".active").forEach(e =>
      e.classList.remove("active"));
    !e && id && document.getElementById(id).closest('.rt-tr-group').classList.add('active');
    await this.setState({ showDetailView: false, showSelected: true });
    await this.setState({
      showDetailView: true, code: code, name: name, source: "CUST"
    });
    await scrollToComponent(this.details, { offset: 0, align: 'top', duration: 1500 });
  }

  handleMenuPopupAction = (event, data) => {
    let tempId = event.target.id.split("_");
    let source = tempId[0].split("-")[0];
    if (tempId[1] == "viewPayment") {
      if (this.state.selectedTab == "CUSTOMER") {
        this.setState({ openPaymentModal: true, saleOrderId: tempId[0], type: data ? data : "" , source : source });
      } else {
        this.setState({ openPaymentModal: true, purchaseOrderId: tempId[0], type: data ? data : "", source: source });
      }
    }
  }

  getDetails = (event, data) => {
    this.handleMenuPopupAction(event, data)
  }

  getPaymentModalDetails = () => {
    this.setState({ openPaymentModal: false });
  }

  getBulkPaymentModalDetails = (flag) => {
    this.setState({ openBulkPaymentModal: false, showSelected: flag });
  }
  bulkPaymentOpen = async (code, name, openingBalance, source) => {
    await this.setState({ openBulkPaymentModal: true, code: code, name: name, source: source,openingBalance:openingBalance });
  }

  openOrderDetailsWindow = (orderCode) => {
    let tempId = orderCode !== null ? orderCode.split("-") : null;
    let orderType = tempId[0];
    this.props.setActionMode(commonConstant.VIEW_ACTION_MODE);
    if (orderType == "PO") {
      this.props.setSelectedPurchaseOrderCode(CommonUtil.getNumberFromCode(orderCode));
    } else if (orderType == "SO") {
      this.props.setSelectedSaleOrderCode(CommonUtil.getNumberFromCode(orderCode));
    }
    this.setState({ alert: null, openModal: false, submitted: false, orderDetailsModal: true, orderType: orderType, orderCode: orderCode, reload: false });
  }

  handlePopupCancel = () => {
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    this.setState({ alert: null, openModal: true, submitted: false, orderDetailsModal: false });
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter, search, status, showDetailView, tableChildColumnList, tableChildConfig, tableChildDataList, selectedTab, orderType, orderCode } = this.state;
    const MANAGE_PAGE_TAB_LIST = financeConstant.MANAGE_PAGE_TAB_LIST;
    const MANAGE_PAGE_LEDGER_TAB_LIST = (isAuthorized("viewCustomerSupplier") && isAuthorized("viewCustomerFinance")) ? financeConstant.MANAGE_PAGE_LEDGER_TAB_LIST : isAuthorized("viewCustomerFinance") ? financeConstant.MANAGE_PAGE_CUSTOMER_LEDGER_TAB_LIST : isAuthorized("viewCustomerSupplier") ? financeConstant.MANAGE_PAGE_SUPPLIER_LEDGER_TAB_LIST : [];

    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={trace} alt="" className="page-icon" />
                  {financeConstant.MANAGE_FINANCE_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl
                        type="text"
                        name="searchInput"
                        placeholder={this.state.mainSelectedTab == "EXPENSE" ? "Search by Order Number/Account" : "Search by Name"}
                        value={this.state.searchInput}
                        onChange={this.handleChange}
                      />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {status || search ?
                      <div className="showfilter">
                        Search / Filter by:
                        {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                        {status ?
                          <div className="filtertag">{StatusUtil.getStatusLabel(status)} <i id="filter-status" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <Tabs id="manage-finance-tabs" activeKey={this.state.mainSelectedTab} onSelect={this.handleMainTabClick} className="table-tabs">
                      {(isAuthorized("viewCustomerSupplier") || isAuthorized("viewCustomerFinance")) && <Tab eventKey="LEDGER" title="LEDGER">
                        <FormGroup className="location-dropdown" style={{ right: '205px', top: '5px' }}>
                          <div className="location-control">
                            <img src={pin} alt="" />
                            <div title={this.state.locationName} >
                              <Select
                                classNamePrefix="react-select"
                                name="location"
                                placeholder="Location"
                                value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                                onChange={(value) => this.handleLocationDropdownChange(value)}
                                options={[...this.state.facilityList]} />
                            </div>
                          </div>
                        </FormGroup>
                        <Tabs id="manage-mfg-resource-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-sub-tabs">
                          {MANAGE_PAGE_LEDGER_TAB_LIST.map((tempTabObj, index) => (
                            <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                              {tableColumnList != null ?
                                <Row>
                                  {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getUpdatedTableDataList={this.getUpdatedTableDataList}
                                      that={this}
                                    />
                                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                </Row>
                                : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                            </Tab>

                          ))}
                          {showDetailView && <LedgerChildTable code={this.state.code} source={this.state.source} getDetails={this.getDetails} selectedTab={this.state.selectedTab} facilityId={this.state.location} openOrderDetailsWindow={this.openOrderDetailsWindow}></LedgerChildTable>}
                        </Tabs>
                      </Tab>}
                      {isAuthorized("viewExpense") && <Tab eventKey="EXPENSE" title="EXPENSE">
                        <FormGroup className="location-dropdown" style={{ right: '270px', top: '5px' }}>
                          <div className="location-control">
                            <img src={pin} alt="" />
                            <div title={this.state.locationName} >
                              <Select
                                classNamePrefix="react-select"
                                name="location"
                                placeholder="Location"
                                value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                                onChange={(value) => this.handleLocationDropdownChange(value)}
                                options={[...this.state.facilityList]} />
                            </div>
                          </div>
                        </FormGroup>
                        <Tabs id="manage-mfg-order-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick} className="table-sub-tabs">
                          {MANAGE_PAGE_TAB_LIST.map((tempTabObj, index) => (
                            <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                              {tableColumnList != null ?
                                <Row>
                                  {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getUpdatedTableDataList={this.getUpdatedTableDataList}
                                      that={this}
                                    />
                                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                </Row>
                                : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                            </Tab>

                          ))}
                        </Tabs>
                      </Tab>}
                      {this.state.openPaymentModal == true ?
                        <PaymentProcessModal
                          saleOrderId={this.state.saleOrderId}
                          purchaseOrderId={this.state.purchaseOrderId}
                          selectedTab={this.state.selectedTab}
                          source={this.state.source}
                          getPaymentModalDetails={this.getPaymentModalDetails}
                          paymentList={this.state.paymentList}
                          facilityId={this.state.location}
                          type={this.state.type}
                          that={this}
                        >
                        </PaymentProcessModal>
                        : null}

                      {this.state.code && this.state.openBulkPaymentModal == true ?
                        <BulkPayment
                          code={this.state.code}
                          name={this.state.name}
                          source={this.state.source}
                          selectedTab={this.state.selectedTab}
                          facilityId={this.state.location}
                          openingBalance={this.state.openingBalance}
                          getBulkPaymentModalDetails={this.getBulkPaymentModalDetails}
                          that={this}
                        >
                        </BulkPayment>
                        : null}

                    </Tabs>
                    {this.state.orderDetailsModal == true ?
                      <Modal show={this.state.orderDetailsModal} onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false} className="order-detail-modal">
                        <Modal.Header closeButton></Modal.Header>
                        <Modal.Body>
                          {orderType == "PO" && <CreatePurchaseOrder purchaseOrderCode={orderCode} insideInventory={true}></CreatePurchaseOrder>}
                          {orderType == "SO" && <CreateSaleOrder saleOrderCode={orderCode} insideInventory={true}></CreateSaleOrder>}
                        </Modal.Body>
                      </Modal>
                      : null
                    }
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    financeList: state.finance.financeList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    facilityList: state.facility.facilityList,
    supplierList: state.supplier.supplierList,
    productList: state.product.productList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    financeSearchList: state.finance.financeSearchList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getFinanceList: (id) => dispatch(getFinanceList(id)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getSupplierList: (params) => dispatch(getSupplierList(params)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getFinanceSearchList: params => dispatch(getFinanceSearchList(params)),
  setSelectedPurchaseOrderCode: (selectedSaleOrderCode) => dispatch(setSelectedPurchaseOrderCode(selectedSaleOrderCode)),
  setSelectedSaleOrderCode: selectedSaleOrderCode => dispatch(setSelectedSaleOrderCode(selectedSaleOrderCode)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ManageFinance);
