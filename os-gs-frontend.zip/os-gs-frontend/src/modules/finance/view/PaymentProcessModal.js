import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { Redirect } from "react-router-dom";
import { getSaleOrderPaymentDetails } from "../../saleOrderAMS/actions/saleOrderActions";
import { getPurchaseOrderPaymentDetails } from "../../purchaseOrderAMS/actions/purchaseOrderActions";
import { getSupplierPaymentDetails } from "../../supplierManagement/actions/supplierActions"
import { getCustomerPaymentDetails } from "../../customer/actions/customerActions"
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as commonConstant from "../../common/constant/commonConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import ValidationUtil from "../../common/util/validationUtil";
import PopularTableUtil from '../../common/util/popularTableUtil';
import { setActionMode } from "../../../actions/appActions";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import currencyIcon from '../../common/util/currencyIcon';
var Modal = require('react-bootstrap-modal')

class PaymentProcessModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: {},
      submitted: false,
      customErrorFlag: false,
      redirect: false,
      redirectUrl: null,
      alert: null,
      tableDataKey: "tableDataList",
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    const managePageList = pagePropertyListConstant["PAYMENT_PROCESS_" + this.props.selectedTab + "_PAGE_LIST"](this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
    if (this.props.selectedTab == "CUSTOMER" && this.props.source == "SO") {
      this.props.getSaleOrderPaymentDetails(CommonUtil.getNumberFromCode(this.props.saleOrderId));
    } else if (this.props.selectedTab == "CUSTOMER" && this.props.source == "CUST") {
      this.props.getCustomerPaymentDetails({ facilityId: this.props.facilityId, customerId: CommonUtil.getNumberFromCode(this.props.saleOrderId)  });
    } else if (this.props.selectedTab == "SUPPLIER" && this.props.source == "PO") {
      this.props.getPurchaseOrderPaymentDetails(CommonUtil.getNumberFromCode(this.props.purchaseOrderId));
    } else if (this.props.selectedTab == "SUPPLIER" && this.props.source == "SUP") {
      this.props.getSupplierPaymentDetails({ facilityId: this.props.facilityId, supplierId: CommonUtil.getNumberFromCode(this.props.purchaseOrderId) });
    }
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.attributeObjPurchase != null && prevProps.attributeObjPurchase != this.props.attributeObjPurchase) {
      this.updateApiData(this.props.attributeObjPurchase);
    }
    if (this.props.attributeObjCustomer != null && prevProps.attributeObjCustomer != this.props.attributeObjCustomer) {
      this.updateApiData(this.props.attributeObjCustomer);
    }
    if (this.props.attributeObjSupplier != null && prevProps.attributeObjSupplier != this.props.attributeObjSupplier) {
      this.updateApiData(this.props.attributeObjSupplier);
    }
  }

  updateApiData(attributeObj) {
    this.setState({
      attributeObj: {
        ...attributeObj,
        totalValue: attributeObj.totalValue || attributeObj.actualOpeningBalance,
      },
      totalPaidAmount: attributeObj.paymentDetailsList.length > 0 ? this.getTotalReceivedAmount(attributeObj.paymentDetailsList) : 0,
      tableDataList: attributeObj.paymentDetailsList.length > 0 ? [...attributeObj.paymentDetailsList] : [{}],
      totalDiscountAmount: attributeObj.products ? this.getTotalDiscountAmount(attributeObj.products) : 0,
    });
  }

  getTotalReceivedAmount = (paymentDetailsList) => {
    let totalPaidAmount = 0;
    if (CommonUtil.isNotNull(paymentDetailsList) && paymentDetailsList.length > 0) {
      for (let i = 0; i < paymentDetailsList.length; i++) {
        totalPaidAmount = CommonUtil.getTotalValue(totalPaidAmount, paymentDetailsList[i].receivedAmount);
      }
    }
    return totalPaidAmount;
  }

  getTotalDiscountAmount = (products) => {
    let totalDiscountAmount = 0;
    if (CommonUtil.isNotNull(products) && products.length > 0) {
      for (let i = 0; i < products.length; i++) {
        totalDiscountAmount = CommonUtil.getTotalValue(totalDiscountAmount, products[i].discount);
      }
    }
    return totalDiscountAmount;
  }


  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.setState({ openModal: false, submitted: false });
      this.setState({ alert: null });
      this.props.setAjaxCallStatus(null);
      this.props.getPaymentModalDetails(true);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
    }
  };

  handlePopupCancel = () => {
    this.props.getPaymentModalDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { submitted, tableColumnList, tableConfig, tableDataList, attributeObj, totalDiscountAmount } = this.state;
    const currencyCode = this.props.currencyCode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">{this.props.type} Payment Status</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="automation">
                            <Row>
                              <Col md={3} className="automation-details">
                                <div className="heading">Order Number</div>
                                <div className="value">{this.props.selectedTab == "CUSTOMER" ? this.props.saleOrderId : this.props.purchaseOrderId}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Total Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,CommonUtil.getFloatValue(attributeObj.totalValue) -
                                  CommonUtil.getFloatValue(totalDiscountAmount))}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Paid Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Pending Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,CommonUtil.getFloatValue(attributeObj.totalValue)
                                  - CommonUtil.getFloatValue(totalDiscountAmount)
                                  - CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                                {this.state.customErrorFlag && (
                                  <small className="text-danger">
                                    Received amount is higher than pending amount.
                              </small>
                                )}
                              </Col>
                            </Row>
                            {tableColumnList != null ?
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) ?
                                  <>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />

                                  </>
                                  : null}
                              </Row>
                              : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    attributeObj: state.saleOrder.saleOrderPaymentDetails,
    attributeObjPurchase: state.purchaseOrder.purchaseOrderPaymentDetails,
    attributeObjCustomer: state.customer.customerPaymentDetails,
    attributeObjSupplier: state.supplier.supplierPaymentDetails,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getSaleOrderPaymentDetails: selectedSaleOrderCode => dispatch(getSaleOrderPaymentDetails(selectedSaleOrderCode)),
  getPurchaseOrderPaymentDetails: (selectedPurchaseOrderCode) => dispatch(getPurchaseOrderPaymentDetails(selectedPurchaseOrderCode)),
  getCustomerPaymentDetails: params => dispatch(getCustomerPaymentDetails(params)),
  getSupplierPaymentDetails: (params) => dispatch(getSupplierPaymentDetails(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(PaymentProcessModal);
