import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { Redirect } from "react-router-dom";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as commonConstant from "../../common/constant/commonConstant";
import { getSaleOrderList } from "../../saleOrderAMS/actions/saleOrderActions";
import { getPurchaseOrderList } from "../../purchaseOrderAMS/actions/purchaseOrderActions";
import { updatePurchaseOrderPayment } from "../../purchaseOrderAMS/actions/purchaseOrderActions";
import { updateSaleOrderPayment } from "../../saleOrderAMS/actions/saleOrderActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import ValidationUtil from "../../common/util/validationUtil";
import PopularTableUtil from '../../common/util/popularTableUtil';
import { setActionMode } from "../../../actions/appActions";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import currencyIcon from '../../common/util/currencyIcon';
var Modal = require('react-bootstrap-modal')

class BulkPayment extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: {},
      submitted: false,
      customErrorFlag: false,
      redirect: false,
      redirectUrl: null,
      alert: null,
      tableDataKey: "tableDataList",
      balanceDetails: {},
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    let source = this.props.source;
    const managePageList = pagePropertyListConstant["BULK_PAYMENT_PROCESS_" + source + "_PAGE_LIST"](this);
    if (source == "CUST") {
      var additionalParams = { location: this.props.facilityId, customerId: this.props.code };
      this.props.getSaleOrderList(additionalParams);
    } else if (source == "SUP") {
      var additionalParams = { location: this.props.facilityId, supplierId: this.props.code };
      this.props.getPurchaseOrderList(additionalParams);
    }
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.saleOrderList != null && prevProps.saleOrderList != this.props.saleOrderList) {
      this.updateApiData(this.props.saleOrderList);
    }
    if (this.props.purchaseOrderList != null && prevProps.purchaseOrderList != this.props.purchaseOrderList) {
      this.updateApiData(this.props.purchaseOrderList);
    }
  }

  async updateApiData(attributeObj) {
    await this.setState({
      totalPaidAmount: attributeObj && this.getTotalReceivedAmount(attributeObj, 'totalPaidAmount'),
      totalValue: attributeObj && this.getTotalReceivedAmount(attributeObj, 'totalValue')
        + CommonUtil.getFloatValue(this.props.openingBalance, true),
      tableDataList: [{}]
    });
  }

  getTotalReceivedAmount = (paymentList, option) => {
    let totalPaidAmount = 0;
    if (CommonUtil.isNotNull(paymentList) && paymentList.length > 0) {
      for (let i = 0; i < paymentList.length; i++) {
        totalPaidAmount = CommonUtil.getFloatValue(totalPaidAmount, true) + CommonUtil.getFloatValue(paymentList[i][option], true);
      }
    }
    return totalPaidAmount;
  }

  handleTableTextBoxChange = (event) => {
    this.setState({ customErrorFlag: false });
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  handleTableSwitchChange = (event, state) => {
    PopularTableUtil.handleTableSwitchChange(event, state, this, this.getSelectedTablekey());
  }

  handleTableRemove = (event) => {
    PopularTableUtil.handleTableRemove(event, this, this.getSelectedTablekey());
  };

  handleTableDateChange = (event, eventId) => {
    PopularTableUtil.handleTableDateChange(event, eventId, this, this.getSelectedTablekey());
  };

  handleTableAddRow = (event) => {
    PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
  }

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.setState({ openModal: false, submitted: false });
      this.setState({ alert: null });
      this.props.setAjaxCallStatus(null);
      this.props.getBulkPaymentModalDetails(true);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  getTdProps = (event) => {
    let tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
    }
  };

  handleSave = async (event) => {
    this.setState({ submitted: true });
    const { tableDataList, attributeObj } = this.state;
    let code = this.props.source.toUpperCase();
    let tempObj = {};
    tempObj.paymentList = [...tableDataList];

    let totalPaidAmount = this.getTotalReceivedAmount(tempObj.paymentList, 'receivedAmount');
    if (CommonUtil.getFloatValue(totalPaidAmount, true) > (CommonUtil.getFloatValue(this.state.totalValue, true) -
      CommonUtil.getFloatValue(this.state.totalPaidAmount, true))) {
      this.setState({ customErrorFlag: true });
      return true;
    }

    tempObj.paymentList = ValidationUtil.removeAttributeFromArrayList(tempObj.paymentList,
      pagePropertyListConstant["BULK_PAYMENT_PROCESS_" + code + "_PAGE_LIST"](this).tableColumnList,
      commonConstant.EDIT_ACTION_MODE);

    if (!ValidationUtil.validateArrayListRequestObj(tempObj.paymentList,
      pagePropertyListConstant["BULK_PAYMENT_PROCESS_" + code + "_PAGE_LIST"](this).tableColumnList)) {
      return false;
    }
    let temp = true;
    if (tempObj.paymentList && tempObj.paymentList.length > 0) {
      tempObj.paymentList.map(x => {
        if(CommonUtil.getFloatValue(x.receivedAmount, true) == 0) {
          temp = false;
        }
      })
    }
    if(temp) {
      tempObj.orderId = this.props.code;
      tempObj.isBulkPayment = true;
      tempObj.facilityId = this.props.facilityId;
      if (code == "CUST") {
        await this.props.updateSaleOrderPayment(tempObj);
      } else if (code == "SUP") {
        await this.props.updatePurchaseOrderPayment(tempObj);
      }
  
      await this.props.getBulkPaymentModalDetails(true);
      await this.setState({ openModal: false });
    }
  }

  handlePopupCancel() {
    this.props.getBulkPaymentModalDetails(false);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { submitted, tableColumnList, tableConfig, tableDataList, attributeObj } = this.state;
    const currencyCode = this.props.currencyCode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Process Payment | {this.props.name} | {this.props.code}</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div className="automation">
                            <Row>
                              <Col md={3} className="automation-details">
                                <div className="heading">Total Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, this.state.totalValue)}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Paid Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                              </Col>
                              <Col md={3} className="automation-details">
                                <div className="heading">Pending Amount</div>
                                <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode, CommonUtil.getFloatValue(this.state.totalValue) -
                                  CommonUtil.getFloatValue(this.state.totalPaidAmount))}</div>
                                {this.state.customErrorFlag && (
                                  <small className="text-danger">
                                    {this.props.source == "CUST" ? "Received amount is higher than pending amount." : "Paid amount is higher than pending amount."}
                                  </small>
                                )}
                              </Col>
                            </Row>
                            {tableColumnList != null ?
                              <Row>
                                {(tableDataList != null && tableDataList.length > 0) ?
                                  <>
                                    <Table columns={tableColumnList}
                                      data={tableDataList}
                                      config={tableConfig}
                                      getRowProps={this.getTdProps}
                                      that={this}
                                    />

                                  </>
                                  : null}
                              </Row>
                              : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                          </div>
                        }
                        ftTextRight
                        legend={
                          <div>
                            <Button className="btn-cancel" onClick={this.handlePopupCancel}>Cancel</Button>
                            <Button className="btn-save btn-fill" onClick={this.handleSave} >Save</Button>
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    saleOrderList: state.saleOrder.saleOrderList,
    purchaseOrderList: state.purchaseOrder.purchaseOrderList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getSaleOrderList: id => dispatch(getSaleOrderList(id)),
  getPurchaseOrderList: (id) => dispatch(getPurchaseOrderList(id)),
  updatePurchaseOrderPayment: obj => dispatch(updatePurchaseOrderPayment(obj)),
  updateSaleOrderPayment: obj => dispatch(updateSaleOrderPayment(obj)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(BulkPayment);
