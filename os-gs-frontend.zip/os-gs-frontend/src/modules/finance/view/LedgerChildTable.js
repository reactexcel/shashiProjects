import React, { Component } from "react";
import { Row, Col, Tab, Tabs } from "react-bootstrap";
import * as financeConstant from "../constant/financeConstant";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import { connect } from "react-redux";
// import { getFinanceSupplierList, getFinanceCustomerList } from "../actions/financeActions";
import CommonUtil from "../../common/util/commonUtil";
import { setActionMode } from "../../../actions/appActions";
import PaginationUtil from "../../common/util/paginationUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { getUserProfile } from "../../userManagement/actions/userActions";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import PopupUtil from '../../common/util/popupUtil';
import { getSaleOrderList } from "../../saleOrderAMS/actions/saleOrderActions";
import { getPurchaseOrderList } from "../../purchaseOrderAMS/actions/purchaseOrderActions";

class LedgerChildTable extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,
      selectedTab: "CUSTOMER",
      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      openPaymentModal: false,
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
  }

  componentDidMount = async () => {
    const { selectedTab } = this.props;
    (selectedTab == "CUSTOMER" || selectedTab == "SUPPLIER") && await this.setSelectedTabDetails(selectedTab);
  };

  setSelectedTabDetails = async (selectedTab) => {
    let managePageList = pagePropertyListConstant["MANAGE_" + selectedTab + "_CHILD_FINANCE_PAGE_LIST"](this);
    let additionalParams = null;
    if (this.props.source == "CUST") {
      additionalParams = { location: this.props.facilityId, customerId: this.props.code };
    } else {
      additionalParams = { location: this.props.facilityId, supplierId: this.props.code };
    }

    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      lastEvaluatedKeyArray: [],
      selectedTab: selectedTab,
      searchInput: "",
      limit: managePageList.tableConfig.defaultPageSize,
      additionalParams: additionalParams
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  };

  handleTabClick = (label, event) => {
    PaginationUtil.initPaginationParams(this);
    let selectedTabKey = label.toUpperCase();
    this.setSelectedTabDetails(selectedTabKey);
  };

  componentDidUpdate(prevProps) {
    if (this.props.purchaseOrderList != null && prevProps.purchaseOrderList != this.props.purchaseOrderList) {
      this.handleCustomPagination();
    }
    if (this.props.saleOrderList != null && prevProps.saleOrderList != this.props.saleOrderList) {
      this.handleCustomPagination();
    }
  }


  handleCustomPagination = () => {
    const { selectedTab } = this.props;
    if (selectedTab == "SUPPLIER" && CommonUtil.isNotNull(this.props.purchaseOrderList)) {
      PaginationUtil.handlePagination(this.props.purchaseOrderList, this);
    } else if (selectedTab == "CUSTOMER" && CommonUtil.isNotNull(this.props.saleOrderList)) {
      PaginationUtil.handlePagination(this.props.saleOrderList, this);
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      PaginationUtil.initPaginationParams(this);
      this.setSelectedTabDetails(this.state.selectedTab);
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      await this.props.setAjaxCallStatus(null);
    }
  }

  async makeCustomAPICall(tempParamas) {
    const { source } = this.props;
    let tempCode = source
    if (CommonUtil.isNotNull(tempCode)) {
      if (tempCode == "SUP") {
        await this.props.getPurchaseOrderList(tempParamas);
      } else if (tempCode == "CUST") {
        await this.props.getSaleOrderList(tempParamas);
      }
    }
  }

  handleMenuPopupAction = (event) => {
    this.props.getDetails(event)
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <>
        {tableDataList != null ?
          <Row className="child-element" ref={(section) => { this.details = section; }}>
            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
              <Table columns={tableColumnList}
                data={tableDataList}
                config={tableConfig}
                that={this}
              />
              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
          </Row>
          : null
        }
      </>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    // financeSupplierList: state.finance.financeSupplierList,
    // financeCustomerList: state.finance.financeCustomerList,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    currencyCode: state.dataDictionary.currencyCode,
    saleOrderList: state.saleOrder.saleOrderList,
    purchaseOrderList: state.purchaseOrder.purchaseOrderList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  // getFinanceSupplierList: (id, params) => dispatch(getFinanceSupplierList(id, params)),
  // getFinanceCustomerList: (id, params) => dispatch(getFinanceCustomerList(id, params)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getSaleOrderList: id => dispatch(getSaleOrderList(id)),
  getPurchaseOrderList: (id) => dispatch(getPurchaseOrderList(id)),
});
export default connect(mapStateToProps, mapDispatchToProps)(LedgerChildTable);
