import * as dashboardConstant from './dashboardConstant';
import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import {
  participant,
  productOwner,
  superUser
} from "../../../constants/GlobalConstants";
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';

export const DASHBOARD_PAGE_LIST =
{
  attributeObj: {
    leadCaptureCount: '',
    pageVisitCount: '',
    batchWithoutQRCodeCount: '',
    incompleteBatchCount: '',
    batchWithoutCMSCount: '',
    leadCaptureIconText: 'Last 30 days',
    pageVisitsIconText: 'Last 7 days',
    topProductList: '',
  },
  attributeListQuickInfo: [
    {
      name: "topProductList",
      value: 100,
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_LEAD_CAPTURE_KEY,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Lead Capture",
      statsSubLeftIcon: 'calendar',
      statsSubLeftIconText: 'leadCaptureIconText',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner],
    },
    {
      name: "leadCaptureCount",
      value: 100,
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_LEAD_CAPTURE_KEY,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Lead Capture",
      statsSubLeftIcon: 'calendar',
      statsSubLeftIconText: 'leadCaptureIconText',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner],
    },
    {
      name: "pageVisitCount",
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_PAGE_VISIT_KEY,
      cardIcon: 'pe-7s-wallet text-success',
      cardTitle: "Page Visits",
      statsSubLeftIcon: 'calendar',
      statsSubLeftIconText: 'pageVisitsIconText',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner],
    },
    {
      name: "incompleteBatchCount",
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_INCOMPLETE_BATCH_KEY,
      cardIcon: 'pe-7s-graph1 text-danger',
      cardTitle: "Incomplete Batches",
      statsSubLeftIcon: '',
      statsSubLeftIconText: '',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner, participant],
    },
    {
      name: "batchWithoutQRCodeCount",
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_INCOMPLETE_QRCODE_KEY,
      cardIcon: 'pe-7s-target text-warning',
      cardTitle: "Batch without QR Code",
      statsSubLeftIcon: '',
      statsSubLeftIconText: '',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner, participant],
    },
    {
      name: "batchWithoutCMSCount",
      type: "INFOCARD",
      lgWidth: "5ths",
      smWidth: "5ths",
      pageType: dashboardConstant.MANAGE_INCOMPLETE_CMS_KEY,
      cardIcon: 'pe-7s-display2 text-warning',
      cardTitle: "Batch without CMS",
      statsSubLeftIcon: '',
      statsSubLeftIconText: '',
      statsSubRightIcon: '',
      statsSubRightIconText: 'View Detail',
      allowedPermissions: [superUser, productOwner, participant],
    }
  ],
  attributeListDetailed: [
    {
      name: "batchList",
      type: "DETAILCARD",
      pageType: "MANAGE-BATCH",
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Most Recent Batches",
      statsSubLeftIcon: 'fa fa-calendar-o',
      statsSubLeftIconText: 'Calendar',
      statsSubRightIcon: 'fa fa-calendar-o',
      statsSubRightIconText: 'Calendar',
      viewMoreFlag: true,
      allowedPermissions: [superUser, productOwner, participant],
    },
    {
      name: "documentList",
      type: "DETAILCARD",
      pageType: "MANAGE-DOCUMENT",
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Documents going to expire in 30 days",
      statsSubLeftIcon: 'fa fa-calendar-o',
      statsSubLeftIconText: 'Calendar',
      statsSubRightIcon: 'fa fa-calendar-o',
      statsSubRightIconText: 'Calendar',
      viewMoreFlag: true,
      allowedPermissions: [superUser],
    },
    {
      name: "quickLinks",
      type: "DETAILCARD",
      pageType: dashboardConstant.MANAGE_QUICK_LINK_KEY,
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Quick Links",
      statsSubLeftIcon: '',
      statsSubLeftIconText: '',
      statsSubRightIcon: '',
      statsSubRightIconText: '',
      viewMoreFlag: false,
      allowedPermissions: [superUser, productOwner],
    },
  ]
};


export const QUICKLINK_PAGE_LIST =
{
  attributeObj: {

  },
  attributeList: [
    {
      id: dashboardConstant.CREATE_PRODUCT,
      name: "createProduct",
      type: "QUICK-LINKS",
      icon: 'fa fa-product-hunt',
      title: "Create Product",
      pageURL: '',
    },
    {
      id: dashboardConstant.CREATE_SUPPLIER,
      name: "createSupplier",
      type: "QUICK-LINKS",
      icon: 'fa fa-truck',
      title: "Create Supplier",
      pageURL: '',
    },
    {
      id: dashboardConstant.CREATE_FACILITY,
      name: "createFacility",
      type: "QUICK-LINKS",
      icon: 'fa fa-home',
      title: "Create Facility",
      pageURL: '',
    },
    {
      id: dashboardConstant.CREATE_FACILITY,
      name: "createUser",
      type: "QUICK-LINKS",
      icon: 'fa fa-user-plus',
      title: "Create User",
      pageURL: '',
    },

  ],
  attributeListDetailed: [
    {
      name: "batchList",
      type: "DETAILCARD",
      pageType: "MANAGE-BATCH",
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Most Recent Batches",
      statsSubLeftIcon: 'fa fa-calendar-o',
      statsSubLeftIconText: 'Calendar',
      statsSubRightIcon: 'fa fa-calendar-o',
      statsSubRightIconText: 'Calendar',
      viewMoreFlag: true,
    },
    {
      name: "documentList",
      type: "DETAILCARD",
      pageType: "MANAGE-DOCUMENT",
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Documents going to expire in 30 days",
      statsSubLeftIcon: 'fa fa-calendar-o',
      statsSubLeftIconText: 'Calendar',
      statsSubRightIcon: 'fa fa-calendar-o',
      statsSubRightIconText: 'Calendar',
      viewMoreFlag: true,
    },
    {
      name: "quickLinks",
      type: "DETAILCARD",
      pageType: dashboardConstant.MANAGE_QUICK_LINK_KEY,
      lgWidth: 6,
      smWidth: 6,
      cardIcon: 'pe-7s-server text-warning',
      cardTitle: "Quick Links",
      statsSubLeftIcon: '',
      statsSubLeftIconText: '',
      statsSubRightIcon: '',
      statsSubRightIconText: '',
      viewMoreFlag: false,
    },
  ]
};


export const MANAGE_SUPPLIER_DOCUMENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Document Name",
        id: "documentName",
        accessor: "documentName",
        dashboardColumn: true,
      },
      {
        Header: "Supplier Code",
        id: "supplierId",
        accessor: "supplierId",
        dashboardColumn: false,
      },
      {
        Header: "Supplier Name",
        id: "supplierName",
        accessor: "supplierName",
        dashboardColumn: true,
      },
      {
        Header: "Expiry Date",
        id: "documentExpiryDate",
        accessor: "documentExpiryDate",
        dashboardColumn: true,
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        sortable: false,
        width: 95,
        className: "action",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon >
                <div className="circle"><i title="edit" id={original.supplierId + "_" + dashboardConstant.EDIT_ACTION_MODE + '_' + index} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
                <div className="circle"><a href={original.documentURL} download="pp">
                  <i title="download" id={original.supplierId + "_" + dashboardConstant.DOWNLOAD_ACTION_MODE + '_' + index} className="fa fa-download" onClick={(e) => that.getTdProps(e)} />
                </a></div>
              </Button>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: ""
        }
      ],
      defaultSortedList: [
        {
          id: "modifieddate",
          desc: true
        }
      ],
      defaultPageSize: 10,
      rowId: 'supplierId',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_FACILITY_DOCUMENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Document",
        id: "documentName",
        accessor: "documentName"
      },
      {
        Header: "Facility Code",
        id: "facilityId",
        accessor: "facilityId"
      },
      {
        Header: "Facility Name",
        id: "facilityName",
        accessor: "facilityName"
      },
      {
        Header: "Expiry Date",
        id: "documentExpiryDate",
        accessor: "documentExpiryDate"
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        sortable: false,
        width: 95,
        className: "action",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">
              <Button bsStyle="default" simple icon >
                <div className="circle"><i title="edit" id={original.facilityId + "_" + dashboardConstant.EDIT_ACTION_MODE + '_' + index} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
                <div className="circle"><a href={original.documentURL} download="pp">
                  <i title="clone" id={original.facilityId + "_" + dashboardConstant.DOWNLOAD_ACTION_MODE + '_' + index} className="fa fa-download" onClick={(e) => that.getTdProps(e)} />
                </a></div>
              </Button>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: ""
        }
      ],
      defaultSortedList: [
        {
          id: "modifieddate",
          desc: true
        }
      ],
      defaultPageSize: 10,
      rowId: 'facilityId',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};


export const DASHBOARD_MANAGE_SUPPLIER_DOCUMENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Document",
        id: "documentName",
        accessor: "documentName",
        disableSortBy: true,
        disableFilters: true,
        dashboardColumn: true,
      },
      {
        Header: "Supplier",
        id: "supplierName",
        accessor: "supplierName",
        disableSortBy: true,
        disableFilters: true,
        dashboardColumn: true,
      },
      {
        Header: "Expiry Date",
        id: "documentExpiryDate",
        accessor: "documentExpiryDate",
        disableSortBy: true,
        disableFilters: true,
        dashboardColumn: true,
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        sortable: false,
        width: 95,
        className: "action",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div>
              <Button bsStyle="default" simple icon >
                <div className="circle"><i title="edit" id={original.supplierId + "_" + dashboardConstant.EDIT_ACTION_MODE + '_' + index} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
              </Button>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: ""
        }
      ],
      defaultSortedList: [
        {
          id: "modifieddate",
          desc: true
        }
      ],
      defaultPageSize: 10,
      rowId: 'supplierId',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }

};

export const DASHBOARD_MANAGE_FACILITY_DOCUMENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Document",
        id: "documentName",
        accessor: "documentName",
        disableSortBy: true,
        disableFilters: true,
      },
      {
        Header: "Facility",
        id: "facilityName",
        accessor: "facilityName",
        disableSortBy: true,
        disableFilters: true,

      },
      {
        Header: "Expiry Date",
        id: "expiryDate",
        accessor: "documentExpiryDate",
        disableSortBy: true,
        disableFilters: true,
      },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        sortable: false,
        width: 95,
        className: "action",
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div>
              <Button bsStyle="default" simple icon >
                <div className="circle"><i title="edit" id={original.facilityId + "_" + dashboardConstant.EDIT_ACTION_MODE + '_' + index} className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} /></div>
              </Button>
            </div>
          )
        }
      }
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: ""
        }
      ],
      defaultSortedList: [
        {
          id: "modifieddate",
          desc: true
        }
      ],
      defaultPageSize: 10,
      rowId: 'facilityId',
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_DASHBOARD_INCIDENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "#",
        id: "code",
        accessor: "code",
      },
      {
        Header: "Type",
        id: "type",
        accessor: "type"
      },
      {
        Header: "Created",
        id: "create",
        accessor: "create"
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status"
      },
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: ""
        }
      ],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    }
  }
};

export const MANAGE_INCOMING_SHIPMENT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "purchaseOrderId",
        accessor: "purchaseOrderId",
      },
      // {
      //   Header: "Pallet#",
      //   id: "paletteNumber",
      //   accessor: "paletteNumber",
      //   disableSortBy: true,
      // },
      {
        Header: "Lot #",
        id: "lotNumber",
        accessor: "lotNumber",
        disableSortBy: true,
      },
      {
        Header: "ETA Date",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        disableSortBy: true,
      },
      {
        Header: "Supplier Type",
        id: "supplierType",
        accessor: "supplierType",
        disableSortBy: true,
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: '0 0 120px'
        },
        disableSortBy: true,
        id: "status",
        Cell: ({ cell }) => {
          //const { value } = cell;
          let value = statusConstant.NEW_STATUS;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value)
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [
        {
          id: "requestedDeliveryDate",
          desc: false
        }
      ],
      defaultPageSize: 5,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};

export const MANAGE_PACKING_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Order#",
        id: "saleOrderId",
        accessor: "saleOrderId",
      },
      // {
      //   Header: "Pallet#",
      //   id: "paletteNumber",
      //   accessor: "paletteNumber",
      //   disableSortBy: true,
      // },
      // {
      //   Header: "Lot #",
      //   id: "lotNumber",
      //   accessor: "lotNumber",
      //   disableSortBy: true,
      // },
      // {
      //   Header: "Consignee Name",
      //   id: "ConsigneeName",
      //   accessor: "ConsigneeName",
      //   disableSortBy: true,
      // },
      {
        Header: "Consignee Name",
        id: "customerName",
        accessor: "customerName",
        disableSortBy: true,
      },
      {
        Header: "ETA Date",
        id: "requestedDeliveryDate",
        accessor: "requestedDeliveryDate",
        disableSortBy: true,
      },
      {
        Header: "Status",
        id: "status",
        accessor: "status",
        style: {
          flex: '0 0 120px'
        },
        disableSortBy: true,
        id: "status",
        Cell: ({ cell }) => {
          const { value } = cell;
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(value)
            }}>
              {StatusUtil.getStatusLabel(value)}
            </div>
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [
        {
          id: "requestedDeliveryDate",
          desc: false
        }
      ],
      defaultPageSize: 5,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      isDraggable: false,
    }
  }
};
