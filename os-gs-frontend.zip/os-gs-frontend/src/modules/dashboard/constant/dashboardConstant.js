export const SUPPLIER_DETAILS_HEADER_TITLE = "Create Supplier";
export const SUPPLIER_DETAILS_SUBHEADER_TITLE = "Capturing general infrmation about Supplier"
export const MANAGE_SUPPLIER_HEADER_TITLE = "Manage Supplier";
export const LOCATION_HEADER_TITLE = "Location";
export const LOCATION_CHECKBOX_TITLE = "Set as default";
export const DOCUMENT_HEADER_TITLE = "Document";

export const ADDRESS_MANDATORY_MSG = "address is required.";
export const SUPPLIER_MODULE = "Supplier";
export const FACILITY_MODULE = "Facility";

export const DOWNLOAD_ACTION_MODE = "download";

export const CREATE_SUPPLIER = "createSupplier";
export const CREATE_PRODUCT = "createProduct";
export const CREATE_FACILITY = "createFacility";

export const CREATE_ACTION_MODE = "createMode";
export const CLONE_ACTION_MODE = "cloneMode";
export const EDIT_ACTION_MODE = "editMode";
export const DELETE_ACTION_MODE = "deleteMode";
export const VIEW_ACTION_MODE = "viewMode";
export const ACTIVE_STATUS = "Active";
export const INACTIVE_STATUS = "Inactive";
export const MENU_ACTION_MODE = "MENU";
export const DEATIVATE_SUPPLIER = "deActivate";
export const ACTIVATE_SUPPLIER = "activate";
export const UNIQUE_CODE_PREFIX = "SUP-";
export const ZERO_PAD_COUNT = 4;
export const CREATE_SUPPLIER_PAGE_URL = '/admin/create-supplier';
export const CREATE_FACILITY_PAGE_URL = '/admin/create-facility';
export const CREATE_PRODUCT_PAGE_URL = '/admin/create-product';
export const MANAGE_SUPPLIER_PAGE_URL = '/admin/manage-supplier';
export const MANAGE_QRCODE_PAGE_URL = '/admin/manage-qrcode';
export const MANAGE_DOCUMENT_PAGE_URL = '/admin/manage-document';
export const MANAGE_BATCH_PAGE_URL = '/admin/batch-detail';
export const MANAGE_LEADCAPTURE_PAGE_URL = '/admin/leadcapture';
export const MANAGE_PAGE_VISIT_PAGE_URL = '/admin/manage-page-visit';

export const VALUE_7D = 'Last 7 days';
export const VALUE_30D = 'Last 30 days';
export const VALUE_180D = 'Last 6 months';
export const VALUE_365D = 'Last 1 year';


export const BATCH_INCOMPLETE_STATUS = 'I';
export const BATCH_QR_STATUS = 'Q';
export const BATCH_CMS_STATUS = 'C';

export const MANAGE_BATCH_KEY   =  'MANAGE-BATCH';
export const MANAGE_DOCUMENT_KEY   =  'MANAGE-DOCUMENT';
export const MANAGE_QUICK_LINK_KEY   =  'MANAGE-QUICK-LINK';
export const MANAGE_LEAD_CAPTURE_KEY   =  'MANAGE-LEAD-CAPTURE';
export const MANAGE_PAGE_VISIT_KEY   =  'MANAGE-PAGE-VISIT';
export const MANAGE_INCOMPLETE_BATCH_KEY   =  'MANAGE-INCOMPLETE-BATCH';
export const MANAGE_INCOMPLETE_QRCODE_KEY   =  'MANAGE-INCOMPLETE-QRCODE';
export const MANAGE_INCOMPLETE_CMS_KEY   =  'MANAGE-INCOMPLETE-CMS';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_SUPPLIER_LIST_URL = `${BASE_URL}/suppliers`;
export const GET_SUPPLIER_DETAILS_URL = `${BASE_URL}/suppliers/`;
export const GET_GENERATED_SUPPLIER_CODE_URL = `${BASE_URL}/suppliers/getId`;
export const SET_CREATE_SUPPLIER_DETAILS_URL = `${BASE_URL}/suppliers`;
export const SET_UPDATE_SUPPLIER_DETAILS_URL = `${BASE_URL}/suppliers/`;
export const SET_UPDATE_SUPPLIER_STATUS_URL  = `${BASE_URL}/suppliers/`;
export const SET_SUPPLIER_DOCUMENTS_URL    =  `${BASE_URL}/upload`;
export const SALES_CHANNEL_COLOR_CODES = [
    "357084",
    "169d9d",
    "2eb49f",
    "293438",
    "5abe8b"];
export const dataTable = [];