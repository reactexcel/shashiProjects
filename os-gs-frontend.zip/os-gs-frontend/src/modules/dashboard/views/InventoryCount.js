import React, { Component } from "react";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getinventoryCount } from '../../inventory/actions/inventoryActions';
import { Redirect } from "react-router-dom";
import CommonUtil from '../../common/util/commonUtil';
import * as inventoryConstant from '../../inventory/constant/inventoryConstant';
import list from "assets/img/list1.svg";

class InventoryCount extends Component {

  constructor(props) {
    super(props);
    this.state = {
      inventoryCount: [],
    };
  }

  componentDidMount = () => {
    this.props.getinventoryCount();
  }

  openInventory = () => {
    CommonUtil.handlePageRedirection(inventoryConstant.MANAGE_INVENTORY_PAGE_URL, this);
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.inventoryCount != null && prevProps.inventoryCount != this.props.inventoryCount) {
      this.setState({ inventoryCount: this.props.inventoryCount });
    }
  }

  render() {
    const { inventoryCount } = this.state;
    var totalCount = CommonUtil.isNaNValue(inventoryCount.inStock + inventoryCount.outStock + inventoryCount.expectedStock);
    return (
      <div className="display-card inventory-count">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        <div className="heading">
          <div className="title"><img src={list} alt="" />Inventory</div>
          <div className="count-section">
            <div className="count" onClick={this.openInventory}>{CommonUtil.getFloatValue(totalCount)}</div>
          </div>
        </div>
        <div className="box">
          <div className="content-box">
            <div className="subheading">In Stock</div>
            <div className="number" onClick={this.openInventory}>{inventoryCount.inStock}</div>
          </div>
          <div className="content-box">
            <div className="subheading">Stock Out</div>
            <div className="number" onClick={this.openInventory}>{inventoryCount.outStock}</div>
          </div>
        </div>
        <div className="last">
          <div className="content-box">
            <div className="subheading">Expected Stock Out</div>
            <div className="number" onClick={this.openInventory}>{inventoryCount.expectedStock}</div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    inventoryCount: state.inventory.inventoryCount,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getinventoryCount: selectedParams => dispatch(getinventoryCount(selectedParams)),
});

export default connect(mapStateToProps, mapDispatchToProps)(InventoryCount);
