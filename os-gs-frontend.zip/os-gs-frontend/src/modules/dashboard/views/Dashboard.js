import React, { Component } from "react";
import { Grid, Col, Row, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import * as dashboardConstant from '../constant/dashboardConstant';
import { setTempAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import map from "lodash/map";
import isAuthorized from "auth-plugin";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import TopSellingProduct from './TopSellingProduct';
import SaleChannelCount from './SalesByChannelCount';
import SalesByChannelCost from './SalesByChannelCost';
import ProfitOverTime from './ProfitOverTime';
import SaleOrderCount from './SaleOrderCount';
import InventoryCount from './InventoryCount';
import IncidentCount from './IncidentCount';
import MfgOrderReport from './MfgOrderReport';
import MfgOrderByCostReport from './MfgOrderByCostReport';
import MfgOTIF from './MfgOTIF';
import SaleOTIF from './SaleOTIF';
import IncidentReport from "./IncidentReport";
import IncomingShipment from './IncomingShipment';
import PackingList from './PackingList';
import { getUserProfile } from "../../userManagement/actions/userActions";
import InventoryCoverage from "./InventoryCoverage";
import SupplierPerformance from './SupplierPerformance';
import dashboard from "assets/img/dashboard-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import { resetUserDetails } from "../../../actions/appActions";
import Capacity from './Capacity';
import SalesBreakDown from './SalesBreakDown';
import SalesFunnel from './SalesFunnel';

class Dashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeListQuickInfo: null,
      attributeListDetailed: null,
      ajaxTempCallStatus: null,
      attributeObj: null,
      params: null,
      categorySelect: null,
      customDate: false,
    };
    this.handleCardClick = this.handleCardClick.bind(this);
    this.getBatchRequestParams = this.getBatchRequestParams.bind(this);
    this.getCMSRequestParams = this.getCMSRequestParams.bind(this);
    this.handleAPIResponse = this.handleAPIResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Dashboard loaded");
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.props.getUserProfile();
    this.setState({
      attributeObj: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeObj,
      attributeListQuickInfo: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeListQuickInfo,
      attributeListDetailed: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeListDetailed,
    })
    const managePageList = pagePropertyListConstant.MANAGE_DASHBOARD_INCIDENT_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
    let requestFrom = await CommonUtil.getAdditonalPathParams(this);
    if (CommonUtil.isNotNull(requestFrom)) {
      await this.props.resetUserDetails(false);
      this.props.userProfile.isDummyDataDeleted = true;
      await this.setState({ alert: null });
      const { location, history } = this.props;
      history.replace();
      CommonUtil.handlePageRedirection("/admin/setting", this, "INTEGRATION");
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.incompleteBatchCount != null && prevProps.incompleteBatchCount != this.props.incompleteBatchCount) {
      this.handleAPIResponse('incompleteBatchCount');
    }
    if (this.props.batchWithoutQRCodeCount != null && prevProps.batchWithoutQRCodeCount != this.props.batchWithoutQRCodeCount) {
      this.handleAPIResponse('batchWithoutQRCodeCount');
    }
    if (this.props.batchWithoutCMSCount != null && prevProps.batchWithoutCMSCount != this.props.batchWithoutCMSCount) {
      this.handleAPIResponse('batchWithoutCMSCount');
    }
    if (this.props.leadCaptureCount != null && prevProps.leadCaptureCount != this.props.leadCaptureCount) {
      this.handleAPIResponse('leadCaptureCount');
    }
    if (this.props.pageVisitCount != null && prevProps.pageVisitCount != this.props.pageVisitCount) {
      this.handleAPIResponse('pageVisitCount');
    }
    if (this.props.topProductList != null && prevProps.topProductList != this.props.topProductList) {
      this.handleAPIResponse('topProductList');
    }
    if (this.props.ajaxTempCallStatus != null && prevProps.ajaxTempCallStatus != this.state.ajaxTempCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleAjaxResponse = async () => {
    if (this.props.ajaxTempCallStatus.status == "SUCCESS") {
      await this.setState({ ajaxTempCallStatus: this.props.ajaxTempCallStatus });
      this.props.setTempAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareResetUserSuccessPopUpConfig());
    }
  }

  handleAPIResponse(attributeName) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        [attributeName]: this.props[attributeName]
      }
    })
  }

  handleCardClick = (event) => {
    var tempId = event.target.id.split("_");
    const { attributeObj } = this.state;
    var selectedOption = dashboardConstant["VALUE_" + tempId[2]];
    this.setState({
      attributeObj: {
        ...attributeObj,
        [tempId[1]]: selectedOption
      }
    })
    if (tempId[0] == dashboardConstant.MANAGE_LEAD_CAPTURE_KEY) {
      this.props.setLeadCaptureCount(null);
      this.props.getLeadCaptureCount(this.getCMSRequestParams(tempId[2]));
    }
    if (tempId[0] == dashboardConstant.MANAGE_PAGE_VISIT_KEY) {
      this.props.setPageVisitCount(null);
      this.props.getPageVisitCount(this.getCMSRequestParams(tempId[2]));
    }
  }

  getCMSRequestParams(duration, listFlag) {
    var tempParamas = {};
    tempParamas.responseType = listFlag ? "list" : "count";
    tempParamas.duration = duration;
    return tempParamas;
  }

  getBatchRequestParams(status, listFlag) {
    var tempParamas = {};
    tempParamas.responseType = listFlag ? "list" : "count";
    tempParamas.status = status;
    return tempParamas;
  }

  handlePageRedirection = (redirectURL, params) => {
    this.setState({ redirect: true, redirectUrl: redirectURL, params }, () => {
    });
  }

  handleViewMoreLinks = (event) => {
    event.preventDefault();
    var tempId = event.target.id;
    if (tempId == dashboardConstant.MANAGE_BATCH_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL);
    }
    if (tempId == dashboardConstant.MANAGE_DOCUMENT_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_DOCUMENT_PAGE_URL);
    }
    if (tempId == dashboardConstant.MANAGE_LEAD_CAPTURE_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_LEADCAPTURE_PAGE_URL,
        this.getCMSRequestParams("30D", "list"));
    }
    if (tempId == dashboardConstant.MANAGE_PAGE_VISIT_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_PAGE_VISIT_PAGE_URL,
        this.getCMSRequestParams("7D", "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_BATCH_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_INCOMPLETE_STATUS, "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_QRCODE_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_QR_STATUS, "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_CMS_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_CMS_STATUS, "list"));
    }
  }

  getPermissions = (userRoles) => {
    const roles = map(userRoles, (role) => {
      return role.role;
    });
    return roles;
  };

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate
    }));
  };

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    const track = this.props.track;
    const popover = (
      <Popover
        id="popover-basic"
        placement="left"
        positionLeft={10}
        positionTop={50}
        className="dashboard-popover"
      >
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button bsSize="xs">Last 7 Days</Button>
                  <Button bsSize="xs">Last 30 Days</Button>
                  <Button bsSize="xs" className="custom" onClick={this.openCustomDateHander}>Custom Date</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel>
                        Custom Date
                      </ControlLabel>
                      <Datetime
                        id="startdate"
                        inputProps={{ readOnly: true, placeholder: "From" }}
                        value=""
                        type="date"
                      />
                      <Datetime
                        id="enddate"
                        inputProps={{ readOnly: true, placeholder: "To" }}
                        value=""
                        type="date"
                      />
                    </FormGroup>
                  </div>
                )}
                <FormGroup>
                  <ControlLabel>
                    Category
                  </ControlLabel>
                  <Select
                    classNamePrefix="react-select"
                    name="categorySelect"
                    value={this.state.categorySelect}
                    onChange={value =>
                      this.setState({ categorySelect: value })
                    }
                    options={[
                      { value: "1", label: "Foobar" },
                      { value: "2", label: "Is great" }
                    ]}
                    placeholder="Select Category"
                  />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs">
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs">
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );
    const { attributeObj, attributeListQuickInfo, attributeListDetailed } = this.state;
    let permissions = [];
    let topProductList = [];
    if (this.props.userInfo) {
      const userRoles = this.props.userInfo.roles;
      permissions = this.getPermissions(userRoles);
    }
    if (this.props.topProductList) {
      topProductList = this.props.topProductList;
    }

    return (
      <div className="main-content dashboard" style={{position: "relative"}}>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <div className="hidedashboard">Coming Soon...</div>
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={dashboard} alt="" className="page-icon" />
                  Dashboard
                </div>
              </Col>
            </Col>
          </Row>
          <Row className="graph-section-wrapper">
            <Col md={12}>
              <Row className="graph-section">
                <Col md={9}>
                  <Row>
                    <TopSellingProduct />
                    <SaleChannelCount />
                    {isAuthorized("dashboardTileChannelCost") && <SalesByChannelCost />}
                    {track !== "lot" &&
                      <>
                        {isAuthorized("dashboardTileManufactoringCount") && <MfgOrderReport />}
                        {isAuthorized("dashboardTileManufactoringCost") && <MfgOrderByCostReport />}
                        {/* {isAuthorized("dashboardTileProfitOverTime") && <ProfitOverTime />} */}
                        {isAuthorized("dashboardTileManufactoringOTIF") && <MfgOTIF />}
                      </>
                    }

                    {/* <SaleOTIF />
                    <SupplierPerformance /> */}
                    <InventoryCoverage /> 
                    {track !== "lot" &&
                      <>
                        {isAuthorized("dashboardTileIncidentReport") && <IncidentReport />}
                        {/* <SalesBreakDown />
                        <SalesFunnel /> */}
                      </>
                    }
                    {track !== "uti" &&
                      <>
                        <IncomingShipment />
                        <PackingList />
                      </>
                    }
                  </Row>
                </Col>
                <Col md={3}>
                  <Card
                    content={
                      <Row>
                        <Col md={12}>
                          <SaleOrderCount />
                          <InventoryCount />
                          {track !== "lot" && isAuthorized("dashboardTileIncidentCount") && <IncidentCount />}
                          {track === "lot" && <Capacity />}
                        </Col>
                      </Row>
                    }
                  />
                </Col>
              </Row>
            </Col>
          </Row>

        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    userProfile: state.user.userProfile,
    ajaxTempCallStatus: state.ajaxStatusReducer.ajaxTempCallStatus,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    track: state.dataDictionary.track,
  };
}

const mapDispatchToProps = dispatch => ({
  setTempAjaxCallStatus: (ajaxCallStatus) => dispatch(setTempAjaxCallStatus(ajaxCallStatus)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  resetUserDetails: additionalData => dispatch(resetUserDetails(additionalData)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
