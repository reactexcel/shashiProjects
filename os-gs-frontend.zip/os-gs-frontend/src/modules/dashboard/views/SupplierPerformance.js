import React, { Component } from "react";
import { Grid, Col, Row, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getSupplierPerformanceList } from "../../supplierManagement/actions/supplierActions";
import { ResponsiveBar } from '@nivo/bar';
import CommonUtil from '../../common/util/commonUtil';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import moment from "moment";

class SupplierPerformance extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '5W',
      categorySelect: null,
      location: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      productCount: null,
      performance: null,
      allList: [{ label: 'All', value: 'All' }]
    };
  }

  componentDidMount = () => {
    this.props.getSupplierPerformanceList();
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.SupplierPerformanceList != null && prevProps.SupplierPerformanceList != this.props.SupplierPerformanceList) {
      this.setState({ SupplierPerformanceList: this.props.SupplierPerformanceList });
    }
  }

  handleDropDownChange = (event, obj) => {
    this.setState({
      'location': event.value,
      'locationName': event.label
    });
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
  }

  handleApiCall = () => {
    this.props.getSupplierPerformanceList();
    this.refs.overlay.hide();
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate
    }));
  };

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options })
  }

  handleFacilityDropDown = (event, obj) => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
        this.props.facilityList.Items), 'facilityId', 'facilityName')
    })
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  render() {
    const { SupplierPerformanceList, duration } = this.state;
    const finalSupplierPerformanceList = SupplierPerformanceList || [];
    const popover = (
      <Popover
        id="popover-basic"
        placement="left"
        positionLeft={10}
        positionTop={50}
        className="dashboard-popover"
      >
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button bsSize="xs">Last 7 Days</Button>
                  <Button bsSize="xs">Last 30 Days</Button>
                  <Button bsSize="xs" className="custom" onClick={this.openCustomDateHander}>Custom Date</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel>
                        Custom Date
                        </ControlLabel>
                      <Datetime id="startdate" inputProps={{ readOnly: true, placeholder: "From" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.fromDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'fromDate')} />
                      <Datetime id="enddate" inputProps={{ readOnly: true, placeholder: "To" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.toDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'toDate')} />
                    </FormGroup>
                  </div>
                )}
                <FormGroup>
                  <ControlLabel>
                    Category
                    </ControlLabel>
                  <Select
                    classNamePrefix="react-select"
                    name="categorySelect"
                    value={this.state.categorySelect}
                    onChange={value =>
                      this.setState({ categorySelect: value })
                    }
                    options={[
                      { value: "1", label: "Foobar" },
                      { value: "2", label: "Is great" }
                    ]}
                    placeholder="Select Category"
                  />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs">
                Cancel
               </Button>
              <Button className="btn-save btn-fill btn-xs">
                Apply
               </Button>
            </div>
          }
        />
      </Popover>
    );

    return (
      <Col md={4} sm={6}>
        <Card
          title="Supplier Performance"
          category=""
          content={
            <div className="graph">
              <ResponsiveBar
                data={finalSupplierPerformanceList}
                keys={['percentageDelivery']}
                indexBy="supplier"
                margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                padding={0.3}
                innerPadding={1}
                groupMode="grouped"
                colors={["#32D04B"]}
                minValue="auto"
                maxValue="auto"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: -20,
                  legend: 'Suppliers',
                  legendPosition: 'middle',
                  legendOffset: 40
                }}
                axisLeft={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: '% Age of on time delivery',
                  legendPosition: 'middle',
                  legendOffset: -30,
                  tickValues: 6
                }}
                theme={{
                  fontSize: 8,
                  axis: {
                    "legend": {
                      "text": {
                        "fill": "#4988A6"
                      }
                    },
                    "domain": {
                      "line": {
                        "stroke": "#9AC7D7",
                        "strokeWidth": 1
                      }
                    },
                  },
                }}
                barComponent={props => (
                  <g transform={`translate(${props.x},${isNaN(props.y) ? 0 : props.y})`}>
                    <rect width={25} height={(isNaN(props.height) || props.height < 0) ? 0 : props.height} fill={props.color} x={(props.width / 2) - 12.5} />
                    <text
                      x={(props.width / 2)}
                      y={(isNaN(props.height) || props.height < 0) ? 0 : (props.height / 2)}
                      textAnchor="middle"
                      dominantBaseline="central"
                      fill="black"
                      style={{
                          fontWeight: 400,
                          fontSize: 10,
                      }}
                    >
                      <tspan y={-6}>{props.data.value > 0 ? props.data.value : ''}</tspan>
                    </text>
                  </g>
                )}
                gridYValues={[0, 20, 40, 60, 80, 100]}
                enableGridY={false}
                labelSkipWidth={0}
                labelSkipHeight={0}
                isInteractive={false}
                animate={false}
              />
            </div>
          }
        />
      </Col>
    )
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    SupplierPerformanceList: state.supplier.SupplierPerformanceList,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getSupplierPerformanceList: selectedParams => dispatch(getSupplierPerformanceList(selectedParams)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SupplierPerformance);
