import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getIncidentReportList } from '../../incident/actions/incidentActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { ResponsiveBar } from '@nivo/bar';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { JS } from "aws-amplify";

class IncidentReport extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: null,
      categorySelect: null,
      priority: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      incidentTotalCount: null,
      incidentTotalCost: null,
      allList: [{ label: 'All', value: 'All' }]
    };
  }

  componentDidMount = () => {
    this.getTileDate();  
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 &&  CommonUtil.isNotNull(userProfile.dashboard[0].incidentReport)) {
      this.props.getIncidentReportList(this.props.userProfile.dashboard[0].incidentReport);
      this.setState({priority: this.props.userProfile.dashboard[0].incidentReport.priority});
    } else {
      this.props.getIncidentReportList({ duration: '30D' });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.incidentReportList != null && prevProps.incidentReportList != this.props.incidentReportList) {
      this.setState({ incidentReportList: this.props.incidentReportList });
      this.getTotalMFGCount(this.props.incidentReportList);
    }
    if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
      this.getTileDate();
    }
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'priority': event.value });
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      priority: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
    })
  }

  handleApiCall = () => {
    this.props.getIncidentReportList(this.getSelectedRequestParams());
    this.refs.overlay.hide();
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { duration, priority } = this.state;
    tempParamas.duration = duration ? duration : "30D";
    if (priority) {
      tempParamas.priority = priority ? priority : '';
    }
    //localStorage.setItem('incidentReport', JSON.stringify(tempParamas));
    let obj = {};
    let incidentReportObj = {};
    incidentReportObj.incidentReport = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(incidentReportObj);
    obj.dashboard = dashboardObj;
    this.props.setProfileDashboardDetails(obj);
    return tempParamas;
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate
    }));
  };

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  getTotalMFGCount = (incidentReportList) => {
    var incidentTotalCount = 0;
    var incidentTotalCost = 0;
    if (incidentReportList != null) {
      for (var i = 0; i < incidentReportList.length; i++) {
        incidentTotalCost = incidentTotalCost +
          CommonUtil.getFloatValue(incidentReportList[i].Open) +
          CommonUtil.getFloatValue(incidentReportList[i].InProgress);
      }
    }
    this.setState({ incidentTotalCost: incidentTotalCost });
  }

  render() {
    const { incidentReportList } = this.state;
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <FormGroup>
                  <ControlLabel>
                    Priority
                  </ControlLabel>
                  <Select classNamePrefix="react-select"
                    name="categorySelect"
                    value={{ "label": this.state.priority }}
                    onChange={this.handleDropDownChange}
                    options={this.props.dataDictionaryList != null &&
                      this.props.dataDictionaryList.dataDictionaryList != null &&
                      [...this.state.allList, ...this.props.dataDictionaryList.dataDictionaryList.priorityList]}
                    placeholder="Select Priority" />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );

    return (
      <Col md={4} sm={6}>
        <Card
          title="Incident Report"
          category={"Count : " + (this.state.incidentTotalCost != null ? this.state.incidentTotalCost : 0)}
          content={
            <div className="graph">
              <ResponsiveBar
                data={incidentReportList != null ? incidentReportList : []}
                keys={['Open', 'InProgress']}
                indexBy="incidents"
                margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                padding={0.3}
                innerPadding={1}
                groupMode="grouped"
                colors={["#FF7D1A", "#0086C0"]}
                minValue="auto"
                maxValue="auto"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Older than',
                  legendPosition: 'middle',
                  legendOffset: 28
                }}
                axisLeft={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'No of incident',
                  legendPosition: 'middle',
                  legendOffset: -30,
                  tickValues: 7
                }}
                theme={{
                  fontSize: 8,
                  axis: {
                    "legend": {
                      "text": {
                        "fill": "#4988A6"
                      }
                    },
                    "domain": {
                      "line": {
                        "stroke": "#9AC7D7",
                        "strokeWidth": 1
                      }
                    },

                  },
                }}
                barComponent={props => (
                  <g transform={`translate(${props.x},${isNaN(props.y) ? 0 : props.y})`}>
                    <rect width={25} height={(isNaN(props.height) || props.height < 0) ? 0 : props.height} fill={props.color} x={(props.width / 2) - 12.5} />
                    <text
                      x={(props.width / 2)}
                      y={(isNaN(props.height) || props.height < 0) ? 0 : (props.height / 2)}
                      textAnchor="middle"
                      dominantBaseline="central"
                      fill="black"
                      style={{
                          fontWeight: 400,
                          fontSize: 10,
                      }}
                    >
                      <tspan y={-6}>{props.data.value > 0 ? props.data.value : ''}</tspan>
                    </text>
                  </g>
                )}
                gridYValues={[0, 10, 20, 30, 40, 50]}
                enableGridY={false}
                labelSkipWidth={0}
                labelSkipHeight={0}
                isInteractive={false}
                animate={false}
                legends={[
                  {
                    dataFrom: 'keys',
                    anchor: 'bottom',
                    direction: 'row',
                    justify: false,
                    translateX: 0,
                    translateY: 50,
                    itemsSpacing: 3,
                    itemWidth: 50,
                    itemHeight: 15,
                    itemDirection: 'left-to-right',
                    itemOpacity: 1,
                    symbolSize: 10,
                  }
                ]}
              />
              <div className="overlay-section">
                <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                  <i className="fa fa-ellipsis-v" />
                </OverlayTrigger>
              </div>
            </div>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    facilityList: state.facility.facilityList,
    incidentReportList: state.incident.incidentReportList,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getIncidentReportList: selectedParams => dispatch(getIncidentReportList(selectedParams)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
});

export default connect(mapStateToProps, mapDispatchToProps)(IncidentReport);
