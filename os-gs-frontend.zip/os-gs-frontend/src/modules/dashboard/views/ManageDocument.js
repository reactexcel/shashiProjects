import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Tab, Tabs } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as dashboardConstant from '../constant/dashboardConstant';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setActionMode } from "../../../actions/appActions";
import { setSelectedSupplierCode, getSupplierList } from "../../supplierManagement/actions/supplierActions";
import { setSelectedFacilityCode, getFacilityList } from "../../facilityManagement/actions/facilityActions";
import CommonUtil from '../../common/util/commonUtil';
import Checkbox from "../../../components/CustomCheckbox/CustomCheckbox.jsx";
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";

class ManageDocument extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: '',
      redirect: false,
      redirectUrl: null,
      facilityDocumentList: null,
      supplierDocumentList: null,
      selectedModuleName: dashboardConstant.FACILITY_MODULE,
      status: null,
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditDownload = this.handleEditDownload.bind(this);
    this.getDocumentList = this.getDocumentList.bind(this);
    this.setSelectedModuleDetails = this.setSelectedModuleDetails.bind(this);
    this.handleTabClick = this.handleTabClick.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage document page loaded");
    this.props.getSupplierList();
    if (CommonUtil.isNullValue(this.props.facilityList)) {
      this.props.getFacilityList();
    }
    this.setSelectedModuleDetails(dashboardConstant.FACILITY_MODULE);
  }

  setSelectedModuleDetails(selectedModuleName) {
    var selectedPageName = this.props.dashboardPage !== undefined ? this.props.dashboardPage + "_" : '';
    const managePageList = pagePropertyListConstant[selectedPageName + "MANAGE_" + selectedModuleName.toUpperCase() + "_DOCUMENT_PAGE_LIST"](this);
    this.setState({
      tableColumnList: managePageList['tableColumnList'],
      defaultFilteredList: managePageList['defaultFilteredList'],
      defaultSortedList: managePageList['defaultSortedList'],
      defaultPageSize: managePageList['defaultPageSize'],
      tableConfig: managePageList['tableConfig'],
    })
  }

  componentDidUpdate(prevProps) {
    if (prevProps.supplierList != this.props.supplierList && this.props.supplierList != null) {
      this.setState({
        supplierDocumentList: this.getDocumentList(this.props.supplierList.Items, dashboardConstant.SUPPLIER_MODULE)
      })
    }
    if (prevProps.facilityList != this.props.facilityList && this.props.facilityList != null) {
      var tempList = this.getDocumentList(this.props.facilityList.Items, dashboardConstant.FACILITY_MODULE);
      this.setState({
        facilityDocumentList: tempList,
        tableDataList: tempList,
      })
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  getDocumentList = (tableDataList, mdouleName) => {
    var documentList = [];
    for (var i = 0; i < tableDataList && tableDataList.length; i++) {
      for (var j = 0; j < tableDataList[i].documents && tableDataList[i].documents.length; j++) {
        var tempDocumentExpiryDate = tableDataList[i].documents[j].documentExpiryDate;
        var currentDate = CommonUtil.getCurrentDate();
        //if (tempDocumentExpiryDate.getTime() < currentDate.getTime()) {
        var tempObj = {};
        tempObj = tableDataList[i].documents[j];
        tempObj[mdouleName.toLowerCase() + "Code"] =
          tableDataList[i][mdouleName.toLowerCase() + "Code"];
        tempObj[mdouleName.toLowerCase() + "Name"] =
          tableDataList[i][mdouleName.toLowerCase() + "Name"];
        documentList.push({ ...tempObj });
        // }
      }
    }
    return documentList;
  }

  handleTabClick(label, event) {
    if (label == dashboardConstant.FACILITY_MODULE) {
      this.setState({
        tableDataList: this.state.facilityDocumentList,
        selectedModuleName: label.toLowerCase()
      });
      this.setSelectedModuleDetails(dashboardConstant.FACILITY_MODULE);
    }
    if (label == dashboardConstant.SUPPLIER_MODULE) {
      this.setState({
        tableDataList: this.state.supplierDocumentList,
        selectedModuleName: label.toLowerCase()
      });
      this.setSelectedModuleDetails(dashboardConstant.SUPPLIER_MODULE);
    }
  }

  globalSearch = () => {
    let { searchInput, selectedModuleName } = this.state;
    let filteredData = this.props.supplierList.filter(value => {
      return (
        value[selectedModuleName + 'Code'].toLowerCase().includes(searchInput.toLowerCase()) ||
        value[selectedModuleName + 'Name'].toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  handleFIlter = (event) => {
    this.setState({
      defaultFilteredList: [
        {
          id: "status",
          value: event
        }
      ]
    })
  }

  handleEditDownload = (id) => {
    var tempId = id.split("_");
    if (this.state.selectedModuleName.toLowerCase() == dashboardConstant.SUPPLIER_MODULE.toLowerCase()) {
      this.props.setSelectedSupplierCode(tempId[0]);
      this.props.setActionMode(tempId[1]);
      this.handlePageRedirection(dashboardConstant.CREATE_SUPPLIER_PAGE_URL);
    }
    if (this.state.selectedModuleName.toLowerCase() == dashboardConstant.FACILITY_MODULE.toLowerCase()) {
      this.props.setSelectedFacilityCode(tempId[0]);
      this.props.setActionMode(tempId[1]);
      this.handlePageRedirection(dashboardConstant.CREATE_FACILITY_PAGE_URL);
    }
  }

  handlePageRedirection = (redirectURL) => {
    this.setState({ redirect: true, redirectUrl: redirectURL }, () => {
    });
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    var editCloneFlag = tempId != null && tempId[1] == dashboardConstant.EDIT_ACTION_MODE || tempId[1] == dashboardConstant.CLONE_ACTION_MODE;
    if (editCloneFlag) {
      this.handleEditDownload(event.target.id);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <div className="page-title">
                <i className="fa fa-cubes" />{" "}
                Documnents
              </div>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <Tabs id="dashboard-document-tabs" activeKey={this.state.key} onSelect={this.handleTabClick}>
                <Tab eventKey={'Facility'} title="Facility">
                </Tab>
                <Tab eventKey={'Supplier'} title="Supplier">
                </Tab>
              </Tabs>
              <Card className="dashboard-page"
                content={
                  <div >
                    {this.props.dashboardPage == undefined ?
                      <Row>
                        <div className="header-section">
                          <Col xs={12} sm={6} md={6}>
                            <div className="inline-checkbox">
                              <Checkbox inline number="Documents going to expire in 30 days" label="Documents going to expire in 30 days"
                                checked />
                            </div>
                            <div className="inline-checkbox">
                              <Checkbox inline number="Expired documents" label="Expired documents"
                              />
                            </div>
                          </Col>
                          <Col xs={12} sm={6} md={6}>
                            <div className="left-section">
                              <div className="search-section">
                                <i className="fa fa-search"></i>
                                <FormControl type="text" name="searchInput" placeholder="Search By Product"
                                  value={this.state.searchInput} onChange={this.handleChange} />
                              </div>
                            </div>
                          </Col>
                        </div>
                      </Row>
                      : null}

                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />

            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    supplierList: state.supplier.supplierList,
    facilityList: state.facility.facilityList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedSupplierCode: selectedSupplierCode => dispatch(setSelectedSupplierCode(selectedSupplierCode)),
  setActionMode: supplierActionMode => dispatch(setActionMode(supplierActionMode)),
  getSupplierList: id => dispatch(getSupplierList(id)),
  setSelectedFacilityCode: selectedSupplierCode => dispatch(setSelectedFacilityCode(selectedSupplierCode)),
  getFacilityList: id => dispatch(getFacilityList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageDocument);
