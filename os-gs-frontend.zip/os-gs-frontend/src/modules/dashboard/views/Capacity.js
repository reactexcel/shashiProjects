import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { ResponsiveBar } from '@nivo/bar';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import { getCapacityReport } from '../../facilityManagement/actions/facilityActions';
import list from "assets/img/list1.svg";

class Capacity extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      categorySelect: null,
      location: null,
      locationName: null,
      facilityList: null,
      allList: [{ label: 'All', value: 'All' }],
    };
  }

  componentDidMount = () => {
    this.getTileDate();  
     //if (CommonUtil.isNullValue(this.props.getFacilityList)) {
       this.props.getFacilityList();
     //}
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 && CommonUtil.isNotNull(userProfile.dashboard[0].capacityReport)) {
        this.setState({location: this.props.userProfile.dashboard[0].capacityReport.location, locationName: this.props.userProfile.dashboard[0].capacityReport.locationName});
      this.props.getCapacityReport(this.props.userProfile.dashboard[0].capacityReport);
    } else {
      this.props.getCapacityReport();
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.capacityReportList != null && prevProps.capacityReportList != this.props.capacityReportList) {
      this.setState({ capacityReportList: this.props.capacityReportList });
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.handleFacilityDropDown();
    }
    if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
      this.getTileDate();
    }
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'location': event.value, 'locationName': event.label });
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      location: null,
      locationName: null,
      facility: null,
    })
  }

  handleApiCall = () => {
    this.props.getCapacityReport(this.getSelectedRequestParams());
    this.refs.overlay.hide();
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { location, locationName } = this.state;
    if (location) {
      tempParamas.location = location ? location : '';
      tempParamas.locationName = locationName ? locationName : '';
    }
    let obj = {};
    let capacityReportObj = {};
    capacityReportObj.capacityReport = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(capacityReportObj);
    obj.dashboard = dashboardObj;
    this.props.setProfileDashboardDetails(obj);
    return tempParamas;
  }

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options, customDate: false })
  }

  handleFacilityDropDown = (event, obj) => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
        this.props.facilityList.Items), 'facilityId', 'facilityName')
    })
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  render() {
    const { capacityReportList, duration, customDate } = this.state;
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <FormGroup>
                  <ControlLabel>
                    Location
                  </ControlLabel>
                  <Select classNamePrefix="react-select"
                    name="categorySelect"
                    value={{ "label": this.state.locationName }}
                    onChange={this.handleDropDownChange}
                    options={this.state.facilityList != null ?
                      [...this.state.allList, ...this.state.facilityList] : []}
                    placeholder="Select Location" />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );

    return (
      <div className="display-card assignedtome">
        <div className="heading">
          <div className="title"><img src={list} alt="" />Capacity</div>
          <div className="count-section">
            <div className="overlay-section">
              <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                <i className="fa fa-ellipsis-v" />
              </OverlayTrigger>
            </div>
          </div>
        </div>
        <div className="box">
          <div className="content-box">
            <div className="subheading">Stock Capacity</div>
            <div className="number">{capacityReportList && capacityReportList.totalSpace}</div>
          </div>
          <div className="content-box">
            <div className="subheading">Used Capacity</div>
            <div className="number">{capacityReportList && capacityReportList.usedSpace}</div>
          </div>
        </div>
        <div className="last">
          <div className="content-box">
            <div className="subheading">Available Capacity</div>
            <div className="number">{capacityReportList && capacityReportList.leftSpace}</div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    facilityList: state.facility.facilityList,
    userProfile: state.user.userProfile,
    capacityReportList: state.facility.capacityReportList,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
  getCapacityReport: selectedParams => dispatch(getCapacityReport(selectedParams)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Capacity);
