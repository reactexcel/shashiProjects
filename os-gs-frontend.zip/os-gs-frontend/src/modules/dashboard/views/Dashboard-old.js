import React, { Component } from "react";
import { Grid, Col, Row } from "react-bootstrap";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import StatsCard from "components/Card/StatsCard.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import ManageBatch from '../../configurePipeLine/views/ManageBatch';
import ManageDocument from './ManageDocument';
import QuickLinks from './QuickLinks';
import { getLeadCaptureCount, getPageVisitCount,setReducerInitMode } from "../../leadCapture/actions/leadCaptureAction";
import { setLeadCaptureCount, setPageVisitCount } from "../../leadCapture/actions/leadCaptureAction";
import {getDataDictionaryDetails} from '../../dataDictionary/actions/dataDictionaryActions';
import { getIncompleteBatchCount, getBatchWithoutQRCount, getBatchWithoutCMSCount }
  from "../../configurePipeLine/actions/batchActions";
import * as dashboardConstant from '../constant/dashboardConstant';
import map from "lodash/map";
import intersection from "lodash/intersection";

class Dashboard extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeListQuickInfo: null,
      attributeListDetailed: null,
      attributeObj: null,
      params: null,
    };
    this.handleCardClick = this.handleCardClick.bind(this);
    this.getBatchRequestParams = this.getBatchRequestParams.bind(this);
    this.getCMSRequestParams = this.getCMSRequestParams.bind(this);
    this.handleAPIResponse = this.handleAPIResponse.bind(this);
  }

  componentDidMount = () => {
    this.props.getDataDictionaryDetails();
    this.props.getLeadCaptureCount(this.getCMSRequestParams("30D"));
    this.props.getPageVisitCount(this.getCMSRequestParams("7D"));
    this.props.getIncompleteBatchCount(this.getBatchRequestParams(dashboardConstant.BATCH_INCOMPLETE_STATUS));
    this.props.getBatchWithoutCMSCount(this.getBatchRequestParams(dashboardConstant.BATCH_CMS_STATUS));
    this.props.getBatchWithoutQRCount(this.getBatchRequestParams(dashboardConstant.BATCH_QR_STATUS));
    this.setState({
      attributeObj: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeObj,
      attributeListQuickInfo: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeListQuickInfo,
      attributeListDetailed: pagePropertyListConstant.DASHBOARD_PAGE_LIST.attributeListDetailed,
    })
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.incompleteBatchCount != null && prevProps.incompleteBatchCount != this.props.incompleteBatchCount) {
      this.handleAPIResponse('incompleteBatchCount');
    }
    if (this.props.batchWithoutQRCodeCount != null && prevProps.batchWithoutQRCodeCount != this.props.batchWithoutQRCodeCount) {
      this.handleAPIResponse('batchWithoutQRCodeCount');
    }
    if (this.props.batchWithoutCMSCount != null && prevProps.batchWithoutCMSCount != this.props.batchWithoutCMSCount) {
      this.handleAPIResponse('batchWithoutCMSCount');
    }
    if (this.props.leadCaptureCount != null && prevProps.leadCaptureCount != this.props.leadCaptureCount) {
      this.handleAPIResponse('leadCaptureCount');
    }
    if (this.props.pageVisitCount != null && prevProps.pageVisitCount != this.props.pageVisitCount) {
      this.handleAPIResponse('pageVisitCount');
    }
  }

  handleAPIResponse(attributeName) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        [attributeName]: this.props[attributeName]
      }
    })
  }

  handleCardClick = (event) => {
    var tempId = event.target.id.split("_");
    const { attributeObj } = this.state;
    var selectedOption = dashboardConstant["VALUE_" + tempId[2]];
    this.setState({
      attributeObj: {
        ...attributeObj,
        [tempId[1]]: selectedOption
      }
    })
    if (tempId[0] == dashboardConstant.MANAGE_LEAD_CAPTURE_KEY) {
      this.props.setLeadCaptureCount(null);
      this.props.getLeadCaptureCount(this.getCMSRequestParams(tempId[2]));
    }
    if (tempId[0] == dashboardConstant.MANAGE_PAGE_VISIT_KEY) {
      this.props.setPageVisitCount(null);
      this.props.getPageVisitCount(this.getCMSRequestParams(tempId[2]));
    }
  }

  getCMSRequestParams(duration, listFlag) {
    var tempParamas = {};
    tempParamas.responseType = listFlag ? "list" : "count";
    tempParamas.duration = duration;
    return tempParamas;
  }

  getBatchRequestParams(status, listFlag) {
    var tempParamas = {};
    tempParamas.responseType = listFlag ? "list" : "count";
    tempParamas.status = status;
    return tempParamas;
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }


  handlePageRedirection = (redirectURL, params) => {
    this.setState({ redirect: true, redirectUrl: redirectURL, params }, () => {
    });
  }

  handleViewMoreLinks = (event) => {
    event.preventDefault();
    var tempId = event.target.id;
    if (tempId == dashboardConstant.MANAGE_BATCH_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL);
    }
    if (tempId == dashboardConstant.MANAGE_DOCUMENT_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_DOCUMENT_PAGE_URL);
    }
    if (tempId == dashboardConstant.MANAGE_LEAD_CAPTURE_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_LEADCAPTURE_PAGE_URL,
        this.getCMSRequestParams("30D", "list"));
    }
    if (tempId == dashboardConstant.MANAGE_PAGE_VISIT_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_PAGE_VISIT_PAGE_URL,
        this.getCMSRequestParams("7D", "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_BATCH_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_INCOMPLETE_STATUS, "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_QRCODE_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_QR_STATUS, "list"));
    }
    if (tempId == dashboardConstant.MANAGE_INCOMPLETE_CMS_KEY) {
      this.handlePageRedirection(dashboardConstant.MANAGE_BATCH_PAGE_URL,
        this.getBatchRequestParams(dashboardConstant.BATCH_CMS_STATUS, "list"));
    }
  }

  getPermissions = (userRoles) => {
    const roles = map(userRoles, (role) => {
      return role.role;
    });
    return roles;
  };

  render() {
    const { attributeObj, attributeListQuickInfo, attributeListDetailed } = this.state;
    let permissions = [];
    if (this.props.userInfo) {
      const userRoles = this.props.userInfo.roles;
      permissions = this.getPermissions(userRoles);
    }

    return (
      <div className="main-content dashboard">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Grid fluid>

          <Row className="infocard">
            {attributeListQuickInfo != null && attributeListQuickInfo.map((tempAttributeListObj, index) => (
              tempAttributeListObj.type == "INFOCARD" && intersection(tempAttributeListObj.allowedPermissions, permissions).length !== 0 ?
                <Col key={index} lg={tempAttributeListObj.lgWidth} sm={tempAttributeListObj.smWidth}>
                  <StatsCard
                    bigIcon={<i className={tempAttributeListObj.cardIcon} />}
                    statsText={tempAttributeListObj.cardTitle}
                    statsValue={attributeObj[tempAttributeListObj.name]}

                    statsSubLeftIcon={tempAttributeListObj.statsSubLeftIcon == 'calendar' ?
                      <Nav pullLeft>
                        <NavDropdown id={tempAttributeListObj.pageType} title={<i className={'fa fa-calendar-o'} />} noCaret >
                          <MenuItem id={tempAttributeListObj.pageType + "_" + tempAttributeListObj.statsSubLeftIconText + "_7D"} onClick={this.handleCardClick}>Last 7 days</MenuItem>
                          <MenuItem id={tempAttributeListObj.pageType + "_" + tempAttributeListObj.statsSubLeftIconText + "_30D"} onClick={this.handleCardClick}>Last 30 days</MenuItem>
                          <MenuItem id={tempAttributeListObj.pageType + "_" + tempAttributeListObj.statsSubLeftIconText + "_180D"} onClick={this.handleCardClick}>Last 6 months</MenuItem>
                          <MenuItem id={tempAttributeListObj.pageType + "_" + tempAttributeListObj.statsSubLeftIconText + "_365D"} onClick={this.handleCardClick}>Last 1 year</MenuItem>
                        </NavDropdown>
                      </Nav>
                      : tempAttributeListObj.statsSubLeftIcon}

                    statsSubLeftIconText={attributeObj[tempAttributeListObj.statsSubLeftIconText]}
                    statsSubRightIcon={<i id={tempAttributeListObj.pageType}
                      className={`${tempAttributeListObj.statsSubRightIcon}`} />}

                    statsSubRightIconText={
                      <a href="" id={tempAttributeListObj.pageType} onClick={this.handleViewMoreLinks}>
                        {tempAttributeListObj.statsSubRightIconText}</a>}
                  />
                </Col>
                : null))}
          </Row>

          <Row>
            {attributeListDetailed != null && attributeListDetailed.map((tempAttributeListObj, index) => (
              tempAttributeListObj.type == "DETAILCARD" && intersection(tempAttributeListObj.allowedPermissions, permissions).length !== 0?
                <Col key={index} lg={tempAttributeListObj.lgWidth} sm={tempAttributeListObj.smWidth}>
                  <Card title={tempAttributeListObj.cardTitle}
                    content={
                      tempAttributeListObj.pageType == dashboardConstant.MANAGE_BATCH_KEY ?
                        <ManageBatch dashboardPage={"DASHBOARD"}></ManageBatch>
                        : tempAttributeListObj.pageType == dashboardConstant.MANAGE_DOCUMENT_KEY ?
                          <ManageDocument dashboardPage={"DASHBOARD"} ></ManageDocument>
                          : tempAttributeListObj.pageType == dashboardConstant.MANAGE_QUICK_LINK_KEY ?
                            <QuickLinks></QuickLinks>
                            : null}
                    ftTextRight
                    legend={
                      <div>
                        {tempAttributeListObj.viewMoreFlag ?
                          <a href="" id={tempAttributeListObj.pageType} onClick={this.handleViewMoreLinks}> View More</a>
                          : null}
                      </div>
                    }
                  />
                </Col>
                : null))}
          </Row>

        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    incompleteBatchCount: state.batch.incompleteBatchCount,
    batchWithoutQRCodeCount: state.batch.batchWithoutQRCodeCount,
    batchWithoutCMSCount: state.batch.batchWithoutCMSCount,
    leadCaptureCount: state.leadCapture.leadCaptureCount,
    pageVisitCount: state.leadCapture.pageVisitCount,
    userInfo: state.authReducer.userInfo
  };
}

const mapDispatchToProps = dispatch => ({
  setLeadCaptureCount: count => dispatch(setLeadCaptureCount(count)),
  setPageVisitCount: count => dispatch(setPageVisitCount(count)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getLeadCaptureCount: selectedParams => dispatch(getLeadCaptureCount(selectedParams)),
  getPageVisitCount: selectedParams => dispatch(getPageVisitCount(selectedParams)),
  getIncompleteBatchCount: selectedParams => dispatch(getIncompleteBatchCount(selectedParams)),
  getBatchWithoutCMSCount: selectedParams => dispatch(getBatchWithoutCMSCount(selectedParams)),
  getBatchWithoutQRCount: selectedParams => dispatch(getBatchWithoutQRCount(selectedParams)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
