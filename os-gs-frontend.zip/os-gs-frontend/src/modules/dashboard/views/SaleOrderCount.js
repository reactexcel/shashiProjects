import React, { Component } from "react";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getsaleOrderCount } from '../../saleOrder/actions/saleOrderActions';
import { Redirect } from "react-router-dom";
import CommonUtil from '../../common/util/commonUtil';
import * as saleOrderConstant from '../../saleOrder/constant/saleOrderConstant';
import list from "assets/img/list1.svg";

class SaleOrderCount extends Component {

  constructor(props) {
    super(props);
    this.state = {
      saleOrderCount : [],
      redirect: false,
      redirectUrl: null,
    };
  }

  componentDidMount = () => {
    this.props.getsaleOrderCount({ saleOderCount: 'true' });
  }

  openSaleOrder = () => {
    CommonUtil.handlePageRedirection(saleOrderConstant.MANAGE_SALE_ORDER_PAGE_URL, this);
  };


  componentDidUpdate(prevProps, prevState) {
    if (this.props.saleOrderCount != null && prevProps.saleOrderCount != this.props.saleOrderCount) {
      this.setState({ saleOrderCount: this.props.saleOrderCount });
    }
  }

  render() {
    const { saleOrderCount } = this.state;
    var totalCount = CommonUtil.isNaNValue(saleOrderCount.openCount + saleOrderCount.doneCount);
    return (
      <div className="display-card sale-count">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        <div className="heading">
          <div className="title"><img src={list} alt="" />Sales Order</div>
          <div className="count-section">
            <div className="count" onClick={this.openSaleOrder}>{totalCount != null ? totalCount : 0}</div>
          </div>
        </div>
        <div className="box">
          <div className="content-box">
            <div className="subheading">Open</div>
            <div className="number" onClick={this.openSaleOrder}>{saleOrderCount.openCount}</div>
          </div>
          <div className="content-box">
            <div className="subheading">In progress</div>
            <div className="number" onClick={this.openSaleOrder}>{saleOrderCount.doneCount}</div>
          </div>
        </div>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    saleOrderCount: state.saleOrder.saleOrderCount,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getsaleOrderCount: selectedParams => dispatch(getsaleOrderCount(selectedParams)),
});

export default connect(mapStateToProps, mapDispatchToProps)(SaleOrderCount);
