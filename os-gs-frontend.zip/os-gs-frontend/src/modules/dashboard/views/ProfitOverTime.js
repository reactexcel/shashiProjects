import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getProfitOverTimeList } from '../../saleOrder/actions/saleOrderActions';
import { getUserProfile , setProfileDashboardDetails } from '../../userManagement/actions/userActions';
import { ResponsiveLine } from '@nivo/line';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import CommonUtil from '../../common/util/commonUtil';

class ProfitOverTime extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '5W',
      saleProfitOverTimeList: null,
    };
  }

  componentDidMount = () => {
    this.getTileDate();
  }

  getTileDate = () => {
    let userProfile = this.props.userProfile;
    if (userProfile.dashboard != null && userProfile.dashboard.length > 0 && CommonUtil.isNotNull(userProfile.dashboard[0].profitOverTime)) {
      this.props.getProfitOverTimeList(this.props.userProfile.dashboard[0].profitOverTime);
      this.setState({duration: this.props.userProfile.dashboard[0].profitOverTime.duration});
    } else {
      this.props.getProfitOverTimeList({ duration: '5W' });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.saleProfitOverTimeList != null && prevProps.saleProfitOverTimeList != this.props.saleProfitOverTimeList) {
      let tempObj = { "data": this.props.saleProfitOverTimeList };
      this.setState({ saleProfitOverTimeList: tempObj });
    }
    if (this.props.userProfile != null && prevProps.userProfile != this.props.userProfile) {
      this.getTileDate();
    }
  }

  getTotalProfit = () => {
    var saleOrderTotalProfit = 0;
    if (this.props.saleProfitOverTimeList != null) {
      for (var i = 0; i < this.props.saleProfitOverTimeList.length; i++) {
        saleOrderTotalProfit = saleOrderTotalProfit +
          CommonUtil.isNaNValue(parseInt(this.props.saleProfitOverTimeList[i].y));
      }
      saleOrderTotalProfit = saleOrderTotalProfit / this.props.saleProfitOverTimeList.length;
    }
    return parseFloat(saleOrderTotalProfit).toFixed();
  }

  handleApiCall = () => {
    this.setState({ saleProfitOverTimeList: null });
    this.props.getProfitOverTimeList(this.getSelectedRequestParams());
    this.refs.overlay.hide();
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
  }

  getSelectedRequestParams = () => {
    var tempParamas = {};
    const { duration } = this.state;
    tempParamas.duration = duration ? duration : "5W";
    let obj = {};
    let profitOverTimeObj = {};
    profitOverTimeObj.profitOverTime = tempParamas;
    var dashboardObj = [];
    dashboardObj.push(profitOverTimeObj);
    obj.dashboard = dashboardObj;
    this.props.setProfileDashboardDetails(obj);
   // return tempParamas;
  //  localStorage.setItem('profitOverTime', JSON.stringify(tempParamas));
    return tempParamas;
  }

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options })
  }

  render() {
    const { saleProfitOverTimeList, duration } = this.state;
    let saleProfitOverTimeListData = [];
    if (saleProfitOverTimeList != null && saleProfitOverTimeList.data != null && saleProfitOverTimeList.data.length > 0) {
      saleProfitOverTimeListData.data = saleProfitOverTimeList.data.map((item, index) => {
        return {
          ...item,
          y: parseFloat(item.y).toFixed(),
        }
      })
    }
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <div className="date-buttons">
                  <Button className={duration == "5W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '5W')}>Last 5 Week</Button>
                  <Button className={duration == "7W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '7W')}>Last 7 Week</Button>
                  <Button className={duration == "10W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '10W')}>Last 10 Week</Button>
                </div>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );
    return (
      <Col md={4} sm={6}>
        <Card
          title="Profit Over Time"
          category={`Average: ${this.getTotalProfit()}`}
          content={
            <div className="graph">
              {saleProfitOverTimeList != null ?
                <ResponsiveLine
                  data={[saleProfitOverTimeListData]}
                  margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                  xScale={{ type: 'point' }}
                  yScale={{ type: 'linear', min: '0', max: '100', stacked: true, reverse: false }}
                  yFormat=" >-.2f"
                  colors={["#BD00FF"]}
                  minValue="auto"
                  maxValue="auto"
                  axisTop={null}
                  axisRight={null}
                  axisBottom={{
                    orient: 'bottom',
                    tickSize: 0,
                    tickPadding: 10,
                    tickRotation: 0,
                    legend: 'Week Number',
                    legendOffset: 28,
                    legendPosition: 'middle'
                  }}
                  axisLeft={{
                    orient: 'left',
                    tickSize: 0,
                    tickPadding: 10,
                    tickRotation: 0,
                    legend: 'Profit Margin',
                    legendOffset: -30,
                    legendPosition: 'middle',
                    tickValues: 7
                  }}
                  theme={{
                    fontSize: 8,
                    axis: {
                      "legend": {
                        "text": {
                          "fill": "#4988A6"
                        }
                      },
                      "domain": {
                        "line": {
                          "stroke": "#9AC7D7",
                          "strokeWidth": 1
                        }
                      },
                    },
                  }}
                  gridYValues={"auto"}
                  pointSize={7}
                  lineWidth={1}
                  enableGridX={false}
                  pointColor='#A5A6FE'
                  pointBorderWidth={1}
                  pointBorderColor='#A5A6FE'
                  pointLabelYOffset={-10}
                  useMesh={false}
                  isInteractive={false}
                  enablePointLabel={true}
                  pointLabel="y"
                />
                : null}
              <div className="overlay-section">
                <OverlayTrigger ref="overlay" trigger="click" rootClose placement="left" overlay={popover}>
                  <i className="fa fa-ellipsis-v" />
                </OverlayTrigger>
              </div>
            </div>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    saleProfitOverTimeList: state.saleOrder.saleProfitOverTimeList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getProfitOverTimeList: selectedParams => dispatch(getProfitOverTimeList(selectedParams)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setProfileDashboardDetails: (dataDictionaryDetailsObj) => dispatch(setProfileDashboardDetails(dataDictionaryDetailsObj)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProfitOverTime);
