import React, { Component } from "react";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getincidentCount } from '../../incident/actions/incidentActions';
import { Redirect } from "react-router-dom";
import CommonUtil from '../../common/util/commonUtil';
import * as incidentConstant from '../../incident/constant/incidentConstant';
import list from "assets/img/list1.svg";

class IncidentCount extends Component {

  constructor(props) {
    super(props);
    this.state = {
      incidentCount: [],
      incidentLoginCount: [],
      redirect: false,
      redirectUrl: null,
    };
  }

  componentDidMount = () => {
    this.props.getincidentCount();
  }

  openIncident = () => {
    CommonUtil.handlePageRedirection(incidentConstant.MANAGE_INCIDENT_PAGE_URL, this);
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.incidentCount != null && prevProps.incidentCount != this.props.incidentCount) {
      this.setState({ incidentCount: this.props.incidentCount.Item, incidentLoginCount: this.props.incidentCount.UserAssignedIncident });
    }
  }

  render() {
    const { incidentCount, incidentLoginCount } = this.state;
    var totalCount = CommonUtil.isNaNValue(incidentCount.openCount + incidentCount.closeCount + incidentCount.inProgressCount);
    var totalLoginCount = CommonUtil.isNaNValue(incidentLoginCount.openCount + incidentLoginCount.closeCount + incidentLoginCount.inProgressCount);
    return (
      <>
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        <div className="display-card incident-count">
          <div className="heading">
            <div className="title"><img src={list} alt="" />Incident</div>
            <div className="count-section">
              <div className="count" onClick={this.openIncident}>{totalCount != null ? totalCount : 0}</div>
            </div>
          </div>
          <div className="box">
            <div className="content-box">
              <div className="subheading">Open</div>
              <div className="number" onClick={this.openIncident}>{incidentCount.openCount}</div>
            </div>
            <div className="content-box">
              <div className="subheading">In Process</div>
              <div className="number" onClick={this.openIncident}>{incidentCount.inProgressCount}</div>
            </div>
          </div>
        </div>

        <div className="display-card incident-count assignedtome">
          <div className="heading">
            <div className="title"><img src={list} alt="" />Incident assigned to me</div>
            <div className="count-section">
              <div className="count" onClick={this.openIncident}>{totalLoginCount != null ? totalLoginCount : 0}</div>
            </div>
          </div>
          <div className="box">
            <div className="content-box">
              <div className="subheading">Open</div>
              <div className="number" onClick={this.openIncident}>{incidentLoginCount.openCount}</div>
            </div>
            <div className="content-box">
              <div className="subheading">In Process</div>
              <div className="number" onClick={this.openIncident}>{incidentLoginCount.inProgressCount}</div>
            </div>
          </div>
          <div className="last">
            <div className="content-box">
              <div className="subheading">Close</div>
              <div className="number" onClick={this.openIncident}>{incidentLoginCount.closeCount}</div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    incidentCount: state.incident.incidentCount,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getincidentCount: selectedParams => dispatch(getincidentCount(selectedParams)),
});

export default connect(mapStateToProps, mapDispatchToProps)(IncidentCount);
