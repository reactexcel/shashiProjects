import React, { Component } from "react";
import { Col, Row, OverlayTrigger, Popover, FormGroup, ControlLabel, Tooltip } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import { connect } from "react-redux";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import { getInventoryCoverage } from '../../saleOrder/actions/saleOrderActions';
import { ResponsiveBar } from '@nivo/bar';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Datetime from "react-datetime";
import Select from "react-select";
import CommonUtil from '../../common/util/commonUtil';
import { getFacilityList } from "../../facilityManagement/actions/facilityActions";
import moment from "moment";

class InventoryCoverage extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null,
      params: null,
      duration: '5W',
      categorySelect: null,
      location: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
      productCount: null,
      coverageValue: null,
      allList: [{ label: 'All', value: 'All' }]
    };
  }

  componentDidMount = () => {
    this.props.getInventoryCoverage();
    if (CommonUtil.isNullValue(this.props.facilityList)) {
      this.props.getFacilityList();
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.inventoryCoverageList != null && prevProps.inventoryCoverageList != this.props.inventoryCoverageList) {
      this.setState({ inventoryCoverageList: this.props.inventoryCoverageList });
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.handleFacilityDropDown();
    }
  }

  handleDropDownChange = (event, obj) => {
    this.setState({ 'location': event.value, 'locationName': event.label });
  }

  cancelOverlay = () => {
    this.refs.overlay.hide();
    this.setState({
      location: null,
      locationName: null,
      facility: null,
      fromDate: null,
      toDate: null,
      customDate: false,
    })
  }

  handleApiCall = () => {
    this.props.getInventoryCoverageList();
    this.refs.overlay.hide();
  }

  openCustomDateHander = () => {
    this.setState(prevState => ({
      customDate: !prevState.customDate
    }));
  };

  handleCustomSelection = (e, options) => {
    this.setState({ duration: options })
  }

  handleFacilityDropDown = (event, obj) => {
    this.setState({
      facilityList: CommonUtil.getOptionsFromList(CommonUtil.getFacilityLocationList(
        this.props.facilityList.Items), 'facilityId', 'facilityName')
    })
  }

  handleDateChange = (event, eventId) => {
    var name = eventId.split('_')[0];
    this.setState({ [name]: event.toDate ? CommonUtil.getFormattedDate(event.toDate()) : '' })
  }

  getTotalMFGCount = (saleOTIFList) => {
    var saleOrderTotalCount = 0;
    var saleOTIFTotalAvg = 0;
    if (saleOTIFList != null) {
      for (var i = 0; i < saleOTIFList.length; i++) {
        if (saleOTIFList[i].totalAvg != null) {
          saleOrderTotalCount = saleOrderTotalCount + 1;
        }
        saleOTIFTotalAvg = saleOTIFTotalAvg +
          CommonUtil.isNaNValue(parseInt(saleOTIFList[i].totalAvg));
      }
    }
    var avg = saleOTIFTotalAvg / saleOrderTotalCount;
    this.setState({ saleOTIFTotalAvg: parseFloat(avg).toFixed(2) });
  }

  render() {
    const { inventoryCoverageList, duration } = this.state;
    const popover = (
      <Popover id="popover-basic" placement="left" positionLeft={10}
        positionTop={50} className="dashboard-popover">
        <Card
          content={
            <Row className="dashboard-popover-content">
              <Col md={12}>
                <p>Date</p>
                <div className="date-buttons">
                  <Button className={duration == "5W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '5W')}>Last 5 Week</Button>
                  <Button className={duration == "7W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '7W')}>Last 7 Week</Button>
                  <Button className={duration == "10W" ? 'active' : ''} bsSize="xs" onClick={(e) => this.handleCustomSelection(e, '10W')}>Last 10 Week</Button>
                </div>
                {this.state.customDate && (
                  <div className="custom-date">
                    <FormGroup>
                      <ControlLabel> Custom Date </ControlLabel>
                      <Datetime id="startdate" inputProps={{ readOnly: true, placeholder: "From" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.fromDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'fromDate')} />
                      <Datetime id="enddate" inputProps={{ readOnly: true, placeholder: "To" }}
                        type="date" closeOnSelect={true} timeFormat={false}
                        dateFormat="MM-DD-YYYY"
                        value={moment(this.state.toDate)}
                        onChange={(moment) => this.handleDateChange(moment, 'toDate')} />
                    </FormGroup>
                  </div>
                )}
                <FormGroup>
                  <ControlLabel>
                    Location
                  </ControlLabel>
                  <Select classNamePrefix="react-select"
                    name="categorySelect"
                    value={{ "label": this.state.locationName }}
                    onChange={this.handleDropDownChange}
                    options={this.state.facilityList != null ?
                      [...this.state.allList, ...this.state.facilityList] : []}
                    placeholder="Select Location" />
                </FormGroup>
              </Col>
            </Row>
          }
          ftTextRight
          legend={
            <div>
              <Button className="btn-cancel btn-xs" onClick={this.cancelOverlay}>
                Cancel
             </Button>
              <Button className="btn-save btn-fill btn-xs" onClick={this.handleApiCall}>
                Apply
             </Button>
            </div>
          }
        />
      </Popover>
    );

    const CustomBarComponent = (props) => {
      const {
        x, y, width, height, color, borderColor, data, showTooltip, hideTooltip,
      } = props;

      return (
        <g transform={`translate(${x},${isNaN(y) ? 0 : y})`}
          onMouseEnter={(event) => {
            showTooltip(<tooltip className="bar-tooltip">
              <div style={{ color, borderColor, backgroundColor: "#fff" }}>
                {data && data.data && data.data.productNames.split(',').map((str, index) => <p key={index}>{str}</p>)}
              </div>
            </tooltip>, event);
          }}
          onMouseLeave={(event) => {
            hideTooltip();
          }}
        >
          <rect width={25} height={isNaN(height) ? 0 : height} fill={color} x={(width / 2) - 12.5} />
          <text
            x={(width / 2)}
            y={isNaN(height) ? 0 : (height / 2)}
            textAnchor="middle"
            dominantBaseline="central"
            fill="black"
            style={{
                fontWeight: 400,
                fontSize: 10,
            }}
          >
            <tspan y={-6}>{data.value > 0 ? data.value : ''}</tspan>
          </text>
        </g>
      );
    };

    return (
      <Col md={6} sm={6}>
        <Card
          title="Inventory Coverage"
          category=""
          content={
            <div className="graph">
              <ResponsiveBar
                data={inventoryCoverageList != null ? inventoryCoverageList : []}
                // tooltip={(data) => {
                //   var tooltipStr = data && data.data && data.data.productNames.split(',').map(str => <p style={{ fontSize: "10px" }}>{str}</p>);
                //   var color = data && data.color;
                //   return (
                //     <div style={{ color }}>
                //       {tooltipStr}
                //     </div>
                //   )
                // }}
                keys={['productCount']}
                indexBy="coverageValue"
                margin={{ top: 10, right: 10, bottom: 50, left: 40 }}
                padding={0.3}
                innerPadding={1}
                groupMode="grouped"
                colors={["#BD00FF"]}
                minValue="auto"
                maxValue="auto"
                axisTop={null}
                axisRight={null}
                axisBottom={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Number of days',
                  legendPosition: 'middle',
                  legendOffset: 28
                }}
                axisLeft={{
                  tickSize: 0,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: 'Stock Coverage',
                  legendPosition: 'middle',
                  legendOffset: -30,
                  tickValues: 6
                }}
                theme={{
                  fontSize: 8,
                  axis: {
                    "legend": {
                      "text": {
                        "fill": "#4988A6"
                      }
                    },
                    "domain": {
                      "line": {
                        "stroke": "#9AC7D7",
                        "strokeWidth": 1
                      }
                    },
                  },
                  tooltip: {
                    "container": {
                      "background": "#FFF"
                    },
                  },
                }}
                barComponent={CustomBarComponent}
                enableGridY={false}
                labelSkipWidth={0}
                labelSkipHeight={0}
                labelFormat={d => <tspan y={6}>{d}</tspan>}
                labelTextColor="white"
                isInteractive={true}
                animate={true}
              />
            </div>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    userInfo: state.authReducer.userInfo,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    facilityList: state.facility.facilityList,
    inventoryCoverageList: state.saleOrder.inventoryCoverageList,
  };
}

const mapDispatchToProps = dispatch => ({
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getInventoryCoverage: selectedParams => dispatch(getInventoryCoverage()),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(InventoryCoverage);
