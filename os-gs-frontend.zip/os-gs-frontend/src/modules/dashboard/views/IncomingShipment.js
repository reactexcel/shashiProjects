import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { getIncomingShipment } from "../../purchaseOrderFp/actions/purchaseOrderActions";
import PaginationUtil from "../../common/util/paginationUtil";
import { connect } from "react-redux";
import CommonUtil from '../../common/util/commonUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";
import { Redirect } from "react-router-dom";
import link from "assets/img/external-link.svg";

class IncomingShipment extends Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      redirectUrl: null,
      status: null,
      redirect: false,
      redirectUrl: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
  }

  componentDidMount = () => {
    mixpanel.track("Incoming Shipment page loaded");
    const managePageList = pagePropertyListConstant.MANAGE_INCOMING_SHIPMENT_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList['tableColumnList'],
      defaultPageSize: managePageList['defaultPageSize'],
      tableConfig: managePageList['tableConfig'],
      lastEvaluatedKeyArray: [],
      limit: managePageList.tableConfig.defaultPageSize
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  }

  makeCustomAPICall = (tempParamas) => {
    this.props.getIncomingShipment(tempParamas);
  }


  componentDidUpdate = (prevProps) => {
    if (this.props.incomingShipmentList != null && prevProps.incomingShipmentList != this.props.incomingShipmentList) {
      this.handleCustomPagination();
    }
  }

  handleCustomPagination = () => {
    if (CommonUtil.isNotNull(this.props.incomingShipmentList)) {
      PaginationUtil.handlePagination(this.props.incomingShipmentList, this);
    }
  }

  pageRedirect = () => {
    CommonUtil.handlePageRedirection('/admin/manage-purchase-order', this);
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <Col md={12} className="dashboard-table">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl }}></Redirect> : null
        }
        <Card
          title="Estimated Incoming Shipment"
          content={
            <>
              {tableColumnList != null ?
                <Row>
                  {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                    <>
                      <Table columns={tableColumnList}
                        data={tableDataList}
                        config={tableConfig}
                        getRowProps={this.getTdProps}
                        that={this}
                      />
                      <Col md={12} className="view-more">
                        <img src={link} alt="" className="link" onClick={this.pageRedirect} title="View More" />
                      </Col>
                    </>
                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                </Row>
                : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
            </>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    incomingShipmentList: state.purchaseOrder.incomingShipmentList,
  };
}

const mapDispatchToProps = dispatch => ({
  getIncomingShipment: (id) => dispatch(getIncomingShipment(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(IncomingShipment);
