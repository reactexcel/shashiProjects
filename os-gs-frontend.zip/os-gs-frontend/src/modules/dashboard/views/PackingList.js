import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { getSaleOrderPackingList } from "../../saleOrderFp/actions/saleOrderActions";
import PaginationUtil from "../../common/util/paginationUtil";
import { connect } from "react-redux";
import CommonUtil from '../../common/util/commonUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";
import { Redirect } from "react-router-dom";
import link from "assets/img/external-link.svg";
class PackingList extends Component {

  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      redirectUrl: null,
      status: null,
      redirect: false,
      redirectUrl: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
    };
  }

  componentDidMount = () => {
    mixpanel.track("Packing List page loaded");
    const managePageList = pagePropertyListConstant.MANAGE_PACKING_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList['tableColumnList'],
      defaultFilteredList: managePageList['defaultFilteredList'],
      defaultSortedList: managePageList['defaultSortedList'],
      defaultPageSize: managePageList['defaultPageSize'],
      tableConfig: managePageList['tableConfig'],
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  }

  makeCustomAPICall = (tempParamas) => {
    this.props.getSaleOrderPackingList(tempParamas);
  }


  componentDidUpdate(prevProps) {
    if (this.props.saleOrderPackingList != null && prevProps.saleOrderPackingList != this.props.saleOrderPackingList) {
      // this.handleCustomPagination();
      PaginationUtil.handlePagination(this.props.saleOrderPackingList, this);
    }
  }

  handleCustomPagination = () => {
    if (CommonUtil.isNotNull(this.props.saleOrderPackingList)) {
      PaginationUtil.handlePagination(this.props.saleOrderPackingList, this);
    }
  }

  pageRedirect = () => {
    CommonUtil.handlePageRedirection('/admin/manage-sale-order', this);
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <Col md={12} className="dashboard-table">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl }}></Redirect> : null
        }
        <Card
          title="Planned Packing/Dispatch List"
          content={
            <>
              {tableColumnList != null ?
                <Row>
                  {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                    <>
                       <Table columns={tableColumnList}
                        data={tableDataList}
                        config={tableConfig}
                        getRowProps={this.getTdProps}
                        that={this}
                      />
                      <Col md={12} className="view-more">
                        <img src={link} alt="" className="link" onClick={this.pageRedirect} title="View More"/>
                      </Col>
                    </>
                    : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                </Row>
                : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
            </>
          }
        />
      </Col>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    saleOrderPackingList: state.saleOrder.saleOrderPackingList,
  };
}

const mapDispatchToProps = dispatch => ({
  getSaleOrderPackingList: (id) => dispatch(getSaleOrderPackingList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(PackingList);
