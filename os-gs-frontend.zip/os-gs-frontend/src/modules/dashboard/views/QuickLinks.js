import React, { Component } from "react";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { Link, Redirect } from "react-router-dom";
import { connect } from "react-redux";
import * as dashboardConstant from '../constant/dashboardConstant';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { setActionMode } from "../../../actions/appActions";

class QuickLinks extends Component {
  constructor(props) {
    super(props);
    this.state = {
      redirect: false,
      redirectUrl: null,
    };
    this.handleQuickLinks = this.handleQuickLinks.bind(this);
  }

  componentDidMount = () => {
    this.setState({
      attributeList: pagePropertyListConstant.QUICKLINK_PAGE_LIST.attributeList,
      attributeObj: pagePropertyListConstant.QUICKLINK_PAGE_LIST.attributeList,
    })
  }

  handlePageRedirection = (redirectURL) => {
    this.setState({ redirect: true, redirectUrl: redirectURL }, () => {
    });
  }

  handleQuickLinks = (event) => {
    event.preventDefault();
    var tempId = event.target.id;
    if (tempId == dashboardConstant.CREATE_SUPPLIER) {
      this.props.setActionMode(dashboardConstant.CREATE_ACTION_MODE);
      this.handlePageRedirection(dashboardConstant.CREATE_SUPPLIER_PAGE_URL);
    }
    if (tempId == dashboardConstant.CREATE_PRODUCT) {
      this.props.setActionMode(dashboardConstant.CREATE_ACTION_MODE);
      this.handlePageRedirection(dashboardConstant.CREATE_PRODUCT_PAGE_URL);
    }
    if (tempId == dashboardConstant.CREATE_FACILITY) {
      this.props.setActionMode(dashboardConstant.CREATE_ACTION_MODE);
      this.handlePageRedirection(dashboardConstant.CREATE_FACILITY_PAGE_URL);
    }
  }

  render() {
    const { attributeList } = this.state;
    return (
      <div >
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        <div className="main-content quicklinks">
          <div>
              {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                <Button bsStyle="default" simple icon key={tempAttributeListObj.index}>
                  <div id={tempAttributeListObj.name}>
                    <i title={tempAttributeListObj.title} id={tempAttributeListObj.name} className={tempAttributeListObj.icon}>
                    </i>
                    <a id={tempAttributeListObj.name} onClick={this.handleQuickLinks}>{tempAttributeListObj.title}</a>
                  </div>
                </Button>
              ))}
          </div>
        </div>

      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    QuickLinks: state.product.QuickLinks,
  };
}

const mapDispatchToProps = dispatch => ({
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(QuickLinks);

