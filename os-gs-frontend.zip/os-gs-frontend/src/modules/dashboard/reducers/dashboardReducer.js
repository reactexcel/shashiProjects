import * as supplierActionTypes from "../actions/dashboardActionTypes";

const initialState = {
  supplierDetails: null,
  supplierList: null,
  selectedSupplierCode: null,
  supplierActionMode: null,
  generatedSupplierCode: null,
  documentURLObj:null
};

const supplierReducer = (state = initialState, action) => {
  switch (action.type) {
    case supplierActionTypes.SET_SUPPLIER_REDUCER_INIT_MODE:
      return {
        ...initialState,
      };
    case supplierActionTypes.SET_SUPPLIER_DETAILS:
      return {
        ...state,
        supplierDetails: action.payload
      };
    case supplierActionTypes.SET_UPLOADED_FILE_URL:
      return {
        ...state,
        documentURLObj: action.payload
      };  
    case supplierActionTypes.GET_SUPPLIER_LIST:
      return {
        ...state,
        supplierList: action.payload
      };
    case supplierActionTypes.SET_SELECTED_SUPPLIER_CODE:
      return {
        ...state,
        selectedSupplierCode: action.payload
      };
    case supplierActionTypes.SET_SUPPLIER_ACTION_MODE:
      return {
        ...state,
        supplierActionMode: action.payload
      }
    case supplierActionTypes.GET_SUPPLIER_DETAILS:
      return {
        ...state,
        supplierDetails: action.payload
      };
    case supplierActionTypes.GET_GENERATED_SUPPLIER_CODE:
      return {
        ...state,
        generatedSupplierCode: action.payload
      };
    default:
      return state;
  }
};

export default supplierReducer;
