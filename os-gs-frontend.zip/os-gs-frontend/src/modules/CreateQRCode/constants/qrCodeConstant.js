export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const CREATE_BARCODE_HEADER_TITLE = "Generate Bar Code";
export const MANAGE_BARCODE_URL = '/admin/manage-qrcode';
export const CREATE_BARCODE_URL = '/admin/create-barcode';
export const CREATE_QRCODE_URL = '/admin/create-qrcode';
export const MANAGE_QR_HEADER_TITLE = "UTI QR/Bar Code";