export const createQRCodeFormFields = [
    {
        name: "uti",
        type: "text",
        label: "UTI Number",
        required: true,
        width: 4,
        disabled: true
    }
];

export const nameAndWebUrlFormFields = [{
    name: "name",
    type: "text",
    label: "Name",
    required: true,
    width: 4,
    disabled: false,
    maxLength: 32,
    minLength: 3,
    mandatoryMsgText: "Field can not be empty.",
},
{
    name: "webUrl",
    type: "text",
    label: "Web Url",
    required: true,
    width: 4,
    disabled: true,
    defaultValue: "Default Url",
    mandatoryMsgText: "Field can not be empty.",
}
];

export const rangeComponent = [{
    name: "size",
    type: "range",
    label: "Size",
    required: true,
    width: 3,
    disabled: false,
    defaultValue: 5
}];

export const colorFieldsDefaultValue = [{
    name: "color",
    defaultValue: '#000000'
}, {
    name: "backGroundcolor",
    defaultValue: '#ffffff'
}, {
    name: "qrType",
    defaultValue: "square"
}, {
    name: "format",
    defaultValue: "png"
}];

const protocol = "https://";
const tenantId = "aurafuchsia";
const originScale = "originscale.io";

export const webUrlPrefix = `${protocol}${tenantId}.${originScale}`;
