export const validateQrCode = formValues => {
    const errors = {};

    if (!formValues.name) {
        errors.name = 'Please Enter Name';
    }

    if (formValues.name && (formValues.name.length < 3 || formValues.name.length >= 32)) {
        errors.name = 'Allowed characters limit is 3 to 32';
    }

    if (formValues.name && formValues.name.length >= 32) {
        formValues.name = formValues.name.slice(0, 32)
    }

    if (!formValues.productId || formValues.productId === 'Select') {
        errors.productId = 'You must Select Product';
    }

    if (!formValues.uti || formValues.uti === 'Select') {
        errors.uti = 'You must Select Batch';
    }

    return errors;
}