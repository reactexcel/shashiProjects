import axios from "axios";
import _ from "lodash";

import * as actionTypes from "./actionTypes";

import { beginAjaxCall, endAjaxCall } from "../../../actions/ajaxStatusActions";
const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const getConsumerPageData = (qrCodeMode, uti = "BATCH-0000") => {
  const cmsCode = "CMS-0001";
  const url = `${BASE_URL}/batches/${uti}/cms/${cmsCode}`;
  if (qrCodeMode === "add") {
    const cmsCode = "CMS-0000";
    const url = `${BASE_URL}/batches/${uti}/cms/${cmsCode}`;

    return (dispatch) => {
      dispatch(beginAjaxCall());
      return axios
        .get(url)
        .then((response) => {
          const data = response.data.Item.consumerPage;
          const defaultData = _.cloneDeep(data);
          dispatch({
            type: actionTypes.CONSUMER_PAGE,
            payload: { data, defaultData },
          });
          dispatch(endAjaxCall());
        })
        .catch((err) => console.log("error ==>", err));
    };
  } else {
    return (dispatch) => {
      dispatch(beginAjaxCall());
      let data;
      return axios
        .get(url)
        .then((response) => {
          const url = `${BASE_URL}/batches/BATCH-0000/cms/CMS-0000`;
          data = response.data.Item && response.data.Item.consumerPage;
          return axios.get(url);
        })
        .then((response) => {
          const defaultData = response.data.Item.consumerPage;
          dispatch({
            type: actionTypes.CONSUMER_PAGE,
            payload: { data, defaultData },
          });
          dispatch(endAjaxCall());
        })
        .catch((err) => console.log("error ==>", err));
    };
  }
};

export const uploadLogo = (file) => {
  return (dispatch) => {
    dispatch(beginAjaxCall());
    if (file) {
      uploadFileToServer(file)
        .then((response) => {
          const url = response.data;
          dispatch({
            type: actionTypes.UPDATE_LOGO,
            payload: { fileName: url },
          });
          dispatch(endAjaxCall());
        })
        .catch(() => {
          dispatch({
            type: actionTypes.ERROR_UPDATE_LOGO,
            payload: { err: "error" },
          });
          dispatch(endAjaxCall());
        });
    } else {
      dispatch({
        type: actionTypes.ERROR_UPDATE_LOGO,
        payload: { err: "error" },
      });
      dispatch(endAjaxCall());
    }
  };
};

export const deleteElement = (elementId) => {
  return {
    type: actionTypes.DELETE_ELEMENT,
    payload: { elementId },
  };
};

export const updateContentData = (data, id, name) => {
  return {
    type: actionTypes.UPDATE_CONTENT_DATA,
    payload: { data, id, name },
  };
};

export const uploadEditableFile = (
  fileDetails,
  id,
  name,
  productId,
  products
) => {
  return (dispatch) => {
    dispatch(beginAjaxCall());
    uploadFileToServer(fileDetails.file)
      .then((response) => {
        const url = response.data;
        const data = {
          src: url,
          altText: fileDetails.altText,
          width: fileDetails.width,
          height: fileDetails.height,
        };

        switch (id) {
          case "qualityInformation":
          case "productVitals": {
            const product = products.filter(
              (product) => product._id === Number(productId)
            )[0];
            const newProduct = {
              ...product,
              image: data,
            };

            const filterProducts = products.filter(
              (product) => product._id !== Number(productId)
            );

            let newProducts = [...filterProducts, newProduct];
            newProducts = _.orderBy(newProducts, ["_id"], ["asc"]);

            dispatch(updateContentData(newProducts, id, name));
            break;
          }

          case "similarRecommendations":
          case "blog": {
            const product = products.filter(
              (product) => product._id === Number(productId)
            )[0];

            const newProduct = {
              ...product,
              data: {
                ...product.data,
                image: data,
              },
            };

            const filterProducts = products.filter(
              (product) => product._id !== Number(productId)
            );

            let newProducts = [...filterProducts, newProduct];
            newProducts = _.orderBy(newProducts, ["_id"], ["asc"]);

            dispatch(updateContentData(newProducts, id, name));
            break;
          }

          default: {
            dispatch(updateContentData(data, id, name));
          }
        }
        dispatch(endAjaxCall());
      })
      .catch((error) => console.log(error));
  };
};

export const saveConsumerPageData = (data, uti) => {
  const url = `${BASE_URL}/batches/${uti}/cms`;

  const requestBody = {
    cmsCode: "CMS-0001",
    consumerPage: data,
  };

  return (dispatch) => {
    dispatch(beginAjaxCall());
    return axios
      .post(url, requestBody)
      .then(() => {
        dispatch({ type: actionTypes.SAVE_CONSUMER_PAGE_DATA });
        dispatch(endAjaxCall());
      })
      .catch((err) => console.log("error ==>", err));
  };
};

export const updateConsumerPageData = (data, uti) => {
  const cmsCode = "CMS-0001";
  const url = `${BASE_URL}/batches/${uti}/cms/${cmsCode}`;

  const requestBody = { consumerPage: data };

  return (dispatch) => {
    dispatch(beginAjaxCall());
    return axios
      .post(url, requestBody)
      .then(() => {
        dispatch({ type: actionTypes.UPDATE_CONSUMER_PAGE_DATA });
        dispatch(endAjaxCall());
      })
      .catch((err) => console.log("error ==>", err));
  };
};

export const addConsumerPageData = (data) => {
  return {
    type: actionTypes.ADD_CONSUMER_PAGE_DATA,
    payload: { data },
  };
};

export const updateElementsOrder = (elementsOrder) => {
  return {
    type: actionTypes.UPDATE_ELEMENTS_ORDER,
    payload: { elementsOrder },
  };
};

const uploadFileToServer = (file) => {
  const url = `${BASE_URL}/upload`;

  let headers = {
    "Access-Control-Allow-Origin": "*",
    methods: "GET,PUT,POST,DELETE",
  };
  const data = new FormData();
  data.append("file", file);
  data.append("filename", file.name);

  return axios.post(url, data, { headers });
};

export const uploadCarouselImages = (images) => {
  return (dispatch) => {
    dispatch(beginAjaxCall());

    const promiseArr = images.map((image) =>
      uploadFileToServer(image.imageObj)
    );

    Promise.all(promiseArr)
      .then((response) => {
        const uploadedImages = images.reduce((obj, item, index) => {
          obj[`image${item.id}`] = response[index].data;
          return obj;
        }, {});

        dispatch(updateCarouselImages(uploadedImages));
        dispatch(endAjaxCall());
      })
      .catch((err) => console.log("error ==>", err));
  };
};

export const updateCarouselImages = (carouselImagesList) => {
  if (carouselImagesList) {
    return {
      type: actionTypes.UPDATE_CAROUSEL,
      payload: { carouselImagesList },
    };
  }
};
