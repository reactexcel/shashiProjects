import axios from '../../../axios/axios';
import environment from '../../../environments/environments';
import {
    beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
    createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import * as qrActionTypes from './actionTypes';
const { API_PATHS } = environment;

export function getQRCodes(utiCode) {
    return function (dispatch) {
        dispatch(beginAjaxCall());
        return axios.get(API_PATHS.GET_QRCODES + "/" + utiCode).then(response => {
            if (response.status == 200) {
                dispatch({
                    type: qrActionTypes.GET_QRCODE_DETAILS,
                    payload: response.data
                });
            }
            dispatch(endAjaxCall());
        }).catch(error => {
            dispatch(endAjaxCall());
        });
    }
}

export function clearQRCodes() {
    return function (dispatch) {
        dispatch({
            type: qrActionTypes.CLEAR_ALL_QRCODES
        });
    }
}

export function clearPopupMessages() {
    return (dispatch) => {
        dispatch({
            type: qrActionTypes.CLEAR_POPUP_MESSAGES
        });
    }
}

export function createQRCode(qrCode) {
    return function (dispatch) {
        dispatch(beginAjaxCall());
        return axios.post(API_PATHS.POST_QRCODES, qrCode).then(response => {
            dispatch(setAjaxCallStatus(createApiResponse(response)));
            dispatch(endAjaxCall());
        }).catch(error => {
            dispatch(endAjaxCall());
            dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    }
}

export function editQrCode(qrCode) {
    qrCode.qrActionTypes = "QRCODE";
    return (dispatch) => {
        dispatch(beginAjaxCall());
        return axios.put(API_PATHS.EDIT_QRCODES + qrCode.uti, qrCode).then((response) => {
            dispatch(setAjaxCallStatus(updateApiResponse(response)));
            dispatch(endAjaxCall());
        }).catch(error => {
            dispatch(endAjaxCall());
            dispatch(setAjaxCallStatus(failedApiResponse(error)));
        })
    }
}