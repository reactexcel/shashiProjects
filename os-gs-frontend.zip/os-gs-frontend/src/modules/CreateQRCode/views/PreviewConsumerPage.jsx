import React from "react";
import { connect } from "react-redux";

import DesignConsumerPage from "./DesignConsumerPage";
import { getConsumerPageData } from "../actions/designConsumerPageActions";
import mixpanel from "../../analytics/mixpanel/mixpael";

const PreviewConsumerPage = (props) => {
    mixpanel.track("Preview consumer page loaded");
  return (
    <DesignConsumerPage
      designConsumerPageData={props.designConsumerPageData}
      getConsumerPageData={props.getConsumerPageData}
      uploadLogo={props.uploadLogo}
      updateCarouselImages={props.updateCarouselImages}
      deleteElement={props.deleteElement}
      mode="readOnly"
    />
  );
};

const mapStateToProps = (state) => {
  return {
    designConsumerPageData: state.designConsumerPage.data,
  };
};

export default connect(mapStateToProps, {
  getConsumerPageData,
})(PreviewConsumerPage);
