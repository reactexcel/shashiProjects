import React from "react";
import QRCodeStyling from "qr-code-styling";
import { QRCode } from "react-qr-svg";

import Button from "components/CustomButton/CustomButton.jsx";

class DownloadQRCode extends React.Component {
  constructor(props) {
    super(props);
    this.downloadCanvas = React.createRef();
    this.download = this.download.bind(this);
    this.generateQrCode = this.generateQrCode.bind(this);
    var downloadQRCode;
    this.state = {
      downloadProperties: props,
    };
  }

  componentWillReceiveProps(nextProps) {
    this.setState({ downloadProperties: nextProps });
  }
  download() {
    if (this.state.downloadProperties.format === "svg") {
      const svg = document.getElementById("qrId");
      const serializer = new XMLSerializer();
      const svgStr = serializer.serializeToString(svg);

      const url = "data:image/svg+xml;base64," + window.btoa(svgStr);

      let downloadLink = document.createElement("a");
      downloadLink.href = url;
      downloadLink.download = "qrCode.svg";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    } else {
      this.generateQrCode(this.state.downloadProperties);
      this.downloadQRCode.download(this.state.downloadProperties.format);
    }
  }

  generateQrCode({ size, color, backGroundcolor, qrType, webUrl }) {
    this.downloadQRCode = new QRCodeStyling({
      width: size * 31.5,
      height: size * 31.5,
      data: webUrl,
      //image: logo,
      dotsOptions: {
        color: color,
        type: qrType,
      },
      backgroundOptions: {
        color: backGroundcolor,
      },
      margin: "50",
    });
    const DOMNode = this.downloadCanvas.current;
    DOMNode.innerHTML = "";
    this.downloadQRCode.append(this.downloadCanvas.current);
  }

  render() {
    const {
      closeForm,
      backGroundcolor,
      color,
      size,
      webUrl,
      qrType,
    } = this.props;
    return (
      <React.Fragment>
        <div ref={this.downloadCanvas} hidden />
        <div hidden>
          <QRCode
            id="qrId"
            bgColor={backGroundcolor}
            fgColor={color}
            type={qrType}
            level="Q"
            style={{
              width: size * 31.5,
              height: size * 31.5,
            }}
            value={webUrl}
          />
        </div>
        <div>
          <Button fill wd bsStyle="info" type="reset" onClick={closeForm}>
            CANCEL
          </Button>
          <Button fill wd bsStyle="info" type="submit" onClick={this.download}>
            Download
          </Button>
        </div>
      </React.Fragment>
    );
  }
}

export default DownloadQRCode;
