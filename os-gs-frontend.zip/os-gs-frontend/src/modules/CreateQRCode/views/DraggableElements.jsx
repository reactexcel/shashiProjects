import React from "react";
import { DragDropContext, Droppable } from "react-beautiful-dnd";
import Element from "./components/Element";

const DraggableElements = (props) => {
  const renderView = () => {
    if (props.mode === "edit") {
      return (
        <DragDropContext onDragEnd={props.onDragEnd}>
          <div>
            <Droppable droppableId="droppableId">
              {(provided) => (
                <div ref={provided.innerRef} {...provided.droppableProps}>
                  {props.elements &&
                    props.elements.moveableElementsOrder.map((name, index) => (
                      <Element
                        key={name}
                        name={name}
                        updateContentData={props.updateContentData}
                        uploadEditableFile={props.uploadEditableFile}
                        deleteElement={props.deleteElement}
                        mode={props.mode}
                        elements={props.elements}
                        index={index}
                      />
                    ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        </DragDropContext>
      );
    }

    return (
      <div>
        {props.elements &&
          props.elements.moveableElementsOrder.map((name, index) => (
            <Element
              key={name}
              name={name}
              updateContentData={props.updateContentData}
              uploadEditableFile={props.uploadEditableFile}
              deleteElement={props.deleteElement}
              mode={props.mode}
              elements={props.elements}
              index={index}
            />
          ))}
      </div>
    );
  };
  return <div>{renderView()}</div>;
};

export default DraggableElements;
