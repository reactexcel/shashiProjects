import React, { Component } from "react";
import { Grid, Row, Col, FormControl } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constants/pagePropertyConstant';
import DownloadQRCode from "./DownloadQRCodeModal";
import { Base64 } from "js-base64";
import { connect } from "react-redux";
import { getQRCodes, clearQRCodes } from "../actions/qrcodeActions";
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import mixpanel from "../../analytics/mixpanel/mixpael";
class ManageQRCode extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      qrCode: null,
      status: null,
      showDownloadPopup: false,
      downloadFormState: null,

      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }


  componentDidMount = () => {
    mixpanel.track("Manage Qr code loaded");
    const managePageList = pagePropertyListConstant.MANAGE_QRCODE_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  }

  componentDidUpdate(prevProps) {
    if (prevProps.qrCodeList != this.props.qrCodeList && this.props.qrCodeList != null) {
      PaginationUtil.handlePagination(this.props.qrCodeList, this);
    }
  }

  componentWillUnmount() {
    this.props.clearQRCodes();
  }

  showDownloadModal = (qrCode) => {
    this.setState({ showDownloadPopup: true, downloadFormState: qrCode });
  };

  closeDowloadModal = () => {
    this.setState({ showDownloadPopup: false, downloadFormState: null });
  };

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.qrCodeList.Items.filter(value => {
      return (
        value.name.toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  makeCustomAPICall(tempParamas) {
    this.props.getQRCodes(tempParamas);
  }

  generateButtonHandler = () => {
    this.props.history.push("createqrcode");
  };

  editButtonHandler = (qrCode) => {
    this.props.history.push(
      `edit-qrcode?data=${Base64.encode(JSON.stringify(qrCode))}`
    );
  };


  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <div className="main-content manage-page">

        {this.state.showDownloadPopup && (
          <DownloadQRCode
            closeForm={this.closeDowloadModal}
            formHeading="Download QR Code"
            initialValues={this.state.downloadFormState}
          />
        )}

        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <i className="fa fa-cubes" />{" "}
                  QR Code
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search By Product Code / Name"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>

                  <Button id={"createQRCode"}
                    fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.generateButtonHandler}>
                    Generate QRCode
                  </Button>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>

                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    qrCodeList: state.qrcode.qrcodes
  };
}

const mapDispatchToProps = dispatch => ({
  getQRCodes: id => dispatch(getQRCodes(id)),
  clearQRCodes: data => dispatch(clearQRCodes(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageQRCode);
