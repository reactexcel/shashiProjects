import React from 'react';
import { useBarcode } from '@createnextapp/react-barcode';

function DownloadSKUBarCode({ SKUNumber }) {
  const barcodeId = `generatedBarcode${SKUNumber}`;
  const { inputRef } = useBarcode({
    value: SKUNumber,
    options: {
      displayValue: true,
      background: 'white',
      text: `${SKUNumber}`
    }
  });

  return (
    <div className="hidden" >
      <div id={barcodeId} className="design"><svg ref={inputRef} alt="" /></div>
    </div>)

};

export default DownloadSKUBarCode;