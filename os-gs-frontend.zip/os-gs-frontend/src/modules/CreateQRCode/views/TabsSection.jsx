import React from "react";
import { Tab } from "react-bootstrap";

import FormTabs from "../../../components/forms/common/FormTabs";
import DesignQRCode from "./DesignQRCode";
import DesignConsumerPage from "./DesignConsumerPage";

class TabSection extends React.Component {
  render() {
    const { change, formValues, changeTabHandler, index } = this.props;
    return (
      <FormTabs changeTabHandler={changeTabHandler}>
        <Tab id={index} eventKey={1} title="Design QR Code">
          <DesignQRCode change={change} />
        </Tab>
        {/* <Tab id={index} eventKey={2} title="Design Consumer Page">
          <DesignConsumerPage
            designConsumerPageData={this.props.designConsumerPageData}
            defaultDesignConsumerPageData={
              this.props.defaultDesignConsumerPageData
            }
            getConsumerPageData={this.props.getConsumerPageData}
            uploadLogo={this.props.uploadLogo}
            updateCarouselImages={this.props.updateCarouselImages}
            deleteElement={this.props.deleteElement}
            updateContentData={this.props.updateContentData}
            addConsumerPageData={this.props.addConsumerPageData}
            updateElementsOrder={this.props.updateElementsOrder}
            uploadCarouselImages={this.props.uploadCarouselImages}
            qrCodeMode={this.props.qrCodeMode}
            uti={this.props.uti}
            uploadEditableFile={this.props.uploadEditableFile}
            isSavedConsumerPage={this.props.isSavedConsumerPage}
            mode="edit"
          />
        </Tab> */}
      </FormTabs>
    );
  }
}

export default TabSection;
