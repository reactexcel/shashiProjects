import React from "react";
import { connect } from "react-redux";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import isEmpty from "lodash/isEmpty";
import CreateQRCode from "./CreateQRCode";
import { createQRCodeFormFields } from "../constants/createQRCodeConstants";
import mixpanel from "../../analytics/mixpanel/mixpael";

class EditQRCodePage extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeObj: null
    }
  }

  componentDidMount() {
    mixpanel.track("Edit Qr code loaded");
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj.Item);
    }
  }

  updateApiData = (attributeObj) => {
    this.setState({ attributeObj: attributeObj })
  }

  render() {
    let qrCodeObject = {};
    const { attributeObj } = this.state;
    if (!isEmpty(attributeObj)) {
      qrCodeObject = attributeObj;
    }

    return (
      <CreateQRCode
        createQRCodeFormFields={createQRCodeFormFields}
        initialValues={qrCodeObject}
        pageHeading="Edit QR Code"
        mode="edit"
      />
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    selectedUTICode: state.qrcode.selectedUTICode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    attributeObj: state.qrcode.qrCodeDetails,
  };
}

const mapDispatchToProps = dispatch => ({
  setAjaxCallStatus: init => dispatch(setAjaxCallStatus(init)),
});

export default connect(mapStateToProps, mapDispatchToProps)(EditQRCodePage);

