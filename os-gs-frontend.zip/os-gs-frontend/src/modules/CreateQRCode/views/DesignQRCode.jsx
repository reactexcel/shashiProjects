import React from "react";
import { formValueSelector } from "redux-form";
import { connect } from "react-redux";
import {
  Grid,
  Row,
  Col,
  OverlayTrigger,
  Tooltip,
  ControlLabel,
  FormGroup,
} from "react-bootstrap";
import { Field } from "redux-form";
import {
  RadioGroup,
  GroupButton,
  Range,
} from "../../../components/forms/common/FormFields";
import ColorPicker from "../../../components/forms/common/ColorPicker";
import { FormFieldsGenerator } from "../../../components/forms/FormFieldsGenerator";
import {
  nameAndWebUrlFormFields,
  webUrlPrefix,
} from "../constants/createQRCodeConstants";
import QRCodePreview from "./QRCodePreview";
import AlertBox from "../../../components/alert/AlertBox";
import { clearPopupMessages } from "../actions/qrcodeActions";

class DesignQRCode extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      color: "#000000",
      backGroundcolor: "#ffffff",
      format: "",
    };
    this.handleColorChange = this.handleColorChange.bind(this);
    this.handleBackgrounColorChange = this.handleBackgrounColorChange.bind(
      this
    );
  }

  componentWillReceiveProps({ color, backGroundcolor, format, batch }) {
    this.setState({ color, backGroundcolor, format });
    this.handleBatchChange(batch);
  }

  handleBatchChange = (batch) => {
    if (batch) {
      this.props.change("webUrl", `${webUrlPrefix}?batch=${batch}`);
    } else {
      this.props.change("webUrl", `${webUrlPrefix}`);
    }
  };

  handleColorChange(color) {
    this.props.change("color", color);
    this.setState({ color: color });
  }

  handleBackgrounColorChange(color) {
    this.props.change("backGroundcolor", color);
    this.setState({ backGroundcolor: color });
  }

  handleFormatChange = (format) => {
    this.setState({ format });
  };

  render() {
    const {
      size,
      qrType,
      webUrl,
      createSucessMessage,
      createErrorMessage,
      clearPopupMessages,
    } = this.props;
    const showAlert = createSucessMessage || createErrorMessage;
    let error = false;
    let success = false;
    let title = "";
    let confirmBtnBsStyle = "";
    if (createSucessMessage) {
      success = true;
      confirmBtnBsStyle = "info";
      title = "QR code generated successfully";
    }
    if (createErrorMessage) {
      error = true;
      title = "QR code generated failed";
      confirmBtnBsStyle = "error";
    }

    const { format } = this.state;
    return (
      <Grid fluid>
        <Row>
          <Col md={10} sm={10} offset={2}>
            <p>Choose Design</p>
          </Col>
        </Row>
        <Row>
          <Field
            name="qrType"
            disabled={false}
            component={RadioGroup}
            props={{ value: "square", currentValue: qrType }}
            label="Square"
          />
          <Field
            name="qrType"
            disabled={false}
            component={RadioGroup}
            props={{ value: "rounded", currentValue: qrType }}
            label="Rounded"
          />
          <Field
            name="qrType"
            disabled={false}
            component={RadioGroup}
            props={{ value: "dots", currentValue: qrType }}
            label="Dots"
          />
          <Col md={2} sm={2}></Col>
          <Col md={3} sm={3}>
            <QRCodePreview
              size={size}
              color={this.state.color}
              backGroundcolor={this.state.backGroundcolor}
              qrType={qrType}
              webUrl={webUrl}
              format={format}
            />
          </Col>
        </Row>
        <Row className="fields-section">
          <FormFieldsGenerator list={nameAndWebUrlFormFields} />
        </Row>
        <Row className="format-section">
          <Col md={1} sm={1}>
            <FormGroup>
              <ControlLabel>Format</ControlLabel>
            </FormGroup>
          </Col>
          <Col md={8} sm={11}>
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "png", currentValue: format }}
              onClick={this.handleFormatChange}
              label="PNG"
            />
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "jpg", currentValue: format }}
              onClick={this.handleFormatChange}
              label="JPG"
            />
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "svg", currentValue: format }}
              onClick={this.handleFormatChange}
              label="SVG"
            />
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "pdf", currentValue: format }}
              onClick={this.handleFormatChange}
              label="PDF"
            />
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "eps", currentValue: format }}
              onClick={this.handleFormatChange}
              label="EPS"
            />
            <Field
              name="format"
              disabled={false}
              component={GroupButton}
              props={{ value: "ps", currentValue: format }}
              onClick={this.handleFormatChange}
              label="PS"
            />
          </Col>
        </Row>
        <Row className="color-section">
          <Col md={4} sm={5}>
            <FormGroup>
              <ControlLabel>
                Color
              </ControlLabel>
              <Field
                ref={(input) => (this.colorValue = input)}
                name="color"
                component="input"
                type="hidden"
              />
              <Field
                name="color"
                props={{ value: this.state.color }}
                component={ColorPicker}
                onColorChange={this.handleColorChange}
              />
            </FormGroup>
          </Col>
          <Col md={4} sm={5}>
            <FormGroup>
              <ControlLabel>
                Background Color
              </ControlLabel>
              <Field
                ref={(input) => (this.colorValue = input)}
                name="backGroundcolor"
                component="input"
                type="hidden"
              />
              <Field
                name="backGroundcolor"
                component={ColorPicker}
                props={{ value: this.state.backGroundcolor }}
                onColorChange={this.handleBackgrounColorChange}
              />
            </FormGroup>
          </Col>
        </Row>
        <Row className="size-section">
          <Col md={1} sm={1}>
            <FormGroup>
              <ControlLabel>
                Size
                <OverlayTrigger
                  placement="right"
                  delay={{ show: 250, hide: 400 }}
                  overlay={
                    <Tooltip id="">
                      Preview image does not show actual size of QR Code. Please
                      download QR Code to see the actual size
                    </Tooltip>
                  }
                >
                  <i className="fa fa-info-circle" aria-hidden="true" />
                </OverlayTrigger>
              </ControlLabel>
            </FormGroup>
          </Col>
          <Col md={5} sm={6}>
            <Field
              name="size"
              disabled={false}
              component={Range}
              props={{ min: 5, max: 15 }}
            />
          </Col>
        </Row>
        {showAlert && (
          <AlertBox
            error={error}
            success={success}
            confirmBtnBsStyle={confirmBtnBsStyle}
            closeAlert={clearPopupMessages}
            title={title}
          />
        )}
      </Grid>
    );
  }
}

const valueSelector = formValueSelector("createQrCodeForm");

const mapStateToProps = (state) => ({
  batch: valueSelector(state, "uti"),
  size: valueSelector(state, "size"),
  format: valueSelector(state, "format"),
  color: valueSelector(state, "color"),
  backGroundcolor: valueSelector(state, "backGroundcolor"),
  qrType: valueSelector(state, "qrType"),
  webUrl: valueSelector(state, "webUrl"),
  createSucessMessage: state.qrcode.createSucessMessage,
  createErrorMessage: state.qrcode.createErrorMessage,
});

export default connect(mapStateToProps, { clearPopupMessages })(DesignQRCode);
