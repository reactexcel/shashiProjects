import React, { Fragment, useState, useEffect } from "react";
import { withRouter, Link } from "react-router-dom";
import { DragDropContext, Droppable } from "react-beautiful-dnd";
import _ from "lodash";
import styled from "styled-components";
import { Grid, Row, Col, Button } from "react-bootstrap";
import QueryString from "query-string";
import { Base64 } from "js-base64";

import Card from "components/Card/Card.jsx";
import Carousel from "./components/Carousel";
import Footer from "./components/Footer";
import NavBar from "./components/NavBar";
import Element from "./components/Element";
import DraggableElements from "./DraggableElements";

import "./DesignConsumerPage.css";

const Styles = styled.div`
  .row {
    margin-right: 0px;
    margin-left: 0px;
  }

  .card {
    border-radius: 0px;
    background-color: #fdf6ff;
  }
  .card .content {
    padding: 0px;
  }

  .mb-5,
  .my-5 {
    margin-bottom: 3rem;
  }

  .pt-5,
  .py-5 {
    padding-top: 3rem;
  }

  .pb-3,
  .py-3 {
    padding-bottom: 1rem;
    padding-top: 1rem;
  }

  .mb-2,
  .my-2 {
    margin-bottom: 0.5rem !important;
  }

  .btn-success {
    color: #fff;
    background-color: #28a745;
    border-color: #28a745;
  }

  .col-md-12,
  .container-fluid {
    padding-left: 0px;
    padding-right: 0px;
  }

  .carousel-indicators {
    margin-left: 20%;
  }

  .fileContainer {
    padding: 0;
    margin: 0;
    flex-direction: row;
    background: unset;
    box-shadow: unset;
  }

  .fileContainer p {
    display: none;
  }

  .fileContainer .chooseFileButton {
    padding: 0;
    border-radius: 0;
  }

  .fa-upload {
    font-size: 20px;
    color: #28a745;
  }

  .fa-trash {
    font-size: 20px;
    color: #dc143c;
  }

  .btn-info:hover {
    background-color: #23ccef;
    color: #fff;
  }

  .textboxaboutproduct {
    margin: 0;
  }
`;

const DesignConsumerPage = (props) => {
  useEffect(() => {
    let qrCodeMode;
    let uti;

    if (props.qrCodeMode) {
      qrCodeMode = props.qrCodeMode;
      uti = props.uti;
    } else {
      if (props.location.search) {
        const queryParams = QueryString.parse(props.location.search);
        const data = JSON.parse(Base64.decode(queryParams.data));
        qrCodeMode = data.qrCodeMode;
        uti = data.uti;
      }
    }
   // props.getConsumerPageData(qrCodeMode, uti);
  }, []);

  const uploadLogo = (file) => {
    props.uploadLogo(file);
  };

  const updateCarouselImages = (carouselImagesList) => {
    props.updateCarouselImages(carouselImagesList);
  };

  const deleteElement = (elementId) => {
    props.deleteElement(elementId);
  };

  const addConsumerPageElement = (elements) => {
    const data = _.cloneDeep(props.designConsumerPageData);
    elements.forEach((element) => {
      data.elements[element] =
        props.defaultDesignConsumerPageData.elements[element];
    });

    props.addConsumerPageData(data);
  };

  const onDragEnd = (result) => {
    const { draggableId, source, destination } = result;

    if (!destination) {
      return;
    }

    if (destination.index === source.index) {
      return;
    }

    const moveableElementsOrder = [
      ...props.designConsumerPageData.elements.moveableElementsOrder,
    ];

    moveableElementsOrder.splice(source.index, 1);
    moveableElementsOrder.splice(destination.index, 0, draggableId);

    props.updateElementsOrder(moveableElementsOrder);
  };

  const openPreview = () => {
    let data;
    if (props.qrCodeMode === "edit" || props.isSavedConsumerPage) {
      data = {
        qrCodeMode: "edit",
        uti: props.uti,
      };
    } else {
      data = {
        qrCodeMode: "add",
      };
    }

    const url = `preview?data=${Base64.encode(JSON.stringify(data))}`;
    return (
      <Link to={url} target="_blank">
        <Button>Preview</Button>
      </Link>
    );
  };

  const renderView = () => {
    const { elements } = props.designConsumerPageData
      ? props.designConsumerPageData
      : {};
    const { mode } = props;

    if (elements) {
      return (
        <Grid fluid>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <Fragment>
                    {elements.header && (
                      <NavBar
                        header={elements.header}
                        uploadLogo={uploadLogo}
                        mode={mode}
                        addConsumerPageElement={addConsumerPageElement}
                        openPreview={openPreview}
                        defaultDesignConsumerPageData={
                          props.defaultDesignConsumerPageData
                        }
                        elements={elements}
                      ></NavBar>
                    )}
                    {/* <div className="container"> */}
                    {elements.carousel && (
                      <Carousel
                        carousel={elements.carousel}
                        updateCarouselImages={updateCarouselImages}
                        uploadCarouselImages={props.uploadCarouselImages}
                        mode={mode}
                      />
                    )}

                    <DraggableElements
                      onDragEnd={onDragEnd}
                      elements={elements}
                      updateContentData={props.updateContentData}
                      uploadEditableFile={props.uploadEditableFile}
                      deleteElement={deleteElement}
                      mode={mode}
                    />
                    {/* <DragDropContext onDragEnd={onDragEnd}>
                      <div>
                        <Droppable droppableId="droppableId">
                          {(provided) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.droppableProps}
                            >
                              {elements &&
                                elements.moveableElementsOrder.map(
                                  (name, index) => (
                                    <Element
                                      key={name}
                                      name={name}
                                      updateContentData={
                                        props.updateContentData
                                      }
                                      uploadEditableFile={
                                        props.uploadEditableFile
                                      }
                                      deleteElement={deleteElement}
                                      mode={mode}
                                      elements={elements}
                                      index={index}
                                    />
                                  )
                                )}
                              {provided.placeholder}
                            </div>
                          )}
                        </Droppable>
                      </div>
                    </DragDropContext> */}
                    {elements.footer && (
                      <Footer
                        updateContentData={props.updateContentData}
                        footer={elements.footer}
                        mode={mode}
                      />
                    )}
                  </Fragment>
                }
              />
            </Col>
          </Row>
        </Grid>
      );
    }

    return null;
  };

  return <Styles>{renderView()}</Styles>;
};

export default withRouter(DesignConsumerPage);
