import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import * as pagePropertyListConstant from '../constants/pagePropertyConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { setBarCodeDetails, getBarCodeDetails, setReducerInitMode } from "../actions/barCodeActions";
import * as barCodeConstat from '../constants/barCodeConstant';
import GenerateBarCode from "./GenerateBarCode";
import * as qrCodeConstant from '../constants/qrCodeConstant';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import TextBoxUtil from '../../common/util/textBoxUtil';
import _ from 'lodash'
import scan from "assets/img/scan-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import barcode from "assets/img/barcode.svg";

class CreateBarCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      generatedBarcode: null,
      submitted: false,
      alert: null,
    };

    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Create Bar Code loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getBarCodeDetails(this.props.selectedUTICode);
      }
    } else {
      CommonUtil.handlePageRedirection(barCodeConstat.MANAGE_BARCODE_PAGE_URL, this);
    }
    const topAttributeList = pagePropertyListConstant.CREATE_BARCODE_HEADER_LIST(this);
    const commonAttributeList = pagePropertyListConstant.CREATE_BARCODE_LIST(this);
    let attributeObj = commonAttributeList.attributeObj;
    attributeObj.uti = this.props.selectedUTICode;
    this.setState({
      topAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        topAttributeList.attributeList, this.props.dataDictionaryList),
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: attributeObj,
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      setTimeout(this.handlePopupContinue, 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  async updateApiData(attributeObj) {
    await this.setState({
      attributeObj: {
        ...attributeObj,
      },
    })
  }

  handleSave(event) {
    this.setState({ submitted: true });
    var tempObj = this.state.attributeObj;
    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, this.props.actionMode);
    tempObj.uti = this.props.selectedUTICode;
    if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList) &&
      tempObj.uti) {
      this.props.setBarCodeDetails(tempObj, this.props.actionMode);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(qrCodeConstant.MANAGE_BARCODE_URL, this);
  }

  render() {
    const { attributeList, submitted, topAttributeList, attributeObj } = this.state;
    const actionMode = this.props.actionMode;

    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={scan} alt="" className="page-icon" />
                  {qrCodeConstant.CREATE_BARCODE_HEADER_TITLE}
                </div>
              </Col>

            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row>
                        <Col md={12}>
                          <Row>
                            {topAttributeList != null && topAttributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : null))
                            }
                          </Row>
                        </Col>
                      </Row>
                      <Row>
                        <Col md={12}>
                          <div className="title">Sample Design</div>
                        </Col>
                        <Col md={12} className="barcode-section">
                          <div className="barcode-image-wrapper active">
                            <img src={barcode} alt="" />
                          </div>
                          <GenerateBarCode
                            attributeObj={attributeObj} />
                        </Col>
                      </Row>
                      <Row>
                        <Col md={8}>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : null))
                            }
                          </Row>
                        </Col>
                      </Row>
                    </div>
                  }
                  ftTextRight
                  legend={
                    <div>
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={() => this.handleSave(this)}>Save</Button>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    selectedUTICode: state.qrcode.selectedUTICode,
    attributeObj: state.qrcode.barCodeDetails,
  };
}

const mapDispatchToProps = dispatch => ({
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  setBarCodeDetails: (productDetailsObj, actionMode) => dispatch(setBarCodeDetails(productDetailsObj, actionMode)),
  getBarCodeDetails: selectedUTICode => dispatch(getBarCodeDetails(selectedUTICode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateBarCode);
