import React from 'react';
import { useBarcode } from '@createnextapp/react-barcode';

function GenerateBarCode(props) {
  const { inputRef } = useBarcode({
    value: JSON.stringify(props.attributeObj),
    options: {
      displayValue: false,
      background: 'white',
    }
  });

  return (
    <div className="preview">
      <div className="title">Preview</div>
      <div id="barCode" className="design"><svg ref={inputRef} alt="" /></div>
      <div className="size">Size (cm) 5*3</div>
    </div>)

};

export default GenerateBarCode;