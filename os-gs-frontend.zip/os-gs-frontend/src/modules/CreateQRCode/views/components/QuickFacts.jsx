import React from "react";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import FileUpload from "./FileUpload";

const QuickFacts = ({
  mode,
  quickFacts,
  updateContentData,
  uploadEditableFile,
  deleteElement,
}) => {
  const deleteHandler = () => {
    deleteElement("quickFacts");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "quickFacts";
    const name = "title";

    updateContentData(data, id, name);
  };

  const descriptionHandler = (event) => {
    const data = event.editor.getData();
    const id = "quickFacts";
    const name = "description";

    updateContentData(data, id, name);
  };

  const uploadFile = (fileDetails) => {
    const id = "quickFacts";
    const name = "image";
    uploadEditableFile(fileDetails, id, name);
  };

  const renderView = () => {
    const { operation, content } = quickFacts;

    if (mode === "edit") {
      return (
        <>
          {operation.remove && (
            <div id="hoverShow2">
              <ul className="hoversetting">
                <li>
                  <span className="hoverbuttons" onClick={deleteHandler}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </span>
                </li>
              </ul>
            </div>
          )}
          <div id="introduction3" style={{ padding: "15px" }}>
            <FileUpload
              src={
                content.image
                  ? content.image.src
                  : "http://localhost:3000/assets/local_library-24px.png"
              }
              altText={content.image ? content.image.altText : "alt text"}
              width={content.image ? content.image.width : "100"}
              height={content.image ? content.image.height : "100"}
              uploadFile={uploadFile}
            />
            <TekCKEditor data={content.title} onChange={titleHandler} />
            <TekCKEditor
              data={content.description}
              onChange={descriptionHandler}
            />
          </div>
        </>
      );
    }

    return (
      <div id="introduction3" style={{ padding: "15px" }}>
        <FileUpload
          src={
            content.image
              ? content.image.src
              : "http://localhost:3000/assets/local_library-24px.png"
          }
          altText={content.image ? content.image.altText : "alt text"}
          width={content.image ? content.image.width : "100"}
          height={content.image ? content.image.height : "100"}
        />
        <EditorPreview data={content.title} />
        <EditorPreview data={content.description} />
      </div>
    );
  };
  return (
    <div className="row">
      <div className="col-lg-3 hide-xs"></div>
      <div className="col-lg-6 col-xs-12">
        <div className="hoverWrapper">{renderView()}</div>
        <div className="col-lg-3 hide-xs"></div>
      </div>
    </div>
  );
};

export default QuickFacts;
