import React, { useState } from "react";
import styled from "styled-components";
import { Modal, Button } from "react-bootstrap";
import ImageUploader from "react-images-upload";

const Container = styled.div`
  .fileContainer {
    justify-content: left;
    flex-direction: row;
    margin: 0;
    padding: 0;
  }
  .fileContainer p {
    display: none;
  }

  .selected-image-label {
    position: absolute;
    top: 32px;
    left: 130px;
  }

  .slider {
    position: relative;
  }
`;

const FileUploadModal = ({
  show,
  carouselImages,
  setImagesToCarousel,
  closeModal,
  handleFile1Change,
  handleFile2Change,
  handleFile3Change,
}) => {
  return (
    <Modal show={show} onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>Upload Images</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Container>
          <div className="slider">
            Slider 1
            {/* <input id="fileupload" type="file" onChange={handleFile1Change} /> */}
            <ImageUploader
              withIcon={false}
              buttonText="Choose File"
              onChange={handleFile1Change}
              imgExtension={[".jpg", ".gif", ".png", ".gif"]}
              singleImage={true}
            />
            <span className="selected-image-label">
              {carouselImages.image1 ? carouselImages.image1.name : null}
            </span>
          </div>
          <div className="slider">
            slider 2
            {/* <input id="fileupload1" type="file" onChange={handleFile2Change} /> */}
            <ImageUploader
              withIcon={false}
              buttonText="Choose File"
              onChange={handleFile2Change}
              imgExtension={[".jpg", ".gif", ".png", ".gif"]}
              singleImage={true}
            />
            <span className="selected-image-label">
              {carouselImages.image2 ? carouselImages.image2.name : null}
            </span>
          </div>
          <div className="slider">
            slider 3
            {/* <input id="fileupload1" type="file" onChange={handleFile3Change} /> */}
            <ImageUploader
              withIcon={false}
              buttonText="Choose File"
              onChange={handleFile3Change}
              imgExtension={[".jpg", ".gif", ".png", ".gif"]}
              singleImage={true}
            />
            <span className="selected-image-label">
              {carouselImages.image3 ? carouselImages.image3.name : null}
            </span>
          </div>
        </Container>
      </Modal.Body>
      <Modal.Footer>
        <Button bsStyle="primary" onClick={setImagesToCarousel}>
          Done
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default FileUploadModal;
