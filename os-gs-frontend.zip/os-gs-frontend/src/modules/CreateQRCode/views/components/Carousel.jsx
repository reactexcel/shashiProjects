import React, { useState } from "react";
import { Carousel } from "react-bootstrap";
import styled from "styled-components";

import FileUploadModal from "./FileUploadModal";

const CarouselStyles = styled.div`
  .item {
    min-height: 150px;
    max-height: 500px;
  }

  a.carousel-control {
    display: none;
  }

  ol.carousel-indicators > li {
    width: 30px;
    height: 3px;
    margin: 0 3px;
    background-color: #fff;
    opacity: 0.5;
    border-radius: unset;
  }

  ol.carousel-indicators > li.active {
    opacity: 1;
  }
`;
const CarouselView = ({
  mode,
  carousel,
  closeCarousel,
  updateCarouselImages,
  uploadCarouselImages,
}) => {
  const [showSettingsModal, setSettingsModal] = useState(false);
  const [carouselImages, setCarouselImages] = useState({
    image1: null,
    image2: null,
    image3: null,
  });

  const [fileUrl1, setFileUrl1] = useState();
  const [fileUrl2, setFileUrl2] = useState();
  const [hoverElement, setHoverElement] = useState("none");

  const closeModal = () => {
    setSettingsModal(false);
    setCarouselImages({ image1: null, image2: null, image3: null });
  };

  const getFileUrl = (file) => {
    if (file[0]) {
      return `../assets/${file[0].name}`;
    }
  };

  const handleFile1Change = (file) => {
    setCarouselImages({ ...carouselImages, image1: file[0] });
  };

  const handleFile2Change = (file) => {
    setCarouselImages({ ...carouselImages, image2: file[0] });
  };

  const handleFile3Change = (file) => {
    setCarouselImages({ ...carouselImages, image3: file[0] });
  };

  const setImagesToCarousel = () => {
    closeModal();

    let images = [
      { id: 1, imageObj: carouselImages.image1 },
      { id: 2, imageObj: carouselImages.image2 },
      { id: 3, imageObj: carouselImages.image3 },
    ];

    images = images.filter((image) => image.imageObj);

    uploadCarouselImages(images);
  };

  return (
    <React.Fragment>
      <div
        id="carouselExampleIndicators"
        className="carousel slide"
        data-ride="carousel"
        onMouseEnter={() => setHoverElement("block")}
        onMouseLeave={() => setHoverElement("none")}
        style={{ minHeight: "150px", maxHeight: "500px", height: "150px" }}
      >
        <CarouselStyles>
          {mode === "edit" && (
            <div
              style={{ overflow: "unset" }}
              className="carousel-inner hoverWrapper"
            >
              <div id="hoverShow1" style={{ display: hoverElement }}>
                <ul className="hoversetting">
                  <li>
                    <span
                      className="hoverbuttons"
                      onClick={() => setSettingsModal(true)}
                    >
                      <i className="fa fa-upload" aria-hidden="true"></i>
                    </span>
                  </li>
                </ul>
              </div>
            </div>
          )}
          <Carousel>
            <Carousel.Item
              style={{
                backgroundImage: `url(${carousel.image1})`,
              }}
            ></Carousel.Item>
            <Carousel.Item
              style={{
                backgroundImage: `url(${carousel.image2})`,
              }}
            ></Carousel.Item>
            <Carousel.Item
              style={{
                backgroundImage: `url(${carousel.image3})`,
              }}
            ></Carousel.Item>
          </Carousel>
        </CarouselStyles>
      </div>

      <FileUploadModal
        show={showSettingsModal}
        carouselImages={carouselImages}
        setImagesToCarousel={setImagesToCarousel}
        closeModal={closeModal}
        handleFile1Change={handleFile1Change}
        handleFile2Change={handleFile2Change}
        handleFile3Change={handleFile3Change}
      />
    </React.Fragment>
  );
};

export default CarouselView;
