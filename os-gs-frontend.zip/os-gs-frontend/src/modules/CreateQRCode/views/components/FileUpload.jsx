import React, { useReducer, useRef } from "react";
import styled from "styled-components";
import {
  Grid,
  Row,
  Col,
  Modal,
  Button,
  FormGroup,
  ControlLabel,
  FormControl,
} from "react-bootstrap";

const Styles = styled.div`
  .editable-img: hover {
    cursor: pointer;
  }
`;

const fileUploadReducer = (state, action) => {
  switch (action.type) {
    case "SHOW_MODAL": {
      return {
        ...state,
        show: action.show,
        src: action.src,
        altText: action.altText,
        width: action.width,
        height: action.height,
        file: action.file,
      };
    }

    case "BROWSE_IMG": {
      return {
        ...state,
        src: action.src,
        file: action.file,
      };
    }

    case "CHANGE_ALT_TEXT": {
      return {
        ...state,
        altText: action.altText,
      };
    }

    case "CHANGE_WIDTH": {
      return {
        ...state,
        width: action.width,
      };
    }

    case "CHANGE_HEIGHT": {
      return {
        ...state,
        height: action.height,
      };
    }

    default: {
      throw new Error("Should not get there!");
    }
  }
};

const FileUpload = ({ src, altText, width, height, uploadFile, id }) => {
  const [fileUploadState, dispatch] = useReducer(fileUploadReducer, {});
  const fileRef = useRef(null);

  const openFileUploadPopup = () => {
    dispatch({
      type: "SHOW_MODAL",
      show: true,
      src,
      altText,
      width,
      height,
      file: null,
    });
  };

  const hideModal = () => {
    dispatch({ type: "SHOW_MODAL", show: false });
  };

  const altTextHandler = (event) => {
    dispatch({ type: "CHANGE_ALT_TEXT", altText: event.target.value });
  };

  const widthHandler = (event) => {
    dispatch({ type: "CHANGE_WIDTH", width: event.target.value });
  };

  const heightHandler = (event) => {
    dispatch({ type: "CHANGE_HEIGHT", height: event.target.value });
  };

  const changeFileHandler = (event) => {
    event.stopPropagation();
    event.preventDefault();
    const file = event.target.files[0];
    const name = file.name;
    dispatch({ type: "BROWSE_IMG", src: name, file });
  };

  const uploadImage = (event) => {
    event.preventDefault();
    hideModal();
    uploadFile(fileUploadState, event.target.id);
  };

  return (
    <Styles>
      {uploadFile ? (
        <div className="file-upload-container" onClick={openFileUploadPopup}>
          <img
            className="editable-img"
            src={src}
            alt={altText}
            width={width}
            height={height}
          />
        </div>
      ) : (
        <div className="file-upload-container">
          <img src={src} alt={altText} width={width} height={height} />
        </div>
      )}
      <div>
        <Modal show={fileUploadState.show} onHide={hideModal}>
          <Modal.Header closeButton>
            <Modal.Title>Upload Image</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <FormGroup controlId="url">
              <ControlLabel style={{ display: "block" }}>Url</ControlLabel>
              <input
                type="file"
                ref={fileRef}
                onChange={changeFileHandler}
                style={{ display: "none" }}
              />
              <FormControl
                type="text"
                value={fileUploadState.src}
                disabled
                style={{ display: "inline-block", width: "70%" }}
              />
              <Button
                onClick={() => fileRef.current.click()}
                style={{ display: "inline-block", float: "right" }}
              >
                Browse
              </Button>
            </FormGroup>
            <FormGroup controlId="altText">
              <ControlLabel>Alt Text</ControlLabel>
              <FormControl
                type="text"
                value={fileUploadState.altText}
                onChange={altTextHandler}
              />
            </FormGroup>
            <FormGroup controlId="width">
              <ControlLabel>Width</ControlLabel>
              <FormControl
                type="number"
                value={fileUploadState.width}
                onChange={widthHandler}
              />
            </FormGroup>
            <FormGroup controlId="height">
              <ControlLabel>Height</ControlLabel>
              <FormControl
                type="number"
                value={fileUploadState.height}
                onChange={heightHandler}
              />
            </FormGroup>
          </Modal.Body>
          <Modal.Footer>
            <Button
              id={id}
              onClick={uploadImage}
              disabled={!fileUploadState.file}
            >
              Upload
            </Button>
          </Modal.Footer>
        </Modal>
      </div>
    </Styles>
  );
};

export default FileUpload;
