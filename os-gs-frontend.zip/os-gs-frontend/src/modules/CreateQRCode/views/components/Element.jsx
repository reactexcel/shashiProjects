import React from "react";
import { Draggable } from "react-beautiful-dnd";

import TraceabilityInformation from "./TraceabilityInformation";
import QuickFacts from "./QuickFacts";
import TraceabilityMap from "./TraceabilityMap";
import TraceabilityScore from "./TraceabilityScore";
import AboutProduct from "./AboutProduct";
import QualityInformation from "./QualityInformation";
import ProductVitals from "./ProductVitals";
import SimilarRecommendations from "./SimilarRecommendations";
import Blog from "./Blog";

const Element = ({
  name,
  elements,
  updateContentData,
  uploadEditableFile,
  deleteElement,
  index,
  mode,
}) => {
  const renderView = (name) => {
    switch (name) {
      case "aboutProduct": {
        return (
          <AboutProduct
            aboutProduct={elements[name]}
            updateContentData={updateContentData}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "traceabilityScore": {
        return (
          <TraceabilityScore
            traceabilityScore={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "traceabilityMap": {
        return (
          <TraceabilityMap
            traceabilityMap={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "quickFacts": {
        return (
          <QuickFacts
            quickFacts={elements[name]}
            updateContentData={updateContentData}
            uploadEditableFile={uploadEditableFile}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "traceabilityInformation": {
        return (
          <TraceabilityInformation
            traceabilityInformation={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "qualityInformation": {
        return (
          <QualityInformation
            updateContentData={updateContentData}
            uploadEditableFile={uploadEditableFile}
            qualityInformation={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "productVitals": {
        return (
          <ProductVitals
            updateContentData={updateContentData}
            uploadEditableFile={uploadEditableFile}
            productVitals={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "similarRecommendations": {
        return (
          <SimilarRecommendations
            updateContentData={updateContentData}
            uploadEditableFile={uploadEditableFile}
            similarRecommendations={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
      case "blog": {
        return (
          <Blog
            updateContentData={updateContentData}
            uploadEditableFile={uploadEditableFile}
            blog={elements[name]}
            deleteElement={deleteElement}
            mode={mode}
          />
        );
      }
    }
  };

  const decideDraggable = () => {
    if (mode === "edit") {
      return (
        <Draggable draggableId={name} index={index}>
          {(provided) => (
            <div
              {...provided.draggableProps}
              {...provided.dragHandleProps}
              ref={provided.innerRef}
            >
              {renderView(name)}
            </div>
          )}
        </Draggable>
      );
    }

    return renderView(name);
  };
  return elements[name] ? <>{decideDraggable()}</> : null;
};

export default Element;
