import React, { useState } from "react";
import { Button } from "react-bootstrap";

const KnowMore = ({
  mode = "readOnly",
  title = "Know More",
  onClick,
  url,
  saveUrl,
}) => {
  const [knowMoreField, setknowMoreField] = useState(false);
  const [knowMoreUrl, setKnowMoreUrl] = useState(url);

  const doneHandler = () => {
    setknowMoreField(false);
    saveUrl(knowMoreUrl);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <>
          {!knowMoreField && (
            <div style={{ padding: "0 15px" }}>
              <Button
                style={{ margin: "0" }}
                bsStyle="info"
                onClick={() => setknowMoreField(true)}
              >
                {title}
              </Button>
            </div>
          )}
          {knowMoreField && (
            <div style={{ padding: "0 15px" }}>
              <input
                type="text"
                placeholder="https://example.com"
                value={knowMoreUrl}
                onChange={(e) => setKnowMoreUrl(e.target.value)}
                style={{
                  display: "inline-block",
                  width: "300px",
                  fontSize: "14px",
                  fontWeight: "400",
                }}
              />
              <Button
                bsStyle="success"
                onClick={doneHandler}
                style={{ display: "inline-block" }}
              >
                Done
              </Button>
            </div>
          )}
        </>
      );
    }

    return (
      <div style={{ padding: "0 15px" }}>
        <Button style={{ margin: "0" }} bsStyle="info" onClick={onClick}>
          Know More
        </Button>
      </div>
    );
  };

  return <>{renderView()}</>;
};

export default KnowMore;
