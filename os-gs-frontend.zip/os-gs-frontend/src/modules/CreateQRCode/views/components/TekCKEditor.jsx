import React, { useEffect, useRef } from "react";
import CKEditor from "ckeditor4-react";

const BASE_URL = process.env.REACT_APP_API_BASE_URL;
const TekCKEditor = ({ data, config, onChange }) => {
  return (
    <div style={{ padding: "15px" }}>
      <CKEditor
        type="inline"
        data={data}
        config={{
          ...config,
          filebrowserUploadUrl: `${BASE_URL}/upload`,
        }}
        onChange={onChange}
        onBeforeLoad={(CKEDITOR) => (CKEDITOR.disableAutoInline = true)}
      />
    </div>
  );
};

export default TekCKEditor;
