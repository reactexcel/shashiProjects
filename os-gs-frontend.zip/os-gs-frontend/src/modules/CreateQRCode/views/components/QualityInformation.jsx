import React from "react";
import _ from "lodash";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import FileUpload from "./FileUpload";

const QualityInformation = ({
  mode,
  qualityInformation,
  updateContentData,
  uploadEditableFile,
  deleteElement,
}) => {
  const { operation, content } = qualityInformation;

  const deleteHandler = () => {
    deleteElement("qualityInformation");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "qualityInformation";
    const name = "title";

    updateContentData(data, id, name);
  };

  const documentHandler = (event) => {
    const documentId = event.editor.config.bodyId;
    const document = content.documents.filter(
      (document) => document._id === documentId
    )[0];
    const data = event.editor.getData();

    const newDocument = {
      ...document,
      data,
    };

    const filterDocuments = content.documents.filter(
      (document) => document._id !== documentId
    );

    let documents = [...filterDocuments, newDocument];
    documents = _.orderBy(documents, ["_id"], ["asc"]);

    const id = "qualityInformation";
    const name = "documents";

    updateContentData(documents, id, name);
  };

  const deleteProductHandler = (documentId) => {
    const documents = content.documents.filter(
      (document) => document._id !== documentId
    );
    const id = "qualityInformation";
    const name = "documents";

    updateContentData(documents, id, name);
  };

  const uploadFile = (fileDetails, documentId) => {
    const id = "qualityInformation";
    const name = "documents";
    uploadEditableFile(fileDetails, id, name, documentId, content.documents);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <>
          {operation.remove && (
            <div id="hoverShow1">
              <ul className="hoversetting">
                <li>
                  <span className="hoverbuttons" onClick={deleteHandler}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </span>
                </li>
              </ul>
            </div>
          )}
          <div className="container">
            <div className="row">
              <h3
                className="text-center mb-2"
                style={{ width: "100%", marginTop: "30px" }}
              >
                <TekCKEditor data={content.title} onChange={titleHandler} />
              </h3>

              {content.documents.map((document) => {
                return (
                  <div key={document._id} className="col-lg-4 col-sm-12">
                    <div className="hoverWrapper qisection">
                      <div id="hoverShow2">
                        <ul className="hoversetting">
                          <li>
                            <span
                              className="hoverbuttons"
                              onClick={() => deleteProductHandler(document._id)}
                            >
                              <i className="fa fa-trash" aria-hidden="true"></i>
                            </span>
                          </li>
                        </ul>
                      </div>
                      <FileUpload
                        id={document._id}
                        src={document.image.src}
                        altText={document.image.altText}
                        width={document.image.width}
                        height={document.image.height}
                        uploadFile={uploadFile}
                      />
                      <TekCKEditor
                        config={{
                          bodyId: document._id,
                        }}
                        data={document.data}
                        onChange={documentHandler}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      );
    }

    return (
      <div className="container">
        <div className="row">
          <h3
            className="text-center mb-2"
            style={{ width: "100%", marginTop: "30px" }}
          >
            <EditorPreview data={content.title} />
          </h3>

          {content.documents.map((document) => {
            return (
              <div key={document._id} className="col-lg-4 col-sm-12">
                <FileUpload
                  src={document.image.src}
                  altText={document.image.altText}
                  width={document.image.width}
                  height={document.image.height}
                />
                <EditorPreview data={document.data} />
              </div>
            );
          })}
        </div>
      </div>
    );
  };
  return (
    <div
      className="hoverWrapper mb-2"
      style={{ backgroundColor: "#d1ebeb", padding: "30px" }}
    >
      {renderView()}
    </div>
  );
};

export default QualityInformation;
