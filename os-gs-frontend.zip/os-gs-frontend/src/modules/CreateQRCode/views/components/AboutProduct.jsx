import React from "react";
import { Button, Tooltip, OverlayTrigger } from "react-bootstrap";

import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import KnowMore from "./KnowMore";

const AboutProduct = ({
  mode,
  aboutProduct,
  updateContentData,
  deleteElement,
}) => {
  const deleteHandler = () => {
    deleteElement("aboutProduct");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "aboutProduct";
    const name = "title";

    updateContentData(data, id, name);
  };

  const summaryHandler = (event) => {
    const data = event.editor.getData();
    const id = "aboutProduct";
    const name = "summary";

    updateContentData(data, id, name);
  };

  const descriptionHandler = (event) => {
    const data = event.editor.getData();
    const id = "aboutProduct";
    const name = "description";

    updateContentData(data, id, name);
  };

  const knowMoreHandler = (url) => {
    const id = "aboutProduct";
    const name = "knowMoreUrl";

    updateContentData(url, id, name);
  };

  const renderView = () => {
    const { operation, content } = aboutProduct;
    const tooltip = <Tooltip id="tooltip">Delete</Tooltip>;
    if (mode === "edit") {
      return (
        <>
          <TekCKEditor data={content.title} onChange={titleHandler} />
          <TekCKEditor data={content.summary} onChange={summaryHandler} />
          <TekCKEditor
            data={content.description}
            onChange={descriptionHandler}
          />

          <KnowMore
            mode="edit"
            url={content.knowMoreUrl}
            saveUrl={knowMoreHandler}
          />

          {operation.remove && (
            <div id="hoverShow2">
              <ul className="hoversetting">
                <li>
                  <OverlayTrigger placement="top" overlay={tooltip}>
                    <span className="hoverbuttons" onClick={deleteHandler}>
                      <i className="fa fa-trash" aria-hidden="true"></i>
                    </span>
                  </OverlayTrigger>
                </li>
              </ul>
            </div>
          )}
        </>
      );
    }

    return (
      <>
        <EditorPreview data={content.title} />
        <EditorPreview data={content.summary} />
        <EditorPreview data={content.description} />
        <KnowMore onClick={() => window.open(content.knowMoreUrl, "_blank")} />
      </>
    );
  };

  return (
    <div className="row">
      <div className="hoverWrapper">
        <div className="col">
          <div className="textboxaboutproduct">{renderView()}</div>
        </div>
      </div>
    </div>
  );
};

export default AboutProduct;
