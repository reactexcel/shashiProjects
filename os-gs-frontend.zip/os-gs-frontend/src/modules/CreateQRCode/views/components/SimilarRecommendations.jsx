import React, { useState } from "react";
import SettingsModal from "./SettingsModal";
import _ from "lodash";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import KnowMore from "./KnowMore";
import FileUpload from "./FileUpload";

const Product = (props) => {
  if (props.numberOfColumn === "col") {
    return (
      <div className="row">
        <div className="col-lg-4">
          <div className="recommendationssection mb-3">{props.image}</div>
        </div>
        <div className="col-lg-8">
          <div className="pt-5">{props.details}</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="recommendationssection mb-3">
        {props.image}
        {props.details}
      </div>
    </div>
  );
};

const SimilarRecommendations = ({
  mode,
  similarRecommendations,
  updateContentData,
  uploadEditableFile,
  deleteElement,
}) => {
  const { operation, content } = similarRecommendations;
  const [showSettingsModal, setSettingsModal] = useState(false);
  const [numberOfColumn, setNumberOfColumn] = useState("col-lg-4 col-xs-12");
  const closeModal = () => setSettingsModal(false);

  const deleteHandler = () => {
    deleteElement("similarRecommendations");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "similarRecommendations";
    const name = "title";

    updateContentData(data, id, name);
  };

  const productHandler = (event, key) => {
    const productId = event.editor.config.bodyId;
    const product = content.products.filter(
      (product) => product._id === productId
    )[0];
    const changedData = event.editor.getData();

    const newProduct = {
      ...product,
      data: {
        ...product.data,
        [key]: changedData,
      },
    };

    const filterProducts = content.products.filter(
      (product) => product._id !== productId
    );

    let products = [...filterProducts, newProduct];
    products = _.orderBy(products, ["_id"], ["asc"]);

    const id = "similarRecommendations";
    const name = "products";

    updateContentData(products, id, name);
  };

  const knowMoreHandler = (url) => {
    const id = "similarRecommendations";
    const name = "knowMoreUrl";

    updateContentData(url, id, name);
  };

  const deleteProductHandler = (productId) => {
    const products = content.products.filter(
      (product) => product._id !== productId
    );
    const id = "similarRecommendations";
    const name = "products";

    updateContentData(products, id, name);
  };

  const uploadFile = (fileDetails, productId) => {
    const id = "similarRecommendations";
    const name = "products";
    uploadEditableFile(fileDetails, id, name, productId, content.products);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <>
          {operation.remove && (
            <div id="hoverShow1">
              <ul className="hoversetting">
                <li>
                  <span className="hoverbuttons" onClick={deleteHandler}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </span>
                </li>
                <li>
                  <span
                    className="hoverbuttons"
                    onClick={() => setSettingsModal(true)}
                  >
                    Setting
                  </span>
                </li>
              </ul>
            </div>
          )}

          <div
            className="pb-2"
            style={{ background: "#ffffff", paddingTop: "40px" }}
          >
            <div className="container">
              <h3 className="text-center mb-4" style={{ width: "100%" }}>
                <div id="introduction12">
                  <TekCKEditor data={content.title} onChange={titleHandler} />
                </div>
              </h3>

              <div>
                <div className="row">
                  {content.products.map((product) => {
                    return (
                      <div key={product._id} className={numberOfColumn}>
                        <div className="hoverWrapper">
                          <div id="hoverShow2">
                            <ul className="hoversetting">
                              <li>
                                <span
                                  className="hoverbuttons"
                                  onClick={() =>
                                    deleteProductHandler(product._id)
                                  }
                                >
                                  <i className="fa fa-trash" aria-hidden="true"></i>
                                </span>
                              </li>
                            </ul>
                          </div>

                          <Product
                            numberOfColumn={numberOfColumn}
                            image={
                              <FileUpload
                                id={product._id}
                                src={product.data.image.src}
                                altText={product.data.image.altText}
                                width={product.data.image.width}
                                height={product.data.image.height}
                                uploadFile={uploadFile}
                              />
                            }
                            details={
                              <>
                                <TekCKEditor
                                  config={{
                                    bodyId: product._id,
                                  }}
                                  data={product.data.summary}
                                  onChange={(event) =>
                                    productHandler(event, "summary")
                                  }
                                />
                                <TekCKEditor
                                  config={{
                                    bodyId: product._id,
                                  }}
                                  data={product.data.description}
                                  onChange={(event) =>
                                    productHandler(event, "description")
                                  }
                                />
                              </>
                            }
                          ></Product>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <h3
                className="text-center mb-4"
                style={{
                  width: "100%",
                  borderBottom: "solid 1px #ccc",
                  marginBottom: ".5rem",
                }}
              >
                <KnowMore
                  mode="edit"
                  url={content.knowMoreUrl}
                  saveUrl={knowMoreHandler}
                />
              </h3>
            </div>
          </div>
        </>
      );
    }

    return (
      <div
        className="pb-2"
        style={{ background: "#ffffff", paddingTop: "40px" }}
      >
        <div className="container">
          <h3 className="text-center mb-4" style={{ width: "100%" }}>
            <div id="introduction12">
              <EditorPreview data={content.title} />
            </div>
          </h3>

          <div>
            <div className="row">
              {content.products.map((product) => {
                return (
                  <div className="col-lg-4 col-xs-12">
                    <div className="hoverWrapper">
                      <div id="introduction19">
                        <div className="recommendationssection mb-3">
                          <FileUpload
                            src={product.data.image.src}
                            altText={product.data.image.altText}
                            width={product.data.image.width}
                            height={product.data.image.height}
                          />
                        </div>
                        <EditorPreview data={product.data.summary} />
                        <EditorPreview data={product.data.description} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          <h3 className="text-center mb-4">
            <KnowMore
              mode="readOnly"
              onClick={() => window.open(content.knowMoreUrl, "_blank")}
            />
          </h3>
        </div>
      </div>
    );
  };

  return (
    <React.Fragment>
      <div className="hoverWrapper">{renderView()}</div>
      {showSettingsModal && (
        <SettingsModal
          setNumberOfColumn={setNumberOfColumn}
          closeModal={closeModal}
        />
      )}
    </React.Fragment>
  );
};

export default SimilarRecommendations;
