import React from "react";

import _ from "lodash";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import KnowMore from "./KnowMore";
import FileUpload from "./FileUpload";

const Blog = ({
  mode,
  blog,
  updateContentData,
  uploadEditableFile,
  deleteElement,
}) => {
  const { operation, content } = blog;

  const styleInfo = { width: "100%" };

  const deleteHandler = () => {
    deleteElement("blog");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "blog";
    const name = "title";

    updateContentData(data, id, name);
  };

  const blogHandler = (event, key) => {
    const blogId = event.editor.config.bodyId;
    const blog = content.blogs.filter((blog) => blog._id === blogId)[0];
    const changedData = event.editor.getData();

    const newBlog = {
      ...blog,
      data: {
        ...blog.data,
        [key]: changedData,
      },
    };

    const filterBlogs = content.blogs.filter((blog) => blog._id !== blogId);

    let blogs = [...filterBlogs, newBlog];
    blogs = _.orderBy(blogs, ["_id"], ["asc"]);

    const id = "blog";
    const name = "blogs";

    updateContentData(blogs, id, name);
  };

  const knowMoreHandler = (url) => {
    const id = "blog";
    const name = "knowMoreUrl";

    updateContentData(url, id, name);
  };

  const deleteProductHandler = (event, blogId) => {
    event.preventDefault();
    const blogs = content.blogs.filter((blog) => blog._id !== blogId);
    const id = "blog";
    const name = "blogs";

    updateContentData(blogs, id, name);
  };

  const uploadFile = (fileDetails, productId) => {
    const id = "blog";
    const name = "blogs";
    uploadEditableFile(fileDetails, id, name, productId, content.blogs);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <div className="hoverWrapper">
          {operation.remove && (
            <div id="hoverShow1">
              <ul className="hoversetting">
                <li>
                  <span className="hoverbuttons" onClick={deleteHandler}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </span>
                </li>
              </ul>
            </div>
          )}
          <div className="container">
            <div className="row">
              <h3
                className="text-center mb-4"
                style={{ width: "100%", marginTop: "30px" }}
              >
                <TekCKEditor data={content.title} onChange={titleHandler} />
              </h3>
              {content.blogs.map((blog) => {
                return (
                  <div key={blog._id} className="col-lg-4 col-xs-12">
                    <div className="hoverWrapper">
                      {operation.remove && (
                        <div id="hoverShow2">
                          <ul className="hoversetting">
                            <li>
                              <span
                                className="hoverbuttons"
                                onClick={(event) =>
                                  deleteProductHandler(event, blog._id)
                                }
                              >
                                <i className="fa fa-trash" aria-hidden="true"></i>
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}
                      <div id="introduction15">
                        <FileUpload
                          id={blog._id}
                          src={blog.data.image.src}
                          altText={blog.data.image.altText}
                          width={blog.data.image.width}
                          height={blog.data.image.height}
                          uploadFile={uploadFile}
                        />
                        <TekCKEditor
                          config={{
                            bodyId: blog._id,
                          }}
                          data={blog.data.title}
                          onChange={(event) => blogHandler(event, "title")}
                        />
                        <TekCKEditor
                          config={{
                            bodyId: blog._id,
                          }}
                          data={blog.data.description}
                          onChange={(event) =>
                            blogHandler(event, "description")
                          }
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <h3
              className="text-center"
              style={{
                width: "100%",
                borderBottom: "solid 1px #ccc",
                marginBottom: ".5rem",
              }}
            >
              <span>
                <KnowMore
                  mode="edit"
                  title="Read More"
                  url={content.knowMoreUrl}
                  saveUrl={knowMoreHandler}
                />
              </span>
            </h3>
          </div>
        </div>
      );
    }

    return (
      <div className="hoverWrapper">
        <div className="container">
          <div className="row">
            <h3
              className="text-center mb-4"
              style={{ width: "100%", marginTop: "30px" }}
            >
              <EditorPreview data={content.title} />
            </h3>
            {content.blogs.map((blog) => {
              return (
                <div className="col-lg-4 col-xs-12">
                  <div className="hoverWrapper">
                    <div id="introduction15">
                      <FileUpload
                        src={blog.data.image.src}
                        altText={blog.data.image.altText}
                        width={blog.data.image.width}
                        height={blog.data.image.height}
                      />
                      <EditorPreview data={blog.data.title} />
                      <EditorPreview data={blog.data.description} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <h3
            className="text-center"
            style={{
              width: "100%",
              borderBottom: "solid 1px #ccc",
              marginBottom: ".5rem",
            }}
          >
            <span>
              <KnowMore
                mode="readOnly"
                title="Read More"
                onClick={() => window.open(content.knowMoreUrl, "_blank")}
              />
            </span>
          </h3>
        </div>
      </div>
    );
  };

  return <div style={{ background: "#ffffff" }}>{renderView()}</div>;
};

export default Blog;
