import React from "react";

import _ from "lodash";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";
import FileUpload from "./FileUpload";

const ProductVitals = ({
  mode,
  productVitals,
  updateContentData,
  uploadEditableFile,
  deleteElement,
}) => {
  const { operation, content } = productVitals;

  const deleteHandler = () => {
    deleteElement("productVitals");
  };

  const titleHandler = (event) => {
    const data = event.editor.getData();
    const id = "productVitals";
    const name = "title";

    updateContentData(data, id, name);
  };

  const productInfoHandler = (event) => {
    const productId = event.editor.config.bodyId;
    const productInfo = content.productsInfo.filter(
      (productInfo) => productInfo._id === productId
    )[0];
    const data = event.editor.getData();

    const newProductInfo = {
      ...productInfo,
      data,
    };

    const filterProductsInfo = content.productsInfo.filter(
      (productInfo) => productInfo._id !== productId
    );

    let productsInfo = [...filterProductsInfo, newProductInfo];
    productsInfo = _.orderBy(productsInfo, ["_id"], ["asc"]);

    const id = "productVitals";
    const name = "productsInfo";

    updateContentData(productsInfo, id, name);
  };

  const deleteProductHandler = (productId) => {
    const products = content.productsInfo.filter(
      (productInfo) => productInfo._id !== productId
    );
    const id = "productVitals";
    const name = "productsInfo";

    updateContentData(products, id, name);
  };

  const uploadFile = (fileDetails, productId) => {
    const id = "productVitals";
    const name = "productsInfo";
    uploadEditableFile(fileDetails, id, name, productId, content.productsInfo);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <>
          {operation.remove && (
            <div id="hoverShow1">
              <ul className="hoversetting">
                <li>
                  <span className="hoverbuttons" onClick={deleteHandler}>
                    <i className="fa fa-trash" aria-hidden="true"></i>
                  </span>
                </li>
              </ul>
            </div>
          )}
          <div className="container">
            <div className="row mb-5">
              <h3
                className="text-center mb-4"
                style={{ width: "100%", marginTop: "30px" }}
              >
                <TekCKEditor data={content.title} onChange={titleHandler} />
              </h3>
              {content.productsInfo.map((productInfo) => {
                return (
                  <div key={productInfo._id} className="col-lg-3 col-xs-6">
                    <div className="hoverWrapper">
                      {operation.remove && (
                        <div id="hoverShow2">
                          <ul className="hoversetting">
                            <li>
                              <span
                                className="hoverbuttons"
                                onClick={() =>
                                  deleteProductHandler(productInfo._id)
                                }
                              >
                                <i className="fa fa-trash" aria-hidden="true"></i>
                              </span>
                            </li>
                          </ul>
                        </div>
                      )}

                      <div className="pv1">
                        <div id="introduction7">
                          <FileUpload
                            id={productInfo._id}
                            src={productInfo.image.src}
                            altText={productInfo.image.altText}
                            width={productInfo.image.width}
                            height={productInfo.image.height}
                            uploadFile={uploadFile}
                          />
                          <TekCKEditor
                            config={{
                              bodyId: productInfo._id,
                            }}
                            data={productInfo.data}
                            onChange={productInfoHandler}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      );
    }

    return (
      <div className="container">
        <div className="row mb-5">
          <h3
            className="text-center mb-4"
            style={{ width: "100%", marginTop: "30px" }}
          >
            <EditorPreview data={content.title} />
          </h3>
          {content.productsInfo.map((productInfo) => {
            return (
              <div key={productInfo._id} className="col-lg-3 col-xs-6">
                <div className="hoverWrapper">
                  <div className="pv1">
                    <div id="introduction7">
                      <FileUpload
                        src={productInfo.image.src}
                        altText={productInfo.image.altText}
                        width={productInfo.image.width}
                        height={productInfo.image.height}
                      />
                      <EditorPreview data={productInfo.data} />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return <div className="hoverWrapper">{renderView()}</div>;
};

export default ProductVitals;
