import React, { useState } from "react";
import styled from "styled-components";

import { Navbar, Button, FormGroup, Checkbox } from "react-bootstrap";
import ImageUploader from "react-images-upload";

import TekModal from "./TekModal";

const Styles = styled.div`
  .navbar-default {
    background-color: #f8f9fa;
    border-bottom: none;
    position: relative;
  }

  .navbar .navbar-brand {
    margin: 0px;
  }

  .navbar-form {
    margin: 0px;
  }

  .navbar .btn {
    color: #28a745;
    border-color: #28a745;
  }

  .navbar .btn:hover {
    background-color: #28a745;
    color: #fff;
  }

  .container {
    padding-left: 0px;
    padding-right: 0px;
    margin-left: 0px;
    margin-right: 0px;
    width: 100%;
  }

  .fileContainer .errorsContainer {
    position: absolute;
    width: 300px;
    left: 20px;
  }

  .chooseFileButton {
    left: -8px;
    top: -31px;
    position: absolute;
  }

  button.chooseFileButton:before {
    content: "\f055";
    font-family: FontAwesome;
    font-size: 18px;
    position: absolute;
    top: 10px;
    left: 0;
    color: #28a745;
  }
`;
const NavBar = ({
  mode,
  header,
  uploadLogo,
  defaultDesignConsumerPageData,
  addConsumerPageElement,
  elements,
  openPreview,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [selectedElements, setSelectedElements] = useState([]);

  const closeModalHandler = () => {
    setShowModal(false);
  };

  const showModalHandler = () => {
    setShowModal(true);
  };

  const elementSelectHandler = (event) => {
    const id = event.target.id;
    let elements;
    if (event.target.checked) {
      elements = [...selectedElements, id];
    } else {
      elements = selectedElements.filter((element) => element !== id);
    }

    setSelectedElements([...new Set(elements)]);
  };

  const addElementHandler = () => {
    closeModalHandler();
    addConsumerPageElement(selectedElements);
  };

  const onDrop = (file) => {
    const fileObj = file[0];
    uploadLogo(fileObj);
  };

  const renderView = () => {
    if (mode === "edit") {
      const pageObj = elements;
      const list = Object.keys(pageObj).filter((key) => {
        return !pageObj[key];
      });

      return (
        <>
          <Navbar>
            <Navbar.Header>
              <Navbar.Brand>
                <img
                  src={header.logo.logoUrl}
                  style={{
                    marginTop: "-10px",
                    paddingTop: "0px",
                    paddingBottom: "0px",
                    width: "50px",
                    height: "50px",
                    borderRadius: "50%",
                    border: "1px solid #c3c3c3",
                    display: "inline-block",
                  }}
                  alt="Logo"
                />

                <div style={{ display: "inline-block" }}>
                  <ImageUploader
                    withIcon={false}
                    buttonText=""
                    onChange={onDrop}
                    imgExtension={[".jpg", ".gif", ".png", ".gif"]}
                    singleImage={true}
                  />
                </div>
              </Navbar.Brand>
            </Navbar.Header>

            <Navbar.Form pullRight>
              <Button onClick={showModalHandler} disabled={!list.length}>
                Add Element
              </Button>
              {openPreview()}
            </Navbar.Form>
          </Navbar>
          <TekModal
            title="Add Element"
            show={showModal}
            closeModal={closeModalHandler}
            addElement={addElementHandler}
          >
            <FormGroup>
              {list.map((element) => {
                return (
                  <div className="row">
                    <Checkbox
                      inline
                      id={element}
                      onChange={elementSelectHandler}
                    >
                      {defaultDesignConsumerPageData.elements[element].name}
                    </Checkbox>
                  </div>
                );
              })}
            </FormGroup>
          </TekModal>
        </>
      );
    }

    return (
      <Navbar>
        <Navbar.Header>
          <Navbar.Brand>
            <img
              src={header.logo.logoUrl}
              style={{
                marginTop: "-10px",
                paddingTop: "0px",
                paddingBottom: "0px",
                width: "50px",
                height: "50px",
                borderRadius: "50%",
                border: "1px solid #c3c3c3",
                display: "inline-block",
              }}
              alt="Logo"
            />
          </Navbar.Brand>
        </Navbar.Header>
      </Navbar>
    );
  };

  return <Styles>{renderView()}</Styles>;
};

export default NavBar;
