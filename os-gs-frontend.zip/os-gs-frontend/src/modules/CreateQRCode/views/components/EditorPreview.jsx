import React from "react";

const EditorPreview = (props) => {
  return (
    <div className="editor-preview" style={{ padding: "15px" }}>
      <div dangerouslySetInnerHTML={{ __html: props.data }}></div>
    </div>
  );
};

export default EditorPreview;
