import React from "react";
import { Modal, Button } from "react-bootstrap";

const TekModal = ({ title, children, show, addElement, closeModal }) => {
  return (
    <Modal show={show} onHide={closeModal}>
      <Modal.Header closeButton>
        <Modal.Title>{title}</Modal.Title>
      </Modal.Header>
      <Modal.Body>{children}</Modal.Body>
      <Modal.Footer>
        <Button bsStyle="default" onClick={addElement}>
          Done
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default TekModal;
