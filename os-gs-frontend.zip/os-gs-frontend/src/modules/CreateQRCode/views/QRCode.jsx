import React, { Component } from "react";
import CreateQRCode from "./CreateQRCode";
import EditQRCodePage from "./EditQRCodePage";
import {
    createQRCodeFormFields,
    nameAndWebUrlFormFields,
    rangeComponent,
    colorFieldsDefaultValue,
} from "../constants/createQRCodeConstants";
import { connect } from "react-redux";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import mixpanel from "../../analytics/mixpanel/mixpael";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import { getQRCodes } from "../actions/qrcodeActions";

class QRCode extends Component {
    getDefaultValuesObject(...allLists) {
        var list = Array.prototype.concat.apply([], allLists);
        let object = {};
        list.map(({ name, defaultValue }) => {
            if (name == "uti") {
                object = { ...object, [name]: this.props.selectedUTICode };
            } else {
                object = { ...object, [name]: defaultValue };
            }
            return object;
        });
        return object;
    }

    componentDidMount() {
        mixpanel.track("Create Qr code loaded");
        if (CommonUtil.isNotNull(this.props.actionMode)) {
            if (!CommonUtil.isCreateMode(this.props.actionMode)) {
                this.props.getQRCodes(this.props.selectedUTICode);
            }
        } else {
            this.props.history.push("manage-qrcode");
        }
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
            this.handleAjaxResponse();
        }
    }

    handlePopupContinue = () => {
        this.props.history.push("manage-qrcode");
    }

    handleAjaxResponse() {
        if (this.props.ajaxCallStatus.status == "SUCCESS") {
            this.props.setAjaxCallStatus(null);
            if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
                this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
                    CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
            } else {
                this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
            }
            setTimeout(this.handlePopupContinue, 0);
        }

        if (this.props.ajaxCallStatus.status == "FAILED") {
            PopupUtil.handleCustomErroMsg(this);
            this.props.setAjaxCallStatus(null);
        }
    }

    render() {
        const createQRCodeFields = this.getDefaultValuesObject(
            createQRCodeFormFields,
            nameAndWebUrlFormFields,
            rangeComponent,
            colorFieldsDefaultValue
        );

        return (
            CommonUtil.isCreateMode(this.props.actionMode) ?
                <CreateQRCode
                    createQRCodeFormFields={createQRCodeFormFields}
                    initialValues={createQRCodeFields}
                    pageHeading="Create QR Code"
                    mode="add"
                />
                :
                <EditQRCodePage
                    mode="edit" />

        );
    }
}


function mapStateToProps(state, ownProps) {
    return {
        selectedUTICode: state.qrcode.selectedUTICode,
        actionMode: state.app.actionMode,
        ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
        attributeObj: state.qrcode.qrCodeDetails,
    };
}

const mapDispatchToProps = dispatch => ({
    setAjaxCallStatus: init => dispatch(setAjaxCallStatus(init)),
    getQRCodes: utiCode => dispatch(getQRCodes(utiCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(QRCode);

