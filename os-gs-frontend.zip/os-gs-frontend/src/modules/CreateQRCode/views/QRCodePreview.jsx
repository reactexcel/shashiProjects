import React from "react";
import QRCodeStyling from "qr-code-styling";
import Card from "../../../components/Card/Card.jsx";
import Button from "components/CustomButton/CustomButton.jsx";
import { QRCode } from "react-qr-svg";

class QRCodePreview extends React.Component {
  constructor(props) {
    super(props);
    this.canvas = React.createRef();
    this.downloadCanvas = React.createRef();
    this.download = this.download.bind(this);
    this.generateQrCode = this.generateQrCode.bind(this);
    this.previewQRCode = this.previewQRCode.bind(this);
    var qrCode;
    var downloadQRCode;
  }

  download() {
    if (this.props.format === "svg") {
      const svg = document.getElementById("qrId");
      const serializer = new XMLSerializer();
      const svgStr = serializer.serializeToString(svg);

      const url = "data:image/svg+xml;base64," + window.btoa(svgStr);

      let downloadLink = document.createElement("a");
      downloadLink.href = url;
      downloadLink.download = "qrCode.svg";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    } else {
      this.generateQrCode(this.props);
      this.downloadQRCode.download(this.props.format);
    }
  }

  componentWillReceiveProps(nextProps) {
    const qrCodePreviewProperties = { ...nextProps, size: 150 };
    this.previewQRCode(qrCodePreviewProperties);
  }

  previewQRCode({ size, color, backGroundcolor, qrType, webUrl }) {
    this.qrCode = new QRCodeStyling({
      width: size,
      height: size,
      data: webUrl,
      //image: logo,
      dotsOptions: {
        color: color,
        type: qrType,
      },
      backgroundOptions: {
        color: backGroundcolor,
      },
      margin: "50",
    });
    const DOMNode = this.canvas.current;
    DOMNode.innerHTML = "";
    this.qrCode.append(this.canvas.current);
  }

  generateQrCode({ size, color, backGroundcolor, qrType, webUrl }) {
    this.downloadQRCode = new QRCodeStyling({
      width: size * 31.5,
      height: size * 31.5,
      data: webUrl,
      //image: logo,
      dotsOptions: {
        color: color,
        type: qrType,
      },
      backgroundOptions: {
        color: backGroundcolor,
      },
      margin: "50",
    });
    const DOMNode = this.downloadCanvas.current;
    DOMNode.innerHTML = "";
    this.downloadQRCode.append(this.downloadCanvas.current);
  }

  render() {
    const { size, backGroundcolor, color, webUrl } = this.props;
    return (
      <div className="qr-code-preview">
        <Card
          title="Preview"
          content={
            <React.Fragment>
              <div ref={this.downloadCanvas} hidden />
              <div ref={this.canvas} />
              <div hidden>
                <QRCode
                  id="qrId"
                  bgColor={backGroundcolor}
                  fgColor={color}
                  level="Q"
                  style={{
                    width: size * 31.5,
                    height: size * 31.5,
                  }}
                  value={webUrl}
                />
              </div>
            </React.Fragment>
          }
          textCenter
          ftTextCenter
          ctTextCenter
          legend={`Size (cm) ${size} * ${size}`}
        />
      </div>
    );
  }
}

export default QRCodePreview;
