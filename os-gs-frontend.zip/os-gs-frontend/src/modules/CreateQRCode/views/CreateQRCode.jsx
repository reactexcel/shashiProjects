import React from "react";
import { reduxForm, formValueSelector } from "redux-form";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import map from "lodash/map";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { FormFieldsGenerator } from "../../../components/forms/FormFieldsGenerator";
import TabsSection from "./TabsSection";
import { createQRCode, editQrCode } from "../actions/qrcodeActions";
import { validateQrCode } from "../validation/qrcodevalidations";
import { Component } from "react";
import popupUtil from "../../common/util/popupUtil";
import commonUtil from "../../common/util/commonUtil";
import scan from "assets/img/scan-page-icon.svg";

import {
  // getConsumerPageData,
  uploadLogo,
  updateCarouselImages,
  deleteElement,
  updateContentData,
  saveConsumerPageData,
  updateConsumerPageData,
  addConsumerPageData,
  updateElementsOrder,
  uploadCarouselImages,
  uploadEditableFile,
} from "../actions/designConsumerPageActions";

class CreateQRCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showConfirmModal: false,
      tabKey: 1,
      isSavedConsumerPage: false,
    };
  }

  changeTabHandler = (tabKey) => {
    this.setState({ tabKey });
  };

  onSubmit = (formValues) => {
    if (this.props.mode === "add") {
      if (this.state.tabKey === 1) {
        this.props.createQRCode(formValues);
      } else {
        this.props.saveConsumerPageData(
          this.props.designConsumerPageData,
          formValues.uti
        );
        this.setState({ isSavedConsumerPage: true });
      }
    } else if (this.props.mode === "edit") {
      if (this.state.tabKey === 1) {
        this.props.editQrCode(formValues);
      } else {
        this.props.updateConsumerPageData(
          this.props.designConsumerPageData,
          formValues.uti
        );
      }
    }
  };

  componentDidMount() {
  }

  setConfirmModal = (value) => {
    this.setState({ showConfirmModal: value });
  };

  openConfirmModal = () => {
    var popupActionButton = {};
    popupActionButton.onConfirmClick = this.navigateToManageQRCode;
    popupActionButton.onCancelClick = this.handelpopupCancel;
    var popupConfig = commonUtil.prepareCancelPopUpConfig(popupActionButton);
    this.setState({ alert: popupUtil.confirmationPopup(popupConfig) });
  };

  handelpopupCancel = () => {
    this.setState({ alert: null });
  };

  closeConfirmModal = () => {
    this.setConfirmModal(false);
  };

  navigateToManageQRCode = () => {
    this.props.history.push("manage-qrcode");
    this.setConfirmModal(false);
  };

  getProductAndBatchFields = (createQRCodeFormFields) => {
    const modifiedFormFields = map(createQRCodeFormFields, (formField) => {
      return formField;
    });
    if (this.props.mode === "add") {
      return modifiedFormFields;
    } else if (this.props.mode === "edit") {
      return map(modifiedFormFields, (formField) => {
        return { ...formField, disabled: true };
      });
    }
  };

  render() {
    const {
      handleSubmit,
      pristine,
      submitting,
      change,
      createQRCodeFormFields,
      designConsumerPageData,
      defaultDesignConsumerPageData,
      // getConsumerPageData,
      uploadLogo,
      updateCarouselImages,
      deleteElement,
      updateContentData,
      addConsumerPageData,
      updateElementsOrder,
      uploadCarouselImages,
      uploadEditableFile,
    } = this.props;

    return (
      <div className="main-content create-page">
        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
               <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={scan} alt="" className="page-icon" />
                  QR Code
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="page-control-buttons">
                    <Button
                      className="btn-cancel"
                      type="reset"
                      onClick={this.openConfirmModal}
                      disabled={pristine || submitting}
                    >
                      Cancel
                        </Button>
                    <Button
                      className="btn-save btn-fill"
                      type="submit"
                      disabled={pristine || submitting}
                    >
                      {/*{this.state.tabKey === 1 ? "Next" : "Save"}*/}
                      Save
                    </Button>
                  </div>
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form
                className="ui form error"
                onSubmit={handleSubmit(this.onSubmit)}
              >
                <Card
                  content={
                    <div>
                      <Row>
                        <FormFieldsGenerator
                          list={this.getProductAndBatchFields(
                            createQRCodeFormFields
                          )}
                        />
                      </Row>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form
                className="ui form error"
                onSubmit={handleSubmit(this.onSubmit)}
              >
                <Card
                  content={
                    <div>
                      <Row>
                        <TabsSection
                          designConsumerPageData={designConsumerPageData}
                          defaultDesignConsumerPageData={
                            defaultDesignConsumerPageData
                          }
                          //getConsumerPageData={getConsumerPageData}
                          uploadLogo={uploadLogo}
                          updateCarouselImages={updateCarouselImages}
                          deleteElement={deleteElement}
                          updateContentData={updateContentData}
                          addConsumerPageData={addConsumerPageData}
                          tabKey={this.state.tabKey}
                          changeTabHandler={this.changeTabHandler}
                          updateElementsOrder={updateElementsOrder}
                          uploadCarouselImages={uploadCarouselImages}
                          qrCodeMode={this.props.mode}
                          uti={this.props.initialValues.uti}
                          uploadEditableFile={this.props.uploadEditableFile}
                          // isSavedConsumerPage={this.props.isSavedConsumerPage}
                          change={change}
                        />
                      </Row>
                    </div>
                  }
                  ftTextRight
                  legend={
                    <div>
                      <Button
                        className="btn-cancel"
                        type="reset"
                        onClick={this.openConfirmModal}
                        disabled={pristine || submitting}
                      >
                        Cancel
                      </Button>
                      <Button
                        className="btn-save btn-fill"
                        type="submit"
                        disabled={pristine || submitting}
                      >
                        {/*{this.state.tabKey === 1 ? "Next" : "Save"}*/}
                        Save
                      </Button>
                    </div>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
        {this.state.alert}
      </div>
    );
  }
}
const valueSelector = formValueSelector("createQrCodeForm");

const mapStateToProps = (state, props) => {
  return {
    products: state.qrcode.products,
    // batches: state.qrcode.batches,
    //productId: valueSelector(state, "productId"),
    //designConsumerPageData: state.designConsumerPage.data,
    // defaultDesignConsumerPageData: state.designConsumerPage.defaultData,
  };
};

export default connect(mapStateToProps, {
  createQRCode,
  editQrCode,
  //getConsumerPageData,
  uploadLogo,
  updateCarouselImages,
  deleteElement,
  updateContentData,
  saveConsumerPageData,
  updateConsumerPageData,
  addConsumerPageData,
  updateElementsOrder,
  uploadCarouselImages,
  uploadEditableFile,
})(
  reduxForm({
    form: "createQrCodeForm",
    enableReinitialize: true,
    validate: validateQrCode,
  })(withRouter(CreateQRCode))
);
