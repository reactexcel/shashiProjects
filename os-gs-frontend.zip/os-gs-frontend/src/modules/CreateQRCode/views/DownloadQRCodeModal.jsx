import React from "react";
import { reduxForm, Field, formValueSelector } from "redux-form";
import { connect } from "react-redux";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import {
  GroupButton,
  Range,
} from "../../../components/forms/common/FormFields";
import PopupModal from "../../../components/modal/PopupModal";
import QRCodeDownload from "./QRCodeDownload";

class DownloadQRCodeModal extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      format: "",
      formValues: null,
    };
  }
  onSubmit = (formValues) => {
    console.log(formValues);
    this.setState({ formValues: formValues });
  };

  handleFormatChange = (format) => {
    this.setState({ format });
  };

  componentWillReceiveProps({ format }) {
    this.setState({ format });
  }

  handleDownLoadButton = () => {};

  render() {
    const { closeForm, formHeading, handleSubmit } = this.props;
    const { format, formValues } = this.state;
    return (
      <PopupModal closeForm={closeForm} formHeading={formHeading}>
        <div className="main-content">
          <Grid fluid>
            <Row>
              <Col md={12}>
                <form
                  className="ui form error"
                  onSubmit={handleSubmit(this.onSubmit)}
                >
                  <Card
                    content={
                      <div>
                        <Row>
                          <Col md={12}>Choose Image Format</Col>
                        </Row>
                        <Row className="fields-section">
                          <Col md={12}>
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "png", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="PNG"
                            />
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "jpg", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="JPG"
                            />
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "svg", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="SVG"
                            />
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "pdf", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="PDF"
                            />
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "eps", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="EPS"
                            />
                            <Field
                              name="format"
                              disabled={false}
                              component={GroupButton}
                              props={{ value: "ps", currentValue: format }}
                              onClick={this.handleFormatChange}
                              label="PS"
                            />
                          </Col>
                        </Row>
                        <Row style={{ marginTop: "20px" }}>
                          <Col md={12}>
                            <p>Size (cm)</p>
                          </Col>
                        </Row>
                        <Row>
                          <Col md={12}>
                            <Field
                              name="size"
                              disabled={false}
                              component={Range}
                              props={{ min: 5, max: 15 }}
                            />
                          </Col>
                        </Row>
                        <Row style={{ marginTop: "40px" }}>
                          <Col md={12}>
                            <p>
                              Tip: Always Scan the Code before printing to
                              confirm output
                            </p>
                          </Col>
                        </Row>
                      </div>
                    }
                    ftTextCenter
                    legend={
                      <QRCodeDownload {...this.props} closeForm={closeForm} />
                    }
                  />
                </form>
              </Col>
            </Row>
          </Grid>
        </div>
      </PopupModal>
    );
  }
}

const valueSelector = formValueSelector("downloadQRCode");

const mapStateToProps = (state) => ({
  size: valueSelector(state, "size"),
  format: valueSelector(state, "format"),
  color: valueSelector(state, "color"),
  backGroundcolor: valueSelector(state, "backGroundcolor"),
  qrType: valueSelector(state, "qrType"),
  webUrl: valueSelector(state, "webUrl"),
});

export default connect(
  mapStateToProps,
  {}
)(
  reduxForm({
    form: "downloadQRCode",
    enableReinitialize: true,
  })(DownloadQRCodeModal)
);
