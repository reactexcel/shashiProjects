import isAuthorized from "auth-plugin";

export const MANAGE_AUDIT_HEADER_TITLE = "Activity Log";
export const CREATE_AUDIT_HEADER_TITLE = "Create Audit";

export const CREATE_REPORT = "createReport";
export const CREATE_AUDIT_PAGE_URL = "/admin/create-audit";
export const MANAGE_AUDIT_PAGE_URL = "/admin/manage-audit";
export const AUDIT_ERROR = "Please try after some time.";
export const VALID_DATE_ERROR = "To date can not be less than From date.";

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_AUDIT_DETAILS_URL = `${BASE_URL}/purchaseorders/downloadreportxls/`;
export const GET_AUDIT_LIST_URL = `${BASE_URL}/activities/'abc/'abc'`;
export const getModuleList = () => {
    const modules = [
        { label: "Sell", value: "SO" },
        { label: "Procure", value: "PO" },
        { label: "Stock Transfer", value: "STO" },
        { label: "Users", value: "USER" },
        { label: "Product", value: "PRODUCT" },
        { label: "Supplier", value: "SUPPLIER" },
        { label: "Customer", value: "CUSTOMER" },
        { label: "Facility", value: "FACILITY" },
        { label: "Finance", value: "FINANCE" },
        { label: "Stock Adjustment", value: "STA" },
        { label: "Settings", value: "SETTING" },
    ];

    if (isAuthorized("viewIngredient")) {
        modules.push({ label: "Ingredient", value: "INGREDIENT" });
    }

    if (isAuthorized("viewMakeOrder")) {
        modules.push({ label: "Make", value: "MAKE" });
    }
    
    return modules;
}
