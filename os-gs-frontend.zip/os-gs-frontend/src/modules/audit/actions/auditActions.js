import axios from "../../../axios/axios";
import * as auditActionTypes from "./auditActionTypes";
import * as auditConstant from "../constant/auditConstant";
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, failedApiResponse, updateApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: auditActionTypes.SET_AUDIT_REDUCER_INIT_MODE,
      payload: null,
    });
  };
}

export function getAuditDetails(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(auditConstant.GET_AUDIT_DETAILS_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch(setAjaxCallStatus(updateApiResponse(response)));
        dispatch(endAjaxCall());
      }
    }).catch(error => {
      dispatch(endAjaxCall());
      dispatch(setAjaxCallStatus(failedApiResponse(error)));
    });
  };
}

export function getAuditList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(auditConstant.GET_AUDIT_LIST_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: auditActionTypes.GET_AUDIT_LIST,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    }).catch((error) => {
      dispatch(endAjaxCall());
    });
  };
}
