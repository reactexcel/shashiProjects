import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as auditConstant from "../constant/auditConstant";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import * as commonConstant from '../../common/constant/commonConstant';
import { connect } from "react-redux";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { getAuditDetails, getAuditList } from "../actions/auditActions";
import TextBoxUtil from '../../common/util/textBoxUtil';
import { setActionMode } from "../../../actions/appActions";
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from "../../common/util/commonUtil";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { getUserList } from "../../userManagement/actions/userActions";
import LabelUtil from "modules/common/util/labelUtil";
import DateUtil from "../../common/util/dateUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import { getUserProfile } from "../../userManagement/actions/userActions";
import audit from "assets/img/audit-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import PopupUtil from '../../common/util/popupUtil';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { at } from "lodash";

class ManageAudit extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      alert: null,
      dateError: false,
      redirect: false,
      redirectUrl: null,
      submitted: false,
      currentPage: 1,
    };
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Audit Page loaded");
    this.props.getUserProfile();
    this.props.getUserList();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.setSelectedTabDetails()
  };

  setSelectedTabDetails = () => {
    const commonAttributeList = pagePropertyListConstant.CREATE_AUDIT_PAGE_LIST(this);
    let managePageList = pagePropertyListConstant.MANAGE_DOWNLOAD_AUDIT_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      lastEvaluatedKeyArray: [],
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    })
  }

  makeCustomAPICall(tempParamas) {
    this.props.getAuditList(tempParamas);
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  componentDidUpdate(prevProps) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (prevProps.auditList != this.props.auditList && this.props.auditList != null) {
      PaginationUtil.handlePagination(this.props.auditList, this);
    }
    if (this.props.userList != null && prevProps.userList != this.props.userList) {
      this.updateUserDropDownList();
    }
  }

  updateUserDropDownList = () => {
    this.setState({
      attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList,
        CommonUtil.getOptionsFromListWithAll([...this.props.userList],
          'email', 'firstName', null, true), 'user')
    })
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.setState({ submitted: false, alert: null });
      this.setSelectedTabDetails();
      this.props.handleClick(CommonUtil.prepareAuditGenerationPopUpConfig());
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      this.handleErrorPopup(auditConstant.AUDIT_ERROR);
    }
  }

  handleErrorPopup = function (message) {
    let popupActionButton = {};
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.prepareCustomErrorMsgPopUpConfig(popupActionButton, message);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
  }

  handleApiCall = async () => {
    this.setState({ submitted: true, alert: null });
    let managePageList = pagePropertyListConstant.MANAGE_DOWNLOAD_AUDIT_PAGE_LIST(this);
    let tempObj = ValidationUtil.removeAttributeFromRequestObj(this.state.attributeObj,
      this.state.attributeList, commonConstant.CREATE_ACTION_MODE);

    if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      tempObj.user = tempObj.user == 'all' ? '' : tempObj.user;
      let additionalParams = tempObj;
      if (new Date(tempObj.fromDate) > new Date(tempObj.toDate)) {
        await this.setState({ dateError: true, additionalParams: additionalParams });
      } else {
        await this.setState({ dateError: false, additionalParams: additionalParams });
        await this.makeCustomAPICall(PaginationUtil.getPaginationParams(
          1, managePageList.tableConfig.defaultPageSize, this))
      }
    }
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableDataList, tableConfig } = this.state;
    const actionMode = commonConstant.CREATE_ACTION_MODE;
    return (
      <div className="main-content create-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={audit} alt="" className="page-icon" />
                  {auditConstant.MANAGE_AUDIT_HEADER_TITLE}
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <>
                      <div>
                        <Row>
                          {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                            tempAttributeListObj.type == "FIXED" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              LabelUtil.fixedAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                              : tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true && tempAttributeListObj.showField == true ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                      : null))
                          }
                          {this.state.dateError &&
                            <Col md={12}>
                              <small className="text-danger">{auditConstant.VALID_DATE_ERROR}</small>
                            </Col>}
                        </Row>
                      </div>
                    </>
                  }
                  ftTextRight
                  legend={
                    <>
                      <div>
                        <Button className="btn-save btn-fill" onClick={this.handleApiCall}>Search</Button>
                        {/* <Button className="btn-save btn-fill" onClick={this.handleApiCall}>Export</Button> */}
                      </div>

                    </>
                  }
                />
              </form>
            </Col>
          </Row>
          {tableColumnList != null ?
            <Row>
              <Col md={12}>
                <form>

                  <Card
                    content={
                      <>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <div>
                            <Row>
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                            </Row>
                          </div>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                      </>
                    }
                  />

                </form>
              </Col>
            </Row>
            : null}
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    actionMode: state.app.actionMode,
    auditList: state.audit.auditList,
    userList: state.user.userList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getAuditDetails: (tempObj, label) => dispatch(getAuditDetails(tempObj, label)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getAuditList: (id) => dispatch(getAuditList(id)),
  getUserList: (id) => dispatch(getUserList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageAudit);
