import axios from '../../../axios/axios';
import * as barCodeActionTypes from './barCodeActionTypes';
import * as barCodeConstant from '../constants/barCodeConstant';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: barCodeActionTypes.SET_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setBarCodeDetails(barCodeDetailsObj, actionMode) {

  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(barCodeConstant.SET_CREATE_BARCODE_DETAILS_URL,
        barCodeDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(createApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }

  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(barCodeConstant.SET_UPDATE_BARCODE_DETAILS_URL +
        barCodeDetailsObj.barCode, barCodeDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedUTICode(selectedBarCode) {
  return function (dispatch) {
    dispatch({
      type: barCodeActionTypes.SET_SELECTED_UTI_CODE,
      payload: selectedBarCode
    });
  }
}

export function getTraceabilityList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios
      .get(barCodeConstant.GET_TRACEBILITY_LIST_URL, { params: params })
      .then((response) => {
        if (response.status == 200) {
          dispatch({
            type: barCodeActionTypes.GET_TRACEABILITY_LIST,
            payload: response.data,
          });
        }
        dispatch(endAjaxCall());
      })
      .catch((error) => {
        dispatch(endAjaxCall());
      });
  };
}

export function getBarCodeDetails(selectedBarCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(barCodeConstant.GET_BARCODE_DETAILS_URL +
      selectedBarCode).then(response => {
        if (response.status == 200) {
          dispatch({
            type: barCodeActionTypes.GET_BARCODE_DETAILS,
            payload: response.data.Item
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}

