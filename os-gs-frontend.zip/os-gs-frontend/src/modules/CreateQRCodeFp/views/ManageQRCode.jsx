import React, { Component } from "react";
import { Grid, Row, Col, FormControl, FormGroup, ControlLabel } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as qrCodeConstant from "../constants/qrCodeConstant";
import * as pagePropertyListConstant from "../constants/pagePropertyConstant";
import { connect } from "react-redux";
import {  getTraceabilityByLot } from "../../traceabilityManagement/actions/traceabilityActions";
import CommonUtil from "../../common/util/commonUtil";
import { getDataDictionaryDetails } from "../../dataDictionary/actions/dataDictionaryActions";
import { setActionMode } from "../../../actions/appActions";
import { setSelectedUTICode ,getTraceabilityList } from "../actions/barCodeActions";
import PaginationUtil from "../../common/util/paginationUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import check from "assets/img/check.svg";
import { getUserProfile } from "../../userManagement/actions/userActions";
import scan from "assets/img/scan-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';

class ManageQRCode extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedUTICode: '',
      alert: null,
      redirect: false,
      redirectUrl: null,
      status: null,
      attributeList: null,
      submitted: false,
      attributeObj: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.downloadBarCode = this.downloadBarCode.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Manage QRCode loaded");
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    const managePageList = pagePropertyListConstant.MANAGE_QRCODE_PAGE_LIST(this);
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
    });
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.traceabilityList != this.props.traceabilityList && this.props.traceabilityList != null) {
      PaginationUtil.handlePagination(this.props.traceabilityList, this);
    }
  }

  downloadBarCode({productId, utiNumber}) {
    const barcodeId = `generatedBarcode${productId}${utiNumber}`;
    this.download(barcodeId);
  }

  download = (barcodeId) => {
    const svg = document.getElementById(barcodeId);
      const serializer = new XMLSerializer();
      const svgStr = serializer.serializeToString(svg);

      const url = "data:image/svg+xml;base64," + window.btoa(svgStr);

      let downloadLink = document.createElement("a");
      downloadLink.href = url;
      downloadLink.download = "barcode.svg";
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
  }

  handleChange = async (event) => {
    await this.setState({ selectedUTICode: event.target.value });
    this.globalSearch();
  };

  getStockListByUTI = (event) => {
    if (CommonUtil.isNotNull(this.state.selectedUTICode)) {
      this.setState({ tableDataList: [] });
      this.props.getTraceabilityByLot(this.state.selectedUTICode);
    }
  };

  getStockListByUTIOnEnter = (event) => {
    if (CommonUtil.isNotNull(this.state.selectedUTICode) && event.charCode === 13) {
      this.setState({ tableDataList: [] });
      this.props.getTraceabilityByLot(this.state.selectedUTICode);
    }
  };

  getQRAndUTIStaus = (value) => {
    if (CommonUtil.isNotNull(value) && value === true) {
      return statusConstant.GENERATED_STATUS;
    } else {
      return statusConstant.PENDING_STATUS;
    }
  }

  globalSearch = () => {
    let { selectedUTICode } = this.state;
    let filteredData = this.props.traceabilityList.Items.filter((value) => {
      return (
        value.lotNumber.toLowerCase().includes(selectedUTICode.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  };

  handleMenuPopupAction = (event) => {
    const tempId = event.target.id.split("#");
    if (tempId[2] === "CREATEQRCODE") {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      this.props.setSelectedUTICode(tempId[0]);
      CommonUtil.handlePageRedirection(qrCodeConstant.CREATE_QRCODE_URL, this);
    } else if (tempId[2] === "CREATEBARCODE") {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      this.props.setSelectedUTICode(tempId[0]);
      CommonUtil.handlePageRedirection(qrCodeConstant.CREATE_BARCODE_URL, this);
    } else if (tempId[2] === "EDITQRCODE") {
      this.props.setActionMode(commonConstant.EDIT_ACTION_MODE);
      this.props.setSelectedUTICode(tempId[0]);
      CommonUtil.handlePageRedirection(qrCodeConstant.CREATE_QRCODE_URL, this);
    } else if (tempId[2] === "EDITBARCODE") {
      this.props.setActionMode(commonConstant.EDIT_ACTION_MODE);
      this.props.setSelectedUTICode(tempId[0]);
      CommonUtil.handlePageRedirection(qrCodeConstant.CREATE_BARCODE_URL, this);
    }
  };

  handlePopupCancel = () => {
    this.setState({ alert: null });
  };

  makeCustomAPICall(tempParamas) {
    this.props.getTraceabilityList(tempParamas);
  }

  getTdProps = (event, original) => {
    var tempId = event.target.id.split("#");
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event, original);
    }
  };

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.selectedUTICode)) {
      this.setState({ tableDataList: [] });
      this.props.getTraceabilityByLot(this.state.selectedUTICode);
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ? (
          <Redirect push to={this.state.redirectUrl}></Redirect>
        ) : null}
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={scan} alt="" className="page-icon" />
                  {qrCodeConstant.MANAGE_QR_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                {/*<div>
                  <div className="advance-search traceability-search">
                    <Row>
                      <Col className="no-gutters" md={12} sm={12}>
                        <ul role="tablist" class="nav nav-tabs rightflow">
                          <li>
                            <FormGroup className="search-haeding padtop">
                              <ControlLabel>Search by Lot Number</ControlLabel>
                            </FormGroup>
                          </li>
                          <li><FormControl
                            type="text"
                            name="selectedUTICode"
                            placeholder="Search by Lot Number"
                            value={this.state.selectedUTICode}
                            onChange={this.handleChange}
                            className="traceability-selection"
                            onKeyPress={this.getStockListByUTIOnEnter}
                          /></li>
                          <li><div className="submit-btn">
                            <img src={check} onClick={this.getStockListByUTI} alt="submit" />
                          </div></li>
                        </ul>
                      </Col>
                    </Row>
                  </div>
                </div>*/}
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl
                        type="text"
                        name="selectedUTICode"
                        placeholder="Search by Lot Number"
                        value={this.state.selectedUTICode}
                        onChange={this.handleChange}
                      />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.selectedUTICode) ? {cursor: 'default'} : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    <Row>
                      {tableColumnList != null && (tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ? (
                        <Table
                          columns={tableColumnList}
                          data={tableDataList}
                          config={tableConfig}
                          getRowProps={this.getTdProps}
                          that={this}
                        />
                      ) : (
                          <Col md={12}>
                            <div className="no-record">No Record Found</div>
                          </Col>
                        )}
                    </Row>
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    traceabilityList: state.traceability.traceabilityList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
    selectedUTI: state.incident.selectedUTI,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  setSelectedUTICode: (barCode) => dispatch(setSelectedUTICode(barCode)),
  getTraceabilityList: (id) => dispatch(getTraceabilityList(id)),
  getTraceabilityByLot: (id) => dispatch(getTraceabilityByLot(id)),
  getDataDictionaryDetails: (selectedDataDictionaryCode) => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageQRCode);
