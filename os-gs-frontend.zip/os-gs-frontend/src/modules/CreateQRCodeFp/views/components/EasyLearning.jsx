import React from "react";
import local_library from "../../CreateQRCode/assets/local_library-24px.png";

const EasyLearning = () => {
  return (
    <div className="row">
      <div className="col-lg-3 hide-xs"></div>
      <div className="col-lg-6 col-xs-12">
        <div className="hoverWrapper">
          <div id="hoverShow2">
            <ul className="hoversetting">
              <li>
                <button>Delete</button>
              </li>
              <li>
                <button>Setting</button>
              </li>
            </ul>
          </div>
          <div id="introduction3" style={{ padding: "15px" }}>
            <h3>
              <img
                src={local_library}
                alt="Simply Easy Learning"
                style={{ marginRight: "10px" }}
              />
              Quick Facts
            </h3>
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry.
            </p>
          </div>
        </div>
        <div className="col-lg-3 hide-xs"></div>
      </div>
    </div>
  );
};

export default EasyLearning;
