import React, { useState } from "react";
import styled from "styled-components";

import _ from "lodash";
import TekCKEditor from "./TekCKEditor";
import EditorPreview from "./EditorPreview";

import {
  InputGroup,
  FormGroup,
  FormControl,
  HelpBlock,
  Button,
} from "react-bootstrap";

import footerSub from "../../../CreateQRCode/assets/footer-sub.png";

const Styles = styled.div`
  .input-group input[type="text"],
  .input-group input[type="text"]:focus {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }

  .emailErrText {
    color: #ff0000;
  }
`;

const EMAIL_REGEXP = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;

const Footer = ({ mode, footer, updateContentData }) => {
  const { operation, content } = footer;
  const [email, setEmail] = useState("");
  const [emailErr, setEmailErr] = useState("");

  const handleChange = (event) => {
    const email = event.target.value;
    const emailErr = EMAIL_REGEXP.test(email) ? null : "Email is not valid";
    setEmail(email);
    setEmailErr(emailErr);
  };

  const copyrightTextHandler = (event) => {
    const data = event.editor.getData();
    const id = "footer";
    const name = "copyrightText";

    updateContentData(data, id, name);
  };

  const handleSubscribe = (event) => {
    event.preventDefault();
    console.log("submit email ==>", email);
  };

  const renderView = () => {
    if (mode === "edit") {
      return (
        <>
          <div className="col-lg-6 col-xs-12">
            <div id="introduction18">
              <form>
                <div className="row">
                  <div className="col-lg-6">
                    <FormGroup controlId="formBasicText">
                      <InputGroup>
                        <InputGroup.Addon>
                          <i className="fa fa-envelope" aria-hidden="true"></i>
                        </InputGroup.Addon>
                        <FormControl
                          type="text"
                          value=""
                          placeholder="Enter Email"
                        />
                      </InputGroup>
                    </FormGroup>
                  </div>
                  <div className="col-lg-6">
                    <Button bsStyle="success">Subscribe</Button>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div className="col-lg-6 col-xs-12" style={{ float: "right" }}>
            <p style={{ color: "#ffffff", textAlign: "right" }}>
              {" "}
              <span id="introduction19">
                <TekCKEditor
                  data={content.copyrightText}
                  onChange={copyrightTextHandler}
                />
              </span>
            </p>
          </div>
        </>
      );
    }

    return (
      <>
        <div className="col-lg-6 col-xs-12">
          <div id="introduction18">
            <form onSubmit={handleSubscribe}>
              <div className="row">
                <div className="col-lg-6">
                  <FormGroup controlId="formBasicText">
                    <InputGroup>
                      <InputGroup.Addon>
                        <i className="fa fa-envelope" aria-hidden="true"></i>
                      </InputGroup.Addon>
                      <FormControl
                        type="text"
                        value={email}
                        placeholder="Enter Email"
                        onChange={handleChange}
                      />
                    </InputGroup>

                    <span className="emailErrText">{emailErr}</span>
                  </FormGroup>
                </div>
                <div className="col-lg-6">
                  <Button
                    bsStyle="success"
                    type="submit"
                    disabled={emailErr === "" || emailErr}
                  >
                    Subscribe
                  </Button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div className="col-lg-6 col-xs-12" style={{ float: "right" }}>
          <p style={{ color: "#ffffff", textAlign: "right" }}>
            {" "}
            <span id="introduction19">
              <EditorPreview data={content.copyrightText} />
            </span>
          </p>
        </div>
      </>
    );
  };

  return (
    <Styles>
      <div
        style={{
          background: "#323232",
          paddingTop: "1rem",
          paddingBottom: "0",
        }}
      >
        <div className="container">
          <div className="row">{renderView()}</div>
        </div>
      </div>
    </Styles>
  );
};

export default Footer;
