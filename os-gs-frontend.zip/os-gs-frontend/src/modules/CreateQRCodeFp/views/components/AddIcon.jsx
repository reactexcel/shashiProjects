import React from "react";
import plusImage from "../../../CreateQRCode/assets/plus.png";

const AddIcon = () => {
  return (
    <div className="row">
      <div className="addelement">
        <img src={plusImage} alt="Add Element"></img>
      </div>
    </div>
  );
};

export default AddIcon;
