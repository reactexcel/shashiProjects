export const CREATE_BARCODE_HEADER_TITLE = "Create BarCode";
export const EDIT_BARCODE_HEADER_TITLE = "Edit BarCode";
export const VIEW_BARCODE_HEADER_TITLE = "View BarCode";
export const MANAGE_BARCODE_HEADER_TITLE = "BarCode";

export const CREATE_BARCODE = "createBarCode";
export const DEATIVATE_BARCODE = "deactivateBarCode";
export const ACTIVE_BARCODE = "activateBarCode";
export const MODULE_NAME = "barcode";

export const CREATE_BARCODE_PAGE_URL = '/admin/create-barcode';
export const MANAGE_BARCODE_PAGE_URL = '/admin/manage-qrcode';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_BARCODE_LIST_URL = BASE_URL + '/barcodes';
export const GET_TRACEBILITY_LIST_URL = BASE_URL + '/traceabilities/v1';
export const GET_BARCODE_DETAILS_URL = BASE_URL + '/barcodes/';
export const SET_CREATE_BARCODE_DETAILS_URL = BASE_URL + '/barcodes';
export const SET_UPDATE_BARCODE_DETAILS_URL = BASE_URL + '/barcodes/';

export const INGREDIENT_TABLE_NAME = 'INGREDIENTS';
export const OPERATION_TABLE_NAME = 'OPERATIONS';
export const BOM_KIT_TABLE_NAME = 'BOM-KIT COMPONENT';
