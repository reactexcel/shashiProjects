import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import StatusUtil from "../../common/util/statusUtil";
import DownloadBarCode from '../views/DownloadBarCode';

export const MANAGE_QRCODE_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Lot#",
        id: "lotNumber",
        accessor: "lotNumber",
        disableSortBy: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>
              {original.multipleUti ?
                <div className="multiple-uti">
                  <Nav>
                    <NavDropdown id="" title={original.multipleUti}
                      noCaret>
                      <MenuItem onClick={(e) => that.getTdProps(e)}>
                        <div className="multiple-uti-top">
                          <div className="header">Product</div>
                          <div className="header">Uti</div>
                        </div>
                        {original.productInfo && original.productInfo.length > 0 &&
                          original.productInfo.map((productInfoObj, index) =>
                            <div className="multiple-uti-details">
                              <div className="multiple-uti-items">{productInfoObj.productName}</div>
                              <div className="multiple-uti-items">{productInfoObj.uti}</div>
                            </div>
                          )}
                      </MenuItem>
                    </NavDropdown>
                  </Nav>
                </div>
                : original.lotNumber
              }
            </>
          )
        }
      },
      // {
      //   Header: "Batch",
      //   id: "batch",
      //   accessor: "batch",
      //   style: {
      //     flex: "0 0 120px",
      //   },
      //   disableSortBy: true,
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <>
      //         {original.multipleBatch ? original.multipleBatch : original.batch}
      //       </>
      //     )
      //   }
      // },
      {
        Header: "Product",
        id: "product",
        accessor: "product",
        disableSortBy: true,
        className: "roles",
      },
      {
        Header: "Supplier",
        id: "supplier",
        accessor: "supplier",
        disableSortBy: true,
        className: "roles",
      },
      {
        Header: "Order #",
        id: "ordernumber",
        accessor: "ordernumber",
        style: {
          flex: "0 0 100px",
        },
        disableSortBy: true,
      },
      {
        Header: "Qty",
        id: "quantity",
        accessor: "quantity",
        disableSortBy: true,
        style: {
          flex: "0 0 80px",
        },
      },
      // {
      //   Header: "QRCode Status",
      //   id: "qrStatus",
      //   accessor: "qrStatus",
      //   style: {
      //     flex: "0 0 105px",
      //   },
      //   disableSortBy: true,
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let qrStatus = that.getQRAndUTIStaus(original.isQrcodeGenerated);
      //     return (
      //       <div className="full-td" style={{
      //         backgroundColor: StatusUtil.getStatusColor(qrStatus),
      //         borderRadius: '5px'
      //       }}>
      //         {StatusUtil.getStatusLabel(qrStatus)}
      //       </div>
      //     )
      //   },
      // },
      {
        Header: "Barcode Label",
        id: "barCodeStatus",
        accessor: "barCodeStatus",
        style: {
          flex: "0 0 110px",
        },
        disableSortBy: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          const productId = original.product.split("|")[0];
          const utiNumber = original.uti;
          let barCodeStatus = that.getQRAndUTIStaus(original.isBarcodeGenerated);
          return (
            <div className="full-td" style={{
              backgroundColor: StatusUtil.getStatusColor(barCodeStatus),
              borderRadius: '5px'
            }}>
            <DownloadBarCode value={productId} utiNumber={utiNumber} />
              <i title="Download barcode" id="id" className="fa fa-download" onClick={() => that.downloadBarCode({productId, utiNumber})} />
            </div>
          )
        },
      },
      // {
      //   Header: "Action",
      //   id: "action",
      //   accessor: "action",
      //   className: "action justify-content-center",
      //   style: {
      //     flex: "0 0 50px",
      //   },
      //   disableSortBy: true,
      //   disableFilters: true,
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     return (
      //       <div className="actions-left">
      //         <Nav pullRight>
      //           <NavDropdown id=""
      //             title={<i className="fa fa-ellipsis-v" id="" onClick={(e) => that.getTdProps(e)} />}
      //             noCaret>
      //             {original.isQrcodeGenerated ?
      //               <MenuItem
      //                 id={`${original.uti}#MENU#EDITQRCODE#${index}`}
      //                 onClick={(e) => that.getTdProps(e)}>
      //                 Edit QRCode
      //             </MenuItem>
      //               :
      //               <MenuItem
      //                 id={`${original.uti}#MENU#CREATEQRCODE#${index}`}
      //                 onClick={(e) => that.getTdProps(e)}>
      //                 Generate QRCode
      //             </MenuItem>}
      //           </NavDropdown>
      //         </Nav>
      //       </div>
      //     );
      //   },
      // },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const CREATE_BARCODE_HEADER_LIST = (that) => {
  return {
    attributeObj: {
      uti: '',
    },
    attributeList: [
      {
        name: "uti",
        type: "TEXTBOX",
        label: "UTI Number",
        required: true,
        fieldWidth: 4,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "disabled",
        cloneMode: "disabled",
        editMode: "disabled",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 32,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
    ]
  };
};

export const CREATE_BARCODE_LIST = (that) => {
  return {
    attributeObj: {
      name: '',
      quantity: '',
      price: '',
      utiCode: ''
    },
    attributeList: [
      {
        name: "name",
        type: "TEXTBOX",
        label: "name",
        required: true,
        fieldWidth: 4,
        inputType: "text",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 32,
        minLength: 3,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "quantity",
        type: "TEXTBOX",
        label: "Quantity",
        required: true,
        fieldWidth: 4,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        minLength: 1,
        mandatoryMsgText: "Field can not be empty.",
      },
      {
        name: "price",
        type: "TEXTBOX",
        label: "Price",
        required: true,
        fieldWidth: 4,
        inputType: "number",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        createMode: "enable",
        cloneMode: "enable",
        editMode: "enable",
        viewMode: "disabled",
        placeholder: "",
        numberOfRow: 0,
        maxLength: 10,
        minLength: 1,
        mandatoryMsgText: "Field can not be empty.",
      },
    ]
  };
};