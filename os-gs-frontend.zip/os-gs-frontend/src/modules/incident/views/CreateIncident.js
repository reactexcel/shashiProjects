import React, { Component } from "react";
import { Grid, Row, Col, FormGroup, FormControl, MenuItem, Tabs, Tab, Nav, NavDropdown } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import {
    setIncidentDetails, getIncidentDetails, setReducerInitMode,
    updateIncidentDeleteStatus, updateIncidentComment, setSelectedBatchCode
} from "../actions/incidentActions";
import { getProductDetails } from "../../productManagement/actions/productActions";
import { getUserList } from "../../userManagement/actions/userActions";
import { getUserProfile } from "../../userManagement/actions/userActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as incidentConstant from '../constant/incidentConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { setActionMode } from "../../../actions/appActions";
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import LabelUtil from "modules/common/util/labelUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DateUtil from '../../common/util/dateUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import StatusUtil from '../../common/util/statusUtil';
import * as _ from "lodash";
import * as commonConstant from '../../common/constant/commonConstant';
import * as statusConstant from '../../common/constant/statusConstant';
import info from "assets/img/info-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import Table from '../../../views/Tables/PopularTable/Table/Table';
import ReceivedModal from "./receivedModal.js";
import { touch } from "redux-form";

class CreateIncident extends Component {
    constructor(props) {
        super(props);
        this.state = {
            attributeList: null,
            attributeObj: null,
            incidentCode: null,
            submitted: false,
            customErrorFlag: false,
            alert: null,
            key: 'COMMENTS',
            comments: [],
            isRecallWithdraw: false,
            productname: '',
            currentPage: 1,
        };
        this.handleSave = this.handleSave.bind(this);
        this.handleCommentSave = this.handleCommentSave.bind(this);
        this.handleCommentTextChange = this.handleCommentTextChange.bind(this);
        this.handlePopupContinue = this.handlePopupContinue.bind(this);
        this.handlePopupCancel = this.handlePopupCancel.bind(this);
        this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
        this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    }

    componentDidMount = () => {
        mixpanel.track("Create Incident loaded");
        if (CommonUtil.isNotNull(this.props.actionMode)) {
            if (!CommonUtil.isCreateMode(this.props.actionMode)) {
                this.props.getIncidentDetails(this.props.selectedBatchCode, this.props.selectedIncidentCode);
            }
        }
        else {
            CommonUtil.handlePageRedirection(incidentConstant.MANAGE_INCIDENT_PAGE_URL, this);
        }
        this.setSelectedTableDetails();
        this.props.getUserList();
        this.props.getUserProfile();
    }

    handleTab = (label, event) => {
        var selectedTabKey = label.toUpperCase();
        this.setState({ key: selectedTabKey });
    }

    handlebatchtrace = async (attributeObj) => {
        this.handleTab('TRACE RESULT');
        const managePageList = pagePropertyListConstant["BATCH_TRACE_RESULT_LIST"](this);
        const manageDetailPageList = pagePropertyListConstant["BATCH_TRACE_DETAILS_RESULT_LIST"](this);
        let tempObj = {};
        let tempQuantity = 0;
        let recallstatus;
        let tempTableDataList = [];
        let productcode = "";
        let ordernumber = "";
        let tempDetailstableDataList = attributeObj.recallWithdrawList
        if(tempDetailstableDataList != null) {
            for(let i = 0; i< tempDetailstableDataList.length; i++) {
                tempQuantity = tempQuantity + tempDetailstableDataList[i].qtyInciated;
                ordernumber = tempDetailstableDataList[i].ordernumber;
                productcode = tempDetailstableDataList[i].productId;
                if (tempDetailstableDataList[i].rwstatus = 'notified') {
                    recallstatus = 'notified';
                    continue;
                } else {
                    recallstatus = 'completed';
                }
            }
        }
        if (CommonUtil.isNotNull(this.props.productDetails)) {
            const name = this.props.productDetails.productId + '|' + this.props.productDetails.productName;
            await this.setState({productname: name});
        }
        tempObj.uti = attributeObj.recallWithdrawList[0].rwuti;
        tempObj.batch = attributeObj.batch;
        tempObj.incident = attributeObj.incidentCode;
        tempObj.totalqtyInciated = tempQuantity;
        tempObj.recallstatus = recallstatus;
        tempObj.ordernumber = ordernumber;
        tempObj.product = this.state.productname;
        tempTableDataList.push(tempObj);

        await this.setState({
            isRecallWithdraw: true,
            tableColumnList: managePageList.tableColumnList,
            tableConfig: managePageList.tableConfig,
            detailstableColumnList: manageDetailPageList.tableColumnList,
            detailstableConfig: manageDetailPageList.tableConfig,
            detailstableDataList: attributeObj.recallWithdrawList,
            tableDataList: tempTableDataList,
        })
    }

    setSelectedTableDetails = async () => {
        const commonAttributeList = JSON.parse(JSON.stringify(pagePropertyListConstant.CREATE_INCIDENT_PAGE_LIST));
        const traceabilityAttributeList = pagePropertyListConstant.CREATE_TRACEABILITY_STATUS_TABLE_LIST(this);

        await this.setState({
            attributeList: CommonUtil.getDropDownOptionsFromDictionary(
                commonAttributeList.attributeList, this.props.dataDictionaryList),
            attributeObj: commonAttributeList.attributeObj,

            traceabilityAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
                traceabilityAttributeList.attributeList, this.props.dataDictionaryList),
            traceabilityAttributeObj: traceabilityAttributeList.attributeObj,
            traceabilityTableColumnList: traceabilityAttributeList.tableColumnList,
            traceabilityTableConfig: traceabilityAttributeList.tableConfig,
        })
        let { attributeObj, attributeList } = this.state;
        attributeObj.batch = CommonUtil.isCreateMode(this.props.actionMode) ? this.props.selectedBatchCode : '';
        if (CommonUtil.isNotNull(attributeObj.batch)) {
            attributeList = CommonUtil.setDisabledPropertyInAttribute(attributeList, ['batch'], true);
        }
        this.setState({ attributeObj: attributeObj, attributeList: attributeList });
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
            this.updateApiData(this.props.attributeObj);
            if(!CommonUtil.isCreateOrCloneMode(this.props.actionMode) && this.props.attributeObj.isRecallWithdraw == true) {
                const code = this.props.attributeObj.recallWithdrawList[0].productId;
                this.props.getProductDetails(code);
            }
        }
        if (prevProps.userList !== this.props.userList && this.props.userList !== null) {
            this.updateUserDropDownList();
        }
        if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
            this.handleAjaxResponse();
        }
        if (prevProps.userProfile !== this.props.userProfile && this.props.userProfile !== null) {
            this.setState({ userProfile: this.props.userProfile })
        }
        if (this.props.productDetails !== null && prevProps.productDetails !== this.props.productDetails) {
            this.updateApiData(this.props.attributeObj);
        }
        if (prevProps.location.key !== this.props.location.key) {
            if (!CommonUtil.isCreateMode(this.props.actionMode)) {
                this.props.getIncidentDetails(this.props.selectedBatchCode, this.props.selectedIncidentCode);
            }
        }
    }

    componentWillUnmount() {
        this.props.setReducerInitMode(null);
        this.props.setSelectedBatchCode(null);
    }

    updateUserDropDownList = () => {
        let tempUserList = [];
        tempUserList.Items = this.props.userList.Items.filter(value => {
          if (value.status && value.status.toLowerCase() == "confirmed") {
            return (value);
          }
          return;
        });
        this.setState({
            attributeList: CommonUtil.setDropDownOptionsInAttribute(this.state.attributeList,
                CommonUtil.getDropDownOptionsFromList(tempUserList, 'firstName',
                    'email'), 'assignUsers'),
        })
    }

    handleSave(event) {
        this.setState({ submitted: true });
        var tempActionMode = this.props.actionMode != null ? this.props.actionMode :
            commonConstant.CREATE_ACTION_MODE;
        var tempObj = this.state.attributeObj;
        tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
            this.state.attributeList, tempActionMode);
        tempObj.batch = tempObj.batch.toUpperCase();    
        tempObj.comments = [...this.state.comments];
        if (ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
            this.props.setIncidentDetails(tempObj, tempActionMode);
        }
    }

    handleCommentSave(event) {
        var tempObj = {};
        tempObj.comment = this.state.commentsArea;

        if(!tempObj.comment) {
            return;
        }
        tempObj.firstName = this.state.userProfile && this.state.userProfile.firstName;
        tempObj.lastName = this.state.userProfile && this.state.userProfile.lastName;
        var currentDate = new Date();
        tempObj.time = currentDate.toISOString();
        var comments = [];
        comments = this.state.comments;
        comments.push(tempObj);
        comments = _.orderBy(comments, ['time'], ['desc']);

        var commentObj = {};
        const { attributeObj } = this.state;
        commentObj.incidentCode = attributeObj.incidentCode;
        commentObj.comment = this.state.commentsArea;
        commentObj.assignUsers = attributeObj.assignUsers;
        commentObj.batch = attributeObj.batch;
        commentObj.time = tempObj.time;
        var tempParam = { comment: true };
        this.props.updateIncidentComment(commentObj, tempParam);
        this.setState({ comments: [...comments], commentsArea: '' });
    }

    handleCommentTextChange = (event) => {
        const { name, value } = event.target;
        this.setState({ [name]: value })
    }

    handleHeaderIconClick = (e, action) => {
        if (!CommonUtil.isEditMode(this.props.actionMode)) {
            return;
        }
        switch (action) {
            case commonConstant.PRINT_ACTION:
                this.printIncident();
                break;
            case commonConstant.CLONE_ACTION:
                this.cloneIncident()
                break;
            case commonConstant.TRASH_ACTION:
                this.deleteIncident();
                break;
            default:
                console.log('Invalid header action')
        }
    }

    printIncident = (params) => {
        // TODO
    }

    cloneIncident = (params) => {
        this.props.setActionMode(commonConstant.CLONE_ACTION_MODE);
        this.props.getIncidentDetails(this.props.selectedBatchCode, this.state.attributeObj.incidentCode);
    }

    deleteIncident = (params) => {
        var popupActionButton = {};
        popupActionButton.onConfirmClick = this.handleStatusAction;
        popupActionButton.onCancelClick = this.handlePopupCancel;
        var popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, incidentConstant.MODULE_NAME);
        this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }

    handleStatusAction = (status) => {
        var tempObj = {};
        tempObj.deleted = true;
        tempObj.batch = this.state.attributeObj.batch;
        this.setState({ alert: null });
        this.props.updateIncidentDeleteStatus(tempObj, this.state.attributeObj.incidentCode);
    }

    handleAjaxResponse() {
        if (this.props.ajaxCallStatus.status == "SUCCESS") {
            this.props.setAjaxCallStatus(null);
            if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
                this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
                    CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
            }
            else {
                this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
            }
            let params = null;
            if (this.state.attributeObj.status == statusConstant.CLOSED_STATUS) {
                params = "COMPLETED";
            }
            setTimeout(CommonUtil.handlePageRedirection(incidentConstant.MANAGE_INCIDENT_PAGE_URL, this, params), 0);
        }

        if (this.props.ajaxCallStatus.status == "FAILED") {
            if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
                var errorMessage = this.props.ajaxCallStatus.data &&
                    this.props.ajaxCallStatus.data.response &&
                    this.props.ajaxCallStatus.data.response.data;
                if (errorMessage && this.props.ajaxCallStatus.data.response.data.code == "404") {
                    this.setState({ customErrorFlag: true });
                }
                else {
                    PopupUtil.popupErrorResponse(this);
                }
            }
            else {
                PopupUtil.popupErrorResponse(this);
            }
            this.props.setAjaxCallStatus(null);
        }
    }

    handlePopupCancel() {
        this.setState({ alert: null });
    }

    handlePopupContinue() {
        let params = null;
        if (this.props.attributeObj && this.props.attributeObj.status == statusConstant.CLOSED_STATUS) {
            params = "COMPLETED";
        }
        CommonUtil.handlePageRedirection(incidentConstant.MANAGE_INCIDENT_PAGE_URL, this, params);
    }

    async updateApiData(attributeObj) {
        if (CommonUtil.isCloneMode(this.props.actionMode)) {
            attributeObj.batch = '';
        }
        if (attributeObj.deleted) {
            this.props.setActionMode(commonConstant.VIEW_ACTION_MODE);
        }
        if(!CommonUtil.isCreateOrCloneMode(this.props.actionMode) && attributeObj.isRecallWithdraw == true) {
            this.handlebatchtrace(attributeObj);
        }
        await this.setState({
            attributeObj: {
                ...attributeObj,
                incidentCode: CommonUtil.isCloneMode(this.props.actionMode) ?
                    '' : attributeObj.incidentCode,
                status: CommonUtil.isCloneMode(this.props.actionMode) ? statusConstant.OPEN_STATUS : attributeObj.status
            },
            comments: _.orderBy([...attributeObj.comments], ['time'], ['desc']), function() {
            }
        });
    }

    getTdProps = (event) => {
        var tempId = event.target.id.split("#");
        if (CommonUtil.isMenuMode(tempId[1])) {
          CommonUtil.overlay(event);
          this.handleMenuPopupAction(event);
        }
    }

    handleMenuPopupAction = (event) => {
        const tempId = event.target.id.split("#");
    };

    render() {
        const { attributeList, attributeObj, submitted, userProfile, customErrorFlag, tableColumnList, tableDataList, tableConfig, detailstableColumnList, detailstableDataList, detailstableConfig, isRecallWithdraw } = this.state;
        const actionMode = this.props.actionMode;
        return (
            <div className="main-content create-page">
                {this.state.redirect === true ?
                    <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
                }
                {this.state.alert}
                <Grid fluid>
                    <Row className="top-row">
                        <Col md={12} className="header-section">
                            <Col sm={4} md={4}>
                                <div className="page-title">
                                    <img src={info} alt="" className="page-icon" />
                                    {CommonUtil.isEditMode(this.props.actionMode) ?
                                        incidentConstant.EDIT_INCIDENT_HEADER_TITLE :
                                        incidentConstant.CREATE_INCIDENT_HEADER_TITLE}

                                </div>
                            </Col>
                            <Col xs={12} sm={8} md={8}>
                                <div className="left-section">
                                    <div className="page-action-buttons">
                                        <div className={!CommonUtil.isViewMode(actionMode) ? 'btn-fill btn-wd btn progress-button' : 'btn-fill btn-wd btn progress-button disabled'}
                                            style={{
                                                backgroundColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status),
                                                borderColor: StatusUtil.getStatusColor(attributeObj && attributeObj.status)
                                            }}>
                                            <div className="items">{StatusUtil.getStatusLabel(attributeObj && attributeObj.status)}
                                            </div>
                                            {!CommonUtil.isViewMode(this.props.actionMode) && !CommonUtil.isCreateOrCloneMode(this.props.actionMode) ?
                                                <div className="items">
                                                    <Nav pullRight>
                                                        <NavDropdown id={'status'} title={<div><i className="fa fa-ellipsis-v" /></div>} noCaret>
                                                            {pagePropertyListConstant.HEADER_STATUS_LIST.map((tempAttributeListObj, index) => (
                                                                <MenuItem name="status" id={tempAttributeListObj.statusKey}
                                                                    onClick={(e) => CommonUtil.handleButtonStatusChange(e, this)}
                                                                    disabled={false}>
                                                                    <span style={{ backgroundColor: StatusUtil.getStatusColor(tempAttributeListObj.statusKey) }}></span>
                                                                    {StatusUtil.getStatusLabel(tempAttributeListObj.statusKey)}
                                                                </MenuItem>
                                                            ))}
                                                        </NavDropdown>
                                                    </Nav>
                                                </div>
                                            : null}
                                        </div>
                                        {/*<i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-print' : 'fa fa-print disabled'} title={"Print"}
                                            disabled={!CommonUtil.isEditMode(actionMode)}
                                            onClick={(e) => this.handleHeaderIconClick(e, commonConstant.PRINT_ACTION)} ></i>*/}
                                        <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-copy' : 'fa fa-copy disabled'} title={"Clone"}
                                            disabled={!CommonUtil.isEditMode(actionMode)}
                                            onClick={(e) => this.handleHeaderIconClick(e, commonConstant.CLONE_ACTION)} ></i>
                                        <i className={CommonUtil.isEditMode(actionMode) ? 'fa fa-trash' : 'fa fa-trash disabled'} title={"Trash"}
                                            disabled={!CommonUtil.isEditMode(actionMode)}
                                            onClick={(e) => this.handleHeaderIconClick(e, commonConstant.TRASH_ACTION)} ></i>
                                    </div>
                                    {!CommonUtil.isViewMode(this.props.actionMode) ?
                                        <div className="page-control-buttons">
                                            <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                                            <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                                        </div>
                                        :
                                        <div className="page-control-buttons">
                                            <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                                        </div>}
                                </div>
                            </Col>
                        </Col>
                    </Row>
                    <Row>
                        <Col md={12}>
                            <form>
                                <Card
                                    content={
                                        <div>
                                            <Row>
                                                {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                                                    tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                                        LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                                        : tempAttributeListObj.type == "DATE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                                            DateUtil.dateAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                                            : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                                                                : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                                                    : null))
                                                }
                                                {/*{!CommonUtil.isCreateOrCloneMode(this.props.actionMode) && !CommonUtil.isViewMode(this.props.actionMode) ?
                                                    <Col md={4} sm={4} className="batch-details-btn">
                                                        <div>
                                                            <Button className="btn-save btn-fill btn-wd" onClick={this.handlebatchtrace}>
                                                                Batch Trace
                                                        </Button>
                                                            <Button className="btn-save btn-fill btn-wd">
                                                                Batch Status
                                                        </Button>
                                                        </div>
                                                    </Col>
                                                    : null}*/}
                                            </Row>
                                        </div>
                                    }
                                />
                            </form>
                        </Col>
                    </Row>
                    <Row>
                        <Col md={12}>
                            <form>
                                <Card
                                    content={
                                        <div>
                                            {!CommonUtil.isCreateOrCloneMode(this.props.actionMode) ?
                                                <Tabs id="comments-incident-tabs" activeKey={this.state.key} onSelect={this.handleTab}>
                                                    {isRecallWithdraw == true &&
                                                        <Tab eventKey={'TRACE RESULT'} title="Trace Result">
                                                            <Row>

                                                                {tableColumnList != null ?
                                                                  <div className="trace-batch-result">
                                                                    {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                                                      <Table columns={tableColumnList}
                                                                        data={tableDataList}
                                                                        config={tableConfig}
                                                                        getRowProps={this.getTdProps}
                                                                        that={this}
                                                                      />
                                                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                                                  </div>
                                                                  : ''
                                                                }

                                                                {detailstableColumnList != null ?
                                                                  <>
                                                                    {detailstableDataList != null && detailstableDataList.length > 0 ?
                                                                      <Table columns={detailstableColumnList}
                                                                        data={detailstableDataList}
                                                                        config={detailstableConfig}
                                                                        getRowProps={this.getTdProps}
                                                                        that={this}
                                                                      />
                                                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                                                  </>
                                                                  : ''
                                                                }
                                                            </Row>
                                                        </Tab>
                                                    }
                                                    <Tab eventKey={'COMMENTS'} title="Comments">
                                                        <Row>
                                                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                                                                <>
                                                                    <Col md={8} className="add-comment">
                                                                        <div className="product-icon">
                                                                            <Col md={2} sm={2}>
                                                                                {userProfile ?
                                                                                    <button id="activity" class="product-circle">
                                                                                        {CommonUtil.getSubString(userProfile.firstName, 0, 1) +
                                                                                            CommonUtil.getSubString(userProfile.lastName, 0, 1)}

                                                                                    </button>
                                                                                    : null}
                                                                            </Col>
                                                                            <Col md={10} sm={10}>
                                                                                <FormGroup>
                                                                                    <FormControl
                                                                                        rows="4"
                                                                                        componentClass="textarea"
                                                                                        bsClass="form-control"
                                                                                        placeholder="Add a comment"
                                                                                        defaultValue=""
                                                                                        name="commentsArea"
                                                                                        value={this.state.commentsArea}
                                                                                        onBlur={(e) => CommonUtil.handleTextBoxBlur(e, this)}
                                                                                        onChange={this.handleCommentTextChange}
                                                                                        onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                                                                                        onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                                                                                        maxLength={100}
                                                                                    />
                                                                                    {touch && this.state.commentsArea && (this.state.commentsArea.length >= 100 || this.state.commentsArea.length < 3) &&
                                                                                        <small className="text-danger">
                                                                                          Allowed characters limit is 3 to 100
                                                                                        </small>
                                                                                      }
                                                                                </FormGroup>
                                                                            </Col>
                                                                        </div>
                                                                    </Col>
                                                                    <Col md={8} className="save-section">
                                                                        <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>
                                                                            Cancel
                                                                        </Button>
                                                                        <Button className="btn-save btn-fill btn-wd" onClick={this.handleCommentSave}>
                                                                            Add
                                                                        </Button>
                                                                    </Col>
                                                                </>
                                                            : null }
                                                            <Col md={8} className="comments-section">

                                                                {this.state != null && this.state.comments != null && this.state.comments.map((tempObj, index) => (

                                                                    <div className="product-icon">
                                                                        <Col md={1} sm={1}>
                                                                            <button id="activity" class="product-circle">
                                                                                {CommonUtil.getSubString(tempObj.firstName, 0, 1) +
                                                                                    CommonUtil.getSubString(tempObj.lastName, 0, 1)}
                                                                            </button>
                                                                        </Col>
                                                                        <Col md={11} sm={11}>
                                                                            <div className="user-name">
                                                                                {tempObj.firstName} {tempObj.lastName}
                                                                            </div>
                                                                            <div className="comment">
                                                                                {tempObj.comment}
                                                                            </div>
                                                                            <div className="reply-section">
                                                                                <span>{CommonUtil.getCurrentZoneFormatDate(tempObj.time)}</span>
                                                                            </div>
                                                                        </Col>
                                                                    </div>
                                                                ))}
                                                            </Col>
                                                        </Row>
                                                    </Tab>
                                                </Tabs>

                                                : null
                                            }
                                        </div>
                                    }
                                    ftTextRight
                                    legend={
                                        <>
                                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                                                <div>
                                                    <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                                                    <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                                                </div>
                                                :
                                                <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                                            }
                                        </>
                                    }
                                />
                            </form>
                        </Col>
                    </Row>
                </Grid>
            </div >
        );
    }
}

function mapStateToProps(state, ownProps) {
    return {
        attributeObj: state.incident.incidentDetails,
        selectedIncidentCode: state.incident.selectedIncidentCode,
        selectedBatchCode: state.incident.selectedBatchCode,
        actionMode: state.app.actionMode,
        ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
        currencyCode: state.dataDictionary.currencyCode,
        dataDictionaryList: state.dataDictionary.dataDictionaryList,
        userList: state.user.userList,
        userProfile: state.user.userProfile,
        productDetails: state.product.productDetails,
    };
}

const mapDispatchToProps = dispatch => ({
    setIncidentDetails: (incidentDetailsObj, actionMode) => dispatch(setIncidentDetails(incidentDetailsObj, actionMode)),
    getIncidentDetails: (selectedBatchCode, selectedIncidentCode) => dispatch(getIncidentDetails(selectedBatchCode, selectedIncidentCode)),
    setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
    setActionMode: actionMode => dispatch(setActionMode(actionMode)),
    getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
    updateIncidentDeleteStatus: (incidentDetails, incidentCode) => dispatch(updateIncidentDeleteStatus(incidentDetails, incidentCode)),
    setReducerInitMode: init => dispatch(setReducerInitMode(init)),
    updateIncidentComment: (incidentDetails, params) => dispatch(updateIncidentComment(incidentDetails, params)),
    getUserList: (id) => dispatch(getUserList(id)),
    setSelectedBatchCode: selectedBatchCode => dispatch(setSelectedBatchCode(selectedBatchCode)),
    getProductDetails: selectedProductCode => dispatch(getProductDetails(selectedProductCode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateIncident);
