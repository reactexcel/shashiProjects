import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, Tab, Tabs } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as incidentConstant from '../constant/incidentConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setSelectedIncidentCode,setSelectedBatchCode, getIncidentList, updateIncidentStatus,updateIncidentDeleteStatus } from "../actions/incidentActions";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PopupUtil from '../../common/util/popupUtil';
import { setActionMode } from "../../../actions/appActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import PopularTableUtil from '../../common/util/popularTableUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import PaginationUtil from '../../common/util/paginationUtil';
import StatusUtil from '../../common/util/statusUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import * as commonConstant from '../../common/constant/commonConstant';
import filter from 'assets/img/filter.svg';
import { getUserProfile } from "../../userManagement/actions/userActions";
import info from "assets/img/info-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
class ManageIncident extends Component {

  constructor(props) {
    super(props);
    this.state = {
      searchInput: "",
      selectedFilter: "all",
      alert: null,
      redirect: false,
      redirectUrl: null,
      incidentCode: null,
      defaultSelectedTab: "OPEN",
      selectedTab: "OPEN",
      status: null,

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
  }


  componentDidMount = () => {
    mixpanel.track("Manage Incident loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    const { defaultSelectedTab } = this.state;
    if (params == "COMPLETED") {
      this.setSelectedTabDetails("COMPLETED");
      const {location,history} = this.props;
      history.replace();
    } else {
      this.setSelectedTabDetails(defaultSelectedTab);
    }
  }

  setSelectedTabDetails = (selectedTab, filter) => {
    const managePageList = pagePropertyListConstant["MANAGE_INCIDENT_" +
      selectedTab.toUpperCase() + "_PAGE_LIST"](this);
    var additionalParams = { status: selectedTab.toLowerCase(), filter: filter};
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      tableDataList: [],
      selectedTab: selectedTab,
      searchInput: "",
      lastEvaluatedKeyArray:[],
      additionalParams: additionalParams
    }, function () {
      this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
        managePageList.tableConfig.defaultPageSize, this));
    })
  }

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    PaginationUtil.initPaginationParams(this);
    this.setSelectedTabDetails(selectedTabKey);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.incidentList != this.props.incidentList && this.props.incidentList != null) {
      PaginationUtil.handlePagination(this.props.incidentList, this);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.incidentList.Items.filter(value => {
      return (
        value.incidentCode.toLowerCase().includes(searchInput.toLowerCase()) ||
        value.incidentPlace.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  getButtonStatusColor = (value) => {
    return PopularTableUtil.getButtonStatusColor(value, incidentConstant);
  }

  handleFIlter = (event) => {
    PaginationUtil.initPaginationParams(this);
    let filter = event.toLowerCase()
    this.setSelectedTabDetails("OPEN", filter);
    this.setState({ selectedFilter: event });
  }


  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedIncidentCode(tempId[0]);
    this.props.setSelectedBatchCode(tempId[3]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(incidentConstant.CREATE_INCIDENT_PAGE_URL, this);
  }

  handleAjaxResponse = () => {
    let additionalData = this.props.ajaxCallStatus.additionalData;
    if (this.props.ajaxCallStatus.status == "SUCCESS" && additionalData && additionalData.deleteFlag) {
      this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,15, this));
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareDeleteSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      this.props.setAjaxCallStatus(null);
      PopupUtil.popupErrorResponse(this);
    }
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == incidentConstant.CREATE_INCIDENT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(incidentConstant.CREATE_INCIDENT_PAGE_URL, this);
    }

    if (tempId[2] == incidentConstant.ACTIVATE_INCIDENT) {
      this.handleStatusAction(tempId[0], statusConstant.ACTIVE_STATUS);
    }

    if (tempId[1] == commonConstant.DELETE_ACTION_MODE) {
      this.setState({
        incidentCode: tempId[0],
        batch:tempId[3],
        status: statusConstant.INACTIVE_STATUS
      });
      var popupActionButton = {};
      popupActionButton.onConfirmClick = this.handleStatusAction;
      popupActionButton.onCancelClick = this.handlePopupCancel;
      var popupConfig = CommonUtil.prepareDeletPopUpConfig(popupActionButton, incidentConstant.MODULE_NAME);
      this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    }
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  handleStatusAction(incidentCode, status) {
    var tempObj = {};
    var incidentCode = incidentCode ? incidentCode : this.state.incidentCode;
    tempObj.deleted = true;
    tempObj.batch = this.state.batch;
    let additionalData = {};
    additionalData.deleteFlag = true;
    this.setState({ alert: null });
    PaginationUtil.initPaginationParams(this);
    this.props.updateIncidentDeleteStatus(tempObj, incidentCode,additionalData);
  }

  makeCustomAPICall(tempParamas) {
    this.props.getIncidentList(tempParamas);
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isDeleteMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
  }


  render() {
    const { tableColumnList, tableDataList, tableConfig, selectedFilter } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={info} alt="" className="page-icon" />
                  {incidentConstant.MANAGE_INCIDENT_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section">
                    <i className="fa fa-search"></i>
                    <FormControl type="text" name="searchInput" placeholder="Search by code"
                      value={this.state.searchInput} onChange={this.handleChange} />
                  </div>

                  {this.state.selectedTab === "OPEN" && (
                    <Nav pullRight>
                      <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                        noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                        <MenuItem eventKey={statusConstant.ALL_STATUS} className={CommonUtil.isBothEqual(selectedFilter, statusConstant.ALL_STATUS) ? 'active' : null}>
                          {StatusUtil.getStatusLabel(statusConstant.ALL_STATUS)}
                        </MenuItem>
                        <MenuItem eventKey={statusConstant.OPEN_STATUS}
                          className={CommonUtil.isBothEqual(selectedFilter, statusConstant.OPEN_STATUS) ? 'active' : null}>
                          {StatusUtil.getStatusLabel(statusConstant.OPEN_STATUS)}
                        </MenuItem>
                        <MenuItem eventKey={statusConstant.IN_PROGRESS_STATUS}
                          className={CommonUtil.isBothEqual(selectedFilter, statusConstant.IN_PROGRESS_STATUS) ? 'active' : null}>
                          {StatusUtil.getStatusLabel(statusConstant.IN_PROGRESS_STATUS)}
                        </MenuItem>
                      </NavDropdown>
                    </Nav>
                  )}

                  <Button id={"incidentCode" + "_" + commonConstant.MENU_ACTION_MODE + "_" + incidentConstant.CREATE_INCIDENT}
                    fill wd className="create-options btn-default btn-fill btn-wd" onClick={this.handleMenuPopupAction.bind(this)}>
                    Create
                  </Button>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>

              <Card
                content={
                  <div>
                    <Tabs id="managepage-incident-tabs" activeKey={this.state.selectedTab} onSelect={this.handleTabClick}>
                      <Tab eventKey={'OPEN'} title="OPEN">
                        {tableColumnList != null ?
                          <Row>
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                          </Row>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                      </Tab>

                      <Tab eventKey={'COMPLETED'} title="COMPLETED">
                        {tableColumnList != null ?
                          <Row>
                            {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                              <Table columns={tableColumnList}
                                data={tableDataList}
                                config={tableConfig}
                                getRowProps={this.getTdProps}
                                that={this}
                              />
                              : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                          </Row>
                          : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                      </Tab>

                    </Tabs>

                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    incidentList: state.incident.incidentList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    userProfile: state.user.userProfile,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedIncidentCode: selectedIncidentCode => dispatch(setSelectedIncidentCode(selectedIncidentCode)),
  setSelectedBatchCode: selectedBatchCode => dispatch(setSelectedBatchCode(selectedBatchCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getIncidentList: id => dispatch(getIncidentList(id)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  updateIncidentStatus: (obj, status) => dispatch(updateIncidentStatus(obj, status)),
  updateIncidentDeleteStatus: (incidentDetails, incidentCode,additionalData) => dispatch(updateIncidentDeleteStatus(incidentDetails, incidentCode,additionalData)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageIncident);
