import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import { Redirect } from "react-router-dom";
var Modal = require('react-bootstrap-modal')

class receivedModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
    };
    this.handleSave = this.handleSave.bind(this);
    this.closeModal = this.closeModal.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }


  componentDidMount = async () => {
    this.setState({ openModal: true });
    let commonAttributeList = pagePropertyListConstant.RECEIVED_MODAL_LIST(this);

    await this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  closeModal = (event) => {
    this.setState({ openModal: false, submitted: false });
  }

  handleSave(event) {
    this.setState({ submitted: true, openModal: false });
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { attributeList, attributeObj, submitted } = this.state;
    const actionMode = this.props.actionMode;
    return (
      <div>
        {this.state.redirect === true ?
          <Redirect push to={{ pathname: this.state.redirectUrl, state: this.state.params }}></Redirect> : null
        }
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false}>
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Recall/Withdraw Receipt</div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content create-page">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            <Row>
                              {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                                tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                  : tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                    DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : null))
                              }
                            </Row>
                          </div>
                        }
                        ftTextRight
                        legend={
                          <>
                            {!CommonUtil.isViewMode(this.props.actionMode) ?
                              <div>
                                <Button className="btn-cancel" onClick={this.closeModal}>Cancel</Button>
                                <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                              </div>
                              :
                              <Button className="btn-cancel" onClick={this.closeModal}>Back</Button>
                            }
                          </>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(receivedModal);
