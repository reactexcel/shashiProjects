import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import StatusUtil from '../../common/util/statusUtil';
import * as statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import CommonUtil from "../../common/util/commonUtil";

export const CREATE_INCIDENT_PAGE_LIST =
{
    attributeObj: {
        incidentCode: '',
        incidentType: '',
        batch: '',
        incidentPlace: '',
        priority: '',
        assignUser: '',
        details: '',
        status: statusConstant.OPEN_STATUS,
        comments: [],
        tracibility: [],
        incidents: []
    },
    attributeList: [
        {
            name: "incidentCode",
            type: "UNIQUE_CODE",
            label: "Incident Number",
            prefix: "INC",
            required: false,
            inputType: "label",
            fieldWidth: 4,
            createModeRemoveFlag: true,
            cloneModeRemoveFlag: true,
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'disabled',
            cloneMode: 'disabled',
            editMode: 'disabled',
            viewMode: 'disabled',
            numberOfRow: 0,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "incidentType",
            type: "DROPDOWN",
            label: "Incident Type",
            required: true,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: "Select",
            numberOfRow: 0,
            maxLength: 32,
            dataDictionaryFlag: true,
            dataDictionaryId: "incidentTypeList",
            lengthValidationMessage: "Max length of 32 chars exceeded",
            mandatoryMsgText: "Field can not be empty.",
            options: [],
        },
        {
            name: "batch",
            type: "TEXTBOX",
            label: "Batch",
            required: true,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'disabled',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: " Uti / Batch",
            numberOfRow: 0,
            maxLength: 32,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
            customMessage: "Batch number does not exist."
        },
        {
            name: "incidentPlace",
            type: "DROPDOWN",
            label: "Incident - Place",
            required: true,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: "Select",
            numberOfRow: 0,
            maxLength: 32,
            dataDictionaryFlag: true,
            dataDictionaryId: "incidentPlaceList",
            lengthValidationMessage: "Max length of 32 chars exceeded",
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "priority",
            type: "DROPDOWN",
            label: "Priority",
            required: true,
            fieldWidth: 4,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: "Select",
            numberOfRow: 0,
            maxLength: 32,
            dataDictionaryFlag: true,
            dataDictionaryId: "priorityList",
            lengthValidationMessage: "Max length of 32 chars exceeded",
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "assignUsers",
            type: "DROPDOWN",
            label: "Assign Users",
            required: false,
            fieldWidth: 4,
            createMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            placeholder: "Select",
            mandatoryMsgText: "Field can not be empty.",
            options: []
        },
        {
            name: "details",
            type: "TEXTBOX",
            label: "Detail (Why?)",
            required: true,
            isMulti: true,
            fieldWidth: 8,
            inputType: "text",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
            createMode: 'enable',
            cloneMode: 'enable',
            editMode: 'enable',
            viewMode: 'disabled',
            placeholder: "",
            numberOfRow: 2,
            maxLength: 500,
            minLength: 3,
            mandatoryMsgText: "Field can not be empty.",
        },
        {
            name: "status",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
            viewModeShowFlag: true,
        },
        {
            name: "version",
            type: "TEMP",
            createModeShowFlag: false,
            cloneModeShowFlag: false,
            editModeShowFlag: true,
        },
        {
            name: "comments",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
        {
            name: "traceResult",
            type: "TEMP",
            createModeShowFlag: true,
            cloneModeShowFlag: true,
            editModeShowFlag: true,
        },
    ],
};

export const CREATE_TRACEABILITY_STATUS_TABLE_LIST = (that) => {
    return {
        tableData: [
        ],
        tableColumnList: [
            {
                Header: "Batch",
                id: "batch",
                accessor: "batch",
                name: "batch",
                required: false,
                disableSortBy: true,
                disableFilters: true,
                className: "input-field",
            },

        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "id",
                    value: ""
                }
            ],
            defaultSortedList: [
                {
                    id: "id",
                    desc: true
                }
            ],
            defaultPageSize: 50,
            rowId: 'id',
            addNewRowFunction: that.handleTableAddRow,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        }
    }
};

export const MANAGE_INCIDENT_OPEN_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Incident",
                id: "incidentCode",
                accessor: "incidentCode"
            },
            {
                Header: "Type",
                id: "incidentType",
                accessor: "incidentType"
            },
            {
                Header: "Incident Place",
                id: "incidentPlace",
                accessor: "incidentPlace"
            },
            {
                Header: "Created",
                id: "createddate",
                accessor: "createddate",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div>
                            {CommonUtil.getCurrentZoneFormatDate(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Priority",
                id: "priority",
                accessor: "priority",
                style: {
                    flex: "0 0 100px",
                },
            },
            {
                Header: "Batch",
                id: "batch",
                accessor: "batch"
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(value)}</div>
                        </div>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 80px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                <div className="circle">
                                    <i title="edit" id={original.incidentCode + "_" + commonConstant.EDIT_ACTION_MODE + '_' + index + "_" + original.batch}
                                        className="fa fa-pencil" onClick={(e) => that.getTdProps(e)} />

                                </div>
                                <div className="circle">
                                    <i title="delete" id={original.incidentCode + "_" + commonConstant.DELETE_ACTION_MODE + '_' + index + "_" + original.batch}
                                        className="fa fa-trash" onClick={(e) => that.getTdProps(e)} />
                                </div>
                            </Button>
                        </div>
                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [

            ],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_INCIDENT_COMPLETED_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Incident",
                id: "incidentCode",
                accessor: "incidentCode"
            },
            {
                Header: "Type",
                id: "incidentType",
                accessor: "incidentType"
            },
            {
                Header: "Incident Place",
                id: "incidentPlace",
                accessor: "incidentPlace"
            },
            {
                Header: "Created",
                id: "createddate",
                accessor: "createddate",
                Cell: ({ cell }) => {
                    const { value } = cell;
                    return (
                        <div>
                            {CommonUtil.getCurrentZoneFormatDate(value)}
                        </div>
                    )
                }
            },
            {
                Header: "Priority",
                id: "priority",
                accessor: "priority",
                style: {
                    flex: "0 0 120px",
                },
            },
            {
                Header: "Batch",
                id: "batch",
                accessor: "batch"
            },
            {
                Header: "Status",
                id: "status",
                accessor: "status",
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(value)}</div>
                        </div>
                    )
                }
            },
            {
                Header: "Actions",
                id: "actions",
                accessor: "actions",
                sticky: "right",
                className: "action justify-content-center",
                style: {
                    flex: "0 0 80px",
                },
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="actions-left">
                            <Button bsStyle="default" simple icon >
                                <div className="circle">
                                    <i title="view" id={original.incidentCode + "_" + commonConstant.VIEW_ACTION_MODE + '_' + index + "_" + original.batch}
                                        className="fa fa-eye" onClick={(e) => that.getTdProps(e)} />

                                </div>



                            </Button>
                        </div>
                    )
                }
            },
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [

            ],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const BATCH_TRACE_RESULT_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "UTI",
                id: "uti",
                accessor: "uti",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Batch",
                id: "batch",
                accessor: "batch",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Product",
                id: "product",
                accessor: "product",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Incident #",
                id: "incident",
                accessor: "incident",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Order Number",
                id: "ordernumber",
                accessor: "ordernumber",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Qty Initiated",
                id: "totalqtyInciated",
                accessor: "totalqtyInciated",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Status",
                id: "recallstatus",
                accessor: "recallstatus",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(value)}</div>
                        </div>
                    )
                }
            },
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [

            ],
            defaultPageSize: 50,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

export const BATCH_TRACE_DETAILS_RESULT_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Incident #",
                id: "incident",
                accessor: "incident",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Affected Batch",
                id: "affectedBatch",
                accessor: "affectedBatch",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "R/W UTI#",
                id: "rwuti",
                accessor: "rwuti",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "SO Number",
                id: "sonumber",
                accessor: "sonumber",
                disableSortBy: true,
                disableFilters: true,
            },
            {
                Header: "Qty Initiated",
                id: "qtyInciated",
                accessor: "qtyInciated",
                disableSortBy: true,
                disableFilters: true,
            },
            // {
            //     Header: "Qty Received",
            //     id: "qtyReceived",
            //     accessor: "qtyReceived",
            //     disableSortBy: true,
            //     disableFilters: true,
            // },
            {
                Header: "UTI Status",
                id: "utistatus",
                accessor: "utistatus",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(value)}</div>
                        </div>
                    )
                }
            },
            {
                Header: "R/W Status",
                id: "rwstatus",
                accessor: "rwstatus",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: "0 0 120px",
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div className="full-td" style={{
                            backgroundColor: StatusUtil.getStatusColor(value)
                        }}>
                            <div className="items">{StatusUtil.getStatusLabel(value)}</div>
                        </div>
                    )
                }
            },
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: ""
                }
            ],
            defaultSortedList: [

            ],
            defaultPageSize: 1000,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            isDraggable: false,
        }
    }
};

export const RECEIVED_MODAL_LIST = (that) => ({
  attributeObj: {
    soNumber: "",
    customer: "",
    orderedQty: "",
    product: "",
    location: "",
    receivingQty: "",
  },
  attributeList: [
    {
      name: "soNumber",
      type: "TEXTBOX",
      label: "Sales Order Number",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: 'enable',
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "customer",
      type: "TEXTBOX",
      label: "Customer",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "orderedQty",
      type: "TEXTBOX",
      label: "Ordered Qty",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "product",
      type: "TEXTBOX",
      label: "Product",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "location",
      type: "TEXTBOX",
      label: "Receiving Location",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "receivingQty",
      type: "TEXTBOX",
      label: "Receiving Qty",
      required: false,
      inputType: "text",
      fieldWidth: 4,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
  ],
});

export const HEADER_STATUS_LIST = [
    {
        statusKey: statusConstant.OPEN_STATUS
    },
    {
        statusKey: statusConstant.IN_PROGRESS_STATUS
    },
    {
        statusKey: statusConstant.CLOSED_STATUS
    },

]

