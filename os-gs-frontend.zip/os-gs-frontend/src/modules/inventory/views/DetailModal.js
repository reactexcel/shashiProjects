import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import * as pagePropertyListConstant from "../constant/pagePropertyConstant";
import CommonUtil from "../../common/util/commonUtil";
import PopularTableUtil from "../../common/util/popularTableUtil.js";
import PopupUtil from "../../common/util/popupUtil";
import Table from "../../../views/Tables/PopularTable/Table/Table";
import { getInventoryDetails } from "../actions/inventoryActions";
import StatusUtil from '../../common/util/statusUtil';
import currencyIcon from '../../common/util/currencyIcon';
var Modal = require('react-bootstrap-modal')

class DetailModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      attributeList: null,
      attributeObj: null,
      submitted: false,
      alert: null,
      tableDataKey: "tableDataList",
      tableDataList: [],
      selectedTab: "instock",
      average: '',
    };
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
    this.handleCalculation = this.handleCalculation.bind(this);
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
  };

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  getSelectedTablekey = (selectedTab) => {
    return this.state.tableDataKey;
  }

  handleTableButtonMenuAction = (event) => {
    PopularTableUtil.handleTableButtonMenuAction(event, this, this.getSelectedTablekey());
  };

  componentDidMount = () => {
    this.setState({ openModal: true });
    this.setState({ tableDataList: this.props.inventoryList });
    const { selectedTab } = this.state;
    this.setSelectedTabDetails(selectedTab);
    const commonAttributeList = pagePropertyListConstant.INVENTORY_MODAL_DETAIL_LIST(this);

    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  getRequestParams = (selectedTab) => {
    //  const{selectedTab} = this.state;
    var tempParamas = {};
    tempParamas.productId = this.props.uniqueCode;
    tempParamas.facilityId = this.props.location;
    tempParamas.isProduct = this.props.stockType == 'PRODUCT' ? true : false;
    tempParamas.tab = selectedTab.toLowerCase();
    return tempParamas;
  }

  setSelectedTabDetails = (selectedTab) => {
    const managePageList = pagePropertyListConstant["DETAIL_MODAL_" +
      selectedTab.toUpperCase() + "_TABLE_LIST"](this);
    var additionalParams = { tab: selectedTab.toLowerCase() };
    this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      selectedTab
    }, function () {
      this.props.getInventoryDetails(this.getRequestParams(selectedTab));
    })
  }

  handleTabClick = (label, event) => {
    var selectedTabKey = label.toUpperCase();
    this.setState({ tableDataList: [] })
    this.setSelectedTabDetails(selectedTabKey);
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (this.props.inventoryDetails != null && prevProps.inventoryDetails != this.props.inventoryDetails) {
      const prodName =  (this.props.inventoryDetails[0].stocktype === "PRODUCT" ? "PRO-" : "ING-") + this.props.inventoryDetails[0].productId + " | " + this.props.inventoryDetails[0].productName;
      let inventoryDetails= this.props.inventoryDetails[0];

      if (this.props.inventoryDetails[0].stocktype === "INGREDIENT") {
        // inventoryDetails.stock = CommonUtil.getFloatValue(Number(inventoryDetails.stock) * Number(inventoryDetails.usgPackSizeQty),2);
        // inventoryDetails.orderstock = CommonUtil.getFloatValue(Number(inventoryDetails.orderstock) * Number(inventoryDetails.usgPackSizeQty),2);
        // inventoryDetails.committedstock = CommonUtil.getFloatValue(inventoryDetails.committedstock, 2);
        // inventoryDetails.physicalstock = CommonUtil.getFloatValue(Number(inventoryDetails.physicalstock) * Number(inventoryDetails.usgPackSizeQty),2);

        inventoryDetails.stock = CommonUtil.getFloatValue(Number(inventoryDetails.stock) ,2);
        inventoryDetails.orderstock = CommonUtil.getFloatValue(Number(inventoryDetails.orderstock) ,2);
        inventoryDetails.committedstock = CommonUtil.getFloatValue(inventoryDetails.committedstock, 2);
        inventoryDetails.physicalstock = CommonUtil.getFloatValue(Number(inventoryDetails.physicalstock) ,2);

        // inventoryDetails.stockDetails = inventoryDetails.stockDetails.map((e) => {
        //   return {...e, usgPackSizeQty: inventoryDetails.usgPackSizeQty, usgCostPerUnit: inventoryDetails.usgCostPerUnit, uom: inventoryDetails.usgUOM };
        // });
      } else {
        // inventoryDetails.stockDetails = inventoryDetails.stockDetails.map((e) => {
        //   return {...e, usgPackSizeQty: 1, usgCostPerUnit: 1 };
        // });
      }
      
      inventoryDetails.surplus = CommonUtil.getFloatValue(inventoryDetails.stock, 2) + CommonUtil.getFloatValue(inventoryDetails.orderstock, 2) - CommonUtil.getFloatValue(inventoryDetails.committedstock, 2);

      this.setState({ tableDataList: inventoryDetails.stockDetails, attributeObj: inventoryDetails, prodName: prodName });
      this.handleCalculation(inventoryDetails.stockDetails);
    }
  }

  handleCalculation = (tempObj) => {
    let tempAverage = 0, totalPrice = 0, totalQty = 0;
    let inventoryDetails
    if (this.props.inventoryDetails) {
      inventoryDetails = this.props.inventoryDetails[0];
    }

    if (CommonUtil.isNotNull(tempObj)) {
      if (inventoryDetails.stocktype === "INGREDIENT") {
        for (var i = 0; i < tempObj.length; i++) {
          // let received = CommonUtil.getFloatValue(Number(tempObj[i].remainingstock) * Number(tempObj[i].usgPackSizeQty));
          let received = CommonUtil.getFloatValue(Number(tempObj[i].remainingstock));
          let purchase = CommonUtil.getFloatValue(tempObj[i].perUnitPrice);
          let tempTotalPrice = CommonUtil.getFloatValue((totalPrice) + (purchase * received), true);
          let tempTotalQty = CommonUtil.getTotalValue(totalQty, received);
          totalPrice = CommonUtil.getFloatValue(tempTotalPrice, 2);
          totalQty = CommonUtil.getFloatValue(tempTotalQty, 2);
        }
      } else {
        for (var i = 0; i < tempObj.length; i++) {
          let received = CommonUtil.getFloatValue(tempObj[i].remainingstock);
          let purchase = CommonUtil.getFloatValue(tempObj[i].perUnitPrice);
          let tempTotalPrice = CommonUtil.getFloatValue((totalPrice) + (purchase * received), true);
          let tempTotalQty = CommonUtil.getTotalValue(totalQty, received);
          totalPrice = CommonUtil.getFloatValue(tempTotalPrice, 2);
          totalQty = CommonUtil.getFloatValue(tempTotalQty, 2);
        }
      }
      
      tempAverage = CommonUtil.getFloatValue((totalPrice / totalQty), 2);
    }
    this.setState({ average: tempAverage, totalQty: totalQty, totalPrice: totalPrice });
  }

  makeCustomAPICall(tempParamas) {
    this.props.getInventoryDetails(tempParamas);
  }


  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
    }
    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.popupErrorResponse(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false, submitted: false });
    this.setState({ alert: null });
  }

  render() {
    const { attributeList, attributeObj, submitted, tableColumnList, tableConfig, tableDataList, prodName, average, totalPrice, totalQty } = this.state;
    const currencyCode = this.props.currencyCode;
    return (
      <div>
        <Modal show={this.state.openModal}
          onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false} className="recallwithdraw-modal">
          <Modal.Header closeButton>
            <Modal.Title>
              <div className="model-heading">Inventory Details: {prodName} </div>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="main-content">
              <Grid fluid>
                <Row>
                  <Col md={12}>
                    <form>
                      <Card
                        content={
                          <div>
                            <Tabs id="inventory-detail-tabs" className="table-tabs-without-border inventory-modal-tabs" onSelect={this.handleTabClick}>
                              <Col md={12} className="content-section">
                                {attributeList != null &&
                                  attributeList.map((tempAttributeListObj, index) =>
                                    tempAttributeListObj.type == "FIXED" ?
                                      <Col md={tempAttributeListObj.fieldWidth} sm={tempAttributeListObj.fieldWidthSmall ? tempAttributeListObj.fieldWidthSmall : tempAttributeListObj.fieldWidth} key={index}>
                                        <FormGroup>
                                          <ControlLabel className="fixed-label">
                                            {tempAttributeListObj.label}
                                          </ControlLabel>
                                          <div className="fixed-text" style={{ color: StatusUtil.getNegativeColor(attributeObj[tempAttributeListObj.name]) }}>
                                            {CommonUtil.getFloatValue(attributeObj[tempAttributeListObj.name], 2)}
                                          </div>
                                        </FormGroup>
                                      </Col>
                                      : null
                                  )}
                                {attributeObj != null &&
                                  <Col md={3}>
                                    <div className="physical-stock">
                                      (In hand {CommonUtil.getFloatValue(attributeObj.physicalstock, 2)})
                                        </div>
                                  </Col>
                                }
                              </Col>
                              <Tab eventKey={'instock'} title="INSTOCK">
                                <Row>
                                  <Col md={12} className="average-section">
                                    <div className="box">
                                      <div className="heading">Total Qty:</div>
                                      <div className="value">{totalQty}</div>
                                    </div>
                                    {/* <div className="box">
                                      <div className="heading">Total Cost:</div>
                                      <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,totalPrice)}</div>
                                    </div> */}
                                    {/* <div className="box">
                                      <div className="heading">Avg Price:</div>
                                      <div className="value">{currencyIcon.getCurrencyIcon(currencyCode)} {currencyIcon.getCurrencyDecimalFormat(currencyCode,average)}</div>
                                    </div> */}
                                  </Col>
                                </Row>
                                {tableColumnList != null ?
                                  <Row className="stockTable popupstocktable">
                                    {(tableDataList != null && tableDataList.length > 0) ?
                                      <Table columns={tableColumnList}
                                        data={tableDataList}
                                        config={tableConfig}
                                        getRowProps={this.getTdProps}
                                        that={this}
                                      />
                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                  </Row>
                                  : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                              </Tab>
                              <Tab eventKey={'expected'} title="EXPECTED">
                                {tableColumnList != null ?
                                  <Row className="stockTable popupstocktable">
                                    {(tableDataList != null && tableDataList.length > 0) ?
                                      <Table columns={tableColumnList}
                                        data={tableDataList}
                                        config={tableConfig}
                                        getRowProps={this.getTdProps}
                                        that={this}
                                      />
                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                  </Row>
                                  : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                              </Tab>
                              <Tab eventKey={'consumption'} title="COMMITTED">
                                {tableColumnList != null ?
                                  <Row className="stockTable popupstocktable">
                                    {(tableDataList != null && tableDataList.length > 0) ?
                                      <Table columns={tableColumnList}
                                        data={tableDataList}
                                        config={tableConfig}
                                        getRowProps={this.getTdProps}
                                        that={this}
                                      />
                                      : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                                  </Row>
                                  : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                              </Tab>
                            </Tabs>
                          </div>
                        }
                      />
                    </form>
                  </Col>
                </Row>
              </Grid>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    currencyCode: state.dataDictionary.currencyCode,
    inventoryDetails: state.inventory.inventoryDetails
  };
}

const mapDispatchToProps = (dispatch) => ({
  getInventoryDetails: (params) => dispatch(getInventoryDetails(params)),
  setAjaxCallStatus: (ajaxCallStatus) => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(DetailModal);
