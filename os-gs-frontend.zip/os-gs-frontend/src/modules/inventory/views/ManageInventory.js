import React, { Component } from "react";
import { Grid, Row, Col, Nav, NavDropdown, MenuItem, Tabs, Tab, FormGroup, FormControl } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "../../../components/Card/Card.jsx";
import * as inventoryConstant from '../constant/inventoryConstant';
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import Select from "react-select";
import { getInventoryList, downLoadXLSFile, getInventorySearchList } from "../actions/inventoryActions";
import CommonUtil from '../../common/util/commonUtil';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import { getFacilityList, getFacilityDetails } from "../../facilityManagement/actions/facilityActions";
import * as commonConstant from '../../common/constant/commonConstant';
import { setActionMode } from "../../../actions/appActions";
import DetailModal from "./DetailModal.js";
import { getUserProfile } from "../../userManagement/actions/userActions";
import inventory from "assets/img/inventory-page-icon.svg";
import pin from "assets/img/pin.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import isAuthorized from "auth-plugin";
import filter from 'assets/img/filter.svg';
import download from "assets/img/download.svg";
import LabelUtil from "modules/common/util/labelUtil";
import TextBoxUtil from '../../common/util/textBoxUtil';
import check from "assets/img/check.svg";
import CreatePurchaseOrder from "../../purchaseOrderAMS/views/CreatePurchaseOrder";
import CreateSaleOrder from "../../saleOrderAMS/views/CreateSaleOrder";
import CreateStockTransfer from "../../stockTransfer/views/CreateStockTransfer"
import CreateStockAdjustment from "../../stockAdjustment/views/CreateStockAdjustment"
import CreateMfgOrder from "../../manufacturingOrder/views/CreateMfgOrder"
import CreateStockCount from "../../stockCount/views/CreateStockCount";
import { setSelectedPurchaseOrderCode } from "../../purchaseOrder/actions/purchaseOrderActions";
import { setSelectedSaleOrderCode } from "../../saleOrder/actions/saleOrderActions"
import { setSelectedStockTransferCode } from "../../stockTransfer/actions/stockTransferActions"
import { setSelectedStockAdjustmentCode } from "../../stockAdjustment/actions/stockAdjustmentActions"
import { setSelectedMfgOrderCode } from "../../manufacturingOrder/actions/mfgOrderActions"
import { setSelectedKitOrderCode } from "../../stockKit/actions/kitOrderActions.js"
import { setSelectedStockCountCode } from "../../stockCount/actions/stockCountActions"
import SuggestionUtil from '../../common/util/suggestionUtil';
import { getProductList } from '../../productManagement/actions/productActions';
import { getIngredientList } from "../../ingredientManagement/actions/ingredientActions";
import CreateStockKit from "../../stockKit/views/CreateStockKit.jsx";
import _ from 'lodash';
import Button from "../../../components/CustomButton/CustomButton.jsx";
const Modal = require('react-bootstrap-modal')

class ManageInventory extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      submitted: false,
      searchInput: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      inventoryCode: null,
      status: null,
      key: 1,
      location: '',
      selectedTab: "PRODUCT",
      additionalParams: null,
      openModal: false,
      orderDetailsModal: false,
      uniqueCode: null,
      facilityList: [],
      search: null,
      productList: null,
      locationName: "",
      locationList: [],

      additionalParams: null,
      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: [],
      fileUrl: '#',
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
    this.handleStockCount = this.handleStockCount.bind(this);
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  componentDidMount = async () => {
    mixpanel.track("Manage Inventory loaded");
    let params = CommonUtil.getAdditonalPathParams(this);
    // let location = CommonUtil.getAdditonalPathLocation(this);
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    // this.props.getProductList({ isDropdown: true });
    // this.props.getIngredientList({ isDropdown: true });
    this.props.getFacilityList({ isDropdown: true });
    const { selectedTab } = this.state;
    // if (CommonUtil.isNotNull(location)) {
    //   await this.props.getFacilityDetails(location);
    // }
    if (params == "PRODUCT") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("PRODUCT");
      const { location, history } = this.props;
      history.replace();
    } else if (params == "INGREDIENT") {
      await this.setState({ selectedTab: params });
      await this.setSelectedTabDetails("INGREDIENT");
      const { location, history } = this.props;
      history.replace();
    } else {
      await this.setSelectedTabDetails(selectedTab);
    }
  }

  setSelectedTabDetails = async (selectedTab) => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    const managePageList = pagePropertyListConstant["MANAGE_INVENTORY_" +  selectedTab.toUpperCase() + "_PAGE_LIST"](this);
    // let additionalParams = { gross: selectedTab.toLowerCase() };
    let additionalParams = {};
    additionalParams["isIngredient"] = selectedTab.toUpperCase() == "PRODUCT" ? false : true;
    additionalParams["facilityId"] = this.state.location;
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      searchInput: "",
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
      selectedTab: selectedTab,
    });
    this.state.location && this.makeCustomAPICall(PaginationUtil.getPaginationParams(
      1, managePageList.tableConfig.defaultPageSize, this));
  }

  advanceSearch = async () => {
    if (CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false, status: null });
    }
  }

  handleTableSuggestionChange = async (event, eventId) => {
    let id = parseInt(eventId.split('_')[1]);
    let key = eventId.split('_')[0];
    if (event != null && event.length > 0) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.selectedTab == "PRODUCT" ? event[0].productId : event[0].ingredientId });
      this.setSelectedTabDetails(this.state.selectedTab);
      this.setState({ menuOpen: false, status: null });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  handleTabClick = async (label, event) => {
    PaginationUtil.initPaginationParams(this);
    var selectedTabKey = label.toUpperCase();
    await this.setState({
      tableDataList: [], nextClick: false,
      previousClick: false, nextClickDisable: true, previousClickDisable: true,
      pageSize: 1, currentPage: 1, lastEvaluatedKeyArray: []
    });
    this.setSelectedTabDetails(selectedTabKey);
  }

  componentDidUpdate(prevProps) {
    if (prevProps.inventoryList != this.props.inventoryList && this.props.inventoryList != null) {
      PaginationUtil.handlePagination(this.props.inventoryList, this);
    }
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList && this.state.location == '') {
      this.updateFacilityDropDownList();
    }
    if (this.props.facilityDetails != null && prevProps.facilityDetails != this.props.facilityDetails) {
      let tempObj = {};
      tempObj.value = this.props.facilityDetails.facilityId; tempObj.label = this.props.facilityDetails.facilityId + " | " + this.props.facilityDetails.facilityName;
      !this.state.orderDetailsModal && this.handleLocationDropdownChange(tempObj);
    }
    // if (this.props.location.state != null && prevProps.location.key !== this.props.location.key) {
    //   this.setSelectedTabDetails(this.props.location.state)
    //   this.props.getFacilityDetails(this.props.location.location);
    // }
    if (this.props.productList != null && prevProps.productList != this.props.productList) {
      this.updateProductDropDownList();
    }
    if (this.props.ingredientList != null && prevProps.ingredientList != this.props.ingredientList) {
      this.updateIngredientDropDownList();
    }
  }

  updateProductDropDownList = () => {
    this.setState({ productList: this.props.productList })
  }

  updateIngredientDropDownList = () => {
    this.setState({ ingredientList: this.props.ingredientList });
  }

  updateFacilityDropDownList = async () => {
    let tempList = CommonUtil.getOptionsFromList(
      this.props.facilityList, 'facilityId', 'facilityName', null, false, "FAC-")
    tempList = tempList.sort((a, b) => (a.value > b.value) ? 1 : ((b.value > a.value) ? -1 : 0))
    await this.setState({
      facilityList: tempList,
      locationList: this.state.location ? this.state.location : tempList[0],
      location: _.map(this.state.location ? [this.state.location] : [tempList[0]], (item) => item.value).join(),
      locationName: _.map(this.state.location ? [this.state.location] : [tempList[0]], (item) => item.label).join(", ")
    })
    tempList && tempList.length > 0 && await this.setSelectedTabDetails(this.state.selectedTab)
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.inventoryList.filter((value) => {
      return (
        value.productName.toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.productId).toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.sku).toLowerCase().includes(searchInput.toLowerCase()) ||
        value.ingredientName.toLowerCase().includes(searchInput.toLowerCase()) ||
        String(value.ingredientId).toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData })
  }

  handleFIlter = async (event) => {
    this.state.location = event;
    this.setState({ location: event });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({ locationList: tempObj, location: _.map(tempObj, (item) => item.value).join(), locationName: _.map(tempObj, (item) => item.label).join(", ") });
    this.setSelectedTabDetails(this.state.selectedTab);
  }

  handleExportFileDownLoad = () => {
    this.props.downLoadXLSFile();
  }

  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == inventoryConstant.STOCK_TRANSFER) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_TRANSFER_PAGE_URL, this);
    }

    if (tempId[2] == inventoryConstant.STOCK_ADJUSTMENT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_ADJUSTMENT_PAGE_URL, this);
    }

    if (tempId[2] == inventoryConstant.STOCK_KIT) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(inventoryConstant.STOCK_KIT_PAGE_URL, this);
    }
  }

  makeCustomAPICall = (tempParamas) => {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getInventorySearchList(tempParamas);
    } else {
      this.props.getInventoryList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");
    if (tempId != null && tempId[1] == inventoryConstant.MENU_ACTION_MODE) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  getCompleteDetails = (completeDetails) => {
    this.setState({ openModal: false });
  }

  handleModalopenButtonClick = (event, that) => {
    var tempId = event.target && event.target.id.split("_");
    this.setState({ openModal: true, uniqueCode: tempId[0], stockType: tempId[2] });
  }

  openModalWindow = (stockId, stockType, facilityId) => {
    this.setState({ openModal: true, uniqueCode: stockId, stockType: stockType, facilityId: facilityId });
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    PaginationUtil.initPaginationParams(this);
    if (tempId[1] === "search") {
      await this.setState({ search: null, status: null, lastEvaluatedKeyArray: [], searchInput: "" });
      await this.setSelectedTabDetails(this.state.selectedTab);
    }
  }

  handlePopupCancel = () => {
    this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
    this.setState({ alert: null, openModal: true, submitted: false, orderDetailsModal: false });
  }

  openOrderDetailsWindow = (orderCode) => {
    let tempId = orderCode !== null ? orderCode.split("-") : null;
    let orderType = tempId[0];
    this.props.setActionMode(commonConstant.VIEW_ACTION_MODE);
    if (orderType == "PO") {
      this.props.setSelectedPurchaseOrderCode(tempId[1]);
    } else if (orderType == "SO") {
      this.props.setSelectedSaleOrderCode(tempId[1]);
    } else if (orderType == "STO") {
      this.props.setSelectedStockTransferCode(tempId[1])
    } else if (orderType == "STA") {
      this.props.setSelectedStockAdjustmentCode(tempId[1])
    } else if (orderType == "MFG") {
      this.props.setSelectedMfgOrderCode(tempId[1])
    } else if (orderType == "KIT") {
      this.props.setSelectedKitOrderCode(tempId[1])
    } else if (orderType == "SCA") {
      this.props.setSelectedStockCountCode(tempId[1])
    }
    this.setState({ alert: null, openModal: false, submitted: false, orderDetailsModal: true, orderType: orderType, orderCode: orderCode });
  }

  handleStockCount = () => {
    this.props.history.push("/admin/manage-stock-count");
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, location, fileUrl, attributeList, attributeObj, submitted, search, orderType, orderCode } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={inventory} alt="" className="page-icon" />
                  {inventoryConstant.MANAGE_INVENTORY_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder={this.state.selectedTab == "PRODUCT" ? "Search by Product Code/Name/SKU" : "Search by Ingredient Code/Name/SKU"}
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? { cursor: 'default' } : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {/* {this.state.selectedTab == "PRODUCT" && <Col md={6} className="suggestion-box">
                    <i className="fa fa-search"></i>
                    <SuggestionUtil
                      searchOptionList={["productId", "productName", "productSKU"]}
                      id={'productId'}
                      options={this.state.productList}
                      selectedListKeys={['productId', 'productSKU']}
                      selectedAttributeList={this.state.products}
                      placeholder="Search by Product Code/Name/SKU"
                      disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                      value={this.state.selelctedValue}
                      selectedValue={this.state.selelctedValue}
                      resetOnSelection={true}
                      reSelect={true}
                      onChange={(e) => this.handleTableSuggestionChange(e, 'productId',
                        ["productId", "productName"])}
                      handleSuggestionChange={this.handleTableSuggestionChange}
                    />
                  </Col> }
                  {this.state.selectedTab == "INGREDIENT" && <Col md={6} className="suggestion-box">
                    <i className="fa fa-search"></i>
                    <SuggestionUtil
                      searchOptionList={["ingredientId", "ingredientName", "ingredientSKU"]}
                      id={'ingredientId'}
                      options={this.state.ingredientList}
                      selectedListKeys={['ingredientId', 'ingredientSKU']}
                      selectedAttributeList={this.state.ingredients}
                      placeholder="Search by Ingredient Code/Name/SKU"
                      disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                      value={this.state.selelctedValue}
                      selectedValue={this.state.selelctedValue}
                      resetOnSelection={true}
                      reSelect={true}
                      onChange={(e) => this.handleTableSuggestionChange(e, 'ingredientId',
                        ["ingredientId", "ingredientName"])}
                      handleSuggestionChange={this.handleTableSuggestionChange}
                    />
                  </Col>} */}

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}

                  {/*<Nav pullRight>
                    <NavDropdown title={<div className="filter"> <img src={filter} alt="" />  </div>}
                      noCaret id="status-filter" className="filter-status" onSelect={this.handleFIlter}>
                      <MenuItem eventKey="all" className={location === "all" ? 'active' : null}>All</MenuItem>
                      {filterDataList}
                    </NavDropdown>
                  </Nav>*/}

                  {isAuthorized("stockCount") &&
                    <Button id="stock-count"
                      fill wd className="create-options btn-default btn-fill btn-wd" onClick={() => this.handleStockCount()}>
                      Stock Count
                    </Button>
                  }
                  <div className="btn-fill btn-wd btn btn-default create-options create-dropdown" >
                    <div className="items">
                      <Nav pullRight>
                        <NavDropdown id="create-stock" title={<div>{" "}<i className="fa fa-ellipsis-v" />{" "}</div>}
                          noCaret >
                          {isAuthorized("createStockTransfer") &&
                            <MenuItem id={"inventoryCode" + "_" + inventoryConstant.MENU_ACTION_MODE +
                              "_" + inventoryConstant.STOCK_TRANSFER}
                              onClick={this.handleMenuPopupAction.bind(this)}>
                              Stock Transfer
                            </MenuItem>
                          }
                         
                          {isAuthorized("stockKitActions") &&
                            <MenuItem id={"inventoryCode" + "_" + inventoryConstant.MENU_ACTION_MODE +
                              "_" + inventoryConstant.STOCK_KIT}
                              onClick={this.handleMenuPopupAction.bind(this)}>
                              Stock Kit - Component
                          </MenuItem>
                          }
                        </NavDropdown>
                      </Nav>
                    </div>
                  </div>

                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ?
                          <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null}
                      </div>
                      : null}
                    <Tabs id="inventory-tabs" className="table-tabs-without-border" onSelect={this.handleTabClick}>
                      {inventoryConstant.getInventoryTabs().map((tempTabObj, index) => (
                        // isAuthorized(tempTabObj.tab) ?
                        tempTabObj.tab ?
                          <Tab eventKey={tempTabObj.key} title={tempTabObj.title}>
                            {tableColumnList != null ?
                              <Row className="stockTable">
                                {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                                  <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                  : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                              </Row>
                              : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                          </Tab> : null
                      ))}

                      <FormGroup className="location-dropdown">
                        {/* <div className="export-btn" onClick={this.handleExportFileDownLoad}>
                          <a href={fileUrl} ref="downloadxlsx" download style={{ display: 'none' }}></a>
                          <img src={download} alt="" /> Export
                        </div> */}
                         <div className="location-control multi">
                          <img src={pin} alt="" />
                          <div title={this.state.locationName} >
                            <Select
                              classNamePrefix="react-select"
                              name="location"
                              placeholder="Location"
                              isMulti={true}
                              value={ this.state.locationList }
                              onChange={(value) => this.handleLocationDropdownChange(value)}
                              options={[...this.state.facilityList]} />
                          </div>
                        </div>
                      </FormGroup>
                    </Tabs>
                    {this.state.openModal == true ?
                      <DetailModal
                        attributeObj={this.state.attributeObj}
                        uniqueCode={this.state.uniqueCode}
                        location={this.state.facilityId}
                        stockType={this.state.stockType}
                        getCompleteDetails={this.getCompleteDetails}
                        openOrderDetailsWindow={this.openOrderDetailsWindow}
                      >
                      </DetailModal>
                      : null}

                    {this.state.orderDetailsModal == true ?
                      <Modal show={this.state.orderDetailsModal} onHide={this.handlePopupCancel} aria-labelledby="ModalHeader" backdrop="static" keyboard={false} className="order-detail-modal">
                        <Modal.Header closeButton></Modal.Header>
                        <Modal.Body>
                          {orderType == "PO" && <CreatePurchaseOrder purchaseOrderId={orderCode} insideInventory={true}></CreatePurchaseOrder>}
                          {orderType == "SO" && <CreateSaleOrder saleOrderId={orderCode} insideInventory={true}></CreateSaleOrder>}
                          {orderType == "STO" && <CreateStockTransfer stockTransferId={orderCode} insideInventory={true}></CreateStockTransfer>}
                          {orderType == "STA" && <CreateStockAdjustment stockAdjustmentId={orderCode} insideInventory={true}></CreateStockAdjustment>}
                          {orderType == "MFG" && <CreateMfgOrder selectedMfgOrderCode={orderCode} insideInventory={true}></CreateMfgOrder>}
                          {orderType == "KIT" && <CreateStockKit selectedKitOrderCode={orderCode} insideInventory={true}></CreateStockKit>}
                          {orderType == "SCA" && <CreateStockCount selectedStockCountCOde={orderCode} insideInventory={true}></CreateStockCount>}
                        </Modal.Body>
                      </Modal>
                      : null
                    }

                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    inventoryList: state.inventory.inventoryList,
    facilityList: state.facility.facilityList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    userProfile: state.user.userProfile,
    currencyCode: state.dataDictionary.currencyCode,
    facilityDetails: state.facility.facilityDetails,
    inventorySearchList: state.inventory.inventorySearchList,
    productList: state.product.productList,
    ingredientList: state.ingredient.ingredientList,
  };
}

const mapDispatchToProps = dispatch => ({
  getInventoryList: params => dispatch(getInventoryList(params)),
  getInventorySearchList: params => dispatch(getInventorySearchList(params)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  downLoadXLSFile: (id) => dispatch(downLoadXLSFile(id)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
  setSelectedPurchaseOrderCode: (selectedSaleOrderCode) => dispatch(setSelectedPurchaseOrderCode(selectedSaleOrderCode)),
  setSelectedSaleOrderCode: selectedSaleOrderCode => dispatch(setSelectedSaleOrderCode(selectedSaleOrderCode)),
  setSelectedStockTransferCode: (selectedSaleOrderCode) => dispatch(setSelectedStockTransferCode(selectedSaleOrderCode)),
  getProductList: (id) => dispatch(getProductList(id)),
  getIngredientList: (params) => dispatch(getIngredientList(params)),
  setSelectedStockAdjustmentCode: (selectedSaleOrderCode) => dispatch(setSelectedStockAdjustmentCode(selectedSaleOrderCode)),
  setSelectedMfgOrderCode: selectedMfgOrderCode => dispatch(setSelectedMfgOrderCode(selectedMfgOrderCode)),
  setSelectedKitOrderCode: selectedKitOrderCode => dispatch(setSelectedKitOrderCode(selectedKitOrderCode)),
  setSelectedStockCountCode: selectedStockCountCOde => dispatch(setSelectedStockCountCode(selectedStockCountCOde)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageInventory);
