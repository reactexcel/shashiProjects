import * as inventoryConstant from './inventoryConstant';
import React from "react";
import { Nav, NavDropdown, MenuItem } from "react-bootstrap";
import StatusUtil from '../../common/util/statusUtil';
import CommonUtil from '../../common/util/commonUtil';
import isAuthorized from "auth-plugin";
import currencyIcon from '../../common/util/currencyIcon';
import moment from "moment";

export const MANAGE_INVENTORY_PRODUCT_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Product",
                id: "productId",
                accessor: "productId",
                style: {
                    flex: '0 0 25%',
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div //className="full-td label-black"
                            style={{ borderLeft: StatusUtil.getStockLabel(original.stocktype), marginLeft: '-6px', paddingLeft: '6px', borderRadius: '4px', height: 'calc(100% + 12px)', display: 'flex', alignItems: 'center'}}
                            id={original.productId + "_1" + index + "_" + original.stocktype}
                            title={original.productId ? ((original.isIngredient ? "ING-" : "PRO-") + original.productId + " | " + original.productName) : ''}
                            onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            {
                                <span >{original.productId ? ((original.isIngredient ? "ING-" : "PRO-")+ original.productId + " | " + original.productName) : ''} </span>
                            }
                        </div>
                    )
                }
            },
            {
                Header: "Category",
                id: "category",
                accessor: "category",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>{original.categoryLabel || CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.category)}</>
                    )
                }
            },
            {
                Header: "Facility",
                id: "facilityId",
                accessor: "facilityId",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>{CommonUtil.getSelectedOptionLabelForManagePage(that.state.facilityList, value)}</>
                    )
                }
            },
            {
                Header: "Sale Price" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")",
                id: "salesPrice",
                accessor: "salesPrice",
            },
            {
                Header: "In Stock",
                id: "stock",
                accessor: "stock",
                name: "stock",
                style: {
                    cursor: 'grab'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let stockValue = CommonUtil.getFloatValue(original.stock, 2)
                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span > {stockValue}  {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}</span>
                        </div>
                    )
                }
            },
            {
                Header: "Expected",
                id: "orderstock",
                accessor: "orderstock",
                style: {
                    cursor: 'grab'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let orderstockValue = CommonUtil.getFloatValue(original.orderstock, 2)
                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span >
                                {orderstockValue}  {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Committed",
                id: "committedstock",
                accessor: "committedstock",
                style: {
                    cursor: 'grab',
                    flex: '0 0 95px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let committedstockValue = CommonUtil.getFloatValue(original.committedstock, 2)
                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span >
                                {committedstockValue}  {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                            </span>
                        </div>
                    )
                }
            },
            {
                Header: "Missing/Surplus",
                id: "surplus",
                accessor: "surplus",
                style: {
                    flex: '0 0 130px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let surplusValue = CommonUtil.getFloatValue(original.stock, 2) + CommonUtil.getFloatValue(original.orderstock, 2) - CommonUtil.getFloatValue(original.committedstock, 2)
                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(surplusValue) }}>
                            {surplusValue}  {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                        </span>
                    )
                }
            },
            {
                Header: "Action",
                id: "actions",
                accessor: "actions",
                className: "action justify-content-center",
                disableSortBy: true,
                disableFilters: true,
                style: {
                    flex: '0 0 50px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (

                        <div className="actions-left">
                            {isAuthorized("newStockTransfer") &&
                                <Nav pullRight>
                                    <NavDropdown id={"PR0-"+original.productId + "_" + inventoryConstant.MENU_ACTION_MODE}
                                        title={<i className="fa fa-ellipsis-v"
                                            id={"PR0-"+original.productId + "_" + inventoryConstant.MENU_ACTION_MODE} />} noCaret>
                                        {isAuthorized("newStockTransfer") &&
                                            <MenuItem id={"PR0-"+original.productId + "_" + inventoryConstant.MENU_ACTION_MODE + "_" + inventoryConstant.STOCK_TRANSFER}
                                                onClick={(e) => that.getTdProps(e)}>Stock Transfer</MenuItem>}
                                    </NavDropdown>
                                </Nav>
                            }
                        </div>

                    )
                }
            }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: "Active"
                }
            ],
            defaultSortedList: [
                // {
                //     id: "productId",
                //     desc: false
                // }
            ],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const MANAGE_INVENTORY_INGREDIENT_PAGE_LIST = (that) => {
    return {
        tableColumnList: [
            {
                Header: "Ingredient",
                id: "productId",
                accessor: "productId",
                style: {
                    flex: '0 0 25%',
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <div //className="full-td label-black"
                            style={{ borderLeft: StatusUtil.getStockLabel(original.stocktype), marginLeft: '-6px', paddingLeft: '6px', borderRadius: '4px', height: 'calc(100% + 12px)', display: 'flex', alignItems: 'center'}}
                            id={original.productId + "_1" + index + "_" + original.stocktype}
                            title={original.productId ? ((original.isIngredient ? "ING-" : "PRO-") + original.productId + " | " + original.productName) : ''}
                            onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            {
                                <span >{original.productId ? ((original.isIngredient ? "ING-" : "PRO-")+ original.productId + " | " + original.productName) : ''} </span>
                            }
                        </div>
                    )
                }
            },
            {
                Header: "Category",
                id: "category",
                accessor: "category",
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>{CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.category)}</>
                    )
                }
            },
            {
                Header: "Facility",
                id: "facilityId",
                accessor: "facilityId",
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <>{CommonUtil.getSelectedOptionLabelForManagePage(that.state.facilityList, value)}</>
                    )
                }
            },
            {
                Header: "In Stock",
                id: "stock",
                accessor: "stock",
                name: "stock",
                style: {
                    cursor: 'grab'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let stockValue = CommonUtil.getFloatValue(original.stock, 2);

                    // stockValue = CommonUtil.getFloatValue(Number(original.stock) * Number(original.usgPackSizeQty),2);
                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span > {stockValue}  
                            {/* {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM)} */}
                            </span>
                        </div>
                    )
                }
            },
            {
                Header: "Expected",
                id: "orderstock",
                accessor: "orderstock",
                style: {
                    cursor: 'grab'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let orderstockValue = CommonUtil.getFloatValue(original.orderstock, 2);
                    // orderstockValue = CommonUtil.getFloatValue(Number(original.orderstock) * Number(original.usgPackSizeQty),2);

                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span >
                                {orderstockValue}  
                                {/* {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM)} */}
                            </span>
                        </div>

                    )
                }
            },
            {
                Header: "Committed",
                id: "committedstock",
                accessor: "committedstock",
                style: {
                    cursor: 'grab',
                    flex: '0 0 95px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let committedstockValue = CommonUtil.getFloatValue(original.committedstock, 2);
                    // committedstockValue = CommonUtil.getFloatValue(Number(original.committedstock) * Number(original.usgPackSizeQty),2);

                    return (
                        <div className="full-td label-black" id={original.productId + "_" + index + "_" + original.stocktype} onClick={() => that.openModalWindow(original.productId, original.stocktype, original.facilityId)}>
                            <span >
                                {committedstockValue}  
                                {/* {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM)} */}
                            </span>
                        </div>
                    )
                }
            },
            {
                Header: "Missing/Surplus",
                id: "surplus",
                accessor: "surplus",
                style: {
                    flex: '0 0 130px'
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let surplusValue = CommonUtil.getFloatValue(original.stock, 2) + CommonUtil.getFloatValue(original.orderstock, 2);
                    // surplusValue = CommonUtil.getFloatValue(Number(surplusValue) * Number(original.usgPackSizeQty),2);

                    surplusValue = surplusValue - CommonUtil.getFloatValue(original.committedstock, 2);


                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(surplusValue) }}>
                            {surplusValue}  
                            {/* {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.usgUOM)} */}
                        </span>
                    )
                }
            },
            // {
            //     Header: "Action",
            //     id: "actions",
            //     accessor: "actions",
            //     className: "action justify-content-center",
            //     disableSortBy: true,
            //     disableFilters: true,
            //     style: {
            //         flex: '0 0 50px'
            //     },
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (

            //             <div className="actions-left">
            //                 {isAuthorized("newStockTransfer") &&
            //                     <Nav pullRight>
            //                         <NavDropdown id={original.productId + "_" + inventoryConstant.MENU_ACTION_MODE}
            //                             title={<i className="fa fa-ellipsis-v"
            //                                 id={original.productId + "_" + inventoryConstant.MENU_ACTION_MODE} />} noCaret>
            //                             {isAuthorized("newStockTransfer") &&
            //                                 <MenuItem id={original.productId + "_" + inventoryConstant.MENU_ACTION_MODE + "_" + inventoryConstant.STOCK_TRANSFER}
            //                                     onClick={(e) => that.getTdProps(e)}>Stock Transfer</MenuItem>}
            //                         </NavDropdown>
            //                     </Nav>
            //                 }
            //             </div>

            //         )
            //     }
            // }
        ],
        tableConfig: {
            defaultFilteredList: [
                {
                    id: "status",
                    value: "Active"
                }
            ],
            defaultSortedList: [
                // {
                //     id: "productId",
                //     desc: false
                // }
            ],
            defaultPageSize: 50,
            showExport: false,
            customPagination: true,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: true,
            isDraggable: false,
        }
    }
};

export const DETAIL_MODAL_INSTOCK_TABLE_LIST = (that) => {
    return {
        tableData: [{
            createddate: '',
            ordernumber: '',
            remainingstock: '',
            perUnitPrice: '',
            blockedstock: '',
            totalQty: '',
            totalValue: '',
            uti: '',
            fac_location: ''
        }],
        tableColumnList: [
            {
                Header: "Date",
                id: "createddate",
                name: "createddate",
                accessor: "createddate",
                style: {
                    flex: "0 0 150px"
                },
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        // CommonUtil.getCurrentZoneFormatDate(value)
                        moment(new Date(value).toLocaleDateString('en-US')).format('MM-DD-YYYY')
                    )
                },
            },
            {
                Header: "Order#",
                id: "orderId",
                accessor: "orderId",
                name: "orderId",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                style: {
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div style={{ width: '100%' }} onClick={() => that.props.openOrderDetailsWindow(String((original.type || "") + "-").toUpperCase() + value)}>{
                            String((original.type || original.orderType || "") + "-").toUpperCase() + value
                        }</div>
                    )
                },
            },
            {
                Header: "In Stock Qty",
                id: "remainingstock",
                accessor: "remainingstock",
                name: "remainingstock",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let dispVal = CommonUtil.getFloatValue(original.remainingstock, true);
                    // let remainingstockValue = CommonUtil.getFloatValue(Number(dispVal) *  Number(original.usgPackSizeQty), true);

                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
                            {dispVal} {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                        </span>
                    )
                }
            },
            // {
            //     Header: "Price" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")",
            //     id: "perUnitPrice",
            //     accessor: "perUnitPrice",
            //     name: "perUnitPrice",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         var dispVal = CommonUtil.getFloatValue(original.perUnitPrice);
            //         let purchasePriceValue = CommonUtil.getFloatValue(dispVal, 2);
            //         return (
            //             <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
            //                 {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, purchasePriceValue)}
            //             </span>
            //         )
            //     }
            // },
            {
                Header: "Available Qty",
                id: "totalQty",
                accessor: "totalQty",
                name: "totalQty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let remaining = CommonUtil.getFloatValue(original.remainingstock);
                    let blocked = CommonUtil.getFloatValue(original.blockedstock);
                    let total = remaining - blocked;
                    // let totalQtyValue = CommonUtil.getFloatValue(Number(total) * Number(original.usgPackSizeQty), true);
                    let totalQtyValue = CommonUtil.getFloatValue(Number(total), true);

                    return (
                        <span style={{ color: StatusUtil.getNegativeColor(total) }}>
                            {totalQtyValue} {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                        </span>
                    )
                }
            },
            // {
            //     Header: "Total Value" + ' ' + "(" + currencyIcon.getCurrencyIcon(that.props.currencyCode) + ")",
            //     id: "totalValue",
            //     accessor: "totalValue",
            //     name: "totalValue",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let tempPurchasePrice = CommonUtil.getFloatValue(original.perUnitPrice);
            //         let received = CommonUtil.getFloatValue(original.remainingstock);
            //         let dispVal = received * tempPurchasePrice;
            //         let tempTotalValue = CommonUtil.getFloatValue(dispVal, 2);
            //         return (
            //             <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
            //                 {that.props.currencyCode && currencyIcon.getCurrencyDecimalFormat(that.props.currencyCode, tempTotalValue)}
            //             </span>
            //         )
            //     }
            // },
            // {
            //     Header: "UTI",
            //     id: "uti",
            //     accessor: "uti",
            //     name: "uti",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            // },
            // {
            //     Header: "Blocked Qty",
            //     id: "blockedstock",
            //     accessor: "blockedstock",
            //     name: "blockedstock",
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         let dispVal = CommonUtil.getFloatValue(original.blockedstock);
            //         let blockedstockValue = CommonUtil.getFloatValue(dispVal, 2);
            //         return (
            //             <span style={{ color: StatusUtil.getNegativeColor(dispVal) }}>
            //                 {blockedstockValue} {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
            //             </span>
            //         )
            //     }
            // },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{"FAC-" + original.facilityId + " | " + original.facilityName} </span>
                    )
                }

            },
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [
                {
                    id: "createddate",
                    desc: true,
                },
            ],
            defaultPageSize: 10000,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const DETAIL_MODAL_EXPECTED_TABLE_LIST = (that) => {
    return {
        tableData: [{
            createddate: '',
            ordernumber: '',
            qty: '',
            fac_location: ''
        }],
        tableColumnList: [
            // {
            //     Header: "Date",
            //     id: "createddate",
            //     name: "createddate",
            //     accessor: "createddate",
            //     style: {
            //         flex: "0 0 150px"
            //     },
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (
            //             CommonUtil.getCurrentZoneFormatDate(value)
            //         )
            //     },
            // },
            {
                Header: "Order#",
                id: "orderId",
                accessor: "orderId",
                name: "orderId",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                style: {
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div style={{ width: '100%' }} onClick={() => that.props.openOrderDetailsWindow(String((original.type || original.orderType || "") + "-").toUpperCase() + value)}>{
                            String((original.type || original.orderType || "") + "-").toUpperCase() + value
                        }</div>
                    )
                },
            },
            {
                Header: "Receiving Qty",
                id: "qty",
                accessor: "quantity",
                name: "qty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let qtyValue = CommonUtil.getFloatValue(value, 2);
                    // let qtyValue = CommonUtil.getFloatValue(Number(value) * Number(original.usgPackSizeQty), true);

                    return (
                        <span >
                            {qtyValue} {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                        </span>
                    )
                }
            },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{"FAC-" + original.facilityId + " | " + original.facilityName} </span>
                    )
                }

            }
        ],

        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [
                {
                    id: "createddate",
                    desc: true,
                },
            ],
            defaultPageSize: 10000,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const DETAIL_MODAL_CONSUMPTION_TABLE_LIST = (that) => {
    return {
        tableData: [{
            createddate: '',
            ordernumber: '',
            qty: '',
            fac_location: ''
        }],
        tableColumnList: [
            // {
            //     Header: "Date",
            //     id: "createddate",
            //     name: "createddate",
            //     accessor: "createddate",
            //     style: {
            //         flex: "0 0 150px"
            //     },
            //     createModeShowFlag: true,
            //     cloneModeShowFlag: true,
            //     editModeShowFlag: true,
            //     viewModeShowFlag: true,
            //     disableSortBy: true,
            //     disableFilters: true,
            //     Cell: ({ cell }) => {
            //         const { value } = cell;
            //         const { index, original } = cell.row;
            //         return (
            //             CommonUtil.getCurrentZoneFormatDate(value)
            //         )
            //     },
            // },
            {
                Header: "Order#",
                id: "ordernumber",
                accessor: "orderId",
                name: "ordernumber",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                style: {
                    cursor: 'grab',
                },
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    return (
                        <div style={{ width: '100%' }} onClick={() => that.props.openOrderDetailsWindow(String((original.type || original.orderType || "") + "-").toUpperCase() + value)}>{
                            String((original.type || original.orderType || "") + "-").toUpperCase() + value
                        }</div>
                    )
                },
            },
            {
                Header: "Reserved Qty",
                id: "qty",
                accessor: "quantity",
                name: "qty",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    const { value } = cell;
                    const { index, original } = cell.row;
                    let qtyValue = CommonUtil.getFloatValue(value, 2)
                    return (
                        <span >
                            {qtyValue} {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.uom)}
                        </span>
                    )
                }
            },
            {
                Header: "Location",
                id: "fac_location",
                name: "fac_location",
                accessor: "fac_location",
                createModeShowFlag: true,
                cloneModeShowFlag: true,
                editModeShowFlag: true,
                viewModeShowFlag: true,
                disableSortBy: true,
                disableFilters: true,
                Cell: ({ cell }) => {
                    var value = cell.value;
                    const { index, original } = cell.row;
                    return (
                        <span>{"FAC-" + original.facilityId + " | " + original.facilityName} </span>
                    )
                }

            }
        ],
        tableConfig: {
            defaultFilteredList: [],
            defaultSortedList: [
                {
                    id: "createddate",
                    desc: true,
                },
            ],
            defaultPageSize: 10000,
            showExport: false,
            customPagination: false,
            showServerSideFilter: false,
            isFilterEnabed: false,
            showPagination: false,
            showAddRow: false,
            isDraggable: false,
        },
    };
};
export const INVENTORY_MODAL_DETAIL_LIST = (that) => ({
    attributeObj: {
        stock: "",
        orderstock: "",
        committedstock: "",
        forecast: "",
        surplus: "",
        uom: "",
    },
    attributeList: [
        {
            name: "stock",
            type: "FIXED",
            label: "In Stock",
            required: false,
            inputType: "text",
            fieldWidth: "5ths",
            numberOfRow: 0,
        },
        {
            name: "orderstock",
            type: "FIXED",
            label: "Expected",
            required: false,
            inputType: "text",
            fieldWidth: "5ths",
            numberOfRow: 0,
        },
        {
            name: "committedstock",
            type: "FIXED",
            label: "Committed",
            required: false,
            inputType: "text",
            fieldWidth: "5ths",
            numberOfRow: 0,
        },
        // {
        //     name: "forecast",
        //     type: "FIXED",
        //     label: "Forecast",
        //     required: false,
        //     inputType: "text",
        //     fieldWidth: "5ths",
        //     numberOfRow: 0,
        // },
        {
            name: "surplus",
            type: "FIXED",
            label: "Missing/Surplus",
            required: false,
            inputType: "text",
            fieldWidth: "5ths",
            numberOfRow: 0,
        },
    ],
});
export const ADVANCE_SEARCH_LIST = (that) => {
    return {
        attributeObj: {
            orderNumber: '',
        },
        attributeList: [
            {
                name: "orderNumber",
                type: "TEXTBOX",
                label: "",
                inputType: "text",
                fieldWidth: 12,
                numberOfRow: 0,
                placeholder: "Search by Product/Ingredient",
            },
        ],
    }
};