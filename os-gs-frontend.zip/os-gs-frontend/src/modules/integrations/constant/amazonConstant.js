import * as commonConstant from "../../common/constant/commonConstant";

export const CREATE_AMAZON_FACILITY = {
    "facilityType": "E-Commerce",
    "facilityName": "Amazon Location",
    "status": "active",
    "locations": [
        {
            "locationName": "Amazon Default Location",
            "address": "Amazon Default Location",
            "country": "United States",
            "state": "New York",
            "city": "New York",
            "zipcode": "123456"
        }
    ],
    "documents": [],
    "manufacturing": false,
    "storage": true,
    "sale": false,
    "source": false,
    "sourceChannel": commonConstant.AMAZON
};

export const AMAZON_MESSAGE_LIST = [
    {
        key: "ALL_CUSTOMERS",
        message: "All Customers"
    },
    {
        key: "ALL_PRODUCTS",
        message: "All Products"
    },
    {
        key: "ALL_ORDERS",
        message: "All Open orders"
    }
];

export const AMAZON_COUNTRY_LIST = [
    { label: "United States of America", value: "ATVPDKIKX0DER" },
    { label: "Canada", value: "ATVPDKIKX0DER" },
    { label: "Mexico", value: "ATVPDKIKX0DER" },
    { label: "Spain", value: "ATVPDKIKX0DER" },
    { label: "United Kingdom", value: "ATVPDKIKX0DER" },
    { label: "France", value: "ATVPDKIKX0DER" },
    { label: "Netherlands", value: "ATVPDKIKX0DER" },
    { label: "Germany", value: "ATVPDKIKX0DER" },
    { label: "Italy", value: "ATVPDKIKX0DER" },
    { label: "Sweden", value: "ATVPDKIKX0DER" },
    { label: "Poland", value: "ATVPDKIKX0DER" },
    { label: "Egypt", value: "ATVPDKIKX0DER" },
    { label: "Turkey", value: "ATVPDKIKX0DER" },
    { label: "United Arab Emirates", value: "ATVPDKIKX0DER" },
    { label: "India", value: "ATVPDKIKX0DER" },
    { label: "Singapore", value: "ATVPDKIKX0DER" },
    { label: "Australia", value: "ATVPDKIKX0DER" },
    { label: "Japan", value: "ATVPDKIKX0DER" }
];

export const AMAZON_MARKETPLACE_URL_LIST = [
    {
        countryName: "United States of America",
        countryCode: "US",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.com"
    },
    {
        countryName: "Canada",
        countryCode: "CA",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.ca"
    },
    {
        countryName: "Mexico",
        countryCode: "MX",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.com.mx"
    },
    {
        countryName: "Brazil",
        countryCode: "BR",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.com.br"
    },
    {
        countryName: "Spain",
        countryCode: "ES",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral-europe.amazon.com"
    },
    {
        countryName: "United Kingdom",
        countryCode: "GB",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral-europe.amazon.com"
    },
    {
        countryName: "France",
        countryCode: "FR",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral-europe.amazon.com"
    },
    {
        countryName: "Netherlands",
        countryCode: "NL",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.nl"
    },
    {
        countryName: "Germany",
        countryCode: "DE",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral-europe.amazon.com"
    },
    {
        countryName: "Italy",
        countryCode: "IT",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral-europe.amazon.com"
    },
    {
        countryName: "Sweden",
        countryCode: "SE",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.se"
    },
    {
        countryName: "Poland",
        countryCode: "PL",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.pl"
    },
    {
        countryName: "Turkey",
        countryCode: "TR",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.com.tr"
    },
    {
        countryName: "United Arab Emirates",
        countryCode: "AE",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.ae"
    },
    {
        countryName: "India",
        countryCode: "IN",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.in"
    },
    {
        countryName: "Singapore",
        countryCode: "SG",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.sg"
    },
    {
        countryName: "Australia",
        countryCode: "AU",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.com.au"
    },
    {
        countryName: "Japan",
        countryCode: "JP",
        marketPlaceId: "ATVPDKIKX0DER",
        marketPlaceURL: "https://sellercentral.amazon.co.jp"
    }
];