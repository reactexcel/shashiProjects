import * as commonConstant from "../../common/constant/commonConstant";

export const CREATE_SHOPIFY_FACILITY = {
    "facilityType": "E-Commerce",
    "facilityName": "Shopify Location",
    "status": "active",
    "locations": [
        {
            "locationName": "Shopify Default Location",
            "address": "Shopify Default Location",
            "country": "United States",
            "state": "New York",
            "city": "New York",
            "zipcode": "123456"
        }
    ],
    "documents": [],
    "manufacturing": false,
    "storage": true,
    "sale": false,
    "source": false,
    "sourceChannel": commonConstant.SHOPIFY
};
