import React from "react";
import { FormControl, InputGroup } from "react-bootstrap";
import CommonUtil from "../../common/util/commonUtil";
import Select from "react-select";
import * as integrationConstant from './integrationConstant';
import * as amazonConstant from './amazonConstant';

export const AMAZON_REGION_PAGE_LIST = (that) => {
  return {
    attributeObj: {
      regionCode: '',
      marketPlaceId: '',
    },
    attributeList: [
      {
        name: "marketPlaceId",
        type: "DROPDOWN",
        label: "Select Market Place Location",
        required: true,
        fieldWidth: 6,
        createMode: 'enable',
        cloneMode: 'enable',
        editMode: 'enable',
        viewMode: 'disabled',
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        numberOfRow: 0,
        mandatoryMsgText: "Field can not be empty.",
        options:amazonConstant.AMAZON_COUNTRY_LIST,
      },
    ],
  }
};

export const TAX_TABLE_LIST = (that) => {
  return {
    tableData: [
    ],
    tableColumnList: [
      {
        Header: "Originscale Tax",
        id: "osTax",
        accessor: "osTax",
        name: "osTax",
        required: false,
        inputType: "number",
        disableSortBy: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <FormControl
              id={"osTax" + "_" + index}
              data-type={'number'}
              onPaste={(e) => { e.preventDefault(); return false }}
              name={"osTax"}
              onChange={that.handleTableTextBoxChange}
              disabled={true}
              value={CommonUtil.isNaNValue(parseFloat(original.osTaxId))} />
          );
        },
      },
      {
        Header: "Quickbooks Tax Type",
        id: "qboTaxId",
        accessor: "qboTaxId",
        name: "qboTaxId",
        inputType: "float",
        required: true,
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        dataDictionaryFlag: true,
        dataDictionaryId: 'taxList',
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <Select id={'qboTaxId' + '_' + index}
              name={"qboTaxId" + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.state.qboTaxList}
              classNamePrefix="react-select"
              placeholder=""
              value={{ "label": original.qboTaxIdlabel }}
            />
          )
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    },
  };
};


