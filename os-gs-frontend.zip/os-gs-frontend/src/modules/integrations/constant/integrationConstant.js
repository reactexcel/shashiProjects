export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_QUICKBOOK_URL = `${BASE_URL}/qbo/qboconnecturi`;
export const CREATETOKEN_URL = `${BASE_URL}/qbo/qboCreateToken`;
export const GET_QUICKBOOK_ACCOUNT_URL = `${BASE_URL}/qbo/getQBOAccounts`;
export const SET_QUICKBOOK_ACCOUNT_SETTING_URL = `${BASE_URL}/qbo/saveQBOAccountSettings`;
export const SET_QUICKBOOK_CUSTOMER_SYNC_URL = `${BASE_URL}/qbo/qboCustomerDataSync`;
export const SET_QUICKBOOK_VENDOR_SYNC_URL = `${BASE_URL}/qbo/qboVendorDataSync`;
export const GET_QUICKBOOK_TAX_CODE_URL = `${BASE_URL}/qbo/getTaxCodes`;
export const REVOKE_QUICKBOOK_ACCOUNT_URL = `${BASE_URL}/qbo/revokeAccess`;
export const SET_QUICKBOOK_TAX_URL = `${BASE_URL}/qbo/saveQBOTaxMapping`;
export const GET_SHOPIFY_ACCOUNT_URL = `${BASE_URL}/shopify/getQBOAccounts`;

export const GET_SHOPIFY_ACCESS_TOKEN_URL = `${BASE_URL}/shopify/getShopifyAccessToken`;
export const GET_SHOPIFY_WEBHOOK_REGISTRATION_URL = `${BASE_URL}/shopify/webhooksShopifyRegistration`;
export const GET_SHOPIFY_DISCONNECT_URL = `${BASE_URL}/shopify/disconnectShopify`;
export const GET_SHOPIFY_CUSTOMERS_URL = `${BASE_URL}/shopify/getShopifyCustomers`;
export const GET_SHOPIFY_PRODUCTS_URL = `${BASE_URL}/shopify/getShopifyProducts`;
export const GET_SHOPIFY_ORDERS_URL = `${BASE_URL}/shopify/getShopifyOrders`;
export const GET_SHOPIFY_API_KEY_URL = `${BASE_URL}/shopify/getShopifyApiKey`;
export const GET_SHOPIFY_LOCATIONS_URL = `${BASE_URL}/shopify/getShopifyLocations`;
export const SET_SHOPIFY_LOCATIONS_URL = `${BASE_URL}/shopify/setShopifyDefaultFacility`;

export const GET_AMAZON_REFRESH_TOKEN_URL = `https://api.amazon.com/auth/o2/token`;
export const GET_AMAZON_ACCESS_TOKEN_URL = `${BASE_URL}/amazon/getAccessToken`;
export const GET_AMAZON_WEBHOOK_REGISTRATION_URL = `${BASE_URL}/amazon/appRegistration`;
export const GET_AMAZON_DISCONNECT_URL = `${BASE_URL}/amazon/disconnectAccount`;
export const GET_AMAZON_CUSTOMERS_URL = `${BASE_URL}/amazon/getCustomers`;
export const GET_AMAZON_PRODUCTS_URL = `${BASE_URL}/amazon/getProducts`;
export const GET_AMAZON_ORDERS_URL = `${BASE_URL}/amazon/getOrders`;
export const GET_AMAZON_APP_KEY_URL = `${BASE_URL}/amazon/getAppKey`;
export const GET_AMAZON_LOCATIONS_URL = `${BASE_URL}/amazon/getLocations`;
export const SET_AMAZON_LOCATIONS_URL = `${BASE_URL}/amazon/setDefaultFacility`;

export const GET_WOOCOM_ACCESS_TOKEN_URL = `${BASE_URL}/woocom/getWooComAccessToken`;
export const GET_WOOCOM_WEBHOOK_REGISTRATION_URL = `${BASE_URL}/woocom/webhooksWooComRegistration`;
export const GET_WOOCOM_DISCONNECT_URL = `${BASE_URL}/woocom/disconnectWooCom`;
export const GET_WOOCOM_CUSTOMERS_URL = `${BASE_URL}/woocom/getWooComCustomers`;
export const GET_WOOCOM_PRODUCTS_URL = `${BASE_URL}/woocom/getWooComProducts`;
export const GET_WOOCOM_ORDERS_URL = `${BASE_URL}/woocom/getWooComOrders`;
export const GET_WOOCOM_API_KEY_URL = `${BASE_URL}/woocom/getWooComApiKey`;
export const GET_WOOCOM_LOCATIONS_URL = `${BASE_URL}/woocom/getWooComLocations`;
export const SET_WOOCOM_LOCATIONS_URL = `${BASE_URL}/woocom/setWooComDefaultFacility`;

export const SHOPIFY_MESSAGE_LIST = [
    {
        key: "ALL_CUSTOMERS",
        message: "All Customers"
    },
    {
        key: "ALL_PRODUCTS",
        message: "All Products"
    },
    {
        key: "ALL_ORDERS",
        message: "All Open orders"
    }
];


