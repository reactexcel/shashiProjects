import * as commonConstant from "../../common/constant/commonConstant";

export const CREATE_WOOCOM_FACILITY = {
    "facilityType": "E-Commerce",
    "facilityName": "WooCommerce Location",
    "status": "active",
    "locations": [
        {
            "locationName": "WooCommerce Default Location",
            "address": "WooCommerce Default Location",
            "country": "United States",
            "state": "New York",
            "city": "New York",
            "zipcode": "123456"
        }
    ],
    "documents": [],
    "manufacturing": false,
    "storage": true,
    "sale": false,
    "source": false,
    "sourceChannel": commonConstant.WOOCOM
};

export const WOOCOM_MESSAGE_LIST = [
    {
        key: "ALL_CUSTOMERS",
        message: "All Customers"
    },
    {
        key: "ALL_PRODUCTS",
        message: "All Products"
    },
    {
        key: "ALL_ORDERS",
        message: "All Open orders"
    }
];
