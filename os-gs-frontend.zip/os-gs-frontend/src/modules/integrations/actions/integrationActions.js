import axios from '../../../axios/axios';
import * as integrationActionTypes from './integrationActionTypes';
import * as integrationConstant from '../constant/integrationConstant';
import * as actionTypes from '../../../actions/actionTypes';
import {
	beginAjaxCall, endAjaxCall, setAjaxCallStatus
} from "../../../actions/ajaxStatusActions";

export const authorizeStore = (storeDetails) => {
	console.log('store details');
};

export const connectToStore = (data) => {
	console.log('data ==>', data);
};

export function getQuickBookUrl() {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.get(integrationConstant.GET_QUICKBOOK_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.GET_QUICKBOOK_URI,
					payload: response.data
				});
				dispatch(setAjaxCallStatus(actionTypes.API_SUCCESS_RESPONSE));
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
			dispatch(endAjaxCall());
		});
	};
}
export function createQboToken(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.CREATETOKEN_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.CREATETOKEN,
					payload: response.data.Attributes
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}
export function quickbookAccount() {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.get(integrationConstant.GET_QUICKBOOK_ACCOUNT_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.GET_QUICKBOOK_ACCOUNT,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}
export function saveQuickbookSetting(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.SET_QUICKBOOK_ACCOUNT_SETTING_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_QUICKBOOK_ACCOUNT_SETTING,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}
export function syncQuickbookCustomer(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.SET_QUICKBOOK_CUSTOMER_SYNC_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_QUICKBOOK_CUSTOMER_SYNC,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}

export function syncQuickbookVendor(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.SET_QUICKBOOK_VENDOR_SYNC_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_QUICKBOOK_VENDOR_SYNC,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}

export function getQuickbookTaxCode() {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.get(integrationConstant.GET_QUICKBOOK_TAX_CODE_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.GET_QUICKBOOK_TAX_CODE,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}

export function revokeQuickbook() {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.get(integrationConstant.REVOKE_QUICKBOOK_ACCOUNT_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.REVOKE_QUICKBOOK_ACCOUNT,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}

export function setQuickbookTax(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.SET_QUICKBOOK_TAX_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_QUICKBOOK_TAX,
					payload: response.data
				});
			}
			dispatch(endAjaxCall());
		}).catch((error) => {
			dispatch(endAjaxCall());
		});
	};
}

/////////////////////////////// Shopify ///////////////////////////////////////////////
export function getShopifyAuthorizeUrl(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.GET_SHOPIFY_API_KEY_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.GET_SHOPIFYKEY_URL,
					payload: response.data
				});
			}
		});
		dispatch(endAjaxCall());
	};
}

export function saveShopifyProduct(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.GET_SHOPIFY_PRODUCTS_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_SHOPIFY_PRODUCT,
					payload: response.data
				});
			}
		});
		dispatch(endAjaxCall());
	};
}

export function getAmazonAppKey(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.GET_AMAZON_APP_KEY_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_AMAZON_APP_KEY,
					payload: response.data
				});
			}
		});
		dispatch(endAjaxCall());
	};
}

export function getAmazonRefreshToken(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.GET_AMAZON_REFRESH_TOKEN_URL, params).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_AMAZON_REFRESH_TOKEN,
					payload: response.data
				});
			}
		});
		dispatch(endAjaxCall());
	};
}


export function getWoocomAccessToken(params) {
	return function (dispatch) {
		dispatch(beginAjaxCall());
		axios.post(integrationConstant.GET_WOOCOM_ACCESS_TOKEN_URL).then(response => {
			if (response.status == 200) {
				dispatch({
					type: integrationActionTypes.SET_WOOCOM_ACCESS_TOKEN,
					payload: response.data
				});
			}
		});
		dispatch(endAjaxCall());
	};
}
