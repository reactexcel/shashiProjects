import React, { useState } from 'react';
import { Grid, Row, Col, FormGroup, ControlLabel, FormControl } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import Checkbox from '../../../../components/CustomCheckbox/CustomCheckbox';
import ReadMore from './ReadMore';
import CheckboxLabel from './CheckboxLabel';

const DataImportSettingsView = (props) => {
  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <div className="highlighter">Data import during first-time connect.</div>
                <p>
                  Originscale will now import all open orders, all customers & all products with their stock levels
                  & prices from Shopify. If you would like to import only all customers & products, then opt out
                  the options below.
                </p>
                <Row>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                        checked={props.importAllCustomers}
                        onClick={(e) => {
                          if (e.target.checked) {
                            props.setPropsImportAllCustomers(e.target.checked);
                          }
                          else {
                            if (!props.importAllOrders) {
                              props.setPropsImportAllCustomers(e.target.checked);
                            }
                          }
                        }}
                      />
                      <CheckboxLabel>Yes, import all customers. <ReadMore />
                      </CheckboxLabel>

                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                        checked={props.importAllProducts}
                        onClick={(e) => {
                          if (e.target.checked) {
                            props.setPropsImportAllProducts(e.target.checked);
                          }
                          else {
                            if (!props.importAllOrders) {
                              props.setPropsImportAllProducts(e.target.checked);
                            }
                          }
                        }}
                      />
                      <CheckboxLabel>Yes, import all products with their stock levels. <ReadMore /></CheckboxLabel>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                        checked={props.importAllOrders}
                        onClick={(e) => {
                          props.setPropsImportAllOrders(e.target.checked);
                          props.setPropsImportAllCustomers(e.target.checked);
                          props.setPropsImportAllProducts(e.target.checked);
                        }}
                      />
                      <CheckboxLabel>Yes, import all open orders. <ReadMore />
                      </CheckboxLabel>
                    </div>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                {!props.isAppOnlyRegistered ?
                  <Button className="btn-cancel" onClick={() => props.updateStep(1)}>Previous</Button> : null}
                <Button className="btn-save btn-fill btn btn-default" onClick={() => { props.updateStep(3) }}>Next</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  )
};

export default DataImportSettingsView;
