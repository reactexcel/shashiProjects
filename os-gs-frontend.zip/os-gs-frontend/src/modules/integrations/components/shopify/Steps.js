import React, { useState, useCallback } from 'react';
import { Badge } from 'react-bootstrap';
import StoreView from './StoreView';
import DataImportSettingsView from './DataImportSettingsView';
import ConnectView from './ConnectView';
import ConnectDoneView from './ConnectDoneView';
import MapFacility from './MapFacility';

const Steps = (props) => {
  const [address, setAddress] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [step, setStep] = useState(1);
  const [importAllCustomers, setImportAllCustomers] = useState(false);
  const [importAllProducts, setImportAllProducts] = useState(false);
  const [importAllOrders, setImportAllOrders] = useState(false);
  const updateStep = useCallback((step) => setStep(step), []);
  const setShopAddress = useCallback((address) => setAddress(address), []);
  const setPropsImportAllCustomers = useCallback((value) => setImportAllCustomers(value), []);
  const setPropsImportAllProducts = useCallback((value) => setImportAllProducts(value), []);
  const setPropsImportAllOrders = useCallback((value) => setImportAllOrders(value), []);

  const renderStepView = useCallback(() => {
    if (step === 1) {
      if (props.syncShopify) {
        return <ConnectDoneView closeModal={props.closeModal} importAllProducts={props.importProducts} importAllCustomers={props.importCustomers} importAllOrders={props.importOrders} address={props.shop} />
      } else {
        return <StoreView closeModal={props.closeModal} updateStep={updateStep} setShopAddress={setShopAddress}
          setApiKey={setApiKey} isAppOnlyRegistered={props.isAppOnlyRegistered} address={props.shop} />
      }
    } else if (step === 2) {
      return <DataImportSettingsView updateStep={updateStep} setPropsImportAllCustomers={setPropsImportAllCustomers}
        setPropsImportAllProducts={setPropsImportAllProducts} setPropsImportAllOrders={setPropsImportAllOrders}
        importAllProducts={importAllProducts} importAllCustomers={importAllCustomers} importAllOrders={importAllOrders}
        apiKey={apiKey} address={address} isAppOnlyRegistered={props.isAppOnlyRegistered} />
    } else if (step === 3) {
      return <ConnectView closeModal={props.closeModal} updateStep={updateStep}
        importAllProducts={importAllProducts} importAllCustomers={importAllCustomers}
        importAllOrders={importAllOrders} apiKey={apiKey} address={address} />
    } else if (step === 4) {
      return <MapFacility closeModal={props.closeModal} updateStep={updateStep} importAllProducts={importAllProducts}
        importAllCustomers={importAllCustomers} importAllOrders={importAllOrders} apiKey={apiKey} address={address} />
    } else if (step === 5) {
      return <ConnectDoneView closeModal={props.closeModal} updateStep={updateStep} importAllProducts={importAllProducts}
        importAllCustomers={importAllCustomers} importAllOrders={importAllOrders}
        address={address} />
    }
  }, [step, importAllProducts, importAllCustomers, importAllOrders]);

  var shopName = props.shop.split(".")[0];

  return (
    <>
      <div className="steps-nav">
        <div className="steps"><Badge className={step === 1 ? props.syncShopify ? 'fill-badge' : 'active-badge' : 'fill-badge'}>1</Badge> <span className={step >= 1 ? 'active-step' : null}>{props.shop ? 
        shopName : "Your Store"}</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncShopify ? 'fill-badge' : null : step === 2 ? 'active-badge' : step > 2 ? 'fill-badge' : null}>2</Badge> <span className={step >= 2 ? 'active-step' : null}>Initial data import settings</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncShopify ? 'fill-badge' : null : step === 3 ? 'active-badge' : step > 3 ? 'fill-badge' : null}>3</Badge> <span className={step >= 3 ? 'active-step' : null}>Connect</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncShopify ? 'active-badge' : null : step === 4 ? 'active-badge' : null}>4</Badge> <span className={step === 4 ? 'active-step' : null}>Map Facility</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncShopify ? 'active-badge' : null : step === 5 ? 'active-badge' : null}>4</Badge> <span className={step === 5 ? 'active-step' : null}>Done</span></div>
      </div>
      {renderStepView()}
    </>
  );
};

export default Steps;
