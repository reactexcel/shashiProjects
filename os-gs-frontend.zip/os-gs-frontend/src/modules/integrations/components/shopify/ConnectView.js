import React from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import OAuth2Login from 'react-simple-oauth2-login';
import axios from '../../../../axios/axios';
import * as constants from '../../constant/integrationConstant';

const getShopifyMessage = (key) => {
  let filteredList = constants.SHOPIFY_MESSAGE_LIST.filter(function (tempObj) {
    return tempObj.key === key;
  });
  if (filteredList.length > 0) {
    return filteredList[0].message;
  }
}

const ConnectView = (props) => {
  console.log("ConnectView props", props);
  const shop = props.address;
  const appScope = [
    "read_products",
    "write_products",
    "read_draft_orders",
    "write_draft_orders",
    "read_orders",
    "read_inventory",
    "write_inventory",
    "write_orders",
    "read_customers",
    "write_customers"
  ];
  const onSuccess = (response) => {
    console.log("Code:", response.code);
    let accessTokenPayload = {
      code: response.code,
      shop: shop,
      importProducts: props.importAllProducts,
      importCustomers: props.importAllCustomers,
      importOrders: props.importAllOrders
    };

    axios.post(constants.GET_SHOPIFY_ACCESS_TOKEN_URL, accessTokenPayload).
      then(tokenResponse => {
        axios.post(constants.GET_SHOPIFY_WEBHOOK_REGISTRATION_URL,
          {
            shop: shop
          }).
          then(webhookResponse => {
            console.log("Webhook registration response", webhookResponse);
            if (props.importAllProducts || props.importAllCustomers || props.importAllOrders) {
              axios.post(constants.GET_SHOPIFY_LOCATIONS_URL,
                {
                  shop: shop
                }).
                then(response => {
                  props.updateStep(4);
                }).catch(error => {
                  console.log(error);
                });
            } else {
              props.closeModal();
            }
          }
          ).catch(error => {
            console.log(error);
          });

      }).catch(error => {
        console.log(error);
      });
  };
  const onFailure = response => console.error(response);
  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <Row>
                  <Col md={12}>
                    <div className="highlighter">First-time connect import:</div>
                    <div className="import-options">
                      {props.importAllOrders ? <div className="option-item">{getShopifyMessage('ALL_ORDERS')}</div> : null}
                      {props.importAllProducts ? <div className="option-item">{getShopifyMessage('ALL_PRODUCTS')}</div> : null}
                      {props.importAllCustomers ? <div className="option-item">{getShopifyMessage('ALL_CUSTOMERS')}</div> : null}
                    </div>
                    <div className="highlighter">Import data going forward</div>
                    <p>
                      After this import, you can continue to import open orders &amp; associated customers &amp; products from your store to Originscale by clicking on SYNC button on integration page.
                    </p>
                    <p>
                      However, we will synchronize the order fulfillment state between Originscale &amp; Shopify automatically.
                    </p>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-cancel" onClick={() => props.updateStep(2)}>Previous</Button>
                <OAuth2Login
                  authorizationUrl={`https://${shop}/admin/oauth/authorize`}
                  responseType="code"
                  clientId={props.apiKey}
                  redirectUri={window.parent.location.href}
                  className="btn-save btn-fill btn btn-default"
                  buttonText="Ok, connect my store"
                  scope={appScope}
                  onSuccess={onSuccess}
                  onFailure={onFailure} />
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  );
};

export default ConnectView;
