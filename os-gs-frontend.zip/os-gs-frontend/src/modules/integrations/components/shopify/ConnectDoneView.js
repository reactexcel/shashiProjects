import React, { useState, useEffect } from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import axios from '../../../../axios/axios';
import * as constants from '../../constant/integrationConstant';

const getShopifyMessage = (key) => {
  let filteredList = constants.SHOPIFY_MESSAGE_LIST.filter(function (tempObj) {
    return tempObj.key === key;
  });
  if (filteredList.length > 0) {
    return filteredList[0].message;
  }
}

const ConnectDoneView = (props) => {
  const [importAllCustomersStatus, setImportAllCustomersStatus] = useState('');
  const [importAllProductsStatus, setImportAllProductsStatus] = useState('');
  const [importAllOrdersStatus, setImportAllOrdersStatus] = useState('');
  const [done, setDone] = useState(false);
  const shop = props.address;

  function getShopifyData(shop) {
    let requestBody = { "shop": shop };
    axios.post(constants.GET_SHOPIFY_PRODUCTS_URL, requestBody, { timeout: 29000 }).then(response => {
      setImportAllProductsStatus('success');
      axios.post(constants.GET_SHOPIFY_CUSTOMERS_URL, requestBody).then(response => {
        setImportAllCustomersStatus('success');
        getShopifyOrders(requestBody);
      }).catch(error => {
        setImportAllCustomersStatus('error');
      });
    }).catch(error => {
      if (error.code == "ECONNABORTED") {
        setTimeout(() => getShopifyData(shop), 2000);
      } else {
        setImportAllProductsStatus('error');
        setImportAllCustomersStatus('error');
        setImportAllOrdersStatus('error');
        setDone(true);
      }
    });
  }

  function getShopifyOrders(requestBody) {
    axios.post(constants.GET_SHOPIFY_ORDERS_URL, requestBody, { timeout: 29000 }).then(response => {
      setDone(true);
      setImportAllOrdersStatus('success');
    }).catch(error => {
      if (error.code == "ECONNABORTED") {
        setTimeout(() => getShopifyOrders(requestBody), 2000);
      }
      setImportAllOrdersStatus('error');
    });
  }

  useEffect(() => {
    if (props.importAllOrders) {
      getShopifyData(shop);
    } else {
      if (props.importAllCustomers) {
        axios.post(constants.GET_SHOPIFY_CUSTOMERS_URL, { "shop": shop }).then(response => {
          setImportAllCustomersStatus('success');
          setDone(true);
        }).catch(error => {
          setImportAllCustomersStatus('error');
        });
      }
      if (props.importAllProducts) {
        axios.post(constants.GET_SHOPIFY_PRODUCTS_URL, { "shop": shop }).then(response => {
          setImportAllProductsStatus('success');
          setDone(true);
        }).catch(error => {
          setImportAllProductsStatus('error');
        });
      }
    }
  }, []);

  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <Row>
                  <Col md={12}>
                    <div>We are importing the requested data from Shopify. Please wait for a while, it may take few seconds.
                      </div>
                    <br /><br />
                    <div className="import-options">
                      {props.importAllOrders ?
                        <div className="option-item">
                          <i
                            className={importAllOrdersStatus == '' ? 'fa fa-spin fa-spinner' : importAllOrdersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getShopifyMessage('ALL_ORDERS')}
                        </div> : null}
                      {props.importAllProducts ?
                        <div className="option-item">
                          <i
                            className={importAllProductsStatus == '' ? 'fa fa-spin fa-spinner' : importAllProductsStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getShopifyMessage('ALL_PRODUCTS')}
                        </div> : null}
                      {props.importAllCustomers ?
                        <div className="option-item">
                          <i
                            className={importAllCustomersStatus == '' ? 'fa fa-spin fa-spinner' : importAllCustomersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getShopifyMessage('ALL_CUSTOMERS')}
                        </div> : null}
                    </div>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className={done ? "btn-save btn-fill btn btn-default" : "disabled"} onClick={() => { props.closeModal() }}>Done</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  );
};

export default ConnectDoneView;
