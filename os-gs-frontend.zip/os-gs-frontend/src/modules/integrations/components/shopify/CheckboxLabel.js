import React from 'react';

const CheckboxLabel = ( props ) => <div className="shopify-label">{props.children}</div>;

export default CheckboxLabel;
