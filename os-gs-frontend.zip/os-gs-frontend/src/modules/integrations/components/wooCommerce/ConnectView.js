import React from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import axios from '../../../../axios/axios';
import * as constants from '../../constant/integrationConstant';
import * as wooCommerceConstant from '../../constant/wooCommerceConstant';
import Checkbox from '../../../../components/CustomCheckbox/CustomCheckbox';
import ReadMore from './ReadMore';
import CheckboxLabel from './CheckboxLabel';

const getWooCommerceMessage = (key) => {
  let filteredList = wooCommerceConstant.WOOCOM_MESSAGE_LIST.filter(function (tempObj) {
    return tempObj.key === key;
  });
  if (filteredList.length > 0) {
    return filteredList[0].message;
  }
}

const ConnectView = (props) => {
  console.log("ConnectView props", props);
  const shop = props.address;

  const registerShop = () => {
    let accessTokenPayload = {
      shop: shop,
      importCustomers: props.importAllCustomers,
      importOrders: props.importAllOrders
    };

    axios.post(constants.GET_WOOCOM_ACCESS_TOKEN_URL, accessTokenPayload).then(tokenResponse => {
      if (props.importAllCustomers || props.importAllOrders) {
        props.updateStep(4);
      } else {
        props.closeModal();
      }
    }).catch(error => {
      console.log(error);
    });
  };
  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <Row>
                  <Col md={12}>
                    <div className="highlighter">Order sync going forward.</div>
                    <p>
                      After this import, we will continue to import orders with processing status &amp; associated customers from your store into Originscale in real time when ever a new order is created in WooCommerce.
                    </p>
                    <div className="import-options">
                      {props.importAllOrders ? <div className="option-item">{getWooCommerceMessage('ALL_ORDERS')}</div> : null}
                      {props.importAllCustomers ? <div className="option-item">{getWooCommerceMessage('ALL_CUSTOMERS')}</div> : null}
                    </div>
                    <div className="highlighter">Order fulfillment &amp; inventory sync going forward.</div>
                    <p>
                      We will synchronize order fulfillment state and WooCommerce in real time. If you don't want this, then you can opt out below.
                    </p>
                  </Col>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                      />
                      <CheckboxLabel>Yes, automatically synchronize order fulfillment state between originscale and WooCommerce. <ReadMore />
                      </CheckboxLabel>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                      />
                      <CheckboxLabel>Commitments from order created in originscale reduce the availability if stock in WooCommerce <ReadMore />
                      </CheckboxLabel>
                    </div>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-cancel" onClick={() => props.updateStep(2)}>Previous</Button>
                <Button className="btn-save btn-fill btn btn-default" onClick={registerShop}>Next</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  );
};

export default ConnectView;
