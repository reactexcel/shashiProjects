import React from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import Checkbox from '../../../../components/CustomCheckbox/CustomCheckbox';
import ReadMore from './ReadMore';
import CheckboxLabel from './CheckboxLabel';

const DataImportSettingsView = (props) => {
  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <div className="highlighter">Data import during first-time connect.</div>
                <p>
                  Originscale will now import all open orders & all customers from WooCommerce.
                </p>
                <Row>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                        checked={props.importAllCustomers}
                        onClick={(e) => {
                          if (e.target.checked) {
                            props.setPropsImportAllCustomers(e.target.checked);
                          }
                          else {
                            if (!props.importAllOrders) {
                              props.setPropsImportAllCustomers(e.target.checked);
                            }
                          }
                        }}
                      />
                      <CheckboxLabel>Yes, import all customers. <ReadMore />
                      </CheckboxLabel>
                    </div>
                  </Col>
                  <Col md={12}>
                    <div className="shopify-checkbox">
                      <Checkbox
                        checked={props.importAllOrders}
                        onClick={(e) => {
                          props.setPropsImportAllOrders(e.target.checked);
                          props.setPropsImportAllCustomers(e.target.checked);
                       }}
                      />
                      <CheckboxLabel>Yes, import all open orders. <ReadMore />
                      </CheckboxLabel>
                    </div>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-save btn-fill btn btn-default" onClick={() => { props.updateStep(3) }}>Next</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  )
};

export default DataImportSettingsView;
