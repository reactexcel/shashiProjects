import React, { useState, useEffect } from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import axios from '../../../../axios/axios';
import * as constants from '../../constant/integrationConstant';
import * as wooCommerceConstant from '../../constant/wooCommerceConstant';
import CommonUtil from '../../../common/util/commonUtil';

const getWooCommerceMessage = (key) => {
  let filteredList = wooCommerceConstant.WOOCOM_MESSAGE_LIST.filter(function (tempObj) {
    return tempObj.key === key;
  });
  if (filteredList.length > 0) {
    return filteredList[0].message;
  }
}

const ConnectDoneView = (props) => {
  const [importAllCustomersStatus, setImportAllCustomersStatus] = useState('');
  const [importAllOrdersStatus, setImportAllOrdersStatus] = useState('');
  const [done, setDone] = useState(false);
  const shop = props.address;

  function getWooCommerceOrders(requestBody) {
    axios.post(constants.GET_WOOCOM_ORDERS_URL, requestBody).then(response => {
      if (response.status == 200 && response.data != null && CommonUtil.isNotNull(response.data.orderLastKey)) {
        getWooCommerceOrders({ "shop": shop, orderLastKey: response.data.orderLastKey });
      } else {
        setDone(true);
        setImportAllCustomersStatus('success');
        setImportAllOrdersStatus('success');
      }
    }).catch(error => {
      setImportAllCustomersStatus('error');
      setImportAllOrdersStatus('error');
    });
  }

  useEffect(() => {
    if (props.importAllOrders) {
      getWooCommerceOrders({ "shop": shop });
    } else {
      if (props.importAllCustomers) {
        axios.post(constants.GET_WOOCOM_CUSTOMERS_URL, { "shop": shop }).then(response => {
          setImportAllCustomersStatus('success');
          setDone(true);
        }).catch(error => {
          setImportAllCustomersStatus('error');
        });
      }
    }
  }, []);

  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <Row>
                  <Col md={12}>
                    <div className="highlighter">Importing open Sales Orders.</div>
                    <p>From WooCommerce to originscale is core functionality. This sync cannot be switch off.</p>
                    <p>Only Sales Orders with "Processing" status will be imported from WooCommerce.</p>
                    <div className="import-options">
                      {props.importAllOrders ?
                        <div className="option-item">
                          <i
                            className={importAllOrdersStatus == '' ? 'fa fa-spin fa-spinner' : importAllOrdersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getWooCommerceMessage('ALL_ORDERS')}
                        </div> : null}

                      {props.importAllCustomers ?
                        <div className="option-item">
                          <i
                            className={importAllCustomersStatus == '' ? 'fa fa-spin fa-spinner' : importAllCustomersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getWooCommerceMessage('ALL_CUSTOMERS')}
                        </div> : null}
                    </div>
                    <div className="wizard-note">Note: You can import up to 1000 WooCommerce Sales Orders with initial import.</div>
                    <p>Check the summary of your integration settings and click "Confirm".</p>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-cancel" onClick={() => props.updateStep(3)}>Previous</Button>
                <Button className={done ? "btn-save btn-fill btn btn-default" : "disabled"} onClick={() => { props.closeModal() }}>Confirm</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  );
};

export default ConnectDoneView;
