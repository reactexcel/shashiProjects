import React, { useState, useCallback, useEffect } from 'react';
import { Row, Col, FormGroup, ControlLabel, FormControl } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import * as constants from "../../constant/integrationConstant";
import axios from '../../../../axios/axios';
import CommonUtil from "../../../common/util/commonUtil";

const StoreView = (props) => {

  const [address, setAddress] = useState('');
  const [errorMsg, setErrorMsg] = useState(false);

  const changeAddressHandler = useCallback((evt) => {
    setAddress(evt.target.value);
    evt.target.value == "" ?
      setErrorMsg(true) : setErrorMsg(false);
  }, []);


  useEffect(() => {
    if (props.address) {
      axios.post(constants.GET_WOOCOM_ACCESS_TOKEN_URL).then(response => {
        if (response.data && CommonUtil.isNotNull(response.data.shop)) {
          props.updateStep(2);
          props.setShopAddress(response.data.shop);
        }
      }).catch(error => {
        console.log(error);
      });
    }
  }, []);

  const authorizeStore = useCallback((evt) => {
    let isValidStoreURL = false;
    if (address != null) {
      console.log('regex is ok');
      isValidStoreURL = true;
      setErrorMsg(false);
    } else {
      console.log('regex is not ok');
      isValidStoreURL = false;
      setErrorMsg(true);
    }

    if (isValidStoreURL) {
      props.updateStep(2);
      props.setShopAddress(address);
    }
  }, [address, setErrorMsg]);

  return (
    <Row>
      <Col md={12}>
        <form>
          <Card
            content={
              <Row>
                <Col md={12}>
                  <div className="store-view-wrapper woocommerce-section">
                    <div className="start-section">
                      Howdy! Log in to WooCommerce.com with your WordPress.com account
                      <span>
                        WooCommerce.com now uses WordPress Accounts.
                      </span>
                    </div>
                    <FormGroup
                      controlId="storeAddress"
                    >
                      <ControlLabel>Enter Address or Username</ControlLabel>
                      <FormControl
                        type="text"
                        value={address}
                        placeholder="Your Store address"
                        onChange={changeAddressHandler}
                      />
                      {errorMsg ?
                        <small className="text-danger">
                          Please enter correct address.
                        </small> : null}
                    </FormGroup>
                  </div>
                </Col>
              </Row>
            }
            ftTextRight
            legend={
              <div>
                <Button className="btn-cancel" onClick={props.closeModal}>Cancel</Button>
                <Button className="btn-save btn-fill btn btn-default" onClick={authorizeStore}>Authorize</Button>
              </div>
            }
          />
        </form>
      </Col>
    </Row>
  );
};

export default StoreView;
