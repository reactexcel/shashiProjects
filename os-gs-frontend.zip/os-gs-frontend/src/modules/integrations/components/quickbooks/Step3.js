import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Card from "components/Card/Card.jsx";
import Select from "react-select";
import * as pagePropertyListConstant from "../../constant/pagePropertyConstant";
import PopularTableUtil from "../../../common/util/popularTableUtil";
import Table from "../../../../views/Tables/PopularTable/Table/Table";
import ValidationUtil from "../../../common/util/validationUtil";
import CommonUtil from "../../../common/util/commonUtil";

class Step3 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      qboTaxList: [],
      taxMapping: [],
    };
  }

  componentDidMount = () => {
    if(this.props.qboTaxCode) {
      this.setState({
        qboTaxList: this.props.qboTaxCode.qboTaxCodes,
      });  
    }
    if(this.props.dataDictionaryList) {
      this.setState({
        taxMapping: this.getOsTaxValues(),
      });  
    }
    const tableAttributeList = pagePropertyListConstant.TAX_TABLE_LIST(this);
    this.setState({
      tableAttributeList: CommonUtil.getDropDownOptionsFromDictionary(
        tableAttributeList.tableColumnList, this.props.dataDictionaryList),
      tableColumnList: tableAttributeList.tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
    });
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.qboTaxCode != null && prevProps.qboTaxCode != this.props.qboTaxCode) {
      this.setState({
        qboTaxList: this.props.qboTaxCode.qboTaxCodes,
      });
      this.handleQboTaxDetails();
    }
    if (this.props.dataDictionaryList != null && prevProps.dataDictionaryList != this.props.dataDictionaryList) {
      this.handleQboTaxDetails();
    }
  }

  handleQboTaxDetails = () => {
    if (CommonUtil.isNotNull(this.props.qboTaxCode) && CommonUtil.isNotNull(this.props.dataDictionaryList)) {
      this.setState({
        taxMapping: this.getOsTaxValues(),
      });
    }
  }

  getQboTaxCode = (value) => {
    let qboTaxObj = null;
    if (CommonUtil.isNotNull(this.props.qboTaxCode) && CommonUtil.isNotNull(this.props.qboTaxCode.taxMapping)) {
      qboTaxObj = CommonUtil.getFilteredObjFromArray(this.props.qboTaxCode.taxMapping, 'osTaxId', value);
    }
    if (CommonUtil.isNotNull(qboTaxObj)) {
      return qboTaxObj;
    }
    return null;
  }

  getOsTaxValues = () => {
    let taxMapping = [];
    for(let i=0; i<this.props.dataDictionaryList.dataDictionaryList.taxList.length; i++) {
      let osTax = {};
      osTax.osTaxId = this.props.dataDictionaryList.dataDictionaryList.taxList[i].value;
      let qboTax = this.getQboTaxCode(osTax.osTaxId);
      if(qboTax){
        osTax.qboTaxId = qboTax.qboTaxId;
        osTax.qboTaxIdlabel = qboTax.qboTaxIdlabel;
       }
      taxMapping.push(osTax);
    }
    return taxMapping;
  }

  setSelectedParams = () => {
    var tempParamas = {};
    const { taxMapping, qboTaxList } = this.state;
    tempParamas.qboTaxCodes = qboTaxList;
    tempParamas.taxMapping = taxMapping;
    return tempParamas;
  }

  handleTableTextBoxChange = (event) => {
    PopularTableUtil.handleTableTextBoxChange(event, this, "taxMapping");
  }

  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleQboTableDropDownChange(event, obj, this, "taxMapping");
  }

  isValidated() {
    this.props.qboTaxMapping(this.setSelectedParams());
    console.log(this.setSelectedParams());
  }

  render() {
    const { tableColumnList, tableConfig, taxMapping } = this.state;
    return (
      <div className="wizard-step">
        <Row>
          <Col md={12}>
            <p>
              Map your originscale &amp; quickbooks tax types below to ensure your taxes are accounted for properly in QuickBooks.
            </p>
          </Col>
          <Col md={12} className="step-table">
            <Card
              content={
                taxMapping != null && taxMapping.length > 0 ? (
                  <Table
                    columns={tableColumnList}
                    data={taxMapping}
                    config={tableConfig}
                    getRowProps={this.getTdProps}
                    that={this}
                  />
                ) : null
              }
            />
          </Col>
        </Row>
      </div>
    );
  }
}

export default Step3;