import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Button from "../../../../components/CustomButton/CustomButton.jsx";

class Step1 extends Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentDidMount = () => {
  }

  isValidated() {
    this.props.getQboAccount();
  }

  render() {
    return (
      <>
        <div className="wizard-step">
          <Row>
            <Col md={12}>
              <p>
                Your everyday business avtivity is tracked and managed in originscale &amp; data gets pushed to quickbooks as accounting data.
              </p>
              <p>
                How originscale syncs sales orders with quickbooks.
              </p>
              <p>
                As soon as you finish setting up your intergration with quickbooks you will see a new status "invoice" in "sell" screen and on every sales order. When you change the invoice status from "Not invoiced" to "Create invoice", an automatic invoice is created in quickbooks with the same sales order data.
              </p>
              <div className="highlighter">
                Sales Order in Originscale > <span>Invoice in QuickBooks</span>
              </div>
              <p>
                How originscale syncs purchase ordera with QuickBooks. 
              </p>
              <p>
                As soon as you finish setting up your integration with QuickBooks you will see a new status "Bill" in "Buy" Screen and on every purchase order. when you change the Bill Status from "Not billed" to "Create bill", an automatic bill is created in QuickBooks with same purchase order data.
              </p> 
              <div className="highlighter">
                Purchase order in originscale  <span>Bill in QuickBooks</span>
              </div> 
            </Col>
          </Row>
        </div>
        <div className="wizard-cancel-button">
          <Button className="btn-cancel pull-left" onClick={this.props.handlePopupClose}>
            Cancel
          </Button>
        </div>
      </>
    );
  }
}

export default Step1;
