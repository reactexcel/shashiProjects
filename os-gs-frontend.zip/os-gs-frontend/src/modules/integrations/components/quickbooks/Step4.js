import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Checkbox from "../../../../components/CustomCheckbox/CustomCheckbox.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";

class Step4 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      importCustomer: true,
      importSupplier: true,
      error: false,
    };
  }

  setSelectedCustomer = () => {
    var tempParamas = {};
    const { importCustomer} = this.state;
    tempParamas.importCustomer = importCustomer;
    return tempParamas;
  }

  setSelectedVendor = () => {
    var tempParamas = {};
    const { importSupplier} = this.state;
    tempParamas.importSupplier = importSupplier;
    return tempParamas;
  }

  handleDone = () => {
    if (this.state.importCustomer == true ) {
      this.props.dataSyncCustomer(this.setSelectedCustomer());
    }
    if (this.state.importSupplier == true) {
      this.props.dataSyncVendor(this.setSelectedVendor());
    } 
    if (this.state.importCustomer == false && this.state.importSupplier == false ) {
      this.props.handlePopupClose();
    }
  }

  render() {
    return (
      <>
        <div className="wizard-step">
          <Row>
            <Col md={12}>
              <p>
                Data import during first-time connect.
              </p>
              <p>
                Would you like to import your customer &amp; supplier data from quickbook to originscale?
              </p>
            </Col>
            <Col md={12}>
              <Checkbox 
                inline
                checked={this.state.importCustomer}
                disabled
                onChange={() => this.setState({ importCustomer: !this.state.importCustomer})}
                key="qbocustomer" 
                number="qbocustomer" 
                label="Yes, import my customer from quickbook to originscale"
              />
            </Col>
            <Col md={12}>
              <Checkbox 
                inline
                checked={this.state.importSupplier}
                disabled
                onChange={() => this.setState({ importSupplier: !this.state.importSupplier})}
                key="qbosupplier" 
                number="qbosupplier" 
                label="Yes, import my supplier from quickbook to originscale"/>
            </Col>
            <Col md={12}>
              <p>
                Great! You are now ready to integrate your originscale &amp; quickbooks account. just click Done &amp; Start sending invoices to quickbooks from sell screen or bills to quickbooks from buy screen.
              </p>
            </Col>
          </Row>
        </div>
        <div className="wizard-finish-button">
          <Button className="btn-save pull-right btn-fill" onClick={this.handleDone}>
            Done
          </Button>
        </div>
      </>
    );
  }
}

export default Step4;