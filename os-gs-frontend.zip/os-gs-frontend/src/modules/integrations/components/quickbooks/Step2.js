import React, { Component } from "react";
import { Row, Col, FormGroup, FormControl, ControlLabel } from "react-bootstrap";
import Select from "react-select";

class Step2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      saleList: [],
      purchaseList: [],
      sale: null,
      salesLedgerId: null,
      salesLedgerName: null,
      saleError: null,
      purchase: null,
      purchaseLedgerId: null,
      purchaseLedgerName: null,
      purchaseError: null,
    };
  }

  componentDidMount = () => {
    if(this.props.qboAccount) {
      this.setState({
        saleList: this.props.qboAccount.incomeList,
        purchaseList: this.props.qboAccount.expenseList,
        sale: { id: this.props.qboAccount.salesLedgerId, label: this.props.qboAccount.salesLedgerName, value: this.props.qboAccount.salesLedgerName },
        purchase: { id: this.props.qboAccount.purchaseLedgerId, label: this.props.qboAccount.purchaseLedgerName, value: this.props.qboAccount.purchaseLedgerName },
        salesLedgerId: this.props.qboAccount.salesLedgerId,
        salesLedgerName: this.props.qboAccount.salesLedgerName,
        purchaseLedgerId: this.props.qboAccount.purchaseLedgerId,
        purchaseLedgerName: this.props.qboAccount.purchaseLedgerName,
      });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.qboAccount != null && prevProps.qboAccount != this.props.qboAccount) {
      this.setState({
        saleList: this.props.qboAccount.incomeList,
        purchaseList: this.props.qboAccount.expenseList,
        sale: { id: this.props.qboAccount.salesLedgerId, label: this.props.qboAccount.salesLedgerName, value: this.props.qboAccount.salesLedgerName },
        purchase: { id: this.props.qboAccount.purchaseLedgerId, label: this.props.qboAccount.purchaseLedgerName, value: this.props.qboAccount.purchaseLedgerName },
        salesLedgerId: this.props.qboAccount.salesLedgerId,
        salesLedgerName: this.props.qboAccount.salesLedgerName,
        purchaseLedgerId: this.props.qboAccount.purchaseLedgerId,
        purchaseLedgerName: this.props.qboAccount.purchaseLedgerName,
      });
    }
  }

  setSelectedParams = () => {
    var tempParamas = {};
    const { salesLedgerId, purchaseLedgerId, salesLedgerName,  purchaseLedgerName} = this.state;
    tempParamas.salesLedgerId = salesLedgerId;
    tempParamas.purchaseLedgerId = purchaseLedgerId;
    tempParamas.salesLedgerName = salesLedgerName;
    tempParamas.purchaseLedgerName = purchaseLedgerName;
    return tempParamas;
  }

  isValidated() {
    this.state.sale === null
      ? this.setState({
        saleError: (
          <small className="text-danger">
            You have to select a sale.
          </small>
        )
      })
      : this.setState({ saleError: null });
    var wb = this.state.sale !== null;
    this.state.purchase === null
      ? this.setState({
        purchaseError: (
          <small className="text-danger">
            You have to select a purchase.
          </small>
        )
      })
      : this.setState({ purchaseError: null });
    var lg = this.state.purchase !== null;
    var valid = wb && lg;
    if (valid == true) {
      this.props.getSelectedParams(this.setSelectedParams());
      return valid;
    } else {
      return valid;
    }
  }


  render() {
    return (
      <div className="wizard-step">
        <Row>
          <Col md={12}>
            <p>
              Link your quickbooks accounts to your originscale &amp; purchase orders. Tis determines which quickbooks account the total values will be pushed to after each respective action in originscale, if you would like to push only Sales or Purchase data, than opt out of one of he options here. read more.
            </p>
          </Col>
          <Col md={12} className="step-form">
            <Row>
              <Col md={6} className="form-heading">originscale</Col>

              <Col md={6} className="form-heading">Quickbooks account</Col>

              <Col md={12} className="form-content">
                <Row>
                  <FormGroup>
                    <Col md={6}>
                      <ControlLabel>originscale Sales: Product income</ControlLabel>
                    </Col>
                    <Col md={6}>
                      <Select
                        classNamePrefix="react-select"
                        name="sale"
                        options={this.state.saleList}
                        value={this.state.sale}
                        onChange={value => {
                          this.setState({ sale: value, salesLedgerId: value.id, salesLedgerName: value.value });
                          value === ""
                            ? this.setState({
                              saleError: (
                                <small className="text-danger">
                                  You have to select a sale.
                                </small>
                              )
                            })
                            : this.setState({ saleError: null });
                        }}
                        placeholder=""
                      />
                      {this.state.saleError}
                    </Col>
                  </FormGroup>
                </Row>
              </Col>
              
              <Col md={12} className="form-content">
                <Row>
                  <FormGroup>
                    <Col md={6}>
                      <ControlLabel>originscale Purchase: Material expense</ControlLabel>
                    </Col>
                    <Col md={6}>
                      <Select
                        classNamePrefix="react-select"
                        name="purchase"
                        options={this.state.purchaseList}
                        value={this.state.purchase}
                        onChange={value => {
                          this.setState({ purchase: value, purchaseLedgerId: value.id, purchaseLedgerName: value.value });
                          value === ""
                            ? this.setState({
                              purchaseError: (
                                <small className="text-danger">
                                  You have to select a purchase.
                                </small>
                              )
                            })
                            : this.setState({ purchaseError: null });
                        }}
                        placeholder=""
                      />
                      {this.state.purchaseError}
                    </Col>
                  </FormGroup>
                </Row>
              </Col>
            </Row>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Step2;