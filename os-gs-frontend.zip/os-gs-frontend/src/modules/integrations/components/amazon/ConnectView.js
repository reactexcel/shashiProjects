import React, { Component } from "react";
import { connect } from "react-redux";
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import { setActionMode } from "../../../../actions/appActions";
import { getAmazonAppKey } from "../../actions/integrationActions";
import AmazonPopup from "../../views/AmazonPopup.js";
import * as integrationConstant from '../../constant/integrationConstant';
import * as amazonConstant from '../../constant/amazonConstant';
import CommonUtil from "../../../common/util/commonUtil";
import axios from '../../../../axios/axios';

class ConnectView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      authorizationUrl: null,
      stateId: "AUTO123456OSSTATEID",
    };
  }

  componentDidMount = () => {
    axios.post(integrationConstant.GET_AMAZON_APP_KEY_URL).then(response => {
      if (response.status == 200) {
        this.buildAuthorizationURL(response.data);
      }
    });
  };

  componentDidUpdate = (prevProps) => {
    if (this.props.amazonAppkey != null && prevProps.amazonAppkey != this.props.amazonAppkey) {
      this.buildAuthorizationURL();
    }
  };

  getAmazonMessage = (key) => {
    let filteredList = amazonConstant.AMAZON_MESSAGE_LIST.filter(function (tempObj) {
      return tempObj.key === key;
    });
    if (filteredList.length > 0) {
      return filteredList[0].message;
    }
  };

  buildAuthorizationURL = async (amazonAppkey) => {
    const { stateId } = this.state;
    let tempMarketPlaceObj = CommonUtil.getFilteredObjFromArray(amazonConstant.AMAZON_MARKETPLACE_URL_LIST,
      'marketPlaceId', this.props.marketPlaceId);
    let tempAmazonAppkey = amazonAppkey ? amazonAppkey : this.props.amazonAppkey;
    if (CommonUtil.isNotNull(tempMarketPlaceObj)) {
      let authorizationUrl = tempMarketPlaceObj.marketPlaceURL + "/apps/authorize/consent?application_id="
        + tempAmazonAppkey + "&state=" + stateId + "&version=beta&";
      await this.setState({ authorizationUrl: authorizationUrl });
    }
  };

  onSuccess = (response) => {
    let requestBody = {
      spapi_oauth_code: response,
      marketPlaceId: this.props.marketPlaceId,
      importProducts: this.props.importAllProducts,
      importCustomers: this.props.importAllCustomers,
      importOrders: this.props.importAllOrders,
    };
    axios.post(integrationConstant.GET_AMAZON_ACCESS_TOKEN_URL, requestBody).then(response => {
      if (this.props.importAllProducts || this.props.importAllCustomers || this.props.importAllOrders) {
        this.props.updateStep(4);
      } else {
        this.props.closeModal();
      }
    }).catch(error => {
      console.log(error);
    });
  };

  onFailure = (response) => {
    console.log('error ' + response);
  };

  render() {
    const { authorizationUrl } = this.state;
    return (
      <div className="multi-step" >
        <Row>
          <Col md={12}>
            <Card
              content={
                <div className="wizard-step">
                  <Row>
                    <Col md={12}>
                      <div className="highlighter">First-time connect import:</div>
                      <div className="import-options">
                        {this.props.importAllOrders ? <div className="option-item">{this.getAmazonMessage('ALL_ORDERS')}</div> : null}
                        {this.props.importAllProducts ? <div className="option-item">{this.getAmazonMessage('ALL_PRODUCTS')}</div> : null}
                        {this.props.importAllCustomers ? <div className="option-item">{this.getAmazonMessage('ALL_CUSTOMERS')}</div> : null}
                      </div>
                      <div className="highlighter">Import data going forward</div>
                      <p>
                        After this import, you can continue to import open orders &amp; associated customers &amp; products from your store to Originscale by clicking on SYNC button on integration page.
                      </p>
                      <p>
                        However, we will synchronize the order fulfillment state between Originscale &amp; Amazon automatically.
                      </p>
                    </Col>
                  </Row>
                </div>
              }
              ftTextRight
              legend={
                <div>
                  <Button className="btn-cancel" onClick={() => this.props.updateStep(2)}>Previous</Button>
                  <AmazonPopup
                    url={authorizationUrl}
                    onCode={this.onSuccess}
                    onClose={this.onFailure}
                    isAmazon={true}
                    title="qbow"
                    width="800"
                    height="600">
                    <Button className="btn-save btn-fill connect-now-btn">connect now</Button>
                  </AmazonPopup>

                </div>
              }
            />
          </Col>
        </Row>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
    amazonAppkey: state.integration.amazonAppkey,
  };
}

const mapDispatchToProps = (dispatch) => ({
  setActionMode: (actionMode) => dispatch(setActionMode(actionMode)),
  getAmazonAppKey: (params) => dispatch(getAmazonAppKey(params)),
});
export default connect(mapStateToProps, mapDispatchToProps)(ConnectView);

