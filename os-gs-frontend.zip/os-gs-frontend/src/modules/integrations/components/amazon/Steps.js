import React, { useState, useCallback } from 'react';
import { Badge } from 'react-bootstrap';
import RegionView from './RegionView';
import DataImportSettingsView from './DataImportSettingsView';
import ConnectView from './ConnectView';
import ConnectDoneView from './ConnectDoneView';
import MapFacility from './MapFacility';

const Steps = (props) => {
  const [marketPlaceId, setMarketPlaceId] = useState("");
  const [step, setStep] = useState(1);
  const [importAllCustomers, setImportAllCustomers] = useState(false);
  const [importAllProducts, setImportAllProducts] = useState(false);
  const [importAllOrders, setImportAllOrders] = useState(false);
  const updateStep = useCallback((step) => setStep(step), []);
  const updateMarketPlaceId = useCallback((marketPlaceId) => setMarketPlaceId(marketPlaceId), []);
  const setPropsImportAllCustomers = useCallback((value) => setImportAllCustomers(value), []);
  const setPropsImportAllProducts = useCallback((value) => setImportAllProducts(value), []);
  const setPropsImportAllOrders = useCallback((value) => setImportAllOrders(value), []);

  const renderStepView = useCallback(() => {
    if (step === 1) {
      if (props.syncAmazon) {
        return <ConnectDoneView closeModal={props.closeModal} importAllProducts={props.importProducts}
          importAllCustomers={props.importCustomers} importAllOrders={props.importOrders}
          marketPlaceId={props.marketPlaceId} />
      } else {
        return <RegionView closeModal={props.closeModal} updateStep={updateStep}
          updateMarketPlaceId={updateMarketPlaceId} />
      }
    } else if (step === 2) {
      return <DataImportSettingsView updateStep={updateStep} setPropsImportAllCustomers={setPropsImportAllCustomers}
        setPropsImportAllProducts={setPropsImportAllProducts} setPropsImportAllOrders={setPropsImportAllOrders}
        importAllProducts={importAllProducts} importAllCustomers={importAllCustomers} importAllOrders={importAllOrders}
        />
    } else if (step === 3) {
      return <ConnectView closeModal={props.closeModal} updateStep={updateStep}
        importAllProducts={importAllProducts} importAllCustomers={importAllCustomers}
        importAllOrders={importAllOrders} marketPlaceId={marketPlaceId} />
    } else if (step === 4) {
      return <MapFacility closeModal={props.closeModal} updateStep={updateStep} importAllProducts={importAllProducts}
        importAllCustomers={importAllCustomers} importAllOrders={importAllOrders} marketPlaceId={marketPlaceId} />
    } else if (step === 5) {
      return <ConnectDoneView closeModal={props.closeModal} updateStep={updateStep} importAllProducts={importAllProducts}
        importAllCustomers={importAllCustomers} importAllOrders={importAllOrders}
        marketPlaceId={marketPlaceId} />
    }
  }, [step, importAllProducts, importAllCustomers, importAllOrders]);

  return (
    <>
      <div className="steps-nav">
        <div className="steps"><Badge className={step === 1 ? props.syncAmazon ? 'fill-badge' : 'active-badge' : 'fill-badge'}>1</Badge> <span className={step >= 1 ? 'active-step' : null}>Select Region</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncAmazon ? 'fill-badge' : null : step === 2 ? 'active-badge' : step > 2 ? 'fill-badge' : null}>2</Badge> <span className={step >= 2 ? 'active-step' : null}>Initial data import settings</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncAmazon ? 'fill-badge' : null : step === 3 ? 'active-badge' : step > 3 ? 'fill-badge' : null}>3</Badge> <span className={step >= 3 ? 'active-step' : null}>Connect</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncAmazon ? 'active-badge' : null : step === 4 ? 'active-badge' : null}>4</Badge> <span className={step === 4 ? 'active-step' : null}>Map Facility</span></div>
        <div className="steps"><Badge className={step === 1 ? props.syncAmazon ? 'active-badge' : null : step === 5 ? 'active-badge' : null}>4</Badge> <span className={step === 5 ? 'active-step' : null}>Done</span></div>
      </div>
      {renderStepView()}
    </>
  );
};

export default Steps;
