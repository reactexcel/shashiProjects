import React, { useState, useEffect } from 'react';
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import axios from '../../../../axios/axios';
import * as constants from '../../constant/integrationConstant';
import * as amazonConstant from '../../constant/amazonConstant';

const getAmazonMessage = (key) => {
  let filteredList = amazonConstant.AMAZON_MESSAGE_LIST.filter(function (tempObj) {
    return tempObj.key === key;
  });
  if (filteredList.length > 0) {
    return filteredList[0].message;
  }
}

const ConnectDoneView = (props) => {
  const [importAllCustomersStatus, setImportAllCustomersStatus] = useState('');
  const [importAllProductsStatus, setImportAllProductsStatus] = useState('');
  const [importAllOrdersStatus, setImportAllOrdersStatus] = useState('');
  const [done, setDone] = useState(false);
  const marketPlaceId = props.marketPlaceId;

  function getAmazonData(marketPlaceId) {
    let requestBody = { "marketPlaceId": marketPlaceId };
    axios.post(constants.GET_AMAZON_PRODUCTS_URL, requestBody, { timeout: 29000 }).then(response => {
      setImportAllProductsStatus('success');
      getAmazonOrders(requestBody);
    }).catch(error => {
      if (error.code == "ECONNABORTED") {
        setTimeout(() => getAmazonData(marketPlaceId), 2000);
      } else {
        setImportAllProductsStatus('error');
        setImportAllCustomersStatus('error');
        setImportAllOrdersStatus('error');
        setDone(true);
      }
    });
  }

  function getAmazonOrders(requestBody) {
    axios.post(constants.GET_AMAZON_ORDERS_URL, requestBody, { timeout: 29000 }).then(response => {
      setDone(true);
      setImportAllOrdersStatus('success');
      setImportAllCustomersStatus('success');
    }).catch(error => {
      if (error.code == "ECONNABORTED") {
        setTimeout(() => getAmazonOrders(requestBody), 2000);
      }
      setImportAllOrdersStatus('error');
      setImportAllCustomersStatus('error');
    });
  }

  useEffect(() => {
    if (props.importAllOrders) {
      getAmazonData(marketPlaceId);
    } else {
      if (props.importAllProducts) {
        axios.post(constants.GET_AMAZON_PRODUCTS_URL, { "marketPlaceId": marketPlaceId }).then(response => {
          setImportAllProductsStatus('success');
          setDone(true);
        }).catch(error => {
          setImportAllProductsStatus('error');
        });
      }
    }
  }, []);

  return (
    <div className="multi-step">
      <Row>
        <Col md={12}>
          <Card
            content={
              <div className="wizard-step">
                <Row>
                  <Col md={12}>
                    <div>We are importing the requested data from Amazon. Please wait for a while, it may take few seconds.
                    </div>
                    <br /><br />
                    <div className="import-options">
                      {props.importAllOrders ?
                        <div className="option-item">
                          <i
                            className={importAllOrdersStatus == '' ? 'fa fa-spin fa-spinner' : importAllOrdersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getAmazonMessage('ALL_ORDERS')}
                        </div> : null}
                      {props.importAllProducts ?
                        <div className="option-item">
                          <i
                            className={importAllProductsStatus == '' ? 'fa fa-spin fa-spinner' : importAllProductsStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getAmazonMessage('ALL_PRODUCTS')}
                        </div> : null}
                      {props.importAllCustomers ?
                        <div className="option-item">
                          <i
                            className={importAllCustomersStatus == '' ? 'fa fa-spin fa-spinner' : importAllCustomersStatus == 'success' ? 'fa fa-check' : 'fa fa-close'} />
                          {getAmazonMessage('ALL_CUSTOMERS')}
                        </div> : null}
                    </div>
                  </Col>
                </Row>
              </div>
            }
            ftTextRight
            legend={
              <div>
                <Button className={done ? "btn-save btn-fill btn btn-default" : "disabled"} onClick={() => { props.closeModal() }}>Done</Button>
              </div>
            }
          />
        </Col>
      </Row>
    </div>
  );
};

export default ConnectDoneView;
