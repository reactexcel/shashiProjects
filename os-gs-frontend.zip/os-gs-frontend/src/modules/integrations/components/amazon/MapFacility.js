import React, { Component } from "react";
import { Row, Col, FormGroup, ControlLabel } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import CommonUtil from "../../../common/util/commonUtil";
import { connect } from "react-redux";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import { getFacilityList, setFacilityDetails } from "../../../facilityManagement/actions/facilityActions";
import * as constants from '../../constant/integrationConstant';
import { setAjaxCallStatus } from '../../../../actions/ajaxStatusActions';
import * as commonConstant from "../../../common/constant/commonConstant";
import * as amazonConstant from "../../constant/amazonConstant";
import PopupUtil from '../../../common/util/popupUtil';
import axios from '../../../../axios/axios';
import Select from "react-select";

class MapFacility extends Component {
  constructor(props) {
    super(props);
    this.state = {
      facilityList: [],
      facility: null,
      facilityError: null,
    };
    this.handleClick = this.handleClick.bind(this);
  }

  componentDidMount = () => {
    this.props.getFacilityList({ "sourceChannel": commonConstant.AMAZON });
  };

  componentDidUpdate(prevProps) {
    if (this.props.facilityList != null && prevProps.facilityList != this.props.facilityList) {
      this.handleSetDefaultFacility();
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
  }

  handleAjaxResponse = () => {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);
      this.props.getFacilityList({ "sourceChannel": commonConstant.AMAZON });
    } else if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handleSetDefaultFacility = () => {
    if (this.props.facilityList.Items != null && this.props.facilityList.Items.length > 0) {
      this.setState({
        facilityList: CommonUtil.getOptionsFromList(
          this.props.facilityList.Items, 'facilityId', 'facilityName')
      });
    } else {
      this.props.setFacilityDetails(amazonConstant.CREATE_AMAZON_FACILITY, commonConstant.CREATE_ACTION_MODE);
    }
  }

  handleClick = () => {
    this.state.facility === null ? this.setState({
      facilityError: (<small className="text-danger">You have to select a facility.</small>)
    }) : this.setState({ facilityError: null });

    if (CommonUtil.isNotNull(this.state.facility)) {
      axios.post(constants.SET_AMAZON_LOCATIONS_URL, { "facilityId": this.state.facility.value })
        .then(response => {
          this.props.updateStep(5);
        }).catch(error => {
          this.setState({
            facilityError: (<small className="text-danger">Facility Update Failed! Please try again.</small>
            )
          })
        });
    }
  }

  render() {
    return (
      <div className="multi-step">
        <Row>
          <Col md={12}>
            <Card
              content={
                <div className="wizard-step">
                  <Row>
                    <Col md={12}>
                      <div className="highlighter">Locations Mapping from Amazon to originscale.</div>
                      <p>
                        We need your help to map Amazon location to originscale. This creates a link between both platform to enable syncing orders & stock levels going forward.
                      </p>
                    </Col>
                    <Col md={12} className="step-form">
                      <Row>
                        <Col md={12} className="form-heading">Choose a originscale location for your Amazon orders :</Col>
                        <Col md={12} className="form-content">
                          <Row>
                            <FormGroup>
                              <Col md={6}>
                                <ControlLabel>Amazon Location</ControlLabel>
                              </Col>
                              <Col md={6}>
                                <Select
                                  classNamePrefix="react-select"
                                  name="facility"
                                  options={this.state.facilityList}
                                  value={this.state.facility}
                                  onChange={value => {
                                    this.setState({ facility: value });
                                    value === ""
                                      ? this.setState({
                                        facilityError: (
                                          <small className="text-danger">
                                            You have to select a facility.
                                          </small>
                                        )
                                      })
                                      : this.setState({ facilityError: null });
                                  }}
                                  placeholder=""
                                />
                                {this.state.facilityError}
                              </Col>
                            </FormGroup>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                </div>
              }
              ftTextRight
              legend={
                <div>
                  <Button className="btn-cancel" onClick={() => this.props.updateStep(3)}>Previous</Button>
                  <Button className="btn-save btn-fill btn btn-default" onClick={this.handleClick}>Next</Button>
                </div>
              }
            />
          </Col>
        </Row>
      </div>
    )
  }
};

function mapStateToProps(state, ownProps) {
  return {
    facilityList: state.facility.facilityList,
    attributeObj: state.facility.facilityDetails,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
  };
}

const mapDispatchToProps = (dispatch) => ({
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  setFacilityDetails: (facilityDetailsObj, actionMode) => dispatch(setFacilityDetails(facilityDetailsObj, actionMode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
});
export default connect(mapStateToProps, mapDispatchToProps)(MapFacility);

