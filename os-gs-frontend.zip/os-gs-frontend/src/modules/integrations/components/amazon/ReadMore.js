import React from 'react';

const ReadMore = (props) => <div className="read-more">Read More</div>;

export default ReadMore;
