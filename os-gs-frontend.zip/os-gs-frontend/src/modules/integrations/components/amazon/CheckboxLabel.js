import React from 'react';

const CheckboxLabel = (props) => <div className="amazon-label">{props.children}</div>;

export default CheckboxLabel;
