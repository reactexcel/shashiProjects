import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import Card from "../../../../components/Card/Card.jsx";
import { connect } from "react-redux";
import Button from "../../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../../constant/pagePropertyConstant';
import * as commonConstant from '../../../common/constant/commonConstant';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import CommonUtil from '../../../common/util/commonUtil';

class RegionView extends Component {
  constructor(props) {
    super(props);
    this.state = {
      submitted: false,
      actionMode: commonConstant.CREATE_ACTION_MODE
    };
  }

  componentDidMount = () => {
    let commonAttributeList = pagePropertyListConstant.AMAZON_REGION_PAGE_LIST(this);
    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        commonAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: commonAttributeList.attributeObj,
    });
  };

  handleClick = () => {
    const { attributeObj } = this.state;
    this.setState({ submitted: true });
    if (attributeObj && CommonUtil.isNotNull(attributeObj.marketPlaceId)) {
      this.props.updateStep(2);
      this.props.updateMarketPlaceId(attributeObj.marketPlaceId);
    }
  }

  componentDidUpdate(prevProps) {

  }

  render() {
    const { attributeList, attributeObj, submitted, actionMode } = this.state;
    return (
      <div className="multi-step">
        <Row>
          <Col md={12}>
            <Card
              content={
                <div className="wizard-step">
                  <Row>
                    <Col md={12}>
                      <div className="highlighter">Location Mapping from Amazon to originscale.</div>
                      <p>
                        We need your help to map Amazon location to originscale. This creates a link between both platform to enable syncing orders & stock levels going forward.
                      </p>
                    </Col>
                    <Row>
                      <Col md={12}>
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "DROPDOWN" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                            : null))
                        }
                      </Col>
                    </Row>

                  </Row>
                </div>
              }
              ftTextRight
              legend={
                <div>
                  <Button className="btn-save btn-fill btn btn-default" onClick={this.handleClick}>Next</Button>
                </div>
              }
            />
          </Col>
        </Row>
      </div>
    )
  }
};

function mapStateToProps(state, ownProps) {
  return {
    actionMode: state.app.actionMode,
  };
}

const mapDispatchToProps = (dispatch) => ({
});
export default connect(mapStateToProps, mapDispatchToProps)(RegionView);

