import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";
import { Redirect, NavLink } from "react-router-dom";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Card from "../../../components/Card/Card.jsx";
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import { connect } from "react-redux";
import { getQuickBookUrl, revokeQuickbook } from "../actions/integrationActions";
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import { getUserProfile } from "../../userManagement/actions/userActions";
import QuickBookModal from "./QuickBookModal.js";
import QuickBookPopup from "./QuickBookPopup.js";
import quickbook from "assets/img/quickbook.png";
import isAuthorized from "auth-plugin"

const querystring = require('querystring');
var Modal = require('react-bootstrap-modal');

class QuickBooks extends Component {

	constructor(props) {
    super(props);
    this.state = { 
    	openModal: false,
    	qboParams: '',
      qboUri: '',
      qboStatus: '',
      alert: null,
    };
    this.getCompleteDetails = this.getCompleteDetails.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
	}

	componentDidMount = () => {
    this.props.getUserProfile();
    this.props.getQuickBookUrl();
	}

  componentDidUpdate(prevProps, prevState) {
    if (this.props.qboDetails != null && prevProps.qboDetails != this.props.qboDetails) {
      this.setState({ 
        qboUri: this.props.qboDetails.authUri,
        qboStatus: this.props.qboDetails.qboStatus, 
      });
    }
    if (this.props.qborevoke != null && prevProps.qborevoke != this.props.qborevoke) {
      this.props.getQuickBookUrl();
    }
  }

	getCompleteDetails = (completeDetails) => {
  	this.setState({ openModal: false });
	}

	onCode = (code, params) => {
    var pp = params.toString()
    this.setState({qboParams:querystring.parse(pp)});
    this.onClose();
    this.showModal();
	}
	onClose = () => {
  	// console.log("closed!");   
	}

	showModal = () => {
    this.setState({ openModal: true, qboStatus: 'active' });
	};

	hideModal = () => {
    this.setState({ openModal: false });
	};

  revokeAccount = () => {
    this.props.revokeQuickbook();
  }

  handlePopupCancel = () => {
    this.setState({ alert: null });
  }

  IntegrationConnection = () => {
    let popupActionButton = {};
    popupActionButton.onCancelClick = this.handlePopupCancel;
    let popupConfig = CommonUtil.IntegrationConnectionPopUpConfig(popupActionButton);
    this.setState({ alert: PopupUtil.confirmationPopup(popupConfig) });
    return
  }

	render() {
    const { userProfile } = this.props;
		return (
      <div className="intg-main-wrapper disabled">
        {this.state.alert}
        <div className="intg-acc-image">
          <img className="main-image" src={quickbook} />
        </div>
        <div className="intg-acc-status">
          {this.state.qboStatus == 'active' ? 'Account is currently connected' : 'Account is currently not connected' }
        </div>
        <div className="intg-control-wrapper">
            <div className="intg-control">
                <div className="read-more-wrapper">
                  Read more
                </div>
                { isAuthorized("adminSettings") && userProfile && userProfile.isDummyDataDeleted == false ?
                  <Button className="btn-save btn-fill connect-now-btn" onClick={this.IntegrationConnection}> connect now </Button>
                  : this.state.qboStatus == 'active' ?
                      <Button className="btn-save btn-fill connect-now-btn" onClick={this.revokeAccount}>
                        Disconnect
                      </Button> 
                    :
                      <QuickBookPopup
                        url={this.state.qboUri}
                        onCode={this.onCode}
                        onClose={this.onClose}
                        title="qbow"
                        width="800"
                        height="600"
                      >
                        <Button className="btn-save btn-fill connect-now-btn">
                          connect now
                        </Button>
                      </QuickBookPopup> 
                    
                }
            </div>
        </div>
        {this.state.openModal == true ?
          <QuickBookModal
              getCompleteDetails={this.getCompleteDetails}
              qboParams={this.state.qboParams}
            >
          </QuickBookModal>
          : null}
      </div>
		);
	}
}

function mapStateToProps(state, ownProps) {
  return {
  	qboDetails: state.integration.qboDetails,
    qborevoke: state.integration.qborevoke,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
  getQuickBookUrl: () => dispatch(getQuickBookUrl()),
  revokeQuickbook: () => dispatch(revokeQuickbook()),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
	getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
});

export default connect(mapStateToProps, mapDispatchToProps)(QuickBooks);
