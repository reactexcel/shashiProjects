import React, { useState, useCallback, useEffect } from "react";
import { Grid, Row, Col, Modal } from "react-bootstrap";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Card from "../../../components/Card/Card.jsx";
import Steps from '../components/shopify/Steps';
import shopify from "assets/img/shopify.png";
import axios from '../../../axios/axios';
import logo from "assets/img/logo-1.png";
import sync from "assets/img/sync.png";
import * as constants from "../constant/integrationConstant";
import isAuthorized from "auth-plugin"
import PopupUtil from "../../common/util/popupUtil";
import { connect } from "react-redux";
import CommonUtil from "../../common/util/commonUtil";

const Shopify = (props) => {
  const [show, setShow] = useState(false);
  const [syncShopify, setSyncShopify] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isAppOnlyRegistered, setIsAppOnlyRegistered] = useState(false);
  const [importProducts, setImportProducts] = useState(false);
  const [importCustomers, setImportCustomers] = useState(false);
  const [importOrders, setImportOrders] = useState(false);
  const [message, setMessage] = useState("Account is currently not connected");
  const [shop, setShop] = useState("");
  const [alert, setAlert] = useState(null);
  const handleClose = useCallback(() => {
    axios.post(constants.GET_SHOPIFY_ACCESS_TOKEN_URL).
      then(response => {
        if (response.data && CommonUtil.isNotNull(response.data.shop)) {
          setShop(response.data.shop);
          setIsAppOnlyRegistered(response.data.isAppOnlyRegistered);
          setImportProducts(response.data.import_products);
          setImportOrders(response.data.import_orders);
          setImportCustomers(response.data.import_customers);
          setIsConnected(true);
          if(response.data.isAppOnlyRegistered){
            setMessage("Please configure webstore integration by clicking on settings.");
          }else{
          setMessage("Account is currently connected to " + response.data.shop);
          }
        } else {
          setIsConnected(false);
          setMessage("Account is currently not connected");
        }
      }).catch(error => {
        console.log(error);
      });
    setShow(false);
    setSyncShopify(false);
  }, [setIsConnected, setMessage, setShop, setImportCustomers, setImportProducts, setImportOrders, setIsAppOnlyRegistered]);

  const connectHandler = useCallback(() => {
    if (isAuthorized("adminSettings") && props.userProfile && props.userProfile.isDummyDataDeleted == false) {
      let popupActionButton = {};
      popupActionButton.onCancelClick = handlePopupCancel;
      let popupConfig = CommonUtil.IntegrationConnectionPopUpConfig(popupActionButton);
      setAlert(PopupUtil.confirmationPopup(popupConfig));
      return
    } else {
      if (isConnected) {
        if (isAppOnlyRegistered) {
          setShow(true);
          setSyncShopify(false);
        } else {
          axios.post(constants.GET_SHOPIFY_DISCONNECT_URL).
            then(response => {
              if (response.data == true) {
                setIsConnected(false);
                setMessage("Account is currently not connected");
              }
            }).catch(error => {
              console.log(error);
            });
        }
      } else {
        setShow(true);
        setSyncShopify(false);
      }
    }
  }, [isConnected]);

  const syncHandler = useCallback(() => {
    console.log("Shop name: " + shop);
    setShow(true);
    setSyncShopify(true);
  }, []);

  const handlePopupCancel = useCallback(() => {
    setAlert(null);
  }, []);

  useEffect(() => {
    axios.post(constants.GET_SHOPIFY_ACCESS_TOKEN_URL).
      then(response => {
        console.log("getShopifyAccessToken response: ", response);
        if (response.data && CommonUtil.isNotNull(response.data.shop)) {
          setShop(response.data.shop);
          setIsAppOnlyRegistered(response.data.isAppOnlyRegistered);
          setImportProducts(response.data.import_products);
          setImportOrders(response.data.import_orders);
          setImportCustomers(response.data.import_customers);
          if(CommonUtil.isNotNull(response.data.shopify_token)) {
            setIsConnected(true);
            if(response.data.isAppOnlyRegistered){
              setMessage("Please configure webstore integration by clicking on settings.");
            }else{
            setMessage("Account is currently connected to " + response.data.shop);
            }
          }
        }
        else {
          setIsConnected(false);
          setMessage("Account is currently not connected");
        }
      }).catch(error => {
        console.log(error);
      });
  }, [setIsConnected, setMessage, setImportCustomers, setImportProducts, setImportOrders, setIsAppOnlyRegistered]);
  return (
    <>
      {alert}
      <Modal className="modal-wrapper" show={show} onHide={handleClose} backdrop="static" keyboard={false} className="integrations-modal">
        <Modal.Header closeButton className="intg-modal-close-btn">
        </Modal.Header>
        <Modal.Body>
          <div className="main-content integration-modal">
            <Grid fluid>
              <Row>
                <Col md={12}>
                  <form>
                    <Card
                      content={
                        <div>
                          <div className="header-section">
                            <div className="logo-section">
                              <img className="logos" src={shopify} alt="shopify" />
                              <img src={sync} alt="" />
                              <img className="logos" src={logo} alt="OriginScale" />
                            </div>
                            <div className="heading">Connect your Shopify account to originscale</div>
                          </div>

                        </div>
                      }
                    />
                  </form>
                </Col>
              </Row>
              <Row>
                <Col md={12}>
                  <Steps closeModal={handleClose} isAppOnlyRegistered={isAppOnlyRegistered}
                    syncShopify={syncShopify} shop={shop} importCustomers={importCustomers}
                    importProducts={importProducts} importOrders={importOrders} />
                </Col>
              </Row>
            </Grid>
          </div>
        </Modal.Body>
      </Modal>

      <div className="intg-main-wrapper">
        <div className="intg-acc-image">
          <img className="main-image" src={shopify} />
        </div>
        <div className="intg-acc-status">
          {message}
        </div>
        <div className="intg-control-wrapper">
          <div className="intg-control">
            <div className="read-more-wrapper">
              Read more
            </div>
            <Button className="btn-save btn-fill btn btn-default connect-now-btn" onClick={connectHandler}>
              {isConnected ? isAppOnlyRegistered ? "Settings" : "disconnect" : "connect now"}
            </Button>
            <Button className={isConnected ? isAppOnlyRegistered ? "disabled connect-now-btn" :
              "btn-save btn-fill btn btn-default connect-now-btn" : "disabled connect-now-btn"}
              disabled={isConnected ? isAppOnlyRegistered ? true : false : true} onClick={syncHandler}>
              sync
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};


function mapStateToProps(state, ownProps) {
  return {
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(Shopify);