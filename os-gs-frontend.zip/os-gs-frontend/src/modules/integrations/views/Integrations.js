import React, { Component } from "react";
import { Row, Col } from "react-bootstrap";
import Card from "../../../components/Card/Card";
import QuickBooks from "./QuickBooks.js";
import Shopify from "./Shopify.js";
import WooCommerce from "./WooCommerce.js";
import mixpanel from "../../analytics/mixpanel/mixpael";
import Amazon from "./Amazon";

class Integrations extends Component {
    constructor(props) {
        super(props);
        this.state = {
        };
    }

    componentDidMount() {
        mixpanel.track("Integrations page loaded");
    }

    render() {
        return (
            <Row>
                <Col md={12}>
                    <Card
                        content={
                            <div>
                                {/* <Shopify />
                                <Amazon />
                                <QuickBooks /> */}
                                <WooCommerce />
                            </div>
                        }
                    />
                </Col>
            </Row>
        );
    }
}

export default Integrations;