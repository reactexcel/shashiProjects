import React, { useState, useCallback, useEffect } from "react";
import { Grid, Row, Col, Modal } from "react-bootstrap";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import Card from "../../../components/Card/Card.jsx";
import Steps from '../components/wooCommerce/Steps';
import wooCommerce from "assets/img/woocommerce.png";
import axios from '../../../axios/axios';
import logo from "assets/img/logo-1.png";
import sync from "assets/img/sync.png";
import * as constants from "../constant/integrationConstant";
import isAuthorized from "auth-plugin"
import PopupUtil from "../../common/util/popupUtil";
import { connect } from "react-redux";
import CommonUtil from "../../common/util/commonUtil";

const WooCommerce = (props) => {
  const [show, setShow] = useState(false);
  const [syncWooCommerce, setSyncWooCommerce] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [importProducts, setImportProducts] = useState(false);
  const [importCustomers, setImportCustomers] = useState(false);
  const [importOrders, setImportOrders] = useState(false);
  const [message, setMessage] = useState("Account is currently not connected");
  const [shop, setShop] = useState("");
  const [alert, setAlert] = useState(null);
  const handleClose = useCallback(() => {
    axios.post(constants.GET_WOOCOM_ACCESS_TOKEN_URL).
      then(response => {
        if (response.data && CommonUtil.isNotNull(response.data.shop)) {
          setShop(response.data.shop);
          setImportProducts(response.data.import_products);
          setImportOrders(response.data.import_orders);
          setImportCustomers(response.data.import_customers);
          setIsConnected(true);
          setMessage("Account is currently connected to " + response.data.shop);
        } else {
          setIsConnected(false);
          setMessage("Account is currently not connected");
        }
      }).catch(error => {
        console.log(error);
      });
    setShow(false);
    setSyncWooCommerce(false);
  }, [setIsConnected, setMessage, setShop, setImportCustomers, setImportProducts, setImportOrders]);

  const connectHandler = useCallback(() => {
    if (isAuthorized("adminSettings") && props.userProfile && props.userProfile.isDummyDataDeleted == false) {
      let popupActionButton = {};
      popupActionButton.onCancelClick = handlePopupCancel;
      let popupConfig = CommonUtil.IntegrationConnectionPopUpConfig(popupActionButton);
      setAlert(PopupUtil.confirmationPopup(popupConfig));
      return
    } else {
      if (isConnected) {
        axios.post(constants.GET_WOOCOM_DISCONNECT_URL).
          then(response => {
            if (response.data == true) {
              setIsConnected(false);
              setMessage("Account is currently not connected");
            }
          }).catch(error => {
            console.log(error);
          });
      } else {
        setShow(true);
        setSyncWooCommerce(false);
      }
    }
  }, [isConnected]);

  const syncHandler = useCallback(() => {
    console.log("Shop name: " + shop);
    setShow(true);
    setSyncWooCommerce(true);
  }, []);

  const handlePopupCancel = useCallback(() => {
    setAlert(null);
  }, []);

  useEffect(() => {
    axios.post(constants.GET_WOOCOM_ACCESS_TOKEN_URL).
      then(response => {
        console.log("getWooCommerceAccessToken response: ", response);
        if (response.data && CommonUtil.isNotNull(response.data.shop)) {
          setShop(response.data.shop);
          setImportProducts(response.data.import_products);
          setImportOrders(response.data.import_orders);
          setImportCustomers(response.data.import_customers);
          setIsConnected(true);
          setMessage("Account is currently connected to " + response.data.shop);
        }
        else {
          setIsConnected(false);
          setMessage("Account is currently not connected");
        }
      }).catch(error => {
        console.log(error);
      });
  }, [setIsConnected, setMessage, setImportCustomers, setImportProducts, setImportOrders]);
  return (
    <>
      {alert}
      <Modal className="modal-wrapper" show={show} onHide={handleClose} backdrop="static" keyboard={false} className="integrations-modal">
        <Modal.Header closeButton className="intg-modal-close-btn">
        </Modal.Header>
        <Modal.Body>
          <div className="main-content integration-modal">
            <Grid fluid>
              <Row>
                <Col md={12}>
                  <form>
                    <Card
                      content={
                        <div>
                          <div className="header-section">
                            <div className="logo-section">
                              <img className="logos" src={wooCommerce} alt="wooCommerce" />
                              <img src={sync} alt="" />
                              <img className="logos" src={logo} alt="OriginScale" />
                            </div>
                            <div className="heading">Connect your WooCommerce account to originscale</div>
                          </div>

                        </div>
                      }
                    />
                  </form>
                </Col>
              </Row>
              <Row>
                <Col md={12}>
                  <Steps closeModal={handleClose}
                    syncWooCommerce={syncWooCommerce} shop={shop} importCustomers={importCustomers}
                    importProducts={importProducts} importOrders={importOrders} />
                </Col>
              </Row>
            </Grid>
          </div>
        </Modal.Body>
      </Modal>

      <div className="intg-main-wrapper">
        <div className="intg-acc-image">
          <img className="main-image" src={wooCommerce} />
        </div>
        <div className="intg-acc-status">
          {message}
        </div>
        <div className="intg-control-wrapper">
          <div className="intg-control">
            <div className="read-more-wrapper">
              Read more
            </div>
            <Button className="btn-save btn-fill btn btn-default connect-now-btn" onClick={connectHandler}>
              {isConnected ? "disconnect" : "connect now"}
            </Button>
            <Button className={isConnected ? "btn-save btn-fill btn btn-default connect-now-btn" : "disabled connect-now-btn"}
              disabled={isConnected ? false : true} onClick={syncHandler}>
              sync
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};


function mapStateToProps(state, ownProps) {
  return {
    userProfile: state.user.userProfile,
  };
}

const mapDispatchToProps = dispatch => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(WooCommerce);