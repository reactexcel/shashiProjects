import React, { Component } from "react";
import { Grid, Row, Col, Tabs, Tab, FormGroup, ControlLabel, Suspense } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import { connect } from "react-redux";
import { setAjaxCallStatus } from "../../../actions/ajaxStatusActions";
import { createQboToken, quickbookAccount, saveQuickbookSetting, syncQuickbookCustomer, syncQuickbookVendor, getQuickbookTaxCode, setQuickbookTax } from "../actions/integrationActions";
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import CommonUtil from "../../common/util/commonUtil";
import PopupUtil from "../../common/util/popupUtil";
import TextBoxUtil from "../../common/util/textBoxUtil";
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import StepZilla from "react-stepzilla";
import quickbook from "assets/img/quickbook.png";
import logo from "assets/img/logo-1.png";
import sync from "assets/img/sync.png";

import Step1 from "../components/quickbooks/Step1.js";
import Step2 from "../components/quickbooks/Step2.js";
import Step3 from "../components/quickbooks/Step3.js";
import Step4 from "../components/quickbooks/Step4.js";

var Modal = require('react-bootstrap-modal');

class QuickBookModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      openModal: false,
      qboAccount: null,
      qboTaxCode: null,
      importCustomer: false,
      importSupplier: false,
      error: false,
      errortext: '',
      dataDictionaryList: null,
    };
    this.handlePopupClose = this.handlePopupClose.bind(this);
    this.getQboAccount = this.getQboAccount.bind(this);
    this.getQbotaxdetails = this.getQbotaxdetails.bind(this);
  }

  componentDidMount = () => {
    this.setState({ openModal: true });
    var params = this.props.qboParams
    this.props.createQboToken(params);
  };

  componentDidUpdate(prevProps, prevState) {
    if (this.props.qboAccount != null && prevProps.qboAccount != this.props.qboAccount) {
      this.setState({qboAccount: this.props.qboAccount});
    }
    if (this.props.qboTaxCode != null && prevProps.qboTaxCode != this.props.qboTaxCode) {
      this.setState({qboTaxCode: this.props.qboTaxCode});
    }
    if (this.props.dataDictionaryList != null && prevProps.dataDictionaryList != this.props.dataDictionaryList) {
      this.setState({dataDictionaryList: this.props.dataDictionaryList});
    }
    if (this.state.importCustomer == true && this.state.importSupplier == false) {
      if (this.props.qboDataCustomer != null && prevProps.qboDataCustomer != this.props.qboDataCustomer) {
        if(this.props.qboDataCustomer == "success") {
          this.closeModal();
        } else {
          this.setState({error: true, errortext: "Customer import failed"  });
        }
      }
    }
    if (this.state.importCustomer == false && this.state.importSupplier == true) {
      if (this.props.qboDataCustomer != null && prevProps.qboDataCustomer != this.props.qboDataCustomer) {
        if(this.props.qboDataVendor == "success") {
          this.closeModal();
        } else {
          this.setState({error: true, errortext: "Supplier import failed" });
        }
      }
    }
    if (this.state.importCustomer == true && this.state.importSupplier == true) {
      if ((this.props.qboDataCustomer != null) && (this.props.qboDataVendor != null)) {
        if((this.props.qboDataCustomer == "success") && (this.props.qboDataVendor == "success")) {
          this.closeModal();
        } else if ((this.props.qboDataCustomer != "success") && (this.props.qboDataVendor == "success")) {
          this.setState({error: true, errortext: "Customer import failed"  });
        } else if ((this.props.qboDataCustomer == "success") && (this.props.qboDataVendor != "success")) {
          this.setState({error: true, errortext: "Supplier import failed"  });
        } else {
          this.setState({error: true, errortext: "Customer and Supplier both import failed" });
        }
      }
    }
  }

  getSelectedParams = (selectedparams) => {
    this.props.saveQuickbookSetting(selectedparams);
    this.getQboAccount();
    if(this.props.qboToken && this.props.qboToken.countryCode != "US") {
      this.getQbotaxdetails();
    }
  }

  getQboAccount = () => {
    this.props.quickbookAccount();
  }

  getQbotaxdetails = () => {
    this.props.getQuickbookTaxCode();
    this.props.getDataDictionaryDetails();
  }

  handlePopupClose = () => {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false });
  }

  closeModal = () => {
    this.props.getCompleteDetails(true);
    this.setState({ openModal: false });
  }

  dataSyncCustomer = (selectedparams) => {
    this.setState({importCustomer: true});
    this.props.syncQuickbookCustomer(selectedparams);
  }

  dataSyncVendor = (selectedparams) => {
    this.setState({importSupplier : true});
    this.props.syncQuickbookVendor(selectedparams);
  }

  qboTaxMapping = (params) => {
    this.props.setQuickbookTax(params);
    this.getQbotaxdetails();
  }

  render() {
    return (
      <Modal className="modal-wrapper" show={this.state.openModal} onHide={this.handlePopupClose} backdrop="static" keyboard={false} className="integrations-modal">
        <Modal.Header closeButton className="intg-modal-close-btn">
        </Modal.Header>
        <Modal.Body>
          <div className="main-content integration-modal">
            <Grid fluid>
              <Row>
                <Col md={12}>
                  <form>
                    <Card
                      content={
                        <div className="header-section">
                          <div className="logo-section">
                            <img className="logos" src={quickbook} alt="quickbook" />
                            <img src={sync} alt="" />
                            <img className="logos" src={logo} alt="OriginScale" />
                          </div>
                          <div className="heading">Connect Quickbooks account to originscale</div>
                        </div>
                      }
                    />
                  </form>
                </Col>
              </Row>
              <Row>
                <Col md={12}>
                  <Card
                    wizard
                    id="wizardCard"
                    content={
                      <div className='step-progress'>
                        {this.props.qboToken && this.props.qboToken.countryCode == "US" ?
                          <StepZilla
                            steps={[
                              { name: "Overview", component: <Step1 handlePopupClose={this.handlePopupClose} getQboAccount={this.getQboAccount}/> },
                              { name: "Ledger accounts mapping", component: <Step2 qboAccount={this.props.qboAccount} getSelectedParams={this.getSelectedParams} /> },
                              { name: "Data import", component: <Step4 dataSyncCustomer={this.dataSyncCustomer} dataSyncVendor={this.dataSyncVendor} /> },
                            ]}
                            stepsNavigation={false}
                            nextButtonText={"Continue"}
                            backButtonText={"Previous"}
                            backButtonCls="btn btn-cancel"
                            nextButtonCls="btn btn-save btn-fill"
                          />
                        : <StepZilla
                            steps={[
                              { name: "Overview", component: <Step1 handlePopupClose={this.handlePopupClose} getQboAccount={this.getQboAccount} /> },
                              { name: "Ledger accounts mapping", component: <Step2 qboAccount={this.state.qboAccount} getSelectedParams={this.getSelectedParams} /> },
                              { name: "Tax types mapping", component: <Step3 qboTaxCode={this.state.qboTaxCode} dataDictionaryList={this.state.dataDictionaryList} qboTaxMapping={this.qboTaxMapping} /> },
                              { name: "Data import", component: <Step4 dataSyncCustomer={this.dataSyncCustomer} dataSyncVendor={this.dataSyncVendor} handlePopupClose={this.handlePopupClose} /> },
                            ]}
                            stepsNavigation={false}
                            nextButtonText={"Continue"}
                            backButtonText={"Previous"}
                            backButtonCls="btn btn-cancel"
                            nextButtonCls="btn btn-save btn-fill"
                          />
                        }
                        {this.state.error == true ?
                          <small className="text-danger">
                            {this.state.errortext}
                          </small>
                          : null
                        }
                      </div>
                    }
                  />
                </Col>
              </Row>
            </Grid>
          </div>
        </Modal.Body>
      </Modal>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    qboToken: state.integration.qboToken,
    qboAccount: state.integration.qboAccount,
    qboAccountSetting: state.integration.qboAccountSetting,
    qboDataCustomer: state.integration.qboDataCustomer,
    qboDataVendor: state.integration.qboDataVendor,
    qboTaxCode: state.integration.qboTaxCode,
    setQboTaxMapping: state.integration.setQboTaxMapping,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
  };
}

const mapDispatchToProps = (dispatch) => ({
  createQboToken: params => dispatch(createQboToken(params)),
  quickbookAccount: () => dispatch(quickbookAccount()),
  saveQuickbookSetting: params => dispatch(saveQuickbookSetting(params)),
  syncQuickbookCustomer: params => dispatch(syncQuickbookCustomer(params)),
  syncQuickbookVendor: params => dispatch(syncQuickbookVendor(params)),
  getQuickbookTaxCode: () => dispatch(getQuickbookTaxCode()),
  setQuickbookTax: params => dispatch(setQuickbookTax(params)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
});
export default connect(mapStateToProps, mapDispatchToProps)(QuickBookModal);
