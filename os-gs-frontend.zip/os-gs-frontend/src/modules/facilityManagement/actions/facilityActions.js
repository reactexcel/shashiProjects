import axios from '../../../axios/axios';
import * as facilityActionTypes from './facilityActionTypes';
import * as facilityConstant from '../constant/facilityConstant';
import * as actionTypes from '../../../actions/actionTypes';
import {
  beginAjaxCall, endAjaxCall, setAjaxCallStatus, updateApiResponse,
  createApiResponse, failedApiResponse
} from "../../../actions/ajaxStatusActions";
import CommonUtil from '../../common/util/commonUtil';

export function setReducerInitMode() {
  return function (dispatch) {
    dispatch({
      type: facilityActionTypes.SET_FACILITY_REDUCER_INIT_MODE,
      payload: null
    });
  }
}

export function setFacilityDetails(facilityDetailsObj, actionMode, facilityId) {
  if (CommonUtil.isCreateOrCloneMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.post(facilityConstant.SET_CREATE_FACILITY_DETAILS_URL, facilityDetailsObj).then(response => {
        dispatch(setAjaxCallStatus(createApiResponse(response)));
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
      });
    };
  }
  if (CommonUtil.isEditMode(actionMode)) {
    return function (dispatch) {
      dispatch(beginAjaxCall());
      axios.put(facilityConstant.SET_UPDATE_FACILITY_DETAILS_URL + facilityId,
        facilityDetailsObj).then(response => {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch(endAjaxCall());
        }).catch(error => {
          dispatch(endAjaxCall());
          dispatch(setAjaxCallStatus(failedApiResponse(error)));
        });
    };
  }
}

export function setSelectedFacilityCode(selectedFacilityCode) {
  return function (dispatch) {
    dispatch({
      type: facilityActionTypes.SET_SELECTED_FACILITY_CODE,
      payload: selectedFacilityCode
    });
  }
}

export function getFacilityList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(facilityConstant.GET_FACILITY_LIST_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: facilityActionTypes.GET_FACILITY_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function setFacilityDocuments(documentObj, documentIdObj) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    let headers = {
      'Content-Type':'application/x-www-form-urlencoded'
    }
    axios.post(facilityConstant.SET_FACILITY_DOCUMENTS_URL, documentObj).then(response => {
      if (response.status == 201) {
        documentIdObj.documentURL = response.data;
        dispatch({
          type: facilityActionTypes.SET_UPLOADED_FILE_URL,
          payload: documentIdObj
        });
      }
      else {
        dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(setAjaxCallStatus(actionTypes.API_FAILED_RESPONSE));
      dispatch(endAjaxCall());
    });
  };
}

export function getFacilityDetails(selectedFacilityCode) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(facilityConstant.GET_FACILITY_DETAILS_URL + selectedFacilityCode).then(response => {
      if (response.status == 200) {
        dispatch({
          type: facilityActionTypes.GET_FACILITY_DETAILS,
          payload: response.data[0]
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
    });
  };
}

export function updateFacilityStatus(facilityDetailsObj, facilityId) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.patch(facilityConstant.SET_UPDATE_FACILITY_STATUS_URL +
      facilityId, facilityDetailsObj).then(response => {
        if (response.status == 200) {
          axios.get(facilityConstant.GET_FACILITY_LIST_URL).then(response => {
            if (response.status == 200) {
              dispatch({
                type: facilityActionTypes.GET_FACILITY_LIST,
                payload: response.data
              })
            }
            dispatch(endAjaxCall());
          })
        }
      }).catch(error => {
        dispatch(endAjaxCall());
      });
  };
}

export function setBulkFacilities(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.post(facilityConstant.SET_CREATE_BULK_FACILITY_URL, params).then(response => {
        if (response.status == 200) {
          dispatch(setAjaxCallStatus(updateApiResponse(response)));
          dispatch({
            type: actionTypes.SET_UPLOAD_IMPORT_FILE_STATUS,
            payload: response.data.uploadDetails
          });
        }
        dispatch(endAjaxCall());
      }).catch(error => {
        dispatch(endAjaxCall());
        dispatch(setAjaxCallStatus(failedApiResponse(error)));
        throw error;
      });
  };
}

export function getFacilitySearchList(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(facilityConstant.GET_FACILITY_SEARCH_URL, { params: params }).then(response => {
      if (response.status == 200) {
        dispatch({
          type: facilityActionTypes.GET_FACILITY_LIST,
          payload: response.data
        });
      }
      dispatch(endAjaxCall());
    }).catch(error => {
      dispatch(endAjaxCall());
      throw error;
    });
  };
}

export function getCapacityReport(params) {
  return function (dispatch) {
    dispatch(beginAjaxCall());
    axios.get(facilityConstant.GET_CAPACITY_REPORT_URL, { params: params }).then((response) => {
      if (response.status == 200) {
        dispatch({
          type: facilityActionTypes.GET_CAPACITY_REPORT,
          payload: response.data,
        });
      }
      dispatch(endAjaxCall());
    })
      .catch((error) => {
        dispatch(endAjaxCall());
        throw error;
      });
  };
}