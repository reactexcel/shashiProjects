import React, { Component } from "react";
import { Grid, Row, Col, FormControl, Nav, NavDropdown, MenuItem, FormGroup, ControlLabel, Form } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import Card from "components/Card/Card.jsx";
import * as facilityConstant from '../constant/facilityConstant';
import Button from "../../../components/CustomButton/CustomButton.jsx";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import { connect } from "react-redux";
import { setSelectedFacilityCode, getFacilityList, updateFacilityStatus, getFacilitySearchList } from "../actions/facilityActions";
import CommonUtil from '../../common/util/commonUtil';
import { setActionMode } from "../../../actions/appActions";
import * as commonConstant from '../../common/constant/commonConstant';
import { getDataDictionaryDetails } from '../../dataDictionary/actions/dataDictionaryActions';
import PaginationUtil from '../../common/util/paginationUtil';
import Table from '../../../views/Tables/PopularTable/Table/Table';
import isAuthorized from "auth-plugin";
import { getUserProfile } from "../../userManagement/actions/userActions";
import facility from "assets/img/facility-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import TextBoxUtil from '../../common/util/textBoxUtil';
import check from "assets/img/check.svg";

class ManageFacility extends Component {

  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      searchInput: "",
      selectedFilter: "",
      alert: null,
      redirect: false,
      redirectUrl: null,
      facilityId: null,
      status: null,
      search: null,

      nextClick: false,
      previousClick: false,
      nextClickDisable: true,
      previousClickDisable: true,
      pageSize: 1,
      currentPage: 1,
      lastEvaluatedKeyArray: []
    };
    this.handleFIlter = this.handleFIlter.bind(this);
    this.handleEditClone = this.handleEditClone.bind(this);
    this.handleMenuPopupAction = this.handleMenuPopupAction.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleStatusAction = this.handleStatusAction.bind(this);
    this.makeCustomAPICall = this.makeCustomAPICall.bind(this);
    this.dropdownToggle = this.dropdownToggle.bind(this);
    this.menuItemClickedThatShouldntCloseDropdown = this.menuItemClickedThatShouldntCloseDropdown.bind(this);
    this.handleRemoveFilter = this.handleRemoveFilter.bind(this);
  }


  componentDidMount = () => {
      mixpanel.track("Manage facility loaded");
    this.props.getUserProfile();
    if (CommonUtil.isNullValue(this.props.dataDictionaryList)) {
      this.props.getDataDictionaryDetails();
    }
    this.setSelectedTabDetails();
  }

  setSelectedTabDetails = async () => {
    const searchAttributeList = pagePropertyListConstant["ADVANCE_SEARCH_LIST"](this);
    var additionalParams = {};
    let managePageList = null;
    if(this.props.track == "lot") {
      managePageList = pagePropertyListConstant.MANAGE_FACILITY_LOT_PAGE_LIST(this);
    } else {
      managePageList = pagePropertyListConstant.MANAGE_FACILITY_PAGE_LIST(this);
    }
    const { search } = this.state;
    additionalParams["search"] = search;
    await this.setState({
      tableColumnList: managePageList.tableColumnList,
      tableConfig: managePageList.tableConfig,
      additionalParams: additionalParams,
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(searchAttributeList.attributeList, this.props.dataDictionaryList),
      attributeObj: searchAttributeList.attributeObj,
    })
    this.makeCustomAPICall(PaginationUtil.getPaginationParams(1,
      managePageList.tableConfig.defaultPageSize, this));
  };

  componentDidUpdate(prevProps) {
    if (prevProps.facilityList != this.props.facilityList && this.props.facilityList != null) {
      PaginationUtil.handlePagination(this.props.facilityList, this);
    }
  }

  handleChange = (event) => {
    this.setState({ searchInput: event.target.value }, () => {
      this.globalSearch();
    });
  }

  globalSearch = () => {
    let { searchInput } = this.state;
    let filteredData = this.props.facilityList.filter(value => {
      return (
        String(value.facilityId).includes(searchInput) ||
        value.facilityName.toLowerCase().includes(searchInput.toLowerCase())
      );
    });
    this.setState({ tableDataList: filteredData });
  }

  handleFIlter = (event) => {
    let filteredData = this.props.facilityList.filter(value => {
      if (event !== '') {
        return (
          value.status.toLowerCase() == event.toLowerCase()
        );
      }
      return (value);
    });

    this.setState({
      tableDataList: filteredData,
      selectedFilter: event
    });
  }

  dropdownToggle = (newValue) => {
    if (this._forceOpen) {
      this.setState({ menuOpen: true });
      this._forceOpen = false;
    } else {
      this.setState({ menuOpen: newValue });
    }
  }
  menuItemClickedThatShouldntCloseDropdown = () => {
    this._forceOpen = true;
  }

  advanceSearch = async () => {
    if(CommonUtil.isNotNull(this.state.searchInput)) {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: this.state.searchInput.trim() });
      this.setSelectedTabDetails();
      this.setState({ menuOpen: false });
    }
  }

  handleSubmit = (event) => {
    event.preventDefault();
    this.advanceSearch();
  }

  // closeSearchBox = () => {
  //   this.state.attributeObj.orderNumber = '';
  //   this.setState({ menuOpen: false });
  // }

  handleEditClone = (id) => {
    var tempId = id.split("_");
    this.props.setSelectedFacilityCode(tempId[0]);
    this.props.setActionMode(tempId[1]);
    CommonUtil.handlePageRedirection(facilityConstant.CREATE_FACILITY_PAGE_URL, this);
  }


  handleMenuPopupAction = (event) => {
    var tempId = event.target.id.split("_");

    if (tempId[2] == facilityConstant.CREATE_FACILITY) {
      this.props.setActionMode(commonConstant.CREATE_ACTION_MODE);
      CommonUtil.handlePageRedirection(facilityConstant.CREATE_FACILITY_PAGE_URL, this);
    }

  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handleStatusAction(facilityId, status) {
    var tempObj = {};
    var facilityId = facilityId ? facilityId : this.state.facilityId;
    tempObj.status = status ? status : this.state.status;
    this.setState({ alert: null });
    this.props.updateFacilityStatus(tempObj, facilityId);
  }

  makeCustomAPICall(tempParamas) {
    if (CommonUtil.isNotNull(tempParamas.search)) {
      this.props.getFacilitySearchList(tempParamas);
    } else {
      this.props.getFacilityList(tempParamas);
    }
  }

  getTdProps = (event) => {
    var tempId = event.target.id.split("_");

    if (CommonUtil.isNotNull(tempId) && CommonUtil.isEditOrCloneMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isViewMode(tempId[1])) {
      this.handleEditClone(event.target.id);
    }
    if (CommonUtil.isNotNull(tempId) && CommonUtil.isMenuMode(tempId[1])) {
      CommonUtil.overlay(event);
      this.handleMenuPopupAction(event);
    }
  }

  handleRemoveFilter = async (event) => {
    var id = event != undefined ? event.target.id : null;
    var tempId = id !== null ? id.split("-") : null;
    if (tempId[1] === "search") {
      PaginationUtil.initPaginationParams(this);
      await this.setState({ search: null, searchInput: ""});
      await this.setSelectedTabDetails(this.state.status);
    }
  }

  render() {
    const { tableColumnList, tableDataList, tableConfig, attributeList, attributeObj, submitted, search } = this.state;
    return (
      <div className="main-content manage-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}
        <Grid fluid>
          <Row className="top-row">
            <div className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={facility} alt="" className="page-icon" />
                  {facilityConstant.MANAGE_FACILITY_HEADER_TITLE}
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  <div className="search-section advance">
                    <form onSubmit={this.handleSubmit}>
                      <i className="fa fa-search"></i>
                      <FormControl type="text" name="searchInput" placeholder="Search By Facility Code/Name"
                        value={this.state.searchInput} onChange={this.handleChange} />
                    </form>
                  </div>

                  <div className="advance-filter">
                    <div className="submit-btn" style={CommonUtil.isNullValue(this.state.searchInput) ? {cursor: 'default'} : null}>
                      <img src={check} onClick={this.advanceSearch} alt="submit" />
                    </div>
                  </div>

                  {/*<Nav pullRight className="advance-filter">
                    <NavDropdown title={<div className="filter"> <i className="fa fa-ellipsis-v"></i>  </div>}
                      noCaret id="search-filter" className="filter-search filter-form" open={this.state.menuOpen} onToggle={val => this.dropdownToggle(val)}>
                      <MenuItem onClick={() => this.menuItemClickedThatShouldntCloseDropdown()} className="default-cursor no-hover">
                        <Form horizontal>
                          <Row>
                            {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                              tempAttributeListObj.type == "TEXTBOX" ?
                                TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this)
                                : null))
                            }
                          </Row>
                        </Form>
                      </MenuItem>
                      <div className="search-btns">
                        <Button className="btn-cancel" onClick={this.closeSearchBox}>
                          Cancel
                        </Button>
                        <Button className="btn-save btn-fill btn-wd" onClick={this.advanceSearch}>
                          Search
                        </Button>
                      </div>
                    </NavDropdown>
                  </Nav>*/}

                { isAuthorized("createFacility") &&
                  <Button id={"facilityId" + "_" + commonConstant.MENU_ACTION_MODE + "_" +
                    facilityConstant.CREATE_FACILITY}
                    fill wd className="create-options btn-default btn-fill btn-wd"
                    onClick={this.handleMenuPopupAction.bind(this)}>
                    Create
                  </Button>
                }
                </div>
              </Col>
            </div>
          </Row>
          <Row>
            <Col md={12}>
              <Card
                content={
                  <div>
                    {search ?
                      <div className="showfilter">
                        Search / Filter by:
                          {search ? 
                            <div className="filtertag">{search} <i id="filter-search" onClick={(event) => this.handleRemoveFilter(event)} className="fa fa-close" /></div>
                          : null }
                      </div>
                    : null }
                    {tableColumnList != null ?
                      <Row>
                        {(tableDataList != null && tableDataList.length > 0) || this.state.currentPage != 1 ?
                          <Table columns={tableColumnList}
                            data={tableDataList}
                            config={tableConfig}
                            getRowProps={this.getTdProps}
                            that={this}
                          />
                          : <Col md={12}><div className="no-record">No Record Found</div></Col>}
                      </Row>
                      : <Row><Col md={12}><div className="no-record">No Record Found</div></Col></Row>}
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    facilityList: state.facility.facilityList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    permissionMapping: state.security.uiComponentsPermissionMapping,
    userProfile: state.user.userProfile,
    facilitySearchList: state.facility.facilityList,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    track: state.dataDictionary.track,
  };
}

const mapDispatchToProps = dispatch => ({
  setSelectedFacilityCode: selectedFacilityCode => dispatch(setSelectedFacilityCode(selectedFacilityCode)),
  setActionMode: actionMode => dispatch(setActionMode(actionMode)),
  getFacilityList: id => dispatch(getFacilityList(id)),
  updateFacilityStatus: (facilityDetails, facilityId) => dispatch(updateFacilityStatus(facilityDetails, facilityId)),
  getDataDictionaryDetails: selectedDataDictionaryCode => dispatch(getDataDictionaryDetails(selectedDataDictionaryCode)),
  getUserProfile: actionMode => dispatch(getUserProfile(actionMode)),
  getFacilitySearchList: params => dispatch(getFacilitySearchList(params)),
});

export default connect(mapStateToProps, mapDispatchToProps)(ManageFacility);
