import React, { Component } from "react";
import { Grid, Row, Col, FormGroup } from "react-bootstrap";
import Card from "../../../components/Card/Card.jsx";
import Button from "../../../components/CustomButton/CustomButton.jsx";
import DragDrop from "../../../components/DragDrop/DragDrop.jsx";
import { connect } from "react-redux";
import { Redirect } from "react-router-dom";
import { setFacilityDetails, getFacilityDetails, setReducerInitMode, getFacilityList } from "../actions/facilityActions";
import * as pagePropertyListConstant from '../constant/pagePropertyConstant';
import * as facilityConstant from '../constant/facilityConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import { setAjaxCallStatus } from '../../../actions/ajaxStatusActions';
import ValidationUtil from '../../common/util/validationUtil';
import CommonUtil from '../../common/util/commonUtil';
import PopupUtil from '../../common/util/popupUtil';
import LocationUtil from "modules/common/util/locationUtil.js";
import TextBoxUtil from '../../common/util/textBoxUtil';
import DropDownUtil from "modules/common/util/dropDownUtil.js";
import CheckBoxUtil from '../../common/util/checkBoxUtil';
import LabelUtil from '../../common/util/labelUtil';
import facility from "assets/img/facility-page-icon.svg";
import mixpanel from "../../analytics/mixpanel/mixpael";
import Table from '../../../views/Tables/PopularTable/Table/Table';
import PopularTableUtil from '../../common/util/popularTableUtil';
import pin from "assets/img/pin.svg";
import PaginationUtil from '../../common/util/paginationUtil';
import Select from "react-select";
import map from "lodash/map";
import { v4 as uuidv4 } from 'uuid';
import { getUserList } from "../../userManagement/actions/userActions";
import _ from 'lodash';

class CreateFacility extends Component {
  constructor(props) {
    super(props);
    this.state = {
      attributeList: null,
      attributeObj: null,
      facilityId: null,
      submitted: false,
      alert: null,
      isFacilityUsageNotSelected: false,
      selectedTab: "FACILITY",
      facilityTableKey: "resources",
      resources: [],
      facilityList: [],
      allList: [{ label: 'All', value: '' }],
      locationName: "Select Location",
    };

    this.handleSave = this.handleSave.bind(this);
    this.getDocumentDetails = this.getDocumentDetails.bind(this);
    this.handleLocationTextChange = this.handleLocationTextChange.bind(this);
    this.handleLocationDropDownChange = this.handleLocationDropDownChange.bind(this);
    this.handleLocationChange = this.handleLocationChange.bind(this);
    this.handlePopupContinue = this.handlePopupContinue.bind(this);
    this.handlePopupCancel = this.handlePopupCancel.bind(this);
    this.handleAjaxResponse = this.handleAjaxResponse.bind(this);
  }

  componentDidMount = () => {
    mixpanel.track("Create facility loaded");
    if (CommonUtil.isNotNull(this.props.actionMode)) {
      if (!CommonUtil.isCreateMode(this.props.actionMode)) {
        this.props.getFacilityDetails(this.props.selectedFacilityCode);
      }
    }
    else {
      CommonUtil.handlePageRedirection(facilityConstant.MANAGE_FACILITY_PAGE_URL, this);
    }
    this.props.getUserList();
    if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
      let attributeObj = pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST.attributeObj;
      attributeObj.storage = true;
      if (this.props.track == "lot") {
        attributeObj.source = true;
        attributeObj.sale = true;
      }
    }
    this.props.getFacilityList();
    const tableAttributeList = pagePropertyListConstant["CREATE_FACILITY_RESOURCE_MANAGAMENT_TABLE_LIST"](this);
    let tableColumnList = tableAttributeList.tableColumnList;
    let pageList = [];
    if (this.props.track == "lot") {
      pageList = pagePropertyListConstant.CREATE_FACILITY_LOT_PAGE_LIST;
    } else {
      pageList = pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST;
    }

    this.setState({
      attributeList: CommonUtil.getDropDownOptionsFromDictionary(
        pageList.attributeList, this.props.dataDictionaryList),
      attributeListLocation: LocationUtil.getCountryList(
        pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST.attributeListLocation),
      attributeObj: pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST.attributeObj,
      locationAttributeObj: pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST.locationAttributeObj,
      attributeListFacilityUsage: pagePropertyListConstant.CREATE_FACILITY_PAGE_LIST.attributeListFacilityUsage,
      tableColumnList: tableColumnList,
      tableConfig: tableAttributeList.tableConfig,
      attributeListDocuments: commonConstant.FILEUPLOAD_STAGE_LIST.attributeList,
    })
  }

  componentDidUpdate(prevProps, prevState) {
    if (this.props.attributeObj != null && prevProps.attributeObj != this.props.attributeObj) {
      this.updateApiData(this.props.attributeObj);
    }
    if (this.props.ajaxCallStatus != null && prevProps.ajaxCallStatus != this.props.ajaxCallStatus) {
      this.handleAjaxResponse();
    }
    if (prevProps.userList !== this.props.userList && this.props.userList !== null) {
      this.updateUserDropDownList();
    }
  }

  updateUserDropDownList = () => {
    let tempUserList = [];
    tempUserList.Items = this.props.userList.filter(value => {
      if (value.status && value.status.toLowerCase() == "confirmed") {
        return (value);
      }
      return;
    });
    this.setState({
      ownerList: CommonUtil.getDropDownOptionsFromTableList(tempUserList, 'firstName', 'email'),
    })
  }

  componentWillUnmount() {
    this.props.setReducerInitMode(null);
  }

  handleSave(event) {
    this.setState({ submitted: true });
    const { attributeObj } = this.state;
    var tempObj = _.cloneDeep(attributeObj);
    const facilityId = attributeObj.facilityId ? attributeObj.facilityId : "";
    delete tempObj.facilityId;
    delete tempObj.businessId;
    var tempActionMode = this.props.actionMode != null ? this.props.actionMode :
      commonConstant.CREATE_ACTION_MODE;

    tempObj = ValidationUtil.removeAttributeFromRequestObj(tempObj,
      this.state.attributeList, tempActionMode);

    const currentTab = this.getSelectedTablekey();
    // if (currentTab === "resources") {
    //   const resources = this.state[currentTab];
    //   const updatedResources = this.generateUniqueResource(resources);
    //   tempObj[currentTab] = updatedResources;
    // }
    if (this.isFacilityUsageSelected(tempObj) && ValidationUtil.validateCreateRequestObj(tempObj, this.state.attributeList)) {
      if (tempObj.locations.length > 0) {
        if (ValidationUtil.validateArrayListRequestObj(tempObj.locations,
          this.state.attributeListLocation)) {
          if (tempObj.documents.length > 0) {
            if (ValidationUtil.validateArrayListRequestObj(tempObj.documents,
              this.state.attributeListDocuments)) {
              delete tempObj.locations;
              this.props.setFacilityDetails(tempObj, tempActionMode, CommonUtil.getFloatValue(facilityId));
            }
          } else {
            delete tempObj.locations;
            this.props.setFacilityDetails(tempObj, tempActionMode, CommonUtil.getFloatValue(facilityId));
          }
        }
      }
    }
  }

  generateUniqueResource = (resources) => {
    const updatedResources = map(resources, (resource) => {
      if (!resource["resourceCode"]) {
        resource["resourceCode"] = uuidv4();
      }
      if (resource["isActive"] === undefined) {
        resource["isActive"] = true;
      }
      return resource;
    });
    return updatedResources;
  }

  isFacilityUsageSelected = (tempObj) => {
    if (tempObj.manufacturing || tempObj.storage || tempObj.sale || tempObj.source) {
      this.setState({ isFacilityUsageNotSelected: false });
      return true;
    }
    this.setState({ isFacilityUsageNotSelected: true });
    return false;
  }

  handleAjaxResponse() {
    if (this.props.ajaxCallStatus.status == "SUCCESS") {
      this.props.setAjaxCallStatus(null);

      if (CommonUtil.isCreateOrCloneMode(this.props.actionMode)) {
        this.props.handleClick(CommonUtil.prepareCreateSuccessPopUpConfig(
          CommonUtil.getGeneratedCodeFromReponse(this.props.ajaxCallStatus)));
      }
      else {
        this.props.handleClick(CommonUtil.prepareUpdateSuccessPopUpConfig());
      }
      setTimeout(this.handlePopupContinue, 0);
    }

    if (this.props.ajaxCallStatus.status == "FAILED") {
      PopupUtil.handleCustomErroMsg(this);
      this.props.setAjaxCallStatus(null);
    }
  }

  handlePopupCancel() {
    this.setState({ alert: null });
  }

  handlePopupContinue() {
    CommonUtil.handlePageRedirection(facilityConstant.MANAGE_FACILITY_PAGE_URL, this);
  }

  async updateApiData(attributeObj) {
    if (attributeObj) {
      await LocationUtil.populateStateList(this.state.attributeListLocation, attributeObj.country);
      await LocationUtil.populateCityList(this.state.attributeListLocation, attributeObj.state);
    }
    await this.setState({
      attributeObj: {
        ...attributeObj,
        facilityId: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.facilityId,
        facilityName: CommonUtil.isCloneMode(this.props.actionMode) ?
          '' : attributeObj.facilityName,
        documents: CommonUtil.isCloneMode(this.props.actionMode) ?
          [] : attributeObj.documents,
        locations: [
          {
            locationName: attributeObj && attributeObj.locationName ? attributeObj.locationName : '',
            address: attributeObj && attributeObj.address ? attributeObj.address : '',
            country: attributeObj && attributeObj.country ? attributeObj.country : '',
            state: attributeObj && attributeObj.state ? attributeObj.state : '',
            city: attributeObj && attributeObj.city ? attributeObj.city : '',
            zipcode: attributeObj && attributeObj.zipcode ? attributeObj.zipcode : '',
          }
        ]
        // sourceChannel: CommonUtil.isCloneMode(this.props.actionMode) ? commonConstant.ORIGINSCALE : attributeObj.sourceChannel
      },
      [this.getSelectedTablekey()]: attributeObj[this.getSelectedTablekey()] || [],
      locationAttributeObj: {
        locationName: attributeObj && attributeObj.locationName ? attributeObj.locationName : '',
        address: attributeObj && attributeObj.address ? attributeObj.address : '',
        country: attributeObj && attributeObj.country ? attributeObj.country : '',
        state: attributeObj && attributeObj.state ? attributeObj.state : '',
        city: attributeObj && attributeObj.city ? attributeObj.city : '',
        zipcode: attributeObj && attributeObj.zipcode ? attributeObj.zipcode : '',
      }, function() {
      }
    })
  }

  getDocumentDetails(documents) {
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        documents: [...documents]
      }
    })
  }

  async handleLocationTextChange(event) {
    await LocationUtil.updateLocationTextChange(event, this);
    this.handleLocationChange();
  }

  async handleLocationNumberChange(event) {
    await LocationUtil.updateLocationNumberChange(event, this);
    this.handleLocationChange();
  }

  async handleLocationDropDownChange(event, obj) {
    await LocationUtil.updateLocationDropDownChange(event, obj, this);
    this.handleLocationChange();
  }

  handleLocationChange() {
    var tempLocationList = [];
    tempLocationList.push({ ...this.state.locationAttributeObj });
    const { attributeObj } = this.state;
    this.setState({
      attributeObj: {
        ...attributeObj,
        locationName: tempLocationList[0].locationName,
        address: tempLocationList[0].address,
        country: tempLocationList[0].country,
        state: tempLocationList[0].state,
        city: tempLocationList[0].city,
        zipcode: tempLocationList[0].zipcode,
        locations: [...tempLocationList]
      }
    })
  }

  handleLocationDropdownChange = async (tempObj) => {
    PaginationUtil.initPaginationParams(this);
    await this.setState({
      location: tempObj.value, locationName: tempObj.label,
      tableDataList: [], selectedFilter: null
    });
  }

  getSelectedTablekey = (selectedTab) => {
    return this.state.facilityTableKey;
  }

  handleTableTextBoxChange = async (event) => {
    const index = parseInt(event.target.id.split('_')[1]);
    await PopularTableUtil.handleTableTextBoxChange(event, this, this.getSelectedTablekey());
    this.calculateTotalMenHoursForResource(index);
  }

  calculateTotalMenHoursForResource = (index) => {
    const existingResources = this.state[this.getSelectedTablekey()];
    const modifiedResource = existingResources[index];
    if (modifiedResource && modifiedResource["workingHours"] && modifiedResource["manPower"]) {
      const workingHours = parseInt(modifiedResource["workingHours"]);
      const manPower = parseInt(modifiedResource["manPower"]);
      const totalMenHours = workingHours * manPower;
      modifiedResource["totalMenHours"] = totalMenHours;
      existingResources[index] = modifiedResource;
      this.setState({ [this.getSelectedTablekey()]: existingResources });
    }
  }

  handleTableSwitchChange = async (event, state) => {
    await PopularTableUtil.handleTableSwitchChange(event, state, this, this.getSelectedTablekey());
    if (state === true) {
      const { attributeObj } = this.state;
      this.setState({ attributeObj: attributeObj });
    }
  }

  handleTableAddRow = (event) => {
    PopularTableUtil.handleTableAddRow(this, this.getSelectedTablekey());
  }

  handleTableMultiDropDownChange = (event, obj) => {
    PopularTableUtil.handleMultiTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  }
  handleTableDropDownChange = (event, obj) => {
    PopularTableUtil.handleTableDropDownChange(event, obj, this, this.getSelectedTablekey());
  };

  render() {
    const { attributeList, attributeListLocation, attributeObj,
      locationAttributeObj, submitted, attributeListFacilityUsage,
      customErrorFlag, tableColumnList, tableConfig } = this.state;
    const tableDataList = this.state[this.getSelectedTablekey()];
    const actionMode = this.props.actionMode;

    return (
      <div className="main-content create-page">
        {this.state.redirect === true ?
          <Redirect push to={this.state.redirectUrl}></Redirect> : null
        }
        {this.state.alert}

        <Grid fluid>
          <Row className="top-row">
            <Col md={12} className="header-section">
              <Col sm={4} md={4}>
                <div className="page-title">
                  <img src={facility} alt="" className="page-icon" />
                  {CommonUtil.isEditMode(actionMode) ?
                    facilityConstant.EDIT_FACILITY_HEADER_TITLE
                    : CommonUtil.isViewMode(actionMode) ?
                      facilityConstant.VIEW_FACILITY_HEADER_TITLE
                      : facilityConstant.CREATE_FACILITY_HEADER_TITLE
                  }
                </div>
              </Col>
              <Col xs={12} sm={8} md={8}>
                <div className="left-section">
                  {!CommonUtil.isViewMode(this.props.actionMode) ?
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                      <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                    </div>
                    :
                    <div className="page-control-buttons">
                      <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                    </div>}
                </div>
              </Col>
            </Col>
          </Row>
          <Row>
            <Col md={12}>
              <form>
                <Card
                  content={
                    <div>
                      <Row className="global-role">
                        {attributeList != null && attributeList.map((tempAttributeListObj, index) => (
                          tempAttributeListObj.type == "UNIQUE_CODE" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                            LabelUtil.labelAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "TEXTBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                              TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode, customErrorFlag)

                              : tempAttributeListObj.type == "DROPDOWN" ?
                                DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                : tempAttributeListObj.type == "CHECKBOX" && tempAttributeListObj[actionMode + 'ShowFlag'] == true ?
                                  CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)


                                  : null))
                        }
                      </Row>

                      <Row>
                        {attributeListLocation != null && attributeListLocation.map((tempAttributeListObj, index) => (

                          tempAttributeListObj.type == "TEXTBOX" ?
                            TextBoxUtil.locationTextBoxAttribute(tempAttributeListObj, index, locationAttributeObj, submitted, this, actionMode)

                            : tempAttributeListObj.type == "DROPDOWN" ?
                              DropDownUtil.locationDropDownAttribute(tempAttributeListObj, index, locationAttributeObj, submitted, this, actionMode)
                              : null))
                        }

                      </Row>
                      <Row>
                        <Col md={6}>
                          <Card
                            plain
                            title={facilityConstant.DOCUMENT_HEADER_TITLE}
                            content={
                              <DragDrop
                                minSize={0}
                                maxSize={5000000}
                                multiple={false}
                                disabled={CommonUtil.isViewMode(this.props.actionMode) ? true : false}
                                errormsg="File size exceed max size limit of 5 MB."
                                typeerror="File type is not accepted"
                                getdocumentdetails={this.getDocumentDetails}
                                files={attributeObj != null && attributeObj.documents.length > 0 ?
                                  attributeObj.documents : null}
                                fileNamePrefix={attributeObj != null && attributeObj.facilityId && _.isString(attributeObj.facilityId) ? parseInt(attributeObj.facilityId.split('-')[1]) : null}
                                moduleName="facility"
                              />
                            }
                          />
                        </Col>
                        <Col md={6}>
                          <Card
                            plain
                            title={facilityConstant.FACILITY_USAGE_HEADER_TITLE}
                            content={
                              <>
                                <div className="usage">
                                  {attributeListFacilityUsage != null && attributeListFacilityUsage.map((tempAttributeListObj, index) => (
                                    tempAttributeListObj.type == "CHECKBOX" ?
                                      <div className="product-checkbox check">
                                        {CheckBoxUtil.checkBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)}
                                      </div>
                                      :
                                      null))}
                                </div>
                                {this.state.isFacilityUsageNotSelected && submitted && <small className="text-danger">
                                  Please select atleast one facility usage.
                                </small>}
                                {attributeListFacilityUsage != null && attributeListFacilityUsage.map((tempAttributeListObj, index) => (
                                  tempAttributeListObj.type == "TEXTBOX_TAX" ?
                                    TextBoxUtil.textBoxAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)

                                    : tempAttributeListObj.type == "DROPDOWN" ?
                                      DropDownUtil.dropDownAttribute(tempAttributeListObj, index, attributeObj, submitted, this, actionMode)
                                      : null))}
                              </>
                            }
                          />
                        </Col>
                      </Row>
                      {this.state.attributeObj != null && (this.state.attributeObj.facilityType == "Production" && this.state.attributeObj.manufacturing == true) &&
                        <>
                          <Row>
                            <Col md={12}>
                              <div className="resoure-management-title">Facility Resource Managemnt</div>
                              <FormGroup className="location-dropdown">
                                <div className="location-control">
                                  <img src={pin} alt="" />
                                  <Select
                                    classNamePrefix="react-select"
                                    name="location"
                                    value={{ "label": this.state.locationName ? this.state.locationName : 'Select Location' }}
                                    onChange={(value) => this.handleLocationDropdownChange(value)}
                                    options={[...this.state.allList, ...this.state.facilityList]}
                                    placeholder="Select Location"
                                  />
                                </div>
                              </FormGroup>
                            </Col>
                          </Row>
                          <div>
                            {tableDataList != null ?
                              <Row>
                                {tableColumnList != null && tableColumnList.length > 0 ?
                                  <Table columns={tableColumnList}
                                    data={tableDataList}
                                    config={tableConfig}
                                    getRowProps={this.getTdProps}
                                    that={this}
                                  />
                                  : null}
                                <div className="add-new-section">
                                  <Col md={6}>
                                    {!CommonUtil.isViewMode(this.props.actionMode) ?
                                      <div className="add-row-button" onClick={(e) => this.handleTableAddRow(e)}>
                                        <i className=" fa fa-plus" />
                                        Add row
                                      </div>
                                      : null}
                                  </Col>
                                </div>
                              </Row>
                              : null
                            }
                          </div>
                        </>
                      }
                    </div>
                  }
                  ftTextRight
                  legend={
                    <>
                      {!CommonUtil.isViewMode(this.props.actionMode) ?
                        <div>
                          <Button className="btn-cancel" onClick={() => PopupUtil.popupCancel(this)}>Cancel</Button>
                          <Button className="btn-save btn-fill" onClick={this.handleSave}>Save</Button>
                        </div>
                        :
                        <Button className="btn-cancel" onClick={this.handlePopupContinue}>Back</Button>
                      }
                    </>
                  }
                />
              </form>
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

function mapStateToProps(state, ownProps) {
  return {
    attributeObj: state.facility.facilityDetails,
    selectedFacilityCode: state.facility.selectedFacilityCode,
    actionMode: state.app.actionMode,
    ajaxCallStatus: state.ajaxStatusReducer.ajaxCallStatus,
    dataDictionaryList: state.dataDictionary.dataDictionaryList,
    facilityList: state.facility.facilityList,
    track: state.dataDictionary.track,
    userList: state.user.userList,
  };
}

const mapDispatchToProps = dispatch => ({
  setFacilityDetails: (facilityDetailsObj, actionMode, facilityId) => dispatch(setFacilityDetails(facilityDetailsObj, actionMode, facilityId)),
  getFacilityDetails: selectedFacilityCode => dispatch(getFacilityDetails(selectedFacilityCode)),
  setAjaxCallStatus: ajaxCallStatus => dispatch(setAjaxCallStatus(ajaxCallStatus)),
  setReducerInitMode: init => dispatch(setReducerInitMode(init)),
  getFacilityList: (params) => dispatch(getFacilityList(params)),
  getUserList: (id) => dispatch(getUserList(id)),
});

export default connect(mapStateToProps, mapDispatchToProps)(CreateFacility);
