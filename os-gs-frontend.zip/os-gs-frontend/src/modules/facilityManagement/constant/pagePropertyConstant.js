import Button from "components/CustomButton/CustomButton.jsx";
import React from "react";
import { FormControl, InputGroup } from "react-bootstrap";
import Switch from "react-bootstrap-switch";
import * as  statusConstant from '../../common/constant/statusConstant';
import * as commonConstant from '../../common/constant/commonConstant';
import CommonUtil from '../../common/util/commonUtil';
import isAuthorized from "auth-plugin";
import Select from "react-select";

export const CREATE_FACILITY_PAGE_LIST = {
  attributeObj: {
    facilityType: "",
    // facilityId: "",
    facilityName: "",
    // status: statusConstant.ACTIVE_STATUS,
    // locations: [],
    documents: [],
    manufacturing: false,
    storage: false,
    sale: false,
    source: false,
    isTaxable: false,
    // sourceChannel: commonConstant.ORIGINSCALE
  },
  locationAttributeObj: {
    locationName: "",
    address: "",
    country: "",
    state: "",
    city: "",
    zipcode: "",
  },
  attributeList: [
    {
      name: "facilityId",
      type: "UNIQUE_CODE",
      label: "Facility Code",
      prefix: "FAC",
      required: false,
      inputType: "text",
      fieldWidth: 2,
      createMode: "disabled",
      createModeRemoveFlag: true,
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "facilityType",
      type: "DROPDOWN",
      label: "Type",
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "facilityTypeList",
      options: [],
    },
    {
      name: "facilityName",
      type: "TEXTBOX",
      label: "Name",
      required: true,
      fieldWidth: 3,
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 60,
      minLength: 3,
      mandatoryMsgText: "Field can not be empty.",
      customMessage: "Facility Name already exist."
    },
    {
      name: "isTaxable",
      type: "CHECKBOX",
      label: "Is Taxable",
      required: false,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      fieldWidth: 3,
    },
    {
      name: "documents",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "manufacturing",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "storage",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "sale",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "source",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "locationName",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "address",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "country",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "state",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "city",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "zipcode",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "locations",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },

  ],
  attributeListLocation: [
    {
      name: "locationName",
      type: "TEXTBOX",
      label: "Location Name",
      inputType: "text",
      required: true,
      fieldWidth: 6,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 32,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "address",
      type: "TEXTBOX",
      label: "Address",
      inputType: "text",
      required: true,
      fieldWidth: 6,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 100,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "country",
      type: "DROPDOWN",
      label: "Country",
      required: true,
      isCountry: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "state",
      type: "DROPDOWN",
      label: "State",
      required: true,
      fieldWidth: 3,
      isState: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "city",
      type: "DROPDOWN",
      label: "City",
      required: true,
      fieldWidth: 3,
      isCity: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "zipcode",
      type: "TEXTBOX",
      label: "Zip Code",
      minValue: 0,
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 15,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
  ],
  attributeListFacilityUsage: [
    {
      name: "manufacturing",
      type: "CHECKBOX",
      label: "Manufacturing",
      required: false,
      // fieldWidth: 4,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
    {
      name: "storage",
      type: "CHECKBOX",
      label: "Storage",
      required: false,
      // fieldWidth: 3,
      createMode: "disabled",
      editMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "disabled",
    },
    {
      name: "sale",
      type: "CHECKBOX",
      label: "Sale",
      required: false,
      // fieldWidth: 3,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
    {
      name: "source",
      type: "CHECKBOX",
      label: "Source",
      required: false,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
  ],

};

export const CREATE_FACILITY_LOT_PAGE_LIST = {
  attributeObj: {
    facilityType: "",
    facilityId: "",
    facilityName: "",
    availableCapacity: "",
    status: statusConstant.ACTIVE_STATUS,
    locations: [],
    documents: [],
    manufacturing: false,
    storage: false,
    sale: false,
    source: false,
    sourceChannel: commonConstant.ORIGINSCALE
  },
  locationAttributeObj: {
    locationName: "",
    address: "",
    country: "",
    state: "",
    city: "",
    zipcode: "",
  },
  attributeList: [
    {
      name: "facilityId",
      type: "UNIQUE_CODE",
      label: "Facility Code",
      prefix: "FAC",
      required: false,
      inputType: "text",
      fieldWidth: 2,
      createMode: "disabled",
      createModeRemoveFlag: true,
      cloneModeRemoveFlag: true,
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      cloneMode: "disabled",
      editMode: "disabled",
      viewMode: "disabled",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "facilityType",
      type: "DROPDOWN",
      label: "Type",
      required: true,
      fieldWidth: 4,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      placeholder: "Select",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      dataDictionaryFlag: true,
      dataDictionaryId: "facilityTypeList",
      options: [],
    },
    {
      name: "facilityName",
      type: "TEXTBOX",
      label: "Name",
      required: true,
      fieldWidth: 3,
      inputType: "text",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 60,
      minLength: 3,
      mandatoryMsgText: "Field can not be empty.",
      customMessage: "Facility Name already exist."
    },
    {
      name: "availableCapacity",
      type: "TEXTBOX",
      label: "Available Capacity",
      required: true,
      fieldWidth: 3,
      inputType: "number",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 10,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "status",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
    },
    {
      name: "version",
      type: "TEMP",
      createModeShowFlag: false,
      cloneModeShowFlag: false,
      editModeShowFlag: true,
    },
    {
      name: "locations",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "documents",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "facilityUsage",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "manufacturing",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "storage",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "sale",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "source",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
    {
      name: "sourceChannel",
      type: "TEMP",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
    },
  ],
  attributeListLocation: [
    {
      name: "locationName",
      type: "TEXTBOX",
      label: "Location Name",
      inputType: "text",
      required: true,
      fieldWidth: 6,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 32,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "address",
      type: "TEXTBOX",
      label: "Address",
      inputType: "text",
      required: true,
      fieldWidth: 6,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 100,
      minLength: 1,
      mandatoryMsgText: "Field can not be empty.",
    },
    {
      name: "country",
      type: "DROPDOWN",
      label: "Country",
      required: true,
      isCountry: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "state",
      type: "DROPDOWN",
      label: "State",
      required: true,
      fieldWidth: 3,
      isState: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "city",
      type: "DROPDOWN",
      label: "City",
      required: true,
      fieldWidth: 3,
      isCity: true,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      mandatoryMsgText: "Field can not be empty.",
      options: [],
    },
    {
      name: "zipcode",
      type: "TEXTBOX",
      label: "Zip Code",
      minValue: 0,
      required: true,
      fieldWidth: 3,
      createMode: "enable",
      cloneMode: "enable",
      editMode: "enable",
      viewMode: "disabled",
      placeholder: "",
      numberOfRow: 0,
      maxLength: 15,
      minLength: 3,
      mandatoryMsgText: "Field can not be empty.",
    },
  ],
  attributeListFacilityUsage: [
    {
      name: "manufacturing",
      type: "CHECKBOX",
      label: "Manufacturing",
      required: false,
      // fieldWidth: 4,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
    {
      name: "storage",
      type: "CHECKBOX",
      label: "Storage",
      required: false,
      // fieldWidth: 3,
      createMode: "disabled",
      editMode: "disabled",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "disabled",
    },
    {
      name: "sale",
      type: "CHECKBOX",
      label: "Sale",
      required: false,
      // fieldWidth: 3,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
    {
      name: "source",
      type: "CHECKBOX",
      label: "Source",
      required: false,
      // fieldWidth: 2,
      createMode: "enable",
      editMode: "enable",
      createModeShowFlag: true,
      cloneModeShowFlag: true,
      editModeShowFlag: true,
      viewModeShowFlag: true,
      viewMode: "disabled",
      cloneMode: "enable",
    },
  ],
};

export const MANAGE_FACILITY_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Facility Code",
        id: "facilityId",
        accessor: "facilityId",
        style: {
          flex: '0 0 120px'
        },
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
              <>FAC-{value}</>
          )
      }
      },
      {
        Header: "Facility Name",
        id: "facilityName",
        accessor: "facilityName",
      },
      {
        Header: "Facility Type",
        id: "facilityType",
        accessor: "facilityType",
        style: {
          flex: '0 0 130px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <>

              {CommonUtil.getSelectedOptionNameFromCode(that.props.dataDictionaryList, original.facilityType)}
            </>
          )
        }
      },
      {
        Header: "Location",
        id: "location",
        accessor: (values) => {
          const { country, city } = values;
          return city + "-" + country;
        },
        style: {
          flex: '0 0 200px'
        },
      },
      // {
      //   Header: "Facility Origin",
      //   id: "sourceChannel",
      //   accessor: "sourceChannel",
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: '0 0 150px'
      //   },
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let sourceChannel = original.sourceChannel ? original.sourceChannel : commonConstant.ORIGINSCALE;
      //     return (
      //       <div className="full-td label-black">
      //         <span> {sourceChannel}</span>
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        className: "action justify-content-center",
        style: {
          flex: '0 0 90px'
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">

              <Button bsStyle="default" simple icon>
                {isAuthorized("editFacility") ? (
                  <div className="circle">
                    <i
                      title="edit"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.EDIT_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                ) : null}
                {isAuthorized("cloneFacility") &&
                  <div className="circle">
                    <i
                      title="clone"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.CLONE_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-copy"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("viewFacility") &&
                  <div className="circle">
                    <i
                      title="view"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.VIEW_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-eye"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: "",
        },
      ],
      defaultSortedList: [

      ],
      defaultPageSize: 50,
      rowId: "facilityId",
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const MANAGE_FACILITY_LOT_PAGE_LIST = (that) => {
  return {
    tableColumnList: [
      {
        Header: "Facility Code",
        id: "facilityId",
        accessor: "facilityId",
        style: {
          flex: '0 0 120px'
        },
      },
      {
        Header: "Facility Name",
        id: "facilityName",
        accessor: "facilityName",
      },
      {
        Header: "Facility Type",
        id: "facilityType",
        accessor: "facilityType",
        style: {
          flex: '0 0 130px'
        },
      },
      {
        Header: "Location",
        id: "location",
        accessor: (values) => {
          const { country, city } = values;
          return city + "-" + country;
        },
        style: {
          flex: '0 0 200px'
        },
      },
      // {
      //   Header: "Facility Origin",
      //   id: "sourceChannel",
      //   accessor: "sourceChannel",
      //   disableSortBy: true,
      //   disableFilters: true,
      //   style: {
      //     flex: '0 0 150px'
      //   },
      //   Cell: ({ cell }) => {
      //     const { value } = cell;
      //     const { index, original } = cell.row;
      //     let sourceChannel = original.sourceChannel ? original.sourceChannel : commonConstant.ORIGINSCALE;
      //     return (
      //       <div className="full-td label-black">
      //         <span> {sourceChannel}</span>
      //       </div>
      //     )
      //   }
      // },
      {
        Header: "Actions",
        id: "actions",
        accessor: "actions",
        sticky: "right",
        className: "action justify-content-center",
        style: {
          flex: '0 0 90px'
        },
        disableSortBy: true,
        disableFilters: true,
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <div className="actions-left">

              <Button bsStyle="default" simple icon>
                {isAuthorized("editFacility") ? (
                  <div className="circle">
                    <i
                      title="edit"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.EDIT_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-pencil"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                ) : null}
                {isAuthorized("cloneFacility") &&
                  <div className="circle">
                    <i
                      title="clone"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.CLONE_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-copy"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
                {isAuthorized("viewFacility") &&
                  <div className="circle">
                    <i
                      title="view"
                      id={
                        original.facilityId +
                        "_" +
                        commonConstant.VIEW_ACTION_MODE +
                        "_" +
                        index
                      }
                      className="fa fa-eye"
                      onClick={(e) => that.getTdProps(e)}
                    />
                  </div>
                }
              </Button>
            </div>
          );
        },
      },
    ],
    tableConfig: {
      defaultFilteredList: [
        {
          id: "status",
          value: "",
        },
      ],
      defaultSortedList: [

      ],
      defaultPageSize: 50,
      rowId: "facilityId",
      showExport: false,
      customPagination: true,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: true,
      isDraggable: false,
    },
  };
};

export const CREATE_FACILITY_RESOURCE_MANAGAMENT_TABLE_LIST = (that) => {
  return {
    tableData: [{
      resourceName: '',
      resourceDetail: '',
      workingHours: 0,
      workingDays: [],
      manPower: 0,
      totalMenHours: 0,
      owner: '',
      isActive: true
    }],
    tableColumnList: [
      {
        Header: "Resource Name",
        id: "resourceName",
        name: "resourceName",
        accessor: "resourceName",
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          var value = cell.value;
          const { index, original } = cell.row;
          return (
            <InputGroup className={that.state.submitted && !original.resourceName ? 'required-error' : ''}>
              <FormControl
                id={'resourceName' + '_' + index}
                name={'resourceName'}
                onChange={(e) => that.handleTableTextBoxChange(e)}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.resourceName}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                maxLength={100} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Resource Detail",
        id: "resourceDetail",
        accessor: "resourceDetail",
        name: "resourceDetail",
        required: true,
        type: "text",
        inputType: "text",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup className={that.state.submitted && original.resourceName && !original.resourceDetail ? 'required-error' : ''}>
              <FormControl
                id={'resourceDetail' + '_' + index}
                name={'resourceDetail'}
                onChange={(e) => that.handleTableTextBoxChange(e)}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.resourceDetail}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 100) }}
                maxLength={100}
              />
            </InputGroup>
          )
        }
      },
      {
        Header: "Working Hours",
        id: "workingHours",
        accessor: "workingHours",
        name: "workingHours",
        required: true,
        type: "number",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        style: {
          flex: '0 0 100px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup className={that.state.submitted && original.resourceName && !original.workingHours ? 'required-error' : ''}>
              <FormControl
                id={'workingHours' + '_' + index}
                name={'workingHours'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                min={0}
                onChange={(e) => that.handleTableTextBoxChange(e)}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.workingHours}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Working Days",
        id: "workingDays",
        accessor: "workingDays",
        name: "workingDays",
        required: true,
        type: "number",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        style: {
          flex: '0 0 140px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          let workDays = [];
          if (original.workingDays && original.workingDays.length > 0) {
            for (let i = 0; i < original.workingDays.length; i++) {
              let tempObj = {};
              tempObj.value = original.workingDays[i];
              tempObj.label = original.workingDays[i];
              workDays.push(tempObj)
            }
          }
          return (
            <Select
              className={that.state.submitted && original.resourceName && !original.workingDays ? 'required-error center-align' : 'center-align'}
              id={'workingDays' + '_' + index}
              name={"workingDays" + '_' + index}
              onChange={that.handleTableMultiDropDownChange}
              options={commonConstant.WORKING_DAYS}
              classNamePrefix="react-select"
              isMulti={true}
              placeholder={''}
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={workDays} />
          )
        }
      },
      {
        Header: "Manpower",
        id: "manPower",
        accessor: "manPower",
        name: "manPower",
        required: true,
        type: "number",
        inputType: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        style: {
          flex: '0 0 75px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup className={that.state.submitted && original.resourceName && !original.manPower ? 'required-error' : ''}>
              <FormControl id={'manPower' + '_' + index}
                name={'manPower'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                min={0}
                onChange={(e) => that.handleTableTextBoxChange(e)}
                disabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
                value={original.manPower}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Total Men Hours",
        id: "totalMenHours",
        accessor: "totalMenHours",
        name: "totalMenHours",
        required: true,
        type: "number",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        className: "input-field",
        style: {
          flex: '0 0 107px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <InputGroup className={that.state.submitted && original.resourceName && !original.totalMenHours ? 'required-error' : ''}>
              <FormControl id={'totalMenHours' + '_' + index}
                name={'totalMenHours'}
                data-type={'number'} onPaste={(e) => { e.preventDefault(); return false }}
                min={0}
                onChange={(e) => that.handleTableTextBoxChange(e)}
                disabled={true}
                value={original.totalMenHours}
                onKeyUp={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                onKeyDown={(e) => { CommonUtil.maxLengthCheck(e, 10) }}
                maxLength={10}
                minLength={1} />
            </InputGroup>
          )
        }
      },
      {
        Header: "Owner of process",
        id: "owner",
        accessor: "owner",
        name: "owner",
        createModeShowFlag: true,
        cloneModeShowFlag: true,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        required: true,
        type: "text",
        disableSortBy: true,
        disableFilters: true,
        className: "input-field",
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <Select
              className={that.state.submitted && original.resourceName && !original.owner ? 'required-error center-align' : 'center-align'}
              id={'owner' + '_' + index}
              name={'owner' + '_' + index}
              onChange={that.handleTableDropDownChange}
              options={that.state.ownerList}
              classNamePrefix="react-select"
              isMulti={false}
              placeholder={''}
              isDisabled={CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              value={{ "label": original.owner }} />
          )
        }
      },
      {
        Header: "Status",
        id: "isActive",
        name: "isActive",
        accessor: "isActive",
        disableSortBy: true,
        disableFilters: true,
        createModeShowFlag: true,
        cloneModeShowFlag: false,
        editModeShowFlag: true,
        viewModeShowFlag: true,
        style: {
          flex: '0 0 100px'
        },
        Cell: ({ cell }) => {
          const { value } = cell;
          const { index, original } = cell.row;
          return (
            <Switch
              id={'isActive' + '_' + index}
              inverse={false}
              value={original.isActive}
              disabled={CommonUtil.isCreateMode(that.props.actionMode) ||
                CommonUtil.isViewMode(that.props.actionMode) ? true : false}
              offColor={'primary'}
              onColor={'success'}
              onText="Active" offText="InActive" defaultValue={true}
              onChange={(el, state) => that.handleTableSwitchChange(el, state)}
            />
          )
        }
      },
    ],
    tableConfig: {
      defaultFilteredList: [],
      defaultSortedList: [],
      defaultPageSize: 50,
      addNewRowFunction: that.handleTableAddRow,
      showExport: false,
      customPagination: false,
      showServerSideFilter: false,
      isFilterEnabed: false,
      showPagination: false,
      showAddRow: false,
      isDraggable: false,
    }
  }
};

export const ADVANCE_SEARCH_LIST = (that) => {
  return {
    attributeObj: {
      orderNumber: '',
    },
    attributeList: [
      {
        name: "orderNumber",
        type: "TEXTBOX",
        label: "",
        inputType: "text",
        fieldWidth: 12,
        numberOfRow: 0,
        placeholder: "Search by Facility Code/Name",
      },
    ],
  }
};
