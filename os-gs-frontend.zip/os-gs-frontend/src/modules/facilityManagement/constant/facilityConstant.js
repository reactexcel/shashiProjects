import * as commonConstant from '../../common/constant/commonConstant';

export const CREATE_FACILITY_HEADER_TITLE = "Create Facility";
export const EDIT_FACILITY_HEADER_TITLE = "Edit Facility";
export const VIEW_FACILITY_HEADER_TITLE = "View Facility";
export const MANAGE_FACILITY_HEADER_TITLE = "Facility";
export const DOCUMENT_HEADER_TITLE = "Document";
export const FACILITY_USAGE_HEADER_TITLE = "Facility Usage";
export const MODULE_NAME = "Facility";

export const CREATE_FACILITY = "createFacility";
export const DEATIVATE_FACILITY = "deActivate";
export const ACTIVATE_FACILITY = "activate";

export const CREATE_FACILITY_PAGE_URL = '/admin/create-facility';
export const MANAGE_FACILITY_PAGE_URL = '/admin/manage-facility';

export const BASE_URL = process.env.REACT_APP_API_BASE_URL;
export const GET_FACILITY_LIST_URL = `${BASE_URL}/facilities`;
export const GET_FACILITY_DETAILS_URL = `${BASE_URL}/facilities/`;
export const SET_CREATE_FACILITY_DETAILS_URL = `${BASE_URL}/facilities/`;
export const SET_UPDATE_FACILITY_DETAILS_URL = `${BASE_URL}/facilities/`;
export const SET_UPDATE_FACILITY_STATUS_URL = `${BASE_URL}/facilities/`;
export const SET_FACILITY_DOCUMENTS_URL = commonConstant.FILEUPLOAD_URL + '/upload';
export const SET_CREATE_BULK_FACILITY_URL = `${BASE_URL}/facilities/bulkupload`;
export const GET_FACILITY_SEARCH_URL = BASE_URL + '/facilities';
export const GET_CAPACITY_REPORT_URL = BASE_URL + '/facilities/storage';

