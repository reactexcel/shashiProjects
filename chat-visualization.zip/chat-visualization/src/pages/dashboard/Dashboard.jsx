import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { Button, MenuItem, Select, TextField } from "@mui/material";
import axiosInstance from "../../utils/axios";
import Draggable from "react-draggable";
import BarChartCom from "../../components/barChart/BarChart";
import { TableChart } from "../../components/tableData/TableChart";
import Loader from "../../components/loader/Loader";
import { useState } from "react";
import { Bounce, ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import PieChartCom from "../../components/pieChart/PieChart";

const optionData = [
  { id: 1, value: "Bar-Chart" },
  { id: 2, value: "Table" },
  { id: 3, value: "Pie-Chart" },
];

const Dashboard = () => {
  const [promptText, setPromptText] = useState({
    inputValue: "",
    selectedValue: "",
  });
  const [data, setData] = useState([]);
  const [resData, setResData] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [showLoading, setShowLoading] = useState(false);

  const handleInputChange = (event, name, id) => {
    console.log(id, "idddddddddddddddd");
    const { value } = event.target;
    setPromptText({
      ...promptText,
      [name]: value,
    });
  };

  const [chartType, setChartType] = useState({
    id: "",
    selectedValue: "",
  });
  const handleInsideSelect = (e, id) => {
    const { value } = e.target;
    setChartType({
      id: id,
      selectedValue: value,
    });
  };

  console.log(chartType, "charttttttttttt");
  const fetchData = async () => {
    try {
      const response = await axiosInstance.post(
        "/generate-query/",
        {
          prompt: promptText && promptText.inputValue,
        },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      // console.log("Response:", response.data);
      setData((prevData) => [...prevData, response.data]);
      setResData(response.data);
      response.data && setIsLoading(false);
    } catch (error) {
      console.error("Error:", error.response);
      error.response.data &&
        toast.info(error.response.data.detail, {
          position: "top-center",
          theme: "colored",
          autoClose: 3000,
          transition: Bounce,
        });
      error.response.data && setIsLoading(false);
    }
  };

  const handlefetchData = async () => {
    setShowLoading(true);
    await fetchData();
  };

  const handleDelete = (id) => {
    const updateData = data.flatMap((item) =>
      item.filter((e) => e.uuid !== id)
    );
    setData([updateData]);
  };

  console.log(data, "@@@@@@@@@@@@@@@@@@@@@@@@@22");

  return (
    <Box>
      <ToastContainer />
      <header
        style={{
          backgroundColor: "#918e8e",
          color: "#fff",
          padding: "4px 15px",
        }}
      >
        <Typography variant="h1" fontSize={"28px"} py={2} fontWeight={600}>
          Chat - Visualization
        </Typography>
      </header>
      <Box maxWidth={"1200px"} mx={"auto"}>
        <Box
          display={"flex"}
          alignItems={"center"}
          my={4}
          width={"90%"}
          px={2}
          gap={4}
        >
          <Box width={"80%"}>
            <TextField
              id="outlined-multiline-flexible"
              label="search"
              multiline
              maxRows={4}
              name={"inputValue"}
              size="small"
              sx={{ width: "100%" }}
              value={promptText.inputValue}
              onChange={(e) => handleInputChange(e, "inputValue")}
            />
          </Box>
          <Box>
            <Select
              sx={{ width: "200px" }}
              value={promptText.selectedValue}
              name={"selectedValue"}
              displayEmpty
              size="small"
              disabled={Boolean(promptText.inputValue == "")}
              onChange={(e) => handleInputChange(e, "selectedValue")}
            >
              <MenuItem value="" disabled>
                --- Choose Type ---
              </MenuItem>
              {optionData.map((option) => (
                <MenuItem
                  key={option.value}
                  value={option.value}
                  sx={{ width: "200px", fontSize: "14px" }}
                >
                  {option.value}
                </MenuItem>
              ))}
            </Select>
          </Box>
          <Box>
            <Button
              variant="contained"
              color="success"
              type="submit"
              disabled={
                (promptText.inputValue && promptText.selectedValue) === ""
              }
              onClick={handlefetchData}
            >
              Search
            </Button>
          </Box>
        </Box>
        {isLoading ? (
          showLoading && <Loader />
        ) : (
          <Box display={"flex"} flexWrap={"wrap"} gap={4}>
            {data.map((item, index) => (
              <Box key={index}>
                {item.map((innerItem, innerIndex) => (
                  <Draggable
                    key={innerIndex}
                    axis="both"
                    handle=".handle"
                    defaultPosition={{ x: 0, y: 0 }}
                    position={null}
                    scale={1}
                  >
                    <Box className="handle">
                      {promptText.selectedValue == "Pie-Chart" ? (
                        <PieChartCom
                          data={innerItem}
                          id={innerItem.uuid}
                          handleInputChange={handleInputChange}
                          optionData={optionData}
                          promptText={promptText}
                          handleDelete={handleDelete}
                        />
                      ) : promptText.selectedValue == "Bar-Chart" ||
                        chartType.selectedValue == "Bar-Chart" ? (
                        promptText.selectedValue == "Bar-Chart" ? (
                          <BarChartCom
                            data={innerItem}
                            id={innerItem.uuid}
                            handleDelete={handleDelete}
                            handleInsideSelect={handleInsideSelect}
                            optionData={optionData}
                            chartType={chartType}
                          />
                        ) : (
                          chartType.selectedValue == "Bar-Chart" &&
                          chartType.id === innerItem.uuid && (
                            <BarChartCom
                              data={innerItem}
                              id={innerItem.uuid}
                              handleDelete={handleDelete}
                              handleInsideSelect={handleInsideSelect}
                              optionData={optionData}
                              chartType={chartType}
                            />
                          )
                        )
                      ) : (
                       ( promptText.selectedValue == "Table" ||
                        chartType.selectedValue == "Table") &&
                          Object.keys(innerItem).map((key) => {
                            if (key !== "uuid") {
                              return (
                                <Box
                                  key={key}
                                  my={4}
                                  maxWidth={"1200px"}
                                  mx={"auto"}
                                >
                                  <Typography
                                    variant="h2"
                                    fontSize={"24px"}
                                    fontWeight={"600"}
                                    pb={2}
                                  >
                                    {key}
                                  </Typography>
                                  {promptText.selectedValue == "Table" ? (
                                    <TableChart
                                      userData={innerItem[key]}
                                      id={innerItem.uuid}
                                      handleDelete={handleDelete}
                                      handleInsideSelect={handleInsideSelect}
                                      optionData={optionData}
                                      chartType={chartType}
                                    />
                                  ) : (
                                    chartType.selectedValue == "Table" &&
                                    chartType.id === innerItem.uuid && (
                                      <TableChart
                                        userData={innerItem[key]}
                                        id={innerItem.uuid}
                                        handleDelete={handleDelete}
                                        handleInsideSelect={handleInsideSelect}
                                        optionData={optionData}
                                        chartType={chartType}
                                      />
                                    )
                                  )}
                                </Box>
                              );
                            }
                            return null;
                          })
                      )}
                    </Box>
                  </Draggable>
                ))}
              </Box>
            ))}
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default Dashboard;
