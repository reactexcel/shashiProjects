const { response } = require("express")
const bcrypt = require('bcrypt');
const registerUser = require("../model/registerUser")


exports.registerUser = async (req, res) => {
    try {
        const requestData = req.body;
        console.log(req.body,"----==============")
        const existingUser = await registerUser.findOne({ email: requestData.email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already exists' });
        }
        const hashedPassword = await bcrypt.hash(requestData.password, 10);
        requestData.password = hashedPassword;
        const newUserData = new registerUser(requestData);
        console.log(newUserData,"---------")
        const savedData = await newUserData.save();
        console.log(savedData,"ppppppppp")
        res.status(201).json({ message: "register success", data: savedData })
    } catch (error) {
        console.log("Error", error);
        res.status(500).json({ message: "internal servor error" })
    }
}

