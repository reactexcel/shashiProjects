from flask.views import MethodView
from flask import render_template, request, jsonify
from flask import current_app


class AllTemplatesView(MethodView):
    def get(self):
        documents = list(current_app.db.documents.find({},{'_id':False}))
        return render_template('all-templates.html', templates=documents)