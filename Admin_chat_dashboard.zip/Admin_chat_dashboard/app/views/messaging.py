from flask.views import MethodView
from flask import render_template, request, jsonify
from flask import current_app
import datetime


class DashboardView(MethodView):
    def get(self):
        users_cursor = current_app.db.users.find({}, {'_id': False, 'password': False})
        users = list(users_cursor)
        return render_template('dashboard.html', users=users)
    

class ChatView(MethodView):
    def get(self):
        users_cursor = current_app.db.users.find({}, {'_id': False, 'password': False})
        users = list(users_cursor)
        for user in users:
            messages = current_app.db.messages.find_one({'user_id':user['uuid']}, {'_id':0, 'messages': 1})
            user['chats'] = messages if messages else None
            pipeline = [
                {
                    "$match": {
                        "user_id": user['uuid']
                    }
                },
                {
                    "$unwind": "$messages"
                },
                {
                    "$match": {
                        "messages.is_seen": False, 
                        "messages.is_response":False
                    }
                },
                {
                    "$group": {
                        "_id": "$_id",
                        "user_id": { "$first": "$user_id" },
                        "messages": { "$push": "$messages" }
                    }
                }
            ]

            unseen_messages = list(current_app.db.messages.aggregate(pipeline))
            
            if unseen_messages:
                user['unseen_msg'] = unseen_messages[0]
                del user['unseen_msg']['_id']
                user['latest_chat'] = unseen_messages[0]['messages'][-1]
            else:
                user['unseen_msg'] = None
                user['latest_chat'] = None 
        
        return render_template('apps-chat.html', users=users)


class UpdateChatStatus(MethodView):
    def post(self):
        data = request.json
        email = data.get('email')
        user = current_app.db.users.find_one({'email': email})
        current_app.db.messages.update_many(
            {'user_id': user['uuid'], 'messages.is_response': False},
            {'$set': {'messages.$[elem].is_seen': True}},
            array_filters=[{'elem.is_response': False}]
        )
        return jsonify({"message":"successfully updated!"}), 200


#class SaveAdminResponseView(MethodView):
#    def post(self):
#
#        data = request.json if request.is_json else request.form
#        data['timestamp'] = datetime.datetime.now() 
#        message_data = data.copy()
#        message_data.pop('user_id')  
#
#        print(data, message_data)
#
#
#        user = current_app.db.users.find_one({'uuid':data['user_id']})
#        print("DFFF", user)
#        if not user:
#            return jsonify({"error":"user not exist!"}), 404
#        
#        existing_document = current_app.db.messages.find_one({'user_id': user['user_id']})
#        if existing_document:
#            print("HIII")
#            current_app.db.messages.update_one({'user_id': user['user_id']}, {'$push': {'messages': message_data}})
#
#        return jsonify({"message": "Response received and published successfully"}), 200
   