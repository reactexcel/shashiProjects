from flask import request
import logging
from datetime import datetime
from flask import current_app
from app import mqtt


logging.basicConfig(level=logging.DEBUG)

def log_request(req: request):
    logging.info(f"Request Method: {req.method}")
    logging.info(f"Request URL: {req.url}")
    logging.info(f"Request Headers: {req.headers}")
    if req.method == 'POST':
        logging.info("Request Form Data: {}".format(req.form if req.form else req.json))
