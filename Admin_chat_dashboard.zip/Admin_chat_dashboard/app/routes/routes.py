from flask import Blueprint
from app.views.messaging import DashboardView, ChatView, UpdateChatStatus
from app.views.media import AllTemplatesView

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

admin_bp.add_url_rule(rule='', view_func=DashboardView.as_view('dashboard'))
admin_bp.add_url_rule(rule='/chat', view_func=ChatView.as_view('chat'))
admin_bp.add_url_rule(rule='/templates', view_func=AllTemplatesView.as_view('templates'))
admin_bp.add_url_rule(rule='/update-chat-status', view_func=UpdateChatStatus.as_view('chat_status'))
#admin_bp.add_url_rule(rule='/response', view_func=SaveAdminResponseView.as_view('response'))
