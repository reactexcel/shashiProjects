import os

from flask import Flask, redirect
#from flask_socketio import SocketIO
from pymongo import MongoClient

from app.config import config, Config



def create_app(config_name):

    app = Flask(__name__,)

    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Connect to mongoDB
    mongo_client = MongoClient(config[config_name].MONGO_URI)
    app.db = mongo_client.get_database()
    
    @app.route('/')
    def index():
        return redirect('/admin')
    

    @app.after_request
    def add_security_headers(response):
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        return response

    from app.routes import admin_bp

    app.register_blueprint(admin_bp)

    return app


config_name = os.getenv('CONFIG', 'development')

app = create_app(config_name)
