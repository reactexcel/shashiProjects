import os
import datetime

from dotenv import load_dotenv


load_dotenv()

base_dir = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.getenv('SECRET_KEY')
    BASE_URL = os.getenv('BASE_URL')
    DB_NAME = os.getenv("DB_NAME")
    DB_HOST = os.getenv('DB_HOST')
    DB_PORT = os.getenv('DB_PORT')
    DEBUG  = os.getenv('FLASK_DEBUG')
    MQTT_BROKER_ADDRESS = os.getenv('MQTT_BROKER_ADDRESS')

    print("ADDRE", MQTT_BROKER_ADDRESS)
    

    @staticmethod
    def init_app(app):
        pass


class DevelopmentConfig(Config):
    FLASk_DEBUG = Config.DEBUG
    SESSION_COOKIE_SECURE = False
    MONGO_URI = f'mongodb://{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_NAME}'


class ProductionConfig(Config):
    FLASk_DEBUG = Config.DEBUG
    SESSION_COOKIE_SECURE=True
    MONGO_URI = f'mongodb://{Config.DB_HOST}:{Config.DB_PORT}/{Config.DB_NAME}'


config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
}
