import "./App.css";
import Todo from "./pages/todo";

function App() {
  return (
    <div className="App">
      <Todo />
    </div>
  );
}

export default App;
