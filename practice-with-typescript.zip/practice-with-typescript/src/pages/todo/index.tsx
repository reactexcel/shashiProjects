import Button from "../../components/button";
import InputField from "../../components/inputField";


const Todo = () => {

  const foo=
  return (
    <div>
      <InputField type={"text"} placeholder={"Enter Your List"}/>
      <Button value={"Add"} />
    </div>
  );
};

export default Todo;
 