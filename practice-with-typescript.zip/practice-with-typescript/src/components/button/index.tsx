interface button {
  value: string;
}

const Button = ({ value }: button) => {
  return <button>{value}</button>;
};

export default Button;
