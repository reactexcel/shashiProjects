

interface input {
  type: string;
  placeholder: string;
}

const InputField = ({ type, placeholder}: input) => {
  return <input  type={type} name="" id="" placeholder={placeholder} />;
};

export default InputField;
