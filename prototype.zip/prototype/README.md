# prototype

## Getting Started

To set up the environment, and run the project on your local system, please follow the installation and usage instructions detailed in the subsequent sections.

### Setting Up database user

- Change the database configuration connection details in the `setup_db.sh` file 
to match your local environment. Next, run the following command to setup the database user
and grant the neccessary privileges

```bash
./setup_db.sh
```

### Setting Up a Python Virtual Environment
- This project requires **Python 3.9** or higher. Please make sure you have the correct version installed before proceeding. You can check your Python version using the following command:
```bash
python3 --version
```

- Before starting with the project, it is recommended to set up a Python virtual environment. Here is how you can do it:

```bash
# Create a new virtual environment
python3 -m venv venv

# Activate the virtual environment
# Unix systems:
source venv/bin/activate

# Windows:
.\venv\Scripts\activate

# Install required packages
pip install -r requirements.txt
```

### Setting up environment variables for backend

- Create a copy of the sample.env file and rename it to .env.
- Open the .env file and update the values based on your local environment.


### Set Flask application in environment
Inside the `backend` folder, set the Flask application environment variable within the virtual environment:
```bash
export FLASK_APP=main.py
```

### Run initial database tables
- Move to the `backend` folder and run the following commands:
```bash
python -m flask db upgrade
```

- If you modify the database models, generate new migration files and apply the changes with:
```bash
python -m flask db migrate -m "Describe your model changes here"
python -m flask db upgrade
```

Re-run the previous command to apply the changes to the database

### Load Initial sample data
- Run the following command to load the seed database
```bash
python -m flask seed_db
```

### Running periodic tasks
- Run the following command to Start a Celery worker service
```bash
celery --app app.tasks:celery worker --loglevel info --concurrency 4
```
- Run the following command to Start a Celery beat service
```bash
celery -A app.tasks:celery beat --loglevel=info
```

## Redis Operations

### Reset/Wipe Memory

To reset or wipe the Redis memory, you can use the following command:

```bash
redis-cli FLUSHALL
```

View Data in Redis
To view data stored in Redis, you can use the Redis command-line interface (CLI). Connect to Redis using:
```bash
redis-cli --scan --pattern '*'
```

or 
```bash
redis-cli
```
Once connected, you can use various commands like KEYS * to list all keys or GET key_name to retrieve the value associated with a specific

## Loading Dummy Data

1. Run the local docker-compose file:

```bash
docker compose -f docker-compose.local.yml up --build
```

2. Get the running containers:

```bash
docker ps
```

3. Copy the CONTAINER ID or NAME of the backend container:

```bash
docker exec -it <CONTAINER_NAME/ID> bash
```

4. Run the following command within the container to seed the database:

```bash
python seed_database.py
```


## Running silumation script

1. Inside the Docker container:

```bash
docker exec -it <CONTAINER_NAME/ID> python app/scripts/simulation.py
```

or

2. Run the script out side the Docker container:

- Change directory to backend
```bash
cd backend/
```

- Activate the virtual environment

```bash
source venv/bin/activate
```

- Run the command

```bash
python app/scripts/simulation.py
```