import React, { useEffect, useState } from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  useLocation,
} from "react-router-dom";
import { useAuth0 } from "@auth0/auth0-react";
import AssetCard from "./components/chart/AssetCard";
import AirQuality from "./components/airQuality/AirQuality";
import ErrorBoundary from "./ErrorBoundary";
import Home from "./components/home/home";
import MarketInfo from "./components/marketInfo/MarketInfo";
import { Portfolio } from "./components/portfolio/Portfolio";
import { Header } from "./components/Header/Header";
import { Login } from "./components/accessory/Login";
import { useAxiosConfig } from "./api/axios";
import { WaveDots } from "./components/accessory/loading";
import { Leaderboard } from "./components/leaderboard/Leaderboard";
import Simulator from "./components/simulator/Simulator";



const App= () => {
  const queryParams = new URLSearchParams(window.location.search);
  const start_date = queryParams.get("start_date");
  const end_date = queryParams.get("end_date");
  useAxiosConfig();

  useEffect(() => {
    
    window.addEventListener("unhandledrejection", (event) => {
      console.warn(`Warning: ${event.reason}`);
      event.preventDefault();
    });
    window.addEventListener("error", (event) => {
      console.warn(`Warning: ${event}`);
      event.preventDefault();
    });
    window.addEventListener("DOMContentLoaded", (event) => {
      console.warn(`Warning: ${event}`);
      event.preventDefault();
    });
  }, []);

  const [assetId, setAssetId] = useState<number>(1);
  const { isLoading } = useAuth0();

  const CenteredLoader = () => (
    <div className="flex justify-center items-center h-screen">
      <WaveDots />
    </div>
  );

  return (
    <ErrorBoundary>
      <Router>
        {window.location.pathname !== "/simulator" && (
          <Header assetId={assetId} />
        )}
        <Routes>
          <Route
            path="/assets/:assetId"
            element={
              isLoading ? (
                <CenteredLoader />
              ) : (
                <AssetCard setHeaderAssetId={setAssetId} />
              )
            }
          />
          <Route path="/" element={isLoading ? <CenteredLoader /> : <Home />} />
          <Route path="/login" element={<Login />} />
          <Route
            path="/market-info"
            element={isLoading ? <CenteredLoader /> : <MarketInfo />}
          />
          <Route
            path="/air-quality/:assetId"
            element={
              isLoading ? (
                <CenteredLoader />
              ) : (
                <AirQuality setHeaderAssetId={setAssetId} />
              )
            }
          />
          <Route
            path="/portfolio/:userId?"
            element={isLoading ? <CenteredLoader /> : <Portfolio />}
          />
          <Route
            path="/leaderboard"
            element={isLoading ? <CenteredLoader /> : <Leaderboard />}
          />
          <Route
            path="/simulator"
            element={
              isLoading ? (
                <CenteredLoader />
              ) : (
                <Simulator startdate={start_date} enddate={end_date} />
              )
            }
          />
        </Routes>
      </Router>
    </ErrorBoundary>
  );
};

export default App;
