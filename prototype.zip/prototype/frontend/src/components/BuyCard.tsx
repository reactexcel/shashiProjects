import React, { useState, ChangeEvent, useEffect } from 'react';
import { InputAdornment, Button, Card, CardContent, TextField, Typography, InputLabel, Box } from '@mui/material';
import { getPrice, swap, userTokenQuantity } from '../api/api';

interface StockChartProps {
  assetId: string;
  assetName: string;
}

function BuyCard({ assetId, assetName }: StockChartProps) {
  const [purchaseValue, setPurchaseValue] = useState(0);
  const [purchaseQuantity, setPurchaseQuantity] = useState(0);
  const [ownedQuantity, setOwnedQuantity] = useState(0);
  const [price, setPrice] = useState(0);
  const [buyingPower, setBuyingPower] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const handleAmountChange = (event: ChangeEvent<HTMLInputElement>) => {
    setPurchaseValue(Number(event.target.value));
    setPurchaseQuantity(Number(event.target.value) / price);
  };

  const handlePlaceOrderClick = async () => {
    try {
      await swap('user1', 'A_' + assetId, 'A', purchaseValue);
    } catch (error: any) {
      console.error(`Error fetching order info: ${error}`);
      setError("Something went wrong! Failed to place order");
    }

  };

  const fetchBuyingPower = async () => {
    // const { quantity } = await userTokenQuantity('user1', 'A');
    // setBuyingPower(quantity);
  };

  const fetchPrice = async () => {
    // const price = await getPrice(assetId);
    // setPrice(price);
  };

  const fetchOwnedQuantity = async () => {
    // const { quantity } = await userTokenQuantity('user1', assetId);
    // setOwnedQuantity(quantity);
  };

  useEffect(() => {
    fetchBuyingPower();
    fetchPrice();
    fetchOwnedQuantity();
    setPurchaseQuantity(0)
    setPurchaseValue(0)
  }, [assetId, assetName]);
  


  return (
    <Card elevation={5} sx={{ margin: 5 }}>
      <CardContent>
        <Typography variant="h5" component="div">
          Buy {assetName} AQ
        </Typography>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
          Order Type: Liquidity Pool (i)
        </Typography>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
          Currently Own: {ownedQuantity.toFixed(3)}
        </Typography>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
          Buying power: ${buyingPower} USDC
        </Typography>
        <Typography sx={{ mb: 1.5 }} color="text.secondary">
          Price: ${price} USDC
        </Typography>
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <InputLabel htmlFor="amount">Amount</InputLabel>
          <TextField
            id="amount"
            type="number"
            placeholder="$0.00"
            value={purchaseValue}
            onChange={handleAmountChange}
            fullWidth
            sx={{ ml: 2, width: '50%' }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">$</InputAdornment>
              ),
            }}
          />
        </Box>
        <Typography variant="body2">
          est. quantity: {purchaseQuantity.toFixed(3)}
        </Typography>
        <Button variant="contained" sx={{ mt: 2 }} fullWidth onClick={handlePlaceOrderClick}>
          Place Order
        </Button>
        <span className="text-red-500">{error}</span>
      </CardContent>
    </Card>
  );
}

export default BuyCard;
