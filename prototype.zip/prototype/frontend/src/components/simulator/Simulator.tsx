// import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
// import { useEffect, useRef, useState } from "react";
// import ReactJson from "react-json-view";

// interface Error {
//   error: string;
// }

// const Simulator = () => {
//   const [inputText, setInputText] = useState("");
//   const [simulatorText, setSimulatorText] = useState("");
//   const [simulatorRes, setSimulatorRes] = useState<string[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [errorMsg, setErrorMsg] = useState<Error[]>([]);
//   const [errorStatus, setErrorStatus] = useState<boolean>(false);
//   const ref = useRef<HTMLDivElement>(null);

//   const handleSubmit = (e: any) => {
//     setSimulatorText("");
//     e.preventDefault();
//     setSimulatorText(inputText.toLowerCase());
//   };

//   const fetchSimulateData = async () => {
//     try {
//       const response = await fetch(`${process.env.REACT_APP_BASE_URL}`, {
//         headers: {
//           Accept: "text/event-stream",
//         },
//       });
//       console.log(response.json(), "$$$$$$$$$$$4444");

//       if (!response.ok) {
//         throw new Error("errr");
//       }
//       const reader = response.body?.getReader();
//       const decoder = new TextDecoder();
//       reader
//         ?.read()
//         .then(function processText(res) {
//           if (res.done) {
//             ref.current?.scrollIntoView({ behavior: "smooth", block: "end" });
//             return;
//           }
//           const decodedValue = decoder.decode(res.value, { stream: true });
//           setLoading(false);
//           setSimulatorRes((prev) => [
//             ...prev,
//             ...decodedValue?.split("\n")?.filter((d: any) => d),
//           ]);
//           ref.current?.scrollIntoView({ behavior: "smooth", block: "end" });
//           reader.read().then(processText).catch(console.log);
//         })
//         .catch(console.log);
//     } catch (e) {
//       console.log(e);
//     }
//   };

//   useEffect(() => {
//     if (simulatorText !== "") {
//       switch (simulatorText) {
//         case "simulate":
//           fetchSimulateData();
//           break;
//         case "clear":
//           setErrorMsg([]);
//           setInputText("");
//           break;
//         default:
//           setErrorStatus(true);
//           setErrorMsg([...errorMsg, { error: "Command not found" }]);
//           setInputText("");
//           break;
//       }
//     }
//   }, [simulatorText]);

//   return (
//     <>
//       <div className="px-[1.5rem] h-[100vh] overflow-y-auto md:px-[2rem] min-[800px]:px-[3rem]  md:pt-[2.19rem] bg-black text-white">
//         <form
//           onSubmit={handleSubmit}
//           className="fixed bg-black left-0 right-0 top-0 pt-4 pl-12 z-50"
//         >
//           {errorStatus &&
//             errorMsg.map((ele, i) => {
//               return (
//                 <p className="flex items-center" key={i}>
//                   <span style={{ color: "gray" }}>PBX :</span>
//                   <KeyboardDoubleArrowRightIcon />
//                   <span className="text-red-500">Error : {ele.error}</span>
//                 </p>
//               );
//             })}
//           <label htmlFor="simulatorText" className="flex items-center">
//             <span style={{ color: "gray" }}>PBX :</span>
//             <KeyboardDoubleArrowRightIcon />
//             <input
//               type="text"
//               name="inputText"
//               id="inputText"
//               value={inputText}
//               className="bg-transparent border-none text-yellow-600 focus:ring-0"
//               placeholder="write command"
//               autoComplete="off"
//               autoSave="off"
//               onChange={(e) => setInputText(e.target.value)}
//             />
//           </label>
//         </form>
//         {!loading && (
//           // <div className="w-[100%] {`${errorMsg} ? mt-10 : m-2`} text-sm flex">
//           //   <div className="flex flex-col gap-4">
//           //     {simulatorRes.map((item, index) => {
//           //       return (
//           //         <ReactJson
//           //           key={index}
//           //           src={JSON.parse(item)}
//           //           theme={"twilight"}
//           //           style={{ backgroundColor: "transparent" }}
//           //           collapsed={false}
//           //           collapseStringsAfterLength={false}
//           //           indentWidth={0}
//           //           displayDataTypes={false}
//           //           enableClipboard={false}
//           //           displayObjectSize={false}
//           //           onEdit={false}
//           //           onAdd={false}
//           //           name={null}
//           //           onDelete={false}
//           //         />
//           //       );
//           //     })}
//           //   </div>
//           //   <div ref={ref} />
//           // </div>

//           <>
//             <div className="w-[100%] {`${errorMsg} ? mt-10 : m-2`} text-sm flex pb-4">
//               <div className="flex flex-col gap-4">
//                 {simulatorRes.map((item, index) => {
//                   const splittedItems = item.split("{}");
//                   return (
//                     <div key={index}>
//                       {splittedItems.map((splitItem, splitIndex) => (
//                         <p key={splitIndex}>{splitItem}</p>
//                       ))}
//                     </div>
//                   );
//                 })}
//               </div>
//             </div>
//             <div ref={ref} />
//           </>

//           // <>
//           //   <div className="w-full mt-3 overflow-x-auto">
//           //     {simulatorRes.map((item, index) => {
//           //       if (item.startsWith("[") && item.endsWith("]")) {
//           //         return (
//           //           <div
//           //             key={index}
//           //             className="w-full inline-block whitespace-nowrap py-1"
//           //           >
//           //             {item}
//           //           </div>
//           //         );
//           //       } else {
//           //         return (
//           //           <p key={index} className="whitespace-pre-line">
//           //             {item}
//           //           </p>
//           //         );
//           //       }
//           //     })}
//           //   </div>
//           //   <div ref={ref} />
//           // </>
//         )}
//       </div>
//     </>
//   );
// };

// export default Simulator;

import {
  JSXElementConstructor,
  Key,
  ReactElement,
  ReactNode,
  ReactPortal,
  useEffect,
  useRef,
  useState,
} from "react";
import KeyboardDoubleArrowRightIcon from "@mui/icons-material/KeyboardDoubleArrowRight";
import ReactJson from "react-json-view";
import { ToastContainer, toast } from "react-toastify";

interface Error {
  error: string;
}

interface TableRow {
  [key: string]: string;
}

interface TableData {
  headers: string[];
  data: TableRow[];
}

interface SimulatorResponse {
  first_table?: TableData;
  second_table?: TableData;
}
interface APIError {
  error: string;
}

const Simulator = ({ startdate, enddate }: any) => {
  const [inputText, setInputText] = useState("");
  const [simulatorText, setSimulatorText] = useState("");
  const [simulatorRes, setSimulatorRes] = useState<SimulatorResponse | {}>({});
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<(Error | { error: string })[]>([]);
  const [errorStatus, setErrorStatus] = useState<boolean>(false);
  const ref = useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    setSimulatorText("");
    e.preventDefault();
    setSimulatorText(inputText.toLowerCase());
  };

  // console.log(startdate, "###############333");
  // console.log(enddate, "%%%%%%%%%%%%%%%%%%");

  const fetchSimulateData = async () => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_BASE_URL}?start_date=${startdate}&end_date=${enddate}`,
        {
          headers: {
            Accept: "text/event-stream",
          },
        }
      );
      if (!response.ok) {
        const errorData: APIError = await response.json();
        throw new Error(errorData.error);
      }
      const data = await response.json();
      setSimulatorRes(data);
    } catch (error: any) {
      console.log(error, "$$$$$$$$$$");
      toast.error(`${error}`, {
        position: "top-center",
        autoClose: 5000,
        theme: "colored",
      })
    }
  };

  useEffect(() => {
    if (simulatorText !== "") {
      switch (simulatorText) {
        case "simulate":
          fetchSimulateData();
          break;
        case "clear":
          setErrorMsg([]);
          setInputText("");
          break;
        default:
          setErrorStatus(true);
          setErrorMsg([...errorMsg, { error: "Command not found" }]);
          setInputText("");
          break;
      }
    }
  }, [simulatorText]);

  // console.log(simulatorRes, "%%%%%%%%%%%%5555");

  return (
    <>
      <div className="px-[1.5rem] h-[100vh] overflow-y-auto md:px-[2rem] min-[800px]:px-[3rem]  md:pt-[2.19rem] bg-black text-white">
        <ToastContainer />
        <form
          onSubmit={handleSubmit}
          className="fixed bg-black left-0 right-0 top-0 pt-4 pl-12 z-50"
        >
          {errorStatus &&
            errorMsg.map((ele, i) => {
              return (
                <p className="flex items-center" key={i}>
                  <span style={{ color: "gray" }}>PBX :</span>
                  <KeyboardDoubleArrowRightIcon />
                  <span className="text-red-500">Error : {ele.error}</span>
                </p>
              );
            })}
          <label htmlFor="simulatorText" className="flex items-center">
            <span style={{ color: "gray" }}>PBX :</span>
            <KeyboardDoubleArrowRightIcon />
            <input
              type="text"
              name="inputText"
              id="inputText"
              value={inputText}
              className="bg-transparent border-none text-yellow-600 focus:ring-0"
              placeholder="write command"
              autoComplete="off"
              autoSave="off"
              onChange={(e) => setInputText(e.target.value)}
            />
          </label>
        </form>

        {"first_table" in simulatorRes && simulatorRes.first_table && (
          <>
            <table className="w-full text-white mt-12 text-sm text-center border-separate border-spacing-y-4">
              <thead>
                <tr className="w-full">
                  {simulatorRes.first_table.headers.map(
                    (header: string, index: number) => (
                      <th
                        className={
                          index !== 0
                            ? "border-l border-white py-0 px-[2px]"
                            : "py-0 px-[2px]"
                        }
                        key={index}
                      >
                        {header}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {simulatorRes.first_table.data.map(
                  (row: TableRow, rowIndex: number) => (
                    <tr key={rowIndex} className="border-l border-white">
                      {Object.values(row).map((value, cellIndex) => (
                        <td
                          className={
                            cellIndex !== 0
                              ? "border-l border-white py-0 px-[2px]"
                              : "py-0 px-[2px]"
                          }
                          key={cellIndex}
                        >
                          {value}
                        </td>
                      ))}
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </>
        )}

        {"second_table" in simulatorRes && simulatorRes.second_table && (
          <>
            <table className="w-full text-white mt-6 text-sm  border-separate border-spacing-y-2">
              <thead>
                <th className="text-left">AVERAGE ON STRATEGY</th>
                <tr className="w-full">
                  <th></th>
                  {simulatorRes.second_table.headers.map(
                    (header: string, index: number) => (
                      <th
                        className="border-l border-white py-0 text-left px-4"
                        key={index}
                      >
                        {header}
                      </th>
                    )
                  )}
                </tr>
              </thead>
              <tbody>
                {simulatorRes.second_table.data.map(
                  (row: TableRow, rowIndex: number) => (
                    <tr key={rowIndex} className="border-l border-white w-full">
                      {Object.values(row).map((value, cellIndex) => (
                        <td
                          className={
                            cellIndex !== 0
                              ? "border-l border-white py-0 px-4"
                              : "py-0"
                          }
                          key={cellIndex}
                        >
                          {value}
                        </td>
                      ))}
                    </tr>
                  )
                )}
              </tbody>
            </table>
          </>
        )}
      </div>
    </>
  );
};

export default Simulator;
