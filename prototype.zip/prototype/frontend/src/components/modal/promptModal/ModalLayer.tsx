import React, { ReactElement, ReactNode } from 'react'
import { Fragment, useEffect, useRef, useState } from 'react'
import { Dialog, Transition } from '@headlessui/react'
import { Fade, Modal } from '@mui/material'

interface Props {
  children: ReactElement
  show: boolean
  onClose: () => void
}

export const ModalLayer = ({ children, show = false, onClose }: Props) => {
  const cancelButtonRef = useRef(null)

  return (
    <Modal open={show} onClose={onClose}>
      <Fade in={show}>
      {children}
      </Fade>
    </Modal>
  )
}
