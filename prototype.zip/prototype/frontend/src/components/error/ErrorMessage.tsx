import React from 'react';

const ErrorMessage = ({ message }: { message: string }) => {
  return (
    <div className="flex justify-center items-center h-screen">
      <span className="text-red-500">{message}</span>
    </div>
  );
}
export default ErrorMessage;