interface ChartHeaderProps {
  currentPrice?: number;
  assetName: string;
}

const ChartHeader = ({ currentPrice, assetName }: ChartHeaderProps) => {
  if (!currentPrice) {
    currentPrice = 0
  }

  return (
    <>
      <h4 className="text-2xl pb-2">
        {assetName}
      </h4>
      {currentPrice !== 0 && 
        <h2 className="text-4xl pb-4">
          {'$' + (typeof currentPrice === 'number' ? new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(currentPrice) : 'N/A')}
        </h2>
      }
    </>
  );
} 

export default ChartHeader;
