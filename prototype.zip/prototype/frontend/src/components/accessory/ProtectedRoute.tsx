import { Navigate } from 'react-router-dom';
import { useAuth0 } from '@auth0/auth0-react';
import { WaveDots } from '../accessory/loading';

export const ProtectedRoute: React.FC<{ element: React.ReactElement }> = ({ element }) => {
  const { isAuthenticated, isLoading } = useAuth0();
  
  if (isLoading) {
    return <WaveDots />;
  }
  
  return isAuthenticated ? element : <Navigate to="/login" />;
};
