import React from 'react'

const ModalDivider = () => {
  return <div className='w-full absolute left-0 bottom-[-15px] h-[1px] bg-[#ccc]' />
}
export default ModalDivider;