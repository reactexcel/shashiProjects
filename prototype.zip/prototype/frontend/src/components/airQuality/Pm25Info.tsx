import React from 'react';
import { Pm25Hourly } from '../../types/types';
import { hour24to12 } from '../../helpers/helperFunctions';

interface Pm25InfoBoxProps {
  data: Pm25Hourly[];
}

const Pm25InfoBox: React.FC<Pm25InfoBoxProps> = ({ data }) => {
  if (data.length === 0) {
    return <div></div>;
  }

  let minPm25 = Infinity;
  let maxPm25 = -Infinity;
  let buyHour = -1;
  let sellHour = -1;


  for (const { avg_pm_25, hour_of_day } of data) {
    const pm25 = Number(avg_pm_25);
    const hour = Number(hour_of_day);

    if (avg_pm_25 < minPm25) {
      minPm25 = pm25;
      buyHour = hour;
    }
    
    if (avg_pm_25 > maxPm25) {
      maxPm25 = avg_pm_25;
      sellHour = hour;
    }
  }
  
  const maxGain = ((maxPm25 - minPm25) / minPm25) * 100;

  return (
    <div className='text-gray-600'>
      <div>Max Gain: <span className='font-medium text-[var(--turquoise-green)]'>{maxGain.toFixed(2)}%</span></div>
      <div>High: {hour24to12(sellHour)} | Low: {hour24to12(buyHour)}</div>
      <div></div>
    </div>
  );
};

export default Pm25InfoBox;
