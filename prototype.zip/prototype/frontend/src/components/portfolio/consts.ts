export const pageTitleClass = "text-[24px] md:text-[35px] font-bold text-[var(--primary-text-color)] "

export const tooltipMessageAnnualProfiit = "Your Annual Profit is calculated as the difference between your current net worth (sum of cash and asset values) and your net worth from either one year ago or the time of your account creation, whichever is more recent."

export const tooltipMessageRoi = "Your Return on Investment (ROI) is calculated by dividing your Annual Profit by your net worth, as it was either one year ago or at the time of your account creation, whichever date is more recent."