export const dummy = {
  
    assetsHoldings: {
      columns: [
        {
          key: "asset",
          label: "Asset",
          type: "text",
          isLeftAligned:true,
        },
        {
          key: "quantity",
          label: "Quantity",
          type: "number",
          isLeftAligned:false,
        },
        {
          key: "shares",
          label: "Shares",
          type: "number",
          isLeftAligned:false,
        },
        {
          key: "value",
          label: "Value",
          type: "number",
          isLeftAligned:false,
        },
        {
          key: "color",
          label: "Color",
          type: "text",
          isLeftAligned:false,
        }
      ],
      data: [
        {
          data: {
            color: "#F6B9AA",
            asset: "New York City",
            quantity: "4288",
            shares: "4288",
            value: "988069",
            
          },
          id: 1381664
        },
        {
          data: {
            color: "#C3C1EB",
            asset: "Toronto",
            quantity: "24885",
            shares: "24885",
            value: "12878696"
          },
          id: 1381668
        },
        {
          data: {
            color: "#86D4D5",
            asset: "San Francisco",
            quantity: "3755",
            shares: "3755",
            value: "7077703"
          },
          id: 1381669
        },
        {
          data: {
            color: "#D5BF86",
            asset: "Miami",
            quantity: "8089",
            shares: "8089",
            value: "30465942"
          },
          id: 1381665
        },
        {
          data: {
            color: "#FFF7AF",
            asset: "Napa Valley",
            quantity: "0.99",
            shares: "0.99",
            value: "1205.79"
          },
          id: 1380909
        },
        {
          data: {
            color: "#C2C2C2",
            asset: "London",
            quantity: "9400.13",
            shares: "9400.13",
            value: "36396980.62"
          },
          id: 1381670
        },
        {
          data: {
            color: "#FFD699",
            asset: "Mexico City",
            quantity: "503786.60",
            shares: "503786.60",
            value: "1095702.87"
          },
          id: 1381666
        },
        {
          data: {
            color: "#FFC3DC",
            asset: "Sydney",
            quantity: "2106.93",
            shares: "2106.93",
            value: "4596164.49"
          },
          id: 1381667
        },
        {
          data: {
            color: "#05FFFF33",
            asset: "Chicago",
            quantity: "2077",
            shares: "2077",
            value: "13311708"
          },
          id: 1381671
        },
        {
          data: {
            color: "#FF7878",
            asset: "Philadelphia",
            quantity: "8877",
            shares: "8877",
            value: "11740430.82"
          },
          id: 1381672
        }
      ]
    },
    assetsHoldingsChartData: [
      {
        color: "#F6B9AA",
        name: "New York City",
        percentage: "20",
        value: "988069"
      },
      {
        color: "#C3C1EB",
        name: "Toronto",
        percentage: "30",
        value: "12878696"
      },
      {
        color: "#86D4D5",
        name: "San Francisco",
        percentage: "5",
        value: "7077703"
      },
      {
        color: "#D5BF86",
        name: "Miami",
        percentage: "13",
        value: "30465942"
      },
      {
        color: "#FFF7AF",
        name: "Napa Valley",
        percentage: "23",
        value: "1205"
      },
      {
        color: "#C2C2C2",
        name: "London",
        percentage: "45",
        value: "36396980"
      },
      {
        color: "#FFD699",
        name: "Mexico City",
        percentage: "20",
        value: "1095702"
      },
      {
        color: "#FFC3DC",
        name: "Sydney",
        percentage: "15",
        value: "4596164"
      },
      {
        color: "#05FFFF33",
        name: "Chicago",
        percentage: "10",
        value: "13311708"
      },
      {
        color: "#FF7878",
        name: "Philadelphia",
        percentage: "11",
        value: "11740430"
      }
    ],
    portfolioData: {
      annualProfit: "120867036",
      assetsValue: "11855260",
      cashBalance: "2315431",
      roiPercent: "100.00"
    },
    recentTransactions: {
      columns: [
        {
          key: "type",
          label: "Type",
          type: "text",
          isLeftAligned:true,
        },
        {
          key: "asset",
          label: "Asset",
          type: "text",
          isLeftAligned:false,
          isBold:true
        },
        {
          key: "total",
          label: "Total",
          type: "currency",
          isLeftAligned:false,
          isBold:true
        },
        {
          key: "quantity",
          label: "Quantity",
          type: "number",
          isLeftAligned:false,
        },
        {
          key: "price",
          label: "Price",
          type: "currency",
          isLeftAligned:false,
        },
        {
          key: "date",
          label: "Date",
          type: "date",
          isLeftAligned:false,
        }
      ],
      data: [
        {
          data: {
            date: "Wed, 06 Dec 2023 10:23:54 GMT",
            asset: "New York City",
            price: "232.13",
            quantity: "14.15",
            total: "3.28K",
            type: "BUY"
          },
          id: 1106130
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:24:08 GMT",
            asset: "Philadelphia",
            price: "1.32K",
            quantity: "132.44",
            total: "175.14K",
            type: "BUY"
          },
          id: 1106134
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:04 GMT",
            asset: "Toronto",
            price: "501.18",
            quantity: "162.28",
            total: "81.33K",
            type: "SELL"
          },
          id: 1106217
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:07 GMT",
            asset: "London",
            price: "3.86K",
            quantity: "11.26",
            total: "43.42K",
            type: "SELL"
          },
          id: 1106218
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:10 GMT",
            asset: "Mexico City",
            price: "2.13",
            quantity: "174.98",
            total: "373.48",
            type: "SELL"
          },
          id: 1106219
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:12 GMT",
            asset: "Sydney",
            price: "2.18K",
            quantity: "4.07",
            total: "8.88K",
            type: "SELL"
          },
          id: 1106220
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:14 GMT",
            asset: "New York City",
            price: "232.04",
            quantity: "35.69",
            total: "8.28K",
            type: "BUY"
          },
          id: 1106221
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:18 GMT",
            asset: "San Francisco",
            price: "1.94K",
            quantity: "29.32",
            total: "57.00K",
            type: "BUY"
          },
          id: 1106222
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:21 GMT",
            asset: "Miami",
            price: "3.80K",
            quantity: "0.98",
            total: "3.73K",
            type: "BUY"
          },
          id: 1106223
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:25 GMT",
            asset: "Chicago",
            price: "6.29K",
            quantity: "0.40",
            total: "2.50K",
            type: "BUY"
          },
          id: 1106224
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:30:29 GMT",
            asset: "Philadelphia",
            price: "1.32K",
            quantity: "148.51",
            total: "196.70K",
            type: "BUY"
          },
          id: 1106225
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:46 GMT",
            asset: "New York City",
            price: "229.38",
            quantity: "44.11",
            total: "10.12K",
            type: "SELL"
          },
          id: 1106292
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:49 GMT",
            asset: "Miami",
            price: "3.75K",
            quantity: "6.14",
            total: "23.06K",
            type: "SELL"
          },
          id: 1106293
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:51 GMT",
            asset: "London",
            price: "3.86K",
            quantity: "9.52",
            total: "36.73K",
            type: "SELL"
          },
          id: 1106294
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:53 GMT",
            asset: "Sydney",
            price: "2.18K",
            quantity: "8.13",
            total: "17.72K",
            type: "SELL"
          },
          id: 1106295
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:55 GMT",
            asset: "Toronto",
            price: "507.16",
            quantity: "16.61",
            total: "8.42K",
            type: "BUY"
          },
          id: 1106296
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:35:59 GMT",
            asset: "San Francisco",
            price: "1.94K",
            quantity: "13.50",
            total: "26.17K",
            type: "BUY"
          },
          id: 1106297
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:36:03 GMT",
            asset: "Mexico City",
            price: "2.16",
            quantity: "593.98",
            total: "1.29K",
            type: "BUY"
          },
          id: 1106298
        },
        {
          data: {
            date: "Wed, 06 Dec 2023 10:36:06 GMT",
            asset: "Chicago",
            price: "6.34K",
            quantity: "31.55",
            total: "200.04K",
            type: "BUY"
          },
          id: 1106299
        },
        {
          data: {
            date: "Tue, 05 Dec 2023 10:48:09 GMT",
            asset: "London",
            price: "3.86K",
            quantity: "1.45",
            total: "5.61K",
            type: "SELL"
          },
          id: 1106462
        },
      
      ]
    },
    userDetails: {
      isUsersPortfolio: false,
      name: "Frederick Fisher",
      userId: 1
    }
}