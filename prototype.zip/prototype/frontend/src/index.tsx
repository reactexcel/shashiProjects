import '@fortawesome/fontawesome-free/css/all.css';
import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Auth0Provider } from '@auth0/auth0-react';



const AppWrapper = process.env.REACT_APP_API_BASE_URL === 'http://127.0.0.1:10000/' 
  ? <React.StrictMode><App /></React.StrictMode> 
  : <App />;

const Auth0Wrapper = () => (
  <Auth0Provider
  {...providerConfig}
  >
    {AppWrapper}
  </Auth0Provider>
);

const providerConfig = {
  domain:"dev-bbhs6iyj1zc2s7gz.us.auth0.com",
  clientId:"CYOwKnqHBC1e0CdcOhmfonuOzrn5TgY1",
  authorizationParams: {
    redirect_uri: window.location.origin,
  },
};
const root = createRoot(document.getElementById('root') as HTMLElement);
root.render(
  <Auth0Wrapper />
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
