import { Dispatch, SetStateAction } from 'react';

export type Pm25Hourly = { avg_pm_25: number, hour_of_day: number }
export type Pm25Daily = { avg_pm_25: number, day_of_week: string, index: number }

export type Asset = {
  id: number
  name: string
  price: number
  pm25: number
}

export type ChartTimeFrame = 'HOUR' | '5HOUR' | 'DAY' | 'WEEK';

export type LineChartData = {
  priceHistory?: LineDataPoint[];
  dividendHistory?: LineDataPoint[];
  assetName: string;
};

export interface LineDataPoint {
  date: string;
  value: number;
}


export interface ShapeProps {
  cx: number;
  cy: number;
  payload: ScatterChartDataPoint;
}

export interface CustomShapeFunctionProps {
  shapeProps: ShapeProps;
  hoveredAssetId: number | null;
  getColorBasedOnAssetId: (assetId: number) => string;
  setHoveredPoint: Dispatch<SetStateAction<ScatterChartDataPoint | null>>;
}

export interface ChartLegendProps {
  assets: AssetsType;
  setHoveredAssetId: React.Dispatch<React.SetStateAction<number | null>>;
}

export type ScatterChartData = {
  xAxis: string;
  yAxis: string;
  assets: AssetsType;
  data: ScatterChartDataPoint[];
  correlation: number;
}

export type MultiScatterChartData = { [key: string]: ScatterChartData };

export type AssetsType = { [key: number]: string };

export type ScatterChartDataPoint = {
  x: number;
  y: number;
  assetId: number;
  cycleId: number;
};

export type MarketData = {
  [key: string]: {
    order: number
    "24hr_change": string,
    label: string,
    value: string,
  }
}


export type Column = {
  label: string;
  type: string;
  key: string;
  isLeftAligned?:boolean
  isBold?:boolean
};

export type TableRowProps = {
  row: {
    id: number;
    data: {
      [key: string]: any;
    };
  };
  columns: Column[];
  selectedRowId?: number | null
  _onRowClick?: (row:any) => void | undefined
};

export type PercentCellProps = { 
  percent: string
  col:Column
  bgColor:string | undefined
}


export type AssetData = {
  assets: Array<{
    id: number;
    data: {
      [key: string]: any;
    };
  }>;
  columns: Column[];
};

export interface TableData {
  data: any[];
  columns: Column[];
}

export interface NumberedTableData {
  [key: number]: TableData;
}

export interface PortfolioInfoCardData {
  annualProfit: string
  assetsValue:string
  cashBalance:string
  roiPercent:string
}

export type PortfolioUserData = {
  isUsersPortfolio:Boolean
  name:string
  userId:number
}



export interface AssetHoldingsValuesData {
  data: {
    asset: string;
    color: string;
    quantity: string;
    shares: string;
    value: string;
  };
  id: number;
}

export interface LeaderboardValuesData {
    data: {
      rank: string,
      name: string,
      net_worth: string,
      profit: string,
      roi: string,
      row_color: string,
      user_id: number
    },
    id: number
}

export interface RecentTransactionValuesData {
  data: {
    date: string,
    asset: string,
    price: string,
    quantity: string,
    total: string,
    type: "BUY" | "SELL"
  },
  id: number
}
export interface AssetsHoldings {
  columns: Column[];
  data: AssetHoldingsValuesData[];
}

export interface AssetsHoldingsChartData {
  color: string;
  name: string;
  percentage: string;
  value: string;
}

export interface PortfolioData {
  annualProfit: string;
  assetsValue: string;
  cashBalance: string;
  roiPercent: string;
}

export interface RecentTransaction {
  columns: Column[];
  data: RecentTransactionValuesData[]; 
}


export interface LeaderboardData {
  data:LeaderboardValuesData[]
  columns:Column[]
}
export interface PortfolioAPIResponse {
  assetsHoldings: AssetsHoldings;
  assetsHoldingsChartData: AssetsHoldingsChartData[];
  portfolioData: PortfolioData;
  recentTransactions: RecentTransaction;
  userDetails: PortfolioUserData;
}

export interface LeaderboardAPIResponse {
  leaderboard: LeaderboardData
}
