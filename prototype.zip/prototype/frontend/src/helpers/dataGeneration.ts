import { useEffect, useState } from 'react';
import { TableData, NumberedTableData, LineDataPoint, ScatterChartDataPoint, ScatterChartData, ChartTimeFrame, LineChartData, Asset, Pm25Hourly, Pm25Daily } from '../types/types';

export const createMultiScatterChartData = () => {
  const airMeasure = createScatterChartData()
  const priceDividend = createScatterChartData();
  return {airMeasure, priceDividend}
}

export const createScatterChartData = (
  xAxisLabel: string = "[Sample] Price",
  yAxisLabel: string = "PM2.5 10 Minute Average",
  correlationValue: number = 0
): ScatterChartData => {
  const dataPoints = generateHighCorrelationData(1000)
  const assetMap: { [key: number]: string } = {};

  dataPoints.forEach((point) => {
    assetMap[point.assetId] = `Asset ${point.assetId}`;
  });

  return {
    xAxis: xAxisLabel,
    yAxis: yAxisLabel,
    assets: assetMap,
    data: dataPoints,
    correlation: correlationValue,
  };
};

const getRandomNumber = (min: number, max: number): number => {
  return Math.random() * (max - min) + min;
};

export const generateHighCorrelationData = (numPoints: number): ScatterChartDataPoint[] => {
  const data: ScatterChartDataPoint[] = [];
  for (let i = 0; i < numPoints; i++) {
    const x = getRandomNumber(1000, 5000);
    const y = x * (1 + getRandomNumber(0,2));
    const assetId = Math.round(getRandomNumber(1, 10));
    data.push({ x, y, assetId, cycleId: 1 });
  }
  return data;
};


export const generateDividendLineChartData = (timeFrame: ChartTimeFrame, numDataPoints: number = 100): LineChartData => {
  const dividendHistory = generateLineData(timeFrame, numDataPoints)
  const assetName = ""
  return { dividendHistory, assetName }
}

export const generatePriceLineChartData = (timeFrame: ChartTimeFrame, numDataPoints: number = 100): LineChartData => {
  const priceHistory = generateLineData(timeFrame, numDataPoints)
  const assetName = "Boulder"
  return { priceHistory, assetName }
}
// Function to generate data based on the given timeframe
export const generateLineData = (timeFrame: ChartTimeFrame, numDataPoints: number = 100): LineDataPoint[] => {
  const data: LineDataPoint[] = [];
  let currentDate = new Date();
  let currentPrice = 2700; // Initial price

  for (let i = 0; i < numDataPoints; i++) {
    const percentageFluctuation = (Math.random() * 2 - 1) / 100; // Fluctuate price by up to +/- 1%
    currentPrice *= (1 + percentageFluctuation);

    const dataPoint: LineDataPoint = {
      date: currentDate.toUTCString(),
      value: parseFloat(currentPrice.toFixed(4)), // Limit to 4 decimal places
    };

    data.push(dataPoint);

    switch (timeFrame) {
      case 'HOUR':
        currentDate = new Date(currentDate.getTime() + 60 * 1000); // Add 1 minute
        break;
      case '5HOUR':
        currentDate = new Date(currentDate.getTime() + 5 * 60 * 60 * 1000); // Add 5 hours
        break;
      case 'DAY':
        currentDate = new Date(currentDate.getTime() + 24 * 60 * 60 * 1000); // Add 1 day
        break;
      case 'WEEK':
        currentDate = new Date(currentDate.getTime() + 7 * 24 * 60 * 60 * 1000); // Add 1 week
        break;
    }
  }

  return data;
}

const generateRandompm25Value = (): number => {
  return Math.random() * (35 - 2) + 2;
}

export const generateAssetsData = () => {
    const assets: Asset[] = [];
    const cities = ["New York", "Los Angeles", "Chicago", "Houston", "Phoenix", "Philadelphia", "San Antonio", "San Diego", "Dallas", "San Jose"]
  
    for (let i = 0; i < cities.length; i++) {
      const asset: Asset = {
        id: i,
        name: cities[i],
        price: parseFloat((Math.random() * 2000).toFixed(2)),
        pm25: generateRandompm25Value(),
      };
    
      assets.push(asset);
    }
  
    return assets;
}

export const generatePm25HourlyData = (): Pm25Hourly[] => {
    const data = []
    for (let i = 0; i < 24; i++) {
      const asset: Pm25Hourly = {
        avg_pm_25: generateRandompm25Value(),
        hour_of_day: i,
      };
    
      data.push(asset);
    }
  
    return data;
}
export const generatePm25DailyData = (): Pm25Daily[] => {
    const data = []
    for (let i = 0; i < 7; i++) {
      const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
      const datapoint: Pm25Daily = {
        avg_pm_25: generateRandompm25Value(),
        index: i,
        day_of_week: days[i],
      };
    
      data.push(datapoint);
    }
  
    return data;
}


export const generatePortfolioData = (():{asset_aggregates: TableData, trade_info: NumberedTableData} => {
  return  {
    "asset_aggregates": {
      "columns": [
        {
          "key": "name",
          "label": "Asset Traded",
          "type": "text"
        },
        {
          "key": "realized_profit",
          "label": "Realized Profit",
          "type": "currency"
        },
        {
          "key": "realized_roi",
          "label": "Realized ROI",
          "type": "percentage"
        },
        {
          "key": "unrealized_profit",
          "label": "Unrealized Profit",
          "type": "currency"
        },
        {
          "key": "total_trades",
          "label": "Total Trades",
          "type": "number"
        }
      ],
      "data": [
        {
          "data": {
            "name": "San Francisco",
            "realized_profit": "22.97M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 3
        },
        {
          "data": {
            "name": "Napa Valley",
            "realized_profit": "18.45M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 5
        },
        {
          "data": {
            "name": "London",
            "realized_profit": "30.92M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 6
        },
        {
          "data": {
            "name": "Sydney",
            "realized_profit": "66.10M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 8
        },
        {
          "data": {
            "name": "New York City",
            "realized_profit": "23.67M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 1
        },
        {
          "data": {
            "name": "Toronto",
            "realized_profit": "29.17M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 2
        },
        {
          "data": {
            "name": "Mexico City",
            "realized_profit": "22.08M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 7
        },
        {
          "data": {
            "name": "Chicago",
            "realized_profit": "25.96M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 9
        },
        {
          "data": {
            "name": "Philadelphia",
            "realized_profit": "37.57M",
            "realized_roi": "0.00",
            "total_trades": 2,
            "unrealized_profit": "0.00"
          },
          "id": 10
        }
      ]
    },
    "trade_info": {
      "1": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "date"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "10.60M",
              "date": "Wed, 11 Oct 2023 18:45:31 GMT",
              "price": "1.01K",
              "quantity": "10.50K",
              "type": "BUY"
            },
            "id": 38053
          },
          {
            "data": {
              "USD": "13.07M",
              "date": "Wed, 11 Oct 2023 18:40:28 GMT",
              "price": "1.01K",
              "quantity": "12.95K",
              "type": "BUY"
            },
            "id": 38006
          }
        ]
      },
      "2": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "13.05M",
              "date": "Wed, 11 Oct 2023 18:45:31 GMT",
              "price": "820.46",
              "quantity": "15.91K",
              "type": "BUY"
            },
            "id": 38054
          },
          {
            "data": {
              "USD": "16.11M",
              "date": "Wed, 11 Oct 2023 18:40:29 GMT",
              "price": "818.77",
              "quantity": "19.68K",
              "type": "BUY"
            },
            "id": 38007
          }
        ]
      },
      "3": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "8.83M",
              "date": "Wed, 11 Oct 2023 18:45:28 GMT",
              "price": "1.07K",
              "quantity": "8.24K",
              "type": "SELL"
            },
            "id": 38049
          },
          {
            "data": {
              "USD": "14.14M",
              "date": "Wed, 11 Oct 2023 18:40:26 GMT",
              "price": "1.07K",
              "quantity": "13.19K",
              "type": "SELL"
            },
            "id": 38002
          }
        ]
      },
      "5": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "8.23M",
              "date": "Wed, 11 Oct 2023 18:45:28 GMT",
              "price": "1.07K",
              "quantity": "7.67K",
              "type": "SELL"
            },
            "id": 38050
          },
          {
            "data": {
              "USD": "10.23M",
              "date": "Wed, 11 Oct 2023 18:40:26 GMT",
              "price": "1.07K",
              "quantity": "9.54K",
              "type": "SELL"
            },
            "id": 38003
          }
        ]
      },
      "6": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "12.49M",
              "date": "Wed, 11 Oct 2023 18:45:29 GMT",
              "price": "528.27",
              "quantity": "23.64K",
              "type": "SELL"
            },
            "id": 38051
          },
          {
            "data": {
              "USD": "18.43M",
              "date": "Wed, 11 Oct 2023 18:40:27 GMT",
              "price": "529.49",
              "quantity": "34.82K",
              "type": "SELL"
            },
            "id": 38004
          }
        ]
      },
      "7": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "9.90M",
              "date": "Wed, 11 Oct 2023 18:45:32 GMT",
              "price": "407.90",
              "quantity": "24.26K",
              "type": "BUY"
            },
            "id": 38055
          },
          {
            "data": {
              "USD": "12.19M",
              "date": "Wed, 11 Oct 2023 18:40:30 GMT",
              "price": "408.09",
              "quantity": "29.86K",
              "type": "BUY"
            },
            "id": 38008
          }
        ]
      },
      "8": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "32.44M",
              "date": "Wed, 11 Oct 2023 18:45:30 GMT",
              "price": "930.47",
              "quantity": "34.86K",
              "type": "SELL"
            },
            "id": 38052
          },
          {
            "data": {
              "USD": "33.66M",
              "date": "Wed, 11 Oct 2023 18:40:27 GMT",
              "price": "934.13",
              "quantity": "36.04K",
              "type": "SELL"
            },
            "id": 38005
          }
        ]
      },
      "9": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "11.62M",
              "date": "Wed, 11 Oct 2023 18:45:33 GMT",
              "price": "921.13",
              "quantity": "12.62K",
              "type": "BUY"
            },
            "id": 38056
          },
          {
            "data": {
              "USD": "14.34M",
              "date": "Wed, 11 Oct 2023 18:40:31 GMT",
              "price": "920.09",
              "quantity": "15.58K",
              "type": "BUY"
            },
            "id": 38009
          }
        ]
      },
      "10": {
        "columns": [
          {
            "key": "type",
            "label": "Type",
            "type": "text"
          },
          {
            "key": "quantity",
            "label": "Quantity",
            "type": "number"
          },
          {
            "key": "USD",
            "label": "USD",
            "type": "currency"
          },
          {
            "key": "price",
            "label": "Price",
            "type": "currency"
          },
          {
            "key": "date",
            "label": "Date",
            "type": "text"
          }
        ],
        "data": [
          {
            "data": {
              "USD": "16.81M",
              "date": "Wed, 11 Oct 2023 18:45:34 GMT",
              "price": "637.33",
              "quantity": "26.37K",
              "type": "BUY"
            },
            "id": 38057
          },
          {
            "data": {
              "USD": "20.76M",
              "date": "Wed, 11 Oct 2023 18:40:32 GMT",
              "price": "635.66",
              "quantity": "32.66K",
              "type": "BUY"
            },
            "id": 38010
          }
        ]
      }
    }
  }
})