import { axiosInstance } from './axios';
import { NumberedTableData, TableData, Column, MarketData, MultiScatterChartData, LineChartData, Asset, Pm25Hourly, Pm25Daily } from '../types/types';
import {
  createMultiScatterChartData,
  generatePriceLineChartData,
  generateDividendLineChartData,
  generateAssetsData,
  generatePm25HourlyData,
  generatePm25DailyData,
  generatePortfolioData
} from '../helpers/dataGeneration';
import { isDevelopment } from './constants';


const getScatterChartData = async (): Promise<MultiScatterChartData | null> => {
  const url = `correlations`;
  try {
    return axiosInstance.get(url).then((response) => {
      if (isDevelopment) {
        return createMultiScatterChartData();
      } else {
        const airMeasure = response.data['air_measure_data'];
        const priceDividend = response.data['dividend_to_price_data'];
        const priceAirMeasure = response.data['price_to_air_measure_data'];
        return { airMeasure, priceDividend, priceAirMeasure }
      }
    });
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}

const getNextDividends = async (asset_id?:string | undefined): Promise<number | null> => {
  const url = `${asset_id ?  `next_dividend/${asset_id}` : 'expected_next_dividend_pool'}`;
  try {
    return axiosInstance.get(url).then((response) => {
      return asset_id ? response.data['next_dividend'] : response.data['expected_dividends']
    });
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}

const getMarketOverview = async (): Promise<MarketData | null> => {
  const url = `market_overview`;
  try {
    return axiosInstance.get(url).then((response) => {
      return response.data['data'];
    });
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}

const getAssets = async (getPM25: boolean = true): Promise<Asset[] | null> => {
  const url = `assets?get_pm25=${getPM25}`;
  try {
    if (isDevelopment) {
      return generateAssetsData();
    }
    const response = await axiosInstance.get(url);
    if (response.status !== 200) {
      console.error(`Failed with status code: ${response.status}`);
      console.error(response);
      throw new Error(response.statusText);
    }
    return response.data['assets'];
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}

const getPm25ByHourAndDay = async (assetId: number): Promise<([Pm25Daily[], Pm25Hourly[], string]) | null> => {
  const url = `air_quality?asset_id=${assetId}`;
  try {
    if (isDevelopment) {
      return [generatePm25DailyData(), generatePm25HourlyData(), 'San Fransico'];
    }
    const response = await axiosInstance.get(url);
    if (response.status !== 200) {
      console.error(`Failed with status code: ${response.status}`);
      console.error(response);
      throw new Error(response.statusText);
    }
    const byDay = response.data['air_quality_by_day'] as Pm25Daily[];
    const byHour = response.data['air_quality_by_hour'] as Pm25Hourly[];
    const assetName = response.data['asset_name'] as string;
    return [byDay, byHour, assetName]
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}


const getAssetTableData = async (): Promise<TableData | null> => {
  const url = `assets_table`;
  try {
    const response = await axiosInstance.get(url);
    if (response.status !== 200) {
      console.error(`Failed with status code: ${response.status}`);
      throw new Error(response.statusText);
    }
    return {
      data: response.data['data'],
      columns: response.data['columns'] as unknown as Column[]
    };
  } catch (error: any) {
    console.log(error.message)
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
};


export const getPortfolioTableData = async (userId: number, transactionsSince: number): Promise<{ asset_aggregates: TableData, trade_info: NumberedTableData, cash: string, netWorth: string } | null> => {
  if (isDevelopment) {
    return { ...generatePortfolioData(), cash: '123.45', netWorth: '1.23B' }
  }
  const url = `transaction_info?transactions_since=${transactionsSince}&user_id=${userId}`;
  try {
    const response = await axiosInstance.get(url);

    if (response.status !== 200) {
      console.error(`Failed with status code: ${response.status}`);
      throw new Error(response.statusText);
    }

    const asset_aggregates: TableData = {
      data: response.data.data['asset_aggregates']['data'],
      columns: response.data.data['asset_aggregates']['columns'] as unknown as Column[]
    };

    const trade_info: NumberedTableData = response.data.data['trade_info'];

    const cash: string = response.data.data['cash']
    const netWorth: string = response.data.data['net_worth']

    return { asset_aggregates, trade_info, cash, netWorth }; // Return an object containing both values

  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
};


const swap = async (
  user_id: string,
  pool_id: string,
  token_in: string,
  amount_in: number
) => {
  const amount_in_as_number = Number(amount_in);
  try {
    const response = await axiosInstance.post(`swap`, {
      user_id,
      pool_id,
      token_in,
      amount_in: amount_in_as_number
    });

    return response.data;
  } catch (error: any) {
    console.error(`Error fetching order info: ${error.message}`);
    throw error;
  }

};

const userTokenQuantity = async (
  user_id: string,
  token_id: string,
) => {
  try {
    const response = await axiosInstance.get(`user-token-quantity`, {
      params: {
        user_id,
        token_id
      }
    });
    if (response.status !== 200) {
      console.error(`Failed with status code: ${response.status}`);
      console.error(response);
      throw new Error(response.statusText);
    }

    const { quantity } = response.data;
    return { quantity }
  } catch (error: any) {
    console.error(`Error fetching order info: ${error.message}`);
    throw error;
  }
}

const getPrice = async (token_id: string) => {
  const response = await axiosInstance.get(`price`, {
    params: {
      token_id
    }
  });
  const { price } = response.data;
  return price;
};

const getPriceChartData = async (assetId: number = 1, period: string = 'DAY'): Promise<LineChartData | undefined> => {
  const url = `price_history?asset_id=${assetId}&period=${period}`;
  try {
    if (isDevelopment) {
      return generatePriceLineChartData('HOUR');
    } else {
      const response = await axiosInstance.get<LineChartData>(url);
      return {
        priceHistory: response.data.priceHistory,
        assetName: response.data.assetName,
      };
    }
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
};

const getDividendChartData = async (assetId: number = 1, period: string = 'DAY'): Promise<LineChartData | undefined> => {
  const url = `dividend_history?asset_id=${assetId}&period=${period}`;
  try {
    if (isDevelopment) {
      return generateDividendLineChartData('HOUR');
    } else {
      const response = await axiosInstance.get<LineChartData>(url);
      return {
        dividendHistory: response.data.dividendHistory,
        assetName: response.data.assetName,
      };
    }
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
};

const getAssetInfo = (assetId: number = 1) => {
  const period = 'WEEK';
  const url = `asset?asset_id=${assetId}&period=${period}`;
  try {
    return axiosInstance.get(url).then((response) => {
      return response.data['data'];
    });
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
};

const createUser = async (name: string, email: string, user_id: string) => {
  try {
    const response = await axiosInstance.post(`/auth`, {
      name: name,
      email: email,
      user_id: user_id
    });
    return response.data;
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw new Error("Failed create or update profile");
  }
}

const getPortFolioData = async (id:string|undefined) =>{
  const url = id ? `portfolio/${id}`: 'portfolio'
  try {
    return axiosInstance.get(url).then((response) => {
      return response.data;
    })
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}

const getLeaderboardData = async () =>{
  const url = 'leaderboard'
  try {
    return axiosInstance.get(url).then((response) => {
      return response.data;
    })
  } catch (error: any) {
    console.error("Axios error", error.response?.data || error);
    throw error;
  }
}


export {
  getAssets,
  getAssetInfo,
  getPm25ByHourAndDay,
  getScatterChartData,
  getNextDividends,
  getMarketOverview,
  swap,
  getPriceChartData,
  getDividendChartData,
  userTokenQuantity,
  getAssetTableData,
  getPrice,
  createUser,
  getPortFolioData,
  getLeaderboardData
};