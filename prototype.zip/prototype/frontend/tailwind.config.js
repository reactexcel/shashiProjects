/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      fontSize: {
        'md+': '0.90em',
        '2xs': '0.60em',
      },
      screens: {
        'xs': '450px',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}