import os
from app import create_app
from dotenv import load_dotenv
load_dotenv()

app = create_app(run=True)

def is_development():
    if os.environ.get('FLASK_ENV') == 'production':
        return False
    return True

if __name__ == '__main__':
    FLASK_ENV = os.environ.get('FLASK_ENV', 'production')
    DEBUG_MODE = os.environ.get('DEBUG_MODE', 'False').lower() == 'true'

    if is_development():
        app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 10000)), debug=DEBUG_MODE)
    else:
        print("Production mode, use Gunicorn to run the application")
