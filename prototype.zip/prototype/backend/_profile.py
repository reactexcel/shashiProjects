import os
import argparse
import glob
import pstats

# Set up command line argument parsing
parser = argparse.ArgumentParser(description="Process profile output files.")
parser.add_argument("--latest-only", action="store_true", help="Process only the latest profile output file.")
parser.add_argument("--focus-path", type=str, default='/backend/app/models/', help="Focus on files starting with this path.")
parser.add_argument("--num", type=int, default=15, help="Number of values to print in the stats.")

args = parser.parse_args()

focus_path = args.focus_path
get_latest_only = args.latest_only  # Use command line argument to set this flag
num_values_to_print = args.num  # Number of values to print in the stats

# Find all profile output files
profile_files = sorted(glob.glob('backend/profile_output_*'), key=os.path.getmtime)

# If only the latest file is needed, slice the list to keep the last element
if get_latest_only:
    profile_files = profile_files[-1:]

# Iterate through each profile file and process it
for profile_file in profile_files:
    stats = pstats.Stats(profile_file)

    # Create a filter function
    def filter_stats(stats_dict, filter_out_starts_with="/usr/", filter_in_starts_with=focus_path):
        filtered_stats = {}
        for func, (cc, nc, tt, ct, callers) in stats_dict.items():
            if not func[0].startswith(filter_out_starts_with) and func[0].startswith(filter_in_starts_with):
                filtered_stats[func] = (cc, nc, tt, ct, callers)
        return filtered_stats
    
    # Apply the filter to the loaded stats
    stats.stats = filter_stats(stats.stats)

    # Now, you can print or sort the stats as usual
    stats.sort_stats('cumtime').print_stats(num_values_to_print)
