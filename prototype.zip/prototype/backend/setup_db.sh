#!/bin/bash

# Check if PostgreSQL is installed
if ! command -v psql &>/dev/null; then
  echo "PostgreSQL is not installed. Installing now..."
  brew install postgresql
else
  echo "PostgreSQL is already installed."
fi

# Check if PostgreSQL is running
if ! pg_isready &>/dev/null; then
  echo "PostgreSQL is not running. Starting now..."
  brew services start postgresql
else
  echo "PostgreSQL is already running."
fi

# Database connection details
DB_NAME="pb_express"
DB_USER="danseider"
DB_PASSWORD="password"
DB_HOST="localhost"
DB_PORT="5432"

SUPERUSER="postgres"

# Check if the database exists, and create it if not
psql postgres -U $SUPERUSER -tc "SELECT 1 FROM pg_database WHERE datname = '$DB_NAME'" | grep -q 1 || psql postgres -U $SUPERUSER -c "CREATE DATABASE $DB_NAME;"

# Check if the user exists, and create it if not
psql postgres -U $SUPERUSER -tc "SELECT 1 FROM pg_roles WHERE rolname = '$DB_USER'" | grep -q 1 || psql postgres -U $SUPERUSER -c "CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';"

# Grant privileges to all tables
psql postgres -U $SUPERUSER -c "GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO $DB_USER;"

# Run the SQL script
export PGPASSWORD="$DB_PASSWORD"
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f $SQL_SCRIPT_PATH
unset PGPASSWORD
