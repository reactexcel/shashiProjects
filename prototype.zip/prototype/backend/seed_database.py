from faker import Faker
from app import db
from app import create_app
from app.models import Asset, Profile
from decimal import Decimal
from app.tests.factories import (
   MarketBalanceFactory, 
   LiquidityPoolFactory,
    PortfolioItemFactory, 
   UserBalanceFactory,
   DividendPayoutFactory,
   AssetDividendFactory,
   AirMeasureFactory,
)
import random

fake = Faker()
app = create_app()

def seed_database():
    with app.app_context():
        db.create_all()

        MarketBalanceFactory(quantity=Decimal(100000))
        db.session.flush()
        UserBalanceFactory.create_batch(size=10)
        db.session.flush()
        LiquidityPoolFactory.create_batch(size=10, create=True)

        assets = Asset.query.all()
        for asset in assets:
            AirMeasureFactory.create(asset_id=asset.id, pm_25_10_minute=25, sensor_count=1)
            AssetDividendFactory.create(asset_id=asset.id, USD=Decimal(300))
            db.session.flush()
        for user in Profile.query.all():
            for asset in Asset.query.all():
                PortfolioItemFactory.create(user_id=user.id, asset_id=asset.id, quantity=Decimal(random.randint(50, 250)))

        db.session.commit()

if __name__ == "__main__":
    seed_database()
