"""add_created_at_to_portfolio_item

Revision ID: 4560f9f023e0
Revises: 348416548311
Create Date: 2023-09-05 20:00:54.129633

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import expression
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.types import DateTime

# Create a custom 'utcnow' function for the default value of 'created_at'
class utcnow(expression.FunctionElement):
    type = DateTime()

@compiles(utcnow, 'postgresql')
def pg_utcnow(element, compiler, **kw):
    return "TIMEZONE('utc', CURRENT_TIMESTAMP)"


# Revision identifiers, used by Alembic.
revision = '4560f9f023e0'
down_revision = '348416548311'
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('portfolio_item', sa.Column('created_at', sa.DateTime, server_default=utcnow(), nullable=False))

def downgrade():
    op.drop_column('portfolio_item', 'created_at')