"""add_created_at_column_to_tables

Revision ID: 4560f9f018e0
Revises: 4760f9f018e0
Create Date: 2023-09-05 20:00:54.129633

"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import expression
from sqlalchemy.ext.compiler import compiles
from sqlalchemy.types import DateTime

# Create a custom 'utcnow' function for the default value of 'created_at'
class utcnow(expression.FunctionElement):
    type = DateTime()

@compiles(utcnow, 'postgresql')
def pg_utcnow(element, compiler, **kw):
    return "TIMEZONE('utc', CURRENT_TIMESTAMP)"

# Revision identifiers, used by Alembic.
revision = '4560f9f018e0'
down_revision = '4760f9f018e0'
branch_labels = None
depends_on = None


def upgrade():
    # Add 'created_at' column to 'Profile'
    op.add_column('profile', sa.Column('created_at', sa.DateTime, server_default=utcnow(), nullable=False))

    # Add 'created_at' column to 'UserBalance'
    op.add_column('user_balance', sa.Column('created_at', sa.DateTime, server_default=utcnow(), nullable=False))

    # Add 'created_at' column to 'PayoutCycle'
    op.add_column('payout_cycle', sa.Column('created_at', sa.DateTime, server_default=utcnow(), nullable=False))

    # Add 'created_at' column to 'MarketBalance'
    op.add_column('market_balance', sa.Column('created_at', sa.DateTime, server_default=utcnow(), nullable=False))


def downgrade():
    # Remove 'created_at' column from 'Profile'
    op.drop_column('Profile', 'created_at')

    # Remove 'created_at' column from 'UserBalance'
    op.drop_column('UserBalance', 'created_at')

    # Remove 'created_at' column from 'PayoutCycle'
    op.drop_column('PayoutCycle', 'created_at')

    # Remove 'created_at' column from 'MarketBalance'
    op.drop_column('MarketBalance', 'created_at')
