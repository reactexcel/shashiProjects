"""Merge heads

Revision ID: 5aa4921cb437
Revises: 4560f9f023e0, ae8c25b04d5f
Create Date: 2023-09-06 01:28:13.469717

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5aa4921cb437'
down_revision = ('4560f9f023e0', 'ae8c25b04d5f')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
