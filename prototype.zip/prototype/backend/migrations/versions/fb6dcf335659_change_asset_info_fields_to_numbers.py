"""Change asset info fields to numbers

Revision ID: fb6dcf335659
Revises: 003c0a6c64e1
Create Date: 2023-11-10 21:04:08.777417

"""
from alembic import op
import sqlalchemy as sa
from app.helpers.shorten_number import shorten_number, expand_number


# revision identifiers, used by Alembic.
revision = 'fb6dcf335659'
down_revision = '003c0a6c64e1'
branch_labels = None
depends_on = None

# Upgrade function
def upgrade():
    conn = op.get_bind()
    with op.batch_alter_table('asset_info', schema=None) as batch_op:
        # Add temporary columns for conversion
       batch_op.add_column(sa.Column('latest_price_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('dp_ratio_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('one_hour_change_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('one_day_change_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('market_cap_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('one_day_trade_vol_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('dividends_24hr_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('pm_25_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('pm_25_1hr_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('pm_25_24hr_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('circulating_supply_temp', sa.Numeric()))
       batch_op.add_column(sa.Column('percent_in_liquidity_pool_temp', sa.Numeric()))

    # Perform data conversion
    asset_info = conn.execute(sa.text("SELECT id, latest_price, dp_ratio, one_hour_change, one_day_change, market_cap, one_day_trade_vol, dividends_24hr, pm_25, pm_25_1hr, pm_25_24hr, circulating_supply, percent_in_liquidity_pool FROM asset_info")).fetchall()
    for row in asset_info:
       # Apply conversion function to each field
       latest_price_numeric = expand_number(row[1])
       latest_dp_ratio_numeric = expand_number(row[2])
       one_hour_change_numeric = expand_number(row[3])
       one_day_change_numeric = expand_number(row[4])
       market_cap_numeric = expand_number(row[5])
       one_day_trade_vol_numeric = expand_number(row[6])
       dividends_24hr_numeric = expand_number(row[7])
       pm_25_numeric = expand_number(row[8])
       pm_25_1hr_numeric = expand_number(row[9])
       pm_25_24hr_numeric = expand_number(row[10])
       circulating_supply_numeric = expand_number(row[11])
       percent_in_liquidity_pool_numeric = expand_number(row[12])
       
       conn.execute(sa.text("UPDATE asset_info SET latest_price_temp = :latest_price WHERE id = :id"), {"latest_price": latest_price_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET dp_ratio_temp = :dp_ratio WHERE id = :id"), {"dp_ratio": latest_dp_ratio_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_hour_change_temp = :one_hour_change WHERE id = :id"), {"one_hour_change": one_hour_change_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_day_change_temp = :one_day_change WHERE id = :id"), {"one_day_change": one_day_change_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET market_cap_temp = :market_cap WHERE id = :id"), {"market_cap": market_cap_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_day_trade_vol_temp = :one_day_trade_vol WHERE id = :id"), {"one_day_trade_vol": one_day_trade_vol_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET dividends_24hr_temp = :dividends_24hr WHERE id = :id"), {"dividends_24hr": dividends_24hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25_temp = :pm_25 WHERE id = :id"), {"pm_25": pm_25_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25_1hr_temp = :pm_25_1hr WHERE id = :id"), {"pm_25_1hr": pm_25_1hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25_24hr_temp = :pm_25_24hr WHERE id = :id"), {"pm_25_24hr": pm_25_24hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET circulating_supply_temp = :circulating_supply WHERE id = :id"), {"circulating_supply": circulating_supply_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET percent_in_liquidity_pool_temp = :percent_in_liquidity_pool WHERE id = :id"), {"percent_in_liquidity_pool": percent_in_liquidity_pool_numeric, "id": row.id})

    with op.batch_alter_table('asset_info', schema=None) as batch_op:
       batch_op.drop_column('latest_price')
       batch_op.drop_column('dp_ratio')
       batch_op.drop_column('one_hour_change')
       batch_op.drop_column('one_day_change')
       batch_op.drop_column('market_cap')
       batch_op.drop_column('one_day_trade_vol')
       batch_op.drop_column('dividends_24hr')
       batch_op.drop_column('pm_25')
       batch_op.drop_column('pm_25_1hr')
       batch_op.drop_column('pm_25_24hr')
       batch_op.drop_column('circulating_supply')
       batch_op.drop_column('percent_in_liquidity_pool')

       # Rename temporary columns to original names
       batch_op.alter_column('latest_price_temp', new_column_name='latest_price')
       batch_op.alter_column('dp_ratio_temp', new_column_name='dp_ratio')
       batch_op.alter_column('one_hour_change_temp', new_column_name='one_hour_change')
       batch_op.alter_column('one_day_change_temp', new_column_name='one_day_change')
       batch_op.alter_column('market_cap_temp', new_column_name='market_cap')
       batch_op.alter_column('one_day_trade_vol_temp', new_column_name='one_day_trade_vol')
       batch_op.alter_column('dividends_24hr_temp', new_column_name='dividends_24hr')
       batch_op.alter_column('pm_25_temp', new_column_name='pm_25')
       batch_op.alter_column('pm_25_1hr_temp', new_column_name='pm_25_1hr')
       batch_op.alter_column('pm_25_24hr_temp', new_column_name='pm_25_24hr')
       batch_op.alter_column('circulating_supply_temp', new_column_name='circulating_supply')
       batch_op.alter_column('percent_in_liquidity_pool_temp', new_column_name='percent_in_liquidity_pool')


    # ### end Alembic commands ###
def downgrade():
    conn = op.get_bind()
    # ### commands auto generated by Alembic - please adjust! ###
    with op.batch_alter_table('asset_info', schema=None) as batch_op:
        batch_op.alter_column('percent_in_liquidity_pool',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('circulating_supply',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('pm_25_24hr',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('pm_25_1hr',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               nullable=True)
        batch_op.alter_column('pm_25',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('dividends_24hr',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('one_day_trade_vol',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('market_cap',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('one_day_change',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('one_hour_change',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               nullable=True)
        batch_op.alter_column('dp_ratio',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
        batch_op.alter_column('latest_price',
               existing_type=sa.Numeric(),
               type_=sa.VARCHAR(length=10),
               existing_nullable=False)
    
    asset_info = conn.execute(sa.text("SELECT id, latest_price, dp_ratio, one_hour_change, one_day_change, market_cap, one_day_trade_vol, dividends_24hr, pm_25, pm_25_1hr, pm_25_24hr, circulating_supply, percent_in_liquidity_pool FROM asset_info")).fetchall()
    for row in asset_info:
       # Apply conversion function to each field
       latest_price_numeric = shorten_number(row[1])
       latest_dp_ratio_numeric = shorten_number(row[2])
       one_hour_change_numeric = shorten_number(row[3])
       one_day_change_numeric = shorten_number(row[4])
       market_cap_numeric = shorten_number(row[5])
       one_day_trade_vol_numeric = shorten_number(row[6])
       dividends_24hr_numeric = shorten_number(row[7])
       pm_25_numeric = shorten_number(row[8])
       pm_25_1hr_numeric = shorten_number(row[9])
       pm_25_24hr_numeric = shorten_number(row[10])
       circulating_supply_numeric = shorten_number(row[11])
       percent_in_liquidity_pool_numeric = shorten_number(row[12])
       
       conn.execute(sa.text("UPDATE asset_info SET latest_price = :latest_price WHERE id = :id"), {"latest_price": latest_price_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET dp_ratio = :dp_ratio WHERE id = :id"), {"dp_ratio": latest_dp_ratio_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_hour_change = :one_hour_change WHERE id = :id"), {"one_hour_change": one_hour_change_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_day_change = :one_day_change WHERE id = :id"), {"one_day_change": one_day_change_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET market_cap = :market_cap WHERE id = :id"), {"market_cap": market_cap_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET one_day_trade_vol = :one_day_trade_vol WHERE id = :id"), {"one_day_trade_vol": one_day_trade_vol_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET dividends_24hr = :dividends_24hr WHERE id = :id"), {"dividends_24hr": dividends_24hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25 = :pm_25 WHERE id = :id"), {"pm_25": pm_25_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25_1hr = :pm_25_1hr WHERE id = :id"), {"pm_25_1hr": pm_25_1hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET pm_25_24hr = :pm_25_24hr WHERE id = :id"), {"pm_25_24hr": pm_25_24hr_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET circulating_supply = :circulating_supply WHERE id = :id"), {"circulating_supply": circulating_supply_numeric, "id": row.id})
       conn.execute(sa.text("UPDATE asset_info SET percent_in_liquidity_pool = :percent_in_liquidity_pool WHERE id = :id"), {"percent_in_liquidity_pool": percent_in_liquidity_pool_numeric, "id": row.id})
       


    # ### end Alembic commands ###
