"""add_created_at_and_payout_cycle_for_asset_dividend

Revision ID: 348416548311
Revises: 4760f9f018e0
Create Date: 2023-09-04 17:17:33.855744

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '348416548311'
down_revision = '4760f9f018e0'
branch_labels = None
depends_on = None


def upgrade():
    # Adding payout_cycle_id column
    op.add_column(
        'asset_dividend',
        sa.Column('payout_cycle_id', sa.Integer, sa.ForeignKey('payout_cycle.id'), index=True)
    )
    
    # Adding created_at column
    op.add_column(
        'asset_dividend',
        sa.Column('created_at', sa.DateTime, nullable=False, server_default=sa.text('CURRENT_TIMESTAMP'))
    )
    
    # Adding unique constraint
    op.create_unique_constraint(
        "uix_1", "asset_dividend", ["asset_id", "payout_cycle_id"]
    )
    
def downgrade():
    # Removing unique constraint
    op.drop_constraint("uix_1", "asset_dividend", type_="unique")
    
    # Removing created_at column
    op.drop_column('asset_dividend', 'created_at')
    
    # Removing payout_cycle_id column
    op.drop_column('asset_dividend', 'payout_cycle_id')
