"""Merge heads

Revision ID: ae8c25b04d5f
Revises: 348416548311, 4560f9f018e0
Create Date: 2023-09-06 00:48:49.030487

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ae8c25b04d5f'
down_revision = ('348416548311', '4560f9f018e0')
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
