from app.services import LiquidityService, PortfolioManagerService
from app.models import Asset, LendingPool, LiquidityPool, Loan, LoanDeposit, UserBalance, PortfolioItem, Pool


class LiquidityApi:

  def buy(self, user_id, usd_in, asset_id):
    return LiquidityService().buy(
              pool_id=None, 
              user_id=user_id, 
              USD_in=usd_in, 
              asset_id=asset_id
            )

  def sell(self, asset_id, user_id, asset_quantity):
    return LiquidityService().sell(
      pool_id=None,
      asset_id=asset_id,
      user_id=user_id,
      asset_quantity=asset_quantity
    )
  
  def asset_price(self, asset_id):
    return LiquidityPool.current_with_asset_id(
            asset_id=asset_id).exchange_rate()
  
  def assets(self):
    return Asset.query.all()


class PortfolioApi:
  def current_portfolio_item(self, asset_id, user_id):
    return PortfolioItem.current(asset_id=asset_id, user_id=user_id)

  def user_portfolio_items(self, user_id):
    return PortfolioItem.latest_user_asset_pairings_for_user(user_id=user_id)
  
  def reallocate_portfolio(self, user_id):
    PortfolioManagerService(user_id=user_id).reallocate_portfolio()


class AccountApi:
  def current_balance(self, user_id):
    return UserBalance.current(user_id=user_id).quantity


class LoanManagerApi:
  def deposit(self, user_id, asset_id, quantity_acquired):
    return LoanDeposit.deposit(
            user_id=user_id,
            asset_id=asset_id,
            amount=quantity_acquired
          )

  def withdraw_all_deposits_and_interest(self, user_id, asset_id):
    return LoanDeposit.withdraw_all_deposits_and_interest(
            user_id=user_id,
            asset_id=asset_id
          )
  
  def user_deposits(self, user_id):
    # Get all user deposits
    return LoanDeposit.current_for_user(user_id=user_id)
  
  def withdraw_interest(self, user_id, asset_id, amount):
    # Withdraw interest on deposits
    return LoanDeposit().withdraw_interest(
                user_id=user_id, 
                asset_id=asset_id, 
                amount=amount
            )
  def withdraw_deposit(self, user_id, asset_id, loan_deposit_amount):
    # Withdraw deposit
    return LoanDeposit.withdraw_deposit(
            user_id=user_id,
            asset_id=asset_id,
            amount=loan_deposit_amount
          )

  def unutilized_deposits(self, asset_id):
    return LendingPool.unutilized_deposits(asset_id=asset_id)
  
  def take_out_loan(self, user_id, asset_id, loan_amount, collateral):
    return Loan.take_out_loan(
            user_id=user_id,
            asset_id=asset_id,
            amount=loan_amount,
            collateral=collateral
          )
  
  def asset_ids_by_utilization_ratio(self):
    return LendingPool.asset_ids_by_utilization_ratio()
