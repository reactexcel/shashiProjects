from collections import deque

class CallLogger:
    def __init__(self, max_entries=4):
        self.calls = deque(maxlen=max_entries)
    
    def log_call(self, func):
        def wrapper(*args, **kwargs):
            self.calls.append((func.__name__, args, kwargs))
            return func(*args, **kwargs)
        return wrapper
    
    def print_calls(self):
        for i, call in enumerate(self.calls):
            function_name, args, kwargs = call
            print(f"Call {i + 1}:")
            print(f"  Function name: {function_name}")
            print(f"  Arguments: {args}")
            print(f"  Keyword arguments: {kwargs}")
            print("-----")

global_call_logger = CallLogger()