import logging
import traceback
from flask import jsonify


def handle_error(exception):
    logging.error(
        f"An error occurred: {exception}\n{traceback.format_exc()}")
    return jsonify({'message': f'An unexpected error occurred {str(exception)}\n{traceback.format_exc()}.'}), 500
