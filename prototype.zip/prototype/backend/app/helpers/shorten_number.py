from decimal import Decimal

def shorten_number(num, decimals=2):
    if num is None:
        return None
    magnitude = 0
    num = Decimal(num)
    while abs(num) >= 1000:
        magnitude += 1
        num /= Decimal('1000.0')
    format_string = "{:." + str(decimals) + "f}"
    formatted_num = format_string.format(num)
    suffixes = ['', 'K', 'M', 'B', 'T', 'Qa', 'Qi']
    suffix = suffixes[magnitude]
    
    return str(formatted_num) + suffix


def expand_number(shortened_number):
    magnitudes = {'Qa': 10**15, 'T': 10**12, 'B': 10**9, 'M': 10**6, 'K': 10**3, '': 1}

    if shortened_number is None:
        return None
    for suffix, magnitude in magnitudes.items():
        if shortened_number.endswith(suffix):
            num_str = shortened_number.replace(suffix, '')
            num = Decimal(num_str) * magnitude
            return num
    return Decimal(shortened_number)
