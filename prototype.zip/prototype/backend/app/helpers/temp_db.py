from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError
import psycopg2
from functools import wraps
import os
from dotenv import load_dotenv
import threading
from flask import jsonify

load_dotenv()
lock = threading.Lock()

temp_db_user = os.environ.get('TEMP_DB_USER')
temp_db_password = os.environ.get('TEMP_DB_PASSWORD')
temp_db_host = os.environ.get('TEMP_DB_HOST', 'localhost')

def generate_unique_db_name():
    with lock:
        try:
            with open('db_name_counter.txt', 'r') as file:
                counter = int(file.read().strip())
        except FileNotFoundError:
            counter = 0

        new_counter = counter + 1
        with open('db_name_counter.txt', 'w') as file:
            file.write(str(new_counter))
        
    db_name = f"temp_db_{counter}"
    return db_name

def with_temp_db(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        print("Creating temporary database")
        db_name = generate_unique_db_name()
        conn = psycopg2.connect(database="template1", user=temp_db_user, password=temp_db_password, host=temp_db_host)
        conn.autocommit = True
        cursor = conn.cursor()
        cursor.execute(f"DROP DATABASE IF EXISTS {db_name}")
        cursor.execute(f"CREATE DATABASE {db_name}")
        conn.close()

        database_uri = f"postgresql://{temp_db_user}:{temp_db_password}@{temp_db_host}/{db_name}"
        engine = create_engine(database_uri)
        try:
            generator = func(*args, **kwargs, database_uri=database_uri)
            yield from generator
        except Exception as e:
            print(f"An error occurred: {e}")
            raise e
        finally:
            # After the generator has completed, delete the temporary database
            print("Dropping temporary database")
            engine.dispose()
            conn = psycopg2.connect(database="template1", user=temp_db_user, password=temp_db_password, host=temp_db_host)
            conn.autocommit = True
            cursor = conn.cursor()
            cursor.execute(f"SELECT pg_terminate_backend(pg_stat_activity.pid) FROM pg_stat_activity WHERE pg_stat_activity.datname = '{db_name}' AND pid <> pg_backend_pid();")
            cursor.execute(f"DROP DATABASE IF EXISTS {db_name}")
            conn.close()
    return wrapper
