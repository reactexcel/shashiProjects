from app.models import Profile, UserBalance, LiquidityPool, MarketBalance, PortfolioItem
from app.helpers.shorten_number import shorten_number
from app.helpers.call_logger import global_call_logger
from math import isclose


class Profiler():
        def __init__(self):
            self.last_total_USD_quantity = 0
            self.last_liquidity_pool_USD_quantity = 0
            self.last_user_USD_quantity = 0
            self.last_market_USD_quantity = 0
            self.last_total_asset_quantity = 0

        def market_profile(self, state):
            self.print_asset_values(state)
            self.print_USD_values(state)

        def print_asset_values(self, state):
            total_user_asset_quantity = {}
            total_user_assets_quantity = 0
            for user_portfolio_item in PortfolioItem.latest_user_asset_pairings():
                total_user_asset_quantity[user_portfolio_item.asset_id] = total_user_asset_quantity.get(user_portfolio_item.asset_id, 0) + user_portfolio_item.quantity
                total_user_assets_quantity += user_portfolio_item.quantity
            
            total_liquidity_pool_asset_quantity = {}
            total_liquidity_pool_assets_quantity = 0
            for liquidity_pool in LiquidityPool.latest_pools_per_id():
                total_liquidity_pool_asset_quantity[liquidity_pool.asset_id] = total_liquidity_pool_asset_quantity.get(liquidity_pool.asset_id, 0) + liquidity_pool.asset_quantity
                total_liquidity_pool_assets_quantity += liquidity_pool.asset_quantity

            total_asset_quantity = total_user_assets_quantity + total_liquidity_pool_assets_quantity

            if not isclose(total_asset_quantity, self.last_total_asset_quantity, rel_tol=1e-9, abs_tol=1e-9):
                print(f"_____________________________________________________")
                print(f"===  {state} ===")
                print(f"_____________________________________________________")
                print(f"_________________ASSET INFO___________________________")
                print(f"User asset quantities         = {shorten_number(total_user_assets_quantity)}")
                print(f"Liquidity pool asset quantity = {shorten_number(total_liquidity_pool_assets_quantity)}")
                print(f"                    ________________________________")
                print(f"Total asset quantity          = {shorten_number(total_asset_quantity)} diff = {shorten_number(total_asset_quantity - self.last_total_asset_quantity)}")
                print(f"____________________________________________________")

            self.last_total_asset_quantity = total_asset_quantity
    
        def print_USD_values(self, state):
            user_USD_quantity = 0
            for user in Profile.query.all():
                user_USD_quantity += getattr(UserBalance.current(user_id=user.id), 'quantity', 0)
            
            liquidity_pool_USD_quantity = 0
            liquidity_pools = LiquidityPool.latest_pools_per_id()
            for liquidity_pool in liquidity_pools:
                liquidity_pool_USD_quantity += liquidity_pool.USD_quantity
            
            market_balance = MarketBalance.current()
            market_balance_quantity = market_balance.quantity if market_balance else 0
            
            total_quantity = market_balance_quantity + liquidity_pool_USD_quantity + user_USD_quantity
            
            if not isclose(total_quantity, self.last_total_USD_quantity, rel_tol=1e-9, abs_tol=1e-9):
                print(f"_____________________________________________________")
                print(f"===  {state} ===")
                print(f"_____________________________________________________")
                print(f"__________________USD INFO___________________________")
                print(f"User quantity      = {shorten_number(user_USD_quantity)}  diff = {shorten_number(user_USD_quantity - self.last_user_USD_quantity)}")
                print(f"Liquidity quantity = {shorten_number(liquidity_pool_USD_quantity)} diff = {shorten_number(liquidity_pool_USD_quantity - self.last_liquidity_pool_USD_quantity)}")
                print(f"Market quantity    = {shorten_number(market_balance_quantity)} diff = {shorten_number(market_balance_quantity - self.last_market_USD_quantity)}")
                print(f"                    ________________________________")
                print(f"Total USD quantity = {shorten_number(total_quantity)}  diff = {shorten_number(total_quantity - self.last_total_USD_quantity)}")
                print(f"_____________________________________________________")
                print("_____________________________________________________")

            self.last_total_USD_quantity = total_quantity
            self.last_liquidity_pool_USD_quantity = liquidity_pool_USD_quantity 
            self.last_user_USD_quantity = user_USD_quantity
            self.last_market_USD_quantity = market_balance_quantity

global_profiler = Profiler()