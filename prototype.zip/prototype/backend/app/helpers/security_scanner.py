import subprocess
import json


class SecurityError(Exception):
    def __init__(self, message, file_path):
        super().__init__(message)
        self.file_path = file_path


def scan_with_bandit(file_path):
    result = subprocess.run(
        ['bandit', '-f', 'json', file_path],
        capture_output=True,
        text=True
    )

    json_result = result.stdout
    issues = json.loads(json_result)

    for issue in issues['results']:
        if issue['issue_severity'] in ('HIGH', 'MEDIUM'):
            raise SecurityError(f"Security issue found in {file_path} - {issue['issue_text']}", file_path) from None
