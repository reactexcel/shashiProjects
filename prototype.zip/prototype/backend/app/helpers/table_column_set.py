def table_column_set(key, label, type="text", isLeftAligned=False, isBold=False):
    return {
        "key": key,
        "label": label,
        "type": type,
        "isLeftAligned": isLeftAligned,
        "isBold": isBold
    }