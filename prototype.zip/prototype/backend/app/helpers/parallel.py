from concurrent.futures import ThreadPoolExecutor
import logging

def generic_wrapper(func):
    from app import create_app
    app = create_app()
    with app.app_context():
        try:
            return func()
        except Exception as e:
            logging.error(f"Error in function {func.__name__}: {e}")
            return None

def execute_functions_in_pool(functions, pool_size=3):
    with ThreadPoolExecutor(max_workers=pool_size) as executor:
        return executor.map(generic_wrapper, functions)
