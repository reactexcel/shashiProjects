from app.database import db
from app.models import Asset
from app.models.BaseModel import BaseModel
from datetime import datetime
from decimal import Decimal

class LendingPool(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    interest_earned = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_lending_pool_asset_id', 'asset_id'),
        db.Index('idx_lending_pool_asset_id_created_at', 'asset_id', 'created_at'),
    )

    @classmethod
    def current(cls, asset_id):
        lending_pool = LendingPool.query.filter_by(asset_id=asset_id).first()
        if lending_pool is None:
            lending_pool = LendingPool(asset_id=asset_id, interest_earned=0)
        return lending_pool
    
    @classmethod
    def unutilized_deposits(cls, asset_id):
        from app.models import Loan, LoanDeposit

        total_deposits_amount = LoanDeposit.total_deposits_for_asset(asset_id=asset_id)
        total_loans_amount = Loan.current_outstanding_loan_amount(asset_id=asset_id)
        return total_deposits_amount - total_loans_amount
    
    @classmethod
    def distribute_interest_for_all_assets(cls):
        for asset in Asset.query.all():
            cls.distribute_interest(asset_id=asset.id)

    @classmethod
    def distribute_interest(cls, asset_id):
        from app.models import Loan, LoanDeposit

        interest_rate = cls.interest_rate(asset_id=asset_id)
        loans = Loan.current_open_loans(asset_id=asset_id)

        net_interest = 0
        for loan in loans:
            if Loan.requires_liquidation(loan=loan):
                loan.liquidate(asset_id=loan.asset_id, user_id=loan.user_id)
                continue
            interest = loan.amount * interest_rate
            Loan.withdraw_collateral(user_id=loan.user_id, asset_id=asset_id, amount=interest_rate)
            net_interest += interest

        cls.add_interest_earned(asset_id=asset_id, interest_earned=net_interest)

        loan_deposits = LoanDeposit.current_for_asset(asset_id=asset_id)
        total_deposits = LoanDeposit.total_deposits(asset_id=asset_id)
        for loan_deposit in loan_deposits:
            user_id = loan_deposit.user_id
            portion = loan_deposit.amount / total_deposits
            portion_of_interest = round(portion * net_interest)
            LoanDeposit.deposit_interest(asset_id=asset_id, user_id=user_id, amount=portion_of_interest)

    @classmethod
    def add_interest_earned(cls, asset_id, interest_earned):
        lending_pool = cls.current(asset_id=asset_id)
        lending_pool.interest_earned += interest_earned
        db.session.add(lending_pool)
        db.session.commit()

    @staticmethod
    def asset_ids_by_utilization_ratio():
        lending_pools = LendingPool.query.all()
        sorted_lending_pools = sorted(lending_pools, key=lambda lp: lp.utilization_ratio(lp.asset_id) or 0, reverse=True)
        return [lp.asset_id for lp in sorted_lending_pools]

    @classmethod
    def utilization_ratio(cls, asset_id):
       from app.models import LoanDeposit
       unutilized_deposits = cls.unutilized_deposits(asset_id=asset_id)
       total_deposits = LoanDeposit.total_deposits(asset_id=asset_id)       
       if total_deposits == 0:
           return None
       return Decimal('1') - unutilized_deposits / total_deposits

    @classmethod
    def interest_rate(cls, asset_id):
       utilization_ratio = cls.utilization_ratio(asset_id=asset_id)
       if utilization_ratio == None:
           return 0
       MINIMUM_INTEREST = Decimal('0.02')
       return max(utilization_ratio * Decimal('0.1'), MINIMUM_INTEREST)

    @classmethod
    def withdraw(cls, asset_id, amount):
        if LendingPool.unutilized_deposits(asset_id=asset_id) < amount:
            raise Exception('Insufficient balance')