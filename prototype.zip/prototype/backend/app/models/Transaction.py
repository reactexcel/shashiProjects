from app.database import db
from app.models.BaseModel import BaseModel
from .Asset import Asset
from .Profile import Profile
from datetime import datetime
class Transaction(BaseModel):
    transaction_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, nullable=False, index=True)
    asset_quantity = db.Column(db.Numeric, nullable=False)
    USD = db.Column(db.Numeric, nullable=False)
    user_id = db.Column(db.Integer, nullable=False)
    fee = db.Column(db.Numeric, nullable=True)
    price = db.Column(db.Numeric, nullable=True)
    trade_type = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    associated_record_id = db.Column(db.Integer, nullable=True)
    associated_record_type = db.Column(db.String(255), nullable=True)