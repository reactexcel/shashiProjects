from dataclasses import dataclass

@dataclass
class SensorData:
    sensor_id: int
    pm25_10_minute: float