from datetime import datetime
from sqlalchemy import func, and_
from app.database import db
from app.models.BaseModel import BaseModel
from .Asset import Asset
from .PayoutCycle import PayoutCycle
from .Pool import Pool
from decimal import Decimal 
from sqlalchemy import Index, desc, text

# TODO Add a method to withdraw from liquidity pool
# TODO Look into the commiting of the liquidity pool & atomic-ness of the related codebase

class LiquidityPool(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pool_id = db.Column(db.Integer, db.ForeignKey('pool.id'), nullable=False, index=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    asset_quantity = db.Column(db.Numeric, nullable=False)
    USD_quantity = db.Column(db.Numeric, nullable=False)
    total_liquidity_tokens = db.Column(db.Numeric, nullable=False)
    payout_cycle_id = db.Column(db.Integer, db.ForeignKey('payout_cycle.id'), index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    idx_liquidity_pool_pool_id_id = Index('idx_liquidity_pool_pool_id_id', "pool_id", "id.desc()")
    idx_liquidity_pool_pool_id_id_desc = Index('idx_liquidity_pool_pool_id_id_desc', 'pool_id', desc('id'))

    __table_args__ = (
        db.Index('idx_liquiditypool_created_at', 'created_at'),
        db.Index('idx_liquiditypool_assetid_createdat', 'asset_id', 'created_at'),
        db.Index('idx_liquiditypool_pood_id_id', 'pool_id', 'id'),
        db.Index('idx_liquiditypool_pool_id_created_at', 'pool_id', db.desc('id')),
    )

    TRANSACTION_FEE_PERCENTAGE = Decimal('0.01')

    @classmethod
    def current(cls, pool_id):
        sql = text("SELECT * FROM liquidity_pool WHERE pool_id = :pool_id ORDER BY id DESC LIMIT 1")
        result = db.session.execute(sql, {'pool_id': pool_id}).fetchone()
        if result:
            result_dict = result._asdict()
            return LiquidityPool(**result_dict)
        else:
            return None

    @classmethod
    def current_with_asset_id(cls, asset_id):
        pool_id = Pool.get_pool_id_for_asset(asset_id=asset_id)
        return cls.current(pool_id=pool_id)

    def get_ideal_purchase_amount(self, ideal_ratio: Decimal) -> Decimal:
        # Calculate the ideal USD quantity based on the ideal ratio and current asset quantity.
        ideal_usd_quantity = self.asset_quantity * ideal_ratio
        # Calculate how much more USD is needed to reach the ideal state.
        additional_usd_needed = ideal_usd_quantity - self.USD_quantity

        return max(Decimal(additional_usd_needed), Decimal(0))


    def get_ideal_selling_amount(self, ideal_ratio: Decimal) -> Decimal:
        if ideal_ratio == 0:
            return Decimal(0)

        # Calculate the ideal asset quantity based on the ideal ratio (USD per asset) and current USD quantity.
        ideal_asset_quantity = self.USD_quantity / ideal_ratio ## (USD/A_QUANTITY)

        # Calculate how much additional asset is in excess to reach the ideal state.
        additional_asset_excess = ideal_asset_quantity - self.asset_quantity

        # print(f"USD_quantity: {self.USD_quantity}, asset_quantity: {self.asset_quantity}, ideal_ratio: {ideal_ratio}")
        # print(f"Calculated ideal_asset_quantity: {ideal_asset_quantity}")
        # print(f"Calculated additional_asset_excess: {additional_asset_excess}")

        if additional_asset_excess < 0:
            print("Current asset quantity is less than or equal to ideal asset quantity.")
            return Decimal(0)
        else:
            return additional_asset_excess

    @classmethod
    def swap_for_asset(cls, pool_id, USD_in):
      old_liquidity_pool = LiquidityPool.current(pool_id=pool_id)
      if old_liquidity_pool is None:
          raise Exception("Liquidity Pool not found.")
      # print('----------------------------------------------')
      # print(f'IN swap_for_asset: old_liquidity_pool.USD_quantity = {old_liquidity_pool.USD_quantity}')
      # print(f'IN swap_for_asset: USD_in = {USD_in}')
      USD_in = Decimal(USD_in)

      # Copy the existing pool's attributes
      liquidity_pool = LiquidityPool.copy(old_liquidity_pool)

      # Calculations
      USD_in_after_fee, asset_quatity_to_withdraw, transaction_fee = LiquidityPool.asset_to_withdraw(
          liquidity_pool.asset_quantity, 
          liquidity_pool.USD_quantity, 
          USD_in
      )

      # print(f'IN swap_for_asset: USD_in_after_fee = {USD_in_after_fee}')
      # Ensure sufficient liquidity in the pool
      assert old_liquidity_pool.asset_quantity >= asset_quatity_to_withdraw

      # print(f'IN swap_for_asset: pre add USD_in_after_fee: liquidity_pool.USD_quantity = {liquidity_pool.USD_quantity}')
      # Update the liquidity pool's quantities
      liquidity_pool.USD_quantity += USD_in_after_fee
      liquidity_pool.asset_quantity -= asset_quatity_to_withdraw

      liquidity_pool.payout_cycle_id = PayoutCycle.max_id()


      # print(f'IN swap_for_asset: USD_in = {USD_in}')
      # print(f'IN swap_for_asset: USD_in_after_fee = {USD_in_after_fee}')
      # print(f'IN swap_for_asset: liquidity_pool.USD_quantity     = {liquidity_pool.USD_quantity}')
      # print('----------------------------------------------')
      db.session.add(liquidity_pool)

      return asset_quatity_to_withdraw, transaction_fee

    @classmethod
    def swap_for_USD(cls, pool_id, asset_quantity):
        old_liquidity_pool = cls.current(pool_id=pool_id)
        if old_liquidity_pool is None:
            raise Exception("Liquidity Pool not found.")
        
        asset_quantity = Decimal(asset_quantity)

        assert old_liquidity_pool.asset_quantity >= asset_quantity, f"Insufficient asset_quantity in the pool. Have: {old_liquidity_pool.asset_quantity}, Need: {asset_quantity} or more."


        # Copy the existing pool's attributes
        liquidity_pool = LiquidityPool.copy(old_liquidity_pool)

        USD_to_withdraw = LiquidityPool.USD_to_withdraw(
            liquidity_pool.asset_quantity, 
            liquidity_pool.USD_quantity, 
            asset_quantity
        )

        # Update the liquidity pool's quantities
        liquidity_pool.asset_quantity += asset_quantity
        liquidity_pool.USD_quantity -= USD_to_withdraw

        liquidity_pool.payout_cycle_id = PayoutCycle.max_id()

        db.session.add(liquidity_pool)

        return USD_to_withdraw


    @classmethod
    def USD_to_withdraw(cls, liquidity_pool_asset_quantity, liquidity_pool_USD_quantity, user_asset_quantity):
        # Calculate K constant
        K = liquidity_pool_asset_quantity * liquidity_pool_USD_quantity
        
        # Calculate the amount of USD to be swapped out
        USD_out = liquidity_pool_USD_quantity - K / (liquidity_pool_asset_quantity + user_asset_quantity)

        # Ensure there's enough USD in the pool
        assert liquidity_pool_USD_quantity >= USD_out
         
        return USD_out
    
    @classmethod
    def asset_to_withdraw(cls, liquidity_pool_asset_quantity, liquidity_pool_USD_quantity, user_USD_in):
        
        # Calculate K constant
        K = liquidity_pool_asset_quantity * liquidity_pool_USD_quantity

        # Transaction fee calculation
        transaction_fee = user_USD_in * cls.TRANSACTION_FEE_PERCENTAGE

        # Calculate USD after fee
        USD_in_after_fee = user_USD_in - transaction_fee
        
        # Calculate the amount of asset to be swapped out
        asset_quantity_to_withdraw = liquidity_pool_asset_quantity - K / (liquidity_pool_USD_quantity + USD_in_after_fee)

        # print(f'IN asset_to_withdraw: USD_in_after_fee = {USD_in_after_fee}')
        # print(f'IN asset_to_withdraw: asset_quantity_to_withdraw = {asset_quantity_to_withdraw}')
        # print(f'IN asset_to_withdraw: transaction_fee = {transaction_fee}')

        return USD_in_after_fee, asset_quantity_to_withdraw, transaction_fee

    @classmethod
    def create(cls, pool_id, asset_id, asset_quantity, USD_quantity, total_liquidity_tokens, commit=True):
        new_liquidity_pool = cls(
            pool_id=pool_id, 
            asset_id=asset_id, 
            asset_quantity=asset_quantity, 
            USD_quantity=USD_quantity, 
            total_liquidity_tokens=total_liquidity_tokens
        )
        db.session.add(new_liquidity_pool)
        if commit:
          db.session.commit()
        return new_liquidity_pool        
        
    @classmethod
    def quantity_in_USD(pool_id, asset_quantity):
        exchange_rate = LiquidityPool.current(pool_id=pool_id).exchange_rate()
        return asset_quantity * exchange_rate

    @classmethod
    def quantity_in_asset(pool_id, USD_quantity):
        exchange_rate = LiquidityPool.current(pool_id=pool_id).exchange_rate()
        return USD_quantity * exchange_rate

    def add_liquidity(self, USD_deposit, asset_deposit):
        liquidity_tokens_issued = self.tokens_to_issue(USD_deposit, asset_deposit)

        # Update the pool's state
        new_liquidity_pool = LiquidityPool.create(
            pool_id=self.pool_id, 
            asset_id=self.asset_id, 
            asset_quantity=self.asset_quantity + asset_deposit, 
            USD_quantity=self.USD_quantity + USD_deposit, 
            total_liquidity_tokens=self.total_liquidity_tokens + liquidity_tokens_issued,
            commit=False
        )

        return new_liquidity_pool, liquidity_tokens_issued

    def tokens_to_issue(self, USD_deposit: Decimal, asset_deposit: Decimal) -> Decimal:
        # Ensure that deposits are non-negative
        if USD_deposit < 0 or asset_deposit < 0:
            raise ValueError("Deposits must be non-negative.")

        # Calculate the value of the TOKEN deposit in USD
        exchange_rate = Decimal(self.exchange_rate())
        if exchange_rate == 0:
            raise ValueError("Exchange rate cannot be zero.")
        
        asset_value = asset_deposit * exchange_rate

        # Calculate the user's share of the pool based on the USD value
        user_share_of_pool = USD_deposit + asset_value
        total_pool_size = self.USD_quantity + self.asset_quantity * exchange_rate

        # Ensure that total pool size is non-zero to avoid division by zero
        if total_pool_size == 0:
            raise ValueError("Total pool size must be greater than zero.")

        # Issue liquidity tokens proportionally to the user's share
        return (user_share_of_pool / total_pool_size) * self.total_liquidity_tokens

    def exchange_rate(self):
        return Decimal(self.USD_quantity / self.asset_quantity)
    
    @staticmethod
    def copy(liquidity_pool):
      return LiquidityPool(
        pool_id=liquidity_pool.pool_id,
        asset_id=liquidity_pool.asset_id,
        asset_quantity=liquidity_pool.asset_quantity,
        USD_quantity=liquidity_pool.USD_quantity,
        total_liquidity_tokens=liquidity_pool.total_liquidity_tokens
      )
    
    @staticmethod
    def get_latest_pool_for_asset(asset_id):
        return LiquidityPool.query.filter_by(asset_id=asset_id).order_by(LiquidityPool.created_at.desc()).first()
    
    @staticmethod
    def get_latest_pools_for_asset(asset_id, since_timestamp):
        return LiquidityPool.query.filter(LiquidityPool.created_at >= since_timestamp).filter_by(asset_id=asset_id).order_by(LiquidityPool.created_at.desc()).all()
    
    @staticmethod
    def latest_pools_per_id():
        try:
            subquery = (
                db.session.query(
                    LiquidityPool.pool_id, 
                    func.max(LiquidityPool.id).label('max_id')
                )
                .group_by(LiquidityPool.pool_id)
                .subquery()
            )

            latest_pools = (
                db.session.query(LiquidityPool)
                .join(
                    subquery, 
                    and_(
                        LiquidityPool.pool_id == subquery.c.pool_id, 
                        LiquidityPool.id == subquery.c.max_id
                    )
                )
                .all()
            )

            return latest_pools
        except Exception as e:
            # Can happen with no LiquidityPools
            print(f"Error occurred: {e}")
            return []