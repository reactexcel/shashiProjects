from datetime import datetime
from app.database import db
from app.models.BaseModel import BaseModel
class LiquidityHolding(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    pool_id = db.Column(db.Integer, db.ForeignKey('pool.id'), index=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), index=True)
    quantity = db.Column(db.Numeric, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_user_asset', 'user_id', 'asset_id'),
    )

    @classmethod
    def current(cls, pool_id, user_id):
        return cls.query.filter_by(user_id=user_id, pool_id=pool_id).order_by(LiquidityHolding.id.desc()).first()


    @classmethod
    def withdraw(cls, user_id, pool_id, asset_id, asset_quantity):
        if asset_quantity <= 0:
            raise Exception("Cannot withdraw a negative quantity of an asset.")
        
        old_liquidity_holding = LiquidityHolding.current(pool_id=pool_id, user_id=user_id)
        if old_liquidity_holding is None:
            raise Exception("Cannot withdraw when not owning the asset.")

        if asset_quantity > old_liquidity_holding.quantity:
            raise Exception("Cannot withdraw more of an asset than you have.")
        
        new_quantity = old_liquidity_holding.quantity - asset_quantity
        liquidity_holding = LiquidityHolding(
            pool_id=pool_id,
            user_id=user_id,
            asset_id=asset_id,
            quantity=new_quantity,
        )
        db.session.add(liquidity_holding)

    @classmethod
    def deposit(cls, user_id, pool_id, asset_id, asset_quantity):
        if asset_quantity <= 0:
            raise Exception("Cannot deposit a negative quantity of an asset.")
        
        old_liquidity_holding = LiquidityHolding.current(asset_id, user_id)

        new_quantity = asset_quantity
        if old_liquidity_holding:
            new_quantity += old_liquidity_holding.quantity
        liquidity_holding = LiquidityHolding(
            pool_id=pool_id,
            user_id=user_id,
            asset_id=asset_id,
            quantity=new_quantity,
        )
        db.session.add(liquidity_holding)