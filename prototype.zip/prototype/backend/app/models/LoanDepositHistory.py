from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime


class LoanDepositHistory(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    loan_deposit_id = db.Column(db.Integer, db.ForeignKey('loan_deposit.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False, index=True)
    amount = db.Column(db.Numeric, nullable=False)
    available_interest_earned = db.Column(db.Numeric, nullable=False)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    @classmethod
    def create_history_entry(cls, loan_deposit, commit=True):
        history_entry = cls(
            loan_deposit_id=loan_deposit.id,
            asset_id=loan_deposit.asset_id,
            user_id=loan_deposit.user_id,
            amount=loan_deposit.amount,
            available_interest_earned=loan_deposit.available_interest_earned,
        )
        db.session.add(history_entry)
        if commit:
            db.session.commit()
        