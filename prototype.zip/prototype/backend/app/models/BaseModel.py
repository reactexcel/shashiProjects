from app.database import db

class BaseModel(db.Model):
    __abstract__ = True

    def flush(self):
        db.session.flush()
        return self
    
    def get_attributes(self):
        # Dynamically fetching all attributes of the instance
        attributes = {key: value for key, value in self.__dict__.items() if not key.startswith('_')}
        return attributes

    def __str__(self):
        attributes_str = ", ".join(f"{key}={value}" for key, value in self.get_attributes().items())
        return f"{self.__class__.__name__}({attributes_str})"

    def __repr__(self):
        return self.__str__()
