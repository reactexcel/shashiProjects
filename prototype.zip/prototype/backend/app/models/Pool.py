from datetime import datetime
from app.database import db
from app.models.BaseModel import BaseModel
from app.models import Asset
from sqlalchemy import text
class Pool(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255), nullable=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, unique=True)
    description = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    
    _pool_id_cache = {}

    @classmethod
    def get_pool_id_for_asset(cls, asset_id):
        if asset_id in cls._pool_id_cache:
            return cls._pool_id_cache[asset_id]
        
        sql = text("SELECT id FROM pool WHERE asset_id = :asset_id LIMIT 1")
        result = db.session.execute(sql, {'asset_id': asset_id}).fetchone()
        if result:
            pool_id = result[0]
            cls._pool_id_cache[asset_id] = pool_id
            return pool_id
        else:
            return None