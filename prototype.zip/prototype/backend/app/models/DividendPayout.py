from datetime import datetime
from app.database import db
from app.models.BaseModel import BaseModel
from .Profile import Profile
from .Asset import Asset
from .PayoutCycle import PayoutCycle
class DividendPayout(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), index=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), index=True)
    amount_in_usd = db.Column(db.Numeric, nullable=False)
    payout_cycle_id = db.Column(db.Integer, db.ForeignKey('payout_cycle.id'), index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
