from app.database import db
from app.models import BaseModel, Asset

class AssetRegion(BaseModel):
    id = db.Column(db.Integer, primary_key=True, unique=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, unique=False)
    nwlng = db.Column(db.Numeric, nullable=False)
    nwlat = db.Column(db.Numeric, nullable=False)
    selng = db.Column(db.Numeric, nullable=False)
    selat = db.Column(db.Numeric, nullable=False)


    def __init__(self, id, asset_id, nwlng, nwlat, selng, selat):
        self.id = id
        self.asset_id = asset_id
        self.nwlng = nwlng
        self.nwlat = nwlat
        self.selng = selng
        self.selat = selat

    def midpoint(self):
        mid_lat = (self.nwlat + self.selat) / 2
        mid_lon = (self.nwlng + self.selng) / 2
        return mid_lat, mid_lon