from app.helpers.shorten_number import shorten_number
from app.database import db
from app.models import BaseModel, Asset
from datetime import datetime, timedelta
from collections import defaultdict

class AirMeasure(BaseModel):
    id = db.Column(db.Integer, primary_key=True, unique=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, unique=False, index=True)
    pm_25_10_minute = db.Column(db.Numeric, nullable=False)
    sensor_count =  db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)
    payout_cycle_id = db.Column(db.Integer, db.ForeignKey('payout_cycle.id'), index=True)

    __table_args__ = (
        db.Index('idx_airmeasure_payoutcycleid', 'payout_cycle_id'),
    )

    @staticmethod
    def current(asset_id):
        return AirMeasure.query.filter_by(asset_id=asset_id).order_by(AirMeasure.created_at.desc()).first()
    
    @staticmethod
    def get_latest_for_asset(asset_id, since_timestamp):
        return AirMeasure.query.filter(AirMeasure.created_at >= since_timestamp).filter_by(asset_id=asset_id).order_by(AirMeasure.created_at.desc()).all()


    @staticmethod
    def get_air_quality_since(asset_id, since_timestamp):
        if since_timestamp is None or asset_id is None:
            return []
        
        return AirMeasure.query.filter(
            AirMeasure.asset_id == asset_id,
            AirMeasure.created_at >= since_timestamp
        ).order_by(AirMeasure.created_at).all()
        
        
    @staticmethod
    def get_air_quality_per_hour(air_measures):
        # Calculate the timestamp for 14 days ago
        since_timestamp = datetime.utcnow() - timedelta(days=14)

        # Initialize a defaultdict to hold the sum and count for each hour
        hourly_data = {hour: {'sum': 0.0, 'count': 0} for hour in range(24)}


        for record in air_measures:
            # Extract just the hour to group by hour
            hour = record.created_at.hour
            
            # Update sum and count for the hour
            hourly_data[hour]['sum'] += float(record.pm_25_10_minute)
            hourly_data[hour]['count'] += 1

        # Calculate the average for each hour
        results = []
        for hour, data in hourly_data.items():
            avg_pm_25 = shorten_number(data['sum'] / data['count']) if data['count'] > 0 else 0.0
            results.append({'hour_of_day': hour, 'avg_pm_25': avg_pm_25})

        # Sort the results by hour
        results.sort(key=lambda x: x['hour_of_day'])

        return results

    @staticmethod
    def get_air_quality_per_day_of_week(air_measures):
        # Initialize a dictionary to hold the sum and count for each day of the week
        # 0: Monday, 1: Tuesday, ..., 6: Sunday
        weekly_data = {day: {'sum': 0.0, 'count': 0} for day in range(7)}

        # List to map day index to day name
        day_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

        for record in air_measures:
            # Extract the day of the week (0: Monday, 1: Tuesday, ..., 6: Sunday)
            day_of_week = record.created_at.weekday()
            
            # Update sum and count for the day
            weekly_data[day_of_week]['sum'] += float(record.pm_25_10_minute)
            weekly_data[day_of_week]['count'] += 1

        # Calculate the average for each day of the week
        results = []
        for day, data in weekly_data.items():
            avg_pm_25 = shorten_number(data['sum'] / data['count']) if data['count'] > 0 else 0.0
            results.append({'index': day, 'day_of_week': day_names[day], 'avg_pm_25': avg_pm_25})

        # Sort the results by the day index
        results.sort(key=lambda x: x['index'])

        return results