from datetime import datetime
from app.database import db
from app.models.BaseModel import BaseModel
from .Asset import Asset
class PriceHistory(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False)
    price = db.Column(db.Numeric, nullable=False)
    time_frequency = db.Column(db.String(255), nullable=False)
    price_time = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    @classmethod
    def current(cls, asset_id):
        return cls.query.filter_by(asset_id=asset_id).order_by(PriceHistory.id.desc()).first()
