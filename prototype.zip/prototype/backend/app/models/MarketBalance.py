from app.database import db
from app.models.BaseModel import BaseModel
from sqlalchemy import Index, text
from datetime import datetime

class MarketBalance(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    quantity = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    

    idx_market_balance_id = Index('idx_market_balance_id', "id.desc()")


    @classmethod
    def current(cls):
        sql = text("SELECT * FROM market_balance ORDER BY id DESC LIMIT 1")
        result = db.session.execute(sql).fetchone()
        if result:
            result_dict = result._asdict()
            balance = MarketBalance(**result_dict)
        else:
            balance = MarketBalance(quantity=0)
        return balance


    @classmethod
    def withdraw(cls, quantity):
        if quantity < 0:
          raise Exception("Cannot withdraw a negative quantity from MarketBalance.")
        if quantity == 0:
            return
        old_balance = cls.current()
        if old_balance is None:
            raise Exception("Cannot withdraw when not owning any balance.")

        if quantity > old_balance.quantity:
            raise Exception("Cannot withdraw more than you have.")
        
        new_quantity = old_balance.quantity - quantity
        market_balance = MarketBalance(
            quantity=new_quantity,
        )
        db.session.add(market_balance)

    @classmethod
    def deposit(cls, quantity):
        if quantity <= 0:
            raise Exception("Cannot deposit a negative quantity.")
        
        old_balance = cls.current()

        new_quantity = quantity
        if old_balance:
            new_quantity += old_balance.quantity
        
        market_balance = MarketBalance(
            quantity=new_quantity,
        )
        db.session.add(market_balance)