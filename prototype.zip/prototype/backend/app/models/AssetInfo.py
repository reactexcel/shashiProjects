from datetime import datetime
from app.database import db
from sqlalchemy.exc import SQLAlchemyError
from app.models.BaseModel import BaseModel
from app.helpers.shorten_number import shorten_number
from app.constants import (
    NAME_KEY,
    MARKET_CAP_KEY,
    PRICE_KEY,
    PRICE_DIVIDEND_RATIO,
    ONE_HOUR_KEY,
    ONE_DAY_KEY,
    DIVIDENDS_24HR_KEY,
    ONE_DAY_TRADE_VOL_KEY,
    CIRCULATING_SUPPLY_KEY,
    PM_25_KEY,
    PM_25_1HR_KEY,
    PM_25_24HR_KEY,
    PERCENT_IN_LIQUIDITY_POOL_KEY
)

class AssetInfo(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    asset_name = db.Column(db.String(255), nullable=False)
    latest_price = db.Column(db.Numeric, nullable=False)
    dp_ratio = db.Column(db.Numeric, nullable=False)
    one_hour_change = db.Column(db.Numeric, nullable=False)
    one_day_change = db.Column(db.Numeric, nullable=False)
    market_cap = db.Column(db.Numeric, nullable=False)
    one_day_trade_vol = db.Column(db.Numeric, nullable=False)
    dividends_24hr = db.Column(db.Numeric, nullable=False)
    pm_25 = db.Column(db.Numeric, nullable=False)
    pm_25_1hr = db.Column(db.Numeric, nullable=False)
    pm_25_24hr = db.Column(db.Numeric, nullable=False)
    circulating_supply = db.Column(db.Numeric, nullable=False)
    percent_in_liquidity_pool = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


    @property
    def serialize(self):
        return {
            'data': {
                NAME_KEY: self.asset_name,
                PRICE_KEY: shorten_number(self.latest_price),
                PRICE_DIVIDEND_RATIO: shorten_number(self.dp_ratio),
                ONE_HOUR_KEY: shorten_number(self.one_hour_change),
                ONE_DAY_KEY: shorten_number(self.one_day_change),
                MARKET_CAP_KEY: shorten_number(self.market_cap),
                ONE_DAY_TRADE_VOL_KEY: shorten_number(self.one_day_trade_vol),
                DIVIDENDS_24HR_KEY: shorten_number(self.dividends_24hr),
                PM_25_KEY: shorten_number(self.pm_25),
                PM_25_1HR_KEY: shorten_number(self.pm_25_1hr),
                PM_25_24HR_KEY: shorten_number(self.pm_25_24hr),
                CIRCULATING_SUPPLY_KEY: shorten_number(self.circulating_supply),
                PERCENT_IN_LIQUIDITY_POOL_KEY: shorten_number(self.percent_in_liquidity_pool)
            }, 
            'id': self.asset_id 
        } 

    @classmethod
    def upsert_asset_info(cls, **kwargs):
        try:
            asset_info = cls(**kwargs)
            db.session.add(asset_info)
            db.session.commit()
            return asset_info
        except SQLAlchemyError as error:
            db.session.rollback()
            raise error
        
    @classmethod
    def get_latest_asset_infos(cls):
        """ 
        Get most recent asset info for each asset_id in database
        """
        subquery = (
            db.session.query(
                cls.asset_id,
                db.func.max(cls.created_at).label('max_created_at')
            )
            .group_by(cls.asset_id)
            .subquery()
        )
        asset_infos = (
            db.session.query(cls).join(subquery, db.and_(
                cls.asset_id == subquery.c.asset_id,
                cls.created_at == subquery.c.max_created_at
            ))
            .all()
        )
        return asset_infos