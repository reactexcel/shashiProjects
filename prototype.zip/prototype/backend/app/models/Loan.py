from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime
from app.models import UserBalance, PortfolioItem, LiquidityPool
from app.models.LendingPool import LendingPool
from app.models.LoanHistory import LoanHistory
from sqlalchemy import text

OPEN = 'open'
CLOSED = 'closed'
DEFAULTED = 'defaulted'
LIQUIDATION_RATE = 1.1
class Loan(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False, index=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    status = db.Column(db.String, nullable=False, default=OPEN)
    amount = db.Column(db.Numeric, nullable=False)
    remaining_collateral = db.Column(db.Numeric, nullable=False, default=0)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


    __table_args__ = (
        db.Index('idx_loan_asset_id_status', 'asset_id', 'status'),
        db.Index('idx_loan_user_id_asset_id_status', 'user_id', 'asset_id', 'status'),
        db.Index('idx_loan_user_id_asset_id', 'user_id', 'asset_id'),
        db.Index('idx_loan_status', 'status'),
    )

    @classmethod
    def current_open_loans(cls, asset_id):
        return cls.query.filter_by(asset_id=asset_id, status=OPEN).all()

    @classmethod
    def current_open_loan(cls, user_id, asset_id, commit=True):
        loan = cls.query.filter_by(user_id=user_id, asset_id=asset_id, status=OPEN).first()
        if loan is None:
            loan = Loan(user_id=user_id, asset_id=asset_id, amount=0, remaining_collateral=0)
            db.session.add(loan)
            if commit:
                db.session.commit()
        return loan
    
    @classmethod
    def current_outstanding_loan_amount(cls, asset_id):
        sql = text("""
            SELECT SUM(amount) AS total_outstanding
            FROM loan
            WHERE asset_id = :asset_id AND status = 'open';
        """)
        
        result = db.session.execute(sql, {'asset_id': asset_id}).scalar()
        return result or 0
    
    @staticmethod
    def take_out_loan(user_id, asset_id, amount, collateral):
        UserBalance.withdraw(user_id=user_id, quantity=collateral)
        LendingPool.withdraw(asset_id=asset_id, amount=amount)
        PortfolioItem.deposit(asset_id=asset_id, user_id=user_id, asset_quantity=amount)
        loan = Loan.current_open_loan(user_id=user_id, asset_id=asset_id, commit=False)
        loan.amount += amount
        loan.remaining_collateral += collateral
        db.session.add(loan)
        if loan.id is None:
            db.session.commit()
        LoanHistory.create_history_entry(loan=loan, commit=False)
        db.session.commit()

    @classmethod
    def liquidate(cls, user_id, asset_id):
        loan = cls.current_open_loan(user_id, asset_id)
        if not cls.requires_liquidation(loan):
            return
        loan, asset_quantity_acquired = cls.liquidate_collateral(loan)
        amount_to_withdraw = cls.amount_to_withdraw_during_liquidation(loan, asset_quantity_acquired)
        cls.deposit_surplus_during_liquidation(loan, asset_quantity_acquired)
        paid_off_loan = Loan.pay_off_loan(user_id=user_id, asset_id=asset_id, amount=amount_to_withdraw)
        paid_off_loan.set_liquidation_status()

    def liquidate_collateral(loan):
        from app.services import LiquidityService
        collateral = loan.remaining_collateral
        Loan.withdraw_collateral(user_id=loan.user_id, asset_id=loan.asset_id, amount=loan.remaining_collateral)
        user_balance = UserBalance.current(user_id=loan.user_id).quantity
        usd_used_to_acquire = min(user_balance, collateral) # here because of transaction fees that user_balance can go lower
        asset_quantity_acquired = LiquidityService().buy(
            pool_id=None,
            user_id=loan.user_id,
            asset_id=loan.asset_id,
            USD_in=usd_used_to_acquire,
            commit=False)
        loan.remaining_collateral = 0
        db.session.add(loan)
        db.session.commit()
        return loan, asset_quantity_acquired
    
    def usdc_value(self):
        return LiquidityPool.current_with_asset_id(asset_id=self.asset_id).exchange_rate() * self.amount

    @staticmethod
    def requires_liquidation(loan):
        return loan.remaining_collateral < float(loan.usdc_value()) * LIQUIDATION_RATE

    @staticmethod
    def deposit_surplus_during_liquidation(loan, asset_quantity_acquired):
        if loan.amount < asset_quantity_acquired:
            surplus_amount = asset_quantity_acquired - loan.amount
            PortfolioItem.deposit(asset_id=loan.asset_id, user_id=loan.user_id, asset_quantity=surplus_amount)

    @staticmethod
    def amount_to_withdraw_during_liquidation(loan, asset_quantity_acquired):
        amount_to_withdraw = loan.amount
        if loan.amount > asset_quantity_acquired:
            amount_to_withdraw = asset_quantity_acquired
        return amount_to_withdraw

    def set_liquidation_status(self):
        self.status = DEFAULTED if self.amount > 0 else CLOSED
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def pay_off_loan(user_id, asset_id, amount):
        PortfolioItem.withdraw(asset_id=asset_id, user_id=user_id, asset_quantity=amount)
        loan = Loan.current_open_loan(user_id=user_id, asset_id=asset_id)
        loan.amount -= amount
        LoanHistory.create_history_entry(loan=loan, commit=False)
        db.session.add(loan)
        db.session.commit()
        return loan

    @staticmethod
    def deposit_collateral(user_id, asset_id, amount):
        UserBalance.withdraw(user_id=user_id, quantity=amount)
        loan = Loan.current_open_loan(user_id=user_id, asset_id=asset_id)
        loan.remaining_collateral += amount
        db.session.add(loan)
        db.session.commit()
        LoanHistory.create_history_entry(loan=loan, commit=False)
        db.session.commit()
            
    @staticmethod
    def withdraw_collateral(user_id, asset_id, amount):
        loan = Loan.current_open_loan(user_id=user_id, asset_id=asset_id)
        if loan.remaining_collateral < amount:
            raise Exception('Insufficient balance')

        loan.remaining_collateral -= amount
        UserBalance.deposit(user_id=user_id, quantity=amount)

        db.session.add(loan)
        LoanHistory.create_history_entry(loan=loan, commit=False)
        db.session.commit()
        return loan
            