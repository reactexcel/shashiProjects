from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime

class Profile(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    auth0_user_id = db.Column(db.String)
    name = db.Column(db.String, nullable=False)
    email = db.Column(db.String, nullable=False)
    auto_rebalance = db.Column(db.Boolean, default=False)
    strategy = db.Column(db.String)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def to_dict(self):
        """Convert the Profile instance to a dictionary."""
        return {
            'id': self.id,
            'auth0_user_id': self.auth0_user_id,
            'name': self.name,
            'email': self.email,
            'auto_rebalance': self.auto_rebalance,
            'created_at': self.created_at.isoformat(),  # Convert to ISO format for serialization
        }