from app.database import db
from app.models.BaseModel import BaseModel


class Asset(BaseModel):
    id = db.Column(db.Integer, primary_key=True,
                   autoincrement=True, index=True)
    name = db.Column(db.String, nullable=False)

    _all_assets = None

    @classmethod
    def all(cls):
        if cls._all_assets is None:
            cls._all_assets = cls.query.all()
        return cls._all_assets
