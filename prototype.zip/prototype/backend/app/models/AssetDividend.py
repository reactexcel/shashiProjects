from sqlalchemy import func, and_
from datetime import datetime
from app.database import db
from app.models.BaseModel import BaseModel
from .Asset import Asset
from .PayoutCycle import PayoutCycle
from .PortfolioItem import PortfolioItem
from decimal import Decimal
from sqlalchemy import text
class AssetDividend(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    USD = db.Column(db.Numeric, nullable=False)
    payout_cycle_id = db.Column(db.Integer, db.ForeignKey('payout_cycle.id'), index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.UniqueConstraint('asset_id', 'payout_cycle_id', name='uix_1'),
        db.Index('idx_assetdividend_created_at', 'created_at'),
        db.Index('idx_assetdividend_created_at_assetid', 'created_at', 'asset_id'),
        db.Index('idx_assetdividend_payoutcycle_createdat', 'payout_cycle_id', 'created_at'),

    )

    @classmethod
    def current(cls, asset_id):
        sql = text("""
            SELECT * FROM asset_dividend
            WHERE asset_id = :asset_id
            ORDER BY id DESC
            LIMIT 1
        """)
        result = db.session.execute(sql, {'asset_id': asset_id}).fetchone()
        if result:
            return cls(**result._asdict())
        else:
            return None

    def dividends_per_share(self):
        circulating_user_supply = PortfolioItem.circulating_user_supply(self.asset_id)
        if circulating_user_supply is 0:
            return Decimal('1e-50')
        return self.USD/circulating_user_supply

    @staticmethod
    def latest_dividends_per_asset():
        try:
            subquery = (
                db.session.query(
                    AssetDividend.asset_id, 
                    func.max(AssetDividend.id).label('max_id')
                )
                .group_by(AssetDividend.asset_id)
                .subquery()
            )

            latest_dividends = (
                db.session.query(AssetDividend)
                .join(
                    subquery, 
                    and_(
                        AssetDividend.asset_id == subquery.c.asset_id, 
                        AssetDividend.id == subquery.c.max_id
                    )
                )
                .all()
            )

            return latest_dividends
        except Exception as e:
            # Can happen with no AssetDividends
            print(f"Error occurred: {e}")
            return []