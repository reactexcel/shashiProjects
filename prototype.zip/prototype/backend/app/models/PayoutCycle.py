from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime
from sqlalchemy import text

class PayoutCycle(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_payoutcycle_created_at', 'created_at'),
    )

    @staticmethod
    def max_id():
        # Attempt to get the max id with a single SQL query
        sql = text("SELECT MAX(id) AS max_id FROM payout_cycle")
        result = db.session.execute(sql).scalar()
        if result is not None:
            return result

        db.session.add(PayoutCycle())
        db.session.commit()

        new_max_id = db.session.execute(sql).scalar()

        return new_max_id if new_max_id is not None else 1
