from app.database import db
from app.models import BaseModel, LendingPool
from datetime import datetime


class LendingPoolHistory(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    lending_pool_id = db.Column(db.Integer, db.ForeignKey('lending_pool.id'), nullable=False)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    unutilized_deposits = db.Column(db.Numeric, nullable=False)
    interest_earned = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)


    @classmethod
    def create_history_entry(cls, lending_pool, commit=True):
        untilized_deposits = LendingPool.unutilized_deposits(asset_id=lending_pool.asset_id)
        history_entry = cls(
            lending_pool_id=lending_pool.id,
            asset_id=lending_pool.asset_id,
            unutilized_deposits=untilized_deposits,
            interest_earned=lending_pool.interest_earned,
        )
        db.session.add(history_entry)
        if commit:
            db.session.commit()
