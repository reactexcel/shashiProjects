from app.database import db
from app.models.BaseModel import BaseModel
from . import Asset, Profile, LiquidityPool
from sqlalchemy import func, Index, text
from datetime import datetime
from sqlalchemy.orm import aliased


class PortfolioItem(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    asset_id = db.Column(db.Integer, db.ForeignKey(
        'asset.id'), nullable=False, index=True)
    quantity = db.Column(db.Numeric, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey(
        'profile.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, nullable=False,
                           default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_portfolio_item_user_id_asset_id_id',
                 "user_id", "asset_id", text('id DESC')),
        db.Index('idx_portfolioitem_userid_assetid', 'user_id', 'asset_id')
    )

    @classmethod
    def withdraw(cls, user_id, asset_id, asset_quantity):
        if asset_quantity <= 0:
            raise Exception("Cannot withdraw a negative quantity of an asset from PortfolioItem.")

        old_portfolio_item = PortfolioItem.current(asset_id, user_id)
        if old_portfolio_item is None:
            raise Exception("Cannot withdraw when not owning the asset.")

        if asset_quantity > old_portfolio_item.quantity:
            raise Exception("Cannot withdraw more of an asset than you have.")

        new_quantity = old_portfolio_item.quantity - asset_quantity
        portfolio_item = PortfolioItem(
            user_id=user_id,
            asset_id=asset_id,
            quantity=new_quantity,
        )
        db.session.add(portfolio_item)
        return portfolio_item

    @classmethod
    def deposit(cls, user_id, asset_id, asset_quantity):
        if asset_quantity <= 0:
            raise Exception("Cannot deposit a negative quantity of an asset.")

        old_portfolio_item = PortfolioItem.current(asset_id, user_id)

        new_quantity = asset_quantity
        if old_portfolio_item:
            new_quantity += old_portfolio_item.quantity
        portfolio_item = PortfolioItem(
            user_id=user_id,
            asset_id=asset_id,
            quantity=new_quantity,
        )
        db.session.add(portfolio_item)
        return portfolio_item

    @staticmethod
    def circulating_user_supply(asset_id):
        sql = text("""
        SELECT SUM(pi.quantity) AS total_circulating_supply
        FROM portfolio_item pi
        INNER JOIN (
            SELECT MAX(id) AS max_id, user_id, asset_id
            FROM portfolio_item
            GROUP BY user_id, asset_id
        ) AS latest_pairs ON pi.id = latest_pairs.max_id
        WHERE pi.asset_id = :asset_id;
        """)

        result = db.session.execute(sql, {'asset_id': asset_id}).scalar()
        return result or 0

    @classmethod
    def current(cls, asset_id, user_id):
        sql = text("SELECT quantity FROM portfolio_item WHERE user_id = :user_id AND asset_id = :asset_id ORDER BY id DESC LIMIT 1")
        result = db.session.execute(sql, {'user_id': user_id, 'asset_id': asset_id}).fetchone()
        if result:
            result_dict = result._asdict()
            return cls(**result_dict, asset_id=asset_id, user_id=user_id)
        else:
            return None

    @classmethod
    def latest_user_asset_pairings(cls):
        # Create a subquery that groups by user_id and asset_id and selects the max id
        subquery = db.session.query(
            func.max(PortfolioItem.id).label('max_id')  # type: ignore
        ).group_by(
            PortfolioItem.user_id,
            PortfolioItem.asset_id
        ).subquery()

        # Join the subquery with the original table on the max_id to get the corresponding PortfolioItem objects
        return db.session.query(PortfolioItem).join(
            subquery, PortfolioItem.id == subquery.c.max_id
        ).all()

    @classmethod
    def latest_user_asset_pairings_for_user(cls, user_id):
        # Create a subquery that groups by user_id and asset_id and selects the max id
        subquery = db.session.query(
            func.max(PortfolioItem.id).label('max_id')  # type: ignore
        ).filter(
            PortfolioItem.user_id == user_id  # using filter
        ).group_by(
            PortfolioItem.asset_id
        ).subquery()

        return db.session.query(PortfolioItem).filter(
            PortfolioItem.user_id == user_id  # using filter
        ).join(
            subquery, PortfolioItem.id == subquery.c.max_id
        ).all()

    @classmethod
    def total_asset_quantities(cls, asset_ids):
        # Calculate the total quantity of each asset for a given set of asset IDs
        result = db.session.query(
            PortfolioItem.asset_id,
            func.sum(PortfolioItem.quantity).label('total_quantity')
        ).filter(
            PortfolioItem.asset_id.in_(
                (asset_ids,) if isinstance(asset_ids, int) else asset_ids)
        ).group_by(
            PortfolioItem.asset_id
        )
        return {asset_id: total_quantity for asset_id, total_quantity in result.all()}

    @classmethod
    def get_latest_portfolio_item(cls, user_id, asset_id):
        return cls.query.filter_by(user_id=user_id, asset_id=asset_id).order_by(PortfolioItem.created_at.desc()).first()
