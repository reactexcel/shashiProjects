from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime
from app.models import PortfolioItem, UserBalance, LiquidityPool
from app.models.LoanDepositHistory import LoanDepositHistory
from sqlalchemy import func, text, select
from app.models.LendingPool import LendingPool
from decimal import Decimal

class LoanDeposit(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False, index=True)
    amount = db.Column(db.Numeric, nullable=False)
    available_interest_earned = db.Column(db.Numeric, nullable=False, default=0)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_loan_deposit_asset_user', 'asset_id', 'user_id'),
        db.Index('idx_loan_deposit_created_at', 'created_at'),
    )

    # @classmethod
    # def current(cls, asset_id, user_id, commit=True):
    #     stmt = select(LoanDeposit).where(
    #         LoanDeposit.user_id == user_id,
    #         LoanDeposit.asset_id == asset_id
    #     ).order_by(LoanDeposit.id.desc()).limit(1)
    #     loan_deposit = db.session.execute(stmt).scalar_one_or_none()
    #     if loan_deposit is None:
    #         loan_deposit = LoanDeposit(asset_id=asset_id, amount=0, available_interest_earned=0, user_id=user_id)
    #         if commit:
    #             db.session.add(loan_deposit)
    #             db.session.commit()
    #     return loan_deposit
    @classmethod
    def current(cls, asset_id, user_id, commit=True):
        loan_deposit = cls.query.filter_by(asset_id=asset_id, user_id=user_id).first()
        if loan_deposit is None:
            loan_deposit = LoanDeposit(asset_id=asset_id, amount=0, available_interest_earned=0, user_id=user_id)
            if commit:
                db.session.add(loan_deposit)
                db.session.commit()
        return loan_deposit

    @classmethod
    def current_for_asset(cls, asset_id):
        return cls.query.filter_by(asset_id=asset_id).all()
    
    @classmethod
    def total_deposits_for_asset(cls, asset_id):
        sql = text("""
            SELECT SUM(amount) AS total
            FROM loan_deposit
            WHERE asset_id = :asset_id;
        """)

        result = db.session.execute(sql, {'asset_id': asset_id}).scalar()
        return result or 0

    @staticmethod
    def current_for_user(user_id):
        return LoanDeposit.query.filter_by(user_id=user_id).all()

    @staticmethod
    def deposit(user_id, amount, asset_id):
        if amount <= 0:
            return
        PortfolioItem.withdraw(user_id=user_id, asset_id=asset_id, asset_quantity=amount)
        loan_deposit = LoanDeposit.current(user_id=user_id, asset_id=asset_id, commit=False)
        loan_deposit.amount += amount
        db.session.add(loan_deposit)
        if loan_deposit.id is None:
            db.session.commit()
        LoanDepositHistory.create_history_entry(loan_deposit, commit=False)
        db.session.commit()
        return loan_deposit
    
    @staticmethod
    def withdraw_all_deposits_and_interest(user_id, asset_id):
        loan_deposit = LoanDeposit.current(user_id=user_id, asset_id=asset_id)
        if loan_deposit.amount > 0:
            LoanDeposit.withdraw_deposit(user_id=user_id, asset_id=asset_id, amount=loan_deposit.amount)
        if loan_deposit.available_interest_earned > 0:
            LoanDeposit.withdraw_interest(user_id=user_id, asset_id=asset_id, amount=loan_deposit.available_interest_earned)

    @staticmethod
    def withdraw_deposit(user_id, amount, asset_id):
        loan_deposit = LoanDeposit.current(user_id=user_id, asset_id=asset_id)
        if loan_deposit.amount < amount:
            raise Exception('Insufficient balance')

        LendingPool.withdraw(asset_id=asset_id, amount=amount)
        PortfolioItem.deposit(asset_id=asset_id, user_id=user_id, asset_quantity=amount)
        
        loan_deposit.amount -= amount
        db.session.add(loan_deposit)
        
        LoanDepositHistory.create_history_entry(loan_deposit, commit=False)
        db.session.commit()
        return loan_deposit

    @staticmethod
    def withdraw_interest(user_id, amount, asset_id):
        loan_deposit = LoanDeposit.current(user_id=user_id, asset_id=asset_id)
        if loan_deposit.available_interest_earned < amount:
            raise Exception('Insufficient balance')
        UserBalance.deposit(user_id=user_id, quantity=amount)
        loan_deposit.available_interest_earned -= amount

        db.session.add(loan_deposit)
        
        LoanDepositHistory.create_history_entry(loan_deposit, commit=False)
        db.session.commit()

    @staticmethod
    def deposit_interest(user_id, amount, asset_id):
        if amount <= 0:
            return
        loan_deposit = LoanDeposit.current(user_id=user_id, asset_id=asset_id)
        loan_deposit.available_interest_earned += amount
        db.session.add(loan_deposit)
        LoanDepositHistory.create_history_entry(loan_deposit, commit=False)
        db.session.commit()

    @staticmethod
    def total_deposits(asset_id):
        total = LoanDeposit.query.filter_by(asset_id=asset_id).filter(LoanDeposit.amount > 0).with_entities(func.sum(LoanDeposit.amount)).scalar()
        return total if total is not None else 0

    @staticmethod
    def deposit_and_interest_value(asset_id, user_id):
        exchange_rate = LiquidityPool.current_with_asset_id(asset_id=asset_id).exchange_rate()
        loan_deposit = LoanDeposit.query.filter_by(asset_id=asset_id, user_id=user_id).first()
        amount = loan_deposit.amount
        available_interest_earned = loan_deposit.available_interest_earned
        deposit_value = amount * exchange_rate
        deposit_and_interest_value = deposit_value + available_interest_earned
        return deposit_and_interest_value

