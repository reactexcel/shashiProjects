from app.database import db
from app.models.BaseModel import BaseModel
from datetime import datetime
from sqlalchemy import text

class LoanHistory(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    loan_id = db.Column(db.Integer, db.ForeignKey('loan.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), nullable=False, index=True)
    asset_id = db.Column(db.Integer, db.ForeignKey('asset.id'), nullable=False, index=True)
    amount = db.Column(db.Numeric, nullable=False)
    remaining_collateral = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    @classmethod
    def create_history_entry(cls, loan, commit=True):
        sql = text("""
        INSERT INTO loan_history (loan_id, user_id, asset_id, amount, remaining_collateral, created_at)
        VALUES (:loan_id, :user_id, :asset_id, :amount, :remaining_collateral, :created_at)
        """)
        
        db.session.execute(sql, {
            'loan_id': loan.id,
            'user_id': loan.user_id,
            'asset_id': loan.asset_id,
            'amount': loan.amount,
            'remaining_collateral': loan.remaining_collateral,
            'created_at': datetime.utcnow()
        })
        
        if commit:
            db.session.commit()