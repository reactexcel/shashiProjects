from app.database import db
from app.models.BaseModel import BaseModel
from .Asset import Asset
from .Profile import Profile
from sqlalchemy import Index, desc, text
from sqlalchemy.orm import load_only, joinedload
from decimal import Decimal
from datetime import datetime

class UserBalance(BaseModel):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    user_id = db.Column(db.Integer, db.ForeignKey('profile.id'), primary_key=True)
    quantity = db.Column(db.Numeric, nullable=False)
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    idx_user_balance_user_id_id = Index('idx_user_balance_user_id_id', "user_id", "id.desc()")
    idx_user_balance_user_id_id_desc = Index('idx_user_balance_user_id_id_desc', user_id, desc(id))
    
    __table_args__ = (
        db.Index('idx_user_balance_user_id', 'user_id'),
        db.Index('idx_user_balance_quantity', 'quantity'),
        db.Index('idx_user_balance_created_at', 'created_at'),
    )


    @classmethod
    def current(cls, user_id):
        sql = text("SELECT quantity FROM user_balance WHERE user_id = :user_id ORDER BY id DESC LIMIT 1")
        result = db.session.execute(sql, {'user_id': user_id}).fetchone()
        if result is None:
            return UserBalance(user_id=user_id, quantity=0)
        else:
            # Ensure quantity is treated as Decimal if not automatically done
            quantity = Decimal(result[0]) if not isinstance(result[0], Decimal) else result[0]
            return UserBalance(user_id=user_id, quantity=quantity)

    @classmethod
    def withdraw(cls, user_id, quantity):
        if quantity <= 0:
            raise Exception(f"Cannot withdraw a negative quantity from UserBalance.")
        
        old_balance = UserBalance.current(user_id)
        if old_balance is None:
            raise Exception("Cannot withdraw when not owning any balance.")

        if quantity > old_balance.quantity:
            raise Exception(f"Cannot withdraw {quantity} as it is more than your current balance of {old_balance.quantity}.")
        
        new_quantity = old_balance.quantity - quantity
        user_balance = UserBalance(
            user_id=user_id,
            quantity=new_quantity,
        )
        db.session.add(user_balance)

    @classmethod
    def deposit(cls, user_id, quantity):
        if quantity == 0:
            return
        
        if quantity < 0:
            raise Exception("Cannot deposit a negative quantity.")
        
        old_balance = cls.current(user_id=user_id)

        new_quantity = quantity
        if old_balance:
            new_quantity += old_balance.quantity
        
        user_balance = UserBalance(
            user_id=user_id,
            quantity=new_quantity,
        )
        db.session.add(user_balance)