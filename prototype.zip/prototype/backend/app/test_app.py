from app import create_app


def create_test_app(run=False):
    return create_app(run=run, testing=True)
