from flask import Flask
from app.database import db
from flask_cors import CORS
from app.routes.routes import register_all_routes
from dotenv import load_dotenv
from flask_migrate import Migrate, upgrade
from app.models import Asset, Profile
from app.tests.factories import (
   MarketBalanceFactory, 
   LiquidityPoolFactory,
    PortfolioItemFactory, 
   UserBalanceFactory,
   DividendPayoutFactory,
   AssetDividendFactory,
   AirMeasureFactory,
)
from decimal import Decimal
import random
import os
import logging

def create_app(run=False, testing=False, simulator=False, database_uri=None):
    load_dotenv()
    app = Flask(__name__)
    
    if testing:
        app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('TEST_DATABASE_URL')
    elif simulator:
        app.config['SQLALCHEMY_DATABASE_URI'] = database_uri
    else:
        app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_pre_ping': True,
        'pool_recycle': 300
    }
    # Add the following lines to configure Celery
    app.config['CELERY_BROKER_URL'] = os.environ.get('CELERY_BROKER_URL', 'redis://localhost:6379/0')
    app.config['CELERY_RESULT_BACKEND'] = os.environ.get('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')
    logging.basicConfig(level=logging.DEBUG)
    CORS(
        app, 
        origins=['https://pbetest.onrender.com', 'https://pbtestfe.onrender.com'] + ['http://localhost:300{}'.format(i) for i in range(10)],
        allow_headers=["Authorization", "Content-Type"],
      )

    register_all_routes(app)
    db.init_app(app)
    Migrate(app, db)
    if run:
        with app.app_context():
            upgrade()


    @app.cli.command("create_db")
    def create_db_command():
        db.create_all()
        print("Database tables created successfully.")

    @app.cli.command("drop_db")
    def drop_db_command():
        db.drop_all()
        print("Tables deleted!")

    @app.cli.command("seed_db")
    def seed_db_command():
        logging.info("Starting to seed database.")

        logging.info("Seeding MarketBalance.")
        MarketBalanceFactory(quantity=Decimal(100000))
        db.session.flush()
    
        logging.info("Seeding UserBalance.")
        UserBalanceFactory.create_batch(size=10)
        db.session.flush()

        logging.info("Seeding LiquidityPool.")
        LiquidityPoolFactory.create_batch(size=10,create=True)
        db.session.flush()

        logging.info("Seeding PortfolioItems.")
        profiles = Profile.query.all()
        assets = Asset.query.all()
        for asset in assets:
            AirMeasureFactory.create(asset_id=asset.id, pm_25_10_minute=25, sensor_count=1)
            AssetDividendFactory.create(asset_id=asset.id, USD=Decimal(300))
            db.session.flush()
        logging.info('assets')
        logging.info(assets)
        logging.info('user')
        logging.info(profiles)
        for user in profiles:
            for asset in assets:
                PortfolioItemFactory.create(user_id=user.id, asset_id=asset.id, quantity=Decimal(random.randint(50, 250)))
        db.session.commit()
        logging.info("Database seeded!")
    return app
