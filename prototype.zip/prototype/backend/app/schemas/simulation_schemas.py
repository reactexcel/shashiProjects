from marshmallow import Schema, fields


class SimulationSchema(Schema):
    strategies = fields.List(fields.String(), required=True)
    aqi_data = fields.Dict(required=True)
    traders = fields.Dict(required=True)
