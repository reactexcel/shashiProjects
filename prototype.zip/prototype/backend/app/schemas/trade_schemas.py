from marshmallow import Schema, fields


class BuySchema(Schema):
    pool_id = fields.Int(required=False)
    asset_id = fields.Int(required=True)
    amount_in = fields.Decimal(required=True)
    user_id = fields.Int(required=False)

class SellSchema(Schema):
    pool_id = fields.Int(required=False)
    asset_id = fields.Int(required=True)
    asset_quantity = fields.Decimal(required=True)
    user_id = fields.Int(required=False)


class AddLiquiditySchema(Schema):
    pool_id = fields.Int(required=True)
    asset_id = fields.Int(required=True)
    user_usd = fields.Decimal(required=True)
    asset_quantity = fields.Decimal(required=True)
    user_id = fields.Int(required=True)



