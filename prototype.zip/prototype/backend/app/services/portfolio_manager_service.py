from app.models import PortfolioItem, LiquidityPool, Asset, AssetDividend, UserBalance, Pool
from app.services import LiquidityService
from app.database import db
from decimal import Decimal
import time
import math
import logging
import statistics

class PortfolioManagerService:
    def __init__(self, user_id):
        self.user_id = user_id

    def reallocate_portfolio(self, _print=False):
        dividend_price_ratios = self.calculate_per_share_dividend_price_ratios()

        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'USER_ID {self.user_id}')
        if _print: print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        if _print: print(f'dividend_price_ratios {dividend_price_ratios}')

        if not dividend_price_ratios:
            return

        median_ratio = statistics.median(dividend_price_ratios.values())
        avg_ratio = sum(dividend_price_ratios.values()) / len(dividend_price_ratios)

        if _print: print(f'avg_ratio {avg_ratio}')
        if _print: print(f'median_ratio {median_ratio}')
        
        if _print: print(f'USER_ID {self.user_id}')

        start_time = time.time()
        self._sell_positions_below_average(dividend_price_ratios, median_ratio)
        sell_time = time.time() - start_time
        if _print: print(f"_sell_positions_below_average took {sell_time} seconds")

        start_time = time.time()
        self._buy_positions_above_average(dividend_price_ratios, median_ratio)
        buy_time = time.time() - start_time
        if _print: print(f"_buy_positions_above_average took {buy_time} seconds")


    def calculate_per_share_dividend_price_ratios(self) -> dict:
        last_dividend_data = self._get_last_dividend_per_share_data()
        latest_pools = LiquidityPool.latest_pools_per_id()

        # Construct the ratio dictionary using available asset_ids
        return {
            pool.asset_id: self._calculate_ratio(last_dividend_data, pool)
            for pool in latest_pools
            if pool.asset_id in last_dividend_data
        }

    def _calculate_ratio(self, last_dividend_data: dict, pool) -> float:
        asset_id = pool.asset_id
        exchange_rate = pool.exchange_rate()
        if exchange_rate == 0:
            return 0.0
        return last_dividend_data[asset_id] / exchange_rate


    def _get_last_dividend_per_share_data(self) -> dict:
        assets = Asset.query.all()
        return {
          asset.id: self._dividends_per_share(asset_id=asset.id)
          for asset in assets 
        }
    
    def _dividends_per_share(self, asset_id):
        asset_dividend = AssetDividend.current(asset_id=asset_id)
        if asset_dividend is None:
            return Decimal('1E-50')
        return asset_dividend.dividends_per_share()

    def _sell_positions_below_average(self, dividend_price_ratios, avg_ratio):
        for asset_id, ratio in dividend_price_ratios.items():
            if ratio < avg_ratio:
                # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
                # print(f'selling asset_id {asset_id}')

                lp = LiquidityPool.current_with_asset_id(asset_id=asset_id)
                # print(f'lp.id {lp.id}')
                ideal_exchange_rate = self._ideal_exchange_rate(dividend_price_ratios[asset_id], avg_ratio, lp)
                # print(f'current exchange rate = {lp.exchange_rate()}')
                # print(f'ideal_exchange_rate = {ideal_exchange_rate}')
                
                # Assuming get_ideal_selling_amount is a method in LiquidityPool
                ideal_selling_amount = lp.get_ideal_selling_amount(ideal_exchange_rate)
                # print(f'ideal_selling_amount = {ideal_selling_amount}')
                
                # Get current portfolio item
                portfolio_item = PortfolioItem.current(asset_id=asset_id, user_id=self.user_id)
                if portfolio_item is None:
                    continue
                
                # print(f'user has quantity {portfolio_item.quantity}')
                # Calculate the strategic amount to sell
                sell_amount = min(ideal_selling_amount, math.floor(portfolio_item.quantity))
                # print(f'sell_amount = {sell_amount}')
                
                # This should be fixed. 
                # Skip if there's nothing to sell (and if only selling 1, keep it for dividend service issue when there are 0 ownership by all users)
                if sell_amount <= 1:
                    continue
                # Sell
                pool_id = Pool.get_pool_id_for_asset(asset_id=asset_id)
                LiquidityService().sell(
                    pool_id=pool_id, 
                    user_id=self.user_id, 
                    asset_id=asset_id, 
                    asset_quantity=sell_amount,
                    commit=True
                )

        db.session.commit()

    def _ideal_exchange_rate(self, dividend_price_ratio, target_dividend_price_ratio, latest_pool):
        dividends_for_asset = dividend_price_ratio * latest_pool.exchange_rate()
        ideal_exchange_rate = dividends_for_asset / target_dividend_price_ratio
        return ideal_exchange_rate
        
    def _buy_positions_above_average(self, dividend_price_ratios, avg_ratio):
        # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
        potential_buys = [asset_id for asset_id, ratio in dividend_price_ratios.items() if ratio > avg_ratio]
        # print(f'potential_buys {potential_buys}')
        cash_available = UserBalance.current(user_id=self.user_id).quantity
        # print(f'cash_available {cash_available}')
        total_ratio = sum(dividend_price_ratios[asset_id] for asset_id in potential_buys)
        to_buy = {asset_id: cash_available * dividend_price_ratios[asset_id] / total_ratio for asset_id in potential_buys}
        for asset_id, amount in to_buy.items():
            # print(f'~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
            # print(f'buying asset = {asset_id}')

            lp = LiquidityPool.current_with_asset_id(asset_id=asset_id)
            ideal_exchange_rate = self._ideal_exchange_rate(dividend_price_ratios[asset_id], avg_ratio, lp)
            # print(f'current exchange rate = {lp.exchange_rate()}')
            # print(f'ideal_exchange_rate = {ideal_exchange_rate}')
            ideal_purchase_amount = lp.get_ideal_purchase_amount(ideal_exchange_rate)
            # print(f'ideal_purchase_amount = {ideal_purchase_amount}')

            purchase_amount = min(ideal_purchase_amount, amount)
            # print(f'cash partioned for trade = {amount}')
            # print(f'purchase_amount = {purchase_amount}')
            balance = UserBalance.current(user_id=self.user_id).quantity
            if purchase_amount > balance:
                # print(f'attempted to buy ${purchase_amount}, which is more than user owned (${balance})')
                purchase_amount = balance
            if balance < 0.01:
                break
            LiquidityService().buy(pool_id=None, USD_in=purchase_amount, asset_id=asset_id, user_id=self.user_id)