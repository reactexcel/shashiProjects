from app.models import Profile, PortfolioItem, LiquidityPool
from app.services import PortfolioService
from app.database import db
from app.helpers import table_column_set, expand_number

class LeaderboardService:

    @staticmethod
    def get_leaderboard_data():
        users = db.session.query(Profile).join(PortfolioItem).group_by(Profile.id).all()

        leaderboard_data = {
            'columns': LeaderboardService.get_leaderboard_columns(),
            'data': []
        }

        for idx, user in enumerate(users):
            performance_data = LeaderboardService.get_performance_data(user)

            leaderboard_data['data'].append({
                "data": performance_data
            })

        leaderboard_data['data'] = sorted(
            leaderboard_data['data'], 
            key=lambda x: expand_number(x['data']['roi']) or 0, 
            reverse=True
        )

        for idx, item in enumerate(leaderboard_data['data'], start=1):
            item['data']['rank'] = f"#{idx}"
            item['data']['row_color'] = LeaderboardService.get_row_color(idx - 1)
            item['id'] = idx

        return leaderboard_data


    @staticmethod
    def get_leaderboard_columns():
        return [
            table_column_set(key="rank", label="Rank", type="text", isLeftAligned=True, isBold=True),
            table_column_set(key="name", label="Name", type="text", isLeftAligned=True, isBold=True),
            table_column_set(key="net_worth", label="Net Worth", type="currency", isLeftAligned=False, isBold=True),
            table_column_set(key="profit", label="Profit", type="currency", isLeftAligned=False, isBold=True),
            table_column_set(key="roi", label="ROI %", type="percentage", isLeftAligned=False, isBold=True),
            table_column_set(key="row_color", label="Color", type="text", isLeftAligned=False, isBold=True),
        ]

    @staticmethod
    def get_row_color(idx):
        color = ["#D6EDED", "#F7E5E1", "#E8E8F4"]
        return color[idx] if idx < len(color) else "#FFFFFF"

    @staticmethod
    def get_performance_data(user):
        portfolio = PortfolioItem.latest_user_asset_pairings_for_user(user.id)
        pools = LiquidityPool.latest_pools_per_id()
        exchange_rates = {pool.asset_id: pool.exchange_rate() for pool in pools}
        total_asset_value = PortfolioService.total_asset_value(portfolio, exchange_rates)
        
        portfolio_data = PortfolioService.get_portfolio_data(user, total_asset_value)

        return {
            "name": user.name,
            "net_worth": portfolio_data['netWorth'],
            "profit": portfolio_data['annualProfit'],
            "roi": portfolio_data['roiPercent'],
            "user_id": user.id,
        }
