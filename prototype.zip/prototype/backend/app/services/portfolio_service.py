from datetime import datetime
from flask import jsonify, request
from app.models import PortfolioItem, Asset, LiquidityPool, Transaction, Profile, LoanDeposit
from app.services import TransactionService, UserBalanceService
from app.helpers.shorten_number import shorten_number
from app.helpers import table_column_set
import logging
import traceback


class PortfolioService:

    ASSET_NAME_KEY = 'asset'
    TRADE_TYPE_KEY = 'type'
    QUANTITY_KEY = 'quantity'
    TOTAL_KEY = 'total'
    PRICE_KEY = 'price'
    DATE_KEY = 'date'

    @staticmethod
    def asset_holding_columns():
        return [
            table_column_set(key="asset", label="Asset", type="text", isLeftAligned=True),
            table_column_set(key="quantity", label="Quantity", type="number", isLeftAligned=False),
            table_column_set(key="shares", label="Shares", type="number", isLeftAligned=False),
            table_column_set(key="value", label="Value", type="currency", isLeftAligned=False),
            table_column_set(key="color", label="Color", type="text", isLeftAligned=False)
        ]

    @staticmethod
    def get_user_details(user):
        return {
            "name": user.name,
            "userId": user.id
        }

    @staticmethod
    def fetch_transactions(user_id, limit):
        return Transaction.query.filter_by(user_id=user_id).order_by(Transaction.created_at.desc()).limit(limit)

    @staticmethod
    def trade_info_columns():
        return [
            table_column_set(key=PortfolioService.TRADE_TYPE_KEY, label="Type", type="text", isLeftAligned=True),
            table_column_set(key=PortfolioService.ASSET_NAME_KEY, label="Asset", type="text", isLeftAligned=True, isBold=True),
            table_column_set(key=PortfolioService.TOTAL_KEY, label="Total", type="currency", isLeftAligned=False, isBold=True),
            table_column_set(key=PortfolioService.QUANTITY_KEY, label="Quantity", type="number", isLeftAligned=False),
            table_column_set(key=PortfolioService.PRICE_KEY, label="Price", type="currency", isLeftAligned=False),
            table_column_set(key=PortfolioService.DATE_KEY, label="Date", type="date", isLeftAligned=False),
        ]

    @staticmethod
    def populate_trade_info(transactions):
        transaction_info = {'data': [],
                            'columns': PortfolioService.trade_info_columns()}
        assets = Asset.query.all()
        asset_id_name_map = {asset.id: asset.name for asset in assets}

        for transaction in transactions:
            asset_id = transaction.asset_id
            trade_entry = {
                PortfolioService.TRADE_TYPE_KEY: transaction.trade_type,
                PortfolioService.ASSET_NAME_KEY: asset_id_name_map.get(asset_id, ""),
                PortfolioService.QUANTITY_KEY: shorten_number(float(transaction.asset_quantity), 2),
                PortfolioService.TOTAL_KEY: shorten_number(float(transaction.USD), 2),
                PortfolioService.PRICE_KEY: shorten_number(transaction.price, 2),
                PortfolioService.DATE_KEY: transaction.created_at
            }
            row = {'data': trade_entry, 'id': transaction.transaction_id}
            transaction_info['data'].insert(0, row)

            TEMP_MAX_LENGTH = 50
            if len(transaction_info['data']) > TEMP_MAX_LENGTH:
                transaction_info['data'].pop()

        return transaction_info

    @staticmethod
    def get_recent_transactions(user_id, limit=50):
        transactions = PortfolioService.fetch_transactions(user_id, limit)
        return PortfolioService.populate_trade_info(transactions)

    @staticmethod
    def asset_holdings_table_data(portfolio, asset_id_name_map, exchange_rates):
        colors = PortfolioService.generate_colors(len(portfolio))
        asset_holdings_table_data = {'columns': PortfolioService.asset_holding_columns(), 'data': []}

        asset_values_with_indices = []
        
        for index, item in enumerate(portfolio):
            asset_id = item.asset_id
            asset_name = asset_id_name_map.get(asset_id, "")
            quantity = item.quantity
            asset_value = quantity * exchange_rates.get(asset_id, 0)

            asset_values_with_indices.append((index, asset_value))

            asset_holdings_table_data['data'].append({
                "id": item.id,
                "data": {
                    "asset": asset_name,
                    "quantity": shorten_number(quantity, 2),
                    "shares": shorten_number(quantity, 2),
                    "value": shorten_number(asset_value, 2),
                    "color": colors[index]
                }
            })

        asset_values_with_indices.sort(key=lambda x: x[1], reverse=True)
        asset_holdings_table_data['data'] = [asset_holdings_table_data['data'][index] for index, _ in asset_values_with_indices]

        return asset_holdings_table_data

    @staticmethod
    def assets_holdings_pie_chart_data(portfolio, total_asset_value, asset_id_name_map, exchange_rates):
        colors = PortfolioService.generate_colors(len(portfolio))
        assets_holdings_pie_chart_data = []

        asset_values_with_indices = []

        for index, item in enumerate(portfolio):
            asset_id = item.asset_id
            asset_name = asset_id_name_map.get(asset_id, "")
            quantity = item.quantity
            asset_value = quantity * exchange_rates.get(asset_id, 0)

            if total_asset_value != 0:
                percentage = round((asset_value / total_asset_value) * 100, 2)
            else:
                percentage = 0.0

            assets_holdings_pie_chart_data.append({
                "name": asset_name,
                "color": colors[index],
                "value": shorten_number(asset_value, 2),
                "percentage": percentage
            })

            asset_values_with_indices.append((index, asset_value))
        
        asset_values_with_indices.sort(key=lambda x: x[1], reverse=True)
        assets_holdings_pie_chart_data = [assets_holdings_pie_chart_data[index] for index, _ in asset_values_with_indices]

        return assets_holdings_pie_chart_data
    
    @staticmethod
    def total_asset_value(portfolio, exchange_rates):
        total_value = 0
        for item in portfolio:
            total_value += item.quantity * exchange_rates.get(item.asset_id, 0)
        return total_value

    @staticmethod
    def get_assets_holdings_data(user_id):
        portfolio = PortfolioItem.latest_user_asset_pairings_for_user(user_id)
        pools = LiquidityPool.latest_pools_per_id()
        exchange_rates = {pool.asset_id: pool.exchange_rate()
                          for pool in pools}

        asset_ids = [item.asset_id for item in portfolio]
        assets = Asset.query.filter(Asset.id.in_(asset_ids)).all()
        asset_id_name_map = {asset.id: asset.name for asset in assets}

        total_asset_value = PortfolioService.total_asset_value(portfolio, exchange_rates)
        asset_holdings_table_data = PortfolioService.asset_holdings_table_data(portfolio, asset_id_name_map, exchange_rates)
        assets_holdings_pie_chart_data = PortfolioService.assets_holdings_pie_chart_data(portfolio, total_asset_value, asset_id_name_map, exchange_rates)
        
        return asset_holdings_table_data, assets_holdings_pie_chart_data, total_asset_value

    @staticmethod
    def generate_colors(num_colors):
        base_colors = ['#F6B9AA', '#C3C1EB', '#86D4D5', '#D5BF86', '#FFF7AF',
                    '#C2C2C2', '#FFD699', '#FFC3DC', '#05FFFF33', '#FF7878']
        if num_colors > len(base_colors):
            additional_colors = ['#808080'] * (num_colors - len(base_colors))
            base_colors.extend(additional_colors)
        return base_colors[:num_colors]
    
    @staticmethod
    def get_portfolio_data(user, total_asset_value):
        cash_balance = UserBalanceService(
            user.auth0_user_id).get_user_balance()
        
        earliest_positive_cash_balance = UserBalanceService.earliest_positive_balance(user.id).quantity
        net_worth = cash_balance + total_asset_value
        annual_profit = net_worth - earliest_positive_cash_balance
        roi = round(((annual_profit / earliest_positive_cash_balance)) * 100, 2)
        return {
            "cashBalance": shorten_number(cash_balance, 2),
            "assetsValue": shorten_number(total_asset_value, 2),
            "annualProfit": shorten_number(annual_profit, 2),
            "roiPercent": shorten_number(roi, 2),
            "netWorth": shorten_number(net_worth, 2),
        }
    
    @staticmethod
    def get_user_portfolio(user_id):
        user = Profile.query.filter_by(id=user_id).first()

        user_details = PortfolioService.get_user_details(user)
        recent_transactions = PortfolioService.get_recent_transactions(user_id, limit=50)

        assets_holdings_table_data, assets_holdings_pie_chart_data, total_asset_value = \
            PortfolioService.get_assets_holdings_data(user_id)

        portfolio_data = PortfolioService.get_portfolio_data(
            user, total_asset_value)

        return {
            'userDetails': user_details,
            'portfolioData': portfolio_data,
            'assetsHoldingsChartData': assets_holdings_pie_chart_data,
            'assetsHoldings': assets_holdings_table_data,
            'recentTransactions': recent_transactions
        }

    @staticmethod
    def net_worth(user_id):
        assets_holdings_table_data, assets_holdings_pie_chart_data, total_asset_value = \
            PortfolioService.get_assets_holdings_data(user_id)
        user = Profile.query.filter_by(id=user_id).first()

        cash_balance = UserBalanceService(
            user.auth0_user_id).get_user_balance()

        net_worth = cash_balance + total_asset_value

        loan_deposits = LoanDeposit.current_for_user(user_id=user_id)
        loan_deposits_value = [LoanDeposit.deposit_and_interest_value(
            asset_id=loan_deposit.asset_id, user_id=user_id
        ) for loan_deposit in loan_deposits]

        total_net_worth = net_worth + sum(loan_deposits_value)

        return total_net_worth

    @staticmethod
    def handle_error(exception):
        logging.error(
            f"An error occurred: {exception}\n{traceback.format_exc()}")
        return jsonify({'message': f'An unexpected error occurred {str(exception)}\n{traceback.format_exc()}.'}), 500
