import os
import requests
from typing import List
from app.models import AssetRegion
from app.models.SensorData import SensorData

class PurpleAirService():
    def __init__(self):
        self.purple_air_fields = 'sensor_index,pm2.5_10minute'
        self.check_environment_vars()

    def check_environment_vars(self):
        if not os.environ.get('PURPLE_AIR_READ'):
            raise EnvironmentError("PURPLE_AIR_READ environment variable not set")
    
    def north_america_bounds(self):
        return AssetRegion(id=1, asset_id=1, nwlng=-155.742188, nwlat=60.673179, selng=-48.7792970, selat=13.752725)

    def global_bounds(self):
        return AssetRegion(2, 1, -179.357300, 84.741283, 191.189575, -52.033063)
    
    def grab_north_america_data(self):
        return self.grab_purple_air_data_for_bounds(self.north_america_bounds())
    
    def grab_global_data(self):
        return self.grab_purple_air_data_for_bounds(self.global_bounds())

    def grab_region_data(self, asset_region: AssetRegion):
        return self.grab_purple_air_data_for_bounds(asset_region)

    def grab_purple_air_data_for_bounds(self, region: AssetRegion) -> List[SensorData]:
        if not isinstance(region, AssetRegion):
            raise TypeError("region must be an instance of Bounds")

        purple_air_key = os.environ.get('PURPLE_AIR_READ')
        if not purple_air_key:
            print('Purple air key not detected')
            return []
        
        url = 'https://api.purpleair.com/v1/sensors/'
        headers = {'X-API-Key': purple_air_key}
        payload = {
            'nwlng': region.nwlng,
            'nwlat': region.nwlat,
            'selng': region.selng,
            'selat': region.selat,
            'fields': self.purple_air_fields
        }
        r = requests.get(url, headers=headers, params=payload)
        try:
            r.raise_for_status()
            data = r.json()['data']
            return [SensorData(*sensor) for sensor in data]
        except requests.exceptions.RequestException as e:
            print(f"An error occurred with the Purple Air API: {e}")
            return []
