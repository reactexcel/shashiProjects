from app.models import UserBalance, Profile, LoanDeposit
from decimal import Decimal


class UserBalanceService:
    def __init__(self, user_id) -> None:
         self.auth0_user_id = user_id

    def get_user_by_auth0_id(self) -> Profile:
        try:
            user = Profile.query.filter_by(auth0_user_id=self.auth0_user_id).first()
            if not user:
                raise ValueError(f'User with auth0_user_id {self.auth0_user_id} not found')
        except Exception as error:
            raise error
        return user

    def get_user_balance(self) -> Decimal:
        try:
            user_id = self.get_user_by_auth0_id().id
            # Get latest balance
            user_balance: UserBalance = UserBalance.query.filter_by(user_id=user_id).order_by(UserBalance.created_at.desc()).first()
            if not user_balance:
                raise ValueError(f'User balance for user_id {user_id} not found')
        except Exception as error:
            raise error
        return user_balance.quantity

    def earliest_positive_balance(user_id):
        return UserBalance.query.filter(UserBalance.user_id == user_id, UserBalance.quantity > 0).order_by(UserBalance.created_at).first()