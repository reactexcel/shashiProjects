from app.models import AssetDividend, Asset, MarketBalance, AssetInfo, LiquidityPool
from app.services.asset_info_service import AssetInfoService
from app.helpers.shorten_number import shorten_number, expand_number
from app.helpers.parallel import execute_functions_in_pool
from datetime import datetime, timedelta
from app.services.air_measure_service import AirMeasureService




def volume_and_market_cap_info():
    assets_info = AssetInfo.get_latest_asset_infos()
    market_caps = []
    market_caps_close_to_24hr_ago = []
    trade_volumes = []
    for asset_info in assets_info:   
        asset_info_service = AssetInfoService(asset_id=asset_info.asset_id)
        latest_circulating_supply = asset_info.circulating_supply
        market_cap_close_to_24hr_ago = latest_circulating_supply * asset_info_service.price_close_to_24hr_ago()
        market_caps_close_to_24hr_ago.append(market_cap_close_to_24hr_ago)
        market_caps.append(asset_info.market_cap)
        trade_volumes.append(asset_info.one_day_trade_vol)

    market_cap = sum(market_caps)
    market_cap_close_to_24hr_ago = sum(market_caps_close_to_24hr_ago)
    market_cap_change = (market_cap - market_cap_close_to_24hr_ago) / market_cap_close_to_24hr_ago * 100 if market_cap_close_to_24hr_ago > 0 else 0
    trade_volume = sum(trade_volumes)

    return market_cap, market_cap_change, trade_volume



def dividend_info():
    now = datetime.utcnow()
    twenty_four_hours_ago = now - timedelta(hours=24)
    forty_eight_hours_ago = now - timedelta(hours=48)

    dividends_past_24hr = AssetDividend.query.filter(
        AssetDividend.created_at >= twenty_four_hours_ago,
    ).all()

    dividends_between_24_and_48hr = AssetDividend.query.filter(
        AssetDividend.created_at >= forty_eight_hours_ago,
        AssetDividend.created_at < twenty_four_hours_ago,
    ).all()
    dividends_total_between_24_and_48hr = sum([dividend.USD for dividend in dividends_between_24_and_48hr])
    dividends_total_past_24hr = sum([dividend.USD for dividend in dividends_past_24hr])

    dividends_change = (dividends_total_past_24hr - dividends_total_between_24_and_48hr) / dividends_total_between_24_and_48hr * 100 if dividends_total_between_24_and_48hr else 0

    return dividends_total_past_24hr, dividends_change

def market_balance_info():
    now = datetime.utcnow()
    twenty_four_hours_ago = now - timedelta(hours=24)
    latest_market_balance = MarketBalance.query.order_by(MarketBalance.created_at.desc()).first()
    market_balance_24hr_ago = MarketBalance.query.filter(
        MarketBalance.created_at >= twenty_four_hours_ago,
    ).order_by(MarketBalance.created_at).first()
    
    latest_market_balance = latest_market_balance.quantity if latest_market_balance is not None else 0
    market_balance_24hr_ago = market_balance_24hr_ago.quantity if market_balance_24hr_ago is not None else 0
    market_balance_change = (latest_market_balance - market_balance_24hr_ago) / market_balance_24hr_ago * 100 if market_balance_24hr_ago else 0
    return latest_market_balance, market_balance_change
    

def market_info():
    
    functions = [volume_and_market_cap_info, dividend_info, market_balance_info]
    volume_and_market_cap_data, dividend_data, market_balance_data = execute_functions_in_pool(functions)
    market_cap, market_cap_change, trade_volume = volume_and_market_cap_data if volume_and_market_cap_data else [None, None, None]
    dividends, dividends_change = dividend_data if dividend_data else [None, None]
    market_balance, market_balance_change = market_balance_data if market_balance_data else [None, None]
    data = {
        'market_cap': {
            'order': 1,
            'label': 'Market Cap',
            'value': shorten_number(market_cap),
            '24hr_change': shorten_number(market_cap_change)
        },
        'trade_volume' : {
            'order': 2, 
            'label': '24h Vol',
            'value': shorten_number(trade_volume),
            '24hr_change': 0
        },
        'dividends' : {
            'order': 3, 
            'label': '24h Dividends',
            'value': shorten_number(dividends),
            '24hr_change': shorten_number(dividends_change)
        }, 
        'market_balance' : {
            'order': 4,
            'label': 'Market Balance',
            'value': shorten_number(market_balance),
            '24hr_change': shorten_number(market_balance_change)
        },
    }
    return data

