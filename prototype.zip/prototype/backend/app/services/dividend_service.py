from app.models import PortfolioItem, MarketBalance, Asset, DividendPayout, UserBalance, PayoutCycle, AssetDividend, AirMeasure
from app.database import db
import random
from decimal import Decimal
from typing import Dict, List, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from app.constants import PERCENT_OF_POOL_DISTRIBUTED

@dataclass
class PayoutCalculationContext:
    total_asset_quantities: Dict[int, Decimal]
    asset_payout_percentages: Dict[int, Decimal]
    fees_to_distribute: Decimal

class DividendService:
    #TODO make a table for this
    dividend_rate = Decimal(0.01)
    payout_cycle_id = None

    def __init__(self):
        self._max_portfolio_item_ids_for_user_asset_pair = None
        self.payout_cycle_id = self.get_payout_cycle()
        
    def distribute_dividends(self):
        try:          
          fees_to_distribute = self.fees_to_distribute()
          MarketBalance.withdraw(fees_to_distribute)

          latest_portfolio_items = self.get_latest_portfolio_items()
          user_total_payouts, db_items = self.calculate_user_payouts(latest_portfolio_items, fees_to_distribute)

          self.update_user_balances(user_total_payouts)
          self.save_dividend_payouts(db_items)
        except Exception as e:
            db.session.rollback()
            raise e

    def get_latest_portfolio_items(self):
        return PortfolioItem.latest_user_asset_pairings()


    def get_payout_cycle(self):
        if self.payout_cycle_id is None:    
            payout_cycle = PayoutCycle()
            db.session.add(payout_cycle)
            db.session.flush()
            self.payout_cycle_id = payout_cycle.id
        return self.payout_cycle_id

    def _calculate_user_payout_for_item(self, item, context: PayoutCalculationContext):
        asset_total_quantity = context.total_asset_quantities[item.asset_id]
        user_percentage_of_asset = Decimal((item.quantity / asset_total_quantity) if asset_total_quantity else 0)
        return user_percentage_of_asset * context.asset_payout_percentages[item.asset_id] * context.fees_to_distribute

    def _create_dividend_payout(self, user_id, asset_id, amount_in_usd):
        return DividendPayout(
            user_id=user_id,
            asset_id=asset_id,
            amount_in_usd=amount_in_usd,
            payout_cycle_id=self.payout_cycle_id
        )

    def calculate_user_payouts(self, latest_portfolio_items: List[PortfolioItem], fees_to_distribute: Decimal) -> Tuple[Dict[int, float], List[DividendPayout]]:
        total_asset_quantities = PortfolioItem.total_asset_quantities([item.asset_id for item in latest_portfolio_items])
        asset_payout_percentages = self.asset_payout_percentages()
        self.make_asset_dividend_payouts(asset_payout_percentages, fees_to_distribute)
        context = PayoutCalculationContext(total_asset_quantities, asset_payout_percentages, fees_to_distribute)
        user_total_payouts = {}
        db_items = []
        for item in latest_portfolio_items:
            payout_for_user_asset = self._calculate_user_payout_for_item(item, context)
            user_total_payouts[item.user_id] = user_total_payouts.get(item.user_id, 0) + payout_for_user_asset
            db_items.append(self._create_dividend_payout(item.user_id, item.asset_id, payout_for_user_asset))

        return user_total_payouts, db_items

    def update_user_balances(self, user_total_payouts):
        for user_id, payout in user_total_payouts.items():
            UserBalance.deposit(user_id=user_id, quantity=payout)

    def save_dividend_payouts(self, db_items):
        db.session.add_all(db_items)
        db.session.commit()

    def fees_to_distribute(self):
        fee_pool = MarketBalance.current()
        return Decimal(self.dividend_rate) * Decimal(fee_pool.quantity)

    def make_asset_dividend_payouts(self, asset_payout_percents, fees_to_distribute):
        try:
            for asset_id, payout_percent in asset_payout_percents.items():
                db.session.add(AssetDividend(asset_id=asset_id, USD=payout_percent*fees_to_distribute, payout_cycle_id=self.payout_cycle_id))
            db.session.commit()
        except Exception as e:
            db.session.rollback()
            raise e

    def asset_payout_percentages(self):
        # Get all distinct assets
        assets = db.session.query(Asset).all()

        # Assign a PM2.5 value to each asset
        asset_pm25_values = {}
        for asset in assets:
            air_measure = AirMeasure.current(asset_id=asset.id)
            if air_measure:
                asset_pm25_values[asset.id] = air_measure.pm_25_10_minute

        # Calculate the scaled PM2.5 value for each asset
        min_threshold = 5  # example threshold
        scaled_pm25_values = {asset: Decimal(pm25) ** Decimal(-0.5) if pm25 > min_threshold else Decimal(min_threshold) ** Decimal(-0.5) for asset, pm25 in asset_pm25_values.items()}

        # Calculate the total scaled PM2.5 value
        total_scaled_pm25 = sum(scaled_pm25_values.values())
        if total_scaled_pm25 == 0:
            total_scaled_pm25 = Decimal(1)

        # Calculate the percentage each asset gets
        asset_percentages = {asset: Decimal(scaled_pm25 / total_scaled_pm25) for asset, scaled_pm25 in scaled_pm25_values.items()}

        return asset_percentages

def get_dividend_per_share_history(asset_id, period):
    asset_dividend = AssetDividend.query.filter_by(asset_id=asset_id).order_by(AssetDividend.created_at.desc())

    if period == 'HOUR':
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(hours=1))
    elif period == '5HOUR':
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(hours=5))
    elif period == 'DAY':
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(days=1))
    elif period == 'WEEK':
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(weeks=1))
    elif period == 'MONTH':
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(days=30))
    else:
        asset_dividend = asset_dividend.filter(AssetDividend.created_at >= datetime.utcnow() - timedelta(days=30))
    
    asset_dividend = asset_dividend.all()


    if period == 'WEEK' and asset_dividend and len(asset_dividend) > 40:
        asset_dividend = asset_dividend[::4]

    shares = PortfolioItem.circulating_user_supply(asset_id)
    return [{'date': div.created_at, 'value':  float(div.USD/shares)} for div in reversed(asset_dividend)]


def calculate_expected_dividends(asset_id):
    asset_payout_percentages = DividendService().asset_payout_percentages()
    specific_asset_payout_percentage = asset_payout_percentages[asset_id]
    market_balance = MarketBalance.current()
    expected_dividends = round(market_balance.quantity * Decimal(specific_asset_payout_percentage) * Decimal(PERCENT_OF_POOL_DISTRIBUTED), 0)
    return expected_dividends
