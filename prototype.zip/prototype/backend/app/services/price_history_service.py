from app.models import LiquidityPool, PriceHistory, Asset    
from datetime import datetime, timedelta
from app.database import db
import traceback

MINUTE = 'minute'

class PriceHistoryService:

    def get_price_history(self, asset_id, period):
        price_histories = PriceHistory.query.filter_by(asset_id=asset_id).order_by(PriceHistory.price_time.desc())

        if period == 'HOUR':
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(hours=1))
        elif period == '5HOUR':
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(hours=5))
        elif period == 'DAY':
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(days=1))
        elif period == 'WEEK':
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(weeks=1))
        elif period == 'MONTH':
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(days=30))
        else:
            price_histories = price_histories.filter(PriceHistory.price_time >= datetime.utcnow() - timedelta(days=30))
        
        price_histories = price_histories.all()

        if period in ['HOUR', '5HOUR', 'DAY'] and price_histories and len(price_histories) > 10:
            price_histories = price_histories[::5]
        elif period == 'WEEK' and price_histories and len(price_histories) > 40:
            price_histories = price_histories[::20]


        return [{'date': ph.price_time, 'value':  float(ph.price)} for ph in reversed(price_histories)]

    def calculate_average_price(self, pools, minute_start, minute_end, last_price):
        sum_prices = 0
        count_pools = 0
        for pool in pools:
            if minute_start < pool.created_at < minute_end:
                sum_prices += pool.exchange_rate()
                count_pools += 1
        return sum_prices / count_pools if count_pools else last_price


    def create_price_history(self, asset_id, time_frequency, price, price_time):
        price_history = PriceHistory(asset_id=asset_id, time_frequency=time_frequency, price=price, price_time=price_time)
        db.session.add(price_history)
        return price_history


    def process_assets(self):
        try:
            current_time = datetime.utcnow()

            for asset in Asset.query.all():
                latest_price = PriceHistory.current(asset_id=asset.id)      
                if latest_price is None:
                    price_time = (datetime.utcnow() - timedelta(minutes=1))
                    latest_price = self.create_price_history(
                        asset_id=asset.id,
                        time_frequency=MINUTE,
                        price=0,
                        price_time=price_time)

                latest_liquidity_pools = LiquidityPool.get_latest_pools_for_asset(asset_id=asset.id, since_timestamp=latest_price.price_time)
                sorted_pools = sorted(latest_liquidity_pools, key=lambda x: x.created_at)

                # print(f'len(sorted_pools) = {len(sorted_pools)}')
                # print(f'latest_price = {latest_price}')
                
                minute_start = latest_price.price_time
                minute_end = minute_start + timedelta(minutes=1)
                last_price_minute = latest_price.price

                while minute_end <= current_time:
                    pools_in_range = [pool for pool in sorted_pools if minute_start < pool.created_at < minute_end]
                    # print(f'len(pools_in_range) = {len(pools_in_range)}')
                    average_price = self.calculate_average_price(pools_in_range, minute_start, minute_end, last_price_minute)
                    # print(f'average_price = {average_price}')
                    
                    self.create_price_history(asset_id=asset.id, time_frequency=MINUTE, price=average_price, price_time=minute_end)

                    last_price_minute = average_price
                    minute_start = minute_end
                    minute_end += timedelta(minutes=1)

            db.session.commit()
        except Exception as e:
            print(f"error in price_history_service: {e}")
            print(f'An error occurred: {e}\n{traceback.format_exc()}')
