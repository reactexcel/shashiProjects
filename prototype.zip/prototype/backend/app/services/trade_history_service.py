from app.models import Transaction, Asset, UserBalance, PortfolioItem, LiquidityPool, Loan
from app.helpers import shorten_number, table_column_set

ASSET_NAME_KEY = 'name'
REALIZED_PROFIT_KEY = 'realized_profit'
REALIZED_ROI_KEY = 'realized_roi'
UNREALIZED_PROFIT_KEY = 'unrealized_profit'
TOTAL_TRADES_KEY = 'total_trades'

TRADE_TYPE_KEY = 'type'
QUANTITY_KEY = 'quantity'
USD_KEY = 'USD'
PRICE_KEY = 'price'
DATE_KEY = 'date'


class TransactionService:

    @staticmethod
    def fetch_user_transactions_and_aggregates(created_since, user_id):
        transactions = TransactionService.fetch_transactions(created_since, user_id)
        transaction_info = TransactionService.populate_trade_info(transactions)
        asset_aggregates_list = TransactionService.update_and_round_aggregates(transactions)
        topline_aggregates = TransactionService.topline_aggregates(user_id=user_id)
        asset_aggregates = {
            'data': asset_aggregates_list,
            'columns': TransactionService.asset_aggregates_columns()
        }
        return { **topline_aggregates, "trade_info": transaction_info, "asset_aggregates": asset_aggregates}
    
    @staticmethod
    def topline_aggregates(user_id):
        balance = UserBalance.current(user_id=user_id)
        net_worth = TransactionService.user_net_worth(user_id=user_id)
        return { 'cash': shorten_number(balance.quantity), 'net_worth': shorten_number(net_worth) }

    @staticmethod
    def user_net_worth(user_id):
        net_worth = 0.0
        items = PortfolioItem.latest_user_asset_pairings_for_user(user_id=user_id)
        pools = LiquidityPool.latest_pools_per_id()
        exchange_rates = {pool.asset_id: pool.exchange_rate() for pool in pools}
        for item in items:
            asset_id = item.asset_id
            quantity = float(item.quantity)
            exchange_rate = float(exchange_rates.get(asset_id, 0))
            net_worth += quantity * exchange_rate
            
        return net_worth
    
    @staticmethod
    def update_and_round_aggregates(transactions):
        asset_aggregates_dict = {}
        asset_aggregates_list = []
        for transaction in transactions:
            asset_id = transaction.asset_id
            if asset_id not in asset_aggregates_dict:
                asset_aggregates_dict[asset_id] = TransactionService.initialize_aggregates(asset_id)
            asset_aggregates_dict[asset_id] = TransactionService.update_aggregates(asset_aggregates_dict[asset_id], transaction)
        for asset_id, data in asset_aggregates_dict.items():
            rounded_data = {k: shorten_number(v, 2) if isinstance(v, float) else v for k, v in data.items()}
            asset_aggregates_list.append({"id": asset_id, "data": rounded_data})
        return asset_aggregates_list
    
    @staticmethod
    def populate_trade_info(transactions):
        transaction_info = {}
        for transaction in transactions:
            asset_id = transaction.asset_id
            if asset_id not in transaction_info:
                transaction_info[asset_id] = {'data': [], 'columns': TransactionService.trade_info_columns()}
            trade_entry = {
                TRADE_TYPE_KEY: transaction.trade_type,
                QUANTITY_KEY: shorten_number(float(transaction.asset_quantity), 2),
                USD_KEY: shorten_number(float(transaction.USD), 2),
                PRICE_KEY: shorten_number(transaction.price, 2),
                DATE_KEY: transaction.created_at
            }
            row = {'data': trade_entry, 'id': transaction.transaction_id}
            transaction_info[asset_id]['data'].insert(0, row)
            TEMP_MAX_LENGTH = 50
            if len(transaction_info[asset_id]['data']) > TEMP_MAX_LENGTH:
                transaction_info[asset_id]['data'].pop()
        return transaction_info
    
    @staticmethod
    def initialize_aggregates(asset_id):
        name = Asset.query.filter_by(id=asset_id).first().name
        return {
            ASSET_NAME_KEY: name,
            REALIZED_PROFIT_KEY: 0.0,
            REALIZED_ROI_KEY: 0.0,
            UNREALIZED_PROFIT_KEY: 0.0,
            TOTAL_TRADES_KEY: 0
        }

    @staticmethod
    def update_aggregates(aggregates, trade):
        aggregates[TOTAL_TRADES_KEY] += 1
        if trade.trade_type == 'buy':
            aggregates[UNREALIZED_PROFIT_KEY] -= float(trade.USD)
        else:  # 'sell'
            aggregates[REALIZED_PROFIT_KEY] += float(trade.USD)

        if aggregates[UNREALIZED_PROFIT_KEY] != 0:
            aggregates[REALIZED_ROI_KEY] = (aggregates[REALIZED_PROFIT_KEY] / abs(aggregates[UNREALIZED_PROFIT_KEY])) * 100
        return aggregates
    
    @staticmethod
    def fetch_transactions(created_since, user_id):
        return Transaction.query.filter(Transaction.created_at > created_since).filter_by(user_id=user_id).all()

    @staticmethod
    def asset_aggregates_columns():
        return [
            table_column_set(key=ASSET_NAME_KEY, label="Asset Traded", type="text"),
            table_column_set(key=REALIZED_PROFIT_KEY, label="Realized Profit", type="currency"),
            table_column_set(key=REALIZED_ROI_KEY, label="Realized ROI", type="percentage"),
            table_column_set(key=UNREALIZED_PROFIT_KEY, label="Unrealized Profit", type="currency"),
            table_column_set(key=TOTAL_TRADES_KEY, label="Total Trades", type="number")
        ]
    
    @staticmethod
    def trade_info_columns():
        return [
            table_column_set(key=TRADE_TYPE_KEY, label="Type", type="text"),
            table_column_set(key=QUANTITY_KEY, label="Quantity", type="number"),
            table_column_set(key=USD_KEY, label="USD", type="currency"),
            table_column_set(key=PRICE_KEY, label="Price", type="currency"),
            table_column_set(key=DATE_KEY, label="Date", type="date")
        ]