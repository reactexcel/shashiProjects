from app.models import LiquidityPool, AssetDividend, Asset, PortfolioItem, AirMeasure, PayoutCycle, AssetInfo
from app.helpers import shorten_number, execute_functions_in_pool, table_column_set
from datetime import datetime, timedelta
from decimal import Decimal
from statistics import mean
from functools import partial
from typing import Union
import logging
from app.constants import (
    NAME_KEY,
    MARKET_CAP_KEY,
    PRICE_KEY,
    PRICE_DIVIDEND_RATIO,
    ONE_HOUR_KEY,
    ONE_DAY_KEY,
    DIVIDENDS_24HR_KEY,
    ONE_DAY_TRADE_VOL_KEY,
    CIRCULATING_SUPPLY_KEY,
    PM_25_KEY,
    PM_25_1HR_KEY,
    PM_25_24HR_KEY,
    PERCENT_IN_LIQUIDITY_POOL_KEY
)



class AssetInfoService:
    
    def __init__(self, asset_id, liquidity_pools=None, circulating_supply=None):
        self._liquidity_pools = liquidity_pools
        self._time_range = None
        self._circulating_supply = circulating_supply
        self.asset_id = asset_id
        self._latest_user_asset_pairings = None


    def save_asset_data(self):
        assets_data_results = self.asset_table_data()
        assets_data = assets_data_results['data']
        asset_id = assets_data_results['id']
        assets_data["asset_name"] = assets_data.pop("name")
        assets_data["latest_price"] = assets_data.pop("price")
        assets_data['asset_id'] = asset_id
        assets_data["one_hour_change"] = assets_data.pop("1h_%")
        assets_data["one_day_change"] = assets_data.pop("24h_%")
        assets_data["pm_25_1hr"] = assets_data.pop("pm_25_1hr_%")
        assets_data["pm_25_24hr"] = assets_data.pop("pm_25_24hr_%")
        assets_data["percent_in_liquidity_pool"] = assets_data.pop("%_in_liquidity_pool")
        assets_data["dividends_24hr"] = assets_data.pop("24h_dividends")
        assets_data["dp_ratio"] = assets_data.pop("pd_ratio")
        AssetInfo.upsert_asset_info(**assets_data)


    def asset_table_data(self):
        asset_name = Asset.query.filter_by(id=self.asset_id).first().name
        latest_price = self.price()
        dp_ratio = self.price_to_dividend_ratio()
        one_hour_change = self.price_change_1hr()
        one_day_change = self.price_change_24hr()
        market_cap = self.market_cap()
        one_day_trade_vol = self.trade_volume()
        dividends_24hr = self.dividends_24hr()
        pm_25 = self.pm_25_latest()
        pm_25_1hr = self.pm_25_1hr_change()
        pm_25_24hr = self.pm_25_24hr_change()
        circulating_supply = self.circulating_supply()
        percent_in_liquidity_pool = self.percent_in_liquidity_pool()

        data = {
            NAME_KEY: asset_name,
            PRICE_KEY: latest_price,
            ONE_HOUR_KEY: one_hour_change,
            ONE_DAY_KEY: one_day_change,
            DIVIDENDS_24HR_KEY: dividends_24hr,
            MARKET_CAP_KEY: market_cap,
            ONE_DAY_TRADE_VOL_KEY: one_day_trade_vol,
            CIRCULATING_SUPPLY_KEY: circulating_supply,
            PM_25_KEY: pm_25,
            PM_25_1HR_KEY: pm_25_1hr,
            PM_25_24HR_KEY: pm_25_24hr,
            PERCENT_IN_LIQUIDITY_POOL_KEY: percent_in_liquidity_pool,
            PRICE_DIVIDEND_RATIO: dp_ratio,
        }
        return { 'data': data, 'id': self.asset_id }


    def res(self):
        high = shorten_number(self.high_price())
        market_cap = shorten_number(self.market_cap())
        trade_vol = shorten_number(self.trade_volume())
        pd_ratio = shorten_number(self.price_to_dividend_ratio())
        low = shorten_number(self.low_price())
        dividends_24hr = shorten_number(self.dividends_24hr())
        data = [
            {'High': high},
            {'Low': low},
            {'P:D Ratio': pd_ratio},
            {'24H Volume':trade_vol},
            {'Market Cap': market_cap},
            {'24H Dividends': dividends_24hr},
        ]
        return data


    def time_range(self):
        if self._time_range is None:
            self._time_range = 'day'
        return self._time_range
    
    def liquidity_pools(self):
        if self._liquidity_pools is None:
            past_day = datetime.utcnow() - timedelta(hours=24)
            self._liquidity_pools = LiquidityPool.query \
                                        .filter(LiquidityPool.created_at >= past_day) \
                                        .filter(LiquidityPool.asset_id == self.asset_id) \
                                        .order_by(LiquidityPool.created_at).all()
        return self._liquidity_pools
    
    def current_pool(self) -> Union[LiquidityPool, None]:
        if len(self.liquidity_pools()) > 0:
            return self.liquidity_pools()[-1]
        else:
            return None
        
    def oldest_pool_within_range(self) -> Union[LiquidityPool, None]:
        if len(self.liquidity_pools()) > 0:
            return self.liquidity_pools()[0]
        else:
            return None

    def price(self):
        current_pool = self.current_pool()
        if current_pool:
            return current_pool.exchange_rate()
        else:
            return 0
    
    def price_close_to_24hr_ago(self):
        oldest_pool_within_range = self.oldest_pool_within_range()
        if oldest_pool_within_range:
            return oldest_pool_within_range.exchange_rate()
        else:
            return 0
    
    def dividends_24hr(self):
        now = datetime.utcnow()
        twenty_four_hours_ago = now - timedelta(hours=24)
        dividends_24hr = AssetDividend.query.filter(AssetDividend.created_at >= twenty_four_hours_ago).filter_by(asset_id=self.asset_id).all()
        total_dividends_24hr = sum([dividend.USD for dividend in dividends_24hr])
        return total_dividends_24hr

    def price_change_1hr(self):
        now = datetime.utcnow()
        one_hour_ago = now - timedelta(hours=1)
        latest_price = self.price()
        one_hour_ago = now - timedelta(hours=1)
        closest_pool_to_1hr_ago = None

        for pool in self.liquidity_pools():
            if one_hour_ago <= pool.created_at <= now:
                closest_pool_to_1hr_ago = pool
                break

        if closest_pool_to_1hr_ago is None:
            return None

        price_change = latest_price - closest_pool_to_1hr_ago.exchange_rate()
        percent_change = (price_change / closest_pool_to_1hr_ago.exchange_rate()) * 100
        return percent_change

    def price_change_24hr(self):
        now = datetime.utcnow()
        twenty_four_hours_ago = now - timedelta(hours=24)
        latest_price = self.price()
        closest_pool_to_24hr_ago = None

        for pool in self.liquidity_pools():
            if twenty_four_hours_ago <= pool.created_at <= now:
                closest_pool_to_24hr_ago = pool
                break

        if closest_pool_to_24hr_ago is None:
            return None

        price_change = latest_price - closest_pool_to_24hr_ago.exchange_rate()
        percent_change = (price_change / closest_pool_to_24hr_ago.exchange_rate()) * 100
        return percent_change


    def latest_user_asset_pairings(self):
        if self._latest_user_asset_pairings is None:
            self._latest_user_asset_pairings = PortfolioItem.latest_user_asset_pairings()
        return self._latest_user_asset_pairings
        

    def circulating_user_supply(self):
        user_supply = 0
        for user_portfolio_item in self.latest_user_asset_pairings():
            if user_portfolio_item.asset_id == self.asset_id:
                user_supply += user_portfolio_item.quantity
        return user_supply
        
            
    def circulating_supply(self):
        if self._circulating_supply is None:
            self._circulating_supply = 0
            self._circulating_supply += self.circulating_user_supply()
            latest_pool = self.current_pool()
            if latest_pool is not None:
                self._circulating_supply += latest_pool.asset_quantity
                    
        return self._circulating_supply
        
    def pm_25_1hr_change(self):
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        latest_air_measure = AirMeasure.current(asset_id=self.asset_id)
        air_measures = AirMeasure.get_latest_for_asset(asset_id=self.asset_id, since_timestamp=one_hour_ago)
        if len(air_measures) == 0: 
            return None
        
        closest_measure = min(air_measures, key=lambda x: abs((x.created_at - one_hour_ago).total_seconds()))
        NON_ZERO_VALUE = Decimal(0.00001)
        pm_25_nearly_1hr_ago = Decimal(closest_measure.pm_25_10_minute) + NON_ZERO_VALUE
        pm_25_change =  Decimal(latest_air_measure.pm_25_10_minute - pm_25_nearly_1hr_ago)
        percent_change = (pm_25_change / pm_25_nearly_1hr_ago) * 100
        return percent_change

    def pm_25_24hr_change(self):
        one_day_ago = datetime.utcnow() - timedelta(hours=24)
        latest_air_measure = AirMeasure.current(asset_id=self.asset_id)
        air_measures = AirMeasure.get_latest_for_asset(asset_id=self.asset_id, since_timestamp=one_day_ago)
        print("air_measures", air_measures)
        if len(air_measures) == 0: 
            return None
        
        closest_measure = min(air_measures, key=lambda x: abs((x.created_at - one_day_ago).total_seconds()))
        NON_ZERO_VALUE = Decimal(0.00001)
        pm_25_nearly_24hr_ago = Decimal(closest_measure.pm_25_10_minute) + NON_ZERO_VALUE
        pm_25_change =  Decimal(latest_air_measure.pm_25_10_minute - pm_25_nearly_24hr_ago)
        percent_change = (pm_25_change / pm_25_nearly_24hr_ago) * 100
        return percent_change


    def pm_25_latest(self):
        air_measure = AirMeasure.current(asset_id=self.asset_id)
        return air_measure.pm_25_10_minute if air_measure is not None else None

    def prices(self):
        return [pool.exchange_rate() for pool in self.liquidity_pools()]

    def high_price(self):
        return max(self.prices()) if self.prices() else None
    def low_price(self):
        return min(self.prices()) if self.prices() else None
    
    def percent_in_liquidity_pool(self):
        latest_pool = self.current_pool()
        if latest_pool is None:
            return 0 
        return latest_pool.asset_quantity / self.circulating_supply() * 100


    def trade_volume(self):
        trade_volume = 0
        previous_USD_quantity = None
        for pool in self.liquidity_pools():
            if previous_USD_quantity is not None:
                trade_volume += abs(pool.USD_quantity - previous_USD_quantity)
            previous_USD_quantity = pool.USD_quantity
        return trade_volume
    
    def market_cap(self):
        return self.circulating_supply() * self.price()

    def market_cap_close_to_24hr_ago(self):
        return self.circulating_supply() * self.price_close_to_24hr_ago()
    
    def price_to_dividend_ratio(self):
        asset_dividend = AssetDividend.query.filter_by(asset_id=self.asset_id).filter_by(payout_cycle_id=PayoutCycle.max_id()).first()
        if asset_dividend is None or asset_dividend.USD == 0 or self.circulating_user_supply() == 0:
            return float('inf')
        
        dividends_per_share = asset_dividend.USD/self.circulating_user_supply()
        return self.price() / dividends_per_share
        
    # UNTESTED
    #TODO improve this by getting the past day or longer data
    def dividend_ranking(self):
        asset_dividends = sorted(AssetDividend.latest_dividends_per_asset(), key=lambda x: x.USD, reverse=True)
        ranking = 0
        previous_usd = None

        for i, asset_dividend in enumerate(asset_dividends):
            if asset_dividend.USD != previous_usd:
                ranking = i + 1
            if asset_dividend.asset_id == self.asset_id:
                break
            previous_usd = asset_dividend.USD
        return ranking
    
def assets_table():
    columns = [
        table_column_set(key=NAME_KEY, label="Name", type="text", isLeftAligned=True, isBold=True),
        table_column_set(key=MARKET_CAP_KEY, label="Market Cap", type="currency", isLeftAligned=False, isBold=True),
        table_column_set(key=PRICE_KEY, label="Price", type="currency", isLeftAligned=False, isBold=True),
        table_column_set(key=ONE_HOUR_KEY, label="1h %", type="percentage", isLeftAligned=False, isBold=True),
        table_column_set(key=ONE_DAY_KEY, label="24h %", type="percentage", isLeftAligned=False, isBold=True),
        table_column_set(key=PRICE_DIVIDEND_RATIO, label="PD Ratio", type="number", isLeftAligned=False),
        table_column_set(key=DIVIDENDS_24HR_KEY, label="24h Dividends", type="currency", isLeftAligned=False),
        table_column_set(key=ONE_DAY_TRADE_VOL_KEY, label="24h Vol", type="currency", isLeftAligned=False),
        table_column_set(key=CIRCULATING_SUPPLY_KEY, label="Circulating Supply", type="number", isLeftAligned=False),
        table_column_set(key=PM_25_KEY, label="Pm2.5", type="number", isLeftAligned=False),
        table_column_set(key=PM_25_1HR_KEY, label="Pm2.5 1h %", type="percentage", isLeftAligned=False, isBold=True),
        table_column_set(key=PM_25_24HR_KEY, label="Pm2.5 24h %", type="percentage", isLeftAligned=False, isBold=True),
        table_column_set(key=PERCENT_IN_LIQUIDITY_POOL_KEY, label="% in LPs", type="percentage", isLeftAligned=False, isBold=True),
    ]
    data = [assetinfo.serialize for assetinfo in AssetInfo.get_latest_asset_infos()]
    return columns, data


def save_asset_info_data():
    def save_asset_table_data(asset_id):
        return AssetInfoService(asset_id=asset_id).save_asset_data()
    
    asset_ids = [asset.id for asset in Asset.query.all()]
    functions_to_execute = [partial(save_asset_table_data, asset_id) for asset_id in asset_ids]
    results = execute_functions_in_pool(functions_to_execute)
    for idx, result in enumerate(results, 1):
        logging.info(f'Result {idx}: {result}')


def liquidity_pools_dict():
    past_day = datetime.utcnow() - timedelta(hours=24)
    lps = LiquidityPool.query \
                            .filter(LiquidityPool.created_at >= past_day) \
                            .order_by(LiquidityPool.created_at).all()
    lps_dict = {}
    for lp in lps:
        if lp.asset_id not in lps_dict:
            lps_dict[lp.asset_id] = []
        lps_dict[lp.asset_id].append(lp)
    return lps_dict

def circulating_supply_dict():
    circulating_supply_dict = {}
    for user_portfolio_item in PortfolioItem.latest_user_asset_pairings():
        if user_portfolio_item.asset_id not in circulating_supply_dict:
            circulating_supply_dict[user_portfolio_item.asset_id] = Decimal(0)
        circulating_supply_dict[user_portfolio_item.asset_id] += user_portfolio_item.quantity
    for lp in LiquidityPool.latest_pools_per_id():
        if lp.asset_id not in circulating_supply_dict:
            circulating_supply_dict[lp.asset_id] = Decimal(0)
        circulating_supply_dict[lp.asset_id] += lp.asset_quantity
    return circulating_supply_dict
