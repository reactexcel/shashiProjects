from app.models import Asset, LiquidityPool
from app.helpers.shorten_number import shorten_number
from app.services.air_measure_service import AirMeasureService


class AssetService:

    @staticmethod
    def get_assets_data():
        asset_names = {}
        for asset in Asset.all():
            asset_names[asset.id] = asset.name

        pm25_by_asset_id = {}
        pm25_by_asset_id = AirMeasureService().get_latest_pm25_by_asset_id()

        assets = []
        for liquidity_pool in LiquidityPool.latest_pools_per_id():
            asset_data = {
                'id': liquidity_pool.asset_id, 
                'name': asset_names[liquidity_pool.asset_id], 
                'price': shorten_number(liquidity_pool.exchange_rate())
            }

            if pm25_by_asset_id:
                asset_data['pm25'] = shorten_number(pm25_by_asset_id.get(liquidity_pool.asset_id, 0))

            assets.append(asset_data)
        return assets
