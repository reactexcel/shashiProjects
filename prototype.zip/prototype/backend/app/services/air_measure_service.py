import traceback
from statistics import mean
from typing import Dict, List
from geopy.distance import geodesic
from dataclasses import dataclass, field
from flask import jsonify
from datetime import datetime, timedelta
from app.models import AirMeasure, AssetRegion, Asset
from app.database import db
from app.services.purple_air_service import PurpleAirService
from app.models import SensorData, PayoutCycle
from decimal import Decimal
from sqlalchemy import func

ROUNDING_PRECISION = 2

@dataclass
class AssetSensorMapping(dict):
    data: Dict[int, List[SensorData]] = field(default_factory=dict)

class AirMeasureService:
    
    def call_and_store_regions_air_data(self):
        for region in AssetRegion.query.all():
            self.call_and_store_region_air_data(region=region)
    
    def call_and_store_region_air_data(self, region: AssetRegion):
        try:
            sensor_datas = PurpleAirService().grab_region_data(region)
            print(f'region id = {region.id}: sensor_datas len = {len(sensor_datas)}')            
            asset_region_data = self.map_sensors_to_regions(sensor_datas, [region])
            air_measure_data = self.average_data(asset_region_data)
            print(f'air_measure_data = {air_measure_data}')            
            db.session.add_all(air_measure_data)
            db.session.commit() 
        except Exception as e:        
            print(f'An error occurred: {e}\n{traceback.format_exc()}')


    # THIS CAN BE CLEANED UP, WE'RE ONLY PASSING ONE ASSETREGION INTO THIS METHOD NOW (ALBIET IN AN ARRAY)
    def map_sensors_to_regions(self, sensor_datas: List[SensorData], asset_regions: List[AssetRegion]) -> AssetSensorMapping:
        asset_region_data = AssetSensorMapping()

        for asset_region in asset_regions:
            asset_region_data.data[asset_region.asset_id] = []
            
        match_count = {region.asset_id: 0 for region in asset_regions}
        for sensor_data in sensor_datas:
            for asset_region in asset_regions:
                  asset_region_data.data[asset_region.asset_id].append(sensor_data)
                  match_count[asset_region.asset_id] += 1
                  break
        return asset_region_data
    
    def is_within_distance(self, point1, point2, threshold_distance):
        distance_to_point1 = geodesic(point1, point2).miles
        return True if distance_to_point1 <= threshold_distance else False

    
    def average_data(self, asset_region_data: AssetSensorMapping) -> List[AirMeasure]:
        air_measures = []
        payout_cycle_id = PayoutCycle.query.order_by(PayoutCycle.id.desc()).first().id
        for asset_id, sensors in asset_region_data.data.items():
            average_pm_25_10_minute = self.aggregate_data(sensors)
            if average_pm_25_10_minute is None:
                print(f'No data for asset_id {asset_id}')
                continue
            air_measures.append(AirMeasure(
                asset_id=asset_id,
                pm_25_10_minute=average_pm_25_10_minute,
                sensor_count=len(sensors),
                payout_cycle_id=payout_cycle_id
            ))
        return air_measures    


    def aggregate_data(self, sensor_datas:List[SensorData]):
        valid_pm25_10_minute_values = [x.pm25_10_minute for x in sensor_datas if x.pm25_10_minute is not None]
        if valid_pm25_10_minute_values:
            return mean(valid_pm25_10_minute_values)
        else:
            return None

    @staticmethod       
    def get_latest_air_measures():
        try:
            subquery = (
                db.session.query(
                    func.max(AirMeasure.id).label("max_id")
                )
                .group_by(AirMeasure.asset_id)
                .subquery()
            )
            latest_airmeasures = (
                db.session.query(AirMeasure)
                .join(subquery, AirMeasure.id == subquery.c.max_id)
                .all()
            )
            return latest_airmeasures
        except Exception as e:
            return None

    def get_latest_pm25_by_asset_id(self):
        air_measures = self.get_latest_air_measures()
        if not air_measures:
            raise ValueError("Failed to fetch latest air measures.")
        asset_pm25_10_minute = {air_measure.asset_id: air_measure.pm_25_10_minute for air_measure in air_measures}
        return asset_pm25_10_minute
    
    @staticmethod
    def get_air_measure_charts_data(asset_id):
        asset = Asset.query.filter_by(id=asset_id).first()
        if asset is None:
            return {'message': f'Asset {asset_id} not found', 'status': 404}
        asset_name = asset.name
        asset_name = Asset.query.filter_by(id=asset_id).first().name
        since_timestamp = datetime.utcnow() - timedelta(days=35)
        air_measures = AirMeasure.get_air_quality_since(asset_id=asset_id, since_timestamp=since_timestamp)
        air_quality_by_hour = AirMeasure.get_air_quality_per_hour(air_measures=air_measures)
        air_quality_by_day = AirMeasure.get_air_quality_per_day_of_week(air_measures=air_measures)
        return {
            'air_quality_by_hour': air_quality_by_hour,
            'air_quality_by_day': air_quality_by_day,
            'asset_name': asset_name,
        }

