from app.models import AssetDividend, AirMeasure, PayoutCycle, LiquidityPool, Asset
from collections import defaultdict
from sqlalchemy import and_
import numpy as np
from typing import List, Dict, Union, Callable
from decimal import Decimal
from app.helpers.parallel import execute_functions_in_pool

def prepare_data_for_dividends_and_price_correlation(payout_cycle_id:int):
    asset_dividends = AssetDividend.query.filter_by(payout_cycle_id=payout_cycle_id).all()
    asset_dividend_next = AssetDividend.query.filter_by(payout_cycle_id=payout_cycle_id+1).first()

    if asset_dividend_next is None or asset_dividends is None or len(asset_dividends) == 0:
      return []
    min_created_at = min([asset.created_at for asset in asset_dividends])
    max_created_at = asset_dividend_next.created_at
    
    liquidity_pools = LiquidityPool.query.filter(
        and_(
            LiquidityPool.created_at >= min_created_at,
            LiquidityPool.created_at <= max_created_at
        )
    ).all()

    USD_KEY = 'USD'
    EXCHANGE_RATE_KEY = 'exchange_rate'

    data = defaultdict(lambda: {USD_KEY: None, EXCHANGE_RATE_KEY: None})

    for asset in asset_dividends:
        data[asset.asset_id][USD_KEY] = asset.USD

    for pool in liquidity_pools:
        data[pool.asset_id][EXCHANGE_RATE_KEY] = pool.exchange_rate()

    return prepare_data(data=data, x_axis_key=EXCHANGE_RATE_KEY, y_axis_key=USD_KEY, cycle_id=payout_cycle_id)

def prepare_data_for_price_and_air_quality_correlation(payout_cycle_id:int):
    air_measures = AirMeasure.query.filter_by(payout_cycle_id=payout_cycle_id).all()
    air_measure_next = AirMeasure.query.filter_by(payout_cycle_id=payout_cycle_id+1).first()

    if air_measure_next is None or air_measures is None or len(air_measures) == 0:
      return []
    min_created_at = min([asset.created_at for asset in air_measures])
    max_created_at = air_measure_next.created_at
    
    liquidity_pools = LiquidityPool.query.filter(
        and_(
            LiquidityPool.created_at >= min_created_at,
            LiquidityPool.created_at <= max_created_at
        )
    ).all()

    PM_25_KEY = 'pm_25_10_minute'
    EXCHANGE_RATE_KEY = 'exchange_rate'

    data = defaultdict(lambda: {PM_25_KEY: None, EXCHANGE_RATE_KEY: None})

    for asset in air_measures:
        data[asset.asset_id][PM_25_KEY] = asset.pm_25_10_minute

    for pool in liquidity_pools:
        data[pool.asset_id][EXCHANGE_RATE_KEY] = pool.exchange_rate()

    return prepare_data(data=data, x_axis_key=PM_25_KEY, y_axis_key=EXCHANGE_RATE_KEY, cycle_id=payout_cycle_id)


def prepare_data_for_air_quality_dividend_correlation(payout_cycle_id: int):
    # Step 1: Join Data
    asset_dividends = AssetDividend.query.filter_by(payout_cycle_id=payout_cycle_id).all()
    air_measures = AirMeasure.query.filter_by(payout_cycle_id=payout_cycle_id).all()

    USD_KEY = 'USD'
    PM_25_KEY = 'pm_25_10_minute'

    data = defaultdict(lambda: {USD_KEY: None, PM_25_KEY: None})

    for asset in asset_dividends:
        data[asset.asset_id][USD_KEY] = asset.USD

    for measure in air_measures:
        data[measure.asset_id][PM_25_KEY] = measure.pm_25_10_minute

    return prepare_data(data=data, x_axis_key=PM_25_KEY, y_axis_key=USD_KEY, cycle_id=payout_cycle_id)


def prepare_data(data, x_axis_key, y_axis_key, cycle_id):
    complete_data = [
        {'x': round(record[x_axis_key], 2), 'y': round(record[y_axis_key], 2), 'assetId': asset_id, 'cycleId': cycle_id }
        for asset_id, record in data.items() 
        if record[x_axis_key] is not None and record[y_axis_key] is not None
    ]
    
    if not complete_data:
        print(f'Empty data for cycle_id = {cycle_id}')
        return []
    
    return complete_data

# Input: [(X, Y, asset_id, ...)]
def correlate(data: List[Dict[str, Union[Decimal, int]]]) -> Union[float, None]:
    if data is None or len(data) == 0:
        print('empty data input in correlate()')
        return None
    # Step 2: Calculate Min-Max
    min_usd = min([x['x'] for x in data])
    max_usd = max([x['x'] for x in data])
    min_pm = min([x['y'] for x in data])
    max_pm = max([x['y'] for x in data])

    # Step 3: Normalize Data
    normalized_data = [( (row['x'] - min_usd) / (max_usd - min_usd), (row['y'] - min_pm) / (max_pm - min_pm) ) for row in data]

    # Step 4: Calculate Correlation
    x_values = np.array([float(x) for x, y in normalized_data], dtype=float)
    y_values = np.array([float(y) for x, y in normalized_data], dtype=float)

    corr = np.corrcoef(x_values, y_values)[0, 1]
    return corr

class CorrelationService():
    
    @staticmethod
    def get_correlations() -> dict:

        functions = [ 
            CorrelationService.get_price_and_air_measure_data, 
            CorrelationService.get_air_measure_and_dividends_data, 
            CorrelationService.get_dividends_and_price_data 
        ]
        price_to_air_measure_data, dividend_to_air_measure_data, dividend_to_price_data = execute_functions_in_pool(functions)

        return {
            'air_measure_data': dividend_to_air_measure_data,
            'dividend_to_price_data': dividend_to_price_data,
            'price_to_air_measure_data': price_to_air_measure_data
        }

    @staticmethod
    def get_price_and_air_measure_data():
        return CorrelationService._prepare_scatter_chart_data(
            payout_cycles_id=CorrelationService._get_payout_cycles_id(hours=2), 
            prepare_data_func=prepare_data_for_price_and_air_quality_correlation, 
            correlate_func=correlate,
            y_axis_label="Price",
            x_axis_label="PM2.5"
        )

    @staticmethod
    def get_dividends_and_price_data():
        return CorrelationService._prepare_scatter_chart_data(
            payout_cycles_id=CorrelationService._get_payout_cycles_id(hours=2), 
            prepare_data_func=prepare_data_for_dividends_and_price_correlation, 
            correlate_func=correlate,
            y_axis_label="Dividends",
            x_axis_label="Price"
        )

    @staticmethod
    def get_air_measure_and_dividends_data():
        return CorrelationService._prepare_scatter_chart_data(
            payout_cycles_id=CorrelationService._get_payout_cycles_id(hours=2),
            prepare_data_func=prepare_data_for_air_quality_dividend_correlation,
            correlate_func=correlate,
            y_axis_label="Dividends",
            x_axis_label="PM2.5"
        )


    def run(self):
        payout_cycles_id = CorrelationService._get_payout_cycles_id(hours=2)

        correlations = []
        for payout_cycle_id in payout_cycles_id:
            # data = prepare_data_for_dividends_and_price_correlation(payout_cycle_id)
            data = prepare_data_for_air_quality_dividend_correlation(payout_cycle_id)
            correlations.append(correlate(data))
        
        CorrelationService.get_air_measure_and_dividends_data()
        CorrelationService.get_dividends_and_price_data()

    
    @staticmethod
    def _prepare_scatter_chart_data(payout_cycles_id: List[int], prepare_data_func: Callable, correlate_func: Callable, x_axis_label: str, y_axis_label: str):
        data_points = []
        for payout_cycle_id in payout_cycles_id:
            row = prepare_data_func(payout_cycle_id=payout_cycle_id)
            if row is not None:
                data_points += row

        # Calculating correlation from data_points
        correlation_value = correlate_func(data=data_points)

        # Prepare final data structure
        result = {
            "xAxis": x_axis_label,
            "yAxis": y_axis_label,
            "assets": {asset.id: asset.name for asset in Asset.query.all()},
            "data": data_points,
            "correlation": round(correlation_value, 3) if correlation_value is not None else 0
        }
        return result
    
    @staticmethod
    def _get_payout_cycles_id(hours=2):
        from datetime import datetime, timedelta
        last_day = datetime.utcnow() - timedelta(hours=hours)
        payout_cycles_id = [payout_cycle.id for payout_cycle in PayoutCycle.query.filter(PayoutCycle.created_at >= last_day).all()]
        return payout_cycles_id
