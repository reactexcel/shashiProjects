from math import isclose
from app.database import db
from app.models import LiquidityPool, PortfolioItem, UserBalance, MarketBalance, LiquidityHolding, Pool, Transaction
import traceback
from decimal import Decimal

class LiquidityService:
  def buy(self, pool_id, user_id, USD_in, asset_id, commit=True):
    try:
      if USD_in <= 0: 
          raise ValueError("USD_in must be greater than 0 to proceed with the buy operation.")
      if pool_id is None:
        pool_id = Pool.get_pool_id_for_asset(asset_id=asset_id)
      
      # print(f"IN liquidity_service.buy: pool_id = {pool_id}, user_id = {user_id}, USD_in = {USD_in}, asset_id = {asset_id}")
      asset_quantity_acquired, transaction_fee = LiquidityPool.swap_for_asset(pool_id=pool_id, USD_in=USD_in)
      UserBalance.withdraw(user_id=user_id, quantity=USD_in)

      pi = PortfolioItem.deposit(
        user_id=user_id, 
        asset_id=asset_id,
        asset_quantity=asset_quantity_acquired,
      )

      MarketBalance.deposit(quantity=transaction_fee)
      if self.state_is_as_expected(asset_id=asset_id, user_id=user_id, buy=True, USD_in=USD_in, USD_acquired=0):
          if commit:
              db.session.commit()
              transaction = Transaction(
                asset_id=asset_id,
                asset_quantity=asset_quantity_acquired,
                USD=USD_in,
                user_id=user_id,
                price=USD_in/asset_quantity_acquired,
                fee=transaction_fee, 
                trade_type='BUY',
                associated_record_type='portfolio_item',
                associated_record_id=pi.id
              )
              db.session.add(transaction)
      else:
          db.session.rollback()
          print(f"BUY Transaction rolled back due to state inconsistency (in sell asset_id = {asset_id}, user_id = {user_id}, asset_quantity_acquired = {asset_quantity_acquired}).")
      return asset_quantity_acquired
    except Exception as e:
      db.session.rollback()
      print(f'An error occurred: {e}\n{traceback.format_exc()}')
      raise e


  def sell(self, pool_id, user_id, asset_id, asset_quantity, commit=True):
      try:
          if asset_quantity <= 0:
             return
          if pool_id is None:
              pool_id = Pool.get_pool_id_for_asset(asset_id=asset_id)
      
          liquidity_pool_asset_quantity = LiquidityPool.current(pool_id=pool_id).asset_quantity
          if liquidity_pool_asset_quantity < asset_quantity:
             print(f"IN liquidity_service.sell: asset_quantity = {asset_quantity} > liquidity_pool_asset_quantity {liquidity_pool_asset_quantity} ")
             return 0
          USD_acquired = LiquidityPool.swap_for_USD(pool_id, asset_quantity)
          UserBalance.deposit(user_id=user_id, quantity=USD_acquired)
          pi = PortfolioItem.withdraw(
              user_id=user_id,
              asset_id=asset_id,
              asset_quantity=asset_quantity,
          )
          if self.state_is_as_expected(asset_id=asset_id, user_id=user_id, buy=False, USD_in=0, USD_acquired=USD_acquired):
              if commit:
                  db.session.commit()
                  transaction = Transaction(
                    asset_id=asset_id,
                    asset_quantity=asset_quantity,
                    USD=USD_acquired,
                    user_id=user_id,
                    price=USD_acquired/asset_quantity,
                    fee=0, 
                    trade_type='SELL',
                    associated_record_type='portfolio_item',
                    associated_record_id=pi.id
                  )
                  db.session.add(transaction)
                  db.session.commit()
                  # print("Transaction committed.")
              return USD_acquired
          else:
              db.session.rollback()
              print(f"SELL Transaction rolled back due to state inconsistency (in sell asset_id = {asset_id}, user_id = {user_id}, asset_quantity = {asset_quantity}).")
              return 0
      except Exception as e:
          db.session.rollback()
          print(f'An error occurred: {e}\n{traceback.format_exc()}')
          raise e 

  def add_liquidity(self, pool_id, asset_id, user_usd, user_asset_quantity, user_id):
    try:
      if user_usd > 0 and user_asset_quantity > 0:
        raise Exception('Must deposit USD or asset')
      if user_usd > 0:
        UserBalance.withdraw(user_id=user_id, quantity=user_usd,)
      elif user_asset_quantity > 0:
        PortfolioItem.withdraw(
          user_id=user_id, 
          asset_quantity=user_asset_quantity,
          asset_id=asset_id,
        )
      _, liquidity_tokens_issued = LiquidityPool.current(pool_id).add_liquidity(
        USD_deposit=user_usd, 
        asset_deposit=user_asset_quantity,
      )
      LiquidityHolding.deposit(
        pool_id=pool_id,
        user_id=user_id, 
        asset_quantity=liquidity_tokens_issued, 
        asset_id=asset_id,
      )
      db.session.commit()
      return liquidity_tokens_issued
    except Exception as e:
        db.rollback()
        raise e

  def state_is_as_expected(self, user_id, asset_id, buy, USD_in, USD_acquired, debugging=False):
    if debugging is False:
       return True
    # For LiquidityPool
    two_latest_lp = LiquidityPool.query.filter_by(asset_id=asset_id).order_by(LiquidityPool.id.desc()).limit(2).all()
    latest_lp, second_latest_lp = two_latest_lp[0], two_latest_lp[1] if len(two_latest_lp) > 1 else None

    # For UserBalance
    two_latest_ub = UserBalance.query.filter_by(user_id=user_id).order_by(UserBalance.id.desc()).limit(2).all()
    latest_ub, second_latest_ub = two_latest_ub[0], two_latest_ub[1] if len(two_latest_ub) > 1 else None

    # For MarketBalance
    two_latest_mb = MarketBalance.query.order_by(MarketBalance.id.desc()).limit(2).all()
    latest_mb, second_latest_mb = two_latest_mb[0], two_latest_mb[1] if len(two_latest_mb) > 1 else None

    # For PortfolioItem
    two_latest_pi = PortfolioItem.query.filter_by(user_id=user_id, asset_id=asset_id).order_by(PortfolioItem.id.desc()).limit(2).all()
    latest_pi, second_latest_pi = two_latest_pi[0], two_latest_pi[1] if len(two_latest_pi) > 1 else None

    # Check the first condition with absolute values
    latest_lp_USD_quantity = latest_lp.USD_quantity if latest_lp is not None else 0
    second_latest_lp_USD_quantity = second_latest_lp.USD_quantity if second_latest_lp is not None else 0
    latest_ub_quantity = latest_ub.quantity if latest_ub is not None else 0
    second_latest_ub_quantity = second_latest_ub.quantity if second_latest_ub is not None else 0
    latest_mb_quantity = latest_mb.quantity if latest_mb is not None else 0
    second_latest_mb_quantity = second_latest_mb.quantity if second_latest_mb is not None else 0
    
    latest_lp_asset_quantity = latest_lp.asset_quantity if latest_lp is not None else 0
    second_latest_lp_asset_quantity = second_latest_lp.asset_quantity if second_latest_lp is not None else 0
    latest_pi_quantity = latest_pi.quantity if latest_pi is not None else 0
    second_latest_pi_quantity = second_latest_pi.quantity if second_latest_pi is not None else 0


    lp_usd_diff = Decimal(abs(latest_lp_USD_quantity - second_latest_lp_USD_quantity))
    ub_usd_diff = Decimal(abs(latest_ub_quantity - second_latest_ub_quantity))
    tx_fee_diff = Decimal(abs(latest_mb_quantity - second_latest_mb_quantity) if buy else Decimal(0))
    # print(f"Invariant violated: Mismatch between LiquidityPool and UserBalance. {lp_usd_diff} + {tx_fee_diff} != {ub_usd_diff}")
    if not isclose(lp_usd_diff + tx_fee_diff, ub_usd_diff, rel_tol=1e-9):
        print(f"Invariant violated: Mismatch between LiquidityPool and UserBalance. {lp_usd_diff} + {tx_fee_diff} != {ub_usd_diff}")
        print(f"USD_in = {USD_in}")
        print(f"USD_acquired = {USD_acquired}")
        print(f"latest_lp = {latest_lp}")
        print(f"second_latest_lp = {second_latest_lp}")
        print(f"latest_ub = {latest_ub}")
        print(f"second_latest_ub = {second_latest_ub}")
        return False

    # Check the second condition with absolute values
    lp_asset_diff = Decimal(abs(latest_lp_asset_quantity - second_latest_lp_asset_quantity))
    pi_asset_diff = Decimal(abs(latest_pi_quantity - second_latest_pi_quantity))
    if not isclose(lp_asset_diff, pi_asset_diff, rel_tol=1e-9):
        print(f"Invariant violated: Mismatch between PortfolioItem and LiquidityPool. {lp_asset_diff} != {pi_asset_diff}")
        print(f"USD_in = {USD_in}")
        print(f"USD_acquired = {USD_acquired}")
        print(f"latest_lp = {latest_lp}")
        print(f"second_latest_lp = {second_latest_lp}")
        print(f"latest_pi = {latest_pi}")
        print(f"second_latest_pi = {second_latest_pi}")
        return False

    return True
  
  def get_liquidity_pool(self, asset_id):
    try:
      liquidity_pool = LiquidityPool.query.filter_by(asset_id=asset_id).first()
      if not liquidity_pool:
        raise ValueError(f'Liquidity pool with id {asset_id} not found')
    except Exception as error:
      raise error
    
    return liquidity_pool