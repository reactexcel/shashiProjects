import datetime
from flask import Blueprint, jsonify, request, Response, stream_with_context
from app.schemas.simulation_schemas import SimulationSchema
from webargs.flaskparser import use_args
import tempfile
from werkzeug.utils import secure_filename
import os
from app.helpers.security_scanner import scan_with_bandit
from app.simulations.simulation import simulate
import json
import logging
import traceback


simulation_bp = Blueprint('simulation_routes', __name__)


@simulation_bp.route('/simulation', methods=['POST'])
def simulation():
    try:
        strategies = []
        traders = json.loads(request.form.get('traders', '{}'))
        pm25_data = json.loads(request.form.get('pm25_data', '{}'))
        loan_deposits = json.loads(request.form.get('loan_deposits', '{}'))

        files = extract_files_from_request(request=request)

        with tempfile.TemporaryDirectory() as temp_dir:
            if not files:
                temp_dir = None
            elif files:
                for file in files:
                    file_path = process_file_and_return_path(file, temp_dir)
                    strategies.append(file_path)
                    try:
                        scan_with_bandit(file_path)
                    except Exception as e:
                        raise e

            def generate():
                for data in simulate(pm25_data=pm25_data, traders=traders, temp_dir=temp_dir, loan_deposits=loan_deposits):
                    yield f"{json.dumps(data)}\n\n".encode('utf-8')
            return Response(stream_with_context(generate()), mimetype='text/event-stream')
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in get_user_assets route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@simulation_bp.route('/simulation-demo', methods=['GET'])
def simulation_demo():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    path_components = current_directory.split('/')
    backend_directory = '/'.join(path_components[:-2])
    print(backend_directory)
    try:
        with open(f'{backend_directory}/traders_data_cpy.json', 'r') as json_file:
            traders = json.load(json_file)
        
        with open(f'{backend_directory}/pm25_data_cpy.json', 'r') as json_file:
            pm25_data = json.load(json_file)

        loan_deposits = {}
        temp_dir=None

        def generate():
            for data in simulate(pm25_data=pm25_data, traders=traders, temp_dir=temp_dir, loan_deposits=loan_deposits):
                end_result = json.loads(json.dumps(data))
                if type(end_result) == str:
                    end_ressult = '{"endResult": ' + end_result.replace("'", '"') + "}"
                    yield f"{json.dumps(json.loads(end_ressult))}".encode('utf-8')
                else:
                    data = str(data).replace("'", '"')
                    yield f"{json.loads(json.dumps(data))}\n\n".encode('utf-8')
        return Response(stream_with_context(generate()), mimetype='text/event-stream')
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in get_user_assets route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


def process_file_and_return_path(file, dir):
    filename = secure_filename(file.filename)
    file_path = os.path.join(dir, filename)
    file.save(file_path)
    return file_path


def extract_files_from_request(request):
    files = request.files
    if 'strategies' not in files:
        return None
    strategy_files = files.getlist('strategies')
    if not strategy_files:
        return None
    if len(strategy_files) == 1 and strategy_files[0].filename == '':
        return None
    return strategy_files
