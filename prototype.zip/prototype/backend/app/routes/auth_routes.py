from flask import Blueprint, jsonify, request
import logging

from app.database import db
from app.models.Profile import Profile
from app.models.UserBalance import UserBalance

INITIAL_BALANCE = 10000000

logging.basicConfig(level=logging.DEBUG)

auth_bp = Blueprint('auth_routes', __name__)


@auth_bp.route('/auth', methods=['POST'])
def handle_auth0_new_user():
    try:
        data = request.get_json()
        user_exists = Profile.query.filter_by(email=data['email']).first()
        if user_exists:
            return jsonify({'message': 'User exists'}), 200
        profile = Profile(name=data['name'], email=data['email'], auth0_user_id=data['user_id'])
        db.session.add(profile)
        db.session.flush()
        UserBalance.deposit(profile.id, INITIAL_BALANCE)
        db.session.commit()
        return jsonify({'message': 'User created successfully'})
    except Exception as e:
        db.session.rollback()
        logging.error(f"Unexpected error in handle_auth0_new_user: {str(e)}")
        return jsonify({'message': "An unexpected error occurred on server side"}), 500