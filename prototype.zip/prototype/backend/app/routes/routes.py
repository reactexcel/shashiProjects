from flask import Blueprint, jsonify
from app.routes.trade_routes import trades_bp
from app.routes.market_routes import market_bp
from app.services import PriceHistoryService, AssetInfoService 
from app.services.dividend_service import get_dividend_per_share_history
from app.models import Asset
from webargs.flaskparser import use_args
from marshmallow import Schema, fields, validate
import logging
import traceback
from app.routes.auth_helpers import requires_auth
from app.routes.auth_routes import auth_bp
from app.routes.simulation_routes import simulation_bp
from app.redis_client import redis_client
import json

routes_bp = Blueprint('routes', __name__)

@routes_bp.route('/')
def home():
    return jsonify(message="🐻‍❄️")


class PriceHistorySchema(Schema):
    asset_id = fields.Int(required=True)
    period = fields.Str(required=True, validate=validate.OneOf(["HOUR", "5HOUR", "DAY", "WEEK", "MONTH"]))


@routes_bp.route('/dividend_history', methods=['GET'])
@use_args(PriceHistorySchema(), location='query')
def dividends_history_route(args):
    try:
        asset_id = args['asset_id']
        cache_key = f"dividend_history:{asset_id}:{args['period']}"
        cached_dividend_history = redis_client.get(cache_key)
        if cached_dividend_history:
            dividend_history = json.loads(cached_dividend_history)
        else:
            dividend_history = get_dividend_per_share_history(
                asset_id=asset_id,
                period=args['period']
            )
        return jsonify({'message': 'Dividend history fetched successfully', 'dividendHistory': dividend_history})
    except ValueError as ve:
        logging.error(f"ValueError in dividend_history_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in dividend_history_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@routes_bp.route('/price_history', methods=['GET'])
@use_args(PriceHistorySchema(), location='query')
def price_history_route(args):
    try:
        asset_id = args['asset_id']
        cache_key = f"price_history:{asset_id}:{args['period']}"
        cached_price_history = redis_client.get(cache_key)
        if cached_price_history:
            price_history = json.loads(cached_price_history)
        else:
            price_history = PriceHistoryService().get_price_history(
                asset_id=asset_id,
                period=args['period']
            )
        name = Asset.query.filter_by(id=asset_id).first().name
        return jsonify({'message': 'Price history fetched successfully', 'priceHistory': price_history, 'assetName': name})
    except ValueError as ve:
        logging.error(f"ValueError in price_history_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in price_history_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@routes_bp.route('/asset', methods=['GET'])
@use_args(PriceHistorySchema(), location='query')
def asset_info_route(args):
    try:
        asset_id = args['asset_id']
        cache_key = f"asset_info:{asset_id}:{args['period']}"
        cached_asset_info = redis_client.get(cache_key)
        if cached_asset_info:
            asset_info = json.loads(cached_asset_info)
        else:
            asset_info = AssetInfoService(asset_id).res()
        return jsonify({'message': 'Asset Info fetched successfully', 'data': asset_info})
    except ValueError as ve:
        logging.error(f"ValueError in asset_info_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in asset_info_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


def register_all_routes(app):
    app.register_blueprint(auth_bp)
    app.register_blueprint(routes_bp)
    app.register_blueprint(trades_bp)
    app.register_blueprint(market_bp)
    app.register_blueprint(simulation_bp)

