import json
import six
from jwt import decode
from flask import  request, _request_ctx_stack, jsonify
from functools import wraps

import logging
import base64

import cryptography.x509
import cryptography.hazmat.backends
import cryptography.hazmat.primitives.serialization


AUTH0_DOMAIN = "dev-bbhs6iyj1zc2s7gz.us.auth0.com"
API_IDENTIFIER = 'https://pbetest.onrender.com/'
ALGORITHMS = ["RS256"]
API_AUDIENCE = "CYOwKnqHBC1e0CdcOhmfonuOzrn5TgY1"


def decode_token(token):
    # Extract the header and payload from the JWT
    _, payload, _ = token.split('.')
    # Decode the header and payload
    decoded_payload = base64.urlsafe_b64decode(payload + '==').decode('utf-8')
    return decoded_payload


def public_key_from_auth0():
    jwks_url = f"https://{AUTH0_DOMAIN}/.well-known/jwks.json"
    jwks = json.loads(six.moves.urllib.request.urlopen(jwks_url).read())
    # Convert the x5c entry in the JWKS to a PEM-encoded certificate
    x5c = jwks["keys"][0]['x5c'][0]
    
    cert_str = f"-----BEGIN CERTIFICATE-----\n{x5c}\n-----END CERTIFICATE-----"
    
    # Extract the public key from the certificate
    certificate = cryptography.x509.load_pem_x509_certificate(cert_str.encode('utf-8'), cryptography.hazmat.backends.default_backend())
    public_key = certificate.public_key()

    # Convert to PEM
    pem = public_key.public_bytes(
        encoding=cryptography.hazmat.primitives.serialization.Encoding.PEM,
        format=cryptography.hazmat.primitives.serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return pem

def extract_token_from_header():
    auth = request.headers.get("Authorization", None)
    if not auth:
        raise Exception({"code": "authorization_header_missing", "description": "Authorization header is expected"}, 401)
    parts = auth.split()
    if parts[0].lower() != "bearer" or len(parts) == 1 or len(parts) > 2:
        raise Exception({"code": "invalid_header", "description": "Authorization header must be Bearer token"}, 401)
    return parts[1]


def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        token = auth_header.split(' ')[-1] if auth_header else None
        public_key = public_key_from_auth0()
        try:
            if token:
                decoded_token = decode(
                        token,
                        public_key,
                        algorithms=ALGORITHMS,
                        audience=API_AUDIENCE,
                        issuer="https://"+AUTH0_DOMAIN+"/"
                    )
                _request_ctx_stack.top.current_user = decoded_token
                request.meta_auth0_user_id = decoded_token.get('sub')
            else:
                raise Exception({"code": "authorization_header_missing", "description": "Authorization header is expected"})
        except Exception as err:
            print(f"Failed to Decode JWT token: {err}")
            logging.info("JWT Validation Error", exc_info=1)
            return jsonify({'message': 'Unauthorized to access this resource'}), 401
        return f(*args, **kwargs)
    return decorated
