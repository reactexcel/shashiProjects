from authlib.integrations.flask_oauth2 import ResourceProtector
from app.routes.validator import Auth0JWTBearerTokenValidator

# Initialize ResourceProtector
require_auth = ResourceProtector()

# Initialize Validator
validator = Auth0JWTBearerTokenValidator(
    "dev-bbhs6iyj1zc2s7gz.us.auth0.com",
    "https://pbetest.onrender.com/"
)

# Register the validator
require_auth.register_token_validator(validator)
