from flask import Blueprint, jsonify, request
from app.services import LiquidityService, TransactionService, UserBalanceService, PortfolioService, LeaderboardService

from decimal import Decimal
from webargs.flaskparser import use_args
from marshmallow import Schema, fields
from app.models import LiquidityPool, Profile, PortfolioItem, Pool, Asset
from datetime import datetime
from app.schemas.trade_schemas import BuySchema, SellSchema, AddLiquiditySchema
from app.routes.auth_helpers import requires_auth
import logging
import traceback
from app.helpers.error_handler import handle_error
from app.redis_client import redis_client
import json


trades_bp = Blueprint('trade_routes', __name__)


class TransactionInfoSchema(Schema):
    transactions_since = fields.Int(required=True)
    user_id = fields.Int(required=True)


@trades_bp.route('/transaction_info', methods=['GET'])
@use_args(TransactionInfoSchema(), location='query')
def transaction_info_route(args):
    try:
        timestamp = args['transactions_since']
        created_since_datetime = datetime.fromtimestamp(timestamp)
        data = TransactionService.fetch_user_transactions_and_aggregates(
            created_since=created_since_datetime,
            user_id=args['user_id']
        )
        return jsonify({'message': 'Transaction information retrieved successfully', 'data': data})
    except ValueError as ve:
        logging.error(f"ValueError in transaction_info_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in transaction_info_route: {str(e)}")
        tb_str = traceback.format_exc()
        logging.error(f"Traceback: {tb_str}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


# @require_auth
@trades_bp.route('/add_liquidity', methods=['POST'])
@use_args(AddLiquiditySchema(), location='json')
@requires_auth
def add_liquidity(args):
    try:
        liquidity_tokens_acquired = LiquidityService().add_liquidity(
            pool_id=args['pool_id'],
            asset_id=args['asset_id'],
            user_usd=Decimal(args['user_usd']),
            user_asset_quantity=Decimal(args['asset_quantity']),
            user_id=args['user_id']
        )
        return jsonify({'message': 'Add liquidity executed successfully', 'liquidity_tokens_acquired': liquidity_tokens_acquired})
    except ValueError as ve:
        logging.error(f"ValueError in add_liquidity route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in add_liquidity route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@trades_bp.route('/balance', methods=['GET'])
@requires_auth
def get_user_balance():
    try:
        auth0_user_id = request.meta_auth0_user_id
        user_balance = UserBalanceService(auth0_user_id).get_user_balance()
        return jsonify({'message': 'User balance retrieved successfully', 'balance': user_balance})
    except Exception as e:
        logging.error(f"Unexpected error in get_user_balance route: {str(e)}")
        return jsonify({'message': 'An unexpected error occurred when getting user balance'}), 500


@trades_bp.route('/buy', methods=['POST'])
@use_args(BuySchema(), location='json')
@requires_auth
def buy_route(args):
    try:
        auth0_user_id = request.meta_auth0_user_id
        asset_id = args['asset_id']
        user_id = Profile.query.filter_by(
            auth0_user_id=auth0_user_id).first().id
        asset_quantity_acquired = LiquidityService().buy(
            pool_id=None,
            asset_id=asset_id,
            USD_in=Decimal(args['amount_in']),
            user_id=user_id
        )
        return jsonify({'message': 'Buy executed successfully', 'asset_quantity_acquired': asset_quantity_acquired})
    except ValueError as ve:
        logging.error(f"ValueError in buy_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in buy_route: {str(e)}")
        print(f"Unexpected error in buy_route: {str(e)}")
        tb_str = traceback.format_exc()
        logging.error(f"Traceback: {tb_str}")
        print(f"Traceback: {tb_str}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@trades_bp.route('/sell', methods=['POST'])
@use_args(SellSchema(), location='json')
@requires_auth
def sell_route(args):
    try:
        auth0_user_id = request.meta_auth0_user_id
        asset_id = args['asset_id']
        user_id = Profile.query.filter_by(
            auth0_user_id=auth0_user_id).first().id
        pool_id = Pool.get_pool_id_for_asset(asset_id=asset_id)
        USD_acquired = LiquidityService().sell(
            user_id=user_id,
            asset_id=asset_id,
            pool_id=pool_id,
            asset_quantity=Decimal(args['asset_quantity'])
        )
        return jsonify({'message': 'Sell executed successfully', 'USD_acquired': USD_acquired})
    except ValueError as ve:
        logging.error(f"ValueError in buy_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in buy_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@trades_bp.route('/users/assets/<int:asset_id>', methods=['GET'])
@requires_auth
def get_user_assets(asset_id):
    try:
        auth0_user_id = request.meta_auth0_user_id
        user_id = Profile.query.filter_by(
            auth0_user_id=auth0_user_id).first().id
        assets = PortfolioItem.get_latest_portfolio_item(
            asset_id=asset_id, user_id=user_id)
        if assets is None:
            return jsonify({'message': 'User has no assets of this type', 'assets': 0})
        return jsonify({'message': 'User assets retrieved successfully', 'assets': assets.quantity})
    except ValueError as ve:
        logging.error(f"ValueError in get_user_assets route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in get_user_assets route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500


@trades_bp.route('/portfolio/<int:user_id>', methods=['GET'])
def get_user_portfolio(user_id):
    try:
        cached_portfolio = redis_client.get(f'portfolio:{user_id}')
        if cached_portfolio:
            portfolio = json.loads(cached_portfolio)
        else:
            portfolio = PortfolioService.get_user_portfolio(user_id)
        return portfolio

    except ValueError as ve:
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        return PortfolioService.handle_error(e)


@trades_bp.route('/portfolio', methods=['GET'])
@requires_auth
def get_user_portfolio_route():
    try:
        auth0_user_id = request.meta_auth0_user_id
        cached_profile = redis_client.get('profiles_cache')
        if cached_profile:
            user = json.loads(cached_profile)
            user = next(
                (item for item in user if item["auth0_user_id"] == auth0_user_id), None)
            user_id = user['id']
        else:
            user = Profile.query.filter_by(auth0_user_id=auth0_user_id).first()
            user_id = user.id
        
        cached_portfolio = redis_client.get(f'portfolio:{user_id}')
        if cached_portfolio:
            portfolio = json.loads(cached_portfolio)
        else:
            portfolio = PortfolioService.get_user_portfolio(user_id)
        return portfolio

    except ValueError as ve:
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        return PortfolioService.handle_error(e)


@trades_bp.route('/leaderboard', methods=['GET'])
def get_leaderboard():
    try:
        cached_leaderboard = redis_client.get('leaderboard_cache')
        if cached_leaderboard:
            print('Using cached leaderboard')
            leaderboard = json.loads(cached_leaderboard)
        else:
            leaderboard = LeaderboardService.get_leaderboard_data()
        return jsonify({'leaderboard': leaderboard})
    except Exception as e:
        return handle_error(e)