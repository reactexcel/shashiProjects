from flask import Blueprint, jsonify
from app.services.asset_info_service import assets_table
from app.services.market_info_service import market_info
from app.services.air_measure_service import AirMeasureService
from app.services.correlation_service import CorrelationService
from app.services.dividend_service import calculate_expected_dividends
from app.services import AssetService, AirMeasureService
from app.models import Asset, LiquidityPool, MarketBalance, AirMeasure
from app.helpers.shorten_number import shorten_number
from app.routes.auth_helpers import requires_auth
from app.redis_client import redis_client
from webargs.flaskparser import use_args
from marshmallow import Schema, fields
from decimal import Decimal
from datetime import datetime, timedelta
import logging
import traceback
import json

logging.basicConfig(level=logging.DEBUG)

market_bp = Blueprint('market_routes', __name__)

# UNTESTED
@market_bp.route('/expected_next_dividend_pool', methods=['GET'])
def expected_dividends_route():
    try:
        market_balance = MarketBalance.current()
        expected_dividends = round(market_balance.quantity * Decimal(0.01), 0)
        return jsonify({'message': 'Market Info fetched successfully', 'expected_dividends': expected_dividends})
    except ValueError as ve:
        logging.error(f"ValueError in expected_dividends_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in market_balance_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500
    

@market_bp.route('/next_dividend/<int:asset_id>', methods=['GET'])
def next_dividend_route(asset_id):
    try:
        cached_dividend = redis_client.get(f"expected_dividend:{asset_id}") # type: ignore
        if cached_dividend:
            next_dividend = json.loads(cached_dividend)
        else:
            next_dividend = calculate_expected_dividends(asset_id=asset_id)
        return jsonify({'message': 'Dividend Info fetched successfully', 'next_dividend': next_dividend})
    except ValueError as ve:
        logging.error(f"ValueError in next_dividend_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400


# UNTESTED
@market_bp.route('/market_overview', methods=['GET'])
def market_overview_route():
    try:        
        cached_market_overview = redis_client.get("market_overview_cache") # type: ignore
        if cached_market_overview:
            data = json.loads(cached_market_overview)
        else:
            data = market_info()
        return jsonify({'message': 'Market Info fetched successfully', 'data': data})
    except ValueError as ve:
        logging.error(f"ValueError in market_overview_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in market_overview_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500

# UNTESTED
@market_bp.route('/correlations', methods=['GET'])
@requires_auth
def correlations_route():
    try:
        correlation_data = CorrelationService.get_correlations()
        return jsonify({
            'message': 'Correlations data fetched successfully',
            **correlation_data
        })
    except ValueError as ve:
        logging.error(f"ValueError in correlations_route: {str(ve)}")
        return jsonify({'message': f'An unexpected error occurred {str(ve)}\n{traceback.format_exc()}.'}), 500
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in correlations_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500

# UNTESTED
@market_bp.route('/assets_table', methods=['GET'])
def assets_table_route():
    try:
        columns, data = assets_table() 
        return jsonify({'message': 'Assets Chart Info fetched successfully', 'data': data, 'columns': columns})
    except ValueError as ve:
        logging.error(f"ValueError in assets_table_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        print(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f'An error occurred: {e}\n{traceback.format_exc()}')
        logging.error(f"Unexpected error in assets_table_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500

class AssetsSchema(Schema):
    get_pm25 = fields.Boolean(required=False, missing=True)

# UNTESTED 
@market_bp.route('/assets', methods=['GET'])
@use_args(AssetsSchema(), location='query')
def assets_route(args):
    try:
        cached_assets = redis_client.get("assets_data_cache") # type: ignore
        if cached_assets:
            assets = json.loads(cached_assets)
        else:
            assets = AssetService.get_assets_data()
        return jsonify({'message': 'Assets fetched successfully', 'assets': assets})
    except ValueError as ve:
        logging.error(f"ValueError in assets_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in assets_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500

class AirQualitySchema(Schema):
    asset_id = fields.Int(required=True)

# @requires_auth
@market_bp.route('/air_quality', methods=['GET'])
@use_args(AirQualitySchema(), location='query')
def air_quality_by_hour_route(args):
    try:
        asset_id = args['asset_id']
        cached_air_quality = redis_client.get(f"air_quality:{asset_id}") # type: ignore

        if cached_air_quality:
            air_quality_data = json.loads(cached_air_quality)
        else:
            air_quality_data = AirMeasureService.get_air_measure_charts_data(asset_id=asset_id)

        if air_quality_data.get('status') == 404:
            return jsonify(air_quality_data), 404

        return jsonify({'message': 'AirQuality fetched successfully', **air_quality_data })
    except ValueError as ve:
        logging.error(f"ValueError in assets_route: {str(ve)}")
        return jsonify({'message': str(ve)}), 400
    except Exception as e:
        logging.error(f"Unexpected error in air_quality_by_hour_route: {str(e)}")
        return jsonify({'message': f'An unexpected error occurred {str(e)}\n{traceback.format_exc()}.'}), 500
