
class StrategyBase:
    def __init__(self, user_id):
        self.user_id = user_id

    def trade(self):
        raise NotImplementedError("Trade method not implemented")
