import random
from decimal import Decimal

from ..strategy_base import StrategyBase
from app.database import db
from app.models import Pool
from app.api import AccountApi, LiquidityApi, PortfolioApi, LoanManagerApi

class StrategyRandom(StrategyBase):
    def __init__(self, user_id):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        self.sell()
        self.buy()
        return f"Trading using Strategy Random for user {self.user_id}"
    
    def buy(self):
        buy_allocations = self.get_random_buy_allocations()
        for asset_id, allocation_amount in buy_allocations.items():
            self.liquidity_api.buy(
                user_id=self.user_id,
                usd_in=allocation_amount,
                asset_id=asset_id
            )
        db.session.commit()

    def get_random_buy_allocations(self):
        cash_balance = self.account_api.current_balance(user_id=self.user_id)
        pools = Pool.query.all()
        asset_ids = [pool.asset_id for pool in pools]

        allocation_ratios = [random.random() for _ in asset_ids]
        total_ratio = sum(allocation_ratios)

        allocation_ratios = [ratio / total_ratio for ratio in allocation_ratios]
            
        allocations = {}
        for asset_id, ratio in zip(asset_ids, allocation_ratios):
            allocation_amount = Decimal(ratio) * cash_balance - Decimal(0.0001)
            if allocation_amount > 0.001:
                allocations[asset_id] = allocation_amount

        return allocations


    def sell(self):
        portfolio_items = self.portfolio_api.user_portfolio_items(user_id=self.user_id)
        for portfolio_item in portfolio_items:
            asset_id = portfolio_item.asset_id
            selling_quantity = Decimal(random.random()) * portfolio_item.quantity
            self.liquidity_api.sell(
                user_id=self.user_id,
                asset_id=asset_id,
                asset_quantity=selling_quantity
            )
        db.session.commit()
