import random
from decimal import Decimal

from app.strategies.strategy_base import StrategyBase
from app.api import LiquidityApi, AccountApi, PortfolioApi, LoanManagerApi


class StrategyRandomLoans(StrategyBase):
    def __init__(
              self,
              user_id
    ):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        self.take_random_loans()
        return f"Trading using RandomLoans for user {self.user_id}"

    def take_random_loans(self):
        assets = self.liquidity_api.assets()
        for asset in assets:
            asset_price = self.liquidity_api.asset_price(asset_id=asset.id)
            user_cash = self.account_api.current_balance(user_id=self.user_id)

            target_ratio = Decimal(1.5)

            # Maximum loan amount based on user's cash and target ratio
            max_loan_based_on_cash = user_cash / (asset_price * target_ratio)

            # Randomly determine cash to allocate but not exceeding max_loan_based_on_cash
            cash_to_allocate = random.randint(0, min(int(user_cash), int(max_loan_based_on_cash)))

            loan_amount = cash_to_allocate / asset_price
            available_loan = self.loan_manager_api.unutilized_deposits(asset_id=asset.id)
            loan_amount = min(available_loan, loan_amount)
            
            collateral = loan_amount * asset_price * target_ratio
            minimum_collateral_value = 0.001
            if collateral < minimum_collateral_value or user_cash < minimum_collateral_value:
                continue
            
            self.loan_manager_api.take_out_loan(
                user_id=self.user_id,
                asset_id=asset.id,
                loan_amount=loan_amount,
                collateral=collateral
            )
