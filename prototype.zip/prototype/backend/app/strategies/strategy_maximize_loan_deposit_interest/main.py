import random
from decimal import Decimal

from app.strategies.strategy_base import StrategyBase
from app.api import LiquidityApi, AccountApi, PortfolioApi, LoanManagerApi


class StrategyMaximizeLoanDepositInterest(StrategyBase):
    def __init__(
              self,
              user_id
    ):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        high_utilization_ratio_asset_ids, low_utilization_ratio_assets = self.split_asset_ids_by_utilization_ratio()
        self.sell(asset_ids=high_utilization_ratio_asset_ids)
        self.buy(asset_ids=low_utilization_ratio_assets)
        return f"Trading using StrategyRandomLoanDeposits for user {self.user_id}"

    def sell(self, asset_ids=[]):
        for asset_id in asset_ids:
            self.loan_manager_api.withdraw_all_deposits_and_interest(user_id=self.user_id, asset_id=asset_id)
            item = self.portfolio_api.current_portfolio_item(asset_id=asset_id, user_id=self.user_id)
            if item:
                self.liquidity_api.sell(asset_id=asset_id, user_id=self.user_id, asset_quantity=item.quantity)

    def buy(self, asset_ids=[]):
        for asset_id in asset_ids:
            balance = self.account_api.current_balance(user_id=self.user_id)
            percentage_of_balance = random.uniform(0.5, 1.0)
            amount_to_use = balance * Decimal(percentage_of_balance)
            if amount_to_use is None or amount_to_use <= 0.001:
                return
            quantity_acquired = self.liquidity_api.buy(
                user_id=self.user_id,
                usd_in=amount_to_use,
                asset_id=asset_id
            )
            self.loan_manager_api.deposit(
                user_id=self.user_id,
                asset_id=asset_id,
                quantity_acquired=quantity_acquired
            )
            
    def split_asset_ids_by_utilization_ratio(self):
            asset_ids = self.loan_manager_api.asset_ids_by_utilization_ratio()
            mid_point = len(asset_ids) // 2
            high_utilization_ratio_assets_ids = asset_ids[:mid_point]
            low_utilization_ratio_assets_ids = asset_ids[mid_point:]
            return high_utilization_ratio_assets_ids, low_utilization_ratio_assets_ids
