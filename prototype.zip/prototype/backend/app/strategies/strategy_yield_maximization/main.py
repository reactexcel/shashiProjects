
from ..strategy_base import StrategyBase

from app.api import LiquidityApi, AccountApi, PortfolioApi, LoanManagerApi

class StrategyYieldMaximization(StrategyBase):
    def __init__(
              self,
              user_id
    ):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        self.portfolio_api.reallocate_portfolio(user_id=self.user_id)
        return f"Trading using Strategy Yield Maximization for user {self.user_id}"
