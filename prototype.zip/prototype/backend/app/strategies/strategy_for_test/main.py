from app.strategies.strategy_base import StrategyBase

from app.api import AccountApi, LiquidityApi, LoanManagerApi, PortfolioApi


class StrategyForTest(StrategyBase):
    def __init__(
              self,
              user_id
    ):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        return f"Trading using StrategyForTest for user {self.user_id}"
