from app.strategies.strategy_base import StrategyBase
from app.database import db
import random
from decimal import Decimal

from app.models import Pool
from app.api import AccountApi, LiquidityApi, PortfolioApi, LoanManagerApi


class StrategyRandomLoanDeposits(StrategyBase):
    def __init__(
              self,
              user_id
    ):
        super().__init__(user_id)
        self.liquidity_api = LiquidityApi()
        self.account_api = AccountApi()
        self.portfolio_api = PortfolioApi()
        self.loan_manager_api = LoanManagerApi()

    def trade(self):
        self.buy()
        self.make_loan_deposits()
        self.withdraw_interest()
        return f"Trading using RandomLoanDeposits for user {self.user_id}"

    def buy(self):
        buy_allocations = self.get_random_buy_allocations()
        for asset_id, allocation_amount in buy_allocations.items():
            if allocation_amount < 0.001:
                continue

            self.liquidity_api.buy(
                user_id=self.user_id,
                usd_in=allocation_amount,
                asset_id=asset_id
            )
        db.session.commit()

    def make_loan_deposits(self):
        portfolio_items = self.get_user_portfolio_items()
        for portfolio_item in portfolio_items:
            asset_id = portfolio_item.asset_id
            quantity = portfolio_item.quantity
            if quantity < 0.001:
                continue
            self.loan_manager_api.deposit(
                user_id=self.user_id,
                quantity_acquired=quantity,
                asset_id=asset_id
            )
        db.session.commit()

    def withdraw_interest(self):
        loan_deposits = self.loan_manager_api.user_deposits(user_id=self.user_id)
        for loan_deposit in loan_deposits:
            self.loan_manager_api.withdraw_interest(
                user_id=self.user_id,
                asset_id=loan_deposit.asset_id,
                amount=loan_deposit.available_interest_earned
            )
        db.session.commit()

    def get_user_portfolio_items(self):
        return self.portfolio_api.user_portfolio_items(user_id=self.user_id)

    def get_random_buy_allocations(self):
        cash_balance = self.account_api.current_balance(user_id=self.user_id)
        pools = Pool.query.all()
        asset_ids = [pool.asset_id for pool in pools]

        allocation_ratios = [random.random() for _ in asset_ids]
        total_ratio = sum(allocation_ratios)

        allocation_ratios = [ratio / total_ratio for ratio in allocation_ratios]
        allocations = {asset_id: Decimal(ratio) * cash_balance - 1 for asset_id, ratio in zip(asset_ids, allocation_ratios)}
        return allocations