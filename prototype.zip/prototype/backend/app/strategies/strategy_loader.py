import importlib
import os

from app.strategies.strategy_base import StrategyBase


def get_strategy(strategy_type, user_id, custom_strategy_dir=None):
    try:
        strategy_dir = ''.join(['_'+i.lower() if i.isupper() else i for i in strategy_type]).lstrip('_')
        strategy_module_path = f"app.strategies.{strategy_dir}.main"
        try:
            strategy_module = importlib.import_module(strategy_module_path)
        except ModuleNotFoundError:
            strategy_filepath = os.path.join(custom_strategy_dir, f"{strategy_type}.py")
            if os.path.exists(strategy_filepath):
                spec = importlib.util.spec_from_file_location("strategy_module", strategy_filepath)
                strategy_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(strategy_module)
            else:
                raise ModuleNotFoundError(f"Unable to find strategy module '{strategy_module_path}' or '{strategy_filepath}'")

        strategy_class = getattr(strategy_module, strategy_type)
        if issubclass(strategy_class, StrategyBase):
            return strategy_class(user_id)
        else:
            raise TypeError("Not a valid strategy class")
    except (AttributeError, ModuleNotFoundError) as e:
        raise ValueError(f"Unable to load strategy '{strategy_type}': {e}")
