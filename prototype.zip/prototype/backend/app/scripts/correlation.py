import sys
sys.path.append("/opt/render/project/src/backend")
from app.services import CorrelationService
from app import create_app
import traceback

def correlation_script():
    app = create_app()  
    with app.app_context(): 
        try:
            correlation_service = CorrelationService()
            correlation_service.run()
        except Exception as e:
            print(f'An error occurred: {e}\n{traceback.format_exc()}')


correlation_script()
