import sys
sys.path.append("/opt/render/project/src/backend")
from app.services import AirMeasureService
from app import create_app
import traceback
def air_measire_script():
    app = create_app()  
    with app.app_context(): 
        try:
            air_measure_service = AirMeasureService()
            # air_measure_service.call_and_store_city_air_data()
            air_measure_service.call_and_store_regions_air_data()
        except Exception as e:
            print(f'An error occurred: {e}\n{traceback.format_exc()}')


air_measire_script()
