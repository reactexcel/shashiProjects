import sys
sys.path.append("/opt/render/project/src/backend")
from app.services import DividendService, PriceHistoryService, PortfolioManagerService
from app.models import Profile, Asset, Pool, AssetDividend, DividendPayout, PortfolioItem, LiquidityPool, MarketBalance
from app.tests.factories import LiquidityPoolFactory, MarketBalanceFactory
from app import create_app
from app.database import db
from app.services.asset_info_service import save_asset_info_data

import logging
import traceback
import time

def e2e_script():
    app = create_app()  
    with app.app_context(): 
        try:
            setup()

            print('running dividend service')
            start_time = time.time()
            d = DividendService()
            d.distribute_dividends()
            process_time = time.time() - start_time
            print(f"dividend service took {process_time} seconds")
            print('-------------------')
            
            
            print('running price history service')
            start_time = time.time()
            ph = PriceHistoryService() 
            ph.process_assets()
            process_time = time.time() - start_time
            print(f"price history service took {process_time} seconds")
            print('-------------------')
            
            
            print('running portfolio rebalancing service')
            start_time = time.time()
            users = Profile.query.filter_by(auto_rebalance=True).all()
            for user in users:
                pm = PortfolioManagerService(user_id=user.id) 
                pm.reallocate_portfolio()
            process_time = time.time() - start_time
            print(f"portfolio manager service took {process_time} seconds")
            print('running save_asset_info_data')
            start_time = time.time()
            save_asset_info_data()
            process_time = time.time() - start_time
            print(f"save_asset_info_data took {process_time} seconds")
        except Exception as e:
            print(f'An error occurred: {e}\n{traceback.format_exc()}')
            db.session.rollback()

def setup():
    print('running add liquidity service')
    start_time = time.time()
    liquidity_pools = LiquidityPool.latest_pools_per_id()

    process_time = time.time() - start_time
    print(f"liquidity service took {process_time} seconds")
    print('-------------------')
    
    print('running create needed new liquidity pools service')
    pools = Pool.query.all()
    start_time = time.time()
    pool_id_to_lp_id = {lp.pool_id: lp.id for lp in liquidity_pools}
    for pool in pools:
        if pool.id not in pool_id_to_lp_id:
            new_lp = LiquidityPoolFactory(pool_id=pool.id, asset_id=pool.asset_id)
            db.session.add(new_lp)
    db.session.commit()
    process_time = time.time() - start_time
    print(f"liquidity pools service took {process_time} seconds")
    print('-------------------')

    if MarketBalance.current() is None:
        MarketBalanceFactory()
        db.session.commit()

e2e_script()
