import sys
import os

sys.path.append(os.getcwd())

from app.simulations.simulation import simulate
from app import create_app
import random

def simulate_market():
    app = create_app()  
    with app.app_context():
        pm25_data = generate_air_measures(1000)
        traders = generate_profiles(25)
        # simulate(pm25_data=pm25_data,traders=traders)
        for _ in simulate(pm25_data=pm25_data, traders=traders):
            pass

def generate_profiles(count):
    profiles = []
    strategies = ['StrategyYieldMaximization', 'StrategyRandom', 'StrategyMaximizeLoanDepositInterest', 'StrategyRandomLoans', 'StrategyRandomLoanDeposits']
    for i in range(count):
        # strategy = randomize_strategies(strategies=strategies)
        strategy = strategies[i%len(strategies)]
        profile = {
            'name': '',
            'email': '',
            'strategy': strategy
        }
        profiles.append(profile)
    return profiles

def randomize_strategies(strategies):
    return random.choice(strategies)
    

def generate_air_measures(count):
    air_measures = []
    for _ in range(count):
        air_measure = {
            'asset_id': round(random.uniform(1, 5)),
            'pm_25_10_minute': random.uniform(1, 50),
            'payout_cycle_id': round(random.uniform(1, 25))
        }
        air_measures.append(air_measure)
    return air_measures

simulate_market()