from app.models import LiquidityPool, PayoutCycle, PortfolioItem, Profile, UserBalance, LoanDeposit, Loan, LendingPool
from app.services import DividendService
from app.strategies.strategy_loader import get_strategy
from app.simulations.store_initial_data import setup_db_for_simulation
from app.services.portfolio_service import PortfolioService
from app.services.user_balance_service import UserBalanceService
from app.helpers.shorten_number import expand_number
# from app.services.transaction_service import TransactionService
from app.services import TransactionService
from app.helpers.temp_db import with_temp_db
from sqlalchemy import func

from app.models import Transaction
import json
import pandas as pd

@with_temp_db
def simulate(pm25_data, traders, temp_dir=None, database_uri=None, loan_deposits=None):
    from app import create_app
    app = create_app(simulator=True, database_uri=database_uri)

    with app.app_context():
        setup_db_for_simulation(pm25_data=pm25_data, profile_data=traders, loan_deposits=loan_deposits)
        traders = Profile.query.all()
        for payout_cycle_id in range(1, PayoutCycle.max_id()):
            import logging
            logging.info('payout_cycle_id: ' + str(payout_cycle_id))

            for trader in traders:
                trade(trader=trader, temp_dir=temp_dir) # TODO pass in payout cycle
            
            if payout_cycle_id % 5 == 0:
                DividendService().distribute_dividends()
                LendingPool().distribute_interest_for_all_assets()

            trades_count = Transaction.query.filter_by(user_id=trader.id).count()
            yield {f"PAYOUT CYCLE {payout_cycle_id}: ": f"{trades_count} TRADES, {len(loan_deposits) if loan_deposits else 0} LOAN DEPOSITS"}
        result = print_simulation_results(traders)
        
        for item in result:
            item['start_net_worth'] = str(item['start_net_worth'])
            item['end_net_worth'] = str(item['end_net_worth'])

        yield json.dumps(result)
        

def trade(trader: Profile, temp_dir=None):
    strategy = get_strategy(trader.strategy, trader.id, temp_dir)
    if strategy is None:
        return
    strategy.trade()


def print_simulation_results(traders):
    data = [[
        'user', 
        'roi ($)', 
        'roi (%)', 
        'start net worth', 
        'end net worth', 
        'trades', 
        'strategy', 
        'cash', 
        'assets value', 
        'loan deposits value', 
        'loan interest earned', 
        'loan taken', 
        'loans collateral'
    ]]

    for trader in traders:
        pools = LiquidityPool.latest_pools_per_id()
        exchange_rates = {pool.asset_id: pool.exchange_rate() for pool in pools}
        portfolio = PortfolioItem.latest_user_asset_pairings_for_user(trader.id)
        total_asset_value = PortfolioService.total_asset_value(portfolio, exchange_rates)

        cash_balance = UserBalance.current(user_id=trader.id).quantity
        loan_deposit_value, loan_interest_earned, loan_value_subtract, loan_value_collateral = 0, 0, 0, 0

        for asset_id, exchange_rate in exchange_rates.items():
            loan_deposit = LoanDeposit.current(user_id=trader.id, asset_id=asset_id)
            if loan_deposit:
                loan_interest_earned += loan_deposit.available_interest_earned
                loan_deposit_value += loan_deposit.amount * exchange_rate

            loan_value = Loan.current_open_loan(user_id=trader.id, asset_id=asset_id)
            if loan_value:
                loan_value_subtract += -(loan_value.amount * exchange_rate)
                loan_value_collateral += loan_value.remaining_collateral

        net_worth_end = round(cash_balance + total_asset_value + loan_deposit_value + loan_interest_earned + loan_value_subtract + loan_value_collateral, 2)
        net_worth_start = round(UserBalanceService.earliest_positive_balance(trader.id).quantity, 2)
        
        trades_count = Transaction.query.filter_by(user_id=trader.id).count()
        strategy = trader.strategy

        # Calculate ROI using the updated net worth end calculation
        roi_dollars = round(net_worth_end - net_worth_start, 2)
        roi_percent = round((roi_dollars / net_worth_start * 100) if net_worth_start else 0.0, 2)

        # Append the detailed financial data along with existing information
        data.append([trader.id, roi_dollars, roi_percent, net_worth_start, net_worth_end, trades_count, strategy, round(cash_balance, 2), round(total_asset_value, 2), round(loan_deposit_value, 2), round(loan_interest_earned, 2), round(loan_value_subtract, 2), round(loan_value_collateral, 2)])

    # Sorting and printing logic updated to accommodate the new structure
    data = [data[0]] + sorted(data[1:], key=lambda x: float(x[2]), reverse=True)
    widths = [max(map(len, (str(val) for val in col))) for col in zip(*data)]

    for row in data:
        print(" | ".join((str(val).ljust(width) for val, width in zip(row, widths))))

    # Adjust the result conversion to include new columns
    result = []
    for row in data[1:]:
        result.append({
            'user': str(row[0]),
            'roi': str(row[1]),
            'roi_percent': str(row[2]),
            'start_net_worth': str(row[3]),
            'end_net_worth': str(row[4]),
            'trades_count': str(row[5]),
            'strategy': str(row[6]),
            'cash_balance': str(row[7]),
            'assets_value': str(row[8]),
            'loan_deposits_value': str(row[9]),
            'loan_interest_earned': str(row[10]),
            'loan_taken': str(row[11]),
            'loans_collateral': str(row[12])
        })

    df = pd.DataFrame(data[1:], columns=data[0])
    roi_by_strategy(df)

    return result


def roi_by_strategy(df):
    average_by_strategy = df.groupby('strategy').mean().round(2).sort_values(by='roi (%)', ascending=False)
    average_by_strategy.rename_axis(None, inplace=True)

    columns = ['roi ($)', 'roi (%)', 'start net worth', 'end net worth', 'trades']
    average_by_strategy = average_by_strategy[columns]

    print("\n\n AVERAGES ON STRATEGY")
    print(average_by_strategy, "\n\n")
    
