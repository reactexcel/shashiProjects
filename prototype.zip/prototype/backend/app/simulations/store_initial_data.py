from app.models import AirMeasure, PayoutCycle, Profile, Asset, UserBalance, Pool, MarketBalance, LiquidityPool, \
    PortfolioItem, LoanDeposit
from app.database import db

INITIAL_USER_CASH_VALUE = 100000
INITIAL_MARKET_BALANCE = 100000
INITIAL_LIQUIDITY_POOL_USD = 100000
INITIAL_LIQUIDITY_POOL_ASSET_QUANTITY = 100000
INITIAL_PORTFOLIO_ITEM_QUANTITY = 100000
INITIAL_DEPOSIT_AMOUNT = 1000

def setup_db_for_simulation(pm25_data, profile_data, loan_deposits):
    initialize()
    add_payout_cycles_to_db(pm25_data=pm25_data)
    add_assets_to_db(pm25_data=pm25_data)
    add_pools_to_db()
    add_liquidity_pools_to_db()
    add_profiles_to_db(profile_data=profile_data)
    add_market_balance_to_db()
    add_user_balance_to_db()
    add_air_measures_to_db(pm25_data=pm25_data)
    add_loan_deposits_to_db(loan_deposits)

def initialize():
    db.drop_all()
    db.create_all()

def add_assets_to_db(pm25_data):
    asset_ids = set(data['asset_id'] for data in pm25_data)
    assets = []
    for asset_id in asset_ids:
        assets.append(Asset(id=asset_id, name=f"asset_{asset_id}"))
    db.session.add_all(assets)
    db.session.commit()
    print(f"{len(assets)} Asset objects successfully added to the database")

def add_payout_cycles_to_db(pm25_data):
    if len(pm25_data) == 0:
        return
    payout_cycles = []
    max_payout_cycle_id = max(data['payout_cycle_id'] for data in pm25_data)
    for _ in range(1, max_payout_cycle_id + 1):
        payout_cycles.append(PayoutCycle())
    db.session.add_all(payout_cycles)
    db.session.commit()
    print(f"Max PayoutCycle {len(payout_cycles)}")

def add_profiles_to_db(profile_data):
    try:
        profiles = [Profile(**profile) for profile in profile_data]
        db.session.add_all(profiles)
        db.session.commit()
        print(f"{len(profiles)} Profile objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")

def add_pools_to_db():
    try:
        pools = []
        for asset in Asset.query.all():
            pools.append(Pool(asset_id=asset.id))
        db.session.add_all(pools)
        db.session.commit()
        print(f"{len(pools)} Pool objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")

def add_liquidity_pools_to_db():
    try:
        liquidity_pools = []
        for pool in Pool.query.all():
            liquidity_pool = LiquidityPool(
                asset_id=pool.asset_id, 
                pool_id=pool.id,
                asset_quantity=INITIAL_LIQUIDITY_POOL_ASSET_QUANTITY,
                USD_quantity=INITIAL_LIQUIDITY_POOL_USD,
                total_liquidity_tokens=0,
                payout_cycle_id=1
            )
            liquidity_pools.append(liquidity_pool)
        db.session.add_all(liquidity_pools)
        db.session.commit()
        print(f"{len(liquidity_pools)} LiquidityPool objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")

def add_user_balance_to_db():
    try:
        user_balances = []
        for profile in Profile.query.all():
            user_balance = UserBalance(user_id=profile.id, quantity=INITIAL_USER_CASH_VALUE)
            user_balances.append(user_balance)
        db.session.add_all(user_balances)
        db.session.commit()
        print(f"{len(user_balances)} UserBalances objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")

def add_market_balance_to_db():
    db.session.add(MarketBalance(quantity=INITIAL_MARKET_BALANCE))
    db.session.commit()

def add_air_measures_to_db(pm25_data):
    try:
        air_measures = [AirMeasure(**pm25_datapoint) for pm25_datapoint in pm25_data]
        db.session.add_all(air_measures)
        db.session.commit()
        print(f"{len(air_measures)} AirMeasure objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")

def add_loan_deposits_to_db(loan_deposits):
    try:
        loan_deposits = [LoanDeposit(**loan_deposit) for loan_deposit in loan_deposits]
        db.session.add_all(loan_deposits)
        db.session.commit()
        print(f"{len(loan_deposits)} LoanDeposit objects successfully added to the database.")
    except Exception as e:
        db.session.rollback()
        print(f"An error occurred: {e}")
