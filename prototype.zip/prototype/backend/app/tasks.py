from celery import Celery
from celery.schedules import crontab
from app import create_app
from app.models import Profile, Asset
from app.services.market_info_service import market_info
from app.services.dividend_service import calculate_expected_dividends
from app.services import LeaderboardService, AssetService, PriceHistoryService, AssetInfoService, PortfolioService, AirMeasureService
from app.services.dividend_service import get_dividend_per_share_history
import redis
import os
import json
from app.redis_client import redis_client
from decimal import Decimal
from datetime import datetime



class CustomEncoder(json.JSONEncoder):
  def default(self, obj):
      if isinstance(obj, Decimal):
          return str(obj)
      elif isinstance(obj, datetime):
          return obj.isoformat()
      return super().default(obj)


app = create_app()

# Initialize Celery
celery = Celery(__name__, broker=app.config['CELERY_BROKER_URL'], backend=app.config['CELERY_RESULT_BACKEND'])

celery.conf.update(
    broker_connection_retry=True,
    broker_connection_retry_on_startup=True,
    broker_connection_max_retries=5,
    broker_connection_timeout=4.0,
    worker_pool='prefork',
)

# Schedule the periodic task
celery.conf.beat_schedule = {
    'query_and_cache_profile': {
        'task': 'app.tasks.query_and_cache_profile',
        'schedule': crontab(minute='*/5'),
    },
    'query_and_cache_leaderboard': {
        'task': 'app.tasks.query_and_cache_leaderboard',
        'schedule': crontab(minute='*/5'),
    },
    'query_and_cache_assets_data': {
        'task': 'app.tasks.query_and_cache_assets_data',
        'schedule': crontab(minute='*/5'),
    },
    'set_asset_page_endpoints_caches': {
        'task': 'app.tasks.set_asset_page_endpoints_caches',
        'schedule': crontab(minute='*/5'),
    },
    'cache_market_overview': {
        'task': 'app.tasks.cache_market_overview',
        'schedule': crontab(minute='*/5'),
    },
    'cache_user_portfolio': {
        'task': 'app.tasks.cache_user_portfolio',
        'schedule': crontab(minute='*/5'),
    },
    'cache_dividend_by_asset': {
        'task': 'app.tasks.cache_dividend_by_asset',
        'schedule': crontab(minute='*/5'),
    },
    'cache_air_quality': {
        'task': 'app.tasks.cache_air_quality',
        'schedule': crontab(minute='*/5'),
    },
}

# Initialize the cache
redis_client = redis_client


@celery.task(name='app.tasks.query_and_cache_profile')
def query_and_cache_profile():
    app = create_app()
    with app.app_context():
        profiles = Profile.query.all()
        profiles_data = [profile.to_dict() for profile in profiles]
        redis_client.set("profiles_cache", json.dumps(profiles_data))


@celery.task(name='app.tasks.query_and_cache_leaderboard')
def query_and_cache_leaderboard():
    app = create_app()
    with app.app_context():
        leaderboard_data = LeaderboardService.get_leaderboard_data()
        redis_client.set("leaderboard_cache", json.dumps(leaderboard_data, cls=CustomEncoder))


@celery.task(name='app.tasks.query_and_cache_assets_data')
def query_and_cache_assets_data():
    app = create_app()
    with app.app_context():
        assets_data = AssetService.get_assets_data()
        redis_client.set("assets_data_cache", json.dumps(assets_data, cls=CustomEncoder))


@celery.task(name='app.tasks.set_asset_page_endpoints_caches')
def set_asset_page_endpoints_caches():
    app = create_app()
    with app.app_context():
        periods = ["HOUR", "5HOUR", "DAY", "WEEK", "MONTH"]
        assets = Asset.query.all()
        for asset in assets:
            for period in periods:
                dividend_history = get_dividend_per_share_history(asset_id=asset.id, period=period)
                redis_client.set(f"dividend_history:{asset.id}:{period}", json.dumps(dividend_history, cls=CustomEncoder))

                price_history = PriceHistoryService().get_price_history(asset_id=asset.id, period=period)
                redis_client.set(f"price_history:{asset.id}:{period}", json.dumps(price_history, cls=CustomEncoder))

                asset_info = AssetInfoService(asset.id).res()
                redis_client.set(f"asset_info:{asset.id}:{period}", json.dumps(asset_info, cls=CustomEncoder))


@celery.task(name='app.tasks.cache_market_overview')
def cache_market_overview():
    app = create_app()
    with app.app_context():
        market_overview = market_info()
        redis_client.set("market_overview_cache", json.dumps(market_overview, cls=CustomEncoder))


@celery.task(name='app.tasks.cache_user_portfolio')
def cache_user_portfolio():
    app = create_app()
    with app.app_context():
        users = Profile.query.all()
        for user in users:
            user_id = user.id
            portfolio = PortfolioService.get_user_portfolio(user_id)
            redis_client.set(f"portfolio:{user_id}", json.dumps(portfolio, cls=CustomEncoder))


@celery.task(name='app.tasks.cache_dividend_by_asset')
def cache_dividend_by_asset():
    app = create_app()
    with app.app_context():
        assets = Asset.query.all()
        for asset in assets:
            expected_dividends = calculate_expected_dividends(asset.id)
            redis_client.set(f"expected_dividend:{asset.id}", json.dumps(expected_dividends, cls=CustomEncoder))


@celery.task(name='app.tasks.cache_air_quality')
def cache_air_quality():
    app = create_app()
    with app.app_context():
        assets = Asset.query.all()
        for asset in assets:
            air_quality_by_hour = AirMeasureService.get_air_measure_charts_data(asset.id)
            redis_client.set(f"air_quality:{asset.id}", json.dumps(air_quality_by_hour, cls=CustomEncoder))


if __name__ == '__main__':
    celery.start()
