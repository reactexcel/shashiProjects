import os
import json
from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app
from werkzeug.datastructures import FileStorage
from app.routes.simulation_routes import process_file_and_return_path
import tempfile
from unittest.mock import patch
from flask import Response


class TestSimulationRoute(BaseTestCase):
    STRATEGY_FILE_NAME = "StrategyForTest.py"

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.client = self.app.test_client()
        self.app_context.push()

    def tearDown(self):
        db_counter_file = 'db_name_counter.txt'
        if os.path.exists(db_counter_file):
            os.remove(db_counter_file)
        self.app_context.pop()

    def get_test_directory(self):
        current_directory = os.path.dirname(os.path.abspath(__file__))
        return os.path.abspath(os.path.join(current_directory, '..'))

    def get_strategies_file_path(self):
        return os.path.join(self.get_test_directory(), self.STRATEGY_FILE_NAME)

    def get_test_data(self, with_external_strategy=True):
        traders_data = [
            {"name": "Trader1", "email": "trader1@example.com", "strategy": "StrategyForTest" if with_external_strategy else "StrategyRandom"},
            {"name": "Trader2", "email": "trader2@example.com", "strategy": "StrategyRandom"},
            {"name": "Trader3", "email": "trader3@example.com", "strategy": "StrategyYieldMaximization"}
        ]
        pm25_data = [
            {"asset_id": 2, "pm_25_10_minute": 23.54, "payout_cycle_id": 45},
            {"asset_id": 1, "pm_25_10_minute": 12.87, "payout_cycle_id": 72},
            {"asset_id": 4, "pm_25_10_minute": 37.12, "payout_cycle_id": 18}
        ]
        return traders_data, pm25_data

    @patch('app.routes.simulation_routes.scan_with_bandit')
    @patch('app.routes.simulation_routes.process_file_and_return_path')
    @patch('app.routes.simulation_routes.simulate')
    def test_simulation_functions(self, simulate_mock, process_file_and_return_path_mock, scan_with_bandit_mock):
        process_file_and_return_path_mock.return_value = self.get_strategies_file_path()
        strategies_file_path = self.get_strategies_file_path()
        traders_data, pm25_data = self.get_test_data()

        simulate_mock.return_value = [{
            "user": 1, "roi": 100, "roi_percent": 10, "start_net_worth": 1000,
            "end_net_worth": 1100, "trades_count": 5, "strategy": "StrategyForTest"
        }]

        response = self.client.post('/simulation', data=dict(
            traders=json.dumps(traders_data),
            pm25_data=json.dumps(pm25_data),
            strategies=(strategies_file_path,)
        ))

        self.assertTrue(response.is_streamed, True)
        data = json.loads(response.data)
        self.assertEqual(response.status_code, 200)
        expected_results = simulate_mock.return_value
        self.assertEqual([data], expected_results)
        
        process_file_and_return_path_mock.assert_called_once()
        scan_with_bandit_mock.assert_called_once()        
        simulate_mock.assert_called_once()

        args, kwargs = simulate_mock.call_args
        self.assertEqual(kwargs['pm25_data'], pm25_data)
        self.assertEqual(kwargs['traders'], traders_data)
        self.assertIn('temp_dir', kwargs)
        self.assertIsNotNone(kwargs['temp_dir'])

    def test_simulation_route_with_external_strategy(self):
        traders_data, pm25_data = self.get_test_data()
        strategies_file_path = self.get_strategies_file_path()

        with open(strategies_file_path, 'rb') as f:
            response = self.client.post('/simulation', data={
                'traders': json.dumps(traders_data),
                'pm25_data': json.dumps(pm25_data),
                'strategies': (f, self.STRATEGY_FILE_NAME)
            })

        self.assertTrue(response.is_streamed, True)
        data = response.data.decode('utf-8')

        self.assertEqual(response.status_code, 200)
        self.assertIn('PAYOUT CYCLE', data)

    def test_simulation_route_with_local_strategy(self):
        traders_data, pm25_data = self.get_test_data(with_external_strategy=False)

        response = self.client.post('/simulation', data={
            'traders': json.dumps(traders_data),
            'pm25_data': json.dumps(pm25_data)
        })
        self.assertTrue(response.is_streamed, True)
        data = response.data.decode('utf-8')
        self.assertEqual(response.status_code, 200)

        self.assertIn('PAYOUT CYCLE', data)

    def test_simulation_route_with_external_strategy_without_file(self):
          traders_data, pm25_data = self.get_test_data()
          data = {
              'traders': json.dumps(traders_data),
              'pm25_data': json.dumps(pm25_data)
          }
          response = self.client.post('/simulation', data=data)
          self.assertEqual(response.status_code, 200)
          self.assertIsInstance(response, Response)

    def test_process_file_and_return_path(self):
        current_directory = os.path.dirname(os.path.abspath(__file__))
        test_directory = os.path.abspath(os.path.join(current_directory, '..'))
        strategies_file_name = "StrategyForTest.py"
        strategies_file_path = os.path.join(test_directory, strategies_file_name)
        file = FileStorage(
            stream=open(strategies_file_path, "rb"),
            filename=strategies_file_name,
            content_type="text/plain",
        )
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = process_file_and_return_path(file, temp_dir)
            self.assertTrue(os.path.exists(file_path))
            os.remove(file_path)