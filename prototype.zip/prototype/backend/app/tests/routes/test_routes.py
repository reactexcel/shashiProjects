import pytest
from datetime import datetime, timedelta
from decimal import Decimal
import json
from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app
from seed_database import seed_database
from app.database import db
from app.models.LiquidityPool import LiquidityPool
from app.models.UserBalance import UserBalance
from app.models import UserBalance, LiquidityPool, PriceHistory, Asset
from app.tests.factories import ProfileFactory, PriceHistoryFactory, LiquidityPoolFactory, PortfolioItemFactory
class Routes(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.client = self.app.test_client()
        self.app_context.push()
        seed_database()
        self.user = ProfileFactory().flush()
        self.pool = LiquidityPoolFactory().flush()
        self.asset_id = self.pool.asset_id
        self.pool_id = self.pool.pool_id

    @pytest.mark.skip('Skipping since it broke after adding jwt')
    def test_add_liquidity_route(self):
        add_liquidity_data = {
            'pool_id': self.pool_id,
            'asset_id': self.asset_id,
            'user_usd': '100',
            'asset_quantity': '0',
            'user_id': self.user.id,
        }

        # Assuming a user balance and liquidity pool are required for adding liquidity
        user_balance = UserBalance(quantity=1000, user_id=self.user.id)
        liquidity_pool = LiquidityPool(pool_id=self.pool_id, asset_id=self.asset_id, asset_quantity=1000, USD_quantity=1000, total_liquidity_tokens=100)

        db.session.add(user_balance)
        db.session.add(liquidity_pool)
        db.session.commit()

        # Send POST request to the /add_liquidity endpoint
        response = self.client.post('/add_liquidity', json=add_liquidity_data)
        data = json.loads(response.data)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['message'], 'Add liquidity executed successfully')
        self.assertIsInstance(Decimal(data['liquidity_tokens_acquired']), Decimal)

    @pytest.mark.skip('Needs updating since adding JWT')
    def test_buy_route(self):
        buy_data = {
            'pool_id': self.pool_id,
            'asset_id': self.asset_id,
            'amount_in': '100',
            'user_id': self.user.id,
        }

        user_balance = UserBalance(quantity=1000, user_id=self.user.id)
        PortfolioItemFactory(user_id=self.user.id, asset_id=self.asset_id)
        db.session.add(user_balance)
        db.session.commit()

        # Send GET request to the /buy endpoint
        response = self.client.post('/buy', json=buy_data)
        data = json.loads(response.data)
        print('data')
        print(data)
        print('response')
        print(response)
        
        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['message'], 'Buy executed successfully')
        self.assertIsInstance(Decimal(data['asset_quantity_acquired']), Decimal) # Update this

    @pytest.mark.skip('Needs updating since JWT')
    def test_sell_route(self):
        sell_data = {
            'pool_id': self.pool_id,
            'asset_id': self.asset_id,
            'asset_quantity': '50',
            'user_id': self.user.id,
        }

        user_balance = UserBalance(quantity=1000, user_id=self.user.id)
        PortfolioItemFactory(user_id = self.user.id, asset_id=self.asset_id, quantity=100)
        db.session.add(user_balance)
        db.session.commit()

        response = self.client.post('/sell', json=sell_data)
        data = json.loads(response.data)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(data['message'], 'Sell executed successfully')
        self.assertIsInstance(data['USD_acquired'], (str, float)) # Modify the type based on your code's logic

    @pytest.mark.skip('Needs updating since adding cache')
    def test_price_history_route(self):
        
        price_history_data = {
            'asset_id': self.asset_id,
            'period': 'DAY',
        }
        pre_count = PriceHistory.query.filter_by(asset_id=self.asset_id).count()
        PriceHistoryFactory(asset_id=self.asset_id, price=2000, price_time=datetime.utcnow()).flush()
        PriceHistoryFactory(asset_id=self.asset_id, price=4, price_time=datetime.utcnow() - timedelta(days=31)).flush()

        response = self.client.get('/price_history', query_string=price_history_data)
        data = json.loads(response.data)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(data['priceHistory']), pre_count + 1)
        self.assertEqual(Decimal(data['priceHistory'][-1]['value']), 2000)
        self.assertEqual(data['assetName'],Asset.query.filter_by(id=self.asset_id).first().name)
        