import os
from unittest.mock import patch
from app import create_app
import pytest


def test_default_configuration():
    with patch.dict(os.environ, {"DATABASE_URL": "sqlite:///default.db"}):
        app = create_app()
        assert app.config['SQLALCHEMY_DATABASE_URI'] == "sqlite:///default.db"
        assert not app.config['SQLALCHEMY_TRACK_MODIFICATIONS']


def test_testing_configuration():
    with patch.dict(os.environ, {"TEST_DATABASE_URL": "sqlite:///test.db"}):
        app = create_app(testing=True)
        assert app.config['SQLALCHEMY_DATABASE_URI'] == "sqlite:///test.db"
        assert not app.config['SQLALCHEMY_TRACK_MODIFICATIONS']


def test_simulator_configuration():
    app = create_app(simulator=True, database_uri="sqlite:///simulator.db")
    assert app.config['SQLALCHEMY_DATABASE_URI'] == "sqlite:///simulator.db"
    assert not app.config['SQLALCHEMY_TRACK_MODIFICATIONS']


def test_no_environment_variable():
    with patch.dict(os.environ, {"DATABASE_URL": ""}):
        with pytest.raises(Exception):
            create_app()

def test_invalid_simulator_database_uri():
    with pytest.raises(Exception):
        create_app(simulator=True, database_uri="invalid-uri")


def test_conflicting_parameters():
    with patch.dict(os.environ, {"DATABASE_URL": "sqlite:///default.db", "TEST_DATABASE_URL": "sqlite:///test.db"}):
        app = create_app(testing=True, simulator=True, database_uri="sqlite:///simulator.db")
        assert app.config['SQLALCHEMY_DATABASE_URI'] == "sqlite:///test.db"