from sqlalchemy.orm.session import close_all_sessions
from app.database import db
import unittest
from app.test_app import create_test_app

class BaseTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        db.session.begin_nested()

    def tearDown(self):
        db.session.rollback()
        db.session.remove()
        close_all_sessions()
        # db.drop_all()
        self.app_context.pop()
