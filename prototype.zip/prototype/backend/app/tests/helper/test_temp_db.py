import psycopg2
from sqlalchemy import create_engine
from app.helpers.temp_db import with_temp_db
import os
from dotenv import load_dotenv

load_dotenv()

temp_db_user = os.getenv('TEMP_DB_USER')
temp_db_password = os.getenv('TEMP_DB_PASSWORD')
temp_db_host = os.getenv('TEMP_DB_HOST', 'localhost')

def test_temporary_database_creation_and_deletion():
    db_name = None

    @with_temp_db
    def dummy_function(database_uri):
        nonlocal db_name
        db_name = database_uri.split('/')[-1]
        with psycopg2.connect(database="template1", user=temp_db_user, password=temp_db_password, host=temp_db_host) as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
                assert cursor.fetchone() is not None

    dummy_function()

    with psycopg2.connect(database="template1", user=temp_db_user, password=temp_db_password, host=temp_db_host) as conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
            assert cursor.fetchone() is None

def test_wrapped_function_execution():
    executed = False

    @with_temp_db
    def dummy_function(database_uri):
        nonlocal executed
        executed = True
        assert database_uri is not None
        return executed

    executed = dummy_function()
    assert executed