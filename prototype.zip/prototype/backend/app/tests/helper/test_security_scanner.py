import unittest
from unittest.mock import patch, MagicMock
import tempfile
import os
import json
from app.helpers.security_scanner import scan_with_bandit, SecurityError

class TestScanWithBandit(unittest.TestCase):
    @patch('subprocess.run')
    def test_scan_with_bandit(self, mock_run):
        with tempfile.NamedTemporaryFile(delete=False) as temp:
            temp_file_path = temp.name

        mock_run.return_value.stdout = json.dumps({
            'results': [
                {'issue_severity': 'HIGH', 'issue_text': 'Test issue'}
            ]
        })

        with self.assertRaises(SecurityError):
            scan_with_bandit(temp_file_path)

        mock_run.assert_called_once_with(['bandit', '-f', 'json', temp_file_path], capture_output=True, text=True)
        os.remove(temp_file_path)

    @patch('subprocess.run')
    def test_scan_with_bandit_no_issues(self, mock_run):
        with tempfile.NamedTemporaryFile(delete=False) as temp:
            temp_file_path = temp.name

        mock_run.return_value.stdout = json.dumps({
            'results': []
        })

        scan_with_bandit(temp_file_path)

        mock_run.assert_called_once_with(['bandit', '-f', 'json', temp_file_path], capture_output=True, text=True)
        os.remove(temp_file_path)