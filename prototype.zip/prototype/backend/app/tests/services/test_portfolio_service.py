import logging

from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.services import PortfolioService
from app.models import PortfolioItem, Profile, Asset, LoanDeposit, UserBalance, LiquidityPool, Pool
from app.test_app import create_test_app


class TestPortfolioService(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.ctx = self.app.app_context()
        self.ctx.push()
        db.create_all()

        self.user = self._create_profile('a', 'b')
        self.asset1 = self._create_asset('SF')
        self.asset2 = self._create_asset('SF2')
        self._create_and_commit([self.user, self.asset1, self.asset2])

        self.user_id = self.user.id
        self.asset1_id = self.asset1.id
        self.asset2_id = self.asset2.id

        self.pool1 = self._create_pool('SF', self.asset1_id)
        self.pool2 = self._create_pool('SF2', self.asset2_id)
        self._create_and_commit([self.pool1, self.pool2])

        self.pool1_id = self.pool1.id
        self.pool2_id = self.pool2.id

        db.session.add(UserBalance(user_id=self.user_id, quantity=100))
        db.session.commit()

        liquidity_pool1 = LiquidityPool(asset_id=self.asset1_id, asset_quantity=100, USD_quantity=100, pool_id=self.pool1_id, total_liquidity_tokens=0)
        liquidity_pool2 = LiquidityPool(asset_id=self.asset2_id, asset_quantity=100, USD_quantity=100, pool_id=self.pool2_id, total_liquidity_tokens=0)
        self._create_and_commit([liquidity_pool1, liquidity_pool2])

    def _create_profile(self, name, email):
        return Profile(name=name, email=email)

    def _create_asset(self, name):
        return Asset(name=name)

    def _create_pool(self, name, asset_id):
        return Pool(name=name, asset_id=asset_id)

    def _create_and_commit(self, items):
        db.session.add_all(items)
        db.session.commit()

    def tearDown(self):
        db.session.remove()
        db.drop_all()
        self.ctx.pop()

    def test_net_worth(self):
        loan_deposit = LoanDeposit(asset_id=self.asset1_id, user_id=self.user_id, amount=100, available_interest_earned=50)
        db.session.add_all([loan_deposit])

        self.assertEqual(PortfolioService.net_worth(self.user_id), 250)

    def test_net_worth_with_multiple_deposit(self):
        loan_deposit1 = LoanDeposit(asset_id=self.asset1_id, user_id=self.user_id, amount=100, available_interest_earned=50)
        loan_deposit2 = LoanDeposit(asset_id=self.asset2_id, user_id=self.user_id, amount=100, available_interest_earned=50)
        db.session.add_all([loan_deposit1, loan_deposit2])

        self.assertEqual(PortfolioService.net_worth(self.user_id), 400)

    def test_net_worth_with_multiple_users_loan_deposits(self):
        user2 = self._create_profile('user2', 'user2@example.com')
        self._create_and_commit([user2])

        loan_deposit1_user1 = LoanDeposit(asset_id=self.asset1_id, user_id=self.user_id, amount=100,
                                          available_interest_earned=25)

        loan_deposit1_user2 = LoanDeposit(asset_id=self.asset1_id, user_id=user2.id, amount=200,
                                            available_interest_earned=50)
        loan_deposit2_user2 = LoanDeposit(asset_id=self.asset2_id, user_id=user2.id, amount=100,
                                            available_interest_earned=100)
        self._create_and_commit([loan_deposit1_user1, loan_deposit1_user2, loan_deposit2_user2])

        self.assertEqual(PortfolioService.net_worth(self.user_id), 225)
        self.assertEqual(PortfolioService.net_worth(user2.id), 550)

