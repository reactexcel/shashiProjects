from ..base_test_case import BaseTestCase
from app.models import LiquidityPool, PriceHistory, Asset, Pool
from app.services.price_history_service import PriceHistoryService
from datetime import datetime, timedelta
from unittest.mock import patch
from app import db
from app.tests.factories import AssetFactory, PoolFactory, PriceHistoryFactory, LiquidityPoolFactory

class PriceHistoryServiceTest(BaseTestCase):
    
    def setUp(self):
        super().setUp()
        self.price_history_service = PriceHistoryService()

    def test_get_price_history_day(self):
        asset_id = AssetFactory().flush().id
        PriceHistoryFactory(asset_id=asset_id, price_time=datetime.utcnow() - timedelta(hours=23)).flush()
        PriceHistoryFactory(asset_id=asset_id, price_time=datetime.utcnow() - timedelta(days=2)).flush()
        result = self.price_history_service.get_price_history(asset_id, 'DAY')
        print(f'result = {result}')
        self.assertEqual(len(result), 1)

    def test_get_price_history_week(self):
        asset_id = AssetFactory().flush().id
        date1 = datetime.utcnow() - timedelta(days=4)
        date2 = datetime.utcnow() - timedelta(days=5)
        date3 = datetime.utcnow() - timedelta(days=6)
        PriceHistoryFactory(asset_id=asset_id, price=5, price_time=date1).flush()
        PriceHistoryFactory(asset_id=asset_id, price=4, price_time=date2).flush()
        PriceHistoryFactory(asset_id=asset_id, price=3, price_time=date3).flush()
        PriceHistoryFactory(asset_id=asset_id, price=2, price_time=datetime.utcnow() - timedelta(days=8)).flush()
        result = self.price_history_service.get_price_history(asset_id, 'WEEK')
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0]['value'], 3)
        self.assertEqual(result[0]['date'], date3)
        self.assertEqual(result[1]['value'], 4)
        self.assertEqual(result[1]['date'], date2)
        self.assertEqual(result[2]['value'], 5)
        self.assertEqual(result[2]['date'], date1)

    def test_get_price_history_month(self):
        asset_id = AssetFactory().flush().id
        date = datetime.utcnow() - timedelta(days=29)
        PriceHistoryFactory(asset_id=asset_id, price=2, price_time=date).flush()
        PriceHistoryFactory(asset_id=asset_id, price_time=datetime.utcnow() - timedelta(days=31)).flush()
        result = self.price_history_service.get_price_history(asset_id, 'MONTH')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]['value'], 2)
        self.assertEqual(result[0]['date'], date)


    def test_get_price_history_no_price_history(self):
        asset_id = AssetFactory().flush().id
        result = self.price_history_service.get_price_history(asset_id, 'DAY')
        self.assertEqual(len(result), 0)


    def test_calculate_average_price_with_pools(self):
        AssetFactory().flush()
        liquidity_pool = LiquidityPoolFactory(USD_quantity=100, asset_quantity=1, created_at=datetime.utcnow()).flush()
        liquidity_pool2 = LiquidityPoolFactory(pool_id=liquidity_pool.pool_id, asset_id=liquidity_pool.asset_id, USD_quantity=200, asset_quantity=1, created_at=datetime.utcnow()).flush()
        pools = iter([
            liquidity_pool,
            liquidity_pool2
        ])
        minute_start = datetime.utcnow()
        minute_end = minute_start + timedelta(minutes=1)
        last_price = 150
        result = self.price_history_service.calculate_average_price(pools, minute_start, minute_end, last_price)
        expected = (100 + 200) / 2
        self.assertEqual(result, expected)

    def test_calculate_average_price_without_pools(self):
        last_price = 150
        result = self.price_history_service.calculate_average_price(iter([]), datetime.utcnow(), datetime.utcnow() + timedelta(minutes=1), last_price)
        self.assertEqual(result, last_price)

    def test_create_price_history(self):
        asset_id = AssetFactory().flush().id
        time_frequency = 'minute'
        price = 200
        self.price_history_service.create_price_history(asset_id, time_frequency, price, price_time=datetime.utcnow())
        price_history = PriceHistory.query.filter_by(asset_id=asset_id, time_frequency=time_frequency, price=price).first()
        self.assertIsNotNone(price_history)

    def test_process_assets(self):
        db.drop_all()
        super().setUp()
        p = PoolFactory().flush()
        LiquidityPoolFactory(
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=10, seconds=30)
        ).flush()
        price_history_count_pre = PriceHistory.query.count()
        self.price_history_service.process_assets()
        price_history_count_post = PriceHistory.query.count()
        self.assertEqual(price_history_count_pre + 1, price_history_count_post)
    
    def test_process_assets_multiple(self):
        db.drop_all()
        super().setUp()
        p = PoolFactory().flush()
        LiquidityPoolFactory(
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=10, seconds=30)
        ).flush()
        LiquidityPoolFactory(
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=10, seconds=30)
        ).flush()
        price_history_count_pre = PriceHistory.query.count()
        self.price_history_service.process_assets()
        price_history_count_post = PriceHistory.query.count()
        self.assertEqual(price_history_count_pre + 1, price_history_count_post)

    def test_process_assets_multipl2(self):
        db.drop_all()
        super().setUp()
        p = PoolFactory().flush()
        minutes = 4
        PriceHistoryFactory(price=0, asset_id=p.asset_id, price_time=datetime.utcnow()-timedelta(minutes=minutes))
        lp = LiquidityPoolFactory(
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=1, seconds=30)
        ).flush()
        price_history_count_pre = PriceHistory.query.count()
        self.price_history_service.process_assets()
        price_history_count_post = PriceHistory.query.count()
        print(f'price_history_count_pre = {price_history_count_pre}')
        print(f'price_history_count_post = {price_history_count_post}')
        print(f'minutes = {minutes}')
        self.assertEqual(price_history_count_pre + minutes, price_history_count_post)
        phs = PriceHistory.query.filter_by(asset_id=p.asset_id).all()
        self.assertEqual(phs[-1].price, lp.exchange_rate())
        self.assertEqual(phs[-2].price, lp.exchange_rate())
        self.assertEqual(phs[0].price, 0)
 
    def test_process_assets_multiple3(self):
        db.drop_all()
        super().setUp()
        p = PoolFactory().flush()
        minutes = 4
        PriceHistoryFactory(price=0, asset_id=p.asset_id, price_time=datetime.utcnow()-timedelta(minutes=minutes))
        LiquidityPoolFactory(
            USD_quantity=1000,
            asset_quantity=1000,
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=1, seconds=30)
        ).flush()
        LiquidityPoolFactory(
            USD_quantity=9000,
            asset_quantity=1000,
            pool_id=p.id, 
            asset_id=p.asset_id, 
            created_at=datetime.utcnow()-timedelta(minutes=1, seconds=30)
        ).flush()
        price_history_count_pre = PriceHistory.query.count()
        self.price_history_service.process_assets()
        price_history_count_post = PriceHistory.query.count()
        print(f'price_history_count_pre = {price_history_count_pre}')
        print(f'price_history_count_post = {price_history_count_post}')
        print(f'minutes = {minutes}')
        self.assertEqual(price_history_count_pre + minutes, price_history_count_post)
        phs = PriceHistory.query.filter_by(asset_id=p.asset_id).all()
        print(phs)
        print(phs[-1])
        print(phs[-2])
        print(phs[0])
        self.assertEqual(phs[-1].price, 5)
        self.assertEqual(phs[-2].price, 5)
        self.assertEqual(phs[0].price, 0)