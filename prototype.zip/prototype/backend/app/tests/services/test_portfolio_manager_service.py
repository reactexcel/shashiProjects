from sqlalchemy.orm.session import close_all_sessions
import unittest.mock 
from sqlalchemy import func
from decimal import Decimal
from unittest.mock import patch
from faker import Faker
from app.test_app import create_test_app
from app.database import db
from unittest.mock import MagicMock 
from app.models import PortfolioItem, LiquidityPool, AssetDividend, Pool, MarketBalance, Profile, Asset, DividendPayout, UserBalance, PayoutCycle
from app.services import DividendService, LiquidityService, PortfolioManagerService
from ..base_test_case import BaseTestCase
from app.tests.factories import AssetFactory, PoolFactory, LiquidityPoolFactory, AssetDividendFactory, ProfileFactory, MarketBalanceFactory, PayoutCycleFactory, PortfolioItemFactory
fake = Faker()


class PortfolioManagerServiceTest(BaseTestCase):
    def setUp(self):
        db.drop_all()
        super().setUp()

    def test_calculate_dividend_price_ratios(self):
        expected_ratios = {1: 0.5, 2: 0.6}
        portfolio_manager = PortfolioManagerService(1)
        portfolio_manager._get_last_dividend_per_share_data = MagicMock(return_value={1: 100, 2: 120})
        LiquidityPool.latest_pools_per_id = MagicMock(return_value=[MagicMock(asset_id=1, exchange_rate=lambda: 200),
                                                                    MagicMock(asset_id=2, exchange_rate=lambda: 200)])
        result = portfolio_manager.calculate_per_share_dividend_price_ratios()
        self.assertEqual(portfolio_manager._get_last_dividend_per_share_data.call_count, 1)
        self.assertEqual(LiquidityPool.latest_pools_per_id.call_count, 1)
        self.assertEqual(result, expected_ratios)

    # def test_sell_positions_below_average(self):
    #     user = ProfileFactory()
    #     asset1 = AssetFactory()
    #     asset2 = AssetFactory()
    #     db.session.flush()
    #     pool1 = PoolFactory(asset_id=asset1.id)
    #     pool2 = PoolFactory(asset_id=asset2.id)
    #     db.session.flush()
    #     LiquidityPoolFactory(asset_id=asset1.id, pool_id=pool1.id)
    #     LiquidityPoolFactory(asset_id=asset2.id, pool_id=pool2.id)
    #     PortfolioItemFactory(asset_id=asset1.id, user_id=user.id, quantity=10)
    #     PortfolioItemFactory(asset_id=asset2.id, user_id=user.id, quantity=10)
    #     db.session.commit()
    #     db.session.flush()
    #     LiquidityService.sell = MagicMock(return_value=50)

    #     AssetDividendFactory.create_batch(size=5)
    #     db.session.commit()
    #     expected_proceeds = 50
    #     portfolio_manager = PortfolioManagerService(user.id)
    #     result = portfolio_manager._sell_positions_below_average({asset1.id: 0.4, asset2.id: 0.6}, 0.5)
    #     self.assertEqual(LiquidityService.sell.call_count, 1)
    #     self.assertEqual(result, expected_proceeds)

    # def test_buy_positions_above_average(self):
    #     user = ProfileFactory()
    #     asset1 = AssetFactory()
    #     asset2 = AssetFactory()
    #     db.session.flush()
    #     pool1 = PoolFactory(asset_id=asset1.id)
    #     pool2 = PoolFactory(asset_id=asset2.id)
    #     db.session.flush()
    #     LiquidityPoolFactory(asset_id=asset1.id, pool_id=pool1.id)
    #     LiquidityPoolFactory(asset_id=asset2.id, pool_id=pool2.id)
    #     db.session.commit()
    #     expected_to_buy = {asset1.id: Decimal(25), asset2.id: Decimal(25)}
    #     portfolio_manager = PortfolioManagerService(user.id)
    #     UserBalance.current = MagicMock(return_value=MagicMock(quantity=100))
    #     LiquidityService.buy = MagicMock(return_value=(25))
    #     result = portfolio_manager._buy_positions_above_average({asset1.id: 0.6, asset2.id: 0.6}, 0.5)
    #     user_portfolio = PortfolioItem.latest_user_asset_pairings()
    #     result = {}
    #     for portfolio_item in user_portfolio:
    #         result[portfolio_item.asset_id] = portfolio_item.quantity

    #     self.assertEqual(LiquidityService.buy.call_count, 2)
    #     self.assertEqual(result, expected_to_buy)

    def test_reallocate_portfolio(self):
        portfolio_manager = PortfolioManagerService(1)
        portfolio_manager.calculate_per_share_dividend_price_ratios = MagicMock(return_value={1: 0.4, 2: 0.6})
        portfolio_manager._sell_positions_below_average = MagicMock(return_value=100)
        portfolio_manager._buy_positions_above_average = MagicMock(return_value={1: 50, 2: 50})
        portfolio_manager.reallocate_portfolio()

    # def test_sell_with_insufficient_assets(self):
    #     portfolio_manager = PortfolioManagerService(1)
    #     PortfolioItem.current = MagicMock(return_value=None)
    #     result = portfolio_manager._sell_positions_below_average({1: 0.4, 2: 0.6}, 0.5)
    #     self.assertEqual(result, 0)

    def test_buy_with_insufficient_usd(self):
        portfolio_manager = PortfolioManagerService(1)
        UserBalance.current = MagicMock(return_value=MagicMock(quantity=0))
        result = portfolio_manager._buy_positions_above_average({1: 0.6, 2: 0.6}, 0.6)
        self.assertEqual(result, None)

    def test_empty_dividend_data(self):
        PortfolioManagerService._get_last_dividend_per_share_data = MagicMock(return_value={})
        LiquidityPool.latest_pools_per_id = MagicMock(return_value=[])
        portfolio_manager = PortfolioManagerService(1)
        result = portfolio_manager.calculate_per_share_dividend_price_ratios()
        self.assertEqual(result, {})

    def test_reallocation_with_empty_portfolio(self):
        AssetDividendFactory.create_batch(size=2)
        AssetFactory.create_batch(size=2)
        LiquidityPoolFactory.create_batch(size=5)
        PoolFactory()
        db.session.add(AssetDividend(asset_id=1, USD=100))
        db.session.commit()
        portfolio_manager = PortfolioManagerService(1)
        portfolio_manager.reallocate_portfolio()

    def test_reallocation_with_full_portfolio(self):
        portfolio_manager = PortfolioManagerService(1)
        portfolio_manager.calculate_dividend_price_ratios = MagicMock(return_value={1: 0.5, 2: 0.5})
        portfolio_manager._sell_positions_below_average = MagicMock(return_value=0)
        portfolio_manager._buy_positions_above_average = MagicMock(return_value={1: 50, 2: 50})
        portfolio_manager.reallocate_portfolio()