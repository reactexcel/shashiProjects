from ..base_test_case import BaseTestCase
from app.database import db
from app.models import Asset, Pool, LiquidityPool, LiquidityHolding, PortfolioItem, UserBalance, MarketBalance, Profile
from app.services.liquidity_service import LiquidityService
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal
from app.tests.factories import LiquidityPoolFactory, PoolFactory, AssetFactory, ProfileFactory
class LiquidityServiceTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        # seed_database()
        self.liquidity_service = LiquidityService()
        self.asset = AssetFactory()
        self.user = ProfileFactory()
        db.session.flush()
        self.pool = PoolFactory(asset_id=self.asset.id)
        self.pool_id = self.pool.id
        db.session.flush()
        liquidity_pool = LiquidityPoolFactory(
            pool_id=self.pool.id,
            asset_id=self.asset.id
        )
        db.session.add(liquidity_pool)
        db.session.commit()
        

    def test_buy(self):
        
        pool_id = self.pool.id
        asset_id = self.asset.id
        user_id = self.user.id
        USD_in = Decimal(100)

        # Setup: Seed initial balances
        db.session.add(UserBalance(user_id=user_id, quantity=1000))
        db.session.add(PortfolioItem(user_id=user_id, asset_id=asset_id, quantity=0))
        db.session.commit()

        initial_user_asset_quantity = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity
        initial_user_balance = UserBalance.current(user_id=user_id).quantity
        initial_market_balance = MarketBalance.current()
        if initial_market_balance is not None:
            initial_market_balance = initial_market_balance.quantity
        else:
            initial_market_balance = 0

        # Perform the buy operation
        self.liquidity_service.buy(pool_id, user_id, USD_in, asset_id)
        db.session.commit()

        # Verify user's USD balance is decreased
        new_user_balance =  UserBalance.current(user_id=user_id).quantity
        self.assertNotEqual(initial_user_balance, new_user_balance)

        # Calculate expected asset quantity acquired
        transaction_fee = USD_in * Decimal('0.01')
        asset_quantity_acquired = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity

        # Verify market balance is increased by transaction fee
        market_balance = MarketBalance.current().quantity
        self.assertEqual(market_balance, initial_market_balance + transaction_fee)

        # Verify the user's asset quantity
        portfolio_item = PortfolioItem.current(user_id=user_id, asset_id=asset_id)
        self.assertIsNotNone(portfolio_item)
        self.assertEqual(portfolio_item.quantity, initial_user_asset_quantity + asset_quantity_acquired)

    def test_sell(self):
        pool_id = self.pool.id
        user_id = self.user.id
        asset_id = self.asset.id
        asset_quantity_to_sell = Decimal(50)

        # Setup: Seed initial balances
        db.session.add(UserBalance(user_id=user_id, quantity=100))
        db.session.commit()
        db.session.add(PortfolioItem(user_id=user_id, asset_id=asset_id, quantity=100))
        db.session.commit()

        initial_user_balance = UserBalance.current(user_id=user_id).quantity
        initial_portfolio_asset_quantity = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity
        initial_pool_asset_quantity = LiquidityPool.current(pool_id).asset_quantity

        # Perform the sell operation
        self.liquidity_service.sell(pool_id=pool_id, user_id=user_id, asset_id=asset_id, asset_quantity=asset_quantity_to_sell,)
        db.session.commit()

        # Verify user's USD balance is increased
        new_user_balance = UserBalance.current(user_id=user_id).quantity
        self.assertNotEqual(initial_user_balance, new_user_balance)

        # Verify the user's asset quantity is decreased
        portfolio_item = PortfolioItem.current(user_id=user_id, asset_id=asset_id)
        self.assertIsNotNone(portfolio_item)
        self.assertEqual(portfolio_item.quantity, initial_portfolio_asset_quantity - asset_quantity_to_sell)

        # Verify the liquidity pool's asset quantity
        pool_asset_quantity = LiquidityPool.current(pool_id).asset_quantity
        self.assertEqual(pool_asset_quantity, initial_pool_asset_quantity + asset_quantity_to_sell)


    def test_add_liquidity_with_USD(self):
        pool_id = self.pool.id
        asset_id = self.asset.id
        user_id = self.user.id
        user_usd = Decimal(100)
        user_asset_quantity = Decimal(0)

        # Setup: Seed initial balances
        db.session.add(UserBalance(user_id=user_id, quantity=1000))
        db.session.commit()
        initial_user_balance = UserBalance.current(user_id=user_id).quantity
        initial_pool = LiquidityPool.current(pool_id)
        initial_liquidity_holding = LiquidityHolding(user_id=user_id, pool_id=pool_id, asset_id=asset_id, quantity=0)
        initial_pool_usd_quantity = initial_pool.USD_quantity

        # Perform the add liquidity operation
        expected_liquidity_tokens_issued = LiquidityPool.current(pool_id).tokens_to_issue(USD_deposit=user_usd, asset_deposit=0)
        self.liquidity_service.add_liquidity(pool_id, asset_id, user_usd, user_asset_quantity, user_id)
        # Verify user's USD balance is decreased by the provided liquidity amount
        user_usd_balance_after = UserBalance.current(user_id=user_id).quantity
        expected_user_usd_balance_after = initial_user_balance - user_usd
        self.assertEqual(user_usd_balance_after, expected_user_usd_balance_after)

        # Verify liquidity pool's USD quantity
        updated_pool = LiquidityPool.current(pool_id)
        self.assertEqual(updated_pool.USD_quantity, initial_pool_usd_quantity + user_usd)

        # Verify liquidity tokens issued to user
        liquidity_holding_after = LiquidityHolding.current(pool_id, user_id).quantity

        self.assertEqual(liquidity_holding_after, initial_liquidity_holding.quantity + expected_liquidity_tokens_issued)
        
        self.assertEqual(updated_pool.total_liquidity_tokens, initial_pool.total_liquidity_tokens + expected_liquidity_tokens_issued)


    def test_add_liquidity_with_asset(self):
        pool_id = self.pool.id
        user_id = self.user.id
        asset_id = self.asset.id
        user_usd = Decimal(0)
        user_asset_quantity = Decimal(50)

        # Setup: Seed initial balances
        db.session.add(PortfolioItem(user_id=user_id, asset_id=asset_id, quantity=200))
        db.session.commit()
        initial_pool = LiquidityPool.current(pool_id)
        initial_pool_asset_quantity = initial_pool.asset_quantity
        initial_user_asset_quantity = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity
        initial_liquidity_holding = LiquidityHolding(user_id=user_id, pool_id=pool_id, asset_id=asset_id, quantity=0)

        # Perform the add liquidity operation
        expected_liquidity_tokens_issued = LiquidityPool.current(pool_id).tokens_to_issue(USD_deposit=0, asset_deposit=user_asset_quantity) # For testing (no side effects)
        self.liquidity_service.add_liquidity(pool_id, asset_id, user_usd, user_asset_quantity, user_id)
        

        # Verify user's asset quantity is decreased
        user_asset_quantity_after = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity
        expected_user_asset_quantity_after = initial_user_asset_quantity - user_asset_quantity
        self.assertEqual(user_asset_quantity_after, expected_user_asset_quantity_after)

        # Verify liquidity pool's asset quantity
        updated_pool = LiquidityPool.current(pool_id)
        self.assertEqual(updated_pool.asset_quantity, initial_pool_asset_quantity + user_asset_quantity)

        # Verify liquidity tokens issued to user
        liquidity_holding_after = LiquidityHolding.current(pool_id, user_id).quantity

        self.assertEqual(liquidity_holding_after, initial_liquidity_holding.quantity + expected_liquidity_tokens_issued)
        
        self.assertEqual(updated_pool.total_liquidity_tokens, initial_pool.total_liquidity_tokens + expected_liquidity_tokens_issued)


    def test_sell_with_pool_id_none(self):
        asset_id = self.asset.id
        user_id = self.user.id
        asset_quantity_to_sell = Decimal(50)

        # Setup: Seed initial balances without specifying pool_id
        db.session.add(UserBalance(user_id=user_id, quantity=100))
        db.session.add(PortfolioItem(user_id=user_id, asset_id=asset_id, quantity=100))
        db.session.commit()

        # Store initial state for comparison
        initial_user_balance = UserBalance.current(user_id=user_id).quantity
        initial_user_asset_quantity = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity

        # Perform the sell operation without specifying pool_id
        USD_acquired = self.liquidity_service.sell(None, user_id, asset_id, asset_quantity_to_sell)

        # Fetch the updated state
        new_user_balance = UserBalance.current(user_id=user_id).quantity
        new_user_asset_quantity = PortfolioItem.current(user_id=user_id, asset_id=asset_id).quantity

        # Assertions to verify the sell operation was successful
        self.assertEqual(new_user_balance, initial_user_balance + USD_acquired, "User's USD balance did not increase correctly.")
        self.assertEqual(new_user_asset_quantity, initial_user_asset_quantity - asset_quantity_to_sell, "User's asset quantity did not decrease correctly.")
