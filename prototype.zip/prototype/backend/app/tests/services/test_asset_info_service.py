from decimal import Decimal
from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.services import AssetInfoService
from app.models import LiquidityPool, AssetDividend, PayoutCycle
from app.tests.factories import LiquidityPoolFactory, AssetDividendFactory, AssetFactory, PortfolioItemFactory

class TestAssetInfoService(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.asset_id = AssetFactory().flush().id
        self.service = AssetInfoService(self.asset_id)

        max_payout_cycle = PayoutCycle.max_id()
        LiquidityPoolFactory.create(asset_quantity=100, USD_quantity=50, asset_id=self.asset_id)
        LiquidityPoolFactory.create(asset_quantity=20, USD_quantity=200, asset_id=self.asset_id)
        LiquidityPoolFactory.create(asset_quantity=200, USD_quantity=100, asset_id=self.asset_id)
        LiquidityPoolFactory.create(asset_quantity=1, USD_quantity=1, asset_id=self.asset_id)
        AssetDividendFactory.create(USD=50, asset_id=self.asset_id, payout_cycle_id=max_payout_cycle)
        PortfolioItemFactory.create(asset_id=self.asset_id, quantity = 100)
        db.session.commit()

    def test_high_price(self):
        result = self.service.high_price()
        self.assertEqual(result, Decimal('10')) 

    def test_low_price(self):
        result = self.service.low_price()
        self.assertEqual(result, Decimal('0.5')) 

    def test_price(self):
        result = self.service.price()
        self.assertEqual(result, Decimal('1'))  

    def test_price_to_dividend_ratio(self):
        result = self.service.price_to_dividend_ratio()
        self.assertEqual(result, Decimal('2.0'))

    def test_trade_volume(self):
        result = self.service.trade_volume()
        self.assertEqual(result, 349)  # abs(100-200) + abs(200-50) + abs(1-100)

    def test_price_to_dividend_ratio_no_dividends(self):
        # Delete all dividends for this asset from the database for this test
        AssetDividend.query.filter_by(asset_id=self.asset_id).delete()
        db.session.commit()

        result = self.service.price_to_dividend_ratio()
        self.assertEqual(result, float('inf'))  # Should return infinity when no dividends
