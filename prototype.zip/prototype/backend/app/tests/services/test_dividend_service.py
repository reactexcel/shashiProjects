from unittest.mock import patch
from math import isclose
from decimal import Decimal
from app.database import db
from app.models import PortfolioItem, Asset, AssetDividend, MarketBalance, DividendPayout, UserBalance, PayoutCycle
from app.services.dividend_service import DividendService, PayoutCalculationContext
from ..base_test_case import BaseTestCase
from app.tests.factories import AirMeasureFactory, AssetFactory, ProfileFactory, DividendPayoutFactory, UserBalanceFactory, MarketBalanceFactory, PortfolioItemFactory
import random

class TestDividendService(BaseTestCase):
    
    def setUp(self):
        super().setUp()
        db.drop_all()
        super().setUp()

    def test_distribute_dividends_with_proper_value(self):
        fees = Decimal(100)
        MarketBalanceFactory(quantity=fees)
        dividend_payouts = fees * DividendService.dividend_rate
        dividend_service = DividendService()
        dividend_service.distribute_dividends()
        self.assertEqual(MarketBalance.current().quantity, fees - dividend_payouts)

    def test_distribute_dividends_and_calls_methods(self):
        fees = Decimal(100)
        MarketBalanceFactory(quantity=fees)
        dividend_service = DividendService()
        user_total_payouts_mock = {} 
        db_items_mock = []
        with patch.object(dividend_service, 'fees_to_distribute', return_value=fees), \
            patch.object(dividend_service, 'get_latest_portfolio_items') as mock_get_latest_portfolio_items, \
            patch.object(dividend_service, 'calculate_user_payouts', return_value=(user_total_payouts_mock, db_items_mock)) as mock_calculate_user_payouts, \
            patch.object(dividend_service, 'update_user_balances') as mock_update_user_balances, \
            patch.object(dividend_service, 'save_dividend_payouts') as mock_save_dividend_payouts:
            dividend_service.distribute_dividends()
            mock_get_latest_portfolio_items.assert_called_once()
            mock_update_user_balances.assert_called_once()
            mock_save_dividend_payouts.assert_called_once()


    def test_calculate_user_payouts(self):
        dividend_service = DividendService()
        
        user = ProfileFactory()
        air_measures = AirMeasureFactory.create_batch(size=5)
        db.session.flush()
        asset_ids = [air_measure.asset_id for air_measure in air_measures]

        latest_portfolio_items = [PortfolioItemFactory(asset_id=asset_id, user_id=user.id) for asset_id in asset_ids]
        db.session.flush()
        
        fees_to_distribute = Decimal(100)
        user_total_payouts, _ = dividend_service.calculate_user_payouts(latest_portfolio_items, fees_to_distribute)
        self.assertTrue(user_total_payouts)


    def test_calculate_user_payouts_multiple_users(self):
        dividend_service = DividendService()

        users = ProfileFactory.create_batch(size=10)
        db.session.flush()
        user_ids = [user.id for user in users]

        air_measures = AirMeasureFactory.create_batch(size=4)
        db.session.flush()
        asset_ids = [air_measure.asset_id for air_measure in air_measures]

        # Create PortfolioItem objects with asset_ids and user_ids
        latest_portfolio_items = []
        for user_id in user_ids:
            for asset_id in asset_ids:
                portfolio_item = PortfolioItemFactory(asset_id=asset_id, user_id=user_id)
                latest_portfolio_items.append(portfolio_item)
        db.session.flush()

        fees_to_distribute = Decimal(100)
        user_total_payouts, _ = dividend_service.calculate_user_payouts(latest_portfolio_items, fees_to_distribute)

        mean_value = sum(user_total_payouts.values()) / len(user_total_payouts)
        # Validate the user_total_payouts for each user
        for _, payout in user_total_payouts.items():
            self.assertTrue(isclose(payout, mean_value, rel_tol=Decimal('0.000000000001')))
    

    def test_calculate_user_payouts_multiple_users_different_assets(self):
        dividend_service = DividendService()
        users = ProfileFactory.create_batch(size=10)
        db.session.flush()
        assets = AssetFactory.create_batch(size=5)
        db.session.flush()
        latest_portfolio_items = [
            PortfolioItemFactory(asset_id=assets[0].id, user_id=users[0].id, quantity=100),
            PortfolioItemFactory(asset_id=assets[1].id, user_id=users[0].id, quantity=100),
            PortfolioItemFactory(asset_id=assets[1].id, user_id=users[1].id, quantity=100),
            PortfolioItemFactory(asset_id=assets[2].id, user_id=users[1].id, quantity=100),
            PortfolioItemFactory(asset_id=assets[3].id, user_id=users[2].id, quantity=100),
            PortfolioItemFactory(asset_id=assets[4].id, user_id=users[2].id, quantity=100),
        ]
        db.session.flush()

        # Define the mock asset_payout_percentages
        mock_asset_payout_percentages = {
            asset.id: Decimal(1/len(assets)) for asset in assets
        }

        fees_to_distribute = Decimal(100)
        total_asset_quantities = {4: Decimal('100'), 3: Decimal('100'), 1: Decimal('100'), 5: Decimal('100'), 2: Decimal('200')}

        # Calculate expected payouts based on portfolio items and mock percentages
        expected_payouts = {}
        for item in latest_portfolio_items:
            user_id = item.user_id
            asset_id = item.asset_id
            quantity = item.quantity
            payout_percentage = mock_asset_payout_percentages[asset_id]
            payout = (quantity/total_asset_quantities[asset_id]) * payout_percentage * fees_to_distribute
            expected_payouts[user_id] = expected_payouts.get(user_id, Decimal(0)) + payout

        # Mock the asset_payout_percentages method and run the actual method
        with patch.object(dividend_service, 'asset_payout_percentages', return_value=mock_asset_payout_percentages):
            with patch.object(PortfolioItem, 'total_asset_quantities', return_value=total_asset_quantities):
                user_total_payouts, _ = dividend_service.calculate_user_payouts(latest_portfolio_items, fees_to_distribute)

        # Validate the user_total_payouts for each user
        net_payouts = 0
        rel_tol = Decimal('0.0000001')
        for user_id, expected_payout in expected_payouts.items():
            actual_payout = user_total_payouts[user_id]
            net_payouts += actual_payout
            self.assertTrue(isclose(actual_payout, expected_payout, rel_tol=rel_tol))
        self.assertTrue(isclose(net_payouts, fees_to_distribute, rel_tol=rel_tol))

    def test_calculate_user_payouts_multiple_users_same_asset_different_quantities(self):
        dividend_service = DividendService()
        users = ProfileFactory.create_batch(size=10)
        db.session.flush()
        asset = AssetFactory.create()
        db.session.flush()
        latest_portfolio_items = [PortfolioItemFactory(asset_id=asset.id, user_id=user.id, quantity=random.randint(50, 150)) for user in users]
        db.session.flush()

        # Define the mock asset_payout_percentages
        mock_asset_payout_percentages = {asset.id: Decimal(1)}

        fees_to_distribute = Decimal(100)
        total_asset_quantities = {asset.id: sum(item.quantity for item in latest_portfolio_items)}

        # Calculate expected payouts based on portfolio items and mock percentages
        expected_payouts = {}
        for item in latest_portfolio_items:
            user_id = item.user_id
            asset_id = item.asset_id
            quantity = item.quantity
            payout_percentage = mock_asset_payout_percentages[asset_id]
            payout = Decimal(quantity / total_asset_quantities[asset_id]) * payout_percentage * fees_to_distribute
            expected_payouts[user_id] = expected_payouts.get(user_id, Decimal(0)) + payout

        # Mock the asset_payout_percentages method and run the actual method
        with patch.object(dividend_service, 'asset_payout_percentages', return_value=mock_asset_payout_percentages):
            with patch.object(PortfolioItem, 'total_asset_quantities', return_value=total_asset_quantities):
                user_total_payouts, _ = dividend_service.calculate_user_payouts(latest_portfolio_items, fees_to_distribute)

        # Validate the user_total_payouts for each user
        net_payouts = 0
        rel_tol = Decimal('0.0000001')
        for user_id, expected_payout in expected_payouts.items():
            actual_payout = user_total_payouts[user_id]
            net_payouts += actual_payout
            self.assertTrue(isclose(actual_payout, expected_payout, rel_tol=rel_tol))
        self.assertTrue(isclose(net_payouts, fees_to_distribute, rel_tol=rel_tol))


    def test_calculate_payout_for_item(self):
        dividend_service = DividendService()
        asset = AssetFactory()
        user = ProfileFactory()
        db.session.flush()
        item = PortfolioItemFactory(asset_id=asset.id, user_id=user.id, quantity=100).flush()

        total_asset_quantities = {asset.id: 200}
        asset_payout_percentages = {asset.id: Decimal('0.2')}
        fees_to_distribute = Decimal(100)
        context = PayoutCalculationContext(
            total_asset_quantities=total_asset_quantities,
            asset_payout_percentages=asset_payout_percentages,
            fees_to_distribute=fees_to_distribute
        )

        payout = dividend_service._calculate_user_payout_for_item(item, context)
        expected_payout = Decimal('10.00')
        self.assertEqual(payout, expected_payout)

    
    def test_distribute_dividends_different_rates(self):
        fees = Decimal(100)
        # Test different dividend rates
        for rate in [Decimal('0.01'), Decimal('0.05'), Decimal('0.10')]:
            MarketBalanceFactory(quantity=fees)  # Reset the MarketBalance
            DividendService.dividend_rate = rate
            dividend_payouts = fees * rate
            dividend_service = DividendService()
            dividend_service.distribute_dividends()
            self.assertEqual(MarketBalance.current().quantity, fees - dividend_payouts)


    def test_distribute_dividends_zero_fees(self):
        fees = Decimal(0)
        MarketBalanceFactory(quantity=fees)
        dividend_service = DividendService()
        dividend_service.distribute_dividends()
        self.assertEqual(MarketBalance.current().quantity, fees)


    def test_create_dividend_payout(self):
        dividend_service = DividendService()
        user = ProfileFactory()
        asset = AssetFactory()
        db.session.flush()
        amount_in_usd = Decimal('10.00')
        dividend_payout = dividend_service._create_dividend_payout(user.id, asset.id, amount_in_usd)

        self.assertEqual(dividend_payout.user_id, user.id)
        self.assertEqual(dividend_payout.asset_id, asset.id)
        self.assertEqual(dividend_payout.amount_in_usd, amount_in_usd)


    def test_fee_pool_calculation(self):
        fee_pool_quantity = Decimal(1000)
        MarketBalanceFactory(quantity=fee_pool_quantity)
        dividend_service = DividendService()
        fees_to_distribute = dividend_service.fees_to_distribute()
        self.assertEqual(fees_to_distribute, Decimal(DividendService.dividend_rate) * fee_pool_quantity)

    def test_user_balance_update(self):
        balances = UserBalanceFactory.create_batch(size=2)
        db.session.flush()
        user_ids = [balance.user_id for balance in balances]
        user_total_payouts = {user_ids[0]: Decimal(100), user_ids[1]: Decimal(50)}
        dividend_service = DividendService()
        dividend_service.update_user_balances(user_total_payouts)
        db.session.commit()
        for user_id, payout in user_total_payouts.items():
            user_initial_balance = next((balance.quantity for balance in balances if balance.user_id == user_id), 0)
            self.assertEqual(UserBalance.current(user_id).quantity, payout + user_initial_balance)

    def test_get_latest_portfolio_items(self):
        latest_portfolio_items = PortfolioItemFactory.create_batch(size=5)
        dividend_service = DividendService()
        items = dividend_service.get_latest_portfolio_items()
        self.assertEqual(len(items), len(latest_portfolio_items))

    def test_asset_payout_percentages(self):
        air_measures = AirMeasureFactory.create_batch(size=5)
        dividend_service = DividendService()
        asset_percentages = dividend_service.asset_payout_percentages()
        self.assertEqual(len(asset_percentages), len(air_measures))

    def test_asset_payout_percentages_scaled_inverse(self):
        # Create mock AirMeasure data
        air_measures = [
            AirMeasureFactory(pm_25_10_minute=10),
            AirMeasureFactory(pm_25_10_minute=20),
            AirMeasureFactory(pm_25_10_minute=30),
        ]
        db.session.flush()
        
        # Compute the expected scaled inverse percentages
        scaled_pm25_values = [Decimal(x.pm_25_10_minute) ** Decimal(-0.5) for x in air_measures]
        total_scaled_pm25 = sum(scaled_pm25_values)
        expected_percentages = [x / total_scaled_pm25 for x in scaled_pm25_values]

        # Test asset_payout_percentages method
        dividend_service = DividendService()
        asset_percentages = dividend_service.asset_payout_percentages()
        
        # Validate the result
        for asset, expected in zip(asset_percentages.keys(), expected_percentages):
            self.assertTrue(isclose(asset_percentages[asset], expected, rel_tol=Decimal('0.0000001')))

    def test_save_dividend_payouts(self):
        db_items = [DividendPayoutFactory()]
        db.session.flush()
        dividend_service = DividendService()
        dividend_service.save_dividend_payouts(db_items)
        self.assertEqual(DividendPayout.query.count(), len(db_items))

    def test_get_new_payout_cycle(self):
        dividend_service = DividendService()
        dividend_service.get_payout_cycle()
        self.assertEqual(PayoutCycle.query.count(), 1)
        dividend_service.get_payout_cycle()
        db.session.flush()
        self.assertEqual(PayoutCycle.query.count(), 1)

    def test_make_asset_dividend_payout(self):
        asset1 = Asset(name="Asset1")
        asset2 = Asset(name="Asset2")
        db.session.add_all([asset1, asset2])
        db.session.commit()

        asset_payout_percents = {asset1.id: Decimal('0.6'), asset2.id: Decimal('0.4')}
        fees_to_distribute = Decimal('100')

        dividend_service = DividendService()
        dividend_service.make_asset_dividend_payouts(asset_payout_percents, fees_to_distribute)
        payout_cycle_id = PayoutCycle.query.order_by(PayoutCycle.id.desc()).first().id
        payouts = AssetDividend.query.all()

        self.assertEqual(len(payouts), 2)
        self.assertEqual(payouts[0].USD, Decimal('60'))
        self.assertEqual(payouts[1].USD, Decimal('40'))
        self.assertEqual(payouts[-1].payout_cycle_id, payout_cycle_id)

        dividend_service = DividendService()
        dividend_service.make_asset_dividend_payouts(asset_payout_percents, fees_to_distribute)
        payouts = AssetDividend.query.all()
        self.assertEqual(payouts[-1].payout_cycle_id, payout_cycle_id+1)


    def test_make_asset_dividend_payout_all_zeros(self):
        asset1 = Asset(name="Asset1")
        asset2 = Asset(name="Asset2")
        db.session.add_all([asset1, asset2])
        db.session.commit()

        asset_payout_percents = {asset1.id: Decimal('0'), asset2.id: Decimal('0')}
        fees_to_distribute = Decimal('100')

        dividend_service = DividendService()
        dividend_service.make_asset_dividend_payouts(asset_payout_percents, fees_to_distribute)

        payouts = AssetDividend.query.all()

        self.assertEqual(len(payouts), 2)
        self.assertEqual(payouts[0].USD, Decimal('0'))
        self.assertEqual(payouts[1].USD, Decimal('0'))

    def test_make_asset_dividend_payout_rounding(self):
        asset1 = Asset(name="Asset1")
        db.session.add(asset1)
        db.session.commit()

        asset_payout_percents = {asset1.id: Decimal('0.3333333333333333333333333')}
        fees_to_distribute = Decimal('100')

        dividend_service = DividendService()
        dividend_service.make_asset_dividend_payouts(asset_payout_percents, fees_to_distribute)

        payout = AssetDividend.query.first()

        self.assertEqual(payout.USD, Decimal('33.3333333333333333333333300'))

    def test_make_asset_dividend_payout_db_failed_transaction(self):
        asset1 = Asset(name="Asset1")
        db.session.add(asset1)
        db.session.commit()

        asset_payout_percents = {asset1.id: Decimal('0.6')}
        fees_to_distribute = Decimal('100')

        with patch.object(db.session, "commit", side_effect=Exception("DB Error")):
            dividend_service = DividendService()
            try:
                dividend_service.make_asset_dividend_payouts(asset_payout_percents, fees_to_distribute)
            except Exception:
                pass

        payouts = AssetDividend.query.all()

        self.assertEqual(len(payouts), 0)