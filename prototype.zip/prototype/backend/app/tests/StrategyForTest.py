
from app.strategies.strategy_base import StrategyBase
from app.models import PortfolioItem, Pool, UserBalance, Pool
from app.services import LiquidityService
from app.database import db
import random
from decimal import Decimal
class StrategyForTest(StrategyBase):
    def __init__(self, user_id):
        super().__init__(user_id)

    def trade(self):
        self.sell()
        self.buy()
        return f"Trading using Strategy Random for user {self.user_id}"
    
    def buy(self):
        buy_allocations = self.get_random_buy_allocations()
        for asset_id, allocation_amount in buy_allocations.items():
            LiquidityService().buy(
                pool_id=None,
                user_id=self.user_id,
                USD_in=allocation_amount,
                asset_id=asset_id
            )
        db.session.commit()

    def get_random_buy_allocations(self):
        cash_balance = UserBalance.current(user_id=self.user_id).quantity
        pools = Pool.query.all()
        asset_ids = [pool.asset_id for pool in pools]

        allocation_ratios = [random.random() for _ in asset_ids]
        total_ratio = sum(allocation_ratios)

        allocation_ratios = [ratio / total_ratio for ratio in allocation_ratios]
        allocations = {asset_id: Decimal(ratio) * cash_balance - 1 for asset_id, ratio in zip(asset_ids, allocation_ratios)}
        return allocations


    def sell(self):
        portfolio_items = PortfolioItem.latest_user_asset_pairings_for_user(
            user_id=self.user_id
        )
        for portfolio_item in portfolio_items:
            asset_id = portfolio_item.asset_id
            pool_id = Pool.query.filter_by(asset_id=asset_id).first().id
            selling_quantity = Decimal(random.random()) * portfolio_item.quantity
            LiquidityService().sell(
                pool_id=pool_id, 
                user_id=self.user_id,
                asset_id=asset_id,
                asset_quantity=selling_quantity
            )
        db.session.commit()
