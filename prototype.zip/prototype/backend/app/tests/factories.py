import factory
from factory import lazy_attribute
from decimal import Decimal
from app.database import db
from app.models import AirMeasure, AssetDividend, PriceHistory, LiquidityPool, Profile, Pool, Asset, PortfolioItem, MarketBalance, DividendPayout, UserBalance, PayoutCycle
from datetime import datetime
from sqlalchemy.exc import IntegrityError

class BaseFactory(factory.alchemy.SQLAlchemyModelFactory):
    class Meta:
        abstract = True

#     def flush(self):
#         db.session.flush()
#         return self

def get_new_asset_id(create_pool=True):
    asset = AssetFactory(create_pool=create_pool).flush()
    return asset.id

def get_user_id(_=''):
    user = ProfileFactory()
    db.session.flush()
    return user.id

def get_new_pool_id(_=''):
    existing_asset_id = get_new_asset_id()
    existing_pool = Pool.query.filter_by(asset_id=existing_asset_id).first()
    if existing_pool is None:
        pool = PoolFactory().flush()
        return pool.id
    return existing_pool.id

def get_last_pool_asset_id(_=''):
    pool_id = get_new_pool_id()
    pool = Pool.query.filter_by(id=pool_id).first()
    return pool.asset_id


class ProfileFactory(BaseFactory):
    class Meta:
        model = Profile
        sqlalchemy_session = db.session

    name = factory.Faker('name')
    email = factory.Faker('email')
    auth0_user_id = factory.Faker('uuid4')
    auto_rebalance = False

class AirMeasureFactory(BaseFactory):
    class Meta:
        model = AirMeasure
        sqlalchemy_session = db.session

    pm_25_10_minute = 25
    sensor_count =  1
    asset_id = factory.LazyAttribute(get_new_asset_id)



class AssetFactory(BaseFactory):
    class Meta:
        model = Asset
        sqlalchemy_session = db.session

    name = factory.Faker('city')

    class Params:
        create_pool=True

    @factory.post_generation
    def create_pool(self, create, value):
        create_pool = getattr(self, 'create', False)
        if create_pool:
            pool = Pool.query.filter_by(asset_id=self.id).first()
            if pool is None:
                PoolFactory(asset_id=(self.id)).flush()


class PoolFactory(BaseFactory):
    class Meta:
        model = Pool
        sqlalchemy_session = db.session
    asset_id = factory.LazyAttribute(get_new_asset_id)
    name = factory.Faker('name')
    description = factory.Faker('sentence')


class LiquidityPoolFactory(BaseFactory):
    class Meta:
        model = LiquidityPool
        sqlalchemy_session = db.session
    
    class Params:
        create=False

    @factory.lazy_attribute
    def payout_cycle_id(self):
        return PayoutCycle.max_id()
    
    @factory.lazy_attribute
    def pool_id(self):
        create = getattr(self, 'create', False)
        pool = Pool.query.first()
        if pool == None or create == True:
            pool = PoolFactory().flush()
        return pool.id
    
    @factory.lazy_attribute
    def asset_id(self):
        return Pool.query.filter_by(id=self.pool_id).first().asset_id

    asset_quantity = Decimal("50000.00")
    USD_quantity = Decimal("50000.00")
    total_liquidity_tokens = Decimal("50000.00")

class PortfolioItemFactory(BaseFactory):
    class Meta:
        model = PortfolioItem
        sqlalchemy_session = db.session

    user_id = factory.LazyAttribute(get_user_id)
    asset_id = factory.LazyAttribute(get_last_pool_asset_id)
    quantity = Decimal('100.0')


class PriceHistoryFactory(BaseFactory):
    class Meta:
        model = PriceHistory
        sqlalchemy_session = db.session

    asset_id = factory.LazyAttribute(get_last_pool_asset_id)
    price = Decimal('2.0')
    time_frequency = 'minute'
    price_time = datetime.now()

class MarketBalanceFactory(BaseFactory):
    class Meta:
        model = MarketBalance
        sqlalchemy_session = db.session

    quantity = Decimal('1000.0')

class AssetDividendFactory(BaseFactory):
    class Meta:
        model = AssetDividend
        sqlalchemy_session = db.session
    asset_id = factory.LazyAttribute(get_new_asset_id)
    USD = Decimal("100.0")

    @factory.lazy_attribute
    def payout_cycle_id(self):
        return PayoutCycle.max_id()


class DividendPayoutFactory(BaseFactory):
    class Meta:
        model = DividendPayout
        sqlalchemy_session = db.session

    user_id = factory.LazyAttribute(get_user_id)
    asset_id = factory.LazyAttribute(get_last_pool_asset_id)
    amount_in_usd = Decimal('50.0')

class UserBalanceFactory(BaseFactory):

    class Meta:
        model = UserBalance
        sqlalchemy_session = db.session

    user_id = factory.LazyAttribute(get_user_id)
    quantity = Decimal('1000.0')

class PayoutCycleFactory(BaseFactory):
    class Meta:
        model = PayoutCycle
        sqlalchemy_session = db.session

