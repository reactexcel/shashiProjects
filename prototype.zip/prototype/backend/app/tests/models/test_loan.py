from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.Loan import Loan, OPEN, DEFAULTED, CLOSED, LIQUIDATION_RATE
from app.models import LendingPool, Asset, Profile, UserBalance, PortfolioItem, Pool, LiquidityPool, LoanDeposit
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal
from unittest import mock


class LoanTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        db.session.begin_nested()
        self.user = Profile(name='a', email='b')
        self.asset = Asset(name='SF')
        db.session.add_all([self.asset, self.user])
        db.session.flush()
        self.user_id = self.user.id
        self.asset_id = self.asset.id
        self.initail_asset_quantity = Decimal('100.00')

        self.pool = Pool(asset_id=self.asset_id, name=f'pool_{self.asset_id}')
        db.session.add(self.pool)
        db.session.flush()
        self.pool_id = self.pool.id
        db.session.add(LiquidityPool(pool_id=self.pool_id, asset_id=self.asset_id, asset_quantity=100, USD_quantity=100,  total_liquidity_tokens=0))
        db.session.add(UserBalance(user_id=self.user_id, quantity=self.initail_asset_quantity))
        db.session.add(LendingPool(asset_id=self.asset_id, interest_earned=0))
        db.session.add(LoanDeposit(asset_id=self.asset_id, user_id=self.user_id, amount=100))
        db.session.commit()
        self.user_balance = UserBalance.query.filter_by(user_id=self.user_id).first()

    @mock.patch('app.models.LoanHistory.create_history_entry')
    @mock.patch('app.models.PortfolioItem.deposit')
    @mock.patch('app.models.LendingPool.withdraw')
    @mock.patch('app.models.UserBalance.withdraw')
    def test_take_out_loan(self, mock_user_withdraw, mock_lending_pool_withdraw, mock_portfolio_deposit,
                           mock_loan_history_entry):
        loan_amount = Decimal('50.00')
        collateral = Decimal('25.00')

        Loan.take_out_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, collateral=collateral)
        expected_loan = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id)

        mock_user_withdraw.assert_called_once_with(user_id=self.user_id, quantity=collateral)
        mock_lending_pool_withdraw.assert_called_once_with(asset_id=self.asset_id, amount=loan_amount)
        mock_portfolio_deposit.assert_called_once_with(asset_id=self.asset_id, user_id=self.user_id,
                                                       asset_quantity=loan_amount)
        mock_loan_history_entry.assert_called_once_with(loan=expected_loan, commit=False)

        assert expected_loan.amount == loan_amount
        assert expected_loan.remaining_collateral == collateral

    def test_take_out_loan_excess_amount(self):
        loan_amount = Decimal('500.00')
        collateral = Decimal('250.00')
        with self.assertRaises(Exception):
            Loan.take_out_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, collateral=collateral)

    def test_take_out_loan_excess_amount_in_lending_pool(self):
        loan_amount = Decimal('500.00')
        collateral = Decimal('25.00')
        with self.assertRaises(Exception):
            Loan.take_out_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, collateral=collateral)

    @mock.patch('app.models.LoanHistory.create_history_entry')
    @mock.patch('app.models.PortfolioItem.withdraw')
    def test_pay_off_loan(self, mock_portfolio_withdraw, mock_loan_history_entry):
        loan_amount = Decimal('50.00')
        new_loan = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, remaining_collateral=0)
        db.session.add(new_loan)
        db.session.flush()
        Loan.pay_off_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount)
        expected_loan = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id)

        mock_portfolio_withdraw.assert_called_once_with(asset_id=self.asset_id, user_id=self.user_id,
                                                        asset_quantity=loan_amount)
        mock_loan_history_entry.assert_called_once_with(loan=expected_loan, commit=False)
        assert expected_loan.amount == 0

    def test_pay_off_loan_excess_amount(self):
        loan_amount = Decimal('50.00')
        collateral = Decimal('25.00')
        Loan.take_out_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, collateral=collateral)
        with self.assertRaises(Exception):
            Loan.pay_off_loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount + 1)

    @mock.patch('app.models.LoanHistory.create_history_entry')
    @mock.patch('app.models.UserBalance.withdraw')
    def test_deposit_collateral(self, mock_user_balance_withdraw, mock_loan_history_entry):
        collateral = Decimal('25.00')
        current_collateral = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id).remaining_collateral
        Loan.deposit_collateral(user_id=self.user_id, asset_id=self.asset_id, amount=collateral)
        loan = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id)

        mock_user_balance_withdraw.assert_called_once_with(user_id=self.user_id, quantity=collateral)
        mock_loan_history_entry.assert_called_once_with(loan=loan, commit=False)

        assert loan.remaining_collateral == collateral + current_collateral

    def test_deposit_collateral_excess_amount(self):
        collateral = self.user_balance.quantity + 1
        with self.assertRaises(Exception):
            Loan.deposit_collateral(user_id=self.user_id, asset_id=self.asset_id, amount=collateral)

    @mock.patch('app.models.LoanHistory.create_history_entry')
    @mock.patch('app.models.UserBalance.deposit')
    def test_withdraw_collateral(self, mock_user_deposit, mock_loan_history_entry):
        collateral = Decimal('25.00')
        db.session.add(Loan(user_id=self.user_id, asset_id=self.asset_id, amount=0, remaining_collateral=collateral))
        db.session.commit()
        Loan.withdraw_collateral(user_id=self.user_id, asset_id=self.asset_id, amount=collateral)
        expected_loan = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id)

        mock_user_deposit.assert_called_once_with(user_id=self.user_id, quantity=collateral)
        mock_loan_history_entry.assert_called_once_with(loan=expected_loan, commit=False)

        assert expected_loan.remaining_collateral == 0

    def test_withdraw_collateral_excess_amount(self):
        collateral = Decimal('25.00')
        Loan.deposit_collateral(user_id=self.user_id, asset_id=self.asset_id, amount=collateral)
        with self.assertRaises(Exception):
            Loan.withdraw_collateral(user_id=self.user_id, asset_id=self.asset_id, amount=collateral + 1)

    def test_current_open_loans(self):
        loan_amount = Decimal('50.00')
        collateral = Decimal('75.00')

        db.session.add(Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, remaining_collateral=collateral))
        db.session.commit()

        loan = Loan.current_open_loans(asset_id=self.asset_id)

        assert len(loan) == 1
        assert loan[0].user_id == self.user_id
        assert loan[0].asset_id == self.asset_id
        assert loan[0].amount == loan_amount
        assert loan[0].remaining_collateral == collateral

    def test_current_open_loan(self):
        loan_amount = Decimal('50.00')
        collateral = Decimal('75.00')

        db.session.add(Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, remaining_collateral=collateral))
        db.session.commit()

        loan = Loan.current_open_loan(user_id=self.user_id, asset_id=self.asset_id)

        assert loan.user_id == self.user_id
        assert loan.asset_id == self.asset_id
        assert loan.amount == loan_amount
        assert loan.remaining_collateral == collateral

    @mock.patch('app.services.LiquidityService.buy')
    @mock.patch('app.models.PortfolioItem.withdraw')
    @mock.patch('app.models.Loan.pay_off_loan')
    def test_no_liquidation_due_to_sufficient_collateral(self, mock_pay_off_loan, mock_portfolio_withdraw,
                                                         mock_liquidity_buy):
        loan_amount = Decimal('50.00')
        collateral = Decimal('75.00')
        loan = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        mock_liquidity_buy.return_value = Decimal('50.00')
        loan.liquidate(asset_id=self.asset_id, user_id=self.user_id)
        mock_liquidity_buy.assert_not_called()
        mock_portfolio_withdraw.assert_not_called()
        mock_pay_off_loan.assert_not_called()

        self.assertEqual(loan.status, OPEN)
        self.assertEqual(loan.remaining_collateral, Decimal('75.00'))
        self.assertEqual(loan.amount, Decimal('50.00'))

    @mock.patch('app.models.PortfolioItem.withdraw')
    @mock.patch('app.services.LiquidityService.buy')
    def test_liquidation_with_insufficient_collateral(self, mock_liquidity_buy, mock_portfolio_item_widthdraw):
        amount = 50
        collateral = 25
        asset_id = self.asset_id
        user_id = self.user_id
        PortfolioItem.deposit(asset_id=asset_id, user_id=user_id, asset_quantity=amount*2)
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        mock_liquidity_buy.return_value = collateral

        loan.liquidate(asset_id=asset_id, user_id=user_id)
        mock_liquidity_buy.assert_called_once_with(
            pool_id=None, 
            user_id=user_id, 
            asset_id=asset_id, 
            USD_in=collateral,
            commit=False)
        mock_portfolio_item_widthdraw.assert_called_once_with(
            asset_id=asset_id, 
            user_id=user_id, 
            asset_quantity=collateral)

        self.assertEqual(loan.remaining_collateral, 0)
        self.assertEqual(loan.amount, Decimal('25'))
        self.assertEqual(loan.status, DEFAULTED)

    @mock.patch('app.models.PortfolioItem.withdraw')
    @mock.patch('app.services.LiquidityService.buy')
    def test_successful_liquidation_no_surplus(self, mock_liquidity_buy, mock_portfolio_item_widthdraw):
        amount = 50
        collateral = 54
        bought_amount = 50
        asset_id = self.asset_id
        user_id = self.user_id
        PortfolioItem.deposit(asset_id=asset_id, user_id=user_id, asset_quantity=amount*2)
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        mock_liquidity_buy.return_value = bought_amount

        loan.liquidate(asset_id=asset_id, user_id=user_id)
        mock_liquidity_buy.assert_called_once_with(
            pool_id=None, 
            user_id=user_id, 
            asset_id=asset_id, 
            USD_in=collateral,
            commit=False)
        mock_portfolio_item_widthdraw.assert_called_once_with(
            asset_id=asset_id, 
            user_id=user_id, 
            asset_quantity=bought_amount)

        self.assertEqual(loan.remaining_collateral, 0)
        self.assertEqual(loan.amount, 0)
        self.assertEqual(loan.status, CLOSED)

    @mock.patch('app.models.PortfolioItem.deposit')
    @mock.patch('app.models.PortfolioItem.withdraw')
    @mock.patch('app.services.LiquidityService.buy')
    def test_successful_liquidation_with_surplus(self, mock_liquidity_buy, mock_portfolio_item_widthdraw, mock_portfolio_item_deposit):
        amount = 50
        collateral = 54
        bought_amount = 52
        surplus = bought_amount - amount
        asset_id = self.asset_id
        user_id = self.user_id
        portfolio_item = PortfolioItem(asset_id=asset_id, user_id=user_id, quantity=amount*2)
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(portfolio_item)
        db.session.add(loan)
        db.session.commit()

        mock_liquidity_buy.return_value = bought_amount

        loan.liquidate(asset_id=asset_id, user_id=user_id)
        mock_liquidity_buy.assert_called_once_with(
            pool_id=None, 
            user_id=user_id, 
            asset_id=asset_id, 
            USD_in=collateral,
            commit=False)
        mock_portfolio_item_widthdraw.assert_called_once_with(
            asset_id=asset_id, 
            user_id=user_id, 
            asset_quantity=amount)
        mock_portfolio_item_deposit.assert_called_once_with(
            asset_id=asset_id, 
            user_id=user_id, 
            asset_quantity=surplus)

        self.assertEqual(loan.remaining_collateral, 0)
        self.assertEqual(loan.amount, 0)
        self.assertEqual(loan.status, CLOSED)

    @mock.patch('app.services.LiquidityService.buy')
    def test_liquidate_collateral(self, mock_liquidity_buy):
        amount = 50
        collateral = 50
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        loan, asset_quantity_acquired = Loan.liquidate_collateral(loan=loan)

        mock_liquidity_buy.assert_called_once_with(
            pool_id=None,
            user_id=user_id,
            asset_id=asset_id,
            USD_in=collateral,
            commit=False)

        self.assertEqual(loan.remaining_collateral, 0)

    def test_requires_liquidation(self):
        amount = 50
        collateral = 25
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        self.assertTrue(Loan.requires_liquidation(loan=loan))

    def test_does_not_require_liquidation(self):
        amount = 50
        collateral = 75
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        self.assertFalse(Loan.requires_liquidation(loan=loan))

    @mock.patch('app.models.PortfolioItem.deposit')
    def test_deposit_surplus_during_liquidation(self, mock_portfolio_item_deposit):
        amount = 50
        collateral = 54
        bought_amount = 52
        surplus = bought_amount - amount
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        Loan.deposit_surplus_during_liquidation(loan=loan, asset_quantity_acquired=bought_amount)

        mock_portfolio_item_deposit.assert_called_once_with(
            asset_id=asset_id,
            user_id=user_id,
            asset_quantity=surplus
        )

    def test_amount_to_withdraw_during_liquidation(self):
        amount = 60
        collateral = 54
        asset_quantity_acquired = 50
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        amount_to_withdraw = Loan.amount_to_withdraw_during_liquidation(loan=loan, asset_quantity_acquired=asset_quantity_acquired)

        self.assertEqual(amount_to_withdraw, asset_quantity_acquired)

    def test_amount_to_withdraw_during_liquidation_with_sufficent_asset_quantity_acquired(self):
        amount = 50
        collateral = 25
        asset_quantity_acquired = 60
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()

        amount_to_withdraw = Loan.amount_to_withdraw_during_liquidation(loan=loan, asset_quantity_acquired=asset_quantity_acquired)

        self.assertEqual(amount_to_withdraw, amount)


    def test_usdc_value(self):
        amount = 50
        collateral = 25
        asset_id = self.asset_id
        user_id = self.user_id
        loan = Loan(user_id=user_id, asset_id=asset_id, amount=amount, remaining_collateral=collateral)
        db.session.add(loan)
        db.session.commit()
        exchange_rate = LiquidityPool.current_with_asset_id(asset_id=self.asset_id).exchange_rate()
        self.assertEqual(loan.usdc_value(), amount * exchange_rate)


    def test_current_outstanding_loan_amount_one_open_loan(self):
        loan_amount = Decimal('100.00')
        loan = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount, status='open')
        db.session.add(loan)
        db.session.commit()
        self.assertEqual(Loan.current_outstanding_loan_amount(asset_id=self.asset_id), loan_amount)

    def test_current_outstanding_loan_amount_multiple_open_loans(self):
        loan_amount1 = Decimal('100.00')
        loan_amount2 = Decimal('150.00')
        loan1 = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount1, status='open')
        loan2 = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount2, status='open')
        db.session.add_all([loan1, loan2])
        db.session.commit()
        expected_total = loan_amount1 + loan_amount2
        self.assertEqual(Loan.current_outstanding_loan_amount(asset_id=self.asset_id), expected_total)

    def test_current_outstanding_loan_amount_with_closed_loans(self):
        open_loan_amount = Decimal('100.00')
        closed_loan_amount = Decimal('200.00')
        open_loan = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=open_loan_amount, status='open')
        closed_loan = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=closed_loan_amount, status='closed')
        db.session.add_all([open_loan, closed_loan])
        db.session.commit()
        self.assertEqual(Loan.current_outstanding_loan_amount(asset_id=self.asset_id), open_loan_amount)

    def test_current_outstanding_loan_amount_multiple_assets(self):
        loan_amount_asset1 = Decimal('100.00')
        loan_amount_asset2 = Decimal('200.00')

        user_2 = Profile(name='a', email='b')
        asset_2 = Asset(name='c')
        db.session.add_all([user_2, asset_2])
        db.session.commit()
        loan1 = Loan(user_id=self.user_id, asset_id=self.asset_id, amount=loan_amount_asset1, status='open')
        loan2 = Loan(user_id=user_2.id, asset_id=asset_2.id, amount=loan_amount_asset2, status='open')
        db.session.add_all([loan1, loan2])
        db.session.commit()
        self.assertEqual(Loan.current_outstanding_loan_amount(asset_id=self.asset_id), loan_amount_asset1)
        self.assertEqual(Loan.current_outstanding_loan_amount(asset_id=asset_2.id), loan_amount_asset2)
