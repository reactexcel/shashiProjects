from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.PriceHistory import PriceHistory

class PriceHistoryTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.price_history = PriceHistory(id=1, asset_id=2, price=100, time_frequency="Daily")

    def test_creation(self):
        self.assertEqual(self.price_history.id, 1)
        self.assertEqual(self.price_history.asset_id, 2)
        self.assertEqual(self.price_history.price, 100)
        self.assertEqual(self.price_history.time_frequency, "Daily")