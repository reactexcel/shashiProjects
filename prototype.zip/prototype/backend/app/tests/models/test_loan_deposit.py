from decimal import Decimal
from unittest import mock
from app.database import db
from app.models import Asset, Profile, LoanDeposit, Pool, LiquidityPool, LendingPool
from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app

class LoanDepositTest(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        self.setupTestData()

    def tearDown(self):
        if db.session:
            db.session.remove()
        db.drop_all()
        super().tearDown()

    def setupTestData(self):
        self.user = Profile(name='TestUser', email='test@example.com')
        self.asset = Asset(name='TestAsset')
        db.session.add_all([self.asset, self.user])
        db.session.commit()

        self.user_id = self.user.id
        self.asset_id = self.asset.id

    def createLoanDeposit(self, user_id, asset_id, amount, available_interest_earned=0):
        loan_deposit = LoanDeposit(
            user_id=user_id, 
            asset_id=asset_id, 
            amount=amount, 
            available_interest_earned=available_interest_earned
        )
        db.session.add(loan_deposit)
        db.session.commit()
        return loan_deposit

    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    @mock.patch('app.models.PortfolioItem.withdraw')
    def test_deposit(self, mock_portfolio_withdraw, mock_loan_deposit_history_entry):
        initial_amount = Decimal('50.00')
        LoanDeposit.deposit(user_id=self.user_id, amount=initial_amount, asset_id=self.asset_id)

        expected_loan_deposit = LoanDeposit.current(asset_id=self.asset_id, user_id=self.user_id)

        mock_portfolio_withdraw.assert_called_once_with(user_id=self.user_id, asset_id=self.asset_id, asset_quantity=initial_amount)
        mock_loan_deposit_history_entry.assert_called_once_with(expected_loan_deposit, commit=False)

        assert expected_loan_deposit.amount == initial_amount

    def test_deposit_excess_amount(self):
        initial_amount = Decimal('500.00')
        with self.assertRaises(Exception):
            LoanDeposit.deposit(self.user_id, initial_amount, self.asset_id)

    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    @mock.patch('app.models.LendingPool.withdraw')
    @mock.patch('app.models.PortfolioItem.deposit')
    def test_withdraw_deposit(self, mock_portfolio_deposit, mock_lending_pool_withdraw, mock_loan_deposit_history_entry):
        initial_amount = Decimal('50.00')
        self.createLoanDeposit(self.user_id, self.asset_id, initial_amount)
        LoanDeposit.withdraw_deposit(user_id=self.user_id, amount=initial_amount, asset_id=self.asset_id)

        expected_loan_deposit = LoanDeposit.current(asset_id=self.asset_id, user_id=self.user_id)

        mock_lending_pool_withdraw.assert_called_once_with(asset_id=self.asset_id, amount=initial_amount)
        mock_portfolio_deposit.assert_called_once_with(asset_id=self.asset_id, user_id=self.user_id, asset_quantity=initial_amount)
        mock_loan_deposit_history_entry.assert_called_once_with(expected_loan_deposit, commit=False)

        assert expected_loan_deposit.amount == 0

    def test_withdraw_deposit_excess_amount(self):
        initial_amount = Decimal('50.00')
        withdraw_amount = Decimal('60.00')
        self.createLoanDeposit(self.user_id, self.asset_id, initial_amount)

        with self.assertRaises(Exception):
            LoanDeposit.withdraw_deposit(user_id=self.user_id, amount=withdraw_amount, asset_id=self.asset_id)

    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    @mock.patch('app.models.UserBalance.deposit')
    def test_withdraw_interest(self, mock_user_balance_deposit, mock_loan_deposit_history_entry):
        initial_amount = Decimal('50.00')
        self.createLoanDeposit(self.user_id, self.asset_id, initial_amount, available_interest_earned=initial_amount)

        LoanDeposit.withdraw_interest(user_id=self.user_id, amount=initial_amount, asset_id=self.asset_id)
        expected_loan_deposit = LoanDeposit.current(asset_id=self.asset_id, user_id=self.user_id)

        mock_user_balance_deposit.assert_called_once_with(user_id=self.user_id, quantity=initial_amount)
        mock_loan_deposit_history_entry.assert_called_once_with(expected_loan_deposit, commit=False)

        assert expected_loan_deposit.available_interest_earned == 0

    def test_withdraw_interest_excess_amount(self):
        initial_amount = Decimal('50.00')
        withdraw_amount = Decimal('60.00')
        self.createLoanDeposit(self.user_id, self.asset_id, initial_amount, available_interest_earned=initial_amount)

        with self.assertRaises(Exception):
            LoanDeposit.withdraw_interest(user_id=self.user_id, amount=withdraw_amount, asset_id=self.asset_id)

    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    def test_deposit_interest(self, mock_loan_deposit_history_entry):
        initial_amount = Decimal('50.00')
        self.createLoanDeposit(self.user_id, self.asset_id, 0, available_interest_earned=0)

        LoanDeposit.deposit_interest(user_id=self.user_id, amount=initial_amount, asset_id=self.asset_id)
        expected_loan_deposit = LoanDeposit.current(asset_id=self.asset_id, user_id=self.user_id)

        mock_loan_deposit_history_entry.assert_called_once_with(expected_loan_deposit, commit=False)

        assert expected_loan_deposit.available_interest_earned == initial_amount

    def test_current(self):
        self.createLoanDeposit(self.user_id, self.asset_id, 100)

        current_deposit = LoanDeposit.current(asset_id=self.asset_id, user_id=self.user_id)
        self.assertIsNotNone(current_deposit)
        self.assertEqual(current_deposit.user_id, self.user_id)
        self.assertEqual(current_deposit.asset_id, self.asset_id)

    def test_current_for_asset(self):
        self.createLoanDeposit(self.user_id, self.asset_id, 100)
        self.createLoanDeposit(self.user_id, self.asset_id, 50)

        current_deposits = LoanDeposit.current_for_asset(asset_id=self.asset_id)
        self.assertEqual(len(current_deposits), 2)

    def test_current_for_user(self):
        asset_id_1 = self.asset_id
        asset_id_2 = self.createAsset(name='Asset 2').id
        self.createLoanDeposit(self.user_id, asset_id_1, 100)
        self.createLoanDeposit(self.user_id, asset_id_2, 50)

        current_deposits = LoanDeposit.current_for_user(user_id=self.user_id)
        self.assertEqual(len(current_deposits), 2)

    def test_total_deposits(self):
        self.createLoanDeposit(self.user_id, self.asset_id, 10)
        self.createLoanDeposit(self.user_id, self.asset_id, 20)

        total_deposits = LoanDeposit.total_deposits(asset_id=self.asset_id)
        self.assertEqual(total_deposits, 30)

    def createAsset(self, name):
        asset = Asset(name=name)
        db.session.add(asset)
        db.session.commit()
        return asset

    def test_deposit_and_interest_value(self):
        pool = Pool(asset_id=self.asset_id, name='Test Pool')
        db.session.add(pool)
        db.session.commit() 
        liquidity_pool = LiquidityPool(asset_id=self.asset_id, pool_id=pool.id, asset_quantity=100, USD_quantity=100, total_liquidity_tokens=0)
        db.session.add_all([pool, liquidity_pool])
        db.session.commit()

        deposit_amount = Decimal('20.00')
        interest_earned = Decimal('10.00')
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount, interest_earned)

        exchange_rate = liquidity_pool.current_with_asset_id(asset_id=self.asset_id).exchange_rate()
        expected_deposit_value = deposit_amount * exchange_rate + interest_earned
        actual_value = LoanDeposit.deposit_and_interest_value(asset_id=self.asset_id, user_id=self.user_id)

        self.assertEqual(actual_value, expected_deposit_value)

    def test_total_deposits_for_asset_no_deposits(self):
        self.assertEqual(LoanDeposit.total_deposits_for_asset(asset_id=self.asset_id), Decimal('0.00'))

    def test_total_deposits_for_asset_one_deposit(self):
        deposit_amount = Decimal('100.00')
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount)
        self.assertEqual(LoanDeposit.total_deposits_for_asset(asset_id=self.asset_id), deposit_amount)

    def test_total_deposits_for_asset_multiple_deposits(self):
        deposit_amount1 = Decimal('100.00')
        deposit_amount2 = Decimal('150.00')
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount1)
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount2)
        expected_total = deposit_amount1 + deposit_amount2
        self.assertEqual(LoanDeposit.total_deposits_for_asset(asset_id=self.asset_id), expected_total)

    def test_total_deposits_for_asset_multiple_assets(self):
        deposit_amount_asset1 = Decimal('100.00')
        asset_2 = self.createAsset(name='Asset 2')
        deposit_amount_asset2 = Decimal('200.00')

        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount_asset1)
        self.createLoanDeposit(self.user_id, asset_2.id, deposit_amount_asset2)

        self.assertEqual(LoanDeposit.total_deposits_for_asset(asset_id=self.asset_id), deposit_amount_asset1)
        self.assertEqual(LoanDeposit.total_deposits_for_asset(asset_id=asset_2.id), deposit_amount_asset2)

    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    @mock.patch('app.models.UserBalance.deposit')
    @mock.patch('app.models.PortfolioItem.deposit')
    def test_withdraw_all_deposits_and_interest(self, mock_portfolio_item_deposit, mock_user_balance_deposit, mock_loan_deposit_history_entry):
        deposit_amount = Decimal('100.00')
        interest_earned = Decimal('10.00')
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount, available_interest_earned=interest_earned)

        LoanDeposit.withdraw_all_deposits_and_interest(user_id=self.user_id, asset_id=self.asset_id)

        mock_user_balance_deposit.assert_called_with(user_id=self.user_id, quantity=interest_earned)
        mock_portfolio_item_deposit.assert_called_with(user_id=self.user_id, asset_id=self.asset_id, asset_quantity=deposit_amount)

        loan_deposit = LoanDeposit.current(user_id=self.user_id, asset_id=self.asset_id)
        self.assertEqual(loan_deposit.amount, Decimal('0.00'))
        self.assertEqual(loan_deposit.available_interest_earned, Decimal('0.00'))

        self.assertEqual(mock_loan_deposit_history_entry.call_count, 2)

    @mock.patch('app.models.LoanDeposit.withdraw_deposit')
    @mock.patch('app.models.LoanDeposit.withdraw_interest')
    def test_withdraw_all_deposits_and_interest_no_deposit(self, mock_withdraw_deposit, mock_withdraw_interest):
        LoanDeposit.withdraw_all_deposits_and_interest(user_id=self.user_id, asset_id=self.asset_id)
        mock_withdraw_deposit.assert_not_called()


    @mock.patch('app.models.LoanDepositHistory.create_history_entry')
    @mock.patch('app.models.UserBalance.deposit')
    @mock.patch('app.models.PortfolioItem.deposit')
    def test_withdraw_all_deposits_and_interest_partial_interest(self, mock_portfolio_item_deposit, mock_user_balance_deposit, mock_loan_deposit_history_entry):
        deposit_amount = Decimal('100.00')
        partial_interest_earned = Decimal('5.00')
        self.createLoanDeposit(self.user_id, self.asset_id, deposit_amount, available_interest_earned=partial_interest_earned)

        LoanDeposit.withdraw_all_deposits_and_interest(user_id=self.user_id, asset_id=self.asset_id)

        loan_deposit = LoanDeposit.current(user_id=self.user_id, asset_id=self.asset_id)
        self.assertEqual(loan_deposit.amount, Decimal('0.00'))
        self.assertEqual(loan_deposit.available_interest_earned, Decimal('0.00'))

        mock_user_balance_deposit.assert_called_with(user_id=self.user_id, quantity=partial_interest_earned)
        mock_portfolio_item_deposit.assert_called_with(user_id=self.user_id, asset_id=self.asset_id, asset_quantity=deposit_amount)
        self.assertEqual(mock_loan_deposit_history_entry.call_count, 2)
