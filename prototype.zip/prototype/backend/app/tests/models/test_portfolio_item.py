from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models import PortfolioItem, Asset, Profile
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal

class PortfolioItemTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.session.begin_nested()
        # seed_database()
        user = Profile(name='a', email='b')
        user2 = Profile(name='a', email='b')
        asset = Asset(name='SF')
        asset2 = Asset(name='NYC')
        db.session.add_all([asset, asset2, user, user2])
        db.session.flush()
        self.user_id = user.id
        self.user2_id = user2.id
        self.asset_id = asset.id
        self.asset2_id = asset2.id
        db.session.add(PortfolioItem(user_id=self.user_id, asset_id=self.asset_id, quantity=0))
        db.session.add(PortfolioItem(user_id=self.user_id, asset_id=self.asset2_id, quantity=0))
        db.session.add(PortfolioItem(user_id=self.user2_id, asset_id=self.asset_id, quantity=0))
        db.session.add(PortfolioItem(user_id=self.user2_id, asset_id=self.asset2_id, quantity=0))
        db.session.commit()


    def test_withdraw(self):
        initial_quantity = Decimal(50)
        PortfolioItem.deposit(self.user_id, self.asset_id, initial_quantity)
        db.session.commit()
        PortfolioItem.withdraw(self.user_id, self.asset_id, Decimal(10))
        db.session.commit()

        portfolio_item = PortfolioItem.current(self.asset_id, self.user_id)

        self.assertEqual(portfolio_item.quantity, initial_quantity - Decimal(10))

    def test_withdraw_negative_quantity(self):
        with self.assertRaises(Exception) as context:
            PortfolioItem.withdraw(self.user_id, self.asset_id, Decimal(-10))
        self.assertIn("negative", str(context.exception))

    def test_withdraw_more_than_balance(self):
        initial_quantity = Decimal(50)
        PortfolioItem.deposit(self.user_id, self.asset_id, initial_quantity)

        with self.assertRaises(Exception) as context:
            PortfolioItem.withdraw(self.user_id, self.asset_id, initial_quantity + Decimal(10))
        
        self.assertIn("more of an asset than you have", str(context.exception))


    def test_deposit(self):
        initial_quantity = Decimal(50)
        PortfolioItem.deposit(self.user_id, self.asset_id, initial_quantity)
        db.session.commit()
        portfolio_item = PortfolioItem.current(self.asset_id, self.user_id)

        self.assertEqual(portfolio_item.quantity, initial_quantity)

    def test_deposit_negative_quantity(self):
        with self.assertRaises(Exception) as context:
            PortfolioItem.deposit(self.user_id, self.asset_id, Decimal(-10))
        self.assertIn("negative", str(context.exception))



    def test_latest_user_asset_pairings(self):
        user_ids = []
        asset_ids = []
        for _ in range(4):
            profile = Profile(name='a', email='b')
            db.session.add(profile)
            db.session.flush()
            user_ids.append(profile.id)
        for _ in range(4):
            asset = Asset(name='a')
            db.session.add(asset)
            db.session.flush()
            asset_ids.append(asset.id)
        test_cases = [
            (user_ids, asset_ids),
            # ([1], [1]),
            # Add more test cases as needed AND FIX UP TEST TO HANDLE DIFFERENT CASES, MAY SPLIT INTO MULTIPLE TESTS
        ]
        for user_ids, asset_ids in test_cases:
            with self.subTest(user_ids=user_ids, asset_ids=asset_ids):
                with db.session.begin_nested():
                    # Get the original portfolio items
                    original_items = PortfolioItem.latest_user_asset_pairings()

                    # Create a list to store the new portfolio items
                    new_items = []

                    # Iterate through user IDs and asset IDs to deposit new items
                    for user_id in user_ids:
                        for asset_id in asset_ids:
                            current_asset = PortfolioItem.current(asset_id=asset_id, user_id=user_id)
                            if current_asset is None:
                                deposit = PortfolioItem.deposit(user_id=user_id, asset_id=asset_id, asset_quantity=5)
                                new_items.append(deposit)

                    # Flush the session to persist the changes
                    db.session.flush()

                    # Validate the result
                    latest_items = PortfolioItem.latest_user_asset_pairings()
                    self.assertEqual(len(latest_items), len(original_items) + len(new_items))
                    for item in new_items:
                        self.assertIn(item, latest_items)


    def test_total_asset_quantities(self):

        # Call total_asset_quantities
        original_quantities = PortfolioItem.total_asset_quantities(asset_ids=[self.asset_id, self.asset2_id])

        # Add some PortfolioItem instances
        db.session.add(PortfolioItem(user_id=self.user_id, asset_id=self.asset_id, quantity=10))
        db.session.add(PortfolioItem(user_id=self.user_id, asset_id=self.asset2_id, quantity=20))
        db.session.add(PortfolioItem(user_id=self.user2_id, asset_id=self.asset_id, quantity=30))
        db.session.add(PortfolioItem(user_id=self.user2_id, asset_id=self.asset2_id, quantity=0))
        db.session.flush()

        # Call total_asset_quantities
        quantities = PortfolioItem.total_asset_quantities(asset_ids=[self.asset_id, self.asset2_id])

        # Check that the returned quantities contain only the expected keys
        self.assertCountEqual(quantities.keys(), [self.asset_id, self.asset2_id])

        # Check that the returned quantities are correct
        self.assertAlmostEqual(quantities[self.asset_id], original_quantities[self.asset_id] + 40)
        self.assertAlmostEqual(quantities[self.asset2_id], original_quantities[self.asset2_id] + 20)
