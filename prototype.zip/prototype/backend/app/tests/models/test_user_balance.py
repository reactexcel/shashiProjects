from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.UserBalance import UserBalance
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal
from app.tests.factories import get_user_id
class UserBalanceTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        self.user_id = get_user_id()
        db.session.add(UserBalance(quantity=0, user_id=self.user_id))
        db.session.commit()


    def test_deposit(self):
        initial_quantity = Decimal(100)
        UserBalance.deposit(self.user_id, initial_quantity)
        db.session.commit()

        latest_balance = UserBalance.current(user_id=self.user_id)
        
        self.assertEqual(latest_balance.quantity, initial_quantity)

    def test_withdraw(self):
        withdraw_quantity = Decimal(50)
        db.session.add(UserBalance(user_id=self.user_id, quantity=Decimal(100)))
        db.session.commit()
        initial_balance = UserBalance.current(user_id=self.user_id).quantity
        UserBalance.withdraw(self.user_id, withdraw_quantity)
        db.session.commit()

        latest_balance = UserBalance.current(user_id=self.user_id)
        self.assertEqual(latest_balance.quantity, initial_balance - withdraw_quantity)

    def test_withdraw_more_than_balance(self):
        initial_quantity = Decimal(500)
        UserBalance.deposit(self.user_id, initial_quantity)
        db.session.commit()
        with self.assertRaises(Exception) as context:
            UserBalance.withdraw(self.user_id, Decimal(1000))

        self.assertIn("Cannot withdraw 1000 as it is more than your current balance of 500.", str(context.exception))
    def test_negative_deposit(self):
        with self.assertRaises(Exception) as context:
            UserBalance.deposit(self.user_id, Decimal(-50))
        
        self.assertIn("Cannot deposit a negative quantity", str(context.exception))

    def test_negative_withdraw(self):
        with self.assertRaises(Exception) as context:
            UserBalance.withdraw(self.user_id, Decimal(-50))
        
        self.assertIn("Cannot withdraw a negative quantity", str(context.exception))

    def test_multiple_deposits(self):
        UserBalance.deposit(self.user_id, Decimal(100))
        db.session.commit()
        UserBalance.deposit(self.user_id, Decimal(50))
        db.session.commit()

        balance = UserBalance.current(self.user_id)
        self.assertIsNotNone(balance)
        self.assertEqual(balance.quantity, Decimal(150))

    def test_deposits_and_withdrawals(self):
        UserBalance.deposit(self.user_id, Decimal(100))
        db.session.commit()
        UserBalance.deposit(self.user_id, Decimal(50))
        db.session.commit()
        UserBalance.withdraw(self.user_id, Decimal(30))
        db.session.commit()

        balance = UserBalance.current(self.user_id)
        self.assertIsNotNone(balance)
        self.assertEqual(balance.quantity, Decimal(120))
