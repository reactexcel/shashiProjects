from app.models import Profile
from app.tests.factories import ProfileFactory
from app.tests.base_test_case import BaseTestCase
from app.database import db
class BaseModelTest(BaseTestCase):
    def setUp(self):
        super().setUp()

    def test_flush_method(self):
        self.assertIsNone(ProfileFactory().id)
        self.assertIsNotNone(ProfileFactory().flush().id)

