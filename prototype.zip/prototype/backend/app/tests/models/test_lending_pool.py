from decimal import Decimal
from unittest import mock

from app.database import db
from app.models import Asset, Loan, Profile, UserBalance, LoanDeposit, Pool, PortfolioItem, LendingPool, LiquidityPool, PriceHistory, LoanHistory
from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app

class LendingPoolTest(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        db.session.begin_nested()
        self.setupTestData()


    def tearDown(self):
        if db.session:
            db.session.remove()
        db.drop_all()
        super().tearDown()

    def setupTestData(self):
        assets = [Asset(name=f'SF{i}') for i in range(3)]
        users = [Profile(name=f'a{i}', email=f'b{i}') for i in range(3)]
        db.session.add_all(assets + users)
        db.session.flush()

        pools = [Pool(asset_id=asset.id, name=f'pool_{asset.id}') for asset in assets]
        db.session.add_all(pools)
        db.session.commit()

        for pool in pools:
            db.session.add(LiquidityPool(
                asset_id=pool.asset_id, asset_quantity=100, USD_quantity=100,
                pool_id=pool.id, total_liquidity_tokens=0
            ))
            db.session.add(LendingPool(asset_id=pool.asset_id, interest_earned=0))

        db.session.commit()

        self.asset_ids = [asset.id for asset in assets]
        self.user_ids = [user.id for user in users]
        self.pool_ids = [pool.id for pool in pools]

    @mock.patch('app.models.LendingPool.add_interest_earned')
    @mock.patch('app.models.LendingPool.interest_rate')
    def test_distribute_interest_interested_earned(self, mock_interest_rate, mock_add_interest_earned):
        asset_id = self.asset_ids[0]
        interest_rate = Decimal('0.05')
        amount = Decimal('10.00')
        mock_interest_rate.return_value = interest_rate

        loan = Loan(user_id=self.user_ids[0], asset_id=asset_id, amount=amount, remaining_collateral=Decimal('50.00'))
        db.session.add(loan)
        db.session.commit()

        LendingPool.distribute_interest(asset_id)

        updated_collateral = Loan.current_open_loan(user_id=self.user_ids[0], asset_id=asset_id).remaining_collateral
        expected_interest = updated_collateral - loan.remaining_collateral

        lending_pool = LendingPool.current(asset_id=asset_id)
        assert lending_pool.interest_earned == expected_interest

    @mock.patch('app.models.LendingPool.interest_rate')
    def test_distribute_interest_loan_collateral_with_multiple_loans(self, mock_interest_rate):
        interest_rate = Decimal('0.05')
        mock_interest_rate.return_value = interest_rate
        asset_id = self.asset_ids[0]

        for user_id in self.user_ids[:2]:
            db.session.add(UserBalance(user_id=user_id, quantity=Decimal('100.00')))

        loans = [
            Loan(user_id=user_id, asset_id=asset_id, amount=Decimal('100.00'), remaining_collateral=Decimal('250.00'))
            for user_id in self.user_ids[:2]
        ]
        db.session.add_all(loans)
        db.session.commit()

        original_collaterals = {loan.id: loan.remaining_collateral for loan in Loan.query.all()}
        LendingPool.distribute_interest(asset_id)

        for loan in loans:
            updated_loan = Loan.query.get(loan.id)
            self.assertTrue(updated_loan.remaining_collateral < original_collaterals[loan.id])
            self.assertTrue(updated_loan.remaining_collateral > 0)

    @mock.patch('app.models.LendingPool.add_interest_earned')
    @mock.patch('app.models.LendingPool.interest_rate')
    def test_distribute_interest_loan_collateral_with_multiple_loans_and_multiple_assets(self, mock_interest_rate, mock_add_interest_earned):
        interest_rate = Decimal('0.05')
        mock_interest_rate.return_value = interest_rate

        for i, asset_id in enumerate(self.asset_ids):
            loan = Loan(user_id=self.user_ids[i], asset_id=asset_id, amount=Decimal('100.00'), remaining_collateral=Decimal('250.00'))
            db.session.add(loan)
        db.session.commit()

        for asset_id in self.asset_ids:
            LendingPool.distribute_interest(asset_id)

        for asset_id in self.asset_ids:
            loans = Loan.query.filter_by(asset_id=asset_id).all()
            for loan in loans:
                self.assertTrue(loan.remaining_collateral > Decimal('50.00'))


    @mock.patch('app.models.LendingPool.add_interest_earned')
    @mock.patch('app.models.LendingPool.interest_rate')
    def test_distribute_interest_multiple_loan_deposits_multiple_assests(self, mock_interest_rate, mock_add_interest_earned):
        interest_rate = Decimal('0.05')
        mock_interest_rate.return_value = interest_rate

        for i, asset_id in enumerate(self.asset_ids):
            loan = Loan(user_id=self.user_ids[i], asset_id=asset_id, remaining_collateral=Decimal('200.00'), amount=Decimal('100.00') )
            loan_deposit = LoanDeposit(user_id=self.user_ids[i], asset_id=asset_id, amount=Decimal('200.00'))
            db.session.add_all([loan_deposit, loan])
        
        db.session.commit()

        for asset_id in self.asset_ids:
            LendingPool.distribute_interest(asset_id)

        for asset_id in self.asset_ids:
            loan_deposits = LoanDeposit.query.filter_by(asset_id=asset_id).all()
            for deposit in loan_deposits:
                updated_deposit = LoanDeposit.query.get(deposit.id)
                self.assertTrue(updated_deposit.available_interest_earned > Decimal('0'))


    def test_withdraw_without_sufficient_funds(self):
        amount = 50
        loan_deposit = LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=amount / 2)
        db.session.add(loan_deposit)
        db.session.commit()
        with self.assertRaises(Exception):
            LendingPool.withdraw(asset_id=self.asset_ids[0], amount=amount)

    def test_withdraw_with_sufficient_funds(self):
        amount = 50
        loan_deposit = LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=amount * 2)
        db.session.add(loan_deposit)
        db.session.commit()
        try:
            LendingPool.withdraw(asset_id=self.asset_ids[0], amount=amount)
        except Exception:
            self.fail("LendingPool.withdraw() raised Exception unexpectedly!")

    def test_unutilized_deposits_no_deposits_or_loans(self):
        self.assertEqual(LendingPool.unutilized_deposits(asset_id=self.asset_ids[0]), 0)

    def test_unutilized_deposits_with_deposits_no_loans(self):
        deposit_amount = Decimal('100.00')
        db.session.add(LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=deposit_amount))
        db.session.commit()
       
    def test_unutilized_deposits_with_deposits_and_loans(self):
        deposit_amount = Decimal('200.00')
        loan_amount = Decimal('50.00')
        db.session.add(LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=deposit_amount))
        db.session.add(Loan(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=loan_amount))
        db.session.commit()
        expected_unutilized = deposit_amount - loan_amount
        self.assertEqual(LendingPool.unutilized_deposits(asset_id=self.asset_ids[0]), expected_unutilized)

    def test_utilization_ratio_no_deposits(self):
        self.assertIsNone(LendingPool.utilization_ratio(asset_id=self.asset_ids[0]))

    def test_utilization_ratio_with_deposits_no_loans(self):
        deposit_amount = Decimal('100.00')
        db.session.add(LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=deposit_amount))
        db.session.commit()

        self.assertEqual(LendingPool.utilization_ratio(asset_id=self.asset_ids[0]), Decimal('0'))

    def test_utilization_ratio_with_deposits_and_loans(self):
        deposit_amount = Decimal('200.00')
        loan_amount = Decimal('50.00')
        db.session.add(LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=deposit_amount))
        db.session.add(Loan(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=loan_amount))
        db.session.commit()

        expected_ratio = Decimal('1') - (deposit_amount - loan_amount) / deposit_amount
        self.assertEqual(LendingPool.utilization_ratio(asset_id=self.asset_ids[0]), expected_ratio)

    def test_interest_rate_no_utilization(self):
        self.assertEqual(LendingPool.interest_rate(asset_id=self.asset_ids[0]), Decimal('0'))

    def test_interest_rate_with_utilization(self):
        deposit_amount = Decimal('100.00')
        loan_amount = Decimal('50.00')
        db.session.add(LoanDeposit(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=deposit_amount))
        db.session.add(Loan(asset_id=self.asset_ids[0], user_id=self.user_ids[0], amount=loan_amount))
        db.session.commit()

        utilization_ratio = LendingPool.utilization_ratio(asset_id=self.asset_ids[0])
        expected_interest_rate = max(utilization_ratio * Decimal('0.1'), Decimal('0.02'))
        self.assertEqual(LendingPool.interest_rate(asset_id=self.asset_ids[0]), expected_interest_rate)

    def test_asset_ids_by_utilization_ratio_empty(self):
        db.session.query(PortfolioItem).delete()
        db.session.query(PriceHistory).delete()
        db.session.query(LoanHistory).delete()
        db.session.query(LiquidityPool).delete()
        db.session.query(LendingPool).delete()
        db.session.query(LoanDeposit).delete()
        db.session.query(Loan).delete()
        db.session.query(Pool).delete()
        db.session.query(Asset).delete()
        db.session.query(Profile).delete()
        db.session.commit()

        self.assertEqual(LendingPool.asset_ids_by_utilization_ratio(), [])

    def test_asset_ids_by_utilization_ratio_sorted(self):
        for i in range(3):
            deposit_amount = Decimal('100.00') * (i + 1)
            loan_amount = Decimal('50.00') * (i + 1)
            db.session.add(LoanDeposit(asset_id=self.asset_ids[i], user_id=self.user_ids[i], amount=deposit_amount))
            db.session.add(Loan(asset_id=self.asset_ids[i], user_id=self.user_ids[i], amount=loan_amount))
        db.session.commit()

        sorted_asset_ids = LendingPool.asset_ids_by_utilization_ratio()
        self.assertEqual(len(sorted_asset_ids), 3)

        for i in range(2):
            utilization_ratio_1 = LendingPool.utilization_ratio(asset_id=sorted_asset_ids[i]) or 0
            utilization_ratio_2 = LendingPool.utilization_ratio(asset_id=sorted_asset_ids[i + 1]) or 0
            self.assertGreaterEqual(utilization_ratio_1, utilization_ratio_2)
