from app.tests.base_test_case import BaseTestCase
# from app.database import db
from app.database import db
from app.models.Transaction import Transaction

class TransactionTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.transaction = Transaction(transaction_id=1, asset_id=2, asset_quantity=50, USD=1000, user_id=1, fee=5, associated_record_id=3, associated_record_type="Buy")

    def test_creation(self):
        self.assertEqual(self.transaction.transaction_id, 1)
        self.assertEqual(self.transaction.asset_id, 2)
        self.assertEqual(self.transaction.asset_quantity, 50)
        self.assertEqual(self.transaction.USD, 1000)
        self.assertEqual(self.transaction.user_id, 1)
        self.assertEqual(self.transaction.fee, 5)
        self.assertEqual(self.transaction.associated_record_id, 3)
        self.assertEqual(self.transaction.associated_record_type, "Buy")