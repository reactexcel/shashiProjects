from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.MarketBalance import MarketBalance
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal

class MarketBalanceTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        # seed_database()
        db.session.add(MarketBalance(quantity=0))
        db.session.commit()


    def test_deposit(self):
        initial_quantity = Decimal(100)
        MarketBalance.deposit(initial_quantity)
        db.session.commit()
        latest_balance = MarketBalance.current()
        
        self.assertEqual(latest_balance.quantity, initial_quantity)

    def test_withdraw(self):
        initial_quantity = Decimal(50)
        MarketBalance.deposit(initial_quantity)
        db.session.commit()
        MarketBalance.withdraw(Decimal(10))
        db.session.commit()

        latest_balance = MarketBalance.current()

        self.assertEqual(latest_balance.quantity, Decimal(40))

    def test_withdraw_more_than_balance(self):
        initial_quantity = Decimal(500)
        MarketBalance.deposit(initial_quantity)

        with self.assertRaises(Exception) as context:
            MarketBalance.withdraw(Decimal(1000))

        self.assertIn("Cannot withdraw more than you have", str(context.exception))
    def test_negative_deposit(self):
        with self.assertRaises(Exception) as context:
            MarketBalance.deposit(Decimal(-50))
        
        self.assertIn("Cannot deposit a negative quantity", str(context.exception))

    def test_negative_withdraw(self):
        with self.assertRaises(Exception) as context:
            MarketBalance.withdraw(Decimal(-50))
        
        self.assertIn("Cannot withdraw a negative quantity", str(context.exception))
