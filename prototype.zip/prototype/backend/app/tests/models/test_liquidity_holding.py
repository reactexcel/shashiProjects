from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models import LiquidityHolding, Asset, Pool, Profile
from app.tests.factories import AssetFactory, PoolFactory
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal


class LiquidityHoldingTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        # seed_database()
        asset = AssetFactory(name='SF')
        db.session.flush()
        pool = PoolFactory(asset_id=asset.id)
        user = Profile(name='a', email='a')
        db.session.add_all([asset,pool, user])
        db.session.flush()
        self.user_id = user.id
        self.pool_id = pool.id
        self.asset_id = asset.id
    
    def test_withdraw(self):
        initial_quantity = Decimal(50)
        LiquidityHolding.deposit(self.user_id, self.pool_id, self.asset_id, initial_quantity)
        LiquidityHolding.withdraw(self.user_id, self.pool_id, self.asset_id, Decimal(10))

        liquidity_holding = LiquidityHolding.current(self.pool_id, self.user_id)

        self.assertEqual(liquidity_holding.quantity, initial_quantity - Decimal(10))

    def test_withdraw_negative_quantity(self):
        with self.assertRaises(Exception) as context:
            LiquidityHolding.withdraw(self.user_id, self.pool_id, self.asset_id, Decimal(-10))
        self.assertIn("negative", str(context.exception))

    def test_withdraw_more_than_balance(self):
        initial_quantity = Decimal(50)
        LiquidityHolding.deposit(self.user_id, self.pool_id, self.asset_id, initial_quantity)

        with self.assertRaises(Exception) as context:
            LiquidityHolding.withdraw(self.user_id, self.pool_id, self.asset_id, initial_quantity + Decimal(10))
        
        self.assertIn("more of an asset than you have", str(context.exception))

    def test_deposit(self):
        initial_quantity = Decimal(50)
        LiquidityHolding.deposit(self.user_id, self.pool_id, self.asset_id, initial_quantity)

        liquidity_holding = LiquidityHolding.current(pool_id=self.pool_id, user_id=self.user_id)

        self.assertEqual(liquidity_holding.quantity, initial_quantity)

    def test_deposit_negative_quantity(self):
        with self.assertRaises(Exception) as context:
            LiquidityHolding.deposit(self.user_id, self.pool_id, self.asset_id, Decimal(-10))
        self.assertIn("negative", str(context.exception))
