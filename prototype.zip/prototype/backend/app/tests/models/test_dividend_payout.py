from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.DividendPayout import DividendPayout

class DividendPayoutTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.dividend_payout = DividendPayout(user_id=1, asset_id=2, amount_in_usd=500, payout_cycle_id=1)

    def test_creation(self):
        self.assertEqual(self.dividend_payout.user_id, 1)
        self.assertEqual(self.dividend_payout.asset_id, 2)
        self.assertEqual(self.dividend_payout.amount_in_usd, 500)
        self.assertEqual(self.dividend_payout.payout_cycle_id, 1)