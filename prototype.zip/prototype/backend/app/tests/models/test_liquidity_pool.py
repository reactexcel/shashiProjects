from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models import LiquidityPool, Pool, Asset
from app.tests.factories import LiquidityPoolFactory, PoolFactory
from app.test_app import create_test_app
from seed_database import seed_database
from decimal import Decimal
from unittest.mock import patch, MagicMock
from sqlalchemy.sql.expression import func
from collections import namedtuple
from datetime import datetime, timedelta

class LiquidityPoolTest(BaseTestCase):

  def setUp(self):
    super().setUp()
    self.app = create_test_app()
    self.app_context = self.app.app_context()
    self.app_context.push()
    # seed_database()

    # Creating a sample liquidity pool
    self.pool = PoolFactory().flush()
    # db.session.add(self.pool)
    self.asset = Asset.query.filter_by(id=self.pool.asset_id).first()
    # db.session.add(self.asset)
    # db.session.flush()
    # db.session.flush()
    self.pool_id = self.pool.id
    self.asset_id = self.asset.id
    self.USD_quantity = Decimal(1000)
    self.asset_quantity = Decimal(2000)
    self.total_liquidity_tokens = Decimal(3000)
    self.liquidity_pool = LiquidityPoolFactory(pool_id=self.pool_id, asset_id=self.asset_id, asset_quantity=50, USD_quantity=1000, total_liquidity_tokens=1000)
    liquidity_pool = LiquidityPool(
        pool_id=self.pool_id, 
        asset_id=self.asset_id, 
        asset_quantity=self.asset_quantity, 
        USD_quantity=self.USD_quantity, 
        total_liquidity_tokens=self.total_liquidity_tokens
    )
    db.session.add(liquidity_pool)
    db.session.commit()

  def test_current_with_existing_pool(self):
      older_pool = LiquidityPoolFactory(pool_id=self.pool.id, asset_id=self.asset_id, created_at=datetime.utcnow() - timedelta(days=1))
      latest_pool = LiquidityPoolFactory(pool_id=self.pool.id, asset_id=self.asset_id)
      db.session.commit()

      result = LiquidityPool.current(self.pool.id)
      self.assertIsNotNone(result)
      self.assertEqual(result.id, latest_pool.id)

  def test_current_with_no_matching_pool(self):
      result = LiquidityPool.current(99999999) # non-existant pool
      self.assertIsNone(result)

  def test_current_returns_latest(self):
      LiquidityPoolFactory(pool_id=self.pool_id, asset_id=self.asset.id, created_at=datetime.utcnow() - timedelta(days=2))
      LiquidityPoolFactory(pool_id=self.pool_id, asset_id=self.asset.id, created_at=datetime.utcnow() - timedelta(days=1))
      latest_pool = LiquidityPoolFactory(pool_id=self.pool_id, asset_id=self.asset_id)
      db.session.commit()

      result = LiquidityPool.current(self.pool_id)
      self.assertEqual(result.id, latest_pool.id)
      self.assertEqual(result.quantity_in_asset, latest_pool.quantity_in_asset)

  def test_creation(self):
    self.assertEqual(self.liquidity_pool.pool_id, self.pool.id)
    self.assertEqual(self.liquidity_pool.asset_id, self.asset.id)
    self.assertEqual(self.liquidity_pool.asset_quantity, 50)
    self.assertEqual(self.liquidity_pool.USD_quantity, 1000)
  

  def test_successful_swap_for_asset(self):
    USD_in = Decimal(100)

    # Calculating expected values
    transaction_fee = USD_in * Decimal(LiquidityPool.TRANSACTION_FEE_PERCENTAGE)
    USD_in_after_fee = USD_in - transaction_fee
    K = self.asset_quantity * self.USD_quantity
    expected_output = self.asset_quantity - K / (self.USD_quantity + USD_in_after_fee)

    # Executing the swap
    result, fee = LiquidityPool.swap_for_asset(self.pool_id, USD_in)

    # Verifying output amount
    self.assertEqual(result, expected_output)

    # Verifying transaction fee
    self.assertEqual(fee, transaction_fee)

    # Retrieving the new liquidity pool from the database
    new_liquidity_pool = LiquidityPool.query.filter_by(pool_id=self.pool_id).order_by(LiquidityPool.id.desc()).first()

    # Verifying pool balance update
    self.assertEqual(new_liquidity_pool.USD_quantity, self.USD_quantity + USD_in_after_fee)
    self.assertEqual(new_liquidity_pool.asset_quantity, self.asset_quantity - expected_output)

  def test_successful_swap_for_USD(self):
    asset_in = Decimal(100)

    # Calculating expected values
    asset_in_after_fee = asset_in
    K = self.asset_quantity * self.USD_quantity
    expected_USD_out = self.USD_quantity - K / (self.asset_quantity + asset_in_after_fee)

    # Executing the swap
    result = LiquidityPool.swap_for_USD(self.pool_id, asset_in)

    # Verifying output amount
    self.assertEqual(result, expected_USD_out)

    # Retrieving the new liquidity pool from the database
    new_liquidity_pool = LiquidityPool.query.filter_by(pool_id=self.pool_id).order_by(LiquidityPool.id.desc()).first()

    # Verifying pool balance update
    self.assertEqual(new_liquidity_pool.USD_quantity, self.USD_quantity - expected_USD_out)
    self.assertEqual(new_liquidity_pool.asset_quantity, self.asset_quantity + asset_in_after_fee)

  def test_exchange_rate(self):
    self.liquidity_pool = LiquidityPool(id=1, asset_id=2, asset_quantity=50, USD_quantity=100, total_liquidity_tokens=1000)
    self.assertEqual(self.liquidity_pool.exchange_rate(), 2.0)
    self.liquidity_pool = LiquidityPool(id=1, asset_id=2, asset_quantity=100, USD_quantity=50, total_liquidity_tokens=1000)
    self.assertEqual(self.liquidity_pool.exchange_rate(), 0.5)
    self.liquidity_pool = LiquidityPool(id=1, asset_id=2, asset_quantity=50, USD_quantity=50, total_liquidity_tokens=1000)
    self.assertEqual(self.liquidity_pool.exchange_rate(), 1.0)    
  
  def test_add_liquidity(self):
    self.liquidity_pool.USD_quantity = 1000
    self.liquidity_pool.asset_quantity = 1000
    self.liquidity_pool.total_liquidity_tokens = 1000
    new_pool, _ = self.liquidity_pool.add_liquidity(USD_deposit=100, asset_deposit=50)
    self.assertEqual(new_pool.USD_quantity, 1100)
    self.assertEqual(new_pool.asset_quantity, 1050)
    self.assertEqual(new_pool.total_liquidity_tokens, 1075) # double check this

  def test_tokens_to_issue_both_deposits(self):
      USD_deposit = Decimal(100)
      asset_deposit = Decimal(50)
      expected_tokens = ((USD_deposit + asset_deposit * self.liquidity_pool.exchange_rate()) / (self.liquidity_pool.USD_quantity + self.liquidity_pool.asset_quantity * self.liquidity_pool.exchange_rate())) * self.liquidity_pool.total_liquidity_tokens
      self.assertEqual(self.liquidity_pool.tokens_to_issue(USD_deposit, asset_deposit), expected_tokens)

  def test_tokens_to_issue_only_USD(self):
      USD_deposit = Decimal(100)
      asset_deposit = Decimal(0)
      expected_tokens = ((USD_deposit + asset_deposit * self.liquidity_pool.exchange_rate()) / (self.liquidity_pool.USD_quantity + self.liquidity_pool.asset_quantity * self.liquidity_pool.exchange_rate())) * self.liquidity_pool.total_liquidity_tokens
      self.assertEqual(self.liquidity_pool.tokens_to_issue(USD_deposit, asset_deposit), expected_tokens)

  def test_tokens_to_issue_only_asset(self):
      USD_deposit = Decimal(0)
      asset_deposit = Decimal(50)
      expected_tokens = ((USD_deposit + asset_deposit * self.liquidity_pool.exchange_rate()) / (self.liquidity_pool.USD_quantity + self.liquidity_pool.asset_quantity * self.liquidity_pool.exchange_rate())) * self.liquidity_pool.total_liquidity_tokens
      self.assertEqual(self.liquidity_pool.tokens_to_issue(USD_deposit, asset_deposit), expected_tokens)

  def test_tokens_to_issue_no_deposits(self):
      USD_deposit = Decimal(0)
      asset_deposit = Decimal(0)
      expected_tokens = Decimal(0)
      self.assertEqual(self.liquidity_pool.tokens_to_issue(USD_deposit, asset_deposit), expected_tokens)

  def test_create_method(self):
    new_pool = LiquidityPool.create(pool_id=self.pool.id, asset_id=self.asset.id, asset_quantity=150, USD_quantity=300, total_liquidity_tokens=1000)
    self.assertEqual(new_pool.pool_id, self.pool.id)
    self.assertEqual(new_pool.asset_id, self.asset.id)
    self.assertEqual(new_pool.asset_quantity, 150)
    self.assertEqual(new_pool.USD_quantity, 300)

  def test_exchange_rate_edge_cases(self):
    with self.assertRaises(ZeroDivisionError):
        liquidity_pool = LiquidityPoolFactory(asset_quantity=0)
        liquidity_pool.exchange_rate()

  def test_no_matching_pools(self):
      result = LiquidityPool.get_latest_pools_for_asset(999999999, datetime.utcnow())
      assert (result == None or result == [])

  def test_matching_pools_after_timestamp(self):
      asset_id = self.liquidity_pool.asset_id
      since_timestamp = datetime.utcnow() - timedelta(days=1)
      db.session.commit()
      pre_count = len(LiquidityPool.get_latest_pools_for_asset(asset_id, since_timestamp))
      matching_pool = LiquidityPoolFactory(created_at=datetime.utcnow(), pool_id=self.liquidity_pool.pool_id, asset_id=asset_id).flush()
      db.session.commit()
      pools = LiquidityPool.query.filter_by(asset_id=self.liquidity_pool.asset_id)
      result = LiquidityPool.get_latest_pools_for_asset(asset_id, since_timestamp)
      assert len(result) == pre_count + 1
      assert matching_pool.id in [pool.id for pool in result]

  def test_pools_before_timestamp(self):
      liquidity_pool = LiquidityPool.query.first()
      asset_id = liquidity_pool.asset_id
      since_timestamp = datetime.utcnow()

      LiquidityPoolFactory(created_at=datetime.utcnow() - timedelta(days=2), asset_id=asset_id).flush()
      result = LiquidityPool.get_latest_pools_for_asset(asset_id, since_timestamp)
      assert (result == [] or result == None)
    
  @patch.object(db.session, 'query')
  def test_latest_pools_per_id_no_pools(self, mock_query):
      # Creating a mock subquery result with a 'c' attribute
      SubqueryMock = namedtuple('SubqueryMock', ['c'])
      mock_subquery = SubqueryMock(c=None)
      mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
      mock_query.return_value.join.return_value.all.return_value = []

      # Running Test
      result = LiquidityPool.latest_pools_per_id()
      self.assertEqual(result, [])

  @patch.object(db.session, 'query')
  @patch.object(func, 'max')
  def test_latest_pools_per_id_single_pool_per_id(self, mock_max, mock_query):
      # Creating a mock subquery result with a 'c' attribute
      SubqueryMock = namedtuple('SubqueryMock', ['c'])
      mock_subquery = SubqueryMock(c=MagicMock(pool_id=1, max_id=1))
      pool_mock = MagicMock(pool_id=1)
      mock_max.return_value.label.return_value = 1
      mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
      mock_query.return_value.join.return_value.all.return_value = [pool_mock]

      # Running Test
      result = LiquidityPool.latest_pools_per_id()
      self.assertEqual(result, [pool_mock])

  @patch.object(db.session, 'query')
  @patch.object(func, 'max')
  def test_latest_pools_per_id_multiple_pools_per_id(self, mock_max, mock_query):
      # Creating a mock subquery result with a 'c' attribute
      SubqueryMock = namedtuple('SubqueryMock', ['c'])
      mock_subquery = SubqueryMock(c=MagicMock(pool_id=2, max_id=2))
      pool_mock1 = MagicMock(pool_id=1)
      pool_mock2 = MagicMock(pool_id=2)
      mock_max.return_value.label.return_value = 2
      mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
      mock_query.return_value.join.return_value.all.return_value = [pool_mock1, pool_mock2]

      # Running Test
      result = LiquidityPool.latest_pools_per_id()
      self.assertEqual(result, [pool_mock1, pool_mock2])