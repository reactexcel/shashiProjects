from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models.Loan import Loan, OPEN, DEFAULTED, CLOSED, LIQUIDATION_RATE
from app.models import LendingPool, Asset, Profile, UserBalance, PortfolioItem
from app.test_app import create_test_app
from decimal import Decimal
import unittest
import pytest
from unittest import mock


@pytest.fixture
def app_context():
    app = create_test_app()
    with app.app_context():
        db.create_all()
        try:
            db.session.begin_nested()
            yield app
        finally:
            db.session.rollback()
            db.drop_all()
            db.session.remove()


@pytest.fixture
def user_and_asset(app_context):
    user = Profile(name='test', email='test@test.com')
    asset = Asset(name='SF')
    db.session.add_all([asset, user])
    db.session.flush()
    return user, asset


@pytest.fixture
def user_balance(user_and_asset):
    user, asset = user_and_asset
    initail_asset_quantity = Decimal('100.00')
    user_balance = UserBalance(user_id=user.id, quantity=initail_asset_quantity)
    db.session.add(user_balance)
    db.session.flush()
    return user_balance

@pytest.mark.usefixtures("app_context")
def test_take_out_loan(user_and_asset, user_balance):
    user, asset = user_and_asset
    loan_amount = Decimal('50.00')
    collateral = Decimal('25.00')

    with mock.patch('app.models.LoanHistory.create_history_entry') as mock_loan_history_entry, \
         mock.patch('app.models.PortfolioItem.deposit') as mock_portfolio_deposit, \
         mock.patch('app.models.LendingPool.withdraw') as mock_lending_pool_withdraw, \
         mock.patch('app.models.UserBalance.withdraw') as mock_user_withdraw:

        Loan.take_out_loan(user_id=user.id, asset_id=asset.id, amount=loan_amount, collateral=collateral)
        expected_loan = Loan.current_open_loan(user_id=user.id, asset_id=asset.id)

        mock_user_withdraw.assert_called_once_with(user_id=user.id, quantity=collateral)
        mock_lending_pool_withdraw.assert_called_once_with(asset_id=asset.id, amount=loan_amount)
        mock_portfolio_deposit.assert_called_once_with(asset_id=asset.id, user_id=user.id,
                                                       asset_quantity=loan_amount)
        mock_loan_history_entry.assert_called_once_with(loan=expected_loan, commit=False)

        assert expected_loan.amount == loan_amount
        assert expected_loan.remaining_collateral == collateral


@pytest.mark.usefixtures("app_context")
def test_take_out_loan_excess_amount(user_and_asset):
    user, asset = user_and_asset
    loan_amount = Decimal('500.00')
    collateral = Decimal('250.00')
    with pytest.raises(Exception):
        Loan.take_out_loan(user_id=user.id, asset_id=asset.id, amount=loan_amount, collateral=collateral)


@pytest.mark.usefixtures("app_context")
def test_take_out_loan_excess_amount_in_lending_pool(user_and_asset):
    user, asset = user_and_asset
    loan_amount = Decimal('500.00')
    collateral = Decimal('25.00')
    with pytest.raises(Exception):
        Loan.take_out_loan(user_id=user.id, asset_id=asset.id, amount=loan_amount, collateral=collateral)
