from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app
from app.database import db
from app.models import LiquidityPool
from app.models.Pool import Pool

class TestPoolModel(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.app_context.push()
        db.create_all()
        db.session.begin_nested()

    # def test_create_pool(self):
    #     pool = Pool(name="Test Pool")
    #     db.session.add(pool)
    #     db.session.commit()

    #     self.assertIsNotNone(pool.id)
    #     self.assertEqual(pool.name, "Test Pool")

    # def test_pool_liquidity_relationship(self):
    #     pool = Pool(name="Test Pool")
    #     db.session.add(pool)
    #     db.session.flush()
    #     liquidity_pool = LiquidityPool(pool_id=pool.id, asset_id=1, asset_quantity=100, USD_quantity=100, total_liquidity_tokens=200)

    #     db.session.add(liquidity_pool)
    #     db.session.commit()

    #     self.assertEqual(pool.liquidity_pools.first(), liquidity_pool)

    # def test_delete_pool(self):
    #     pool = Pool(name="Test Pool")

    #     db.session.add(pool)
    #     db.session.commit()

    #     db.session.delete(pool)
    #     db.session.commit()

    #     self.assertIsNone(Pool.query.get(pool.id))
