from app.tests.base_test_case import BaseTestCase
from app.database import db
from app.models import AssetDividend
from collections import namedtuple
from unittest.mock import patch, MagicMock
from sqlalchemy.sql import func

class AssetDividendTest(BaseTestCase):

    def setUp(self):
        super().setUp()
        self.asset_dividend = AssetDividend(asset_id=1, USD=500)

    def test_creation(self):
        self.assertEqual(self.asset_dividend.asset_id, 1)
        self.assertEqual(self.asset_dividend.USD, 500)


    @patch.object(db.session, 'query')
    def test_latest_dividends_per_asset_no_dividends(self, mock_query):
        # Creating a mock subquery result with a 'c' attribute
        SubqueryMock = namedtuple('SubqueryMock', ['c'])
        mock_subquery = SubqueryMock(c=None)
        mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
        mock_query.return_value.join.return_value.all.return_value = []

        # Running Test
        result = AssetDividend.latest_dividends_per_asset()
        self.assertEqual(result, [])

    @patch.object(db.session, 'query')
    @patch.object(func, 'max')
    def test_latest_dividends_per_asset_single_dividend_per_asset(self, mock_max, mock_query):
        # Creating a mock subquery result with a 'c' attribute
        SubqueryMock = namedtuple('SubqueryMock', ['c'])
        mock_subquery = SubqueryMock(c=MagicMock(asset_id=1, max_id=1))
        dividend_mock = MagicMock(asset_id=1)
        mock_max.return_value.label.return_value = 1
        mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
        mock_query.return_value.join.return_value.all.return_value = [dividend_mock]

        # Running Test
        result = AssetDividend.latest_dividends_per_asset()
        self.assertEqual(result, [dividend_mock])

    @patch.object(db.session, 'query')
    @patch.object(func, 'max')
    def test_latest_dividends_per_asset_multiple_dividends_per_asset(self, mock_max, mock_query):
        # Creating a mock subquery result with a 'c' attribute
        SubqueryMock = namedtuple('SubqueryMock', ['c'])
        mock_subquery = SubqueryMock(c=MagicMock(asset_id=2, max_id=2))
        dividend_mock1 = MagicMock(asset_id=1)
        dividend_mock2 = MagicMock(asset_id=2)
        mock_max.return_value.label.return_value = 2
        mock_query.return_value.group_by.return_value.subquery.return_value = mock_subquery
        mock_query.return_value.join.return_value.all.return_value = [dividend_mock1, dividend_mock2]

        # Running Test
        result = AssetDividend.latest_dividends_per_asset()
        self.assertEqual(result, [dividend_mock1, dividend_mock2])