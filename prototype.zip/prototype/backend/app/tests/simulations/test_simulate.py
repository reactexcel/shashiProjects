import os

from app.tests.base_test_case import BaseTestCase
from app.test_app import create_test_app
from unittest.mock import patch, ANY
from app.simulations.simulation import simulate
from app import create_app
from app.simulations.simulation import setup_db_for_simulation, trade
from app.services import DividendService
from app.simulations.simulation import print_simulation_results

class TestSimulate(BaseTestCase):
    STRATEGY_FILE_NAME = "StrategyForTest.py"

    def setUp(self):
        super().setUp()
        self.app = create_test_app()
        self.app_context = self.app.app_context()
        self.client = self.app.test_client()
        self.app_context.push()

    def get_test_data(self, with_external_strategy=True):
        traders_data = [
            {"name": "Trader1", "email": "trader1@example.com", "strategy": "StrategyForTest" if with_external_strategy else "StrategyRandom"},
            {"name": "Trader2", "email": "trader2@example.com", "strategy": "StrategyRandom"},
            {"name": "Trader3", "email": "trader3@example.com", "strategy": "StrategyYieldMaximization"},
            {"name": "Trader4", "email": "trader3@example.com", "strategy": "StrategyRandomLoans"},
            {"name": "Trader5", "email": "trader3@example.com", "strategy": "StrategyRandomLoanDeposits"},
            {"name": "Trader6", "email": "trader3@example.com", "strategy": "StrategyMaximizeLoanDepositInterest"},
        ]
        pm25_data = [
            {"asset_id": 2, "pm_25_10_minute": 23.54, "payout_cycle_id": 45},
            {"asset_id": 1, "pm_25_10_minute": 12.87, "payout_cycle_id": 72},
            {"asset_id": 4, "pm_25_10_minute": 37.12, "payout_cycle_id": 18}
        ]
        loan_deposit_data = [
            {"user_id": 1, "amount": 100000.00, "asset_id": 2},
            {"user_id": 2, "amount": 200000.00, "asset_id": 1},
            {"user_id": 3, "amount": 300000.00, "asset_id": 4}
        ]

        return traders_data, pm25_data, loan_deposit_data

    @patch('app.create_app', side_effect=create_app)
    @patch('app.simulations.simulation.setup_db_for_simulation', side_effect=setup_db_for_simulation)
    @patch('app.simulations.simulation.trade', side_effect=trade)
    @patch('app.services.DividendService.distribute_dividends')
    @patch('app.simulations.simulation.print_simulation_results', side_effect=print_simulation_results)
    def test_simulate(self, print_simulation_results_mock, distribute_dividends_mock, trade_mock, setup_db_for_simulation_mock, create_app_mock):
        traders_data, pm25_data, loan_deposit_data = self.get_test_data(with_external_strategy=False)
        for _ in simulate(pm25_data=pm25_data, traders=traders_data, loan_deposits=loan_deposit_data):
            pass

        dividend_service_instance = DividendService()
        distribute_dividends_mock.side_effect = dividend_service_instance.distribute_dividends
        create_app_mock.assert_called_once_with(simulator=True, database_uri=ANY)
        setup_db_for_simulation_mock.assert_called_once_with(pm25_data=pm25_data, profile_data=traders_data, loan_deposits=loan_deposit_data)
        trade_mock.assert_called()
        distribute_dividends_mock.assert_called()
        print_simulation_results_mock.assert_called()

        os.remove('db_name_counter.txt')