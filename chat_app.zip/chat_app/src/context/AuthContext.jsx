import { onAuthStateChanged } from "firebase/auth";
import { createContext, useEffect, useState } from "react";
import { auth } from "../pages/firebase";

export const myContext = createContext();
export const AuthContextProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState({});

  useEffect(() => {
    const sub = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      // console.log(user, "userrrrrrrrrrrrrrrrrr");
    });
    
    return () => {
      sub();
    };
  }, []);
  return (
    <myContext.Provider value={{ currentUser }}>{children}</myContext.Provider>
  );
};
