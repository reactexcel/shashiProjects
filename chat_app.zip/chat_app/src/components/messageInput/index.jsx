import styles from "../messageInput/messageInput.module.css";
import { IoMdAttach } from "react-icons/io";
import { FcAddImage } from "react-icons/fc";


const MessageInput = () => {
  return (
    <div className={styles.input}>
      <input type="text" placeholder="Type something..." />
      <div className={styles.icons}>
        <IoMdAttach size={22} />
        <input type="file" name="file" id="file" style={{display:"none"}} />
        <label htmlFor="file">
          <FcAddImage size={26} />
        </label>
        <button className={styles.btn}>send</button>
      </div>
    </div>
  );
};

export default MessageInput;
