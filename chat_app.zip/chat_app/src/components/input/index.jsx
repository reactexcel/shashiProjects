import React from "react";

const InputField = ({
  placeholder,
  type,
  inputStyle,
  handleChange,
  handleKey,
}) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      className={inputStyle}
      onChange={handleChange}
      onKeyDown={handleKey}
    />
  );
};

export default InputField;
