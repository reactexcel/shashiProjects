import styles from "../messages/messages.module.css"
import Message from "../message";

const Messages = () => {
  return (
      <div className={styles.messages}>
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
        <Message />
      </div>
  );
};

export default Messages;
