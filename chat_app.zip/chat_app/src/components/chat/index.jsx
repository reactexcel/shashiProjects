import styles from "../chat/chat.module.css";
import { IoVideocam } from "react-icons/io5";
import { RiUserAddFill } from "react-icons/ri";
import { LuMoreVertical } from "react-icons/lu";
import Messages from "../messages";
import MessageInput from "../messageInput"
import InputField from "../input";

const Chat = () => {
  return (
    <div className={styles.chat}>
      <div className={styles.userChatInfo}>
        <span>user</span>
        <div className={styles.icon}>
          <IoVideocam size={20} />
          <RiUserAddFill size={20} />
          <LuMoreVertical size={22} />
        </div>
      </div>
      <Messages />
      <MessageInput />
    </div>
  );
};

export default Chat;
