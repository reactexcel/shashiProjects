import styles from "../navbar/navbar.module.css";
import { FaPowerOff } from "react-icons/fa";

const Navbar = () => {
  return (
    <div className={styles.container}>
      <p>Chat-app</p>
      <div className={styles.user}>
        <img
          src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8dXNlcnxlbnwwfHwwfHx8MA%3D%3D"
          alt="user"
        />
        <p>name</p>
        <FaPowerOff size={20} color="#eb4034" />
      </div>
    </div>
  );
};

export default Navbar;
