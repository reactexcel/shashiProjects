import ChatsInfo from "../chatsInfo";
import Navbar from "../navbar";
import Search from "../search";
import styles from "../sidebar/sidebar.module.css";

const SideBar = () => {
  return (
    <div className={styles.sidebar}>
      <Navbar />
      <Search />
      <ChatsInfo />
      <ChatsInfo />
      <ChatsInfo />
      <ChatsInfo />
      <ChatsInfo />
      <ChatsInfo />
    </div>
  );
};

export default SideBar;
