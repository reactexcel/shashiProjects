import React from "react";
import { signOut } from "firebase/auth";
import { auth } from "../firebase";
import { useNavigate } from "react-router-dom";
import SideBar from "../../components/sidebar";
import Chat from "../../components/chat";
import styles from "../home/home.module.css";

const Home = () => {
  const navigate = useNavigate();

  const handleLogOut = () => {
    signOut(auth);
    navigate("/login");
  };

  return (
    <div className={styles.home}>
      <div className={styles.container}>
        <SideBar />
        <Chat />
      </div>
    </div>
  );
};

export default Home;
