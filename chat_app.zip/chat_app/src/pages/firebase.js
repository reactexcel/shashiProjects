import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAemXfAVGXh1ZrTaHanYu9Ojn9T3oDdjH4",
  authDomain: "chat-f99cf.firebaseapp.com",
  projectId: "chat-f99cf",
  storageBucket: "chat-f99cf.appspot.com",
  messagingSenderId: "795061951333",
  appId: "1:795061951333:web:bd254ee3f3edea6fb49f8c"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth();
export const storage = getStorage();
export const db = getFirestore();