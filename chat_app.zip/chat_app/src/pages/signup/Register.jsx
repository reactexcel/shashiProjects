import { useState } from "react";
import { Link } from "react-router-dom";
import styles from "../signup/register.module.css";
import { FaCloudUploadAlt } from "react-icons/fa";
import { createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
import { auth, storage, db } from "../firebase";
import { ref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { collection, addDoc, setDoc, doc } from "firebase/firestore";




const Register = () => {
  const [error, setError] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const displayName = e.target[0].value;
    const email = e.target[1].value;
    const password = e.target[2].value;
    const file = e.target[3].files[0];



    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      const storageRef = ref(storage, displayName);
      const uploadTask = uploadBytesResumable(storageRef, file);

      uploadTask.on(
        (error) => {
          setError(true);
          console.error(error);
        },
        async () => {
          try {
            const downloadURL = await getDownloadURL(uploadTask.snapshot.ref);
            await updateProfile(res.user, {
              displayName,
              photoURL: downloadURL,
            });
            await setDoc(doc(db, "users", res.user.uid), {
              uid: res.user.uid,
              displayName,
              email,
              photoURL: downloadURL,
            });

            await setDoc(doc(db,"userChats",res.user.uid),{})
          } catch (error) {
            setError(true);
            console.error(error);
          }
        }
      );
    } catch (error) {
      setError(true);
      console.error(error);
    }
  };
  

  return (
    <div className={styles.container}>
      <form className={styles.form} onSubmit={handleSubmit}>
        <h2>Register</h2>
        <input type="text" placeholder="Enter Your Name" name="name" />
        <input type="text" placeholder="Enter Your Email" name="email" />
        <input
          type="password"
          placeholder="Enter Your Password"
          name="password"
        />
        <input type="file" id="file" style={{ display: "none" }} />
        <label
          htmlFor="file"
          style={{
            display: "flex",
            gap: "10px",
            color: "#fff",
            cursor: "pointer",
            width: "50%",
            margin: "auto",
          }}
        >
          <FaCloudUploadAlt size={24} />
          upload Avatar
        </label>
        <button className={styles.btn} type="submit">
          Register
        </button>
        {error && <p style={{ color: "red" }}>Something went wrong.</p>}
        <div className={styles.login}>
          <p className={styles.loginbtn}>
            I have an account?
            <Link to="/login" className="">
              Log in
            </Link>
          </p>
        </div>
      </form>
    </div>
  );
};

export default Register;
