import { useEffect, useState } from 'react';
import { Menu, MenuItem, SubMenu } from 'react-pro-sidebar';
import { Link, Outlet, json, useLocation, useNavigate } from 'react-router-dom';
import WalletRoundedIcon from '@mui/icons-material/WalletRounded';
import SettingsApplicationsRoundedIcon from '@mui/icons-material/SettingsApplicationsRounded';
import HomeIcon from '@mui/icons-material/Home';
import AssessmentIcon from '@mui/icons-material/Assessment';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AssignmentIcon from '@mui/icons-material/Assignment';
import ManageAccountsIcon from '@mui/icons-material/ManageAccounts';
import Snackbar from '@mui/material/Snackbar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Avatar from '@mui/material/Avatar';
import { deepOrange } from '@mui/material/colors';
import BasicList from './avatar';
import Auth from '../hooks/auth.hook';
import { useSelector } from 'react-redux';
import { Grid } from '@mui/material';

const Nav = () => {
  const [showLogout, setShowLogout] = useState(false);
  const { snackBar, handleClose } = Auth();
  const user = useSelector((store) => store.user);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem('Authorization')) {
      navigate('/home');
    }else{
      navigate('/login');
    }
  }, [navigate]);

  const isSelected = (path) => location.pathname === path;

  const selectedStyle = {
    cursor: 'none',
    pointerEvents: 'none',
  };
  const resources = JSON.parse(localStorage.getItem('resources'));
  return (
    <>
      <Grid container sx={{ width: '100%', bgcolor: '#000' }}>
        <Grid item xs={2}>
          <Box className="example" sx={{ bgcolor: '#000', height: '100vh', overflowY: 'auto' }}>
            <Menu style={{}}>
              <Box style={{ display: 'flex', alignItems: 'center' }}>
                <img src={require('../images/renoon_app_icon.png')} alt="panda" height={'80px'} width={'70px'} className="logo-dashboard" />
                <Typography sx={{ color: 'white', mt: 4 }}>Renoon</Typography>
              </Box>
              <Box mt={4} pl={2} sx={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <MenuItem
                  style={isSelected('/home') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }}
                  component={<Link to="home" className={`link ${isSelected('/home') ? 'selected' : ''}`} />}
                  icon={<HomeIcon />}
                >
                  Home
                </MenuItem>
                {resources?.userManagement && (
                  <SubMenu className="user-management" style={{ borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }} label="User Management" icon={<ManageAccountsIcon />}>
                    <MenuItem
                      style={isSelected('/brand') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }}
                      component={<Link to="/brand" className={`link ${isSelected('/brand') ? 'selected' : ''}`} />}
                    >
                      Brand
                    </MenuItem>
                    <MenuItem
                      style={isSelected('/role') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }}
                      component={<Link to="/role" className={`link ${isSelected('/role') ? 'selected' : ''}`} />}
                    >
                      Role
                    </MenuItem>
                    <MenuItem
                      style={isSelected('/user') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }}
                      component={<Link to="/user" className={`link ${isSelected('/user') ? 'selected' : ''}`} />}
                    >
                      User
                    </MenuItem>
                  </SubMenu>
                )}
                {resources?.measure && (
                  <SubMenu className="measures" style={{ borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }} label="Measures" icon={<AssessmentIcon />}>
                    <MenuItem
                      style={
                        isSelected('/claim-management')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/claim-management" className={`link ${isSelected('/claim-management') ? 'selected' : ''}`} />}
                    >
                      Claim Management
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/order-engine')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/order-engine" className={`link ${isSelected('/order-engine') ? 'selected' : ''}`} />}
                    >
                      Order Engine
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/product-engine')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/product-engine" className={`link ${isSelected('/product-engine') ? 'selected' : ''}`} />}
                    >
                      Product Engine
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/supplier-map')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/supplier-map" className={`link ${isSelected('/supplier-map') ? 'selected' : ''}`} />}
                    >
                      Supplier Map
                    </MenuItem>
                  </SubMenu>
                )}
                {resources?.compliance && (
                  <SubMenu className="compliance" style={{ borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }} label="Compliance" icon={<AssignmentIcon />}>
                    <MenuItem
                      style={
                        isSelected('/compliance-overview')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/compliance-overview" className={`link ${isSelected('/compliance-overview') ? 'selected' : ''}`} />}
                    >
                      Overview
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/production-compliance')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/production-compliance" className={`link ${isSelected('/production-compliance') ? 'selected' : ''}`} />}
                    >
                      Production Compliance
                    </MenuItem>
                  </SubMenu>
                )}
                {resources?.reports && (
                  <SubMenu className="reports" style={{ borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }} label="Reports" icon={<TrendingUpIcon />}>
                    <MenuItem
                      style={
                        isSelected('/reporting') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/reporting" className={`link ${isSelected('/reporting') ? 'selected' : ''}`} />}
                    >
                      Reporting
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/reports-overview')
                          ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                          : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/reports-overview" className={`link ${isSelected('/reports-overview') ? 'selected' : ''}`} />}
                    >
                      Overview
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/product-lca') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/product-lca" className={`link ${isSelected('/product-lca') ? 'selected' : ''}`} />}
                    >
                      Product LCA
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/clustering') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/clustering" className={`link ${isSelected('/clustering') ? 'selected' : ''}`} />}
                    >
                      Clustering
                    </MenuItem>
                  </SubMenu>
                )}
                {resources?.impactLabel && (
                  <SubMenu className="impact-label" style={{ borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }} label="Impact Label" icon={<WalletRoundedIcon />}>
                    <MenuItem
                      style={
                        isSelected('/ecom-widget') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/ecom-widget" className={`link ${isSelected('/ecom-widget') ? 'selected' : ''}`} />}
                    >
                      E-com Widget
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/qr-codes') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/qr-codes" className={`link ${isSelected('/qr-codes') ? 'selected' : ''}`} />}
                    >
                      QR codes
                    </MenuItem>
                    <MenuItem
                      style={
                        isSelected('/analytics') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                      }
                      component={<Link to="/analytics" className={`link ${isSelected('/analytics') ? 'selected' : ''}`} />}
                    >
                      Analytics
                    </MenuItem>
                  </SubMenu>
                )}
                {resources?.settings && (
                  <MenuItem
                    style={
                      isSelected('/settings') ? { ...selectedStyle, borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' } : { borderTopLeftRadius: '50px', borderBottomLeftRadius: '50px' }
                    }
                    component={<Link to="settings" className={`link ${isSelected('/settings') ? 'selected' : ''}`} />}
                    icon={<SettingsApplicationsRoundedIcon />}
                  >
                    Settings
                  </MenuItem>
                )}
              </Box>
            </Menu>
          </Box>
        </Grid>
        <Grid item xs={10} sx={{ borderTopLeftRadius: '30px', borderBottomLeftRadius: '30px', bgcolor: '#f2f2f2', height: '100vh' }}>
          <Box
            sx={{
              borderTopLeftRadius: '30px',
              display: 'flex',
              alignItems: 'center',
              height: '15vh',
              justifyContent: 'space-between',
              px: 4,
              position: 'sticky',
              top: '0px',
              bgcolor: '#f2f2f2',
              zIndex: '100',
            }}
          >
            <Typography variant="h6" color="#000" fontWeight={'bold'} textTransform={'capitalize'}>
              {location.pathname.replace(/^\//, '')}
            </Typography>

            <div onClick={() => setShowLogout(true)} style={{ display: 'flex', alignItems: 'center' }}>
              <Avatar sx={{ bgcolor: deepOrange[500], marginRight: '10px', height: '40px' }} alt="Remy Sharp" src="/broken-image.jpg">
                {user?.name?.split(' ')[0] && user.name.split(' ')[0][0] && user?.name.split(' ')[0][0].toUpperCase()}
                {user?.name?.split(' ')[1] && user.name.split(' ')[1][0] && user?.name.split(' ')[1][0].toUpperCase()}
              </Avatar>
            </div>
          </Box>
          <Box sx={{ height: '85vh', overflowY: 'auto', zIndex: '10' }} onClick={() => setShowLogout(false)} px={2}>
            <Outlet />
          </Box>
        </Grid>
      </Grid>
      <Snackbar
        open={snackBar.open}
        autoHideDuration={2000}
        message="Your session has been expired"
        anchorOrigin={{
          vertical: snackBar.vertical,
          horizontal: snackBar.horizontal,
        }}
        onClose={handleClose}
        className="snackBarColor"
        key={snackBar.vertical + snackBar.horizontal}
      />
      <BasicList name={user?.name} email={user?.email} showLogout={showLogout} setShowLogout={setShowLogout} />
    </>
  );
};

export default Nav;
