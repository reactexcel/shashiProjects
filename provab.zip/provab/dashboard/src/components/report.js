import React from 'react';

const Report = () => {
  return <div>Report</div>;
};

export default Report;
