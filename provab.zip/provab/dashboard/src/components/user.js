import React, { useState, useEffect } from 'react';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { Box, Card, CardContent, Dialog, DialogContent, IconButton, InputAdornment, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import { CommonButton } from './utils/CommonButton';
import SearchIcon from '@mui/icons-material/Search';
import AlertDialog from './utils/AlertDialog';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';

const User = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [brandId, setBrandId] = useState('');
  const [roleId, setRoleId] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const [brands, setBrands] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [validationErrors, setValidationErrors] = useState({});
  const [openDialog, setOpenDialog] = useState(false);

  useEffect(() => {
    fetchBrands();
    fetchRoles();
    fetchUsers();
  }, []);

  useEffect(() => {
    setFilteredUsers(users);
  }, [users]);

  const fetchBrands = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.brandUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setBrands(response.data.data);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.roleUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setRoles(response.data.data);
    } catch (error) {
      console.error('Error fetching roles:', error);
    }
  };

  const fetchUsers = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.userUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setUsers(response.data.data);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  };

  const validateForm = () => {
    const errors = {};

    if (!firstName.trim()) errors.firstName = 'First Name is required';
    if (!lastName.trim()) errors.lastName = 'Last Name is required';
    if (!email.trim()) {
      errors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Email is invalid';
    }
    if (!updateMode && !password.trim()) errors.password = 'Password is required';
    if (!roleId) errors.roleId = 'Role is required';
    if (!brandId) errors.brandId = 'Brand is required';

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const createUser = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const user = {
        firstName,
        lastName,
        email,
        password,
        roleId,
        brandId,
      };

      const response = await httpService.post(RestUrlsConstants.userUrl, user, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      if(response.status===200){
        handleClose()
      }

      if (!response.data) {
        throw new Error('Failed to create user');
      }

      await fetchUsers();
      setShowForm(false);
      setFirstName('');
      setLastName('');
      setPassword('');
      setEmail('');
      setBrandId('');
      setRoleId('');
      setShowTable(true);
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const updateUser = async () => {
    if (!validateForm()) return;

    try {
      setLoading(true);
      setError(null);

      const updatedUser = {
        firstName,
        lastName,
        email,
        roleId,
        brandId,
      };

      if (password.trim() !== '') {
        updatedUser.password = password;
      }

      const res=await httpService.put(`${RestUrlsConstants.userUrl}${selectedUserId}`, updatedUser, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      if(res.status===200){
        handleClose()
      }

      await fetchUsers();
      setUpdateMode(false);
      setShowForm(false);
      setShowTable(true);
      setFirstName('');
      setLastName('');
      setPassword('');
      setEmail('');
      setBrandId('');
      setRoleId('');
      setSelectedUserId(null);
    } catch (error) {
      if (error?.response?.data?.message?.includes('duplicate key error')) {
        setError('A user with this email already exists.');
      } else {
        setError(error?.response?.data?.message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUser = (userId) => {
    const selectedUser = users.find((user) => user.id === userId);
    setFirstName(selectedUser.firstName);
    setLastName(selectedUser.lastName);
    setEmail(selectedUser.email);
    setPassword('');
    setBrandId(selectedUser.brand.id);
    setRoleId(selectedUser.role.id);
    setSelectedUserId(userId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
    handleOpen()
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (updateMode) {
      await updateUser();
    } else {
      await createUser();
    }
  };

  const deleteUser = async (userId) => {
    try {
      setLoading(true);
      setError(null);

      await httpService.delete(`${RestUrlsConstants.userUrl}${userId}`, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      await fetchUsers();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(!showTable);
    handleOpen()
  };

  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    if (term.trim() === '') {
      setFilteredUsers(users);
    } else {
      const filtered = users.filter(
        (user) => user.firstName.toLowerCase().includes(term.trim().toLowerCase()) || user.lastName.toLowerCase().includes(term.trim().toLowerCase()) || user.email.toLowerCase().includes(term.trim().toLowerCase())
      );
      setFilteredUsers(filtered);
    }
  };
  const [modalOpen, setModalOpen] = useState(false);

  const handleOpen = () => {
    setModalOpen(true);
  };

  const handleClose = () => {
    setModalOpen(false);
    setFirstName('');
    setLastName('');
    setPassword('');
    setEmail('');
    setBrandId('');
    setRoleId('');
  };

  const handleOpenDialog = (userId) => {
    setSelectedUserId(userId);
    setOpenDialog(true);
  };
  const handleDeleteRoles = async () => {
    await deleteUser(selectedUserId);
    setOpenDialog(false);
  };

  const handleCloseDialog = async () => {
    setOpenDialog(false);
    setSelectedUserId(null);
  };
  const totalPages = Math.ceil(filteredUsers.length / 5);

  const handlePageChange = (page) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  const indexOfLastUser = currentPage * 5;
  const indexOfFirstUser = indexOfLastUser - 5;
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
  const columns = ['First Name', 'Last Name', 'Email', 'Actions', ]
  return (
    <>
      <Card className="example" sx={{ borderRadius: '20px' }}>
        <CardContent>
          <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
            <CommonButton buttonName={'Add Users'} handleClick={toggleFormVisibility} />
            <TextField
              size="small"
              variant="outlined"
              placeholder="Search brands"
              value={searchTerm}
              onChange={handleSearchChange}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Box>
          <Dialog open={modalOpen} onClose={handleClose}>
            <DialogContent  className='example' sx={{width:'400px'}}>
            <div className="card-body">
                  <h3 className="mb-4 text-center">{updateMode ? 'Update User' : 'User Onboarding Form'}</h3>
                  {error && <div className="alert alert-danger">{error}</div>}
                  <form onSubmit={handleSubmit}>
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        id="firstName"
                        className="form-control"
                        placeholder="First Name"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                      />
                      {validationErrors.firstName && <div className="text-danger">{validationErrors.firstName}</div>}
                    </div>
                    <div className="form-group mb-4">
                      <input
                        type="text"
                        id="lastName"
                        className="form-control"
                        placeholder="Last Name"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                      />
                      {validationErrors.lastName && <div className="text-danger" style={{fontSize:"12px"}}>{validationErrors.lastName}</div>}
                    </div>
                    <div className="form-group mb-4">
                      <input
                        type="email"
                        id="email"
                        className="form-control"
                        placeholder="Email Address"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                      />
                      {validationErrors.email && <div className="text-danger" style={{fontSize:"12px"}}>{validationErrors.email}</div>}
                    </div>
                    {!updateMode && (
                      <div className="form-group mb-4">
                        <input
                          type="password"
                          id="password"
                          className="form-control"
                          placeholder="Password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        />
                        {validationErrors.password && <div className="text-danger" style={{fontSize:"12px"}}>{validationErrors.password}</div>}
                      </div>
                    )}
                    <div className="form-group mb-4">
                      <select id="roleId" className="form-control" value={roleId} onChange={(e) => setRoleId(e.target.value)} style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}>
                        <option value="">Select Role</option>
                        {roles.map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.name}
                          </option>
                        ))}
                      </select>
                      {validationErrors.roleId && <div className="text-danger" style={{fontSize:"12px"}}>{validationErrors.roleId}</div>}
                    </div>
                    <div className="form-group mb-4">
                      <select id="brandId" className="form-control" value={brandId} onChange={(e) => setBrandId(e.target.value)} style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}>
                        <option value="">Select Brand</option>
                        {brands.map((brand) => (
                          <option key={brand.id} value={brand.id}>
                            {brand.name}
                          </option>
                        ))}
                      </select>
                      {validationErrors.brandId && <div className="text-danger" style={{fontSize:"12px"}}>{validationErrors.brandId}</div>}
                    </div>
                    <button type="submit" className="btn btn-dark mt-3 w-100" disabled={loading}>
                      {loading ? (updateMode ? 'Updating User...' : 'Creating User...') : updateMode ? 'Update User' : 'Create User Account'}
                    </button>
                  </form>
                  <div className="d-flex justify-content-center mt-3">
                    <button
                      className="btn btn-secondary w-100"
                      onClick={() => {
                        setShowForm(false);
                        setShowTable(true);
                        setError(null);
                        handleClose()
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                </div>
            </DialogContent>
            </Dialog>
            <Box>
            <TableContainer>
              <Typography sx={{ fontWeight: 'bold', mt: 4, fontSize: '24px' }}>USERS</Typography>
              <Table sx={{ cursor: 'pointer' }}>
                <TableHead>
                  <TableRow>
                    {columns.map((column, index) => (
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }} key={index}>
                        {column}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentUsers.map((user, index) => (
                    <TableRow key={index}>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{user.firstName}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{user.lastName}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{user.email}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                          <FontAwesomeIcon style={{ color: 'blue' }} icon={faPenToSquare} onClick={() => handleUpdateUser(user.id)} />
                          <FontAwesomeIcon style={{ color: 'red' }} icon={faTrashCan} onClick={() => handleOpenDialog(user.id)} />
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <AlertDialog
                btnName={'Delete'}
                title={'Delete User'}
                description={'Are you sure you want to delete this user ?'}
                open={openDialog}
                handleClick={handleDeleteRoles}
                handleCloseDialog={handleCloseDialog}
              />
            </TableContainer>
            <Box mt={1} sx={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: 'gray' }}>Page: {currentPage}</span>
                <Box>
                  <IconButton disabled={currentPage === 1}>
                    <KeyboardArrowLeftIcon onClick={() => handlePageChange(currentPage - 1)} />
                  </IconButton>
                  <IconButton disabled={currentPage === totalPages}>
                    <KeyboardArrowRightIcon onClick={() => handlePageChange(currentPage + 1)} />
                  </IconButton>
                </Box>
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </>
  );
};

export default User;
