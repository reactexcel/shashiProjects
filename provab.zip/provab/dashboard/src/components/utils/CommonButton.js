import { Button } from '@mui/material';

export const CommonButton = ({ buttonName, handleClick }) => {
  return (
    <Button onClick={handleClick} sx={{px:3, bgcolor: '#000', color: '#fff', ':hover': { bgcolor: '#0a0a0a' }, borderRadius: '15px', textTransform: 'capitalize' }}>
      {buttonName}
    </Button>
  );
};
