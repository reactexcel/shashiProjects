const PATH = {
  NAV: '/',
  LOGIN: `/login`,
  FORGOTPASSWORD: `/forgot-password`,
  RESETPASSWORD: `/reset-password/:token`,
  HOME: `home`,
  ROLE: `role`,
  BRAND: `brand`,
  USER: `user`,
  REPORT: `report`,
  CLAIMMANAGEMENT: `claim-management`,
  ORDERENGINE: `order-engine`,
  PRODUCTENGINE: `product-engine`,
  SUPPLIERMAP: `supplier-map`,
};
export default PATH;
