import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import axios from 'axios';
import httpService from '../../service/http.service';
import { RestUrlsConstants } from '../../constants/rest-urls.constants';
import { Box, Card, CardContent, Chip, Snackbar, Tab, Tabs, Typography } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { CommonButton } from '../utils/CommonButton';
import ClaimCard from './claimCards';
import Loader from '../utils/loader';
import { FaHandPointUp } from 'react-icons/fa';
import { RiCompassFill } from 'react-icons/ri';

const ToggleButton = ({ id, label, selected, fetchClaim, setSnackBar }) => {
  const toggleSelect = () => {
    updateSelectedClaim();
  };

  const updateSelectedClaim = async () => {
    try {
      const response = await httpService.patch(`${RestUrlsConstants.claimUrl}${id}`, { selected: !selected }, { headers: { Authorization: localStorage.getItem('Authorization') } });
      setSnackBar({ open: true, message: `${response?.data?.message}` });
      fetchClaim();
    } catch (error) {
      console.error('Error updating claim:', error);
    }
  };

  return (
    <Chip
      sx={{ boxShadow: '1px 1px 1px 1px lightgray', fontWeight: 'bold' }}
      color={selected ? 'primary' : 'default'}
      label={label}
      onClick={toggleSelect}
      icon={selected && <CheckCircleIcon sx={{ color: '#fff', fontSize: '16px' }} />}
    />
  );
};

const SelectedClaims = () => {
  const token = localStorage.getItem('Authorization');
  const [data, setData] = useState([]);
  const [claimForm, setClaimForm] = useState([]);
  const [snackBar, setSnackBar] = useState({ open: false, message: '' });
  const [questionForm, setQuestionForm] = useState([]);
  const [loading, setLoading] = useState(true);
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
    fetchClaim(newValue);
  };

  const fetchClaim = async (mode) => {
    setLoading(true);
    try {
      const response = await axios.get(`${RestUrlsConstants.claimUrl}?mode=${mode === 0 ? 'SELECTION' : 'DISCOVERY'}`, { headers: { Authorization: token } });
      setData(response?.data?.data?.claims);
      setClaimForm(response?.data?.data?.forms);
    } catch (error) {
      console.error('Error fetching claims:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchQuestionForms = async (id) => {
    setLoading(true);
    try {
      const response = await httpService.get(`${RestUrlsConstants.formUrl}${id}`, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setQuestionForm(response?.data?.data);
    } catch (error) {
      console.error('Error fetching form:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchClaim(value);
  }, [value]);

  const handleClose = () => {
    setSnackBar({ open: false, message: '' });
  };

  return (
    <Box>
      <Box sx={{ flexGrow: 1, marginBottom: '20px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center' }}>
          <Tabs indicatorColor="" value={value} onChange={handleChange} sx={{ borderRadius: '20px' }}>
            <Tab
              label={
                <span style={{ display: 'flex', alignItems: 'center' }}>
                  <FaHandPointUp style={{ marginRight: 8, fontSize: '24px' }} /> Selected claim
                </span>
              }
              sx={{
                textTransform: 'none',
                display: 'flex',
                backgroundColor: '#d4d4d4',
                color: '#000',
                fontWeight: 'bold',
                fontSize: '14px',
                padding: '0px 50px',
                '&:hover': {
                  backgroundColor: '#e0e0e0',
                },
                '&.Mui-selected': {
                  backgroundColor: '#545454',
                  color: '#fff',
                  borderBottom: 'none',
                },
                '&.MuiTabs-indicator': {
                  display: 'none',
                },
              }}
            />
            <Tab
              label={
                <span style={{ display: 'flex', alignItems: 'center' }}>
                  <RiCompassFill style={{ marginRight: 8, fontSize: '24px' }} /> Discovery mode
                </span>
              }
              sx={{
                textTransform: 'none',
                backgroundColor: '#d4d4d4',
                color: '#000',
                fontWeight: 'bold',
                fontSize: '14px',
                padding: '0px 50px',
                '&:hover': {
                  backgroundColor: '#e0e0e0',
                },
                '&.Mui-selected': {
                  backgroundColor: '#545454',
                  color: '#fff',
                  borderBottom: 'none',
                },
                '&.MuiTabs-indicator': {
                  display: 'none',
                },
              }}
            />
          </Tabs>
        </Box>
      </Box>
      <Card sx={{ borderRadius: '20px', boxShadow: 'none' }}>
        <CardContent>
          {value === 0 ? (
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Box>
                <Typography sx={{ fontWeight: '700', fontSize: '16px' }}>Selected claims</Typography>
                <Typography sx={{ fontSize: '12px', color: 'gray' }}>
                  Select the values you want to claim to easily aggregate your data in the section below - <span style={{ color: 'black', fontWeight: 'bold' }}>updates automatically.</span>
                </Typography>
              </Box>
              <CommonButton buttonName={'Confirm Selection'} />
            </Box>
          ) : (
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <Box>
                <Typography sx={{ fontWeight: '700', fontSize: '16px' }}>Discovery mode</Typography>
                <Typography sx={{ fontSize: '12px', color: 'gray' }}>
                  View & reply to as many questions as you can to discover which values you could claim based on your data and documentation of proof.
                </Typography>
              </Box>
            </Box>
          )}

          {/* {loading && <Loader />} */}
          <Box mt={6} sx={{ display: 'flex', flexWrap: 'wrap', columnGap: '10px', rowGap: '20px' }}>
            {data.map((item, index) => (
              <ToggleButton key={index} id={item.id} fetchClaim={() => fetchClaim(value)} selected={item.selected} label={item.name} setSnackBar={setSnackBar} />
            ))}
          </Box>
        </CardContent>
      </Card>
      <Box mt={4}>
        <ClaimCard claimForm={claimForm} fetchQuestionForms={fetchQuestionForms} questionForm={questionForm} loading={loading} />
      </Box>
      <Snackbar
        open={snackBar.open}
        autoHideDuration={2000}
        message={snackBar.message}
        anchorOrigin={{
          vertical: 'top',
          horizontal: 'center',
        }}
        onClose={handleClose}
        className="snackBarColor"
        key="snackbar"
      />
    </Box>
  );
};

export default SelectedClaims;
