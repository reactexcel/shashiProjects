import { Box, Button, DialogActions, DialogContentText, Divider, InputLabel, Popover, Typography } from '@mui/material';
import CommonDialog from '../../utils/CommonDialog';
import { CommonButton } from '../../utils/CommonButton';
import { useRef, useState } from 'react';
import CommonInput from '../../utils/CommonInput';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import CommonSelect from '../../utils/CommonSelect';
import CommonOption from '../../utils/commonOption';
import httpService from '../../../service/http.service';
import { RestUrlsConstants } from '../../../constants/rest-urls.constants';
import Loader from '../../utils/loader';
import { RxTarget } from 'react-icons/rx';




export default function QuestionForm({ openQuestion, setOpenQuestionForm, formTitle, questionForm, loading }) {
  const fileInputRef = useRef(null);
  const [goal, setGoal] = useState(false);
  const [questionFormData, setQuestionFormData] = useState({});
  const [fileData, setFileData] = useState({});
  const [anchorEl, setAnchorEl] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [openCreateNewDialog, setOpenCreateNewDialog] = useState(false);
  const closeDialog = () => {
    setOpenDialog(false);
    setAnchorEl(false);
  };
  const closeCreateNewDialog = () => {
    setOpenCreateNewDialog(false);
    setAnchorEl(false);
  };
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const closePopover = () => {
    setAnchorEl(false);
  };

  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  const timeoutRef = useRef(null);
  const latestFormDataRef = useRef(questionFormData);
  const handleClose = () => {
    setOpenQuestionForm(false);
  };
  const handleQuestionAnswer = async (queId, formData) => {
    try {
      await httpService.post(`${RestUrlsConstants.formQueUrl}/${queId}`, formData, {
        headers: {
          Authorization: localStorage.getItem('Authorization'),
          'Content-Type': 'multipart/form-data',
        },
      });
    } catch (error) {
      console.log(error?.response?.data?.message);
    }
  };

  const handleInput = (e, id) => {
    const newValue = e.target.value;
    latestFormDataRef.current = {
      ...latestFormDataRef.current,
      [id]: newValue,
    };
    setQuestionFormData(latestFormDataRef.current);
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(() => {
      const formData = new FormData();
      formData.append('value', latestFormDataRef.current[id]);
      handleQuestionAnswer(id, formData);
    }, [2000]);
  };

  const handleFileInput = (e, id) => {
    const file = e.target.files[0];
    setFileData({
      ...fileData,
      [id]: file,
    });
    latestFormDataRef.current = {
      ...latestFormDataRef.current,
      [id]: file.name,
    };
    setQuestionFormData(latestFormDataRef.current);

    const formData = new FormData();
    formData.append('documents', file);
    handleQuestionAnswer(id, formData);
  };
  const handleSetGoals = (id) => {
    setGoal(true);
    // console.log("Goal set successfylly");
  };

  // console.log(questionFormData, '=======questionform11111111111111111111111111');
  return (
    <>
      <CommonDialog heading={formTitle?.title} open={openQuestion} handleClose={handleClose}>
        <DialogContentText sx={{ width: { sm: '500px', md: '800px' } }} mt={4}>
          <Typography sx={{ color: 'gray', fontWeight: '600', fontSize: '14px' }}>{formTitle?.description}</Typography>
          <Divider sx={{ mt: 2, height: '3px', bgcolor: 'gray' }} />
          {loading && <Loader />}
          <form>
            <Box>
              {questionForm?.map((form, index) => (
                <Box>
                  {['text', 'TEXT', 'number'].includes(form?.question?.type) && (
                    <CommonInput
                      label={form?.question?.title}
                      value={questionFormData[form?.question?.id]}
                      type={form?.question?.type}
                      tooltip={form?.question?.tooltipText}
                      variant="standard"
                      autoComplete={false}
                      handleChange={(e) => handleInput(e, form?.question?.id)}
                    />
                  )}

                  {form?.question?.type === 'dropdown' && (
                    <>
                      <CommonSelect
                        label={form?.question?.title}
                        options={form?.question?.validation?.validOptions}
                        value={questionFormData[form?.question?.id]}
                        handleChange={(e) => handleInput(e, form?.question?.id)}
                      />
                    </>
                  )}
                  {form?.question?.type === 'options' && (
                    <CommonOption
                    tooltip={form?.question?.tooltipText}
                      label={form?.question?.title}
                      options={form?.question?.validation?.validOptions}
                      value={questionFormData[form?.question?.id]}
                      handleChange={(e) => handleInput(e, form?.question?.id)}
                    />
                  )}
                  {form?.question?.showSetAsFutureGoal && (
                    <Button
                      variant="outlined"
                      sx={{ color: 'blue', fontWeight: '600', mt: 2, px: 2, borderRadius: '15px', border: '1px solid gray' }}
                      onClick={() => handleSetGoals(form?.question?.id)}
                    >
                      <RxTarget style={{ fontSize: '20px' }} /> Set as future goal
                    </Button>
                  )}
                  {form?.question?.fileUpload && (
                    <Box mt={4}>
                      {form?.question?.type === 'file' && <InputLabel sx={{ color: '#000', fontWeight: '600', fontSize: '14px' }}>{form?.question?.title}</InputLabel>}
                      <input ref={fileInputRef} type="file" onChange={(e) => handleFileInput(e, form?.question?.id)} hidden />
                      <Button
                        sx={{
                          marginTop: '20px',
                          height: '150px',
                          width: '100%',
                          color: 'black',
                          boxShadow: 'none',
                          border: '2px dashed gray',
                          background: '#f2f2f2',
                          display: 'flex',
                          flexDirection: 'column',
                          textTransform: 'none',
                          fontWeight: 'bold',
                          ':hover': { background: '#eeeeee', boxShadow: 'none' },
                        }}
                        variant="contained"
                        // onClick={()=>fileInputRef.current.click()}
                        onClick={handleClick}
                      >
                        <CloudUploadIcon sx={{ color: 'gray', fontSize: '40px' }} />
                        {fileData[form?.question?.id] ? fileData[form?.question?.id].name : 'Choose file'}
                        <span style={{ fontSize: '12px', fontWeight: 'normal' }}>pdf, doc, docx, csv, txt, xlsx, ppt, pptx, png, jpg, jpeg</span>
                      </Button>
                    </Box>
                  )}
                </Box>
              ))}
            </Box>
          </form>
          <DialogActions sx={{ mt: 2 }}>
            <CommonButton buttonName={'Back'} handleClick={handleClose} />
          </DialogActions>
        </DialogContentText>
      </CommonDialog>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={closePopover}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
      >
        <Typography onClick={() => setOpenDialog(true)} sx={{ p: 1, cursor: 'pointer', fontWeight: '600', fontSize: '14px' }}>
          Pick From Library
        </Typography>
        <Typography onClick={() => setOpenCreateNewDialog(true)} sx={{ p: 1, cursor: 'pointer', fontWeight: '600', fontSize: '14px' }}>
          Create New
        </Typography>
      </Popover>
      <CommonDialog heading={'Pick from library'} open={openDialog} handleClose={closeDialog}>
        <DialogContentText>
          <Typography>Pick form library</Typography>
        </DialogContentText>
      </CommonDialog>
      <CommonDialog heading={'Create new'} open={openCreateNewDialog} handleClose={closeCreateNewDialog}>
        <DialogContentText>
          <Typography>Create new</Typography>
        </DialogContentText>
      </CommonDialog>
    </>
  );
}
