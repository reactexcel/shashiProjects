import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Box, Grid } from '@mui/material';
import { CommonButton } from '../utils/CommonButton';
import QuestionForm from './questionForm/questionForm';

export default function ClaimCard({ claimForm, fetchQuestionForms,questionForm,loading }) {
  const [openQuestion, setOpenQuestionForm] = React.useState(false);
  const [formTitle,setFormTitle]=React.useState({title:"",description:""})
  return (
    <>
      <Grid container spacing={2}>
        {claimForm?.map((val) => (
          <Grid key={val.id} item xs={12} md={6}>
            <Card sx={{ boxShadow: 'none', borderRadius: '10px' }}>
              <CardMedia sx={{ height: '250px' }} image={val.imageUrl} title={val.title} />
              <CardContent sx={{ p: 2 }}>
                <Box>
                  <Typography sx={{ fontSize: '16px', fontWeight: 'bold' }} variant="h6">
                    {val.title}
                  </Typography>
                  <Typography sx={{ fontSize: '12px' }} color="text.secondary">
                    {val.shortDescription}
                  </Typography>
                </Box>
                <Box mt={2} sx={{ display: 'flex', justifyContent: 'end', flexDirection: 'column' }}>
                  <Typography sx={{ display: 'flex', justifyContent: 'end', textTransform: 'uppercase', fontWeight: 'bold', fontSize: '16px' }}>Questions answered</Typography>
                  <Typography sx={{ display: 'flex', justifyContent: 'end', fontWeight: 'bold', fontSize: '16px' }}>{'0/16'}</Typography>
                  <Box mt={1} sx={{ display: 'flex', justifyContent: 'end' }}>
                    <CommonButton
                      buttonName={'Begin'}
                      handleClick={() => {
                        fetchQuestionForms(val.id);
                        setFormTitle({title:val?.title,description:val?.description})
                        setOpenQuestionForm(true);
                      }}
                    />
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <QuestionForm openQuestion={openQuestion} setOpenQuestionForm={setOpenQuestionForm} formTitle={formTitle} questionForm={questionForm} loading={loading} />
    </>
  );
}
