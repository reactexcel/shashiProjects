import React, { useState, useEffect } from 'react';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { Box, Card, CardContent, Chip, IconButton, InputAdornment, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TextField, Typography } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import { CommonButton } from './utils/CommonButton';
import { Modal } from 'react-bootstrap';
import KeyboardArrowLeftIcon from '@mui/icons-material/KeyboardArrowLeft';
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import AlertDialog from './utils/AlertDialog';

const Brand = () => {
  const [brands, setBrands] = useState([]);
  const [filteredBrands, setFilteredBrands] = useState([]);
  const [brandName, setBrandName] = useState('');
  const [contractStartDate, setContractStartDate] = useState('');
  const [contractEndDate, setContractEndDate] = useState('');
  const [maxProducts, setMaxProducts] = useState('');
  const [maxUsers, setMaxUsers] = useState('');
  const [features, setFeatures] = useState('');
  const [contractFiles, setContractFiles] = useState([]);
  const [logo, setLogo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const [selectedBrandId, setSelectedBrandId] = useState(null);
  const [updateMode, setUpdateMode] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [formErrors, setFormErrors] = useState({});
  const [openDialog, setOpenDialog] = useState(false);
  const [brandId, setBrandId] = useState(null);

  useEffect(() => {
    fetchBrands();
  }, []);

  useEffect(() => {
    setFilteredBrands(brands);
  }, [brands]);

  const fetchBrands = async () => {
    try {
      const response = await httpService.get(RestUrlsConstants.brandUrl, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });
      setBrands(response.data.data);
      setShowTable(true);
    } catch (error) {
      console.error('Error fetching brands:', error);
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!brandName) errors.brandName = 'Brand Name is required';
    if (!contractStartDate) errors.contractStartDate = 'Contract Start Date is required';
    if (!contractEndDate) errors.contractEndDate = 'Contract End Date is required';
    if (!maxProducts) errors.maxProducts = 'Max Products is required';
    if (!maxUsers) errors.maxUsers = 'Max Users is required';
    if (!features) errors.features = 'Features are required';
    // if (!contractFiles) errors.contractFiles = 'Contract Files are required';
    // if (!logo) errors.logo = 'Logo is required';
    return errors;
  };

  const createBrand = async () => {
    try {
      setLoading(true);
      setError(null);

      const formData = new FormData();
      formData.append('name', brandName);
      formData.append('contractStartDate', contractStartDate.slice(0, 10));
      formData.append('contractEndDate', contractEndDate.slice(0, 10));
      formData.append('maxProducts', maxProducts);
      formData.append('maxUsers', maxUsers);
      formData.append('features', JSON.stringify(features.split(',').map((feature) => feature.trim())));

      for (let i = 0; i < contractFiles.length; i++) {
        formData.append('contractFiles', contractFiles[i]);
      }
      if (logo) {
        formData.append('logo', logo);
      }

      const response = await httpService.post(RestUrlsConstants.brandUrl, formData, {
        headers: {
          Authorization: localStorage.getItem('Authorization'),
          'Content-Type': 'multipart/form-data',
        },
      });

      if (!response.data) {
        throw new Error('Failed to create brand');
      }

      await fetchBrands();
      setShowForm(false);
      resetFormFields();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const updateBrand = async () => {
    try {
      setLoading(true);
      setError(null);
      const formData = new FormData();

      formData.append('name', brandName);
      formData.append('contractStartDate', contractStartDate.slice(0, 10));
      formData.append('contractEndDate', contractEndDate.slice(0, 10));
      formData.append('maxProducts', maxProducts);
      formData.append('maxUsers', maxUsers);
      formData.append('features', JSON.stringify(features.split(',').map((feature) => feature.trim())));

      if(contractFiles.length){
      for (let i = 0; i < contractFiles.length; i++) {
        formData.append('contractFiles', contractFiles[i]);
      }}

      if (logo) {
        formData.append('logo', logo);
      }

      await httpService.put(`${RestUrlsConstants.brandUrl}${selectedBrandId}`, formData, {
        headers: {
          Authorization: localStorage.getItem('Authorization'),
          'Content-Type': 'multipart/form-data',
        },
      });

      await fetchBrands();
      setUpdateMode(false);
      setShowForm(false);
      resetFormFields();
      setSelectedBrandId(null);
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const deleteBrand = async (brandId) => {
    try {
      setLoading(true);
      setError(null);

      await httpService.delete(`${RestUrlsConstants.brandUrl}${brandId}`, {
        headers: { Authorization: localStorage.getItem('Authorization') },
      });

      await fetchBrands();
    } catch (error) {
      setError(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateBrand = (brandId) => {
    const selectedBrand = brands.find((brand) => brand.id === brandId);
    setBrandName(selectedBrand.name);
    setContractStartDate(selectedBrand.contractStartDate);
    setContractEndDate(selectedBrand.contractEndDate);
    setMaxProducts(selectedBrand.maxProducts);
    setMaxUsers(selectedBrand.maxUsers);
    setFeatures(selectedBrand.features.join(','));
    setContractFiles([]);
    setLogo(null);
    setSelectedBrandId(brandId);
    setUpdateMode(true);
    setShowForm(true);
    setShowTable(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errors = validateForm();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      return;
    }
    if (updateMode) {
      await updateBrand();
    } else {
      await createBrand();
    }
  };

  const resetFormFields = () => {
    setBrandName('');
    setContractStartDate('');
    setContractEndDate('');
    setMaxProducts('');
    setMaxUsers('');
    setFeatures('');
    setContractFiles([]);
    setLogo(null);
    setFormErrors({});
  };

  const toggleFormVisibility = () => {
    setShowForm(!showForm);
    setUpdateMode(false);
    setShowTable(false);
  };

  const handleSearchChange = (e) => {
    const term = e.target.value;
    setSearchTerm(term);
    if (term.trim() === '') {
      setFilteredBrands(brands);
    } else {
      const filtered = brands.filter((brand) => brand.name.toLowerCase().includes(term.trim().toLowerCase()));
      setFilteredBrands(filtered);
    }
  };

  const handleFileChange = (e) => {
    const files = e.target.files;
    setContractFiles(files);
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    setLogo(file);
  };
  const handleCloseModal = () => {
    setShowForm(false);
    setShowTable(true);
    resetFormFields();
  };

  const handleOpenDialog = (brandId) => {
    setBrandId(brandId);
    setOpenDialog(true);
  };
  const handleDeleteBrand = async () => {
    await deleteBrand(brandId);
    setOpenDialog(false);
  };

  const handleCloseDialog = async () => {
    setOpenDialog(false);
    setBrandId(null);
  };

  const totalPages = Math.ceil(filteredBrands.length / 5);

  const handlePageChange = (page) => {
    if (page > 0 && page <= totalPages) {
      setCurrentPage(page);
    }
  };


  const indexOfLastBrand = currentPage * 5;
  const indexOfFirstBrand = indexOfLastBrand - 5;
  const currentBrands = filteredBrands.slice(indexOfFirstBrand, indexOfLastBrand);
  const columns = ['Brand Name', 'Contract Start Date', 'Contract End Date', 'Max Products', 'Max Users', 'Features', 'Contract Files', 'Logo', 'Actions'];

  return (
    <>
      <Card className="example" sx={{ borderRadius: '20px' }}>
        <CardContent>
          {/* {!showForm && ( */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
              <CommonButton buttonName={'Add Brand'} handleClick={toggleFormVisibility} />
              <TextField
                size="small"
                variant="outlined"
                placeholder="Search brands"
                value={searchTerm}
                onChange={handleSearchChange}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton>
                        <SearchIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Box>
          {/* )} */}

          <Modal className='example' size="lg" aria-labelledby="contained-modal-title-vcenter" centered show={showForm} onHide={() => setShowForm(false)} animation={false}>
            <Modal.Header closeButton onClick={handleCloseModal}>
              <Modal.Title>{updateMode ? 'UPDATE BRAND' : 'BRAND ONBOARDING FORM'}</Modal.Title>
            </Modal.Header>
            <Modal.Body>
              <div>
                <form onSubmit={handleSubmit}>
                  <div className="form-group mb-3 column">
                    <label htmlFor="brandName" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Brand Name:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="text"
                        id="brandName"
                        className="form-control"
                        placeholder="Brand Name"
                        value={brandName}
                        onChange={(e) => setBrandName(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.brandName && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.brandName}</p>}
                    </div>
                  </div>

                  <div className="form-group mb-3 column">
                    <label htmlFor="contractStartDate" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Contract Start Date:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="date"
                        id="contractStartDate"
                        className="form-control"
                        placeholder="Contract Start Date"
                        value={contractStartDate ? contractStartDate.slice(0, 10) : ''}
                        onChange={(e) => setContractStartDate(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.contractStartDate && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.contractStartDate}</p>}
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="contractEndDate" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Contract End Date:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="date"
                        id="contractEndDate"
                        className="form-control"
                        placeholder="Contract End Date"
                        value={contractEndDate ? contractEndDate.slice(0, 10) : ''}
                        onChange={(e) => setContractEndDate(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.contractEndDate && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.contractEndDate}</p>}
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="maxProducts" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Max Products:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="number"
                        id="maxProducts"
                        className="form-control"
                        placeholder="Max Products"
                        value={maxProducts}
                        onChange={(e) => setMaxProducts(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.maxProducts && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.maxProducts}</p>}
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="maxUsers" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Max Users:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="number"
                        id="maxUsers"
                        className="form-control"
                        placeholder="Max Users"
                        value={maxUsers}
                        onChange={(e) => setMaxUsers(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.maxUsers && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.maxUsers}</p>}
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="features" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Features:
                    </label>
                    <div className="col-sm-12">
                      <input
                        type="text"
                        id="features"
                        className="form-control"
                        placeholder="Features"
                        value={features}
                        onChange={(e) => setFeatures(e.target.value)}
                        style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }}
                        required
                      />
                      {formErrors.features && <p className="text-danger" style={{fontSize:"12px"}}>{formErrors.features}</p>}
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="contractFiles" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Contract Files:
                    </label>
                    <div className="col-sm-12">
                      <input type="file" id="contractFiles"  className="form-control" onChange={handleFileChange} multiple style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} />
                    </div>
                  </div>
                  <div className="form-group mb-3 column">
                    <label htmlFor="logo" className="col-sm-3 col-form-label font-weight-bold text-right">
                      Logo:
                    </label>
                    <div className="col-sm-12">
                      <input type="file" id="logo"  className="form-control" onChange={handleLogoChange} multiple style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} />
                    </div>
                  </div>

                  <div style={{ display: 'flex', gap: '20px', alignItems: 'end', justifyContent: 'right' }}>
                    <button onClick={handleSubmit} className="btn btn-dark">
                      {loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                          <span className="sr-only">Loading...</span>
                        </>
                      ) : updateMode ? (
                        'Update'
                      ) : (
                        'Submit'
                      )}
                    </button>
                    <button onClick={handleCloseModal} className="btn btn-secondary">
                      Cancel
                    </button>
                  </div>
                </form>
              </div>
            </Modal.Body>
          </Modal>
          <Box>
            <TableContainer>
              <Typography sx={{ fontWeight: 'bold', mt: 4, fontSize: '24px' }}>BRANDS</Typography>
              <Table sx={{ cursor: 'pointer' }}>
                <TableHead>
                  <TableRow>
                    {columns.map((column, index) => (
                      <TableCell sx={{ fontWeight: '700', fontSize: '12.5px' }} key={index}>
                        {column}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentBrands.map((brand, index) => (
                    <TableRow key={brand.id}>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{brand.name}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{new Date(brand.contractStartDate).toLocaleDateString()}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{new Date(brand.contractEndDate).toLocaleDateString()}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{brand.maxProducts}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{brand.maxUsers}</TableCell>
                      <TableCell sx={{ fontWeight: '700', fontSize: '12px' }}>{brand.features.join(', ')}</TableCell>
                      <TableCell>
                        {brand.contractFiles.map((file, i) => (
                          <Box sx={{mb:"2px"}} key={i}>
                            <a className='download' href={`${file}`} rel="noopener noreferrer">
                              <Chip sx={{ fontSize: '12px'}} size="small" label="Download" color="warning" />
                            </a>
                          </Box>
                        ))}
                      </TableCell>
                      <TableCell>{brand.logo && <img src={`${brand.logo}`} alt="" style={{ width: '40px', height: '40px' }} />}</TableCell>
                      <TableCell>
                        <Box sx={{ display: 'flex', gap: '20px', justifyContent: 'center', alignItems: 'center' }}>
                          <FontAwesomeIcon style={{ color: 'blue' }} icon={faPenToSquare} onClick={() => handleUpdateBrand(brand.id)} />
                          <FontAwesomeIcon style={{ color: 'red' }} icon={faTrashCan} onClick={() => handleOpenDialog(brand.id)} />
                        </Box>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <AlertDialog
                btnName={'Delete'}
                title={'Delete Brand'}
                description={'Are you sure you want to delete this brand ?'}
                open={openDialog}
                handleClick={handleDeleteBrand}
                handleCloseDialog={handleCloseDialog}
              />
            </TableContainer>
            <Box mt={1} sx={{ display: 'flex', justifyContent: 'end', alignItems: 'center' }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <span style={{ fontSize: '12px', color: 'gray' }}>Page: {currentPage}</span>
                <Box>
                  <IconButton disabled={currentPage === 1}>
                    <KeyboardArrowLeftIcon onClick={() => handlePageChange(currentPage - 1)} />
                  </IconButton>
                  <IconButton disabled={currentPage === totalPages}>
                    <KeyboardArrowRightIcon onClick={() => handlePageChange(currentPage + 1)} />
                  </IconButton>
                </Box>
              </Box>
            </Box>
          </Box>
        </CardContent>
      </Card>
    </>
  );
};

export default Brand;
