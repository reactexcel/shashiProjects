import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import httpService from '../service/http.service';
import { RestUrlsConstants } from '../constants/rest-urls.constants';

const useLoginHook = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [snackBar, setsnackBar] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'center',
    message: '',
  });

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClose = () => setsnackBar({ ...snackBar, open: false });
  const handleMouseDownPassword = (event) => event.preventDefault();
  const email = useRef(null);
  const password = useRef(null);
  const navigate = useNavigate();

  const signIn = async () => {
    if (email.current.value && password.current.value) {
      try {
        const login = await httpService.post(RestUrlsConstants.loginUrl, {
          email: email.current.value,
          password: password.current.value,
        });
        setsnackBar({ ...snackBar, open: true, message: login.data.message });
        localStorage.setItem('Authorization', login.data.data.token);
        const expirationTime = Date.now() + 3600 * 1000; //1hour time set
        localStorage.setItem('resources', JSON.stringify(login?.data?.data?.resources));
        localStorage.setItem('tokenExpiration', expirationTime);
        navigate('/home');
        setupTokenExpirationHandler(expirationTime);
      } catch (e) {
        setsnackBar({ ...snackBar, open: true, message: e.response.data.message });
      }
    }
  };

  const setupTokenExpirationHandler = (expirationTime) => {
    const timeLeft = expirationTime - Date.now();
    setTimeout(() => {
      localStorage.removeItem('Authorization');
      localStorage.removeItem('resources');
      localStorage.removeItem('tokenExpiration');
      navigate('/login');
    }, timeLeft);
  };

  useEffect(() => {
    const token = localStorage.getItem('Authorization');
    const tokenExpiration = localStorage.getItem('tokenExpiration');
    if (token && tokenExpiration) {
      if (Date.now() < tokenExpiration) {
        setupTokenExpirationHandler(tokenExpiration);
        navigate('/home');
      } else {
        localStorage.removeItem('Authorization');
        localStorage.removeItem('resources');
        localStorage.removeItem('tokenExpiration');
        navigate('/login');
      }
    } else {
      navigate('/login');
    }
  }, [navigate]);

  return { showPassword, snackBar, email, password, handleClickShowPassword, handleClose, handleMouseDownPassword, signIn };
};

export default useLoginHook;
