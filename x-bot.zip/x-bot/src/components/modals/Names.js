import React, { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import {
  FormControl,
  InputLabel,
  Input,
  FormControlLabel,
  FormGroup,
  Switch,
  FormLabel,
  Box,
  Tab,
  Select,
  MenuItem,
  Typography,
} from "@mui/material";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import "../../App.css";
const defaultStorage = {
  isActive: false,
  ethAmount: 0,
  namesList: "[]",
  gasSpeed: 0,
};

export default function Names() {
  const [isActive, setIsActive] = useState(false);
  const [ethAmount, setEthAmount] = useState(0);
  const [name, setName] = useState("");
  const [namesList, setNamesList] = useState([]);
  const [removeName, setRemoveName] = useState("...");

  // for tabs
  const [value, setValue] = useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  useEffect(() => {
    const names = getNames();
    const isActive = names.isActive;
    const ethAmount = names.ethAmount;
    const namesList = JSON.parse(names.namesList);
    const removeName = namesList.length > 0 ? namesList[0] : "";
    setIsActive(isActive);
    setEthAmount(ethAmount);
    setNamesList(namesList);
    setRemoveName(removeName);
  }, [setIsActive, setEthAmount]);

  // helper for activate or deactivate auto buy by names
  const activateHandler = () => {
    const names = getNames();
    names.isActive = !isActive;
    setIsActive(!isActive);
    localStorage.setItem("names", JSON.stringify(names));
  };

  // helper for set eth amount
  const ethAmountHandler = (ethAmount) => {
    if (isNaN(ethAmount) || ethAmount < 0) return;

    const names = getNames();
    names.ethAmount = ethAmount;
    setEthAmount(ethAmount);
    localStorage.setItem("names", JSON.stringify(names));
  };

  // helper for add names
  const addNameHandler = () => {
    if (name.length === 0) return alert("Please input name");

    const names = getNames();
    namesList.push(name);
    setNamesList(namesList);
    const prevNames = JSON.parse(names.namesList);
    prevNames.push(name);
    names.namesList = JSON.stringify(prevNames);

    localStorage.setItem("names", JSON.stringify(names));
    setName("");
  };

  // helper for remove names
  const removeNameHandler = () => {
    const names = getNames();
    const filteredNames = namesList.filter((name) => name !== removeName);

    setNamesList(filteredNames);
    names.namesList = JSON.stringify(filteredNames);
    localStorage.setItem("names", JSON.stringify(names));
  };

  // helper for get names
  const getNames = () => {
    const names = localStorage.getItem("names")
      ? JSON.parse(localStorage.getItem("names"))
      : defaultStorage;

    return names;
  };

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
  };

  const gasSpeedHandler = (gasSpeed) => {
    const names = getNames();
    names.gasSpeed = gasSpeed;

    localStorage.setItem("names", JSON.stringify(names));
  };

  return (
    <>
      <Box sx={style} className="style2 style3">
        <FormGroup>
          <FormControlLabel
            control={
              <Switch
                defaultChecked={isActive}
                onChange={(e) => activateHandler()}
              />
            }
            label="Activate"
          />
        </FormGroup>

        <br />

        <FormControl onChange={(e) => console.log(e.target.value)}>
          <InputLabel sx={{ fontWeight: "700" }}>ETH amount</InputLabel>
          <Input
            value={ethAmount}
            onChange={(e) => ethAmountHandler(e.target.value)}
          />
          <FormLabel component="legend">
            <small>
              Set the amount of ETH to automatic purchase each new token with
              name you set
            </small>
          </FormLabel>
        </FormControl>

        <TabContext value={value}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleChange} aria-label="lab API tabs example">
              <Tab label="Add name" value="1" />
              <Tab label="Remove name" value="2" />
            </TabList>
          </Box>

          {/* Add name */}
          <TabPanel value="1">
            <InputLabel>Name</InputLabel>
            <Input
              style={{ width: "100%" }}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            <FormLabel component="legend">
              <small> Add name to track list</small>
            </FormLabel>

            <Box
              sx={{
                textAlign: "center",
                marginTop: { xs: "5px", md: "20px" },
              }}
            >
              <Button
                variant="contained"
                size="small"
                style={{
                  width: "70%",
                  backgroundColor: "#039BE5",
                  fontWeight: "600",
                  letterSpacing: "2px",
                  ":hover": { backgroundColor: "#027CB8" },
                }}
                onClick={() => addNameHandler()}
              >
                Add
              </Button>
            </Box>
          </TabPanel>

          {/* Remove name */}
          <TabPanel value="2">
            {namesList.length > 0 ? (
              <>
                <FormLabel component="legend">
                  <small>Select name for remove from track list</small>
                </FormLabel>
                <Select
                  value={removeName}
                  label="Age"
                  onChange={(e) => setRemoveName(e.target.value)}
                >
                  {namesList.map((item, key) => {
                    return (
                      <MenuItem value={item} key={key}>
                        {item}
                      </MenuItem>
                    );
                  })}
                </Select>
                <br />
                <br />
                <Button
                  variant="contained"
                  size="small"
                  style={{
                    width: "10em",
                    backgroundColor: "#9850DC",
                    fontWeight: "600",
                    letterSpacing: "2px",
                  }}
                  onClick={() => removeNameHandler()}
                >
                  Remove
                </Button>
              </>
            ) : (
              <Typography id="modal-desc" textColor="text.tertiary">
                You dont have names to track
              </Typography>
            )}
          </TabPanel>
        </TabContext>
        <FormLabel component="legend" sx={{ paddingTop: "2px" }}>
          <small style={{ fontWeight: "900" }}> Gas price </small>
        </FormLabel>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "40px",
          }}
        >
          <Button
            onClick={() => gasSpeedHandler(10)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "green",
              width: "40%",
              ":hover": { backgroundColor: "#0d8c31" },
            }}
          >
            Fast
          </Button>
          <Button
            onClick={() => gasSpeedHandler(0)}
            variant="contained"
            size="small"
            sx={{
              width: "40%",
              backgroundColor: "#039BE5",
              ":hover": { backgroundColor: "#027CB8" },
            }}
          >
            Market
          </Button>
        </Box>
      </Box>
    </>
  );
}
