import * as React from "react";
import Button from "@mui/material/Button";

import { CopyToClipboard } from "react-copy-to-clipboard";
import { Box } from "@mui/material";

export default function Settings() {
  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
    textAlign: "center",
  };

  return (
    <>
      <Box sx={style} className="style2">
        <CopyToClipboard
          text={localStorage.getItem("key")}
          onCopy={() => alert("Copied")}
        >
          <Button
            variant="contained"
            size="small"
            style={{
              width: "10em",
              backgroundColor: "#039BE5",
              ":hover": { backgroundColor: "#027CB8" },
              fontWeight: "600",
              letterSpacing: "2px",
            }}
          >
            Export key
          </Button>
        </CopyToClipboard>
      </Box>
    </>
  );
}
