import React, { useState } from "react";
import Button from "@mui/material/Button";
import {
  FormControl,
  InputLabel,
  Input,
  Box,
  Tab,
  CircularProgress,
  Typography,
} from "@mui/material";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import { scanURI } from "../../config";
import { isAddress, toWei } from "web3-utils";
import sendETH from "../../helpers/sendETH";
import sendERC20 from "../../helpers/sendERC20";
import decimals from "../../helpers/decimals.js";
import Web3 from "web3"; 

// helper for send ETH
const sendEthereum = async (to, amount, setHash, setShowPending) => {
  if (!isAddress(to)) return alert("Wrong recipient address");

  if (!amount && Number(amount) <= 0) return alert("Please input eth amount");

  setShowPending(true);
 
  // check key
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const key = localStorage.getItem("key");

  if (!key) return alert("Need set key");
 
  const value = toWei(String(amount));
  const gasPrice = await web3.eth.getGasPrice();
  const hash = await sendETH(key, value, gasPrice, to);
 
  setHash(hash);
  setShowPending(false);
};

// helper for send token
const sendToken = async (to, amount, token, setHash, setShowPending) => {
  if (!amount && Number(amount) <= 0) return alert("Please input token amount");

  if (!isAddress(to)) return alert("Wrong recipient address");

  if (!isAddress(token)) return alert("Wrong token address");

  setShowPending(true);

  // check key
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const key = localStorage.getItem("key");

  if (!key) return alert("Need set key");
  
   const _decimals = await decimals(token);
  const value = String(parseInt(amount * 10 ** _decimals));
  const gasPrice = await web3.eth.getGasPrice();
  const hash = await sendERC20(key, value, gasPrice, token, to);

  setHash(hash); 
  setShowPending(false);
};

export default function Send() { 
  const [ethAmount, setEthAmount] = useState(0);
  const [tokenAmount, setTokenAmount] = useState(0);
  const [tokenAddress, setTokenAddress] = useState("");
  const [recipient, setRecipient] = useState("");
  const [hash, setHash] = useState("");
  const [showPending, setShowPending] = useState(false);

  // for tabs
  const [value, setValue] = useState("1");
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
    textAlign: "center",
  };

  return (
    <>
      <Box sx={style} className="style2">
        <TabContext value={value}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleChange}>
              <Tab label="Send ETH" value="1" />
              <Tab label="Send token" value="2" />
            </TabList>
          </Box>

          {/* Send ETH*/}
          <TabPanel value="1">
            <FormControl
              onChange={(e) => setRecipient(e.target.value)}
              sx={{ width: "100%", margin: "14px 0" }}
            >
              <InputLabel>Recipient address</InputLabel>
              <Input />
            </FormControl>

            <FormControl
              onChange={(e) => setEthAmount(e.target.value)}
              sx={{ width: "100%", margin: "14px 0" }}
            >
              <InputLabel>ETH amount</InputLabel>
              <Input />
            </FormControl>

            <Button
              variant="contained"
              size="small"
              style={{
                width: "60%",
                marginTop: "10px",
                backgroundColor: "#039BE5",
                ":hover": { backgroundColor: "#027CB8" },
                fontWeight: "600",
                letterSpacing: "2px",
              }}
              onClick={() =>
                sendEthereum(recipient, ethAmount, setHash, setShowPending)
              }
            >
              Send
            </Button>
          </TabPanel>

          {/* Send ERC20 */}
          <TabPanel value="2">
            <FormControl
              onChange={(e) => setRecipient(e.target.value)}
              sx={{ width: "100%", margin: "14px 0" }}
            >
              <InputLabel>Recipient address</InputLabel>
              <Input />
            </FormControl>

            <FormControl
              onChange={(e) => setTokenAddress(e.target.value)}
              sx={{ width: "100%", margin: "14px 0" }}
            >
              <InputLabel>Token address</InputLabel>
              <Input />
            </FormControl>

            <FormControl
              onChange={(e) => setTokenAmount(e.target.value)}
              sx={{ width: "100%", margin: "14px 0" }}
            >
              <InputLabel>Token amount</InputLabel>
              <Input />
            </FormControl>

            <Button
              variant="contained"
              sx={{
                width: "60%",
                marginTop: { xs: "0px", md: "10px" },
                backgroundColor: "#039BE5",
                ":hover": { backgroundColor: "#027CB8" },
                fontWeight: "600",
                letterSpacing: "2px",
              }}
              onClick={() =>
                sendToken(
                  recipient,
                  tokenAmount,
                  tokenAddress,
                  setHash,
                  setShowPending
                )
              }
            >
              Send
            </Button>
          </TabPanel>
        </TabContext>
        {showPending ? (
          <>
            <CircularProgress />
            <small>processing transaction ...</small>
          </>
        ) : null}

        {hash && hash.length > 0 ? (
          <Typography id="modal-desc" textColor="text.tertiary">
            Transaction:{" "}
            {
              <a
                href={scanURI + "/tx/" + hash}
                target="_blank"
                rel="noreferrer"
              >
                {hash.slice(0, 10)}
              </a>
            }
          </Typography>
        ) : null}
      </Box>
    </>
  );
}
