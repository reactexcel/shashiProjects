import Button from "@mui/material/Button";
import {
  FormControl,
  InputLabel,
  Input,
  CircularProgress,
  TextField,
  Autocomplete,
  FormLabel,
  Box,
  Typography,
} from "@mui/material";
import tradeETHtoERC20 from "../../helpers/tradeETHtoERC20.js";
import tradeERC20toETH from "../../helpers/tradeERC20toETH.js";
import tradeERC20toERC20 from "../../helpers/tradeERC20toERC20";
import Web3 from "web3";
import { scanURI, WETH, UNISWAP_V2_ROUTER } from "../../config";
import getTokens from "../../storage/getTokens";
import { isAddress } from "web3-utils";
import decimals from "../../helpers/decimals.js";
import allowance from "../../helpers/allowance.js";
import approveERC20 from "../../helpers/approveERC20.js";
import { useEffect, useState } from "react";
import "../../App.css";

const swap = async (tokens, from, to, amount, setHash, setShowPending) => {
  // check inputs
  if (!amount && Number(amount) <= 0) return alert("Please input amount");

  const fromObj = tokens.filter((item) => item.symbol === from);
  if (!fromObj[0]) return alert("Please select from");

  const toObj = tokens.filter((item) => item.symbol === to);
  if (!toObj[0]) return alert("Please select to");

  // check key
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const key = localStorage.getItem("key");

  if (!key) return alert("Need set key");

  // show loading
  setShowPending(true);

  // prepare tx data
  const _decimals = fromObj[0].decimals
    ? fromObj[0].decimals
    : await decimals(fromObj[0].address);

  // convert input to wei
  const value = String(parseInt(amount * 10 ** _decimals));
  // get current gas price
  const gasPrice = await web3.eth.getGasPrice();

  let hash;

  // trade ETH to ERC20
  if (String(fromObj[0].address).toLowerCase() === String(WETH).toLowerCase()) {
    hash = await tradeETHtoERC20(key, value, 1, gasPrice, toObj[0].address);
  }
  // ERC20 case
  else {
    // check allowance
    const account = localStorage.getItem("account");
    const _allowance = await allowance(
      fromObj[0].address,
      account,
      UNISWAP_V2_ROUTER
    );

    // approve it not enough allowance
    if (amount > _allowance / 10 ** _decimals) {
      const maxApprove =
        "115792089237316195423570985008687907853269984665640564039457584007913129639935";
      await approveERC20(
        key,
        maxApprove,
        gasPrice,
        fromObj[0].address,
        UNISWAP_V2_ROUTER
      );
    }

    // trade ERC20 to ETH
    if (String(toObj[0].address).toLowerCase() === String(WETH).toLowerCase()) {
      hash = await tradeERC20toETH(key, value, 1, gasPrice, fromObj[0].address);
    }

    // trade ERC20 to ERC20
    if (String(toObj[0].address).toLowerCase() === String(WETH).toLowerCase()) {
      hash = await tradeERC20toERC20(
        key,
        value,
        1,
        gasPrice,
        fromObj[0].address,
        toObj[0].address
      );
    }
  }

  // display result
  setShowPending(false);
  setHash(hash);
};

export default function BuyTokens() {
  const [amount, setAmount] = useState(0);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [hash, setHash] = useState("");
  const [showPending, setShowPending] = useState(false);
  const [symbols, setSymbols] = useState([]);
  const [customIndex, setCustomIndex] = useState(1);
  const [tokens, setTokens] = useState([]);

  useEffect(() => {
    const _tokens = getTokens();
    const symbols = _tokens.map((i) => i.symbol);
    setSymbols(symbols);
    setTokens(_tokens);
  }, []);

  // helper for catch address input
  const handleInput = (e, v, direction) => {
    if (isAddress(v)) {
      const customSymbol = `Custom token ${customIndex}`;
      setCustomIndex(customIndex + 1);

      symbols.push(customSymbol);
      setSymbols(symbols);

      tokens.push({
        name: customSymbol,
        symbol: customSymbol,
        address: v,
        chainId: null,
        decimals: null,
        logoURI: null,
      });

      setTokens(tokens);

      if (direction === "From") setFrom(customSymbol);

      if (direction === "To") setTo(customSymbol);
    }
  };

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: { xs: "24px", sm: "10px", md: "24px" },
    textAlign: "center",
  };

  return (
    <>
      <Box sx={style} className="style2">
        <FormLabel component="legend">
          <small style={{ fontWeight: "600", color: "#000", fontSize: "14px" }}>
            Select Symbol or paste Address
          </small>
        </FormLabel>

        <Autocomplete
          value={from}
          disablePortal
          id="from"
          options={symbols}
          sx={{
            width: "100%",
            borderColor: "1px solid #000",
            margin: "14px 0",
          }}
          onInputChange={(e, v) => handleInput(e, v, "From")}
          onChange={(e, v) => setFrom(v)}
          renderInput={(params) => <TextField {...params} label="From" />}
        />

        <Autocomplete
          value={to}
          disablePortal
          id="to"
          options={symbols}
          sx={{ width: "100%" }}
          onInputChange={(e, v) => handleInput(e, v, "To")}
          onChange={(e, v) => setTo(v)}
          renderInput={(params) => <TextField {...params} label="To" />}
        />
        <FormControl
          onChange={(e) => setAmount(e.target.value)}
          sx={{ width: "100%", margin: "14px 0" }}
        >
          <InputLabel>Swap amount</InputLabel>
          <Input />
        </FormControl>

        <Button
          variant="contained"
          size="small"
          style={{
            width: "60%",
            backgroundColor: "#039BE5",
            ":hover": { backgroundColor: "#027CB8" },
            fontWeight: "600",
            letterSpacing: "2px",
          }}
          onClick={() =>
            swap(tokens, from, to, amount, setHash, setShowPending)
          }
        >
          Swap
        </Button>
        {showPending ? (
          <>
            <CircularProgress />
            <small>processing transaction ...</small>
          </>
        ) : null}
        {hash && hash.length > 0 ? (
          <Typography id="modal-desc" textColor="text.tertiary">
            Transaction:{" "}
            {
              <a
                href={scanURI + "/tx/" + hash}
                target="_blank"
                rel="noreferrer"
              >
                {hash.slice(0, 10)}
              </a>
            }
          </Typography>
        ) : null}
      </Box>
    </>
  );
}
