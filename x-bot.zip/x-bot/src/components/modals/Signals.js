import React, { useEffect, useState } from "react";
import {
  FormControl,
  InputLabel,
  Input,
  FormControlLabel,
  FormGroup,
  Switch,
  FormLabel,
  Box,
  Button,
} from "@mui/material";

const defaultStorage = { isActive: false, ethAmount: 0, gasSpeed: 0 };

export default function Signals() {
  const [isActive, setIsActive] = useState(false);
  const [ethAmount, setEthAmount] = useState(0);

  useEffect(() => {
    const _signals = localStorage.getItem("signals");
    if (_signals) {
      const signals = JSON.parse(_signals);
      const isActive = signals.isActive;
      const ethAmount = signals.ethAmount;
      setIsActive(isActive);
      setEthAmount(ethAmount);
    } else {
      setIsActive(false);
      setEthAmount(0);
    }
  }, [setIsActive]);

  const activateHandler = () => {
    const signals = localStorage.getItem("signals")
      ? JSON.parse(localStorage.getItem("signals"))
      : defaultStorage;

    signals.isActive = !isActive;

    setIsActive(!isActive);
    localStorage.setItem("signals", JSON.stringify(signals));
  };

  const ethAmountHandler = (ethAmount) => {
    if (isNaN(ethAmount) || ethAmount < 0) return;

    const signals = localStorage.getItem("signals")
      ? JSON.parse(localStorage.getItem("signals"))
      : defaultStorage;

    signals.ethAmount = ethAmount;

    setEthAmount(ethAmount);
    localStorage.setItem("signals", JSON.stringify(signals));
  };

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
  };

  const gasSpeedHandler = (gasSpeed) => {
    const signals = localStorage.getItem("signals")
      ? JSON.parse(localStorage.getItem("signals"))
      : defaultStorage;

    signals.gasSpeed = gasSpeed;

    localStorage.setItem("signals", JSON.stringify(signals));
  };

  return (
    <>
      <Box sx={style} className="style2">
        <FormGroup>
          <FormControlLabel
            control={
              <Switch
                defaultChecked={isActive}
                onChange={(e) => activateHandler()}
              />
            }
            label="Activate"
          />
        </FormGroup>
        <br />
        <FormControl onChange={(e) => console.log(e.target.value)}>
          <InputLabel style={{fontSize:"14px"}}>ETH amount</InputLabel>
          <Input
            value={ethAmount}
            onChange={(e) => ethAmountHandler(e.target.value)}
          />
          <FormLabel component="legend">
            <small>
              Set the amount of ETH to automatic purchase by platform signals
            </small>
          </FormLabel>
        </FormControl>
        <FormLabel component="legend" sx={{ paddingTop: "10px" }}>
          <small style={{ fontWeight: "900" }}> Gas price </small>
        </FormLabel>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "40px",
            marginTop: "10px",
          }}
        >
          <Button
            onClick={() => gasSpeedHandler(10)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "green",
              ":hover": { backgroundColor: "#0d8c31" },
              width: "40%",
            }}
          >
            Fast
          </Button>
          <Button
            onClick={() => gasSpeedHandler(0)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "#039BE5",
              ":hover": { backgroundColor: "#027CB8" },
              width: "40%",
            }}
          >
            Market
          </Button>
        </Box>
      </Box>
    </>
  );
}
