import React, { useEffect, useState } from "react";
import {
  FormControl,
  InputLabel,
  Input,
  FormControlLabel,
  FormGroup,
  Switch,
  FormLabel,
  Box,
  Button,
} from "@mui/material";

const defaultStorage = { isActive: false, ethAmount: 0, gasSpeed: 0 };

export default function Snipe() {
  const [isActive, setIsActive] = useState(false);
  const [ethAmount, setEthAmount] = useState(0);

  useEffect(() => {
    const _snipe = localStorage.getItem("snipe");
    if (_snipe) {
      const snipe = JSON.parse(_snipe);
      const isActive = snipe.isActive;
      const ethAmount = snipe.ethAmount;
      setIsActive(isActive);
      setEthAmount(ethAmount);
    } else {
      setIsActive(false);
      setEthAmount(0);
    }
  }, [setIsActive]);

  const activateHandler = () => {
    const snipe = localStorage.getItem("snipe")
      ? JSON.parse(localStorage.getItem("snipe"))
      : defaultStorage;

    snipe.isActive = !isActive;

    setIsActive(!isActive);
    localStorage.setItem("snipe", JSON.stringify(snipe));
  };

  const ethAmountHandler = (ethAmount) => {
    if (isNaN(ethAmount) || ethAmount < 0) return;

    const snipe = localStorage.getItem("snipe")
      ? JSON.parse(localStorage.getItem("snipe"))
      : defaultStorage;

    snipe.ethAmount = ethAmount;

    setEthAmount(ethAmount);
    localStorage.setItem("snipe", JSON.stringify(snipe));
  };

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
  };

  const gasSpeedHandler = (gasSpeed) => {
    const snipe = localStorage.getItem("snipe")
      ? JSON.parse(localStorage.getItem("snipe"))
      : defaultStorage;

    snipe.gasSpeed = gasSpeed;

    localStorage.setItem("snipe", JSON.stringify(snipe));
  };

  return (
    <>
      <Box sx={style} className="style2">
        <FormGroup>
          <FormControlLabel
            control={
              <Switch
                defaultChecked={isActive}
                onChange={(e) => activateHandler()}
              />
            }
            label="Activate"
          />
        </FormGroup>
        <br />
        <FormControl onChange={(e) => console.log(e.target.value)}>
          <InputLabel sx={{ fontWeight: "700" }}>ETH amount</InputLabel>
          <Input
            value={ethAmount}
            onChange={(e) => ethAmountHandler(e.target.value)}
          />
          <FormLabel component="legend">
            <small>
              {" "}
              Set the amount of ETH to automatic purchase each new token added
              to DEX
            </small>
          </FormLabel>
        </FormControl>
        <FormLabel component="legend" sx={{ paddingTop: "10px" }}>
          <small style={{ fontWeight: "900" }}> Gas price </small>
        </FormLabel>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            gap: "40px",
          }}
        >
          <Button
            onClick={() => gasSpeedHandler(10)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "green",
              ":hover": { backgroundColor: "#0d8c31" },
              width: "40%",

            }}
          >
            Fast
          </Button>
          <Button
            onClick={() => gasSpeedHandler(0)}
            variant="contained"
            size="small"
            sx={{
              backgroundColor: "#039BE5",
              ":hover": { backgroundColor: "#027CB8" },
              width: "40%",
            }}
          >
            Market
          </Button>
        </Box>
      </Box>
    </>
  );
}
