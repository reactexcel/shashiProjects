import * as React from "react";
import Button from "@mui/material/Button";
import {
  FormControl,
  InputLabel,
  Input,
  FormLabel,
  Box,
  Tab,
  Modal,
} from "@mui/material";
import { TabContext, TabList, TabPanel } from "@mui/lab";
import Web3 from "web3";

const generateKey = async (setKey, setAccount, setOpen) => {
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const wallet = web3.eth.accounts.create();
  console.log(`Private Key: \n${wallet.privateKey}`);
  console.log(`Address: \n${wallet.address}`);

  localStorage.setItem("account", wallet.address);
  localStorage.setItem("key", wallet.privateKey);

  setAccount(wallet.address);
  setKey(wallet.privateKey);
  setOpen();
};

const _setKey = async (key, setOpen, setAccount) => {
  const web3 = new Web3(process.env.REACT_APP_RPC);
  try {
    const fromObj = await web3.eth.accounts.privateKeyToAccount(key);
    const from = fromObj.address;
    localStorage.setItem("account", from);
    setAccount(fromObj.address);
  } catch (e) {
    console.log("error", e);
    return alert("Wrong private key");
  }
  localStorage.setItem("key", key);
  setOpen(false);
};

export default function SetKey({ setAccount, open, setOpen }) {
  const handleClose = () => setOpen(false);
  const [key, setKey] = React.useState("");
  const [value, setValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  React.useEffect(() => {
    const key = localStorage.getItem("key");
    if (!key) setOpen(true);
  }, []);

  const style = {
    position: "absolute",
    left: "50%",
    transform: "translate(-50%, -50%)",
    bgcolor: "#dcdcde",
    border: "2px solid #fff",
    borderRadius: "12px",
    boxShadow: 24,
    p: 4,
    textAlign: "center",
  };

  console.log();
  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style} className="style2">
          <Box sx={{ width: "100%", typography: "body1" }}>
            <TabContext value={value}>
              <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
                <TabList
                  onChange={handleChange}
                  aria-label="lab API tabs example"
                >
                  <Tab label="Create" value="1" />
                  <Tab label="Import" value="2" />
                </TabList>
              </Box>

              {/* Create key */}
              <TabPanel value="1">
                {key.length > 0 ? (
                  <>{key}</>
                ) : (
                  <Button
                    variant="contained"
                    size="small"
                    style={{
                      width: "50%",
                      marginTop: "10px",
                      backgroundColor: "#039BE5",
                      ":hover": { backgroundColor: "#027CB8" },
                      fontWeight: "600",
                      letterSpacing: "2px",
                    }}
                    onClick={() => generateKey(setKey, setAccount, setOpen)}
                  >
                    Create
                  </Button>
                )}
              </TabPanel>

              {/* Import key */}
              <TabPanel value="2">
                <FormControl
                  onChange={(e) => setKey(e.target.value)}
                  sx={{ width: "100%" }}
                >
                  <InputLabel>Key</InputLabel>
                  <Input />
                  <FormLabel component="legend">
                    <small> Your keys will be stored in local storage </small>
                  </FormLabel>
                </FormControl>
                <br />
                <br />
                <Button
                  variant="contained"
                  size="small"
                  style={{
                    width: "60%",
                    backgroundColor: "#039BE5",
                    ":hover": { backgroundColor: "#027CB8" },
                    fontWeight: "600",
                    letterSpacing: "2px",
                  }}
                  onClick={() => _setKey(key, setOpen, setAccount)}
                >
                  Save
                </Button>
              </TabPanel>
            </TabContext>
          </Box>
        </Box>
      </Modal>
    </>
  );
}
