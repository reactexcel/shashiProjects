import * as React from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import BuyTokens from "../modals/Swap";
import Send from "../modals/Send";
import Signals from "../modals/Signals";
import Names from "../modals/Names";
import Snipe from "../modals/Snipe";
import Settings from "../modals/Settings";
import {Tabs } from "@mui/material";

const mobTabs = [
  { id: "1", value: "SWAP" },
  { id: "2", value: "SEND" },
  { id: "3", value: "SIGNALS" },
  { id: "4", value: "NAMES" },
  { id: "5", value: "SNIPE" },
  { id: "6", value: "SETTINGS" },
];

export default function MobileNavTab({ open }) {
  const [value, setValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const mobcomponent = function () {
    switch (value) {
      case "1":
        return <BuyTokens />;
      case "2":
        return <Send />;
      case "3":
        return <Signals />;
      case "4":
        return <Names />;
      case "5":
        return <Snipe />;
      case "6":
        return <Settings />;
      default:
        return null;
    }
  };


  return (
    <Box sx={{ display: "flex", justifyContent: "center" }}>
      <TabContext value={value}>
        {!open && (
          <>
            <Box
              sx={{
                maxWidth: { xs: 320, sm: 480 },
                bgcolor: "#212020",
                borderRadius:"10px",
                height:"40px"
              }}
            >
              <Tabs
                value={value}
                onChange={handleChange}
                variant="scrollable"
                scrollButtons="auto"
                indicatorColor="primary"
              >
                {mobTabs.map((ele) => (
                  <Tab
                    sx={{ fontWeight: "600",color:"#e0dcdc" }}
                    key={ele.id}
                    label={ele.value}
                    value={ele.id}
                  />
                ))}
              </Tabs>
            </Box>
            <Box>{mobcomponent()}</Box>
            {/* <Box>
            <Button
              variant="contained"
              sx={{
                color: "#fff",
                fontWeight: "600",
                letterSpacing: "2px",
                borderRadius: "4px",
                height: "30px",
                backgroundColor: "#9850DC",
                ":hover": {
                  color: "#fff",
                  backgroundColor: "#9850DC",
                },
              }}
              onClick={() => {
                window.open(`${scanURI}/address/${account}`, "_blank");
              }}
            >
              Scan
            </Button>
          </Box> */}
          </>
        )}
      </TabContext>
    </Box>
  );
}
