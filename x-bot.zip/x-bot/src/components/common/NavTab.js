import * as React from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import BuyTokens from "../modals/Swap";
import Send from "../modals/Send";
import Signals from "../modals/Signals";
import Names from "../modals/Names";
import Snipe from "../modals/Snipe";
import Settings from "../modals/Settings";
import { Button } from "@mui/material";
import { scanURI } from "../../config";

const Tabs = [
  { id: "1", value: "SWAP" },
  { id: "2", value: "SEND" },
  { id: "3", value: "SIGNALS" },
  { id: "4", value: "NAMES" },
  { id: "5", value: "SNIPE" },
  { id: "6", value: "SETTINGS" },
];

export default function NavTab() {
  const [value, setValue] = React.useState("1");
  const [account, setAccount] = React.useState("");

  React.useEffect(() => {
    const account = localStorage.getItem("account");
    if (account) setAccount(account);
  }, []);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%", typography: "body1" }}>
      <TabContext value={value}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <TabList onChange={handleChange}>
            {Tabs.map((ele) => (
              <Tab
                key={ele.id}
                sx={{ color: "#fff", fontWeight: "600", width:"30px" }}
                label={ele.value}
                value={ele.id}
              />
            ))}
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <Button
                variant="contained"
                sx={{
                  color: "#fff",
                  fontWeight: "600",
                  letterSpacing: "2px",
                  borderRadius: "4px",
                  height: "30px",
                  marginLeft:"20px",
                  backgroundColor: "#039BE5",
                  ":hover": { backgroundColor: "#027CB8" },
                }}
                onClick={() => {
                  window.open(`${scanURI}/address/${account}`, "_blank");
                }}
              >
                Scan
              </Button>
            </Box>
          </TabList>
        </Box>
        <TabPanel sx={{ color: "#fff" }} value="1">
          <BuyTokens />
        </TabPanel>
        <TabPanel sx={{ color: "#fff" }} value="2">
          <Send />
        </TabPanel>
        <TabPanel sx={{ color: "#fff" }} value="3">
          <Signals />
        </TabPanel>
        <TabPanel sx={{ color: "#fff" }} value="4">
          <Names />
        </TabPanel>
        <TabPanel sx={{ color: "#fff" }} value="5">
          <Snipe />
        </TabPanel>
        <TabPanel sx={{ color: "#fff" }} value="6">
          <Settings />
        </TabPanel>
      </TabContext>
    </Box>
  );
}
