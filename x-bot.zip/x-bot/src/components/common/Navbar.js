import { Box, Typography } from "@mui/material";
import NavTab from "./NavTab";
import MobileNavTab from "./MobileNav";

const Navbar = ({ open }) => {
  return (
    <Box
      sx={{
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <Box>
        <Typography
          variant="h1"
          sx={{
            color: "#fff",
            fontSize: { xs: "24px", md: "30px" },
            fontWeight: "800",
          }}
        >
          XBOT
        </Typography>
      </Box>
      {!open && (
        <>
          <Box className="nav">
            <NavTab />
          </Box>
          <Box className="nav2">
            <MobileNavTab open={open} />
          </Box>
        </>
      )}
    </Box>
  );
};

export default Navbar;
