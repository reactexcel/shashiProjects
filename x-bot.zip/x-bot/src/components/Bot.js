// import React, { useEffect, useState } from "react";
// import Box from "@mui/material/Box";
// import Button from "@mui/material/Button";
// import Swap from "./modals/Swap";
// import Snipe from "./modals/Snipe";
// import Signals from "./modals/Signals";
// import Settings from "./modals/Settings";
// import Names from "./modals/Names";
// import Send from "./modals/Send";
// import { scanURI } from "../config";

// export default function Bot() {
//   const [account, setAccount] = useState("");

//   useEffect(() => {
//     const account = localStorage.getItem("account");
//     if (account) setAccount(account);
//   }, []);

//   return (
//     <Box Box sx={{ display: "flex", gap: "18px" }} className="nav2">
//       <Swap />
//       <Send />
//       <Signals />
//       <Names />
//       <Snipe />
//       <Settings />
//       <Button
//         sx={{
//           color: "#B8B0BE",
//           fontWeight: "700",
//           letterSpacing: "2px",
//           borderRadius: "10px",
//           ":hover":{color:"#fff"}
//         }}
//         className="btn"
//         onClick={() => {
//           window.open(`${scanURI}/address/${account}`, "_blank");
//         }}
//       >
//         Scan
//       </Button>
//       {/* <Button
//         variant="contained"
//         style={{color:"#fff"  }}
//         disabled
//       >
//         Buy limit
//       </Button>
//       <Button
//         variant="contained"
//         style={{color:"#fff"}}
//         disabled
//       >
//         Sell limit
//       </Button> */}
//     </Box>
//   );
// }
