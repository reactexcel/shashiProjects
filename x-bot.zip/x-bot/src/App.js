import React, { useEffect, useState } from "react";
import Alert from "@mui/material/Alert";
import SetKey from "./components/modals/SetKey";
import socketClient from "./socketClient";
import { CopyToClipboard } from "react-copy-to-clipboard";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { curency } from "./config";
import Navbar from "./components/common/Navbar";
import { Box } from "@mui/material";
import "./App.css";
import MobileNavTab from "./components/common/MobileNav";

export default function App() {
  const [account, setAccount] = useState("");
  const [open, setOpen] = React.useState(false);

  useEffect(() => {
    const account = localStorage.getItem("account");
    if (account) setAccount(account);

    socketClient();
  }, []);

  return (
    <Box className="main" sx={{ width: "100%" }}>
      <Box sx={{ padding: "10px 18px"}}>
        <Navbar open={open} />
      </Box>
      <Box className="nav3">
        <MobileNavTab open={open} />
      </Box>
      {account.length > 0 ? (
        <Alert
          severity="info"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "6px 20px",
          }}
        >
          Network: {curency} &nbsp; {account} &nbsp;
          <CopyToClipboard text={account} onCopy={() => alert("Copied")}>
            <ContentCopyIcon />
          </CopyToClipboard>
        </Alert>
      ) : null}
      <SetKey setAccount={setAccount} open={open} setOpen={setOpen} />
    </Box>
  );
}
