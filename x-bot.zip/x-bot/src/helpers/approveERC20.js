import ERC20_ABI from '../abi/ERC20_ABI'
import signTx from "./signTx"
import Web3 from 'web3'
import { 
  CHAINID
} from '../config'

const web3 = new Web3(process.env.REACT_APP_RPC);
const gas = 500000

// create buy transaction
// params: from - user account, value - bnb amount
// return prepared for sign transaction
const createTx = async (from, value, gasPrice, token, to) => {
    const contract = new web3.eth.Contract(ERC20_ABI, token)
    const data = contract.methods.approve(to, value).encodeABI({from})
  
    const nonce = await web3.eth.getTransactionCount(from)
  
    const tx = {
      from,
      to: token,
      value: 0,
      data,
      gasPrice,
      gas,
      "chainId": CHAINID,
      nonce: nonce
    }
  
    return tx
}

// bot buy token by eth(bnb) amount
// params: private key index, eth(bnb) amount
const approveERC20 = async (key, value, gasPrice, token, to) => {
  const accountObj = await web3.eth.accounts.privateKeyToAccount(key)
  const account = accountObj.address
  console.log("account", account)
  const tx = await createTx(account, value, gasPrice, token, to)
  const hash = await signTx(tx, key)
  console.log("approve ERC20 : ", hash)
  return hash
}

export default approveERC20
