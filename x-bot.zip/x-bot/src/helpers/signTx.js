import Web3 from 'web3'

const signTx = async (transactionObject, key) => {
  const web3 = new Web3(process.env.REACT_APP_RPC);
  const signedTransaction = await web3.eth.accounts.signTransaction(
    transactionObject,
    key
  );

  const transactionReceipt = await web3.eth.sendSignedTransaction(
    signedTransaction.rawTransaction
  );

  return transactionReceipt.transactionHash
}

export default signTx