const bnbTestNet = [
    {
        "name": "BNB",
        "address": "0x1c4ed1f3d87e5a6100cffd37b2a4e739f5b6bdd9",
        "symbol": "BNB",
        "decimals": 18,
        "chainId": 97,
        "logoURI": "https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png"
    },
    {
        "name": "TEST",
        "address": "0x7D7467C8925Ca8E1D166424551D0D262e3F801fA",
        "symbol": "TEST",
        "decimals": 18,
        "chainId": 97,
        "logoURI": ""
    }
]

export default bnbTestNet