import { io } from "socket.io-client"
import { API_EMITER_URI, net } from "./config"
import tradeETHtoERC20 from './helpers/tradeETHtoERC20.js'
import Web3 from 'web3';

const socket = io(API_EMITER_URI)

function onConnect() {
  console.log("Connected")
}

function onDisconnect() {
  console.log("Disconnected")
}

async function snipe(tokenAddress, network){
  await buyHelper("snipe", tokenAddress, network, null)
}

async function signals(tokenAddress, network){
  await buyHelper("signals", tokenAddress, network, null)
}

async function names(tokenAddress, name, network){
  await buyHelper("names", tokenAddress, network, name)
}

// snipe or signals handler 
async function buyHelper(method, tokenAddress, network, name){
  if(String(network).toLowerCase() !== net){
    console.log(`this ${method} signal not for current network`)
    return
  }

  const _localData = localStorage.getItem(method)

  if(_localData){
    const localData = JSON.parse(_localData)
    
    // check if method is active
    if(!localData.isActive){
      console.log(`${method} not active`)
      return
    }

    // special checker for names case 
    if(method === "names"){
      let namesArr = JSON.parse(localData.namesList)
      namesArr = namesArr.map(i => i = String(i).toLowerCase())
      if(!namesArr.includes(String(name).toLowerCase())){
        console.log(`This name ${name} not in track list`)
        return 
      }
    }
    
    // check key
    const key = localStorage.getItem("key"); 
    if(!key){
      console.log(`need set key for ${method}`)
      return 
    }
    
    // buy
    const web3 = new Web3(process.env.REACT_APP_RPC);
    const value = web3.utils.toWei(String(localData.ethAmount))

    // update gas price 
    const gasSpeed = localData.gasSpeed ? localData.gasSpeed : 0
    const gasPrice = await web3.eth.getGasPrice()
    const gasPriceToSend = gasSpeed > 0 
    ? String(parseInt(Number(gasPrice) + Number(gasPrice / 100 * gasSpeed))) 
    : gasPrice

    const hash = await tradeETHtoERC20(key, value, 1, gasPriceToSend, tokenAddress)

    console.log(`Successes ${method} buy ${hash}`)
  }
}

const socketClient = () => {
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);

    socket.on("buy-token", ({ tokenAddress, network}) => {
      signals(tokenAddress, network)
    });
    
    socket.on("new-token-created", ({ tokenAddress, name, network}) => {
      snipe(tokenAddress, network)
      names(tokenAddress, name, network)
    });


    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
}

export default socketClient